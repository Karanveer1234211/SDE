import numpy as np
from replay import find_entry,exit_fill,line
r=lambda i:100
bars=np.array([[99,100,98,99],[99,101,98,99],[99,103,99,102],[102,104,100,103],[103,105,101,104]],float)
assert find_entry(bars,0,r)==('signal',4)
bars[3,3]=99
assert find_entry(bars,0,r)==('break_failed',None)
assert exit_fill([100,110,90,101],95,108)==(95,'stop')
assert exit_fill([90,100,85,99],95,108)==(90,'gap')
assert line(np.array([110,100,106,101]),[0,2],True)(4)==102
assert line(np.array([110,109,106,101]),[0,2],True) is None
print('Timing, invalidation, conservative exits and anchor checks passed.')
