@echo off
cd /d "%~dp0"
python check.py
if errorlevel 1 exit /b 1
python replay.py --cache "C:\QuantData\cache_daily" --out "results_%RANDOM%_%RANDOM%"
pause
