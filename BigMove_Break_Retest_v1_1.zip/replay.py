"""Long-only BigMove daily trendline research, version 1."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

COLS = ['open','high','low','close']
LOOKBACK = 30
COST = 0.35

def pivots(values, high):
    test = np.max if high else np.min
    return [i for i in range(2,len(values)-2)
            if values[i] == test(values[i-2:i+3]) and
            np.count_nonzero(values[i-2:i+3]==values[i])==1]

def line(values, anchors, high):
    if len(anchors)<2:
        return None
    a,b = anchors[-2:]
    slope = (values[b]-values[a])/(b-a)
    levels = values[a]+(np.arange(a,len(values))-a)*slope
    sign = 1 if high else -1
    if sign*slope>=0 or np.any(sign*(values[a:]-levels)>1e-8):
        return None
    return lambda k: values[a]+(k-a)*slope

def find_entry(bars,start,resistance):
    broken = False
    for d in range(1,10):
        i = start+d
        if i>=len(bars) or not np.isfinite(bars[i]).all():
            return 'missing_watch',None
        close = bars[i,3]
        level = resistance(i)
        if broken:
            if close<level:
                return 'break_failed',None
            if bars[i,2]<=level<close:
                return 'signal',i+1
        elif bars[i-1,3]<=resistance(i-1) and close>level:
            broken=True
    return ('no_retest' if broken else 'no_break'),None

def exit_fill(bar,stop,target):
    o,h,l,_ = bar
    if o<=stop or o>=target:
        return o,'gap'
    if l<=stop:
        return stop,'stop'
    if h>=target:
        return target,'target'
    return None,None

def replay(bars,dates,idx,signal_close):
    if idx<LOOKBACK-1:
        return {'result':'missing_history'}
    bars=bars[idx-LOOKBACK+1:]
    dates=dates[idx-LOOKBACK+1:]
    k=LOOKBACK-1
    hist=bars[:LOOKBACK]
    if not np.isfinite(hist).all():
        return {'result':'missing_history'}
    h,l,c=hist[:,1],hist[:,2],hist[:,3]
    if not np.isclose(c[-1],signal_close,rtol=1e-5,atol=.005):
        return {'result':'price_mismatch'}
    weeks=dates[:LOOKBACK].to_period('W-FRI')
    closes=pd.Series(c,index=weeks).groupby(level=0).last().iloc[:-1]
    if not closes.iloc[-1]>closes.iloc[-2]:
        return {'result':'weekly_filter'}
    highs=pivots(h,True)
    r=line(h,highs,True)
    s=line(l,pivots(l,False),False)
    if r is None or s is None:
        return {'result':'no_valid_lines'}
    targets=[h[j] for j in highs if h[j]>r(k)]
    if not targets:
        return {'result':'no_overhead_target'}
    target=min(targets)
    atr=np.maximum(h[-14:]-l[-14:],np.maximum(abs(h[-14:]-c[-15:-1]),abs(l[-14:]-c[-15:-1]))).mean()
    state,i=find_entry(bars,k,r)
    if i is None:
        return {'result':state}
    if i>=len(bars) or not np.isfinite(bars[i]).all():
        return {'result':'missing_entry'}
    entry=bars[i,0]
    stop=s(i)-.25*atr
    if not stop<entry<target:
        return {'result':'invalid_open'}
    info={'entry':entry,'entry_date':dates[i],'target':target,'initial_stop':stop}
    for j in range(i,len(bars)):
        if not np.isfinite(bars[j]).all():
            break
        stop=max(stop,s(j)-.25*atr)
        price,reason=exit_fill(bars[j],stop,target)
        if price is not None:
            return dict(info,result='closed',exit_date=dates[j],exit_reason=reason,
                        net=100*(price/entry-1)-COST)
    return dict(info,result='censored_exit')

def daily_bars(frame, dates, symbol, audit):
    rows = frame[['date', *COLS]]
    repeated = rows[rows.date.duplicated(keep=False)]
    unique = rows.drop_duplicates()
    conflicts = unique.date.duplicated(keep=False)
    conflict_days = set(unique.loc[conflicts, 'date'])
    for day, count in repeated.groupby('date').size().items():
        action = 'marked_missing' if day in conflict_days else 'used_once'
        audit.append((symbol, day, count, action))
    return unique.loc[~conflicts].set_index('date')[COLS].reindex(dates).to_numpy(float)


def main():
    parser=argparse.ArgumentParser()
    src=parser.add_mutually_exclusive_group(required=True)
    src.add_argument('--cache',type=Path)
    src.add_argument('--paths',type=Path)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    picks=pd.read_csv(Path(__file__).with_name('picks.csv'),parse_dates=['signal_day'])
    if args.paths:
        prices=pd.read_csv(args.paths,usecols=['date','symbol','open','high','low','close_price']).rename(columns={'close_price':'close'})
        prices['date']=pd.to_datetime(prices.date)
        frames=dict(tuple(prices.groupby('symbol')))
    else:
        frames={}
        names={p.name:p for p in args.cache.rglob('*_daily.parquet')}
        if not names: raise ValueError('No *_daily.parquet found under cache')
        for sym in picks.symbol.unique():
            path=names.get(sym+'_daily.parquet')
            if path:
                f=pd.read_parquet(path,columns=['timestamp']+COLS)
                f['date']=pd.to_datetime(f.timestamp).dt.tz_localize(None).dt.normalize()
                frames[sym]=f
    dates=pd.DatetimeIndex(sorted(set(picks.signal_day).union(*(set(f.date) for f in frames.values()))))
    audit=[]
    output=[]
    for sym,group in picks.groupby('symbol'):
        f=frames.get(sym)
        bars=None
        if f is not None:
            bars=daily_bars(f, dates, sym, audit)
        for pick in group.itertuples():
            result={'result':'missing_history'} if bars is None else replay(bars,dates,dates.get_loc(pick.signal_day),pick.signal_close)
            output.append(dict(trade_id=pick.trade_id,engine=pick.engine,rank_band='1-3' if pick.rank<=3 else '4-10',baseline=pick.net_bp/100 if pick.status=='ok' else np.nan,**result))
    out=pd.DataFrame(output)
    args.out.mkdir(parents=True,exist_ok=False)
    pd.DataFrame(audit, columns=['symbol','date','rows','action']).to_csv(args.out/'duplicate_dates.csv',index=False)
    out.to_csv(args.out/'decisions.csv',index=False)
    out.groupby(['engine','rank_band','result']).size().rename('count').to_csv(args.out/'coverage.csv')
    unknown=['missing_history','missing_watch','missing_entry','price_mismatch','censored_exit']
    valid=out.loc[~out.result.isin(unknown)&out.baseline.notna()].copy()
    valid['setup']=valid.get('net',pd.Series(index=valid.index,dtype=float)).fillna(0)
    print(valid.groupby(['engine','rank_band']).agg(picks=('setup','size'),closed=('result',lambda x:(x=='closed').sum()),setup_pct=('setup','mean'),baseline_pct=('baseline','mean')).to_string())
if __name__=='__main__':
    main()
