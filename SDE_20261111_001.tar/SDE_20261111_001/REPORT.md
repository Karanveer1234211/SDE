# SDE universe study - SDE universe study R1 (sdelab v1.0)

Declaration sha256 `a3017eb71c798be4` (declared 2026-11-11, before any run). Universe 1,455 stocks (50 ETFs / indices out by production's research_common.is_etf_symbol; 0 without bars), 1,676,876 eligible stock-days, calendar 2015-01-01..2026-11-11. 2426 s.

## Verdict first

**1 combination(s) TRADEABLE** (survived every event test and the 3-position book beat random picks from its environment in both periods): E2 x N2 x X1.

Of 120 declared tests: 7 pass the out-of-sample test (A, 2016-2020, Bonferroni), 50 the replication (B), 30 beat their own environment (C), 65 are positive in 8+ years (D); 6 pass all four; 1 tradeable.

### The environments ranked (by their best entry's out-of-sample excess, X1)

| rank | env | name | survivors (of 20) | tradeable | best entry | its excess A bp [Bonferroni] | its excess B bp [95%] |
|---|---|---|---|---|---|---|---|
| 1 | E2 | dip in an intact uptrend | 3 | 1 | N3 | +61.1 [-18.6, +140.8] | +15.5 [-4.2, +34.2] |
| 2 | E3 | stock volatility expansion | 2 | 0 | N4 | +38.8 [-12.2, +89.8] | +39.1 [+24.2, +53.9] |
| 3 | E4 | market-wide stress | 0 | 0 | U3 | +36.8 [-21.9, +95.5] | +26.4 [+1.1, +49.1] |
| 4 | E1 | lone seller, calm market | 1 | 0 | U3 | +33.4 [-14.1, +80.9] | +30.0 [+11.8, +48.5] |
| 5 | E5 | heavy-volume selling | 0 | 0 | N5 | +28.3 [-16.6, +73.2] | -3.3 [-20.9, +15.4] |
| 6 | E0 | control: every eligible stock-day | 0 | 0 | U3 | +18.7 [-20.2, +57.6] | +21.1 [+6.9, +35.1] |

### The survivors

| env | entry | exit | A: excess bp, Bonferroni interval | B: excess bp [95%] | vs env A / B bp | years + | book CAGR A / B | random A / B | book worst DD A / B | verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| E1 | N2 | X2 | +12.1 [+0.7, +23.4] | +9.7 [+5.0, +14.7] | +11.7 / +9.1 | 10 | -3.9% / +1.4% | -17.9% / -15.0% | -54.0% / -51.9% | event survivor only |
| E2 | N1 | X2 | +31.5 [+2.7, +60.3] | +20.2 [+10.0, +30.0] | +17.9 / +12.0 | 11 | -5.0% / -3.3% | -13.4% / -12.0% | -58.3% / -65.7% | event survivor only |
| E2 | N2 | X1 | +29.1 [+7.2, +50.9] | +15.5 [+8.8, +22.4] | +14.4 / +6.4 | 11 | +4.1% / +0.2% | -13.0% / -16.2% | -52.6% / -56.4% | TRADEABLE |
| E2 | N2 | X2 | +23.5 [+2.7, +44.2] | +18.0 [+11.4, +24.4] | +11.4 / +9.6 | 11 | -3.0% / -10.3% | -13.4% / -12.0% | -57.6% / -67.2% | event survivor only |
| E3 | N2 | X1 | +24.0 [+2.7, +45.3] | +24.2 [+15.8, +32.8] | +20.6 / +16.5 | 11 | -25.1% / -6.9% | -17.4% / -13.9% | -87.1% / -55.8% | event survivor only |
| E3 | N2 | X2 | +24.8 [+3.0, +46.6] | +27.8 [+19.9, +36.1] | +17.8 / +16.6 | 11 | -10.0% / +8.5% | -18.3% / -14.3% | -69.7% / -51.6% | event survivor only |

## The theory and the five environments

SDE_N = (close(t) - close(t-N)) / sum over the N moves ending at t of |close(i) - close(i-1)|. The share of the path that was net progress: -1 = every move down (one-sided selling), +1 = every move up. It measures how one-sided the trading was, not the size of the move.

- Reversal: Price pressure: a seller who is not trading on information (fund redemptions, margin calls, a large holder exiting, an index change) pushes the price below value day after day; when the seller is done the price recovers and whoever supplied liquidity earns it (Grossman & Miller 1988; Jegadeesh 1990; Lehmann 1990; Nagel 2012).
- Continuation: Informed selling: bad news priced in gradually keeps going; orderly, continuous moves continue (Da, Gurun & Warachka 2014, 'frog in the pan').
- An environment's job: tilt the odds toward non-informational (liquidity) selling and away from informed selling, using only what is known at the signal close.

| env | name | rule | why | share of stock-days A / B | env excess X1 bp A / B |
|---|---|---|---|---|---|
| E0 | control: every eligible stock-day | eligible | - | 100.0% / 100.0% | +0.0 / +0.0 |
| E1 | lone seller, calm market | market_sde10 > -0.2 and not shock | news arrives as gaps; a fall made of small steps while the market is not falling looks like one seller working an order | 81.9% / 79.6% | +0.6 / +0.5 |
| E2 | dip in an intact uptrend | close > SMA200 and SMA50 >= 1.02 x SMA200 and SMA200 rising | the long-run information is positive; trend holders absorb the selling (the handover's S02) | 44.5% / 50.3% | +10.7 / +5.6 |
| E3 | stock volatility expansion | v3 | a bigger dislocation should pay a bigger liquidity premium (the handover's V3) | 36.8% / 33.6% | -3.4 / +0.8 |
| E4 | market-wide stress | market_v3_share >= 0.50 | when the whole market is volatile, liquidity providers withdraw and short-term reversal profits rise (Nagel 2012) | 24.6% / 22.5% | +0.0 / +0.0 |
| E5 | heavy-volume selling | volume_ratio >= 1.5 | moves on heavy volume driven by liquidity needs reverse (Campbell, Grossman & Wang 1993; Llorente et al. 2002) | 19.9% / 18.9% | -3.8 / -1.5 |

## Every test (excess = net minus the same-date mean of every eligible stock, same exit; bp)

A = 2016-2020, out of sample for the SDE research; B = 2021 on, its replication. Bonferroni interval: the mean +- 3.53 bootstrap standard deviations (120 tests).

| env | entry | exit | events A | excess A [Bonferroni] | vs env A [95%] | events B | excess B [95%] | vs env B | years + | verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| E0 | N1 | X1 | 17,383 | +1.8 [-18.6, +22.2] | +1.8 [-9.6, +13.2] | 46,801 | +8.8 [+2.7, +15.2] | +8.8 | 8 | fails A, C |
| E0 | N1 | X2 | 17,383 | +8.2 [-8.9, +25.4] | +8.2 [-1.1, +17.8] | 46,803 | +11.8 [+6.0, +17.5] | +11.8 | 10 | fails A, C |
| E0 | N2 | X1 | 35,569 | +9.3 [-1.8, +20.4] | +9.3 [+3.5, +16.0] | 94,581 | +8.9 [+4.5, +13.3] | +8.9 | 11 | fails A |
| E0 | N2 | X2 | 35,569 | +9.6 [-1.8, +21.0] | +9.6 [+3.4, +16.4] | 94,582 | +9.6 [+5.7, +13.6] | +9.6 | 11 | fails A |
| E0 | N3 | X1 | 5,922 | +17.5 [-20.6, +55.5] | +17.5 [-3.0, +38.8] | 13,776 | +17.1 [+5.7, +29.3] | +17.1 | 7 | fails A, C, D |
| E0 | N3 | X2 | 5,922 | +22.9 [-7.8, +53.5] | +22.9 [+6.5, +40.4] | 13,777 | +23.5 [+13.5, +34.0] | +23.5 | 10 | fails A |
| E0 | N4 | X1 | 7,159 | +11.4 [-20.2, +42.9] | +11.4 [-6.4, +28.7] | 18,202 | +14.3 [+4.0, +23.6] | +14.3 | 8 | fails A, C |
| E0 | N4 | X2 | 7,159 | +11.6 [-16.6, +39.8] | +11.6 [-4.2, +27.4] | 18,203 | +20.4 [+11.1, +29.6] | +20.4 | 9 | fails A, C |
| E0 | N5 | X1 | 16,508 | +5.3 [-10.2, +20.7] | +5.3 [-3.0, +13.7] | 43,512 | +2.3 [-4.1, +8.5] | +2.3 | 8 | fails A, B, C |
| E0 | N5 | X2 | 16,508 | +5.9 [-7.7, +19.6] | +5.9 [-1.6, +13.3] | 43,515 | +5.5 [-0.1, +11.4] | +5.5 | 9 | fails A, B, C |
| E0 | N6 | X1 | 13,408 | -17.7 [-36.5, +1.2] | -17.7 [-28.1, -7.4] | 37,928 | -21.5 [-29.3, -13.9] | -21.5 | 0 | fails A, B, C, D |
| E0 | N6 | X2 | 13,408 | -14.5 [-32.1, +3.1] | -14.5 [-24.7, -5.1] | 37,935 | -19.8 [-26.7, -13.0] | -19.8 | 0 | fails A, B, C, D |
| E0 | U1 | X1 | 4,084 | -6.4 [-47.9, +35.1] | -6.4 [-30.0, +15.8] | 10,566 | -7.7 [-19.6, +4.1] | -7.7 | 4 | fails A, B, C, D |
| E0 | U1 | X2 | 4,084 | +0.4 [-42.2, +42.9] | +0.4 [-24.3, +22.7] | 10,566 | -2.8 [-14.1, +8.5] | -2.8 | 5 | fails A, B, C, D |
| E0 | U2 | X1 | 7,595 | -26.9 [-59.1, +5.2] | -26.9 [-45.3, -9.5] | 21,289 | -33.6 [-44.1, -23.0] | -33.6 | 0 | fails A, B, C, D |
| E0 | U2 | X2 | 7,595 | -26.2 [-57.9, +5.5] | -26.2 [-44.2, -8.7] | 21,295 | -31.4 [-41.6, -21.2] | -31.4 | 0 | fails A, B, C, D |
| E0 | U3 | X1 | 4,730 | +18.7 [-20.2, +57.6] | +18.7 [-4.2, +38.5] | 10,833 | +21.1 [+6.9, +35.1] | +21.1 | 9 | fails A, C |
| E0 | U3 | X2 | 4,730 | +25.8 [-23.3, +74.8] | +25.8 [-1.4, +52.7] | 10,834 | +24.2 [+11.1, +37.5] | +24.2 | 10 | fails A, C |
| E0 | P1 | X1 | 19,812 | -14.2 [-31.0, +2.6] | -14.2 [-23.4, -5.0] | 50,332 | -6.8 [-14.9, +1.1] | -6.8 | 3 | fails A, B, C, D |
| E0 | P1 | X2 | 19,812 | -13.1 [-29.7, +3.6] | -13.1 [-22.4, -3.4] | 50,381 | -7.5 [-14.7, -0.6] | -7.5 | 3 | fails A, B, C, D |
| E1 | N1 | X1 | 10,370 | +1.3 [-18.8, +21.4] | +0.5 [-10.4, +12.1] | 27,487 | +8.9 [+0.5, +17.0] | +8.4 | 8 | fails A, C |
| E1 | N1 | X2 | 10,370 | +6.1 [-12.2, +24.4] | +5.4 [-4.9, +15.9] | 27,488 | +12.9 [+5.2, +20.7] | +12.4 | 10 | fails A, C |
| E1 | N2 | X1 | 26,952 | +10.5 [-1.5, +22.4] | +9.9 [+3.4, +16.7] | 70,725 | +8.5 [+3.0, +14.0] | +7.9 | 11 | fails A |
| E1 | N2 | X2 | 26,952 | +12.1 [+0.7, +23.4] | +11.7 [+5.3, +18.0] | 70,726 | +9.7 [+5.0, +14.7] | +9.1 | 10 | SURVIVOR |
| E1 | N3 | X1 | 3,075 | +29.8 [-11.4, +70.9] | +29.1 [+5.1, +51.2] | 8,122 | +10.9 [-6.9, +27.3] | +10.3 | 10 | fails A, B |
| E1 | N3 | X2 | 3,075 | +32.1 [-5.7, +69.9] | +31.6 [+9.9, +53.0] | 8,123 | +19.0 [+4.6, +33.3] | +18.4 | 10 | fails A |
| E1 | N4 | X1 | 3,529 | +11.9 [-25.8, +49.6] | +11.1 [-9.8, +32.8] | 9,093 | +13.3 [-1.5, +28.0] | +12.7 | 10 | fails A, B, C |
| E1 | N4 | X2 | 3,529 | +15.8 [-18.6, +50.3] | +15.1 [-3.4, +34.8] | 9,094 | +22.2 [+8.9, +36.3] | +21.7 | 10 | fails A, C |
| E1 | N5 | X1 | 13,767 | +8.1 [-7.7, +23.9] | +7.5 [-1.1, +16.2] | 35,213 | +1.2 [-6.5, +8.4] | +0.7 | 8 | fails A, B, C |
| E1 | N5 | X2 | 13,767 | +9.2 [-4.6, +23.1] | +8.7 [+1.4, +16.5] | 35,214 | +3.9 [-3.1, +10.6] | +3.5 | 10 | fails A, B |
| E1 | N6 | X1 | 10,178 | -15.4 [-36.4, +5.5] | -16.2 [-27.5, -4.4] | 28,967 | -19.4 [-27.7, -11.0] | -19.7 | 1 | fails A, B, C, D |
| E1 | N6 | X2 | 10,178 | -13.8 [-33.0, +5.5] | -14.7 [-25.2, -4.1] | 28,972 | -18.5 [-25.9, -10.3] | -18.9 | 1 | fails A, B, C, D |
| E1 | U1 | X1 | 1,591 | -29.1 [-80.6, +22.4] | -30.0 [-59.2, -2.1] | 4,449 | -16.0 [-32.5, +0.3] | -16.7 | 3 | fails A, B, C, D |
| E1 | U1 | X2 | 1,591 | -29.2 [-78.5, +20.1] | -30.0 [-58.6, -3.1] | 4,449 | -13.1 [-27.6, +1.1] | -13.6 | 2 | fails A, B, C, D |
| E1 | U2 | X1 | 4,851 | -39.6 [-70.7, -8.6] | -40.5 [-57.9, -23.2] | 13,446 | -33.9 [-46.7, -20.4] | -34.5 | 1 | fails A, B, C, D |
| E1 | U2 | X2 | 4,851 | -39.5 [-67.2, -11.8] | -40.4 [-55.8, -25.6] | 13,453 | -32.7 [-45.0, -19.9] | -33.2 | 0 | fails A, B, C, D |
| E1 | U3 | X1 | 2,218 | +33.4 [-14.1, +80.9] | +32.7 [+5.9, +59.2] | 5,329 | +30.0 [+11.8, +48.5] | +29.4 | 10 | fails A |
| E1 | U3 | X2 | 2,218 | +29.7 [-12.9, +72.2] | +29.0 [+5.9, +53.3] | 5,330 | +30.0 [+13.6, +46.5] | +29.5 | 10 | fails A |
| E1 | P1 | X1 | 19,427 | -13.8 [-31.1, +3.4] | -14.4 [-23.7, -5.1] | 49,234 | -5.6 [-13.6, +2.3] | -6.0 | 3 | fails A, B, C, D |
| E1 | P1 | X2 | 19,427 | -12.5 [-29.0, +4.0] | -13.0 [-21.8, -4.1] | 49,276 | -5.8 [-12.8, +1.3] | -6.2 | 3 | fails A, B, C, D |
| E2 | N1 | X1 | 5,958 | +26.4 [-6.6, +59.4] | +8.1 [-6.6, +22.7] | 18,244 | +15.1 [+5.2, +25.7] | +5.9 | 11 | fails A, C |
| E2 | N1 | X2 | 5,958 | +31.5 [+2.7, +60.3] | +17.9 [+4.1, +32.4] | 18,244 | +20.2 [+10.0, +30.0] | +12.0 | 11 | SURVIVOR |
| E2 | N2 | X1 | 14,730 | +29.1 [+7.2, +50.9] | +14.4 [+7.1, +22.2] | 43,646 | +15.5 [+8.8, +22.4] | +6.4 | 11 | SURVIVOR / TRADEABLE |
| E2 | N2 | X2 | 14,730 | +23.5 [+2.7, +44.2] | +11.4 [+3.8, +19.0] | 43,646 | +18.0 [+11.4, +24.4] | +9.6 | 11 | SURVIVOR |
| E2 | N3 | X1 | 890 | +61.1 [-18.6, +140.8] | +46.4 [+7.0, +84.2] | 2,785 | +15.5 [-4.2, +34.2] | +3.8 | 10 | fails A, B |
| E2 | N3 | X2 | 890 | +61.7 [-10.3, +133.7] | +50.9 [+14.1, +87.2] | 2,785 | +30.2 [+11.7, +48.5] | +19.4 | 11 | fails A |
| E2 | N4 | X1 | 2,048 | +42.5 [-15.4, +100.4] | +25.8 [-2.4, +53.5] | 5,975 | +23.6 [+8.7, +38.5] | +12.7 | 11 | fails A, C |
| E2 | N4 | X2 | 2,048 | +40.8 [-10.4, +92.0] | +28.9 [+3.8, +53.3] | 5,975 | +34.4 [+18.3, +49.6] | +24.9 | 10 | fails A |
| E2 | N5 | X1 | 6,238 | +18.8 [-7.6, +45.2] | +11.6 [-0.7, +23.6] | 18,859 | -0.3 [-10.3, +9.4] | -5.5 | 7 | fails A, B, C, D |
| E2 | N5 | X2 | 6,238 | +21.6 [+0.1, +43.2] | +15.5 [+5.4, +25.6] | 18,860 | +4.7 [-4.5, +13.1] | -0.5 | 9 | fails B, C |
| E2 | N6 | X1 | 5,005 | -8.9 [-40.8, +22.9] | -25.3 [-40.1, -10.6] | 16,045 | -30.3 [-41.6, -18.6] | -34.3 | 2 | fails A, B, C, D |
| E2 | N6 | X2 | 5,005 | -7.1 [-36.5, +22.4] | -19.1 [-32.9, -6.1] | 16,046 | -29.7 [-40.7, -18.5] | -34.0 | 2 | fails A, B, C, D |
| E2 | U1 | X1 | 1,201 | +6.5 [-75.3, +88.4] | -19.7 [-60.8, +14.4] | 3,614 | -21.2 [-41.9, -1.4] | -28.8 | 6 | fails A, B, C, D |
| E2 | U1 | X2 | 1,201 | +11.3 [-66.6, +89.1] | -5.6 [-44.6, +28.1] | 3,614 | -12.6 [-32.9, +8.6] | -18.5 | 5 | fails A, B, C, D |
| E2 | U2 | X1 | 2,680 | -33.7 [-85.1, +17.6] | -50.9 [-75.9, -28.5] | 8,564 | -49.8 [-66.1, -34.4] | -53.5 | 1 | fails A, B, C, D |
| E2 | U2 | X2 | 2,680 | -37.9 [-83.7, +8.0] | -51.2 [-72.8, -32.1] | 8,565 | -50.7 [-66.2, -35.5] | -54.1 | 1 | fails A, B, C, D |
| E2 | U3 | X1 | 1,222 | +41.1 [-16.2, +98.4] | +17.8 [-15.1, +50.0] | 2,911 | +36.7 [+12.7, +58.3] | +25.4 | 11 | fails A, C |
| E2 | U3 | X2 | 1,222 | +37.8 [-18.8, +94.4] | +19.6 [-11.7, +53.1] | 2,911 | +41.9 [+17.2, +63.8] | +32.0 | 11 | fails A, C |
| E2 | P1 | X1 | 9,933 | +2.3 [-26.6, +31.2] | -2.9 [-13.4, +7.6] | 29,422 | +0.4 [-10.5, +11.8] | -2.9 | 6 | fails A, B, C, D |
| E2 | P1 | X2 | 9,933 | +1.6 [-24.9, +28.1] | -3.3 [-13.1, +7.4] | 29,432 | -1.6 [-11.5, +8.5] | -5.1 | 5 | fails A, B, C, D |
| E3 | N1 | X1 | 8,748 | +17.3 [-14.6, +49.1] | +13.9 [-2.4, +30.1] | 18,843 | +24.2 [+13.9, +34.5] | +17.2 | 10 | fails A, C |
| E3 | N1 | X2 | 8,748 | +22.8 [-6.5, +52.1] | +17.1 [+3.2, +31.5] | 18,844 | +29.5 [+19.2, +39.9] | +18.9 | 10 | fails A |
| E3 | N2 | X1 | 16,659 | +24.0 [+2.7, +45.3] | +20.6 [+11.7, +30.1] | 38,019 | +24.2 [+15.8, +32.8] | +16.5 | 11 | SURVIVOR |
| E3 | N2 | X2 | 16,659 | +24.8 [+3.0, +46.6] | +17.8 [+9.2, +28.0] | 38,019 | +27.8 [+19.9, +36.1] | +16.6 | 11 | SURVIVOR |
| E3 | N3 | X1 | 3,646 | +30.2 [-31.7, +92.1] | +26.3 [-6.1, +59.3] | 5,374 | +33.5 [+11.6, +55.2] | +25.0 | 8 | fails A, C |
| E3 | N3 | X2 | 3,646 | +38.5 [-5.6, +82.5] | +33.2 [+11.3, +56.3] | 5,375 | +39.6 [+19.6, +58.8] | +29.3 | 9 | fails A |
| E3 | N4 | X1 | 3,868 | +38.8 [-12.2, +89.8] | +35.1 [+10.0, +61.6] | 7,356 | +39.1 [+24.2, +53.9] | +31.1 | 10 | fails A |
| E3 | N4 | X2 | 3,868 | +40.0 [-6.9, +87.0] | +34.0 [+12.6, +58.6] | 7,356 | +47.3 [+33.0, +62.2] | +35.9 | 11 | fails A |
| E3 | N5 | X1 | 6,972 | +21.8 [-5.8, +49.4] | +25.9 [+11.3, +39.4] | 16,555 | +11.3 [+1.3, +21.7] | +10.0 | 9 | fails A |
| E3 | N5 | X2 | 6,972 | +23.3 [-2.3, +49.0] | +24.0 [+10.7, +36.4] | 16,557 | +18.4 [+8.8, +28.8] | +13.6 | 11 | fails A |
| E3 | N6 | X1 | 6,104 | -15.4 [-41.9, +11.1] | -14.2 [-28.4, -0.1] | 13,886 | -21.9 [-36.0, -6.8] | -21.7 | 1 | fails A, B, C, D |
| E3 | N6 | X2 | 6,104 | -9.5 [-35.2, +16.3] | -9.2 [-23.4, +4.3] | 13,892 | -15.9 [-29.2, -3.5] | -18.7 | 3 | fails A, B, C, D |
| E3 | U1 | X1 | 2,434 | +10.0 [-46.3, +66.4] | +8.3 [-22.2, +35.3] | 4,450 | -7.3 [-25.3, +11.4] | -8.5 | 6 | fails A, B, C, D |
| E3 | U1 | X2 | 2,434 | +16.3 [-41.7, +74.3] | +14.0 [-16.5, +41.9] | 4,450 | -0.6 [-18.9, +18.2] | -4.4 | 7 | fails A, B, C, D |
| E3 | U2 | X1 | 3,541 | -13.1 [-68.5, +42.4] | -11.3 [-41.7, +15.9] | 7,701 | -37.9 [-54.5, -21.5] | -37.2 | 2 | fails A, B, C, D |
| E3 | U2 | X2 | 3,541 | -7.0 [-62.3, +48.2] | -6.0 [-35.9, +21.0] | 7,704 | -29.4 [-45.7, -12.7] | -32.3 | 3 | fails A, B, C, D |
| E3 | U3 | X1 | 3,070 | +32.3 [-22.5, +87.1] | +29.5 [-3.7, +59.3] | 5,715 | +33.8 [+12.8, +53.5] | +24.5 | 10 | fails A, C |
| E3 | U3 | X2 | 3,070 | +45.7 [-22.9, +114.2] | +40.0 [-0.8, +77.2] | 5,715 | +37.1 [+16.1, +57.3] | +24.3 | 10 | fails A, C |
| E3 | P1 | X1 | 6,529 | -42.8 [-74.4, -11.3] | -28.7 [-45.0, -12.9] | 17,126 | -11.1 [-27.2, +3.6] | -8.2 | 3 | fails A, B, C, D |
| E3 | P1 | X2 | 6,529 | -34.9 [-65.5, -4.2] | -25.9 [-42.1, -9.3] | 17,149 | -10.0 [-23.7, +3.4] | -10.7 | 2 | fails A, B, C, D |
| E4 | N1 | X1 | 6,796 | +6.9 [-34.9, +48.6] | +6.9 [-16.1, +29.3] | 15,692 | +16.7 [+4.3, +28.9] | +16.7 | 8 | fails A, C |
| E4 | N1 | X2 | 6,796 | +13.0 [-21.7, +47.8] | +13.0 [-6.2, +32.0] | 15,694 | +19.7 [+8.3, +31.1] | +19.7 | 9 | fails A, C |
| E4 | N2 | X1 | 11,224 | +14.1 [-9.7, +37.8] | +14.1 [+1.4, +27.8] | 27,727 | +17.7 [+7.4, +28.8] | +17.7 | 9 | fails A |
| E4 | N2 | X2 | 11,224 | +13.4 [-10.8, +37.7] | +13.4 [+1.1, +27.9] | 27,728 | +17.3 [+8.2, +26.8] | +17.3 | 10 | fails A |
| E4 | N3 | X1 | 3,296 | +25.4 [-37.7, +88.5] | +25.4 [-7.4, +61.3] | 5,670 | +17.3 [-0.3, +35.5] | +17.3 | 7 | fails A, B, C, D |
| E4 | N3 | X2 | 3,296 | +25.6 [-24.1, +75.4] | +25.6 [-0.8, +54.2] | 5,672 | +29.1 [+12.2, +45.6] | +29.1 | 9 | fails A, C |
| E4 | N4 | X1 | 3,064 | +24.7 [-33.6, +83.0] | +24.7 [-8.4, +56.1] | 6,101 | +28.3 [+12.8, +43.9] | +28.3 | 8 | fails A, C |
| E4 | N4 | X2 | 3,064 | +19.6 [-31.1, +70.2] | +19.6 [-7.4, +46.6] | 6,102 | +32.5 [+18.6, +46.0] | +32.5 | 9 | fails A, C |
| E4 | N5 | X1 | 4,374 | +18.2 [-18.7, +55.0] | +18.2 [-2.4, +38.0] | 11,119 | +7.7 [-5.4, +19.8] | +7.7 | 9 | fails A, B, C |
| E4 | N5 | X2 | 4,374 | +16.6 [-16.7, +49.9] | +16.6 [-1.9, +34.6] | 11,122 | +11.7 [-0.6, +23.2] | +11.7 | 9 | fails A, B, C |
| E4 | N6 | X1 | 5,087 | -10.4 [-41.9, +21.2] | -10.4 [-27.4, +7.8] | 11,977 | -23.5 [-37.5, -8.2] | -23.5 | 3 | fails A, B, C, D |
| E4 | N6 | X2 | 5,087 | -0.7 [-29.8, +28.4] | -0.7 [-16.4, +14.7] | 11,984 | -19.2 [-31.6, -7.0] | -19.2 | 4 | fails A, B, C, D |
| E4 | U1 | X1 | 2,051 | +13.6 [-46.7, +74.0] | +13.6 [-21.6, +44.5] | 3,814 | -6.4 [-25.5, +14.4] | -6.4 | 4 | fails A, B, C, D |
| E4 | U1 | X2 | 2,051 | +19.8 [-42.9, +82.6] | +19.8 [-18.0, +52.3] | 3,814 | +3.5 [-16.3, +23.7] | +3.5 | 5 | fails A, B, C, D |
| E4 | U2 | X1 | 2,916 | +1.0 [-61.5, +63.5] | +1.0 [-34.7, +34.8] | 6,677 | -31.3 [-48.8, -13.8] | -31.3 | 2 | fails A, B, C, D |
| E4 | U2 | X2 | 2,916 | +6.4 [-51.5, +64.3] | +6.4 [-26.9, +37.2] | 6,683 | -27.2 [-44.1, -9.9] | -27.2 | 3 | fails A, B, C, D |
| E4 | U3 | X1 | 2,173 | +36.8 [-21.9, +95.5] | +36.8 [+1.7, +68.1] | 3,932 | +26.4 [+1.1, +49.1] | +26.4 | 8 | fails A |
| E4 | U3 | X2 | 2,173 | +45.9 [-39.6, +131.5] | +45.9 [-3.1, +89.0] | 3,933 | +31.0 [+4.5, +56.8] | +31.0 | 8 | fails A, C |
| E4 | P1 | X1 | 3,355 | -16.1 [-78.6, +46.4] | -16.1 [-49.6, +19.9] | 8,861 | -28.2 [-57.0, -6.4] | -28.2 | 3 | fails A, B, C, D |
| E4 | P1 | X2 | 3,355 | -19.1 [-80.0, +41.9] | -19.1 [-52.5, +16.4] | 8,910 | -25.4 [-48.5, -7.1] | -25.4 | 3 | fails A, B, C, D |
| E5 | N1 | X1 | 2,802 | +17.6 [-26.3, +61.6] | +7.4 [-23.1, +34.2] | 5,159 | +3.3 [-16.0, +22.2] | +5.1 | 7 | fails A, B, C, D |
| E5 | N1 | X2 | 2,802 | +23.3 [-27.7, +74.3] | +13.3 [-9.5, +35.4] | 5,159 | +6.1 [-11.0, +23.8] | +6.1 | 8 | fails A, B, C |
| E5 | N2 | X1 | 7,073 | +23.0 [-5.3, +51.3] | +20.6 [+5.1, +37.4] | 16,424 | +18.1 [+6.2, +30.0] | +16.1 | 10 | fails A |
| E5 | N2 | X2 | 7,073 | +24.3 [-3.8, +52.3] | +21.3 [+6.3, +36.8] | 16,424 | +22.3 [+11.5, +33.8] | +19.2 | 11 | fails A |
| E5 | N3 | X1 | 1,361 | +22.8 [-53.7, +99.4] | +14.0 [-36.2, +71.8] | 2,098 | +26.3 [-6.2, +57.4] | +26.4 | 8 | fails A, B, C |
| E5 | N3 | X2 | 1,361 | +45.5 [-34.4, +125.5] | +36.4 [+0.2, +71.1] | 2,098 | +23.3 [-7.0, +52.2] | +23.6 | 8 | fails A, B |
| E5 | N4 | X1 | 1,278 | +17.0 [-44.2, +78.2] | +1.7 [-41.3, +42.7] | 2,171 | +16.2 [-18.2, +48.4] | +17.8 | 7 | fails A, B, C, D |
| E5 | N4 | X2 | 1,278 | +28.5 [-31.4, +88.4] | +13.8 [-21.9, +49.3] | 2,171 | +21.0 [-10.7, +50.3] | +21.1 | 8 | fails A, B, C |
| E5 | N5 | X1 | 2,666 | +28.3 [-16.6, +73.2] | +29.2 [+5.5, +54.0] | 5,515 | -3.3 [-20.9, +15.4] | -3.3 | 7 | fails A, B, C, D |
| E5 | N5 | X2 | 2,666 | +22.9 [-19.8, +65.5] | +24.8 [+2.4, +48.7] | 5,516 | -2.2 [-18.4, +15.5] | -3.7 | 7 | fails A, B, C, D |
| E5 | N6 | X1 | 2,218 | -19.9 [-76.8, +37.0] | -11.4 [-35.3, +12.4] | 4,760 | -21.1 [-42.3, -1.3] | -18.3 | 2 | fails A, B, C, D |
| E5 | N6 | X2 | 2,218 | -15.5 [-68.1, +37.0] | -5.8 [-29.8, +18.5] | 4,766 | -16.7 [-34.2, +0.1] | -16.7 | 3 | fails A, B, C, D |
| E5 | U1 | X1 | 809 | -17.9 [-90.3, +54.6] | -23.3 [-68.7, +22.0] | 1,352 | -3.9 [-39.0, +30.6] | -2.3 | 4 | fails A, B, C, D |
| E5 | U1 | X2 | 809 | -12.8 [-97.0, +71.4] | -14.9 [-60.2, +24.1] | 1,352 | +1.1 [-33.1, +34.8] | +1.4 | 5 | fails A, B, C, D |
| E5 | U2 | X1 | 1,183 | +3.5 [-55.2, +62.1] | +15.2 [-15.3, +47.3] | 2,488 | -38.8 [-65.8, -12.3] | -37.6 | 4 | fails A, B, C, D |
| E5 | U2 | X2 | 1,183 | -3.8 [-62.6, +55.0] | +9.9 [-23.1, +42.4] | 2,491 | -26.4 [-50.6, -2.3] | -28.0 | 4 | fails A, B, C, D |
| E5 | U3 | X1 | 1,752 | +21.3 [-34.4, +76.9] | +8.3 [-27.9, +44.8] | 2,983 | +23.6 [-6.3, +50.9] | +25.5 | 8 | fails A, B, C |
| E5 | U3 | X2 | 1,752 | +29.6 [-34.6, +93.7] | +16.8 [-13.2, +44.8] | 2,983 | +22.0 [-2.7, +47.0] | +23.3 | 10 | fails A, B, C |
| E5 | P1 | X1 | 7,724 | -23.2 [-56.2, +9.9] | -14.9 [-30.3, -0.4] | 20,459 | -10.1 [-22.2, +1.7] | -8.5 | 3 | fails A, B, C, D |
| E5 | P1 | X2 | 7,724 | -21.7 [-53.8, +10.5] | -14.1 [-28.9, +1.2] | 20,469 | -11.1 [-23.1, +0.2] | -10.0 | 2 | fails A, B, C, D |

## How to read it

- Entries: N1 SDE10 < -0.5; N2 SDE5 < -0.5; N3 SDE20 < -0.5; N4 SDE10 < -0.7; N5 SDE10 in the bottom 10% of eligible stocks that day; N6 turn: SDE10 < -0.5 on one of the 3 sessions before t, and SDE3(t) >= 0; U1 reversal bar: SDE10 < -0.5, close > open, close in the top 30% of the day's range; U2 thrust: SDE10(t-1) < -0.5 and close(t) > high(t-1); U3 climax: SDE10 < -0.5 and volume(t) >= 2 x the median volume of the 50 sessions before t; P1 orderly rise: SDE10 > +0.5 (the opposite theory's check).
- Exits: X1 the 5th close; X2 2 ATR target / 3 ATR stop, else the 5th close. a close locked at the lower circuit (production's stage E rule) sells at the first open within 20 sessions that is not locked; none = sold at the 20th session's close ('stuck'); data ending first = 'pending' (left out); a frozen bar sells nothing.
- One event per stock until 5 sessions have passed; 35 bp a round trip; signal at the close, buy at the next open.
- Decision: all of: (A) excess Bonferroni lower bound > 0 in period A; (B) excess 95% lower bound > 0 in period B; (C) incremental 95% lower bound > 0 in A and incremental mean > 0 in B; (D) mean excess > 0 in at least 8 of the 11 calendar years 2016-2026 (a year with fewer than 30 events does not count as positive); and at least 300 events on 100 days in each period. Tradeable: a survivor whose 3-position book, in both periods, has CAGR > 0, CAGR above the mean CAGR of the same environment's random books, and a worst drawdown no deeper than their mean worst drawdown.
- Book: each entry gets 1/3 of the book's closed value (never more than the cash); SDE10 ascending (most one-sided fall first), then 20-day turnover descending, then symbol; P1 ranks SDE10 descending; baseline: the same environment's eligible stock-days picked in random order, seeds 1-10, same rules; mean CAGR and mean worst drawdown.
- Known bias: the cache holds the stocks it holds today: stocks delisted after a fall are probably missing, which flatters every buy-the-fall rule, most in period A.
- Files: results.csv (every test x period), years.csv, books.csv, environments.csv, survivor_events.parquet (the survivors' events), run.json, DECLARATION.json.
