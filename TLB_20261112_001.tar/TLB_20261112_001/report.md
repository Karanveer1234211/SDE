# tradelab backtest - voldir_B1

tl_backtest v1.3.1 (tradelab v1.3.1), 2026-11-12T09:48:52. pick_meta run PM_20261017_001. Strategy strategies\voldir.py (sha 3396a5eb35f61dcd, mode daily), compared with tree.
Tag: -. Declared rule: voldir VD1 Stage 2 B1 D.

## Verdict first

- Per pick slot: strategy **+143.7 [+95.2, +196.0] bp**, tree +143.7 [+95.2, +196.0] bp, difference **+0.0 [+0.0, +0.0] bp -> NOT SHOWN (interval spans 0)** (1,903 picks, 1,267 signal days).
- On the picks the strategy actually traded (1,903): difference +0.0 [+0.0, +0.0] bp.
- Picks the plan finished but the strategy could not trade (0, {}): the plan made n/a bp on them vs +143.7 [+95.2, +196.0] bp on the paired picks - a large gap means the pairing is not a fair sample.
- Entered 100.0% of picks; average size used 1.00 of the target; net on the money actually used +143.7 bp.

## Money view (one account, the strategy's sizing)

| | strategy | tree |
|---|---|---|
| CAGR | +76.82% | +97.40% |
| worst drawdown | -26.56% (2023-01-20 -> 2023-02-24) | -29.04% (2025-11-03 -> 2026-04-07) |
| Sharpe (daily x sqrt 252) | 1.94 | 2.03 |
| average exposure | 0.61 | 0.70 |
| trades opened | 804 | 829 |
| skipped (reason) | {'max_open': 991, 'cash': 108} | {'max_open': 1074} |
| legs trimmed / skipped by cash | 249 / 108 | 253 / 0 |

Daily return difference: -5.15 [-9.82, -0.61] bp a day -> WORSE (interval below 0) (one-sided p 0.9865).
Calmar ratio (CAGR over 252 sessions a year / |worst drawdown|, from the daily returns): strategy 2.951, tree 3.426, difference -0.474 [-1.940, +0.992] (paired block bootstrap; one-sided p 0.7285).

## Detail

- Win rate: strategy 54.4%, tree 54.4%.
- Legs filled (share of entered picks): {'tree': 1.0}.
- Exit reasons: {'tree': 1903}.
- Median MFE +5.00%, median MAE -3.12% (from the first buy, while held).
- Average exit session 5.25; locked exits 79; bars where a stop and a target were both inside the bar (settled by the 'worst' policy): 0.
- Left out of the pairing: strategy {'not_entered': 2339}, tree {'not_entered': 2339}.

### By year (bp per pick)

| year | picks | strategy | tree | difference |
|---|---|---|---|---|
| 2021 | 347 | +169.7 | +169.7 | +0.0 |
| 2022 | 344 | +208.4 | +208.4 | +0.0 |
| 2023 | 350 | +43.1 | +43.1 | +0.0 |
| 2024 | 314 | +210.6 | +210.6 | +0.0 |
| 2025 | 339 | +127.2 | +127.2 | +0.0 |
| 2026 | 209 | +88.3 | +88.3 | +0.0 |

### By engine and rank (bp per pick)

| engine | rank | picks | strategy | tree | difference |
|---|---|---|---|---|---|
| D | 1 | 838 | +135.4 | +135.4 | +0.0 |
| D | 2 | 578 | +163.6 | +163.6 | +0.0 |
| D | 3 | 487 | +134.3 | +134.3 | +0.0 |

## How much to trust this

- The tradelab ledger held 4 earlier backtests (2 distinct strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at the 95% level by luck alone.
- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.
- Costs: flat 35 bp round trip on entry notional (half at buy, half at sale); slippage 0.0 bp a side. Fills: next-bar opens, stop / limit levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.
- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model.

## Decision rule: {'rule': {'metric': 'calmar_diff', 'pass_if': 'lower > 0', 'money': 'drawdown'}, 'value': -1.9403205487407362, 'p_one_sided': 0.7285, 'metric_value': [-0.4742341268213144, -1.9403205487407362, 0.9921342174674345], 'cagr': [0.7681643672900835, 0.9740279013233106], 'max_drawdown': [-0.2655721232584868, -0.29042356517166334], 'money_ok': True, 'verdict': 'FAIL'}

## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)

### The money by environment (known at the previous close)

Each account's daily returns grouped by the environment known before the day began: mean day return (bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), average exposure and the most positions open at once.

| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |
|---|---|---|---|---|---|---|---|---|
| voldir_B1 | broad_bullish | 426 (30%) | +35.46 [+14.71, +58.22] | +310.07% | -19.56% | -885 | 0.68 | 3 |
| voldir_B1 | narrow_bullish | 383 (27%) | +8.05 [-11.27, +26.25] | +27.64% | -36.00% | -585 | 0.62 | 3 |
| voldir_B1 | mixed | 194 (14%) | +40.12 [+11.91, +71.50] | +109.27% | -17.50% | -564 | 0.60 | 3 |
| voldir_B1 | broad_bearish | 224 (16%) | +17.04 [-15.97, +47.56] | +38.37% | -25.16% | -775 | 0.57 | 3 |
| voldir_B1 | high_stress | 191 (13%) | +30.06 [+6.28, +54.93] | +71.29% | -13.62% | -506 | 0.48 | 3 |
| tree | broad_bullish | 426 (30%) | +34.11 [+13.59, +57.16] | +288.44% | -18.14% | -797 | 0.73 | 3 |
| tree | narrow_bullish | 383 (27%) | +12.49 [-9.60, +32.97] | +47.00% | -41.21% | -734 | 0.71 | 3 |
| tree | mixed | 194 (14%) | +54.66 [+22.03, +90.17] | +172.40% | -16.47% | -551 | 0.67 | 3 |
| tree | broad_bearish | 224 (16%) | +27.03 [-10.20, +61.24] | +68.61% | -23.92% | -788 | 0.68 | 3 |
| tree | high_stress | 191 (13%) | +35.91 [-0.51, +68.94] | +85.74% | -22.51% | -675 | 0.68 | 3 |

### The paired picks by the market and by the stock's state at the pick

'difference' = strategy - tree on the same picks, bp, 95% block-bootstrap intervals over signal days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a finding. Nothing here filters trades.

#### engine D

**environment at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 518 | 27% | +60.8 [-8.9, +131.9] | +60.8 [-8.9, +131.9] | +0.0 [+0.0, +0.0] | 50% | 13.3% |
| narrow_bullish | 509 | 27% | +110.3 [+36.2, +184.4] | +110.3 [+36.2, +184.4] | +0.0 [+0.0, +0.0] | 54% | 15.7% |
| mixed | 247 | 13% | +166.6 [+13.7, +324.4] | +166.6 [+13.7, +324.4] | +0.0 [+0.0, +0.0] | 52% | 14.2% |
| broad_bearish | 366 | 19% | +188.3 [+57.0, +333.7] | +188.3 [+57.0, +333.7] | +0.0 [+0.0, +0.0] | 58% | 18.9% |
| high_stress | 263 | 14% | +287.9 [+138.1, +451.2] | +287.9 [+138.1, +451.2] | +0.0 [+0.0, +0.0] | 62% | 15.6% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 1,640 | 86% | +120.5 [+73.5, +169.6] | +120.5 [+73.5, +169.6] | +0.0 [+0.0, +0.0] | 53% | 15.4% |
| yes | 263 | 14% | +287.9 [+138.1, +451.2] | +287.9 [+138.1, +451.2] | +0.0 [+0.0, +0.0] | 62% | 15.6% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 557 | 29% | +60.7 [-7.7, +133.5] | +60.7 [-7.7, +133.5] | +0.0 [+0.0, +0.0] | 50% | 13.8% |
| narrow_bullish | 575 | 30% | +142.3 [+59.2, +225.9] | +142.3 [+59.2, +225.9] | +0.0 [+0.0, +0.0] | 56% | 15.7% |
| mixed | 277 | 15% | +187.4 [+48.0, +318.7] | +187.4 [+48.0, +318.7] | +0.0 [+0.0, +0.0] | 53% | 14.1% |
| broad_bearish | 494 | 26% | +214.3 [+77.2, +346.6] | +214.3 [+77.2, +346.6] | +0.0 [+0.0, +0.0] | 59% | 17.8% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < 0.40 | 230 | 12% | +347.9 [+196.4, +506.5] | +347.9 [+196.4, +506.5] | +0.0 [+0.0, +0.0] | 67% | 15.2% |
| 0.40 - 0.50 | 967 | 51% | +130.7 [+54.4, +207.3] | +130.7 [+54.4, +207.3] | +0.0 [+0.0, +0.0] | 54% | 17.0% |
| 0.50 - 0.60 | 661 | 35% | +90.3 [+20.0, +166.1] | +90.3 [+20.0, +166.1] | +0.0 [+0.0, +0.0] | 50% | 13.0% |
| >= 0.60 | 45 | 2% | +163.3 [-134.4, +425.6] | +163.3 [-134.4, +425.6] | +0.0 [+0.0, +0.0] | 64% | 20.0% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -10% | 204 | 11% | +187.1 [+56.3, +333.3] | +187.1 [+56.3, +333.3] | +0.0 [+0.0, +0.0] | 56% | 14.7% |
| -10% .. 0% | 757 | 40% | +72.7 [+10.4, +133.3] | +72.7 [+10.4, +133.3] | +0.0 [+0.0, +0.0] | 52% | 16.0% |
| 0% .. +10% | 624 | 33% | +170.3 [+93.8, +257.6] | +170.3 [+93.8, +257.6] | +0.0 [+0.0, +0.0] | 54% | 15.5% |
| +10% .. +25% | 273 | 14% | +231.7 [+130.7, +345.6] | +231.7 [+130.7, +345.6] | +0.0 [+0.0, +0.0] | 59% | 14.3% |
| >= +25% | 45 | 2% | +236.6 [-54.1, +462.2] | +236.6 [-54.1, +462.2] | +0.0 [+0.0, +0.0] | 58% | 15.6% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 506 | 27% | +63.2 [-14.9, +137.0] | +63.2 [-14.9, +137.0] | +0.0 [+0.0, +0.0] | 49% | 15.8% |
| -3 .. 0 pts | 660 | 35% | +161.4 [+80.3, +245.2] | +161.4 [+80.3, +245.2] | +0.0 [+0.0, +0.0] | 55% | 12.9% |
| 0 .. +3 pts | 462 | 24% | +161.7 [+66.1, +266.5] | +161.7 [+66.1, +266.5] | +0.0 [+0.0, +0.0] | 57% | 16.5% |
| >= +3 pts (NIFTY ahead: narrow) | 275 | 14% | +218.8 [+88.4, +349.9] | +218.8 [+88.4, +349.9] | +0.0 [+0.0, +0.0] | 58% | 19.3% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no list | 1,903 | 100% | +143.7 [+95.2, +196.0] | +143.7 [+95.2, +196.0] | +0.0 [+0.0, +0.0] | 54% | 15.4% |

**home index** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NIFTY 50 | 129 | 7% | +93.0 [-108.7, +268.0] | +93.0 [-108.7, +268.0] | +0.0 [+0.0, +0.0] | 56% | 14.0% |
| Midcap 150 | 412 | 22% | +103.8 [+13.3, +200.5] | +103.8 [+13.3, +200.5] | +0.0 [+0.0, +0.0] | 54% | 15.5% |
| Smallcap 250 | 1,362 | 72% | +160.5 [+102.6, +221.3] | +160.5 [+102.6, +221.3] | +0.0 [+0.0, +0.0] | 54% | 15.6% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 249 | 13% | +61.2 [-17.4, +145.9] | +61.2 [-17.4, +145.9] | +0.0 [+0.0, +0.0] | 53% | 17.7% |
| S02 | 128 | 7% | +191.5 [+15.0, +395.4] | +191.5 [+15.0, +395.4] | +0.0 [+0.0, +0.0] | 52% | 12.5% |
| S03 | 185 | 10% | +50.0 [-23.4, +132.0] | +50.0 [-23.4, +132.0] | +0.0 [+0.0, +0.0] | 43% | 11.9% |
| S06 | 56 | 3% | +181.2 [-9.5, +354.1] | +181.2 [-9.5, +354.1] | +0.0 [+0.0, +0.0] | 50% | 17.9% |
| S07 | 82 | 4% | +54.3 [-18.1, +129.3] | +54.3 [-18.1, +129.3] | +0.0 [+0.0, +0.0] | 46% | 11.0% |
| S08 | 226 | 12% | +251.9 [+134.5, +373.7] | +251.9 [+134.5, +373.7] | +0.0 [+0.0, +0.0] | 64% | 12.8% |
| S09 | 510 | 27% | +213.8 [+111.4, +319.5] | +213.8 [+111.4, +319.5] | +0.0 [+0.0, +0.0] | 58% | 16.9% |
| UNKNOWN | 467 | 25% | +93.9 [-7.8, +199.0] | +93.9 [-7.8, +199.0] | +0.0 [+0.0, +0.0] | 53% | 16.7% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 477 | 25% | +128.1 [+48.8, +206.4] | +128.1 [+48.8, +206.4] | +0.0 [+0.0, +0.0] | 52% | 14.3% |
| MATURE | 731 | 38% | +210.5 [+140.3, +284.3] | +210.5 [+140.3, +284.3] | +0.0 [+0.0, +0.0] | 59% | 14.5% |
| DETERIORATING | 228 | 12% | +63.9 [-23.9, +162.7] | +63.9 [-23.9, +162.7] | +0.0 [+0.0, +0.0] | 47% | 18.4% |
| (blank) | 467 | 25% | +93.9 [-7.8, +199.0] | +93.9 [-7.8, +199.0] | +0.0 [+0.0, +0.0] | 53% | 16.7% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| HIGH | 706 | 37% | +192.4 [+121.0, +263.8] | +192.4 [+121.0, +263.8] | +0.0 [+0.0, +0.0] | 58% | 15.7% |
| MEDIUM | 502 | 26% | +157.6 [+87.6, +241.1] | +157.6 [+87.6, +241.1] | +0.0 [+0.0, +0.0] | 53% | 12.5% |
| LOW | 228 | 12% | +63.9 [-23.9, +162.7] | +63.9 [-23.9, +162.7] | +0.0 [+0.0, +0.0] | 47% | 18.4% |
| UNKNOWN | 467 | 25% | +93.9 [-7.8, +199.0] | +93.9 [-7.8, +199.0] | +0.0 [+0.0, +0.0] | 53% | 16.7% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 183 | 10% | +241.6 [+81.5, +415.8] | +241.6 [+81.5, +415.8] | +0.0 [+0.0, +0.0] | 55% | 15.8% |
| BREAKOUT:CONFIRMED | 215 | 11% | +148.2 [+15.7, +275.6] | +148.2 [+15.7, +275.6] | +0.0 [+0.0, +0.0] | 59% | 14.4% |
| BREAKOUT:STALLED | 16 | 1% | -18.8 | -18.8 | +0.0 | 38% | 12.5% |
| FAILED_BREAKOUT:FAILED | 160 | 8% | +116.7 [+9.5, +228.1] | +116.7 [+9.5, +228.1] | +0.0 [+0.0, +0.0] | 52% | 10.0% |
| BREAKDOWN:NEW | 593 | 31% | +221.9 [+123.0, +328.8] | +221.9 [+123.0, +328.8] | +0.0 [+0.0, +0.0] | 60% | 16.4% |
| BREAKDOWN:CONFIRMED | 267 | 14% | +125.6 [-71.4, +307.9] | +125.6 [-71.4, +307.9] | +0.0 [+0.0, +0.0] | 51% | 21.7% |
| BREAKDOWN:STALLED | 3 | 0% | -452.4 | -452.4 | +0.0 | 33% | 33.3% |
| FAILED_BREAKDOWN:FAILED | 70 | 4% | +20.1 [-84.8, +126.3] | +20.1 [-84.8, +126.3] | +0.0 [+0.0, +0.0] | 49% | 10.0% |
| (blank) | 396 | 21% | +34.9 [-29.0, +102.2] | +34.9 [-29.0, +102.2] | +0.0 [+0.0, +0.0] | 48% | 13.4% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 1,815 | 95% | +136.8 [+87.1, +187.4] | +136.8 [+87.1, +187.4] | +0.0 [+0.0, +0.0] | 54% | 15.4% |
| overextended | 82 | 4% | +311.0 [+111.1, +522.5] | +311.0 [+111.1, +522.5] | +0.0 [+0.0, +0.0] | 67% | 15.9% |
| extreme | 6 | 0% | -52.0 | -52.0 | +0.0 | 67% | 33.3% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 264 | 14% | +76.2 [-18.2, +182.1] | +76.2 [-18.2, +182.1] | +0.0 [+0.0, +0.0] | 50% | 10.6% |
| NORMAL | 983 | 52% | +106.8 [+39.6, +172.7] | +106.8 [+39.6, +172.7] | +0.0 [+0.0, +0.0] | 53% | 16.0% |
| ELEVATED | 369 | 19% | +226.2 [+123.7, +320.0] | +226.2 [+123.7, +320.0] | +0.0 [+0.0, +0.0] | 56% | 13.6% |
| EXTREME | 287 | 15% | +225.9 [+88.0, +360.0] | +225.9 [+88.0, +360.0] | +0.0 [+0.0, +0.0] | 61% | 20.6% |

**SDE10 at the pick (signed directional efficiency, 10 sessions)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NEG < -0.5 | 763 | 40% | +209.2 [+105.0, +309.7] | +209.2 [+105.0, +309.7] | +0.0 [+0.0, +0.0] | 59% | 17.7% |
| MID | 863 | 45% | +77.5 [+31.0, +127.6] | +77.5 [+31.0, +127.6] | +0.0 [+0.0, +0.0] | 50% | 12.4% |
| POS >= +0.5 | 277 | 15% | +169.2 [+27.7, +309.3] | +169.2 [+27.7, +309.3] | +0.0 [+0.0, +0.0] | 56% | 18.8% |

**RSJ10 at the pick (up minus down variance, 10 returns)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| falls < -0.5 | 860 | 45% | +186.9 [+97.8, +282.0] | +186.9 [+97.8, +282.0] | +0.0 [+0.0, +0.0] | 57% | 17.7% |
| MID | 621 | 33% | +74.7 [+24.6, +124.6] | +74.7 [+24.6, +124.6] | +0.0 [+0.0, +0.0] | 49% | 12.4% |
| rises >= +0.5 | 422 | 22% | +157.1 [+47.7, +266.9] | +157.1 [+47.7, +266.9] | +0.0 [+0.0, +0.0] | 56% | 15.4% |

**Lower-circuit close in the 3 sessions to the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 1,661 | 87% | +140.6 [+94.3, +187.3] | +140.6 [+94.3, +187.3] | +0.0 [+0.0, +0.0] | 54% | 14.2% |
| yes | 242 | 13% | +165.0 [-34.5, +351.7] | +165.0 [-34.5, +351.7] | +0.0 [+0.0, +0.0] | 60% | 24.0% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3% | 205 | 11% | -507.4 [-594.9, -416.3] | -507.4 [-594.9, -416.3] | +0.0 [+0.0, +0.0] | 23% | 52.2% |
| -3% .. -1% | 279 | 15% | -103.5 [-176.4, -25.1] | -103.5 [-176.4, -25.1] | +0.0 [+0.0, +0.0] | 35% | 22.6% |
| -1% .. +1% | 680 | 36% | +136.9 [+79.8, +193.1] | +136.9 [+79.8, +193.1] | +0.0 [+0.0, +0.0] | 54% | 9.4% |
| +1% .. +3% | 531 | 28% | +278.7 [+213.1, +346.9] | +278.7 [+213.1, +346.9] | +0.0 [+0.0, +0.0] | 65% | 9.0% |
| >= +3% | 208 | 11% | +794.4 [+618.1, +956.7] | +794.4 [+618.1, +956.7] | +0.0 [+0.0, +0.0] | 86% | 5.8% |


## Frozen setups (setuplab tags)

Tags TAGS_20261108_001 (setuplab v0.7), freeze sha256 483f1539324f3ae5, signal days ['2020-01-16', '2026-09-15']; they cover 3,997 of this run's picks. Columns in trades.csv: setups (e.g. S2@D3 = setup S2 entered on watch day 3), n_setups, su_<ID>_day, setups_tagged.

This strategy enters on its own rules: for it the tags are hindsight (a setup is known only on its own entry day) - describe trades with them, never pick trades by them.

## Calm / jumpy lanes and the entry tree (setuplab tree)

Tree run TREE_20261109_001 (setuplab v1.1), TREE.json sha256 5cd4571765c2de80, freeze 483f1539324f3ae5, history window ['2021-01-01', '2026-09-22'], RECONCILED with the declaration; it covers 3,997 of this run's picks. Lane = the pick's 14-session ATR / close against its year's cut-off (the 2/3 quantile of earlier years' picks): 2021 5.77%, 2022 5.64%, 2023 5.75%, 2024 5.35%, 2025 5.49%, 2026 5.52%. CALM = at or below, JUMPY = above; picks before the first cut-off year have no lane. The lane is known at the pick's close (a pre-pick breakdown); trades.csv also carries the tree's action on each rank 1-3 pick (tree_action, tree_how, tree_net, opened_up - hindsight: the tree decides at the open and on each setup's own day).

This strategy IS the tree: it buys where the tree bought (tree_how: 'open' = the D1 open, 'S2@D3' = setup S2's own day-3 open) and sells where the tree sold (the 5th close; N1 4 sessions after its entry); a pick the tree skips is not entered (0 bp). The comparison buys every pick at the D1 open. The money view uses tradelab's account (integer shares, its tie order: rank, then engine); setuplab's TREE.md is the reference for the tree's own book numbers. These years are the history the tree was declared on (descriptive); only the forward record judges it.

Paired picks by lane: strategy, tree and the difference (strategy - tree), bp, 95% block-bootstrap intervals over signal days. Descriptive: one lane 'BETTER' is a hypothesis.

| engine | lane | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|
| D | CALM | 1,315 | 1,315 | +117.7 [+64.2, +172.3] | +117.7 [+64.2, +172.3] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| D | JUMPY | 588 | 588 | +201.8 [+109.3, +294.3] | +201.8 [+109.3, +294.3] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |

## SDE at the pick (signed directional efficiency)

SDE_N = (close at the pick - close N sessions before) / the sum of the N absolute close-to-close moves to the pick: -1 = an orderly fall, +1 = an orderly rise; known at the pick's close (pre_sde3 / 5 / 10 / 20 in trades.csv, usable in filters). SDE10 known for 4,223 of 4,242 picks (NEG < -0.5 1,420, MID 2,089, POS >= +0.5 714); blank when the window is flat, has a missing bar or a close-to-close move above 45% (an unadjusted split or bonus).

Paired picks by SDE10 and lane: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Many groups: one 'BETTER' is a hypothesis to declare and test forward.

| engine | lane | SDE10 | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| D | CALM | NEG < -0.5 | 404 | 404 | +156.8 [+24.9, +288.6] | +156.8 [+24.9, +288.6] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| D | CALM | MID | 648 | 648 | +67.6 [+23.4, +109.6] | +67.6 [+23.4, +109.6] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| D | CALM | POS >= +0.5 | 263 | 263 | +181.0 [+34.3, +332.0] | +181.0 [+34.3, +332.0] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| D | JUMPY | NEG < -0.5 | 359 | 359 | +268.3 [+137.8, +391.3] | +268.3 [+137.8, +391.3] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| D | JUMPY | MID | 215 | 215 | +107.4 [-7.0, +228.0] | +107.4 [-7.0, +228.0] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| D | JUMPY | POS >= +0.5 | 14 | 14 | -52.1 | -52.1 | +0.0 | NO INTERVAL (fewer than 20 signal days) |

## Volatility x direction at the pick (voldir VD1)

RSJ10 known for 4,223 of 4,242 picks; a lower-circuit close in the 3 sessions to the pick on 464; day cross-section flags from voldir run VD_20261112_001 (daily_cuts sha256 74ff14ffd06a0d6d).
Where the paired picks sit: RSJ10 deciles 10/25/50/75/90% = -0.96 / -0.82 / -0.34 / +0.43 / +0.80.
Share of the paired picks 33.4% in the day's lowest RSJ tenth; 9.3% in its highest tenth; 41.0% in the top turnover third; 70.6% in the top ATR third; 15.6% in the top 20-day-return tenth; 18.8% on high market volatility days (a universe-wide rule needs room inside the picks: a share near 0 or 1 leaves nothing to separate).

Paired picks by the value at the pick: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Descriptive: a 'BETTER' here is a hypothesis.

| split | engine | group | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| RSJ10 at the pick (up minus down variance, 10 returns) | D | falls < -0.5 | 860 | 860 | +186.9 [+97.8, +282.0] | +186.9 [+97.8, +282.0] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | D | MID | 621 | 621 | +74.7 [+24.6, +124.6] | +74.7 [+24.6, +124.6] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | D | rises >= +0.5 | 422 | 422 | +157.1 [+47.7, +266.9] | +157.1 [+47.7, +266.9] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | D | no | 1,661 | 1,661 | +140.6 [+94.3, +187.3] | +140.6 [+94.3, +187.3] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | D | yes | 242 | 242 | +165.0 [-34.5, +351.7] | +165.0 [-34.5, +351.7] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
