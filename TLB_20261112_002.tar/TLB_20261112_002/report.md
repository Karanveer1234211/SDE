# tradelab backtest - voldir_B2

tl_backtest v1.3.1 (tradelab v1.3.1), 2026-11-12T09:51:35. pick_meta run PM_20261017_001. Strategy strategies\voldir.py (sha d84b89bfaf7022d5, mode daily), compared with tree.
Tag: -. Declared rule: voldir VD1 Stage 2 B2 D.

## Verdict first

- Per pick slot: strategy **+113.1 [+76.7, +152.3] bp**, tree +143.7 [+95.2, +196.0] bp, difference **-30.6 [-59.2, -3.3] bp -> WORSE (interval below 0)** (1,903 picks, 1,267 signal days).
- On the picks the strategy actually traded (1,643): difference +0.0 [+0.0, +0.0] bp.
- Picks the plan finished but the strategy could not trade (0, {}): the plan made n/a bp on them vs +143.7 [+95.2, +196.0] bp on the paired picks - a large gap means the pairing is not a fair sample.
- Entered 86.3% of picks; average size used 0.86 of the target; net on the money actually used +131.0 bp.

## Money view (one account, the strategy's sizing)

| | strategy | tree |
|---|---|---|
| CAGR | +91.37% | +97.40% |
| worst drawdown | -20.32% (2021-09-30 -> 2021-11-16) | -29.04% (2025-11-03 -> 2026-04-07) |
| Sharpe (daily x sqrt 252) | 1.97 | 2.03 |
| average exposure | 0.68 | 0.70 |
| trades opened | 809 | 829 |
| skipped (reason) | {'max_open': 834} | {'max_open': 1074} |
| legs trimmed / skipped by cash | 244 / 0 | 253 / 0 |

Daily return difference: -1.35 [-8.46, +6.30] bp a day -> NOT SHOWN (interval spans 0) (one-sided p 0.6520).
Calmar ratio (CAGR over 252 sessions a year / |worst drawdown|, from the daily returns): strategy 4.592, tree 3.426, difference +1.166 [-2.398, +2.798] (paired block bootstrap; one-sided p 0.4460).

## Detail

- Win rate: strategy 45.8%, tree 54.4%.
- Legs filled (share of entered picks): {'tree': 1.0}.
- Exit reasons: {'tree': 1643}.
- Median MFE +4.70%, median MAE -3.03% (from the first buy, while held).
- Average exit session 5.18; locked exits 30; bars where a stop and a target were both inside the bar (settled by the 'worst' policy): 0.
- Left out of the pairing: strategy {'not_entered': 2339}, tree {'not_entered': 2339}.

### By year (bp per pick)

| year | picks | strategy | tree | difference |
|---|---|---|---|---|
| 2021 | 347 | +99.6 | +169.7 | -70.1 |
| 2022 | 344 | +185.0 | +208.4 | -23.4 |
| 2023 | 350 | +66.0 | +43.1 | +22.9 |
| 2024 | 314 | +100.9 | +210.6 | -109.7 |
| 2025 | 339 | +107.7 | +127.2 | -19.6 |
| 2026 | 209 | +123.3 | +88.3 | +35.0 |

### By engine and rank (bp per pick)

| engine | rank | picks | strategy | tree | difference |
|---|---|---|---|---|---|
| D | 1 | 838 | +94.7 | +135.4 | -40.7 |
| D | 2 | 578 | +149.8 | +163.6 | -13.8 |
| D | 3 | 487 | +101.2 | +134.3 | -33.1 |

## How much to trust this

- The tradelab ledger held 5 earlier backtests (3 distinct strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at the 95% level by luck alone.
- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.
- Costs: flat 35 bp round trip on entry notional (half at buy, half at sale); slippage 0.0 bp a side. Fills: next-bar opens, stop / limit levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.
- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model.

## Decision rule: {'rule': {'metric': 'daily_diff_bp', 'pass_if': 'lower > 0', 'money': 'cagr_and_drawdown'}, 'value': -8.463862045085499, 'p_one_sided': 0.652, 'metric_value': [-1.3505875627719437, -8.463862045085499, 6.295930505405098], 'cagr': [0.9136757134033509, 0.9740279013233106], 'max_drawdown': [-0.20317077525598248, -0.29042356517166334], 'money_ok': False, 'verdict': 'FAIL'}

## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)

### The money by environment (known at the previous close)

Each account's daily returns grouped by the environment known before the day began: mean day return (bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), average exposure and the most positions open at once.

| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |
|---|---|---|---|---|---|---|---|---|
| voldir_B2 | broad_bullish | 426 (30%) | +28.16 [+9.11, +48.09] | +201.56% | -19.00% | -817 | 0.72 | 3 |
| voldir_B2 | narrow_bullish | 383 (27%) | +9.62 [-11.96, +30.83] | +31.79% | -40.49% | -734 | 0.68 | 3 |
| voldir_B2 | mixed | 194 (14%) | +47.98 [+21.17, +77.30] | +138.40% | -11.12% | -554 | 0.66 | 3 |
| voldir_B2 | broad_bearish | 224 (16%) | +27.29 [-4.03, +57.62] | +70.81% | -23.55% | -929 | 0.64 | 3 |
| voldir_B2 | high_stress | 191 (13%) | +51.38 [+23.20, +81.39] | +152.06% | -10.81% | -576 | 0.61 | 3 |
| tree | broad_bullish | 426 (30%) | +34.11 [+13.59, +57.16] | +288.44% | -18.14% | -797 | 0.73 | 3 |
| tree | narrow_bullish | 383 (27%) | +12.49 [-9.60, +32.97] | +47.00% | -41.21% | -734 | 0.71 | 3 |
| tree | mixed | 194 (14%) | +54.66 [+22.03, +90.17] | +172.40% | -16.47% | -551 | 0.67 | 3 |
| tree | broad_bearish | 224 (16%) | +27.03 [-10.20, +61.24] | +68.61% | -23.92% | -788 | 0.68 | 3 |
| tree | high_stress | 191 (13%) | +35.91 [-0.51, +68.94] | +85.74% | -22.51% | -675 | 0.68 | 3 |

### The paired picks by the market and by the stock's state at the pick

'difference' = strategy - tree on the same picks, bp, 95% block-bootstrap intervals over signal days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a finding. Nothing here filters trades.

#### engine D

**environment at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 518 | 27% | +57.0 [-9.4, +128.3] | +60.8 [-8.9, +131.9] | -3.8 [-26.8, +23.6] | 47% | 11.8% |
| narrow_bullish | 509 | 27% | +69.3 [+16.5, +127.8] | +110.3 [+36.2, +184.4] | -41.1 [-84.2, +3.9] | 45% | 13.4% |
| mixed | 247 | 13% | +136.7 [+22.2, +251.5] | +166.6 [+13.7, +324.4] | -29.9 [-96.4, +26.1] | 45% | 10.9% |
| broad_bearish | 366 | 19% | +149.3 [+56.5, +253.7] | +188.3 [+57.0, +333.7] | -39.0 [-112.8, +40.3] | 46% | 14.2% |
| high_stress | 263 | 14% | +236.0 [+126.5, +362.2] | +287.9 [+138.1, +451.2] | -51.9 [-145.4, +36.5] | 47% | 10.3% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 1,640 | 86% | +93.4 [+56.8, +133.3] | +120.5 [+73.5, +169.6] | -27.1 [-53.1, -1.3] | 46% | 12.7% |
| yes | 263 | 14% | +236.0 [+126.5, +362.2] | +287.9 [+138.1, +451.2] | -51.9 [-145.4, +36.5] | 47% | 10.3% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 557 | 29% | +48.9 [-23.1, +121.4] | +60.7 [-7.7, +133.5] | -11.8 [-38.4, +15.8] | 46% | 12.4% |
| narrow_bullish | 575 | 30% | +82.3 [+21.8, +144.6] | +142.3 [+59.2, +225.9] | -60.0 [-107.2, -12.6] | 45% | 13.6% |
| mixed | 277 | 15% | +156.1 [+56.7, +250.0] | +187.4 [+48.0, +318.7] | -31.3 [-93.0, +25.6] | 45% | 11.2% |
| broad_bearish | 494 | 26% | +197.2 [+113.5, +286.5] | +214.3 [+77.2, +346.6] | -17.1 [-92.4, +64.0] | 47% | 11.5% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < 0.40 | 230 | 12% | +342.7 [+230.4, +460.4] | +347.9 [+196.4, +506.5] | -5.1 [-99.6, +106.6] | 55% | 9.1% |
| 0.40 - 0.50 | 967 | 51% | +83.9 [+31.5, +137.2] | +130.7 [+54.4, +207.3] | -46.8 [-88.1, -4.6] | 42% | 13.4% |
| 0.50 - 0.60 | 661 | 35% | +71.3 [+7.7, +137.5] | +90.3 [+20.0, +166.1] | -18.9 [-51.5, +9.9] | 46% | 11.5% |
| >= 0.60 | 45 | 2% | +179.9 [-132.1, +445.7] | +163.3 [-134.4, +425.6] | +16.6 [+0.0, +44.9] | 64% | 17.8% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -10% | 204 | 11% | +142.6 [+57.2, +246.3] | +187.1 [+56.3, +333.3] | -44.6 [-136.9, +36.6] | 46% | 12.7% |
| -10% .. 0% | 757 | 40% | +54.4 [+3.2, +104.0] | +72.7 [+10.4, +133.3] | -18.3 [-45.8, +8.1] | 46% | 13.3% |
| 0% .. +10% | 624 | 33% | +136.6 [+72.8, +209.0] | +170.3 [+93.8, +257.6] | -33.7 [-72.2, +0.1] | 46% | 12.0% |
| +10% .. +25% | 273 | 14% | +193.3 [+98.8, +299.1] | +231.7 [+130.7, +345.6] | -38.4 [-112.3, +33.8] | 46% | 10.3% |
| >= +25% | 45 | 2% | +154.1 [-179.6, +390.1] | +236.6 [-54.1, +462.2] | -82.5 [-164.5, -5.0] | 40% | 11.1% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 506 | 27% | +38.7 [-23.9, +97.6] | +63.2 [-14.9, +137.0] | -24.4 [-61.0, +10.3] | 42% | 13.0% |
| -3 .. 0 pts | 660 | 35% | +132.9 [+65.2, +204.5] | +161.4 [+80.3, +245.2] | -28.6 [-63.8, +8.0] | 48% | 10.8% |
| 0 .. +3 pts | 462 | 24% | +139.1 [+59.5, +217.1] | +161.7 [+66.1, +266.5] | -22.6 [-83.1, +48.6] | 47% | 12.8% |
| >= +3 pts (NIFTY ahead: narrow) | 275 | 14% | +158.8 [+61.3, +252.2] | +218.8 [+88.4, +349.9] | -60.0 [-125.2, +3.8] | 45% | 14.2% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no list | 1,903 | 100% | +113.1 [+76.7, +152.3] | +143.7 [+95.2, +196.0] | -30.6 [-59.2, -3.3] | 46% | 12.3% |

**home index** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NIFTY 50 | 129 | 7% | +165.4 [+41.7, +301.0] | +93.0 [-108.7, +268.0] | +72.5 [-15.3, +237.5] | 53% | 9.3% |
| Midcap 150 | 412 | 22% | +65.8 [-9.1, +142.6] | +103.8 [+13.3, +200.5] | -38.1 [-94.2, +16.9] | 47% | 13.3% |
| Smallcap 250 | 1,362 | 72% | +122.5 [+79.9, +167.6] | +160.5 [+102.6, +221.3] | -38.1 [-68.7, -9.0] | 45% | 12.3% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 249 | 13% | +59.8 [-21.3, +150.5] | +61.2 [-17.4, +145.9] | -1.4 [-43.2, +54.1] | 47% | 15.3% |
| S02 | 128 | 7% | +131.3 [-24.0, +319.9] | +191.5 [+15.0, +395.4] | -60.2 [-171.0, +20.0] | 45% | 10.9% |
| S03 | 185 | 10% | +42.1 [-28.3, +120.7] | +50.0 [-23.4, +132.0] | -7.9 [-23.0, +0.0] | 42% | 11.9% |
| S06 | 56 | 3% | +204.2 [+4.1, +380.8] | +181.2 [-9.5, +354.1] | +23.1 [-46.4, +90.9] | 45% | 12.5% |
| S07 | 82 | 4% | +63.6 [+1.7, +126.5] | +54.3 [-18.1, +129.3] | +9.2 [-42.7, +54.2] | 44% | 7.3% |
| S08 | 226 | 12% | +190.0 [+89.3, +301.4] | +251.9 [+134.5, +373.7] | -61.9 [-130.6, -9.3] | 57% | 11.5% |
| S09 | 510 | 27% | +178.2 [+113.9, +245.5] | +213.8 [+111.4, +319.5] | -35.6 [-105.2, +34.7] | 44% | 11.2% |
| UNKNOWN | 467 | 25% | +54.1 [-18.1, +130.7] | +93.9 [-7.8, +199.0] | -39.8 [-92.8, +18.0] | 44% | 13.9% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 477 | 25% | +86.6 [+27.4, +147.5] | +128.1 [+48.8, +206.4] | -41.5 [-82.1, -4.2] | 44% | 11.7% |
| MATURE | 731 | 38% | +184.7 [+131.2, +242.1] | +210.5 [+140.3, +284.3] | -25.8 [-70.8, +22.0] | 50% | 10.9% |
| DETERIORATING | 228 | 12% | +60.0 [-24.4, +155.3] | +63.9 [-23.9, +162.7] | -3.9 [-31.9, +22.3] | 41% | 14.9% |
| (blank) | 467 | 25% | +54.1 [-18.1, +130.7] | +93.9 [-7.8, +199.0] | -39.8 [-92.8, +18.0] | 44% | 13.9% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| HIGH | 706 | 37% | +165.1 [+110.6, +218.6] | +192.4 [+121.0, +263.8] | -27.3 [-75.1, +20.1] | 49% | 11.8% |
| MEDIUM | 502 | 26% | +119.0 [+57.1, +191.4] | +157.6 [+87.6, +241.1] | -38.6 [-83.1, -2.9] | 45% | 10.6% |
| LOW | 228 | 12% | +60.0 [-24.4, +155.3] | +63.9 [-23.9, +162.7] | -3.9 [-31.9, +22.3] | 41% | 14.9% |
| UNKNOWN | 467 | 25% | +54.1 [-18.1, +130.7] | +93.9 [-7.8, +199.0] | -39.8 [-92.8, +18.0] | 44% | 13.9% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 183 | 10% | +235.3 [+79.9, +403.3] | +241.6 [+81.5, +415.8] | -6.2 [-19.2, +0.0] | 55% | 15.8% |
| BREAKOUT:CONFIRMED | 215 | 11% | +82.1 [-28.0, +189.6] | +148.2 [+15.7, +275.6] | -66.1 [-141.7, +0.7] | 47% | 12.1% |
| BREAKOUT:STALLED | 16 | 1% | -18.8 | -18.8 | +0.0 | 38% | 12.5% |
| FAILED_BREAKOUT:FAILED | 160 | 8% | +67.8 [-29.9, +163.0] | +116.7 [+9.5, +228.1] | -48.9 [-99.0, -6.6] | 45% | 8.8% |
| BREAKDOWN:NEW | 593 | 31% | +163.1 [+88.6, +240.2] | +221.9 [+123.0, +328.8] | -58.8 [-111.1, -8.4] | 47% | 12.3% |
| BREAKDOWN:CONFIRMED | 267 | 14% | +120.8 [-9.1, +262.7] | +125.6 [-71.4, +307.9] | -4.8 [-104.2, +108.6] | 42% | 15.4% |
| BREAKDOWN:STALLED | 3 | 0% | +0.0 | -452.4 | +452.4 | 0% | 0.0% |
| FAILED_BREAKDOWN:FAILED | 70 | 4% | +9.9 [-96.7, +123.6] | +20.1 [-84.8, +126.3] | -10.2 [-31.1, +2.7] | 47% | 10.0% |
| (blank) | 396 | 21% | +36.2 [-23.8, +102.2] | +34.9 [-29.0, +102.2] | +1.3 [-24.1, +27.8] | 43% | 10.9% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 1,815 | 95% | +105.3 [+68.0, +145.8] | +136.8 [+87.1, +187.4] | -31.5 [-59.6, -2.9] | 45% | 12.3% |
| overextended | 82 | 4% | +272.5 [+85.1, +464.9] | +311.0 [+111.1, +522.5] | -38.6 [-93.6, +12.5] | 60% | 13.4% |
| extreme | 6 | 0% | +301.5 | -52.0 | +353.5 | 50% | 16.7% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 264 | 14% | +54.4 [-36.8, +157.2] | +76.2 [-18.2, +182.1] | -21.7 [-57.3, +0.9] | 47% | 10.2% |
| NORMAL | 983 | 52% | +81.8 [+31.6, +132.3] | +106.8 [+39.6, +172.7] | -25.0 [-61.9, +13.3] | 45% | 13.3% |
| ELEVATED | 369 | 19% | +151.4 [+69.7, +231.7] | +226.2 [+123.7, +320.0] | -74.8 [-131.7, -21.2] | 46% | 11.7% |
| EXTREME | 287 | 15% | +225.2 [+138.4, +321.0] | +225.9 [+88.0, +360.0] | -0.7 [-89.6, +94.6] | 46% | 11.8% |

**SDE10 at the pick (signed directional efficiency, 10 sessions)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NEG < -0.5 | 763 | 40% | +158.0 [+87.6, +228.9] | +209.2 [+105.0, +309.7] | -51.2 [-112.3, +9.7] | 46% | 13.0% |
| MID | 863 | 45% | +54.4 [+12.7, +97.1] | +77.5 [+31.0, +127.6] | -23.1 [-52.8, +3.7] | 44% | 10.7% |
| POS >= +0.5 | 277 | 15% | +172.3 [+47.8, +307.1] | +169.2 [+27.7, +309.3] | +3.0 [-33.3, +39.6] | 52% | 15.9% |

**RSJ10 at the pick (up minus down variance, 10 returns)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| falls < -0.5 | 860 | 45% | +140.4 [+79.6, +205.3] | +186.9 [+97.8, +282.0] | -46.5 [-96.6, +9.4] | 45% | 12.9% |
| MID | 621 | 33% | +46.4 [+1.9, +94.8] | +74.7 [+24.6, +124.6] | -28.3 [-63.6, +6.3] | 42% | 10.6% |
| rises >= +0.5 | 422 | 22% | +155.6 [+56.0, +259.6] | +157.1 [+47.7, +266.9] | -1.5 [-26.7, +25.1] | 53% | 13.7% |

**Lower-circuit close in the 3 sessions to the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 1,661 | 87% | +127.0 [+82.8, +172.5] | +140.6 [+94.3, +187.3] | -13.6 [-23.9, -5.2] | 52% | 13.8% |
| yes | 242 | 13% | +18.0 [-7.4, +44.5] | +165.0 [-34.5, +351.7] | -147.0 [-338.0, +48.5] | 6% | 2.1% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3% | 167 | 9% | -433.8 [-534.2, -328.9] | -433.8 [-534.2, -328.9] | +0.0 [+0.0, +0.0] | 25% | 50.3% |
| -3% .. -1% | 242 | 13% | -129.8 [-196.9, -55.5] | -129.8 [-196.9, -55.5] | +0.0 [+0.0, +0.0] | 32% | 20.7% |
| -1% .. +1% | 615 | 32% | +123.3 [+68.7, +179.8] | +123.3 [+68.7, +179.8] | +0.0 [+0.0, +0.0] | 53% | 9.3% |
| +1% .. +3% | 455 | 24% | +241.3 [+174.5, +312.1] | +241.3 [+174.5, +312.1] | +0.0 [+0.0, +0.0] | 63% | 8.4% |
| >= +3% | 164 | 9% | +814.0 [+619.2, +1008.0] | +814.0 [+619.2, +1008.0] | +0.0 [+0.0, +0.0] | 87% | 3.7% |
| (blank) | 260 | 14% | +0.0 [+0.0, +0.0] | +223.7 [+12.8, +409.5] | -223.7 [-409.5, -12.8] | 0% | 0.0% |


## Frozen setups (setuplab tags)

Tags TAGS_20261108_001 (setuplab v0.7), freeze sha256 483f1539324f3ae5, signal days ['2020-01-16', '2026-09-15']; they cover 3,997 of this run's picks. Columns in trades.csv: setups (e.g. S2@D3 = setup S2 entered on watch day 3), n_setups, su_<ID>_day, setups_tagged.

This strategy enters on its own rules: for it the tags are hindsight (a setup is known only on its own entry day) - describe trades with them, never pick trades by them.

## Calm / jumpy lanes and the entry tree (setuplab tree)

Tree run TREE_20261109_001 (setuplab v1.1), TREE.json sha256 5cd4571765c2de80, freeze 483f1539324f3ae5, history window ['2021-01-01', '2026-09-22'], RECONCILED with the declaration; it covers 3,997 of this run's picks. Lane = the pick's 14-session ATR / close against its year's cut-off (the 2/3 quantile of earlier years' picks): 2021 5.77%, 2022 5.64%, 2023 5.75%, 2024 5.35%, 2025 5.49%, 2026 5.52%. CALM = at or below, JUMPY = above; picks before the first cut-off year have no lane. The lane is known at the pick's close (a pre-pick breakdown); trades.csv also carries the tree's action on each rank 1-3 pick (tree_action, tree_how, tree_net, opened_up - hindsight: the tree decides at the open and on each setup's own day).

This strategy IS the tree: it buys where the tree bought (tree_how: 'open' = the D1 open, 'S2@D3' = setup S2's own day-3 open) and sells where the tree sold (the 5th close; N1 4 sessions after its entry); a pick the tree skips is not entered (0 bp). The comparison buys every pick at the D1 open. The money view uses tradelab's account (integer shares, its tie order: rank, then engine); setuplab's TREE.md is the reference for the tree's own book numbers. These years are the history the tree was declared on (descriptive); only the forward record judges it.

Paired picks by lane: strategy, tree and the difference (strategy - tree), bp, 95% block-bootstrap intervals over signal days. Descriptive: one lane 'BETTER' is a hypothesis.

| engine | lane | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|
| D | CALM | 1,315 | 1,231 | +104.3 [+61.8, +150.7] | +117.7 [+64.2, +172.3] | -13.4 [-36.0, +11.7] | NOT SHOWN (interval spans 0) |
| D | JUMPY | 588 | 412 | +132.9 [+73.9, +193.1] | +201.8 [+109.3, +294.3] | -68.9 [-134.6, -6.6] | WORSE (interval below 0) |

## SDE at the pick (signed directional efficiency)

SDE_N = (close at the pick - close N sessions before) / the sum of the N absolute close-to-close moves to the pick: -1 = an orderly fall, +1 = an orderly rise; known at the pick's close (pre_sde3 / 5 / 10 / 20 in trades.csv, usable in filters). SDE10 known for 4,223 of 4,242 picks (NEG < -0.5 1,420, MID 2,089, POS >= +0.5 714); blank when the window is flat, has a missing bar or a close-to-close move above 45% (an unadjusted split or bonus).

Paired picks by SDE10 and lane: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Many groups: one 'BETTER' is a hypothesis to declare and test forward.

| engine | lane | SDE10 | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| D | CALM | NEG < -0.5 | 404 | 361 | +135.6 [+42.8, +236.3] | +156.8 [+24.9, +288.6] | -21.2 [-85.2, +54.7] | NOT SHOWN (interval spans 0) |
| D | CALM | MID | 648 | 621 | +52.7 [+9.5, +94.1] | +67.6 [+23.4, +109.6] | -14.9 [-27.0, -3.7] | WORSE (interval below 0) |
| D | CALM | POS >= +0.5 | 263 | 249 | +183.1 [+48.7, +326.0] | +181.0 [+34.3, +332.0] | +2.1 [-26.5, +32.4] | NOT SHOWN (interval spans 0) |
| D | JUMPY | NEG < -0.5 | 359 | 243 | +183.3 [+101.6, +269.4] | +268.3 [+137.8, +391.3] | -85.0 [-184.2, +15.0] | NOT SHOWN (interval spans 0) |
| D | JUMPY | MID | 215 | 161 | +59.5 [-29.4, +139.7] | +107.4 [-7.0, +228.0] | -47.9 [-149.9, +43.2] | NOT SHOWN (interval spans 0) |
| D | JUMPY | POS >= +0.5 | 14 | 8 | -31.2 | -52.1 | +20.9 | NO INTERVAL (fewer than 20 signal days) |

## Volatility x direction at the pick (voldir VD1)

RSJ10 known for 4,223 of 4,242 picks; a lower-circuit close in the 3 sessions to the pick on 464; day cross-section flags from voldir run VD_20261112_001 (daily_cuts sha256 74ff14ffd06a0d6d).
Where the paired picks sit: RSJ10 deciles 10/25/50/75/90% = -0.96 / -0.82 / -0.34 / +0.43 / +0.80.
Share of the paired picks 33.4% in the day's lowest RSJ tenth; 9.3% in its highest tenth; 41.0% in the top turnover third; 70.6% in the top ATR third; 15.6% in the top 20-day-return tenth; 18.8% on high market volatility days (a universe-wide rule needs room inside the picks: a share near 0 or 1 leaves nothing to separate).

This strategy's tree skips a buy when `pre_lock3 == 1` holds at that buy's own signal close (the close before the buy).

Paired picks by the value at the pick: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Descriptive: a 'BETTER' here is a hypothesis.

| split | engine | group | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| RSJ10 at the pick (up minus down variance, 10 returns) | D | falls < -0.5 | 860 | 686 | +140.4 [+79.6, +205.3] | +186.9 [+97.8, +282.0] | -46.5 [-96.6, +9.4] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | D | MID | 621 | 557 | +46.4 [+1.9, +94.8] | +74.7 [+24.6, +124.6] | -28.3 [-63.6, +6.3] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | D | rises >= +0.5 | 422 | 400 | +155.6 [+56.0, +259.6] | +157.1 [+47.7, +266.9] | -1.5 [-26.7, +25.1] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | D | no | 1,661 | 1,617 | +127.0 [+82.8, +172.5] | +140.6 [+94.3, +187.3] | -13.6 [-23.9, -5.2] | WORSE (interval below 0) |
| Lower-circuit close in the 3 sessions to the pick | D | yes | 242 | 26 | +18.0 [-7.4, +44.5] | +165.0 [-34.5, +351.7] | -147.0 [-338.0, +48.5] | NOT SHOWN (interval spans 0) |
