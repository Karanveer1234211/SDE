# tradelab backtest - voldir_B1

tl_backtest v1.3.1 (tradelab v1.3.1), 2026-11-12T09:54:04. pick_meta run PM_20261017_001. Strategy strategies\voldir.py (sha 3396a5eb35f61dcd, mode daily), compared with tree.
Tag: -. Declared rule: voldir VD1 Stage 2 B1 ENS.

## Verdict first

- Per pick slot: strategy **+106.2 [+57.1, +151.7] bp**, tree +106.2 [+57.1, +151.7] bp, difference **+0.0 [+0.0, +0.0] bp -> NOT SHOWN (interval spans 0)** (3,168 picks, 1,333 signal days).
- On the picks the strategy actually traded (3,168): difference +0.0 [+0.0, +0.0] bp.
- Picks the plan finished but the strategy could not trade (0, {}): the plan made n/a bp on them vs +106.2 [+57.1, +151.7] bp on the paired picks - a large gap means the pairing is not a fair sample.
- Entered 100.0% of picks; average size used 1.00 of the target; net on the money actually used +106.2 bp.

## Money view (one account, the strategy's sizing)

| | strategy | tree |
|---|---|---|
| CAGR | +53.04% | +72.11% |
| worst drawdown | -36.97% (2023-01-18 -> 2023-03-28) | -37.54% (2025-12-23 -> 2026-04-07) |
| Sharpe (daily x sqrt 252) | 1.51 | 1.66 |
| average exposure | 0.66 | 0.76 |
| trades opened | 830 | 837 |
| skipped (reason) | {'max_open': 2282, 'cash': 56} | {'max_open': 2331} |
| legs trimmed / skipped by cash | 278 / 56 | 264 / 0 |

Daily return difference: -5.47 [-10.79, -0.51] bp a day -> WORSE (interval below 0) (one-sided p 0.9810).
Calmar ratio (CAGR over 252 sessions a year / |worst drawdown|, from the daily returns): strategy 1.462, tree 1.960, difference -0.498 [-1.567, +0.648] (paired block bootstrap; one-sided p 0.7595).

## Detail

- Win rate: strategy 51.7%, tree 51.7%.
- Legs filled (share of entered picks): {'tree': 1.0}.
- Exit reasons: {'tree': 3168}.
- Median MFE +4.48%, median MAE -3.27% (from the first buy, while held).
- Average exit session 5.14; locked exits 106; bars where a stop and a target were both inside the bar (settled by the 'worst' policy): 0.
- Left out of the pairing: strategy {'not_entered': 1074}, tree {'not_entered': 1074}.

### By year (bp per pick)

| year | picks | strategy | tree | difference |
|---|---|---|---|---|
| 2021 | 583 | +132.8 | +132.8 | +0.0 |
| 2022 | 547 | +143.2 | +143.2 | +0.0 |
| 2023 | 678 | +68.6 | +68.6 | +0.0 |
| 2024 | 484 | +142.8 | +142.8 | +0.0 |
| 2025 | 539 | +99.7 | +99.7 | +0.0 |
| 2026 | 337 | +33.2 | +33.2 | +0.0 |

### By engine and rank (bp per pick)

| engine | rank | picks | strategy | tree | difference |
|---|---|---|---|---|---|
| ENS | 1 | 1,007 | +155.3 | +155.3 | +0.0 |
| ENS | 2 | 1,070 | +101.6 | +101.6 | +0.0 |
| ENS | 3 | 1,091 | +65.2 | +65.2 | +0.0 |

## How much to trust this

- The tradelab ledger held 6 earlier backtests (4 distinct strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at the 95% level by luck alone.
- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.
- Costs: flat 35 bp round trip on entry notional (half at buy, half at sale); slippage 0.0 bp a side. Fills: next-bar opens, stop / limit levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.
- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model.

## Decision rule: {'rule': {'metric': 'calmar_diff', 'pass_if': 'lower > 0', 'money': 'drawdown'}, 'value': -1.5674697078174313, 'p_one_sided': 0.7595, 'metric_value': [-0.4977614001398758, -1.5674697078174313, 0.6480384324607684], 'cagr': [0.5303937051070691, 0.7211082118875003], 'max_drawdown': [-0.3697290599612897, -0.37538360713711627], 'money_ok': True, 'verdict': 'FAIL'}

## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)

### The money by environment (known at the previous close)

Each account's daily returns grouped by the environment known before the day began: mean day return (bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), average exposure and the most positions open at once.

| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |
|---|---|---|---|---|---|---|---|---|
| voldir_B1 | broad_bullish | 426 (30%) | +27.69 [+8.11, +47.43] | +199.78% | -24.17% | -520 | 0.74 | 3 |
| voldir_B1 | narrow_bullish | 383 (27%) | +29.19 [+11.33, +48.23] | +186.59% | -18.28% | -551 | 0.66 | 3 |
| voldir_B1 | mixed | 194 (14%) | -0.90 [-27.49, +25.84] | -5.95% | -33.11% | -642 | 0.67 | 3 |
| voldir_B1 | broad_bearish | 224 (16%) | +3.87 [-29.42, +37.12] | +2.75% | -34.05% | -895 | 0.61 | 3 |
| voldir_B1 | high_stress | 191 (13%) | +18.48 [-9.24, +44.70] | +37.01% | -20.45% | -489 | 0.55 | 3 |
| tree | broad_bullish | 426 (30%) | +29.87 [+10.11, +49.07] | +228.05% | -21.42% | -624 | 0.78 | 3 |
| tree | narrow_bullish | 383 (27%) | +34.55 [+12.80, +57.36] | +242.24% | -20.70% | -649 | 0.76 | 3 |
| tree | mixed | 194 (14%) | +8.71 [-23.59, +42.64] | +11.83% | -28.77% | -672 | 0.75 | 3 |
| tree | broad_bearish | 224 (16%) | +15.24 [-23.39, +52.25] | +29.52% | -27.73% | -1065 | 0.71 | 3 |
| tree | high_stress | 191 (13%) | +20.37 [-24.64, +57.93] | +36.84% | -35.88% | -673 | 0.76 | 3 |

### The paired picks by the market and by the stock's state at the pick

'difference' = strategy - tree on the same picks, bp, 95% block-bootstrap intervals over signal days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a finding. Nothing here filters trades.

#### engine ENS

**environment at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,060 | 33% | +81.7 [+19.7, +139.5] | +81.7 [+19.7, +139.5] | +0.0 [+0.0, +0.0] | 50% | 14.1% |
| narrow_bullish | 887 | 28% | +102.7 [+39.5, +161.3] | +102.7 [+39.5, +161.3] | +0.0 [+0.0, +0.0] | 51% | 13.6% |
| mixed | 411 | 13% | +25.0 [-87.9, +127.3] | +25.0 [-87.9, +127.3] | +0.0 [+0.0, +0.0] | 45% | 17.5% |
| broad_bearish | 456 | 14% | +124.1 [-61.3, +309.4] | +124.1 [-61.3, +309.4] | +0.0 [+0.0, +0.0] | 54% | 21.7% |
| high_stress | 354 | 11% | +259.1 [+117.9, +397.0] | +259.1 [+117.9, +397.0] | +0.0 [+0.0, +0.0] | 61% | 15.5% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 2,814 | 89% | +86.9 [+42.1, +129.7] | +86.9 [+42.1, +129.7] | +0.0 [+0.0, +0.0] | 50% | 15.7% |
| yes | 354 | 11% | +259.1 [+117.9, +397.0] | +259.1 [+117.9, +397.0] | +0.0 [+0.0, +0.0] | 61% | 15.5% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,124 | 35% | +81.6 [+21.0, +139.7] | +81.6 [+21.0, +139.7] | +0.0 [+0.0, +0.0] | 50% | 14.1% |
| narrow_bullish | 990 | 31% | +134.5 [+62.7, +204.4] | +134.5 [+62.7, +204.4] | +0.0 [+0.0, +0.0] | 53% | 13.3% |
| mixed | 459 | 14% | +58.1 [-50.7, +171.6] | +58.1 [-50.7, +171.6] | +0.0 [+0.0, +0.0] | 48% | 16.6% |
| broad_bearish | 595 | 19% | +142.5 [-23.7, +304.6] | +142.5 [-23.7, +304.6] | +0.0 [+0.0, +0.0] | 55% | 21.7% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < 0.40 | 288 | 9% | +256.5 [+101.2, +408.4] | +256.5 [+101.2, +408.4] | +0.0 [+0.0, +0.0] | 64% | 18.4% |
| 0.40 - 0.50 | 1,493 | 47% | +96.0 [+24.0, +162.3] | +96.0 [+24.0, +162.3] | +0.0 [+0.0, +0.0] | 50% | 16.1% |
| 0.50 - 0.60 | 1,296 | 41% | +76.0 [+20.4, +129.9] | +76.0 [+20.4, +129.9] | +0.0 [+0.0, +0.0] | 50% | 14.7% |
| >= 0.60 | 91 | 3% | +226.8 [+46.9, +373.5] | +226.8 [+46.9, +373.5] | +0.0 [+0.0, +0.0] | 63% | 12.1% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -10% | 357 | 11% | +114.1 [+25.1, +209.3] | +114.1 [+25.1, +209.3] | +0.0 [+0.0, +0.0] | 51% | 16.0% |
| -10% .. 0% | 1,329 | 42% | +74.9 [+21.7, +126.3] | +74.9 [+21.7, +126.3] | +0.0 [+0.0, +0.0] | 51% | 15.3% |
| 0% .. +10% | 1,033 | 33% | +123.0 [+51.4, +197.9] | +123.0 [+51.4, +197.9] | +0.0 [+0.0, +0.0] | 51% | 15.6% |
| +10% .. +25% | 384 | 12% | +151.0 [+42.5, +253.3] | +151.0 [+42.5, +253.3] | +0.0 [+0.0, +0.0] | 57% | 16.1% |
| >= +25% | 65 | 2% | +168.3 [-87.8, +365.3] | +168.3 [-87.8, +365.3] | +0.0 [+0.0, +0.0] | 55% | 20.0% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 983 | 31% | +46.5 [-22.5, +118.1] | +46.5 [-22.5, +118.1] | +0.0 [+0.0, +0.0] | 46% | 15.0% |
| -3 .. 0 pts | 1,126 | 36% | +108.0 [+43.1, +173.2] | +108.0 [+43.1, +173.2] | +0.0 [+0.0, +0.0] | 54% | 15.0% |
| 0 .. +3 pts | 697 | 22% | +127.0 [+19.1, +230.5] | +127.0 [+19.1, +230.5] | +0.0 [+0.0, +0.0] | 54% | 16.9% |
| >= +3 pts (NIFTY ahead: narrow) | 362 | 11% | +222.2 [+88.7, +362.6] | +222.2 [+88.7, +362.6] | +0.0 [+0.0, +0.0] | 55% | 17.1% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no list | 3,168 | 100% | +106.2 [+57.1, +151.7] | +106.2 [+57.1, +151.7] | +0.0 [+0.0, +0.0] | 52% | 15.7% |

**home index** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NIFTY 50 | 234 | 7% | +26.7 [-161.1, +199.1] | +26.7 [-161.1, +199.1] | +0.0 [+0.0, +0.0] | 50% | 12.4% |
| Midcap 150 | 673 | 21% | +87.5 [-21.5, +185.6] | +87.5 [-21.5, +185.6] | +0.0 [+0.0, +0.0] | 54% | 13.4% |
| Smallcap 250 | 2,261 | 71% | +119.9 [+68.3, +171.5] | +119.9 [+68.3, +171.5] | +0.0 [+0.0, +0.0] | 51% | 16.7% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 458 | 14% | +124.0 [+37.2, +209.8] | +124.0 [+37.2, +209.8] | +0.0 [+0.0, +0.0] | 56% | 16.2% |
| S02 | 188 | 6% | +111.3 [-38.1, +264.4] | +111.3 [-38.1, +264.4] | +0.0 [+0.0, +0.0] | 48% | 16.5% |
| S03 | 518 | 16% | +42.1 [-18.6, +100.6] | +42.1 [-18.6, +100.6] | +0.0 [+0.0, +0.0] | 46% | 11.6% |
| S06 | 86 | 3% | +348.8 [+95.5, +605.7] | +348.8 [+95.5, +605.7] | +0.0 [+0.0, +0.0] | 55% | 15.1% |
| S07 | 137 | 4% | +9.2 [-64.6, +81.8] | +9.2 [-64.6, +81.8] | +0.0 [+0.0, +0.0] | 45% | 8.0% |
| S08 | 314 | 10% | +182.1 [+57.3, +305.7] | +182.1 [+57.3, +305.7] | +0.0 [+0.0, +0.0] | 55% | 15.6% |
| S09 | 646 | 20% | +125.3 [+3.8, +238.0] | +125.3 [+3.8, +238.0] | +0.0 [+0.0, +0.0] | 56% | 17.6% |
| UNKNOWN | 821 | 26% | +82.1 [+0.1, +160.7] | +82.1 [+0.1, +160.7] | +0.0 [+0.0, +0.0] | 50% | 17.5% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 797 | 25% | +99.0 [+34.8, +160.9] | +99.0 [+34.8, +160.9] | +0.0 [+0.0, +0.0] | 54% | 15.4% |
| MATURE | 1,167 | 37% | +111.1 [+50.3, +175.2] | +111.1 [+50.3, +175.2] | +0.0 [+0.0, +0.0] | 51% | 14.9% |
| DETERIORATING | 383 | 12% | +157.7 [+74.5, +241.6] | +157.7 [+74.5, +241.6] | +0.0 [+0.0, +0.0] | 54% | 14.4% |
| (blank) | 821 | 26% | +82.1 [+0.1, +160.7] | +82.1 [+0.1, +160.7] | +0.0 [+0.0, +0.0] | 50% | 17.5% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| HIGH | 1,076 | 34% | +109.9 [+38.2, +181.3] | +109.9 [+38.2, +181.3] | +0.0 [+0.0, +0.0] | 52% | 15.3% |
| MEDIUM | 888 | 28% | +101.6 [+43.6, +162.9] | +101.6 [+43.6, +162.9] | +0.0 [+0.0, +0.0] | 52% | 14.9% |
| LOW | 383 | 12% | +157.7 [+74.5, +241.6] | +157.7 [+74.5, +241.6] | +0.0 [+0.0, +0.0] | 54% | 14.4% |
| UNKNOWN | 821 | 26% | +82.1 [+0.1, +160.7] | +82.1 [+0.1, +160.7] | +0.0 [+0.0, +0.0] | 50% | 17.5% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 251 | 8% | +154.2 [+25.8, +305.5] | +154.2 [+25.8, +305.5] | +0.0 [+0.0, +0.0] | 55% | 18.3% |
| BREAKOUT:CONFIRMED | 385 | 12% | +170.6 [+77.1, +262.4] | +170.6 [+77.1, +262.4] | +0.0 [+0.0, +0.0] | 57% | 14.0% |
| BREAKOUT:STALLED | 31 | 1% | -3.3 [-146.8, +144.7] | -3.3 [-146.8, +144.7] | +0.0 [+0.0, +0.0] | 45% | 12.9% |
| FAILED_BREAKOUT:FAILED | 338 | 11% | +78.9 [-15.6, +184.3] | +78.9 [-15.6, +184.3] | +0.0 [+0.0, +0.0] | 49% | 14.5% |
| BREAKDOWN:NEW | 815 | 26% | +138.6 [+45.5, +235.7] | +138.6 [+45.5, +235.7] | +0.0 [+0.0, +0.0] | 56% | 18.4% |
| BREAKDOWN:CONFIRMED | 306 | 10% | +62.1 [-133.7, +236.3] | +62.1 [-133.7, +236.3] | +0.0 [+0.0, +0.0] | 49% | 21.2% |
| BREAKDOWN:STALLED | 16 | 1% | +99.2 | +99.2 | +0.0 | 38% | 12.5% |
| FAILED_BREAKDOWN:FAILED | 113 | 4% | -53.1 [-182.3, +91.1] | -53.1 [-182.3, +91.1] | +0.0 [+0.0, +0.0] | 48% | 19.5% |
| (blank) | 913 | 29% | +85.1 [+27.0, +143.6] | +85.1 [+27.0, +143.6] | +0.0 [+0.0, +0.0] | 47% | 11.4% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 3,047 | 96% | +106.9 [+60.0, +152.6] | +106.9 [+60.0, +152.6] | +0.0 [+0.0, +0.0] | 52% | 15.4% |
| overextended | 114 | 4% | +181.9 [+13.7, +353.2] | +181.9 [+13.7, +353.2] | +0.0 [+0.0, +0.0] | 54% | 21.1% |
| extreme | 7 | 0% | -1447.2 | -1447.2 | +0.0 | 0% | 57.1% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 650 | 21% | +102.6 [+36.2, +165.9] | +102.6 [+36.2, +165.9] | +0.0 [+0.0, +0.0] | 50% | 10.9% |
| NORMAL | 1,741 | 55% | +70.5 [+10.8, +130.7] | +70.5 [+10.8, +130.7] | +0.0 [+0.0, +0.0] | 49% | 17.1% |
| ELEVATED | 440 | 14% | +169.9 [+80.5, +263.0] | +169.9 [+80.5, +263.0] | +0.0 [+0.0, +0.0] | 58% | 15.0% |
| EXTREME | 337 | 11% | +213.9 [+76.1, +340.8] | +213.9 [+76.1, +340.8] | +0.0 [+0.0, +0.0] | 61% | 18.1% |

**SDE10 at the pick (signed directional efficiency, 10 sessions)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NEG < -0.5 | 1,040 | 33% | +139.5 [+41.2, +237.6] | +139.5 [+41.2, +237.6] | +0.0 [+0.0, +0.0] | 55% | 18.8% |
| MID | 1,687 | 53% | +81.7 [+36.8, +127.6] | +81.7 [+36.8, +127.6] | +0.0 [+0.0, +0.0] | 50% | 13.2% |
| POS >= +0.5 | 441 | 14% | +120.9 [+9.7, +224.4] | +120.9 [+9.7, +224.4] | +0.0 [+0.0, +0.0] | 51% | 17.7% |

**RSJ10 at the pick (up minus down variance, 10 returns)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| falls < -0.5 | 1,181 | 37% | +110.7 [+17.0, +205.4] | +110.7 [+17.0, +205.4] | +0.0 [+0.0, +0.0] | 54% | 18.9% |
| MID | 1,246 | 39% | +76.2 [+26.0, +133.1] | +76.2 [+26.0, +133.1] | +0.0 [+0.0, +0.0] | 48% | 12.8% |
| rises >= +0.5 | 741 | 23% | +149.2 [+78.0, +225.5] | +149.2 [+78.0, +225.5] | +0.0 [+0.0, +0.0] | 53% | 15.4% |

**Lower-circuit close in the 3 sessions to the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 2,837 | 90% | +107.2 [+68.1, +150.7] | +107.2 [+68.1, +150.7] | +0.0 [+0.0, +0.0] | 51% | 14.6% |
| yes | 331 | 10% | +97.0 [-135.2, +291.0] | +97.0 [-135.2, +291.0] | +0.0 [+0.0, +0.0] | 56% | 24.5% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3% | 370 | 12% | -537.6 [-640.7, -435.9] | -537.6 [-640.7, -435.9] | +0.0 [+0.0, +0.0] | 21% | 49.2% |
| -3% .. -1% | 455 | 14% | -157.2 [-223.0, -91.9] | -157.2 [-223.0, -91.9] | +0.0 [+0.0, +0.0] | 31% | 26.6% |
| -1% .. +1% | 1,100 | 35% | +93.3 [+38.7, +149.3] | +93.3 [+38.7, +149.3] | +0.0 [+0.0, +0.0] | 49% | 10.9% |
| +1% .. +3% | 931 | 29% | +330.8 [+268.8, +400.2] | +330.8 [+268.8, +400.2] | +0.0 [+0.0, +0.0] | 67% | 5.9% |
| >= +3% | 312 | 10% | +628.6 [+478.1, +784.8] | +628.6 [+478.1, +784.8] | +0.0 [+0.0, +0.0] | 81% | 5.8% |


## Frozen setups (setuplab tags)

Tags TAGS_20261108_001 (setuplab v0.7), freeze sha256 483f1539324f3ae5, signal days ['2020-01-16', '2026-09-15']; they cover 4,159 of this run's picks. Columns in trades.csv: setups (e.g. S2@D3 = setup S2 entered on watch day 3), n_setups, su_<ID>_day, setups_tagged.

This strategy enters on its own rules: for it the tags are hindsight (a setup is known only on its own entry day) - describe trades with them, never pick trades by them.

## Calm / jumpy lanes and the entry tree (setuplab tree)

Tree run TREE_20261109_001 (setuplab v1.1), TREE.json sha256 5cd4571765c2de80, freeze 483f1539324f3ae5, history window ['2021-01-01', '2026-09-22'], RECONCILED with the declaration; it covers 4,159 of this run's picks. Lane = the pick's 14-session ATR / close against its year's cut-off (the 2/3 quantile of earlier years' picks): 2021 5.77%, 2022 5.64%, 2023 5.75%, 2024 5.35%, 2025 5.49%, 2026 5.52%. CALM = at or below, JUMPY = above; picks before the first cut-off year have no lane. The lane is known at the pick's close (a pre-pick breakdown); trades.csv also carries the tree's action on each rank 1-3 pick (tree_action, tree_how, tree_net, opened_up - hindsight: the tree decides at the open and on each setup's own day).

This strategy IS the tree: it buys where the tree bought (tree_how: 'open' = the D1 open, 'S2@D3' = setup S2's own day-3 open) and sells where the tree sold (the 5th close; N1 4 sessions after its entry); a pick the tree skips is not entered (0 bp). The comparison buys every pick at the D1 open. The money view uses tradelab's account (integer shares, its tie order: rank, then engine); setuplab's TREE.md is the reference for the tree's own book numbers. These years are the history the tree was declared on (descriptive); only the forward record judges it.

Paired picks by lane: strategy, tree and the difference (strategy - tree), bp, 95% block-bootstrap intervals over signal days. Descriptive: one lane 'BETTER' is a hypothesis.

| engine | lane | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|
| ENS | CALM | 2,561 | 2,561 | +75.6 [+29.7, +121.9] | +75.6 [+29.7, +121.9] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | 607 | 607 | +235.2 [+130.1, +345.3] | +235.2 [+130.1, +345.3] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |

## SDE at the pick (signed directional efficiency)

SDE_N = (close at the pick - close N sessions before) / the sum of the N absolute close-to-close moves to the pick: -1 = an orderly fall, +1 = an orderly rise; known at the pick's close (pre_sde3 / 5 / 10 / 20 in trades.csv, usable in filters). SDE10 known for 4,215 of 4,242 picks (NEG < -0.5 1,526, MID 2,160, POS >= +0.5 529); blank when the window is flat, has a missing bar or a close-to-close move above 45% (an unadjusted split or bonus).

Paired picks by SDE10 and lane: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Many groups: one 'BETTER' is a hypothesis to declare and test forward.

| engine | lane | SDE10 | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| ENS | CALM | NEG < -0.5 | 654 | 654 | +65.5 [-38.5, +172.7] | +65.5 [-38.5, +172.7] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | CALM | MID | 1,482 | 1,482 | +64.1 [+17.0, +111.9] | +64.1 [+17.0, +111.9] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | CALM | POS >= +0.5 | 425 | 425 | +131.0 [+22.9, +233.4] | +131.0 [+22.9, +233.4] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | NEG < -0.5 | 386 | 386 | +264.9 [+114.3, +416.1] | +264.9 [+114.3, +416.1] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | MID | 205 | 205 | +209.1 [+61.9, +347.7] | +209.1 [+61.9, +347.7] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | POS >= +0.5 | 16 | 16 | -148.0 | -148.0 | +0.0 | NO INTERVAL (fewer than 20 signal days) |

## Volatility x direction at the pick (voldir VD1)

RSJ10 known for 4,215 of 4,242 picks; a lower-circuit close in the 3 sessions to the pick on 545; day cross-section flags from voldir run VD_20261112_001 (daily_cuts sha256 74ff14ffd06a0d6d).
Where the paired picks sit: RSJ10 deciles 10/25/50/75/90% = -0.96 / -0.77 / -0.15 / +0.46 / +0.80.
Share of the paired picks 29.1% in the day's lowest RSJ tenth; 9.4% in its highest tenth; 36.3% in the top turnover third; 58.6% in the top ATR third; 14.0% in the top 20-day-return tenth; 15.2% on high market volatility days (a universe-wide rule needs room inside the picks: a share near 0 or 1 leaves nothing to separate).

Paired picks by the value at the pick: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Descriptive: a 'BETTER' here is a hypothesis.

| split | engine | group | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| RSJ10 at the pick (up minus down variance, 10 returns) | ENS | falls < -0.5 | 1,181 | 1,181 | +110.7 [+17.0, +205.4] | +110.7 [+17.0, +205.4] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | ENS | MID | 1,246 | 1,246 | +76.2 [+26.0, +133.1] | +76.2 [+26.0, +133.1] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | ENS | rises >= +0.5 | 741 | 741 | +149.2 [+78.0, +225.5] | +149.2 [+78.0, +225.5] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | ENS | no | 2,837 | 2,837 | +107.2 [+68.1, +150.7] | +107.2 [+68.1, +150.7] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | ENS | yes | 331 | 331 | +97.0 [-135.2, +291.0] | +97.0 [-135.2, +291.0] | +0.0 [+0.0, +0.0] | NOT SHOWN (interval spans 0) |
