"""strategies/voldir.py - voldir VD1, Stage 2 (setups add-on v1.5). Declared 12 Nov 2026 before any run
(sdelab\\VOLDIR_DECLARATION.json; 'python voldir.py check' confirms this file's sha256).

Every variant is the FROZEN entry tree (strategies\\tree.py: ranks 1-3 from 2021, Rs 5 L, 3 positions, 35 bp, honest
exits) with one change, compared with the frozen tree itself - once for engine D, once for ENS:

    B1        always    each position sized equity / 3 x pre_semivol_w (min(1.5, the engine's median downside
                        semideviation over the last 365 days / this pick's); at most 51% of equity)
    B2        always    a tree buy is not made when a close locked at the lower circuit falls on one of the 3 sessions
                        up to that buy's own signal close
    J_V1L ... only when voldir's Stage 1 says so (its REPORT.md lists the exact commands): the tree's empty branch -
    J_V6H_X1            a JUMPY tree pick whose values at the pick meet the surviving rule is bought at the D1 open
                        (sold at the 5th close; J_V6H_X0 at the 2nd)
    X_V2H ... X_V6L     only for a confirmed veto: a tree buy is not made when the veto holds at its signal close

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\voldir.py#B1 --compare strategies\\tree.py --voldir <VD run folder> --declare "voldir VD1 Stage 2 B1 D"

Decision (declared; per engine): B1 - the Calmar ratio difference against the frozen tree has a 95% interval above 0
and the worst drawdown is no deeper; every other - the daily-return difference has a 95% interval above 0, the CAGR is
higher and the worst drawdown no deeper. Then 'python voldir.py holm' Holm-corrects each engine's family (0.025,
one-sided). A PASS makes the change a forward candidate only: these are the years the tree was found on.
"""
import copy

_TREE = {
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": "2021-01-01"},
    "max_sessions": 9,
    "entries": [{"name": "tree", "size": 1.0, "tree": True}],
    "exits": [{"name": "tree", "type": "time", "tree": True}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "sizing": {"rule": "equal_slots", "slots": 3, "max_pct": 0.34},
    "portfolio": {"capital": 500000, "max_open": 3},
    "decision_rule": {"metric": "daily_diff_bp", "pass_if": "lower > 0", "money": "cagr_and_drawdown"},
}


def _v(name: str, description: str, entry: dict = None, sizing: dict = None, decision: dict = None) -> dict:
    s = copy.deepcopy(_TREE)
    s["name"], s["description"] = f"voldir_{name}", description
    if entry:
        s["entries"][0].update(entry)
    if sizing:
        s["sizing"] = sizing
    if decision:
        s["decision_rule"] = decision
    return s


_JUMPY_DIP = "calm == 0 and pre_sde10 < -0.5"
STRATEGIES = {
    "B1": _v("B1", "the frozen tree sized by inverse downside semideviation (cap 1.5x a slot)",
             sizing={"rule": "expression", "expression": "equity / 3 * pre_semivol_w", "max_pct": 0.51},
             decision={"metric": "calmar_diff", "pass_if": "lower > 0", "money": "drawdown"}),
    "B2": _v("B2", "the frozen tree without buys after a lower-circuit close in the 3 sessions to the buy's signal",
             entry={"veto_if": "pre_lock3 == 1"}),
    "J_V1L": _v("J_V1L", "frozen tree + jumpy picks in the day's lowest RSJ10 tenth bought at the D1 open",
                entry={"open_if": "calm == 0 and pre_rsj_lo == 1"}),
    "J_V1H": _v("J_V1H", "frozen tree + jumpy picks in the day's highest RSJ10 tenth bought at the D1 open",
                entry={"open_if": "calm == 0 and pre_rsj_hi == 1"}),
    "J_V2L": _v("J_V2L", "frozen tree + jumpy orderly falls on thin turnover bought at the D1 open",
                entry={"open_if": _JUMPY_DIP + " and pre_turn_lo == 1"}),
    "J_V3D": _v("J_V3D", "frozen tree + jumpy orderly falls that are a drift (no panic candle) bought at the D1 open",
                entry={"open_if": _JUMPY_DIP + " and pre_lds10 < 0.35 and pre_shock == 0"}),
    "J_V4F": _v("J_V4F", "frozen tree + jumpy orderly falls while high market volatility is falling, D1 open",
                entry={"open_if": _JUMPY_DIP + " and pre_mvol_high == 1 and pre_mvol_falling == 1"}),
    "J_V6H_X0": _v("J_V6H_X0", "frozen tree + jumpy 20-day winners on heavy turnover bought at the D1 open, 2nd close",
                   entry={"open_if": "calm == 0 and pre_atr_hi == 1 and pre_ret20_top == 1 and pre_turn_hi == 1",
                          "open_exit": 2}),
    "J_V6H_X1": _v("J_V6H_X1", "frozen tree + jumpy 20-day winners on heavy turnover bought at the D1 open, 5th close",
                   entry={"open_if": "calm == 0 and pre_atr_hi == 1 and pre_ret20_top == 1 and pre_turn_hi == 1"}),
    "X_V2H": _v("X_V2H", "the frozen tree without buys into an orderly fall on heavy turnover",
                entry={"veto_if": "pre_sde10 < -0.5 and pre_turn_hi == 1"}),
    "X_V3C": _v("X_V3C", "the frozen tree without buys into an orderly fall that had a panic candle",
                entry={"veto_if": "pre_sde10 < -0.5 and (pre_lds10 >= 0.35 or pre_shock == 1)"}),
    "X_V4R": _v("X_V4R", "the frozen tree without buys into an orderly fall while high market volatility rises",
                entry={"veto_if": "pre_sde10 < -0.5 and pre_mvol_high == 1 and pre_mvol_falling == 0"}),
    "X_V6L": _v("X_V6L", "the frozen tree without buys of jumpy 20-day winners on thin turnover",
                entry={"veto_if": "pre_atr_hi == 1 and pre_ret20_top == 1 and pre_turn_lo == 1"}),
}
