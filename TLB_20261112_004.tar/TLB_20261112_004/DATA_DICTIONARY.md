# Data dictionary - tradelab backtest TLB_20261112_004

Units: fraction = 0.012 means +1.2%; bp = basis points (100 bp = 1%); pts = difference of two returns, as a fraction. 'known' says WHEN a value is known:

- **id**: identifies the row
- **pick**: known at the pick day's close - a rule may use it
- **day**: known at that row's own close
- **after**: known only afterwards - explains, never a rule input
- **record**: pick_meta's recorded value (reconciliation)
- **info**: summary statistic

## backtest_trades

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | ENGINE-YYYYMMDD-RANK (the signal day) |
| engine | id | text | D or ENS |
| signal_day | id | date | the pick day = session 0 |
| symbol | id | text | NSE symbol |
| rank | pick | 1..10 | the engine's rank that day |
| strategy | id | text | the strategy |
| status | after | text | ok / not_entered (no entry fired: cash) / filtered (the picks filter skipped it: cash) / stuck / pending / no_data |
| note | after | text | simulation note |
| entered | after | bool | anything was bought |
| deployed | after | fraction | total bought / target |
| max_pos | after | fraction | largest position / target |
| first_entry | after | price | price of the first buy |
| avg_entry | after | price | average entry |
| exit_price | after | price | last sale price |
| exit_reason | after | text | the exit rule that sold last |
| entry_session | after | number | session of the first buy / last sale |
| exit_session | after | number | session of the first buy / last sale |
| entry_time | after | date-time | time of the first buy / last sale |
| exit_time | after | date-time | time of the first buy / last sale |
| bars_held | after | count | bars from the first buy to the last sale |
| gross | after | fraction | gross P&L / target |
| costs | after | fraction | costs / target |
| net | after | fraction | net P&L / target |
| net_bp | after | bp | net P&L / the trade's target size (an unfilled leg is cash) |
| net_deployed_bp | after | bp | net / deployed |
| win | after | bool | net > 0 |
| mfe | after | fraction | best high since the first buy / first entry - 1, while held |
| mae | after | fraction | worst low since the first buy / first entry - 1, while held |
| mfe_session | after | number | session of that high / low |
| mae_session | after | number | session of that high / low |
| locked_exit | after | bool | a sale was delayed by a lower-circuit lock |
| ambiguous_bars | after | count | bars where a stop and a target were both inside the bar |
| n_fills | after | count | number of fills |
| legs_filled | after | text | entry legs that filled |
| exits_used | after | text | exit rules that sold |
| net_bp_compare | after | bp | the comparison strategy's net on the same pick |
| status_compare | after | text | its status |
| diff_bp | after | bp | net_bp - net_bp_compare (paired picks only) |
| paired | after | bool | in the paired comparison |
| setups | after | text | the frozen entry setups (setuplab) that entered this pick, with the watch day, e.g. 'S2@D3 C1@D3'. A setup is known only on its own entry day: hindsight for any entry before it - describe trades with it, never choose them by it |
| n_setups | after | count | how many frozen setups entered this pick |
| su_S1_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| su_S2_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| su_S3_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| su_C1_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| su_C2_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| su_C3_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| su_N1_day | after | 1..5 | the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not |
| setups_tagged | info | bool | setuplab's tag run covers this pick (blank tags on a covered pick = no setup entered) |
| pre_sde3 | pick | -1..+1 | setups add-on v1.4: signed directional efficiency over the N sessions to the pick's close = (close - close N sessions before) / the sum of the N absolute close-to-close moves; -1 an orderly fall, +1 an orderly rise; blank: flat window, missing bar or a move above 45% |
| pre_sde5 | pick | -1..+1 | setups add-on v1.4: signed directional efficiency over the N sessions to the pick's close = (close - close N sessions before) / the sum of the N absolute close-to-close moves; -1 an orderly fall, +1 an orderly rise; blank: flat window, missing bar or a move above 45% |
| pre_sde10 | pick | -1..+1 | setups add-on v1.4: signed directional efficiency over the N sessions to the pick's close = (close - close N sessions before) / the sum of the N absolute close-to-close moves; -1 an orderly fall, +1 an orderly rise; blank: flat window, missing bar or a move above 45% |
| pre_sde20 | pick | -1..+1 | setups add-on v1.4: signed directional efficiency over the N sessions to the pick's close = (close - close N sessions before) / the sum of the N absolute close-to-close moves; -1 an orderly fall, +1 an orderly rise; blank: flat window, missing bar or a move above 45% |
| pre_rsj10 | pick | -1..+1 | setups add-on v1.5 (voldir VD1): (up-day minus down-day squared log returns) / their sum over the 10 returns to the pick's close; -1 = all variance from falls |
| pre_turn_rel | pick | ratio | v1.5: mean turnover (close x volume) of the 10 sessions to the pick / the median of the 120 sessions before them |
| pre_lds10 | pick | 0..1 | v1.5: largest-day share - the largest of the 10 absolute close-to-close moves to the pick / their sum |
| pre_shock | pick | flag | v1.5: 1 = a single close-to-close fall of 2 ATR14 or more among the 10 moves to the pick |
| pre_ret20 | pick | fraction | v1.5: close at the pick / close 20 sessions before - 1 |
| pre_atrp | pick | fraction | v1.5: ATR14 (simple mean of true ranges) / close at the pick |
| pre_lock3 | pick | flag | v1.5: 1 = a close locked at the lower circuit (production's rule) on one of the 3 sessions to the pick |
| pre_semivol20 | pick | fraction | v1.5: downside semideviation sqrt(2 x mean(r^2 on down days)) over the 20 returns to the pick |
| pre_rsj_lo | pick | flag | v1.5: 1 = in the day's universe tail (voldir's cuts): RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank without --voldir |
| pre_rsj_hi | pick | flag | v1.5: 1 = in the day's universe tail (voldir's cuts): RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank without --voldir |
| pre_turn_lo | pick | flag | v1.5: 1 = in the day's universe tail (voldir's cuts): RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank without --voldir |
| pre_turn_hi | pick | flag | v1.5: 1 = in the day's universe tail (voldir's cuts): RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank without --voldir |
| pre_atr_hi | pick | flag | v1.5: 1 = in the day's universe tail (voldir's cuts): RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank without --voldir |
| pre_ret20_top | pick | flag | v1.5: 1 = in the day's universe tail (voldir's cuts): RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank without --voldir |
| pre_mvol_high | pick | flag | v1.5: NIFTY50 GJR-GARCH volatility forecast at the pick >= its 80th percentile of the 252 sessions before / below its value 5 sessions before (voldir); blank without --voldir |
| pre_mvol_falling | pick | flag | v1.5: NIFTY50 GJR-GARCH volatility forecast at the pick >= its 80th percentile of the 252 sessions before / below its value 5 sessions before (voldir); blank without --voldir |
| pre_semivol_w | pick | ratio | v1.5: B1's size weight min(1.5, median pre_semivol20 of the engine's picks over the 365 days before / this pick's); 1 when unknown or fewer than 50 earlier picks |
| lane | pick | text | setuplab's entry tree: CALM = the pick's 14-session ATR / close at or below its year's cut-off, JUMPY = above; NO ATR / NO CUT-OFF (before the first cut-off year) otherwise - known at the pick's close |
| lane_atr14 | pick | fraction | the pick's 14-session ATR as a share of its close (setuplab's s_atr14) - sets the lane |
| lane_cutoff | pick | fraction | the year's calm / jumpy cut-off: the 2/3 quantile of earlier years' picks' ATR / close |
| calm | pick | flag | 1 = CALM, 0 = JUMPY, blank = no lane; a pick attribute a filter may read (picks.filter: 'calm == 1') |
| opened_up | after | bool | the D1 open was at or above the pick's close (the tree's D rule) - known only at the open |
| tree_action | after | text | what the entry tree did with the pick (ranks 1-3 from the first cut-off year): buy at the open, wait for a setup (-> S2@D3) or skip - decided at the open and on each setup's own day: hindsight for any entry before then; never choose trades by it |
| tree_how | after | text | where the tree bought: 'open' (the D1 open), 'S2@D3' (setup S2's own day-3 open); blank = skipped |
| tree_net | after | percent | net % after 0.35 pp of the tree's own trade on the pick (the D5 close for 'open'; the setup's primary exit for a setup buy) |
| tree_tagged | info | bool | setuplab's tree run covers this pick |
| pre_prev_date | pick | date | the session before the pick day |
| pre_nifty_ret | pick | fraction | index day return on the pick day |
| pre_mid_ret | pick | fraction | index day return on the pick day |
| pre_small_ret | pick | fraction | index day return on the pick day |
| pre_nifty_ret5 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_mid_ret5 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_small_ret5 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_nifty_ret20 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_mid_ret20 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_small_ret20 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_nifty_vs_ma50 | pick | fraction | index / its 50-session average - 1 on the pick day |
| pre_mid_vs_ma50 | pick | fraction | index / its 50-session average - 1 on the pick day |
| pre_small_vs_ma50 | pick | fraction | index / its 50-session average - 1 on the pick day |
| pre_nifty_minus_mid | pick | pts | NIFTY minus Midcap / Smallcap on the pick day |
| pre_nifty_minus_small | pick | pts | NIFTY minus Midcap / Smallcap on the pick day |
| pre_nifty_minus_mid_20 | pick | pts | NIFTY minus Midcap / Smallcap over the 20 sessions to the pick day |
| pre_nifty_minus_small_20 | pick | pts | NIFTY minus Midcap / Smallcap over the 20 sessions to the pick day |
| pre_ad_ratio | pick | 0..1 | breadth on the pick day: advancers / (advancers + decliners) |
| pre_ad_ratio_10 | pick | 0..1 | breadth, 10-session average, on the pick day |
| pre_ad_n | pick | count | stocks in the breadth count on the pick day |
| pre_vix | pick | level | VIX close on the pick day |
| pre_vix_chg_pct | pick | fraction | VIX day change on the pick day |
| pre_vix_chg5_pct | pick | fraction | VIX 5-session change to the pick day |
| pre_vix_pct250 | pick | 0..1 | VIX percentile within the last 250 sessions on the pick day |
| pre_env_direction | pick | code | environment direction on the pick day |
| pre_env_code | pick | 0..3 | 0 broad_bullish, 1 narrow_bullish, 2 mixed, 3 broad_bearish |
| pre_high_stress | pick | 0/1 | high-stress flag on the pick day (1 / 0 / blank = unknown) |
| pre_stress_reason | pick | text | which stress conditions fired on the pick day |
| pre_environment | pick | code | five-label view on the pick day (high_stress overrides the direction) |
| pre_missing | pick | text | core market inputs missing on the pick day |
| pre_prev_nifty_ret | pick | fraction | index day return on the session before the pick day |
| pre_prev_mid_ret | pick | fraction | index day return on the session before the pick day |
| pre_prev_small_ret | pick | fraction | index day return on the session before the pick day |
| pre_prev_ad_ratio | pick | 0..1 | breadth on the session before the pick day |
| pre_prev_vix_chg_pct | pick | fraction | VIX change on the session before the pick day |
| pre_prev_environment | pick | code | five-label environment the session before the pick day |
| pre_prev_high_stress | pick | 0/1 | high-stress flag the session before the pick day |
| pre_size_class | pick | text | large / mid / small from the AMFI list in force on the pick day; 'not in list' (the list does not name the stock) / 'no list' (no list in force: before the first, or the half-year's list is missing - an older list is never carried on) |
| pre_size_class_num | pick | 1..3 | 1 large, 2 mid, 3 small (blank when no AMFI class) |
| pre_amfi_rank | pick | rank | the stock's rank in that AMFI list (by average market cap) |
| pre_amfi_list | pick | text | the AMFI list in force on the pick day; '(via ISIN ...)' when the stock was found by its company's ISIN because that list used an older symbol (a rename) |
| pre_exposure_days | pick | count | valid daily returns in the 120-session sensitivity window |
| pre_beta_nifty | pick | number | beta of the stock's daily returns on the index's, 120 sessions to the pick day |
| pre_corr_nifty | pick | -1..1 | correlation of those daily returns with the index's |
| pre_beta_mid | pick | number | beta of the stock's daily returns on the index's, 120 sessions to the pick day |
| pre_corr_mid | pick | -1..1 | correlation of those daily returns with the index's |
| pre_beta_small | pick | number | beta of the stock's daily returns on the index's, 120 sessions to the pick day |
| pre_corr_small | pick | -1..1 | correlation of those daily returns with the index's |
| pre_home_index | pick | code | nifty / mid / small: the index the stock correlates with most |
| pre_beta_home | pick | number | beta on the home index |
| pre_corr_home | pick | -1..1 | correlation with the home index |
| pre_home_index_name | pick | text | NIFTY 50 / Midcap 150 / Smallcap 250 |
| pre_home_index_num | pick | 1..3 | 1 NIFTY 50, 2 Midcap 150, 3 Smallcap 250 |
| pre_stock_ret | pick | fraction | the stock's own return on the pick day |
| pre_prev_stock_ret | pick | fraction | the stock's return on its session before the pick day |
| pre_stock_minus_home | pick | pts | the stock's pick-day return minus its home index's |
| pre_context_complete | pick | 0/1 | 1 when every core pre-entry market value is present (indices, VIX, breadth, labels) |
| pre_state | pick | code | primary state at the pick day's close: S01 strong bullish continuation, S02 emerging bullish, S03 bullish consolidation, S06 bullish reversal attempt, S07 neutral range, S08 bearish continuation, S09 emerging bearish, S12 unstable / disorderly, UNKNOWN (evidence conflicts), INSUFFICIENT_DATA (< 60 sessions); blank when the stock has no bar on the signal day |
| pre_state_name | pick | text | the state in words |
| pre_state_num | pick | code | the state as a number (1, 2, 3, 6, 7, 8, 9, 12 = S01..S12; 0 UNKNOWN; -1 INSUFFICIENT_DATA) |
| pre_state_bullish | pick | 0/1 | 1 when the state is S01-S03 / S08-S09 |
| pre_state_bearish | pick | 0/1 | 1 when the state is S01-S03 / S08-S09 |
| pre_state_confidence | pick | text | HIGH / MEDIUM / LOW / UNKNOWN: evidence agreement, conflicts, persistence and data completeness - not a probability |
| pre_state_conf_num | pick | 0..3 | 3 HIGH, 2 MEDIUM, 1 LOW, 0 UNKNOWN |
| pre_state_phase | pick | text | EARLY (the first 5 sessions) / MATURE / DETERIORATING (a change pending, support under 50% or 2+ conflicting signs) |
| pre_state_phase_num | pick | 1..3 | 1 early, 2 mature, 3 deteriorating |
| pre_state_age | pick | sessions | sessions in the state, counted from the session the change began |
| pre_state_prev | pick | code | the state before the current one |
| pre_state_raw | pick | code | that session's own reading before confirmation (a change needs 2 sessions in a row) |
| pre_state_pending | pick | code | the new reading when a change is pending (blank when none) |
| pre_state_support | pick | 0..1 | share of the state's supporting conditions that hold (of those that can be evaluated) |
| pre_state_conflicts | pick | count | how many of the state's conflicting conditions hold |
| pre_state_event | pick | code | the event shown at the pick (last 10 sessions): BREAKOUT / FAILED_BREAKOUT / BREAKDOWN / FAILED_BREAKDOWN with NEW / CONFIRMED / STALLED / FAILED; blank = none |
| pre_state_event_num | pick | code | 0 none; 1 / 2 / 3 breakout new / confirmed / stalled; 4 failed breakout; 5 / 6 / 7 breakdown new / confirmed / stalled; 8 failed breakdown |
| pre_state_event_age | pick | sessions | sessions since that event began |
| pre_state_breakout_recent | pick | 0/1 | 1 when that event is the one shown (S04 / S11 / S10) |
| pre_state_failed_breakout | pick | 0/1 | 1 when that event is the one shown (S04 / S11 / S10) |
| pre_state_breakdown_recent | pick | 0/1 | 1 when that event is the one shown (S04 / S11 / S10) |
| pre_state_overextended | pick | 0..2 | S05 overextension: 0 no, 1 overextended, 2 extreme (a risk flag, not a sell signal) |
| pre_state_risks | pick | text | risk flags / notes, comma-separated codes (STATE_RULES.md) |
| pre_state_notes | pick | text | risk flags / notes, comma-separated codes (STATE_RULES.md) |
| pre_state_vol_regime | pick | text | the stock's volatility: COMPRESSED / NORMAL / ELEVATED / EXTREME |
| pre_state_vol_elevated | pick | 0/1 | 1 when that volatility is ELEVATED or EXTREME |
| pre_state_big_down | pick | 0/1 | 1 after a 2+ ATR down candle in the last 5 sessions |
| pre_state_bear_div | pick | 0/1 | 1 for a bearish RSI divergence candidate on confirmed swings |
| pre_state_ext20_atr | pick | ATR | close minus EMA20 / EMA50, in ATR (14, Wilder) |
| pre_state_ext50_atr | pick | ATR | close minus EMA20 / EMA50, in ATR (14, Wilder) |
| pre_state_ema20_slope_atr | pick | ATR | EMA20's change over 5 sessions / EMA50's over 10, in ATR |
| pre_state_ema50_slope_atr | pick | ATR | EMA20's change over 5 sessions / EMA50's over 10, in ATR |
| pre_state_eff20 | pick | -1..1 | 20-session efficiency: net move / sum of the absolute daily moves |
| pre_state_rsi14 | pick | 0..100 | RSI 14 (Wilder) |
| pre_state_macd_hist_atr | pick | ATR | MACD (12, 26, 9) histogram in ATR |
| pre_state_r20 | pick | fraction | the stock's 20 / 60-session return |
| pre_state_r60 | pick | fraction | the stock's 20 / 60-session return |
| pre_state_vol_ratio | pick | ratio | 10-session / 60-session realised volatility |
| pre_state_atr_rank | pick | 0..1 | ATR% percentile within its last 250 sessions (today included) |
| pre_state_rvol | pick | ratio | the day's volume / the median of the previous 50 sessions |
| pre_state_flow20 | pick | -1..1 | signed volume share over 20 sessions: OBV change / volume (a candidate, never proof of accumulation) |
| pre_state_cons_range_atr | pick | ATR | high-low range of the last 15 sessions, in ATR (consolidation width) |
| pre_state_pos20 | pick | ratio | close within the previous 20 sessions' high-low range (above 1 = above it) |
| post_hold_nifty_ret | after | fraction | index return from the first buy (session open or close) to the last sale |
| post_hold_mid_ret | after | fraction | index return from the first buy (session open or close) to the last sale |
| post_hold_small_ret | after | fraction | index return from the first buy (session open or close) to the last sale |
| post_hold_home_ret | after | fraction | the home index over the same span |

## fills

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | the trade |
| strategy | id | text | the strategy |
| symbol | id | text | NSE symbol |
| leg | after | text | entry leg / exit rule name |
| side | after | text | buy / sell |
| session | after | number | session |
| time | after | date-time | when |
| ts | after | date-time | sortable time |
| price | after | price | fill price after slippage |
| raw | after | price | market price before slippage |
| frac | after | fraction | buy: share of the target; sell: share of the position |
| notional | after | fraction | value bought / received (target = 1) |
| basis | after | fraction | entry value of the shares sold |
| cost | after | fraction | cost of the fill |
| kind | after | text | open / close / next_open / stop / limit / target / trail / locked_open |
| reason | after | text | why it filled |

## backtest_trade_days

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | the trade |
| strategy | id | text | the strategy name |
| engine | id | text | D or ENS |
| symbol | id | text | NSE symbol |
| rank | id | 1..10 | rank |
| session | id | number | 0 = pick day, 1 = entry day, 2, 3, ... (beyond 5 only while a lock delays the exit) |
| date | id | date | the session's date |
| open | day | price | the stock's official daily price |
| high | day | price | the stock's official daily price |
| low | day | price | the stock's official daily price |
| close | day | price | the stock's official daily price |
| volume | day | shares | the stock's daily volume |
| pos | day | 0..1 | fraction of the target held at the close |
| avg_entry | day | price | average entry price of what is held |
| mtm_net | day | fraction | the same as a fraction |
| realized | day | fraction | realized gross P&L so far / target |
| costs_paid | day | fraction | costs paid so far / target |
| buys | day | text | fills that session: leg@price |
| sells | day | text | fills that session: leg@price |
| day_net | day | fraction | the same as a fraction |
| mtm_net_bp | day | bp | P&L so far marked at this close |
| day_net_bp | day | bp | change in mtm_net_bp |

## portfolio_daily

| column | known | unit | meaning |
|---|---|---|---|
| date | id | date | session |
| equity | day | rupees | account value |
| cash | day | rupees | cash |
| invested | day | rupees | positions at the close |
| exposure | day | 0..1 | invested / equity |
| n_open | day | count | open positions |
| new_trades | day | count | positions opened |
| day_ret | day | fraction | equity / previous equity - 1 |
| drawdown | day | fraction | equity / running peak - 1 |
| day_ret_compare | day | number | the same for the comparison strategy |
| equity_compare | day | number | the same for the comparison strategy |

## portfolio_trades

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | the trade |
| engine | id | text | engine |
| symbol | id | text | symbol |
| signal_day | id | date | pick day |
| rank | id | number | rank |
| status | after | text | status |
| opened | after | bool | the account opened it |
| skip_reason | after | text | why not |
| target_rupees | after | rupees | target size |
| bought_rupees | after | rupees | bought |
| sold_rupees | after | rupees | received |
| costs_rupees | after | rupees | costs |
| open_value | after | rupees | value still open at the end |
| pnl_rupees | after | rupees | P&L |
| ret_on_target | after | fraction | P&L / target |
| legs_trimmed | after | count | legs trimmed by cash |
| legs_skipped | after | count | legs skipped by cash |
| still_open | after | bool | open at the end |

## context_breakdown

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS (or the strategy) |
| dimension | id | text | what the trades are grouped by |
| timing | id | text | before = known at the pick (could choose trades); after = known only afterwards (explains) |
| bucket | id | text | the group |
| trades | info | count | trades in the group |
| share | info | 0..1 | share of the engine's trades |
| days | info | count | signal days in the group |
| net_bp_mean | info | bp | average of that column in the group |
| net_bp_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| net_bp_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| net_bp_compare_mean | info | bp | average of that column in the group |
| net_bp_compare_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| net_bp_compare_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| diff_bp_mean | info | bp | average of that column in the group |
| diff_bp_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| diff_bp_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| win_rate | info | 0..1 | share of trades with net > 0 |
| severe_rate | info | 0..1 | share of trades with net <= -500 bp |

## money_by_environment

| column | known | unit | meaning |
|---|---|---|---|
| group | id | text | the engine (export) or the account (backtest) |
| environment | id | code | the environment known at the PREVIOUS session's close (what was known that morning) |
| days | info | count | sessions in that environment |
| share_of_days | info | 0..1 | their share |
| mean_day_bp | info | bp | mean day return of the account / book (bp of capital) |
| lo | info | bp | 95% block-bootstrap interval of mean_day_bp |
| hi | info | bp | 95% block-bootstrap interval of mean_day_bp |
| total_return | info | fraction | those days' returns added (book) or compounded (account) |
| max_drawdown_inside | info | fraction | worst drawdown with only that environment's days chained together |
| worst_day_bp | info | bp | worst / best day |
| best_day_bp | info | bp | worst / best day |
| avg_positions | info | count | positions held at the close: average / most at once (simultaneous exposure) |
| max_positions | info | count | positions held at the close: average / most at once (simultaneous exposure) |
| avg_exposure | info | 0..1 | invested / equity: average / highest |
| max_exposure | info | 0..1 | invested / equity: average / highest |
