# tradelab backtest - voldir_B2

tl_backtest v1.3.1 (tradelab v1.3.1), 2026-11-12T09:58:30. pick_meta run PM_20261017_001. Strategy strategies\voldir.py (sha d84b89bfaf7022d5, mode daily), compared with tree.
Tag: -. Declared rule: voldir VD1 Stage 2 B2 ENS.

## Verdict first

- Per pick slot: strategy **+93.1 [+55.3, +131.1] bp**, tree +106.2 [+57.1, +151.7] bp, difference **-13.0 [-35.3, +11.4] bp -> NOT SHOWN (interval spans 0)** (3,168 picks, 1,333 signal days).
- On the picks the strategy actually traded (2,818): difference +0.0 [+0.0, +0.0] bp.
- Picks the plan finished but the strategy could not trade (0, {}): the plan made n/a bp on them vs +106.2 [+57.1, +151.7] bp on the paired picks - a large gap means the pairing is not a fair sample.
- Entered 89.0% of picks; average size used 0.89 of the target; net on the money actually used +104.7 bp.

## Money view (one account, the strategy's sizing)

| | strategy | tree |
|---|---|---|
| CAGR | +85.06% | +72.11% |
| worst drawdown | -24.46% (2022-11-18 -> 2023-03-28) | -37.54% (2025-12-23 -> 2026-04-07) |
| Sharpe (daily x sqrt 252) | 1.90 | 1.66 |
| average exposure | 0.74 | 0.76 |
| trades opened | 828 | 837 |
| skipped (reason) | {'max_open': 1990} | {'max_open': 2331} |
| legs trimmed / skipped by cash | 248 / 0 | 264 / 0 |

Daily return difference: +2.79 [-5.63, +11.72] bp a day -> NOT SHOWN (interval spans 0) (one-sided p 0.2795).
Calmar ratio (CAGR over 252 sessions a year / |worst drawdown|, from the daily returns): strategy 3.550, tree 1.960, difference +1.590 [-0.997, +3.596] (paired block bootstrap; one-sided p 0.1570).

## Detail

- Win rate: strategy 45.4%, tree 51.7%.
- Legs filled (share of entered picks): {'tree': 1.0}.
- Exit reasons: {'tree': 2818}.
- Median MFE +4.27%, median MAE -3.17% (from the first buy, while held).
- Average exit session 5.05; locked exits 33; bars where a stop and a target were both inside the bar (settled by the 'worst' policy): 0.
- Left out of the pairing: strategy {'not_entered': 1074}, tree {'not_entered': 1074}.

### By year (bp per pick)

| year | picks | strategy | tree | difference |
|---|---|---|---|---|
| 2021 | 583 | +96.8 | +132.8 | -36.0 |
| 2022 | 547 | +117.7 | +143.2 | -25.5 |
| 2023 | 678 | +99.6 | +68.6 | +31.0 |
| 2024 | 484 | +72.3 | +142.8 | -70.4 |
| 2025 | 539 | +96.0 | +99.7 | -3.7 |
| 2026 | 337 | +59.0 | +33.2 | +25.8 |

### By engine and rank (bp per pick)

| engine | rank | picks | strategy | tree | difference |
|---|---|---|---|---|---|
| ENS | 1 | 1,007 | +127.0 | +155.3 | -28.3 |
| ENS | 2 | 1,070 | +102.5 | +101.6 | +0.9 |
| ENS | 3 | 1,091 | +52.6 | +65.2 | -12.7 |

## How much to trust this

- The tradelab ledger held 7 earlier backtests (4 distinct strategy files) before this one. With 20 variants tried on the same years, about one will look BETTER at the 95% level by luck alone.
- Same 2020-2026 history the engines were built and studied on. Treat any edge found here as a hypothesis: declare the rule (--declare, decision_rule) and judge it on the forward paper ledger.
- Costs: flat 35 bp round trip on entry notional (half at buy, half at sale); slippage 0.0 bp a side. Fills: next-bar opens, stop / limit levels from the previous bar, official open / close for 'at' orders, honest lower-circuit exits.
- Not modelled: upper-circuit buys that cannot fill, partial fills, market impact beyond the cost model.

## Decision rule: {'rule': {'metric': 'daily_diff_bp', 'pass_if': 'lower > 0', 'money': 'cagr_and_drawdown'}, 'value': -5.62738665984089, 'p_one_sided': 0.2795, 'metric_value': [2.7907006549322935, -5.62738665984089, 11.7193099158626], 'cagr': [0.8506070374316681, 0.7211082118875003], 'max_drawdown': [-0.24461056690888505, -0.37538360713711627], 'money_ok': True, 'verdict': 'FAIL'}

## Market context and stock state: where the strategy helps or hurts (v1.1, states v1.3.1)

### The money by environment (known at the previous close)

Each account's daily returns grouped by the environment known before the day began: mean day return (bp, 95% block-bootstrap interval), the worst drawdown inside that environment (its days chained), average exposure and the most positions open at once.

| account | environment | days | mean day bp | total | worst drawdown inside | worst day bp | avg exposure | max positions |
|---|---|---|---|---|---|---|---|---|
| voldir_B2 | broad_bullish | 426 (30%) | +29.36 [+7.30, +51.88] | +220.30% | -26.95% | -629 | 0.78 | 3 |
| voldir_B2 | narrow_bullish | 383 (27%) | +31.35 [+9.68, +54.53] | +201.86% | -19.07% | -825 | 0.74 | 3 |
| voldir_B2 | mixed | 194 (14%) | +14.92 [-11.62, +42.13] | +27.58% | -20.07% | -672 | 0.74 | 3 |
| voldir_B2 | broad_bearish | 224 (16%) | +9.70 [-23.87, +43.37] | +15.19% | -31.91% | -713 | 0.68 | 3 |
| voldir_B2 | high_stress | 191 (13%) | +48.86 [+12.24, +86.16] | +137.05% | -19.45% | -760 | 0.73 | 3 |
| tree | broad_bullish | 426 (30%) | +29.87 [+10.11, +49.07] | +228.05% | -21.42% | -624 | 0.78 | 3 |
| tree | narrow_bullish | 383 (27%) | +34.55 [+12.80, +57.36] | +242.24% | -20.70% | -649 | 0.76 | 3 |
| tree | mixed | 194 (14%) | +8.71 [-23.59, +42.64] | +11.83% | -28.77% | -672 | 0.75 | 3 |
| tree | broad_bearish | 224 (16%) | +15.24 [-23.39, +52.25] | +29.52% | -27.73% | -1065 | 0.71 | 3 |
| tree | high_stress | 191 (13%) | +20.37 [-24.64, +57.93] | +36.84% | -35.88% | -673 | 0.76 | 3 |

### The paired picks by the market and by the stock's state at the pick

'difference' = strategy - tree on the same picks, bp, 95% block-bootstrap intervals over signal days. Many groups are shown: a single group 'BETTER' is a hypothesis to declare and test forward, not a finding. Nothing here filters trades.

#### engine ENS

**environment at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,060 | 33% | +87.5 [+27.8, +145.9] | +81.7 [+19.7, +139.5] | +5.8 [-11.5, +30.1] | 48% | 13.0% |
| narrow_bullish | 887 | 28% | +72.0 [+21.5, +118.5] | +102.7 [+39.5, +161.3] | -30.7 [-54.7, -6.7] | 45% | 12.1% |
| mixed | 411 | 13% | +16.3 [-77.5, +106.3] | +25.0 [-87.9, +127.3] | -8.7 [-41.9, +27.6] | 40% | 14.8% |
| broad_bearish | 456 | 14% | +116.5 [+2.4, +235.8] | +124.1 [-61.3, +309.4] | -7.5 [-108.0, +106.3] | 42% | 15.1% |
| high_stress | 354 | 11% | +221.9 [+122.8, +324.2] | +259.1 [+117.9, +397.0] | -37.2 [-130.7, +52.6] | 48% | 10.5% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 2,814 | 89% | +76.9 [+41.2, +113.8] | +86.9 [+42.1, +129.7] | -10.0 [-29.9, +11.8] | 45% | 13.3% |
| yes | 354 | 11% | +221.9 [+122.8, +324.2] | +259.1 [+117.9, +397.0] | -37.2 [-130.7, +52.6] | 48% | 10.5% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| broad_bullish | 1,124 | 35% | +85.4 [+27.3, +144.1] | +81.6 [+21.0, +139.7] | +3.8 [-13.1, +27.7] | 48% | 13.2% |
| narrow_bullish | 990 | 31% | +89.8 [+32.7, +143.5] | +134.5 [+62.7, +204.4] | -44.7 [-75.4, -15.1] | 45% | 11.8% |
| mixed | 459 | 14% | +43.0 [-49.0, +135.4] | +58.1 [-50.7, +171.6] | -15.1 [-51.9, +23.8] | 42% | 14.2% |
| broad_bearish | 595 | 19% | +152.0 [+52.0, +253.9] | +142.5 [-23.7, +304.6] | +9.4 [-82.9, +116.9] | 43% | 13.8% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < 0.40 | 288 | 9% | +230.2 [+131.9, +335.9] | +256.5 [+101.2, +408.4] | -26.3 [-141.3, +124.4] | 49% | 11.5% |
| 0.40 - 0.50 | 1,493 | 47% | +71.3 [+19.6, +123.0] | +96.0 [+24.0, +162.3] | -24.7 [-57.1, +10.1] | 42% | 12.9% |
| 0.50 - 0.60 | 1,296 | 41% | +78.4 [+25.9, +131.9] | +76.0 [+20.4, +129.9] | +2.4 [-15.1, +24.7] | 48% | 13.5% |
| >= 0.60 | 91 | 3% | +226.8 [+46.9, +373.5] | +226.8 [+46.9, +373.5] | +0.0 [+0.0, +0.0] | 63% | 12.1% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -10% | 357 | 11% | +84.0 [+18.0, +154.4] | +114.1 [+25.1, +209.3] | -30.1 [-103.4, +35.5] | 45% | 14.3% |
| -10% .. 0% | 1,329 | 42% | +65.4 [+19.7, +110.6] | +74.9 [+21.7, +126.3] | -9.5 [-29.6, +12.2] | 46% | 13.4% |
| 0% .. +10% | 1,033 | 33% | +118.5 [+56.1, +179.4] | +123.0 [+51.4, +197.9] | -4.5 [-33.8, +24.9] | 45% | 12.6% |
| +10% .. +25% | 384 | 12% | +113.3 [+24.9, +194.8] | +151.0 [+42.5, +253.3] | -37.7 [-99.3, +26.5] | 45% | 12.0% |
| >= +25% | 65 | 2% | +187.5 [-82.5, +426.9] | +168.3 [-87.8, +365.3] | +19.2 [-123.7, +162.1] | 42% | 10.8% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 983 | 31% | +41.0 [-18.9, +101.8] | +46.5 [-22.5, +118.1] | -5.6 [-27.4, +18.5] | 43% | 13.4% |
| -3 .. 0 pts | 1,126 | 36% | +98.1 [+37.3, +158.5] | +108.0 [+43.1, +173.2] | -9.8 [-36.5, +17.4] | 48% | 12.3% |
| 0 .. +3 pts | 697 | 22% | +131.8 [+56.7, +206.2] | +127.0 [+19.1, +230.5] | +4.7 [-52.7, +74.0] | 47% | 13.3% |
| >= +3 pts (NIFTY ahead: narrow) | 362 | 11% | +144.7 [+44.1, +258.6] | +222.2 [+88.7, +362.6] | -77.6 [-151.2, -14.1] | 43% | 13.3% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no list | 3,168 | 100% | +93.1 [+55.3, +131.1] | +106.2 [+57.1, +151.7] | -13.0 [-35.3, +11.4] | 45% | 13.0% |

**home index** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NIFTY 50 | 234 | 7% | +74.3 [-50.4, +222.2] | +26.7 [-161.1, +199.1] | +47.6 [-29.8, +179.5] | 48% | 9.0% |
| Midcap 150 | 673 | 21% | +82.2 [+10.3, +153.2] | +87.5 [-21.5, +185.6] | -5.3 [-49.9, +57.1] | 49% | 11.6% |
| Smallcap 250 | 2,261 | 71% | +98.3 [+55.1, +144.0] | +119.9 [+68.3, +171.5] | -21.6 [-44.1, +0.3] | 44% | 13.8% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 458 | 14% | +128.8 [+42.2, +212.9] | +124.0 [+37.2, +209.8] | +4.9 [-34.7, +58.0] | 51% | 14.2% |
| S02 | 188 | 6% | +100.5 [-42.0, +247.6] | +111.3 [-38.1, +264.4] | -10.8 [-65.8, +26.7] | 46% | 15.4% |
| S03 | 518 | 16% | +45.3 [-14.1, +104.0] | +42.1 [-18.6, +100.6] | +3.2 [+0.0, +10.1] | 46% | 11.4% |
| S06 | 86 | 3% | +279.2 [+75.1, +490.3] | +348.8 [+95.5, +605.7] | -69.6 [-155.7, +13.2] | 49% | 14.0% |
| S07 | 137 | 4% | +21.8 [-54.6, +100.5] | +9.2 [-64.6, +81.8] | +12.6 [-2.9, +32.4] | 42% | 5.8% |
| S08 | 314 | 10% | +152.9 [+55.2, +255.5] | +182.1 [+57.3, +305.7] | -29.2 [-88.3, +32.8] | 48% | 13.1% |
| S09 | 646 | 20% | +109.0 [+35.6, +184.0] | +125.3 [+3.8, +238.0] | -16.4 [-86.0, +64.4] | 42% | 11.3% |
| UNKNOWN | 821 | 26% | +58.7 [-11.1, +127.9] | +82.1 [+0.1, +160.7] | -23.4 [-64.7, +23.6] | 43% | 15.2% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 797 | 25% | +84.3 [+31.1, +136.9] | +99.0 [+34.8, +160.9] | -14.6 [-47.1, +19.4] | 47% | 12.5% |
| MATURE | 1,167 | 37% | +111.1 [+63.1, +166.0] | +111.1 [+50.3, +175.2] | -0.0 [-35.0, +38.5] | 46% | 12.0% |
| DETERIORATING | 383 | 12% | +130.4 [+59.7, +205.9] | +157.7 [+74.5, +241.6] | -27.3 [-60.9, +1.3] | 47% | 12.3% |
| (blank) | 821 | 26% | +58.7 [-11.1, +127.9] | +82.1 [+0.1, +160.7] | -23.4 [-64.7, +23.6] | 43% | 15.2% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| HIGH | 1,076 | 34% | +105.2 [+56.2, +159.9] | +109.9 [+38.2, +181.3] | -4.8 [-43.1, +34.8] | 45% | 11.7% |
| MEDIUM | 888 | 28% | +94.2 [+40.8, +150.9] | +101.6 [+43.6, +162.9] | -7.4 [-33.0, +18.6] | 47% | 12.8% |
| LOW | 383 | 12% | +130.4 [+59.7, +205.9] | +157.7 [+74.5, +241.6] | -27.3 [-60.9, +1.3] | 47% | 12.3% |
| UNKNOWN | 821 | 26% | +58.7 [-11.1, +127.9] | +82.1 [+0.1, +160.7] | -23.4 [-64.7, +23.6] | 43% | 15.2% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 251 | 8% | +151.5 [+26.4, +300.1] | +154.2 [+25.8, +305.5] | -2.8 [-13.9, +5.1] | 54% | 18.3% |
| BREAKOUT:CONFIRMED | 385 | 12% | +152.4 [+73.8, +228.3] | +170.6 [+77.1, +262.4] | -18.2 [-67.2, +43.3] | 51% | 11.7% |
| BREAKOUT:STALLED | 31 | 1% | -98.9 [-191.7, -1.5] | -3.3 [-146.8, +144.7] | -95.7 [-243.6, +0.0] | 39% | 12.9% |
| FAILED_BREAKOUT:FAILED | 338 | 11% | +65.4 [-26.5, +169.5] | +78.9 [-15.6, +184.3] | -13.5 [-37.7, +9.7] | 46% | 13.9% |
| BREAKDOWN:NEW | 815 | 26% | +102.5 [+33.4, +177.4] | +138.6 [+45.5, +235.7] | -36.2 [-84.7, +13.0] | 43% | 14.0% |
| BREAKDOWN:CONFIRMED | 306 | 10% | +100.8 [-8.6, +214.9] | +62.1 [-133.7, +236.3] | +38.6 [-80.8, +183.3] | 40% | 12.4% |
| BREAKDOWN:STALLED | 16 | 1% | +182.1 | +99.2 | +82.8 | 38% | 6.2% |
| FAILED_BREAKDOWN:FAILED | 113 | 4% | -75.0 [-190.3, +57.8] | -53.1 [-182.3, +91.1] | -21.9 [-80.8, +15.2] | 46% | 18.6% |
| (blank) | 913 | 29% | +77.2 [+17.6, +133.3] | +85.1 [+27.0, +143.6] | -8.0 [-23.0, +6.3] | 44% | 10.5% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 3,047 | 96% | +90.6 [+53.5, +127.0] | +106.9 [+60.0, +152.6] | -16.3 [-39.2, +7.7] | 45% | 12.8% |
| overextended | 114 | 4% | +193.9 [+48.3, +345.5] | +181.9 [+13.7, +353.2] | +12.0 [-39.5, +62.2] | 53% | 18.4% |
| extreme | 7 | 0% | -436.0 | -1447.2 | +1011.1 | 0% | 28.6% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 650 | 21% | +100.5 [+34.8, +164.0] | +102.6 [+36.2, +165.9] | -2.1 [-9.6, +3.5] | 49% | 10.5% |
| NORMAL | 1,741 | 55% | +62.8 [+19.8, +109.4] | +70.5 [+10.8, +130.7] | -7.7 [-37.1, +25.2] | 43% | 14.8% |
| ELEVATED | 440 | 14% | +116.7 [+44.0, +190.2] | +169.9 [+80.5, +263.0] | -53.2 [-105.4, -4.5] | 49% | 12.3% |
| EXTREME | 337 | 11% | +204.9 [+110.2, +299.3] | +213.9 [+76.1, +340.8] | -9.0 [-103.9, +88.8] | 44% | 9.5% |

**SDE10 at the pick (signed directional efficiency, 10 sessions)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| NEG < -0.5 | 1,040 | 33% | +109.9 [+42.6, +180.9] | +139.5 [+41.2, +237.6] | -29.5 [-80.6, +29.2] | 43% | 13.6% |
| MID | 1,687 | 53% | +70.5 [+28.8, +113.6] | +81.7 [+36.8, +127.6] | -11.2 [-31.0, +8.3] | 46% | 11.9% |
| POS >= +0.5 | 441 | 14% | +139.7 [+33.3, +244.6] | +120.9 [+9.7, +224.4] | +18.8 [-10.6, +48.6] | 50% | 15.9% |

**RSJ10 at the pick (up minus down variance, 10 returns)** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| falls < -0.5 | 1,181 | 37% | +90.0 [+25.3, +158.8] | +110.7 [+17.0, +205.4] | -20.7 [-70.6, +34.1] | 43% | 13.6% |
| MID | 1,246 | 39% | +55.3 [+8.2, +105.9] | +76.2 [+26.0, +133.1] | -20.9 [-42.7, -0.1] | 44% | 11.6% |
| rises >= +0.5 | 741 | 23% | +161.5 [+89.7, +241.4] | +149.2 [+78.0, +225.5] | +12.3 [-3.7, +30.9] | 52% | 14.3% |

**Lower-circuit close in the 3 sessions to the pick** - known BEFORE entry

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| no | 2,837 | 90% | +103.8 [+65.2, +146.1] | +107.2 [+68.1, +150.7] | -3.4 [-9.9, +1.8] | 50% | 14.4% |
| yes | 331 | 10% | +1.7 [-12.6, +17.2] | +97.0 [-135.2, +291.0] | -95.3 [-292.9, +132.7] | 2% | 0.9% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | strategy bp | tree bp | difference bp | win | severe |
|---|---|---|---|---|---|---|---|
| < -3% | 315 | 10% | -465.8 [-557.3, -368.6] | -465.8 [-557.3, -368.6] | +0.0 [+0.0, +0.0] | 22% | 47.6% |
| -3% .. -1% | 404 | 13% | -167.4 [-236.4, -96.5] | -167.4 [-236.4, -96.5] | +0.0 [+0.0, +0.0] | 30% | 25.7% |
| -1% .. +1% | 1,006 | 32% | +83.4 [+33.3, +132.4] | +83.4 [+33.3, +132.4] | +0.0 [+0.0, +0.0] | 48% | 10.9% |
| +1% .. +3% | 845 | 27% | +315.9 [+252.2, +393.5] | +315.9 [+252.2, +393.5] | +0.0 [+0.0, +0.0] | 67% | 5.0% |
| >= +3% | 248 | 8% | +638.9 [+475.3, +807.7] | +638.9 [+475.3, +807.7] | +0.0 [+0.0, +0.0] | 83% | 2.4% |
| (blank) | 350 | 11% | +0.0 [+0.0, +0.0] | +118.1 [-112.1, +320.2] | -118.1 [-320.2, +112.1] | 0% | 0.0% |


## Frozen setups (setuplab tags)

Tags TAGS_20261108_001 (setuplab v0.7), freeze sha256 483f1539324f3ae5, signal days ['2020-01-16', '2026-09-15']; they cover 4,159 of this run's picks. Columns in trades.csv: setups (e.g. S2@D3 = setup S2 entered on watch day 3), n_setups, su_<ID>_day, setups_tagged.

This strategy enters on its own rules: for it the tags are hindsight (a setup is known only on its own entry day) - describe trades with them, never pick trades by them.

## Calm / jumpy lanes and the entry tree (setuplab tree)

Tree run TREE_20261109_001 (setuplab v1.1), TREE.json sha256 5cd4571765c2de80, freeze 483f1539324f3ae5, history window ['2021-01-01', '2026-09-22'], RECONCILED with the declaration; it covers 4,159 of this run's picks. Lane = the pick's 14-session ATR / close against its year's cut-off (the 2/3 quantile of earlier years' picks): 2021 5.77%, 2022 5.64%, 2023 5.75%, 2024 5.35%, 2025 5.49%, 2026 5.52%. CALM = at or below, JUMPY = above; picks before the first cut-off year have no lane. The lane is known at the pick's close (a pre-pick breakdown); trades.csv also carries the tree's action on each rank 1-3 pick (tree_action, tree_how, tree_net, opened_up - hindsight: the tree decides at the open and on each setup's own day).

This strategy IS the tree: it buys where the tree bought (tree_how: 'open' = the D1 open, 'S2@D3' = setup S2's own day-3 open) and sells where the tree sold (the 5th close; N1 4 sessions after its entry); a pick the tree skips is not entered (0 bp). The comparison buys every pick at the D1 open. The money view uses tradelab's account (integer shares, its tie order: rank, then engine); setuplab's TREE.md is the reference for the tree's own book numbers. These years are the history the tree was declared on (descriptive); only the forward record judges it.

Paired picks by lane: strategy, tree and the difference (strategy - tree), bp, 95% block-bootstrap intervals over signal days. Descriptive: one lane 'BETTER' is a hypothesis.

| engine | lane | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|
| ENS | CALM | 2,561 | 2,430 | +77.5 [+36.8, +119.3] | +75.6 [+29.7, +121.9] | +2.0 [-13.7, +22.7] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | 607 | 388 | +158.8 [+94.2, +230.8] | +235.2 [+130.1, +345.3] | -76.4 [-153.2, +6.0] | NOT SHOWN (interval spans 0) |

## SDE at the pick (signed directional efficiency)

SDE_N = (close at the pick - close N sessions before) / the sum of the N absolute close-to-close moves to the pick: -1 = an orderly fall, +1 = an orderly rise; known at the pick's close (pre_sde3 / 5 / 10 / 20 in trades.csv, usable in filters). SDE10 known for 4,215 of 4,242 picks (NEG < -0.5 1,526, MID 2,160, POS >= +0.5 529); blank when the window is flat, has a missing bar or a close-to-close move above 45% (an unadjusted split or bonus).

Paired picks by SDE10 and lane: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Many groups: one 'BETTER' is a hypothesis to declare and test forward.

| engine | lane | SDE10 | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| ENS | CALM | NEG < -0.5 | 654 | 580 | +69.0 [-15.0, +154.6] | +65.5 [-38.5, +172.7] | +3.6 [-39.7, +63.7] | NOT SHOWN (interval spans 0) |
| ENS | CALM | MID | 1,482 | 1,436 | +60.7 [+15.5, +105.7] | +64.1 [+17.0, +111.9] | -3.4 [-16.0, +12.5] | NOT SHOWN (interval spans 0) |
| ENS | CALM | POS >= +0.5 | 425 | 414 | +149.3 [+40.4, +252.9] | +131.0 [+22.9, +233.4] | +18.2 [-7.8, +48.3] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | NEG < -0.5 | 386 | 236 | +179.3 [+95.1, +272.7] | +264.9 [+114.3, +416.1] | -85.6 [-192.5, +30.5] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | MID | 205 | 140 | +141.5 [+62.8, +222.7] | +209.1 [+61.9, +347.7] | -67.7 [-171.1, +47.3] | NOT SHOWN (interval spans 0) |
| ENS | JUMPY | POS >= +0.5 | 16 | 12 | -113.9 | -148.0 | +34.1 | NO INTERVAL (fewer than 20 signal days) |

## Volatility x direction at the pick (voldir VD1)

RSJ10 known for 4,215 of 4,242 picks; a lower-circuit close in the 3 sessions to the pick on 545; day cross-section flags from voldir run VD_20261112_001 (daily_cuts sha256 74ff14ffd06a0d6d).
Where the paired picks sit: RSJ10 deciles 10/25/50/75/90% = -0.96 / -0.77 / -0.15 / +0.46 / +0.80.
Share of the paired picks 29.1% in the day's lowest RSJ tenth; 9.4% in its highest tenth; 36.3% in the top turnover third; 58.6% in the top ATR third; 14.0% in the top 20-day-return tenth; 15.2% on high market volatility days (a universe-wide rule needs room inside the picks: a share near 0 or 1 leaves nothing to separate).

This strategy's tree skips a buy when `pre_lock3 == 1` holds at that buy's own signal close (the close before the buy).

Paired picks by the value at the pick: strategy, tree and the difference, bp, 95% block-bootstrap intervals over signal days. Descriptive: a 'BETTER' here is a hypothesis.

| split | engine | group | picks | entered | strategy bp | tree bp | difference bp | verdict |
|---|---|---|---|---|---|---|---|---|
| RSJ10 at the pick (up minus down variance, 10 returns) | ENS | falls < -0.5 | 1,181 | 942 | +90.0 [+25.3, +158.8] | +110.7 [+17.0, +205.4] | -20.7 [-70.6, +34.1] | NOT SHOWN (interval spans 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | ENS | MID | 1,246 | 1,160 | +55.3 [+8.2, +105.9] | +76.2 [+26.0, +133.1] | -20.9 [-42.7, -0.1] | WORSE (interval below 0) |
| RSJ10 at the pick (up minus down variance, 10 returns) | ENS | rises >= +0.5 | 741 | 716 | +161.5 [+89.7, +241.4] | +149.2 [+78.0, +225.5] | +12.3 [-3.7, +30.9] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | ENS | no | 2,837 | 2,803 | +103.8 [+65.2, +146.1] | +107.2 [+68.1, +150.7] | -3.4 [-9.9, +1.8] | NOT SHOWN (interval spans 0) |
| Lower-circuit close in the 3 sessions to the pick | ENS | yes | 331 | 15 | +1.7 [-12.6, +17.2] | +97.0 [-135.2, +291.0] | -95.3 [-292.9, +132.7] | NOT SHOWN (interval spans 0) |
