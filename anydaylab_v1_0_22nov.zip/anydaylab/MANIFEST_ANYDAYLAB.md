# MANIFEST - anydaylab v1.0 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\anydaylab` (a NEW research folder beside `setuplab` and `soullab`).
Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\anydaylab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `anydaylab.py` | 3573bf421a8c1471 | 64269 |
| `ANYDAY_DECLARATION.json` | 6ae9ff80dc947ce2 | 9194 |
| `README_ANYDAYLAB.md` | b8440ec433cfa443 | 7607 |
| `tests\test_anydaylab.py` | 6edd0c0ac0fc6243 | 25558 |
| `MANIFEST_ANYDAYLAB.md` | this file | - |

Needs, read only, as sibling folders: `setuplab` v1.1 (setuplab.py sha16 9979d418aecec6de, FROZEN_SETUPS.json and TREE.json beside
it) and `soullab` v1.0 (soullab.py sha16 aaf5fa1742638561).

Declaration: `ANYDAY_DECLARATION.json`, internal sha256 45d6d5e83839ee74... - checked at every start; an edited file is refused.

## Verified (synthetic data, pandas 3.0.5 and pandas 2.3.3): `31 checks, 0 failed` / `VERIFIED (anydaylab v1.0)`
- By hand:
  - the search's day masks give setuplab's own trigger fills;
  - the twins match the cache's closes;
  - weekly inputs are left out (by name, and a weekly value hidden under another name);
  - WEEKLY is the earliest S1-C3 fill;
  - the twin swap changes only the weekly condition;
  - the halves follow the declared hash;
  - the tree replay equals setuplab's tree_history_picks / tree_history;
  - the judge's difference and p;
  - the verdict's thresholds;
  - ETFs are out.
- Planted world: the planted any-day pair is found and BETTER on the hidden half, both its conditions add, the judged
  setups are not versions of each other, S1's tw5 twin is BETTER, and the FOUND tree beats FROZEN.
- Absent world: nothing BETTER.
- Weekly world (only Tuesday entries pay): no twin and no found setup BETTER.
- Refusals: check-only writes nothing; an output inside the cache, an edited declaration and a panel without
  w_ret_13w are all refused.
- Mutation test: 11 of 11 planted bugs caught:
  - judged on the searched half;
  - no correction for the number judged;
  - a look-ahead twin;
  - weekday-bound inputs kept (the constant, and the exclusion itself);
  - WEEKLY taking the latest fill;
  - masks in the wrong day order;
  - a tie going to the later setup;
  - p on the wrong side;
  - BETTER without the threshold;
  - the twin swapping the wrong condition.
- Scale run: 160 stocks, 35,440 picks, 159 inputs, 652 conditions finished in 1.5 minutes.
