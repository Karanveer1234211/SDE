# anydaylab v1.0 - setups for any weekday, judged against the tree's Tuesday setups

Your ask (22 Nov 2026, 00:21): *"Lets go back to tree. Non Tuesday(weekly) setups which are better than weekly
setups. Find. Non-negotiable."*

anydaylab sits beside setuplab and soullab (`PyCharmMiscProject\anydaylab`) and uses their tested code (read only).
- **What it reads:** production, the watchlist, the panel, Soul and the daily cache, all read only.
- **Where it writes:** only under `C:\QuantData\anydaylab`.
- **What it does not change:** the frozen setups, the tree, the paper test and production.
- **Its rules:** `ANYDAY_DECLARATION.json`, written before any run and sha256-checked. An edited file is refused.

## Why the weekly setups only buy on Tuesdays

S1, S2, S3, C1, C2 and C3 all need **"w_ret_13w fell"**.
- **What that value is:** the stock's 13-week return, worked out once a week from Friday's close.
- **Where it changes:** the panel changes it only on the week's first session.
- **What follows:** the setups read it at the next open, so they can only buy at a **Tuesday open**.

A pick signalled on a Wednesday waits until the next Tuesday (about D4). It is skipped if the conditions don't hold that
day. N1 has no weekly condition.

## What it does, in plain words

**The bar: WEEKLY.**
- **What it is:** the weekly setups as the tree uses them. Each pick takes its earliest S1–C3 fill.
- **How a candidate is measured:** its net per trade, on the same picks and at the same exit as WEEKLY.
- **The picks:** D and ENS, every rank, with ETFs left out (the tree skips them). A stock picked twice on a day counts once.

**Part A: the twins (declared, nothing searched).** Each weekly setup keeps its other conditions, and its "bad
completed week" is swapped for a daily rolling version, worked out at every close from the stock's own daily bars in
the cache:
- **tw13:** the 13-week return (close vs 65 sessions back) is lower than it was 5 sessions ago. This is the weekly
  condition's own meaning, available on any day.
- **tw5:** the last 5 sessions fell.

That gives 12 twins, plus two "lanes" (each pick's earliest twin fill). All are judged on every pick against WEEKLY.

**Part B: the open search.**
- **The conditions:**
  - every input of engine D that isn't weekly, every Soul value and both twins: rose or fell at the close before the
    entry, or sits in its low or high third;
  - price conditions: dips under the D1 open in % and in ATR, gap down or gap up, the previous close, and a red or
    green previous candle.
- **The rules:** 1 to 3 conditions each. A rule buys at the first open (D1–D5, any weekday) where all its conditions
  hold, which is the frozen setups' own rule. Each condition must earn its place.
- **How the stocks are split:** the search sees only **half A** (a fixed hash of the symbol).
- **How a rule qualifies on half A:** 25+ trades a year, net per trade above 0 (95%), above WEEKLY's net, and at most 2
  losing years.
- **The judge:** the best 5 per exit (the D5 close, or 4 sessions after entry) are checked **once on half B**, against
  WEEKLY on half B's picks. The search never saw half B.
- **Versions are skipped:** a setup that shares two of three conditions' families with one already kept doesn't take
  a second judge slot.
- **Each condition is checked again on half B.** The report names any condition that adds nothing there; the setup
  without it is the cleaner candidate.

**BETTER** means the setup's net per trade minus WEEKLY's has a one-sided p at most 0.05 / K, where K is the number of
setups judged in that part. This correction stops a lucky setup out of thousands from passing. **TIE** means no clear
difference either way. **WORSE** means the 95% interval is below 0.

**Part C: money in the tree.** These are TREE.json's own books: ranks 1-3, D and ENS, Rs 5 L, 3 positions, from 2021.
- **FROZEN:** the tree as frozen. It must reproduce TREE.json's history, and the report says whether it does.
- **TWINS-13 and TWINS-5:** the six weekly setups replaced by their twins.
- **FOUND:** the weekly six replaced by Part B's BETTER setups.
- **FOUND+WEEKLY:** the frozen seven and the found ones together.

For each tree you get the yearly return, the worst fall, trades a week, and the daily difference against FROZEN.

**Example:**
- **The twin of S2:** buys a pick at the first open (D1–D5, any weekday) where minus-DI's 5-day change rose, the open
  gapped down, and the stock's 13-week return is lower than 5 sessions ago. That's S2's recipe without the Tuesday.
- **How it's judged:** suppose WEEKLY makes +1.40 a trade and the twin makes +1.90 with three times the trades. The twin
  is BETTER only if that +0.50 clears the corrected bar. Either way, Part C shows what it does to the tree's money.

## Install and run

Copy the `anydaylab` folder to `C:\Users\karanvsi\PyCharmMiscProject\anydaylab`, beside `setuplab` and `soullab`. Then
in `cmd`:

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\anydaylab
python tests\test_anydaylab.py
```

It must end `31 checks, 0 failed` / `VERIFIED (anydaylab v1.0)`. That takes about 1-3 minutes on synthetic data only.

```
python anydaylab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\anydaylab --soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet --check-only
```

This takes a few minutes and ends `CHECK OK`. It prints:
- the picks;
- how much of the twins the cache gives;
- whether the frozen setups replay FINAL_001's numbers;
- whether the frozen tree reproduces TREE.json's history;
- the time estimate.

Then the real run, the same without `--check-only`:

```
python anydaylab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\anydaylab --soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet
```

- **When it ends:** it prints `ANYDAY WRITTEN C:\QuantData\anydaylab\ANYDAY_<date>_<nnn>`, then how many twins and
  found setups are BETTER than WEEKLY.
- **Running beside stratlab:** it can run in a second cmd window while stratlab runs.

## What you get (`C:\QuantData\anydaylab\ANYDAY_<date>_<nnn>\`)

- **`ANYDAY.md` - read this first.** It contains, in order:
  - the verdict;
  - the bar (WEEKLY and each frozen setup);
  - Part A's twins;
  - Part B's judged setups, with their half A and half B numbers and how often they still buy on a Tuesday;
  - Part C's money table;
  - the checks.
- `twins.csv`, `found_d5.csv`, `found_fresh.csv`: every finalist, with its judged numbers where judged.
- `ANYDAY_CANDIDATES.json`: every twin and judged setup in setuplab's own condition format, ready for a freeze. It is
  hash-checked.
- `money.csv`, `weekly_bar.csv`, `frozen_vs_final_001.csv`, `conditions.csv`, `excluded.csv`, `DECLARATION.json`,
  `RUN.json`, `outputs.sha256`.
- A start and an end line in `C:\QuantData\anydaylab\anydaylab_ledger.jsonl`.

Send me `ANYDAY.md`.

## Limits

- **Every year here has been seen before.**
  - **The weekly setups:** chosen on 2020-2026 and every stock, so their half-B numbers are not new. That favours
    WEEKLY.
  - **The twins:** pre-declared, but judged on the same history.
  - **Part C:** descriptive.
  - **What counts:** a BETTER setup goes to a new freeze with its own date, and the forward paper ledger judges it
    beside the frozen tree.
- **Where the twins come from:** the cache's daily closes, as stored. A stock with no cache file has no twin.
- **What the search doesn't do:** profit targets, brackets and day-of-week conditions are not searched.
