"""
tests for anydaylab v1.0 - synthetic worlds only; nothing real is read, nothing outside a temporary folder is written.

    python tests\\test_anydaylab.py          (from the anydaylab folder, in tradelab's env)

Ends with  VERIFIED (anydaylab v1.0)  or  FAILED.
  u1  the search's day masks = setuplab's own trigger (the first fill) for random rules of 1-3 conditions
  u2  the twins = the stock's own daily closes in the cache, by hand (13-week return vs 5 sessions earlier; 5 sessions)
  u3  weekly inputs are left out: w_ret_13w by name, a weekly value with another name because its changes all fall on
      Mondays; daily inputs are kept
  u4  WEEKLY = each pick's earliest S1-C3 fill, by a plain loop; its net = the exit by hand
  u5  a twin = its weekly original with only the weekly condition swapped
  u6  the halves = sha256('anydaylab-v1|SYMBOL') parity
  u7  the tree replay (any setups) = setuplab's own tree_history_picks / tree_history on the frozen setups
  u8  a judge's difference = the plain difference of the two means; p from the resamples' standard deviation
  u9  the verdict: BETTER needs p <= 0.05 / K and the interval above 0; WORSE = the interval below 0; else TIE
  u10 ETFs out of the searched / judged picks (the tree skips them); one row per stock and signal day
  w1  PLANTED world (a non-weekly pair at any weekday; a daily 'bad week' + S1's indicator): the pair found and BETTER on
      half B, S1's tw5 twin BETTER, the FOUND tree above FROZEN, every output hashed, two ledger lines
  w2  ABSENT world (no effect): nothing BETTER
  w3  WEEKLY world (only Tuesday entries after a bad completed week pay): WEEKLY clearly positive; no twin and no
      found setup BETTER
  w4  --check-only writes nothing; an edited declaration, an output folder inside the cache and a panel without the
      weekly input are refused
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import anydaylab as AD  # noqa: E402

SU, SL = AD.SU, AD.SL
FAILS = []
N_OK = [0]


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   %s" % what)
    else:
        FAILS.append(what)
        print("  FAIL %s" % what)


DF = ["f%02d" % i for i in range(8)]
FZ = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_wq_44", "d_bb_bw_20", "d_bb_pctb_20"]
SOUL = ["soul_a", "soul_b", "soul_c"]
BOOST = 0.012


def make_world(base: Path, seed: int, mode: str, n_sym=60, per_day=5, start="2019-05-06", end="2026-10-30"):
    """root: the daily cache (<SYMBOL>_daily.parquet, IST stamps), panel_oc\\panel.parquet (+ PRODUCTION.json), the Soul
    file + meta; data: setuplab's watchlist folder (D and ENS, ranks 1-per_day). Prices are one continuous series per
    stock; a plant adds BOOST to each of the 5 sessions after its condition held at a close:
      planted  f07 fell and f05 rose (any day)  |  the last 5 sessions fell and d_wq_16 rose (any day)
      weekly   w_ret_13w fell on the week's first session (only a Tuesday entry catches it)
      absent   nothing"""
    rng = np.random.default_rng(seed)
    root, data = base / "root", base / "data"
    for p in (root / "panel_oc" / "frozen" / "production", root / "panel" / "soul", data):
        p.mkdir(parents=True, exist_ok=True)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]     # one ETF: the tree skips it
    wk = cal.to_period("W-FRI").to_numpy()
    first_of_week = np.r_[True, wk[1:] != wk[:-1]]
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)), axis=1) for f in DF + FZ}
    for f, pr in (("f05", 0.3), ("f07", 0.3), ("d_wq_16", 0.12)):       # sparse steps: the plants stay rare
        X[f] = np.cumsum(rng.normal(0, 1, (n_sym, T)) * (rng.random((n_sym, T)) < pr), axis=1)
    X["d_bb_pctb_20"] = rng.normal(0.5, 0.5, (n_sym, T))
    wval = np.zeros((n_sym, T))
    wslow = np.zeros((n_sym, T))
    for s in range(n_sym):
        cur, cur2 = rng.normal(0, 10), rng.normal(0, 1)
        for t in range(T):
            if first_of_week[t]:
                if rng.random() < 0.3:
                    cur += rng.normal(0, 3)
                cur2 += rng.normal(0, 1)
            wval[s, t], wslow[s, t] = cur, cur2
    X["w_ret_13w"] = wval
    X["d_wk_level"] = wslow                         # a weekly value without a weekly name (changes on Mondays)
    X["d_sma200"] = 100 + np.cumsum(rng.normal(0, 1, (n_sym, T)), axis=1)
    X["label_x"] = rng.normal(0, 1, (n_sym, T))
    chg = {f: np.diff(X[f], axis=1, prepend=np.nan) for f in ("f05", "f07", "d_wq_16", "w_ret_13w")}
    sig = rng.uniform(0.012, 0.035, n_sym)
    O = np.zeros((n_sym, T))
    C = np.zeros((n_sym, T))
    H = np.zeros((n_sym, T))
    Lo = np.zeros((n_sym, T))
    for s in range(n_sym):
        c_prev = 100.0 * np.exp(rng.normal(0, 0.4))
        boost_until = -1
        closes = []
        for t in range(T):
            g = rng.normal(0, 0.005)
            u = rng.normal(0.0003, sig[s])
            if t <= boost_until:
                u += BOOST
            o = c_prev * (1 + g)
            c = o * (1 + u)
            O[s, t], C[s, t] = o, c
            H[s, t] = max(o, c) * (1 + abs(rng.normal(0, sig[s] / 3)))
            Lo[s, t] = min(o, c) * (1 - abs(rng.normal(0, sig[s] / 3)))
            closes.append(c)
            c_prev = c
            hit = False
            if mode == "planted":
                if chg["f07"][s, t] < 0 and chg["f05"][s, t] > 0:
                    hit = True
                if t >= 5 and closes[-1] / closes[-6] - 1 < 0 and chg["d_wq_16"][s, t] > 0:
                    hit = True
            elif mode == "weekly":
                if first_of_week[t] and chg["w_ret_13w"][s, t] < 0:
                    hit = True
            if hit:
                boost_until = max(boost_until, t + 5)
    stamps = pd.DatetimeIndex(cal).tz_localize("Asia/Kolkata") + pd.Timedelta(hours=9, minutes=15)
    for s, sym in enumerate(syms):
        pd.DataFrame({"timestamp": stamps, "open": O[s], "high": H[s], "low": Lo[s], "close": C[s],
                      "volume": rng.integers(1e5, 1e6, T)}).to_parquet(root / ("%s_daily.parquet" % sym), index=False)
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(cal, n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    so = pd.DataFrame({"timestamp": np.tile(cal, n_sym), "symbol": np.repeat(syms, T)})
    for f in SOUL:
        a = np.zeros((n_sym, T))
        a[:, 0] = rng.normal(0, 1, n_sym)
        e = rng.normal(0, 0.2, (n_sym, T))
        for t in range(1, T):
            a[:, t] = 0.98 * a[:, t - 1] + e[:, t]
        so[f] = a.ravel().astype("float32")
    so["soul_state_missing"] = 0
    so.to_parquet(root / "panel" / "soul" / "soul_v3.parquet", index=False)
    (root / "panel" / "soul" / "soul_v3_meta.json").write_text(json.dumps(
        {"code": "soul_v3.1", "entry": "close", "config": {"lag": 6, "horizon": 5},
         "features": SOUL + ["soul_state_missing"]}), encoding="utf-8")
    (root / "panel_oc" / "frozen" / "production" / "PRODUCTION.json").write_text(json.dumps(
        {"models": {"D": {"file": "D.pkl", "features": [f.upper() if f == "f00" else f for f in DF] + FZ +
                          ["w_ret_13w", "d_wk_level", "d_sma200", "label_x", "f_missing"]}}}), encoding="utf-8")
    atr = np.vstack([SU.atr_simple(H[s], Lo[s], C[s]) for s in range(n_sym)])
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    rows = []
    for t in range(t0, T - 11):
        pick_d = rng.choice(n_sym, per_day, replace=False)
        pick_e = np.concatenate([pick_d[:per_day // 2], rng.choice(np.setdiff1d(np.arange(n_sym), pick_d),
                                                                   per_day - per_day // 2, replace=False)])
        rng.shuffle(pick_e)
        for eng, picks in (("D", pick_d), ("ENS", pick_e)):
            for rk, s in enumerate(picks, 1):
                e1 = O[s, t + 1]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": C[s, t], "entry": e1, "status": "ok",
                       "net_bp": (C[s, t + 5] / e1 - 1) * 1e4 - 35, "s_atr14": atr[s, t], "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[s, t + k] / e1 - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[s, t + k] / C[s, t + k - 1] - 1
                rows.append(row)
    pd.DataFrame(rows).to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return root, data, {"cal": cal, "C": C, "syms": syms}


def args(root, data, out, **kw):
    return SimpleNamespace(root=str(root), data=str(data), out=str(out),
                           soul=str(root / "panel" / "soul" / "soul_v3.parquet"), panel=kw.get("panel"),
                           check_only=kw.get("check_only", False))


def runs(out):
    return sorted(p for p in Path(out).iterdir() if p.is_dir() and re.fullmatch(r"ANYDAY_\d{8}_\d{3}", p.name))


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return len(lines) >= 10 and all(
        hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0] for ln in lines)


def the_book(root, data):
    panel = root / "panel_oc" / "panel.parquet"
    soul = root / "panel" / "soul" / "soul_v3.parquet"
    _, fdoc = SU.load_frozen()
    ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
    dfeats, _, _ = SL.d_features(root)
    dcols, _ = SL.choose_features(dfeats, panel)
    _, scols, _ = SL.soul_meta(soul)
    pcols = list(dict.fromkeys(ffeats + dcols))
    bk, _, _ = AD.load_book(data, panel, soul, pcols, scols, set(ffeats) | set(AD.TWIN_FEATS), root,
                            log=lambda *a: None)
    return bk, fdoc, dcols, scols


# ---------------------------------------------------------------------------------------------------- unit checks
def unit_checks(root, data, info):
    print("u1-u8: the parts by hand")
    bk, fdoc, dcols, scols = the_book(root, data)
    ctx = AD.Ctx(bk)
    _, tdoc0 = SU.load_tree()
    ok = AD.complete_rows(bk) & ~SU.tree_etf(bk.symbols, tdoc0)
    R, _ = AD.pooled_rows(bk, ok)
    feats = [f for f in dcols + scols + list(AD.TWIN_FEATS) if not AD.is_weekly_name(f)]
    atoms = AD.feature_atoms(feats, set(scols), bk, R) + AD.price_atoms()
    DM = AD.masks(bk, R, atoms)
    rng = np.random.default_rng(3)
    fam = SL.fam_ids(atoms)
    bad, tried = 0, 0
    for _ in range(60):
        size = int(rng.integers(1, 4))
        c = []
        while len(c) < size:
            x = int(rng.integers(len(atoms)))
            if all(fam[x] != fam[y] for y in c):
                c.append(x)
        K = SL.trig_entries(DM, tuple(c))
        day, _ = ctx.rep(AD.conds_of(atoms, c))
        want = np.where(day[R] > 0, day[R] - 1, 5)
        bad += int((K != want).sum())
        tried += 1
    check(bad == 0, "u1 %d random rules: the masks' first fill = setuplab's trigger on every pooled pick" % tried)
    C, cal, syms = info["C"], info["cal"], info["syms"]
    si = {s: i for i, s in enumerate(syms)}
    ci = {d: i for i, d in enumerate(pd.DatetimeIndex(cal).normalize())}
    bad = 0
    for r in rng.choice(R, 200):
        k = int(rng.integers(1, 6))
        j = ci[pd.Timestamp(bk.cal[bk.i1[r] + k - 2])]
        c = C[si[bk.symbols[r]]]
        r65 = lambda t: (c[t] / c[t - 65] - 1) * 100
        want13 = r65(j) - r65(j - 5)
        want5 = (c[j] / c[j - 5] - 1) * 100
        bad += not (abs(bk.F["dw_ret_13w"][r, k] - want13) < 1e-9 and abs(bk.F["d_ret_5s"][r, k] - want5) < 1e-9)
    check(bad == 0, "u2 200 random pick-days: both twins = the cache's own closes by hand")
    wb = AD.weekday_bound(bk, R, ["w_ret_13w", "d_wk_level", "f03", "dw_ret_13w"])
    check(wb["w_ret_13w"][0] > 0.9 and wb["w_ret_13w"][1] == 0 and wb["d_wk_level"][0] > 0.9 and
          wb["f03"][0] < 0.3 and wb["dw_ret_13w"][0] < 0.3 and AD.is_weekly_name("w_ret_13w_change") and
          not AD.is_weekly_name("dw_ret_13w"),
          "u3 weekly inputs: w_ret_13w (name) and d_wk_level (%.0f%% of its changes on Mondays) are weekly; f03 and "
          "the twin are not" % (100 * wb["d_wk_level"][0]))
    fconds = SU.frozen_conds(fdoc)
    wk_ids = [s for s, cc in fconds.items() if any(AD.is_weekly_name(f) for f, _, _ in cc)]
    day, nets = AD.lane(ctx, [fconds[s] for s in wk_ids])
    hand = np.zeros(bk.n, int)
    for s in wk_ids:
        d_, st = SU.trigger(bk, fconds[s])
        for i in np.flatnonzero(st == "Filled"):
            if hand[i] == 0 or d_[i] < hand[i]:
                hand[i] = d_[i]
    rr = np.flatnonzero(hand > 0)
    want = (bk.C[rr, 5] / bk.O[rr, hand[rr]] - 1) * 100 - 0.35
    check(wk_ids == ["S1", "S2", "S3", "C1", "C2", "C3"] and np.array_equal(day, hand) and
          np.allclose(nets["original_d5"][rr], want, equal_nan=True) and len(rr) > 50,
          "u4 WEEKLY = the earliest S1-C3 fill by a plain loop (%d fills); the D5-close net by hand" % len(rr))
    tw = AD.twin_conds(fconds["S2"], "dw_ret_13w")
    check(tw == [("d_mdi14_diff5_change", ">", 0.0), ("gap_pct", "<", 0.0), ("dw_ret_13w", "<", 0.0)],
          "u5 S2's tw13 twin = S2 with only the weekly condition swapped")
    hv = AD.halves(np.unique(bk.symbols))
    check(all(AD.half_of(s) == int(hashlib.sha256(("anydaylab-v1|" + s).encode()).hexdigest(), 16) % 2
              for s in np.unique(bk.symbols)) and 0 < hv.mean() < 1,
          "u6 the halves = sha256('anydaylab-v1|SYMBOL') parity; both halves have stocks")
    _, tdoc = SU.load_tree()
    cuts = AD.tree_cuts(bk, tdoc)
    primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
    order = [s for s in SU.TREE_ORDER if s in fconds]
    P1 = AD.tree_picks(bk, AD.su_of(ctx, {s: fconds[s] for s in order}, primary), order, primary, tdoc, cuts)
    tags = []
    for e in ("D", "ENS"):
        W_, _, _ = SU.tag_book(bk.take(bk.engine_arr == e, e), fconds, fdoc)
        tags.append(W_)
    P2 = SU.tree_history_picks(bk, pd.concat(tags, ignore_index=True), fdoc, tdoc, cuts)
    same = all(np.array_equal(P1[c].to_numpy(), P2[c].to_numpy()) for c in ("su_id", "su_k", "su_ent", "su_ex")) and \
        np.allclose(P1["su_net"].to_numpy(float), P2["su_net"].to_numpy(float), equal_nan=True) and \
        (P1["lane"].to_numpy() == P2["lane"].to_numpy()).all()
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    s_ = int(np.searchsorted(bk.cal, np.datetime64("%d-01-01" % min(y for y in cuts if (years == y).any()))))
    b1, _ = SU.tree_run_books(P1, bk, s_)
    b2, _ = SU.tree_run_books(P2, bk, s_)
    t1 = int(min(len(bk.cal) - 1, max(int(b[0]["ex"].max()) for b in b2.values() if len(b[0]))))
    r1, _, _ = SU.tree_history(bk, P1, b1, s_, t1, reruns=0, log=lambda *a: None)
    r2, _, _ = SU.tree_history(bk, P2, b2, s_, t1, reruns=0, log=lambda *a: None)
    money, chk = AD.tree_money(ctx, {"FROZEN": ({s: fconds[s] for s in order}, order, primary)}, tdoc,
                               log=lambda *a: None)
    same2 = all(abs(np.mean([d["a_year"] for d in r1[g]]) - np.mean([d["a_year"] for d in r2[g]])) < 1e-9 and
                abs(money["FROZEN"]["res"][g]["a_year"] - np.mean([d["a_year"] for d in r2[g]])) < 1e-9
                for g in r2)
    check(same and same2, "u7 the tree replay = setuplab's tree_history_picks / tree_history (first fills, lanes, the "
                          "books' a-year numbers; D tree %+.2f%%)" % money["FROZEN"]["res"]["D tree"]["a_year"])
    pop = AD.Pop(ctx, R, day, nets, "all")
    r = pop.stats(ctx, fconds["N1"], "original_d5")
    dN, nN = ctx.rep(fconds["N1"])
    mN = dN[R] > 0
    mW = day[R] > 0
    plain = float(nN["original_d5"][R][mN].mean() - nets["original_d5"][R][mW].mean())
    lo, hi, sd = pop.boot.ci_diff(pop.bdi[mN], nN["original_d5"][R][mN], pop.bdi[mW], nets["original_d5"][R][mW])
    import math
    p_hand = 0.5 * math.erfc(plain / sd / math.sqrt(2.0))
    check(abs(r["diff"] - plain) < 1e-12 and abs(r["p"] - p_hand) < 1e-12 and lo <= plain <= hi,
          "u8 N1 vs WEEKLY: the difference = the plain difference of the means (%+.3f); p from the resamples" % plain)
    keys = pd.Series(pd.DatetimeIndex(bk.signal_day[R]).strftime("%Y-%m-%d") + "|" + bk.symbols[R])
    check((bk.symbols == "LIQUIDBEES").sum() > 50 and not (bk.symbols[R] == "LIQUIDBEES").any() and
          not keys.duplicated().any(),
          "u10 the ETF's %d watchlist rows are out of the pooled picks; one row per stock and signal day" %
          int((bk.symbols == "LIQUIDBEES").sum()))
    thr = 0.05 / 14
    v = [AD.verdict({"diff": 1.0, "p": p_, "diff_lo": lo_, "diff_hi": hi_}, thr) for p_, lo_, hi_ in
         ((0.001, 0.2, 2.0), (0.01, 0.2, 2.0), (0.001, -0.1, 2.0), (0.99, -2.0, -0.1), (0.5, -1.0, 1.0))]
    check(v == ["BETTER", "TIE", "TIE", "WORSE", "TIE"],
          "u9 the verdict: p 0.001 -> BETTER; p 0.01 (above 0.05/14) -> TIE; the interval below 0 -> WORSE (%s)" % v)


def run_world(tmp, name, seed, mode):
    print("%s world" % name)
    root, data, info = make_world(tmp / name, seed, mode)
    out = tmp / name / "out"
    rc = AD.cmd_run(args(root, data, out))
    d = runs(out)[-1] if out.exists() and runs(out) else None
    return rc, d, root, data, info, out


def main():
    t0 = time.time()
    tmp = Path(tempfile.mkdtemp(prefix="anydaylab_test_"))
    try:
        print("%s tests (%s, %s; pandas %s, numpy %s)" % (AD.VERSION, SU.VERSION, SL.VERSION, pd.__version__,
                                                          np.__version__))
        rc, d, root, data, info, out = run_world(tmp, "planted", 11, "planted")
        unit_checks(root, data, info)
        print("w1: the planted world")
        check(rc == 0 and d is not None, "w1 run returns 0 and writes a run folder")
        if d is not None:
            tw = pd.read_csv(d / "twins.csv")
            fd = pd.read_csv(d / "found_d5.csv")
            mo = pd.read_csv(d / "money.csv")
            cand = json.loads((d / "ANYDAY_CANDIDATES.json").read_text(encoding="utf-8"))
            jd = fd[fd["judged"]]
            hit = jd[jd["rule"].str.contains("f07:dn") & jd["rule"].str.contains("f05:up")]
            check(len(hit) >= 1 and (hit["verdict"] == "BETTER").all(),
                  "w1 the planted non-weekly pair (f07 fell AND f05 rose) found, judged and BETTER on half B (%s)" % (
                      "; ".join("%s %s %+.2f vs WEEKLY" % (r.rule, r.verdict, r.B_vs_weekly) for r in hit.itertuples())
                      or "not judged"))
            check(len(hit) >= 1 and all(str(x) in ("", "nan") for x in hit["B_adds_nothing"]),
                  "w1 both of its conditions add on half B (%s)" % "; ".join(str(x) for x in hit["B_adds"]))
            famof = dict(zip(pd.read_csv(d / "conditions.csv")["id"], pd.read_csv(d / "conditions.csv")["family"]))
            sets = [(len(r.split(" & ")), {famof[x] for x in r.split(" & ")}) for r in jd["rule"]]
            clash = [1 for i, (na, a_) in enumerate(sets) for nb, b_ in sets[i + 1:]
                     if a_ <= b_ or b_ <= a_ or (max(na, nb) == 3 and len(a_ & b_) >= 2)]
            check(not clash, "w1 the judged d5 setups are not versions of each other (%d judged)" % len(sets))
            check((hit["B_tuesday_share"] < 0.4).all() if len(hit) else False,
                  "w1 it buys on every weekday (Tuesday share %s)" % ", ".join("%.0f%%" % (100 * x) for x in
                                                                              hit["B_tuesday_share"]))
            s1 = tw[tw["setup"] == "S1-tw5"]
            check(len(s1) == 1 and s1["verdict"].iloc[0] == "BETTER",
                  "w1 S1's tw5 twin (the planted daily 'bad week' + WQ-16 rising) BETTER than WEEKLY (%s)" % (
                      "%+.2f, p %.2g" % (s1["vs_weekly"].iloc[0], s1["p"].iloc[0]) if len(s1) else "-"))
            both = mo[mo["group"] == "both trees (Rs 2.5 L each)"].set_index("tree")["a_year_pct"]
            check("FOUND" in both.index and both["FOUND"] > both["FROZEN"],
                  "w1 money: the FOUND tree above FROZEN (%s)" % ", ".join("%s %+.1f%%" % kv for kv in both.items()))
            check(outputs_ok(d) and cand["sha256"] == SU.frozen_hash(cand),
                  "w1 every output hashed (outputs.sha256), the candidates file hash-checked")
            led = (out / "anydaylab_ledger.jsonl").read_text(encoding="utf-8").splitlines()
            check(len(led) == 2 and json.loads(led[0])["event"] == "start" and json.loads(led[1])["event"] == "end",
                  "w1 two ledger lines (start, end)")
            ex = pd.read_csv(d / "excluded.csv")
            cn = pd.read_csv(d / "conditions.csv")
            check({"w_ret_13w", "d_wk_level"} <= set(ex["feature"]) and
                  not cn["field"].str.fullmatch(r"(w_ret_13w|d_wk_level)(_change)?").any() and
                  cn["field"].str.startswith("dw_ret_13w").any(),
                  "w1 the search used no weekly input (w_ret_13w and d_wk_level left out, the twins in)")
            md = (d / "ANYDAY.md").read_text(encoding="utf-8")
            check("## Verdict" in md and "BETTER" in md and "Part C" in md, "w1 ANYDAY.md written with the verdict")
            mk = re.search(r"Part A: K = (\d+), p <= ([\d.]+); Part B: K = (\d+), p <= ([\d.]+)", md)
            nj = int(pd.concat([pd.read_csv(d / f) for f in ("found_d5.csv", "found_fresh.csv")])["judged"].sum())
            fl = pd.concat([pd.read_csv(d / f) for f in ("found_d5.csv", "found_fresh.csv")])
            bt = fl[fl["verdict"] == "BETTER"]
            check(mk is not None and int(mk.group(1)) == 14 and abs(float(mk.group(2)) - 0.05 / 14) < 1e-4 and
                  int(mk.group(3)) == nj and abs(float(mk.group(4)) - 0.05 / max(nj, 1)) < 1e-4 and
                  (bt["B_p"] <= 0.05 / max(nj, 1)).all(),
                  "w1 the corrected thresholds: Part A 0.05/14, Part B 0.05/%d; every BETTER below its threshold" % nj)
        rc, d, root2, data2, _, out2 = run_world(tmp, "absent", 12, "absent")
        print("w2: the absent world")
        check(rc == 0 and d is not None, "w2 run returns 0")
        if d is not None:
            tw = pd.read_csv(d / "twins.csv")
            fl = pd.concat([pd.read_csv(d / f) for f in ("found_d5.csv", "found_fresh.csv")])
            nj = int(fl["judged"].sum())
            check(not (tw["verdict"] == "BETTER").any() and not (fl["verdict"] == "BETTER").any(),
                  "w2 nothing BETTER (14 twins and lanes, %d found setups judged)" % nj)
        rc, d, _, _, _, _ = run_world(tmp, "weekly", 13, "weekly")
        print("w3: the weekly world")
        check(rc == 0 and d is not None, "w3 run returns 0")
        if d is not None:
            tw = pd.read_csv(d / "twins.csv")
            fl = pd.concat([pd.read_csv(d / f) for f in ("found_d5.csv", "found_fresh.csv")])
            bar = pd.read_csv(d / "weekly_bar.csv")
            w = bar.iloc[0]
            check(w["net_d5_lo"] > 0 and w["tuesday_share"] > 0.99,
                  "w3 WEEKLY clearly positive (%+.2f [%+.2f, %+.2f]), every entry on a Tuesday" % (
                      w["net_d5"], w["net_d5_lo"], w["net_d5_hi"]))
            check(not (tw["verdict"] == "BETTER").any() and not (fl["verdict"] == "BETTER").any(),
                  "w3 no twin and no found setup BETTER (twins: %s)" % ", ".join(
                      "%s %s" % (r.setup, r.verdict) for r in tw.itertuples() if "lane" in r.setup))
        print("w4: refusals")
        out3 = tmp / "planted" / "out_check"
        rc = AD.cmd_run(args(root, data, out3, check_only=True))
        check(rc == 0 and not out3.exists(), "w4 --check-only searches and writes nothing")
        rc = AD.cmd_run(args(root, data, root / "x"))
        check(rc == 3, "w4 an output folder inside the cache is refused")
        dp = AD.HERE / AD.DECL_FILE
        orig = dp.read_bytes()
        try:
            doc = json.loads(orig.decode("utf-8"))
            doc["part_A_twins"]["K"] = "13"
            dp.write_text(json.dumps(doc, indent=1), encoding="utf-8")
            rc = AD.cmd_run(args(root, data, tmp / "out_x"))
        finally:
            dp.write_bytes(orig)
        check(rc == 3 and dp.read_bytes() == orig, "w4 an edited declaration is refused (and restored byte for byte)")
        pp = root2 / "panel_oc" / "panel.parquet"
        P = pd.read_parquet(pp).drop(columns=["w_ret_13w"])
        pp2 = tmp / "panel_noweekly.parquet"
        P.to_parquet(pp2, index=False)
        rc = AD.cmd_run(args(root2, data2, tmp / "out_y", panel=str(pp2)))
        check(rc == 3, "w4 a panel without the weekly input (w_ret_13w) is refused")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("")
    print("%d checks, %d failed (%.0f s)" % (N_OK[0] + len(FAILS), len(FAILS), time.time() - t0))
    if FAILS:
        print("FAILED:")
        for f in FAILS:
            print("  - " + f)
        return 1
    print("VERIFIED (%s)" % AD.VERSION)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
