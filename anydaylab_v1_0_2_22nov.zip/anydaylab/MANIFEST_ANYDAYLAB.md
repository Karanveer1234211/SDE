# MANIFEST - anydaylab v1.0.2 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\anydaylab` (a research folder beside `setuplab` and `soullab`).
Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\anydaylab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `anydaylab.py` | 4e7de52d0695238d | 102025 |
| `ANYDAY_DECLARATION.json` | f6451255d03b8ef9 | 16059 |
| `README_ANYDAYLAB.md` | fad732bc589f3667 | 13700 |
| `tests\test_anydaylab.py` | 2a40adc3727fe6aa | 47657 |
| `MANIFEST_ANYDAYLAB.md` | this file | - |

Needs, read only, as sibling folders: `setuplab` v1.1 (setuplab.py sha16 9979d418aecec6de, FROZEN_SETUPS.json and TREE.json beside
it) and `soullab` v1.0 (soullab.py sha16 aaf5fa1742638561). Neither changes in v1.0.2.

Declaration: `ANYDAY_DECLARATION.json`, internal sha256 8f73a261a2d7167a... - checked at every start; an edited file is refused.

## History
- v1.0.2 (22 Nov 2026, 02:10-02:30 IST, after run ANYDAY_20261122_001 was read and before any v1.0.2 run): THE 2024
  SPLIT.
  - Part B searches and judges only picks whose every price is before 2024-01-01 (the thirds' cut-offs and the
    weekday test too).
  - Part C replays every tree from 2021 (descriptive) and from 2024-01-01 (THE TEST).
  - The declared decision on FOUND+WEEKLY vs FROZEN (both books): CONFIRMED / LEAD / DEAD. Its interval is 200 paired
    reruns, setuplab's own; the day-block bootstrap of the worst fall is shown but never decides (README: why).
  - It writes the daily values (curves.csv), every book's 3 deepest falls with dates (falls.csv) and each input's
    weekday / month-first-session share (bound.csv).
  - It names month-bound inputs (Soul's monthly memory count, soul_m_self_n) and shows each setup's month-start
    entries.
  - It refuses a watchlist without picks on both sides of the split.
- v1.0.1 (22 Nov 2026, before any real run was read):
  - day-of-week inputs are never searched (D's DOW_ dummies slipped past v1.0's weekday filter);
  - a verdict needs trades on 30 or more signal days and resamples with spread;
  - Part D judges stratlab run 001's two confirmed triggers on the stocks stratlab hid from its search, against WEEKLY,
    and in the tree's money.
- v1.0 (22 Nov 2026): first build. Its run 001: the twins failed, 5 found setups beat WEEKLY per trade (all
  month-start setups with a market filter), and FOUND+WEEKLY's smaller worst fall led to v1.0.2.

## Verified (synthetic data only): `59 checks, 0 failed` / `VERIFIED (anydaylab v1.0.2)` on pandas 3.0.5 (340 s) and pandas 2.3.3 (328 s)
- **v1.0.1's checks** still pass: the masks, the twins, weekly and day-of-week inputs out, WEEKLY, the halves, the tree
  replay, the judge, the verdict and the 30-day rule, 'fell the session before', ETFs out, and the planted, absent and
  weekly worlds.
- **v1.0.2's parts, by hand:**
  - the worst fall, and the day-block bootstrap (a path against itself gives 0 [0, 0]; halved losing days give an
    interval above 0; an unrelated path gives one holding 0);
  - the decision on every edge;
  - the falls' dates;
  - each session's place in its month, and the Soul count being month-bound ('rose' buys only on a month's 2nd
    session);
  - the firewall (every searched pick's D9 close before the split; the thirds from half A before the split, by hand
    and in the run's own conditions.csv);
  - the reruns are paired (a tree against itself: a cut of exactly 0 in all 200);
  - the saved daily values give setuplab's own worst falls.
- **Wiring:** the decision as written equals the declared rule applied to the run's own numbers. curves.csv and
  falls.csv agree.
- **Crash world** (market falls before and after the split; the planted pair protects): the pair is found before the
  split and the decision is **CONFIRMED** (cut +13.43, reruns [+4.86, +14.89]). FROZEN's worst fall is a planted market
  fall. The day-block bootstrap of the same cut put only 71% of its draws above 0, which is why it doesn't decide.
- **The pair works only before the split:** it is found, there is nothing clear after the split, and the decision is
  not CONFIRMED.
- **The pair works only after the split:** the search never sees it (the firewall), and the decision is not
  CONFIRMED.
- **Nothing planted:** not CONFIRMED.
- **Refusals:** an edited declaration, an output folder inside the cache, a panel without w_ret_13w, and a watchlist
  ending before the split.
- **Mutation test of the v1.0.2 changes:** 11 of 11 planted bugs caught (a leak past the split, the thirds from every pick, the search on every day, an equal fall counted as lower, unpaired reruns, the decision reading the day-block bootstrap, the test not restarted on the split, the month-bound measure, a fall dated late, an unpaired day-block bootstrap, a looser return check).
