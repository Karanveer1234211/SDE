# anydaylab v1.0.2 - setups for any weekday, judged against the tree's Tuesday setups, with the 2024 split

Your ask (22 Nov 2026, 00:21): *"Lets go back to tree. Non Tuesday(weekly) setups which are better than weekly
setups. Find. Non-negotiable."* Then, on FOUND+WEEKLY's smaller worst fall in run ANYDAY_20261122_001: *"Go"*.

## v1.0.2: the 2024 split - does FOUND+WEEKLY really cut the worst fall?

**What run 001 (v1.0) showed.** Adding the found setups to the weekly ones (FOUND+WEEKLY) gave the two trees
(Rs 2.5 L each, 2021-01-01 .. 2026-09-22):
- a worst fall of 20.96% against FROZEN's 25.89%;
- +109.83% a year against +112.79%; the daily difference -0.59 bp [-3.17, +2.09].

**Why that isn't proof yet.**
- **Book by book it didn't hold:** D's worst fall went up (24.11% -> 25.08%), only ENS's went down (29.46% -> 26.18%).
- **The found setups saw those days:** they were searched on every day of the window. They are market-day filters
  (VIX, Nifty RSI, Nifty Bank, Nifty Metal), and the hidden half B shares its days with half A, so it can't check them.

**What v1.0.2 does.**
- **The search sees only the past:** Part B searches and judges only picks whose every price (the D1-D5 opens and the
  D1-D9 closes) is before **1 Jan 2024**. The thirds' cut-offs come from those picks too.
- **The test:** both trees start again with Rs 5 L a book on 1 Jan 2024 and run to the end of the tree's trades
  (Sep 2026), on picks the search never saw.

**The decision (declared before the run, in `ANYDAY_DECLARATION.json`).** Both books together:
- **CONFIRMED:** FOUND+WEEKLY's worst fall is lower than FROZEN's on all 5 start days, AND its a year is at most 5 points
  under FROZEN's, AND the cut's 95% interval over 200 paired reruns is above 0.
- **LEAD:** the first two hold, but the interval reaches 0. FOUND+WEEKLY goes on the paper ledger beside FROZEN.
- **DEAD:** anything else, including nothing found before 2024.

**The paired reruns.** These are setuplab's own tree reruns:
- **One rerun:** starts on a random one of the 5 start days and drops 2% of each engine's picks at random.
- **The pairing:** both trees get the SAME start day and the SAME dropped picks, so each rerun gives one cut.
- **What it catches:** a cut that is a timing accident of the exact trades. That was the worry after run 001: the two
  books' falls stopped lining up.

**Why not a day-block bootstrap.**
- **How it was tested:** I built that first and tested it on a planted crash world. There, the found setup really cut
  the worst fall in 2024-26 from 24.7% to 11.3% on every start day.
- **What it gave:** it put only 71% of its draws above 0 (with blocks of 10 to 126 sessions: 67-75%). A worst fall is
  one episode, and a re-ordered history that leaves the crash out has nothing to cut.
- **What that means:** a check that can't confirm a cut that large decides nothing. It is still shown, never
  deciding.

**Example.**
- **The numbers:** FROZEN falls 24.7% from April to May 2025 and FOUND+WEEKLY falls 11.3%, on every start day. FOUND+WEEKLY
  makes more a year, and the cut stays above 0 in all 200 reruns ([+4.86, +14.89]).
- **The verdict:** CONFIRMED. That is the planted crash world in the tests.
- **If the cut only shows on the real path:** say it is +3 points but negative in 1 rerun in 6. Then it is LEAD.

**What "soul_m_self_n rose" really is.**
- **What the value counts:** soul_m_self_n is the number of the stock's own finished trades in Soul's memory.
- **When it changes:** Soul rebuilds that memory once a month. So the count changes only on a month's first session,
  and "soul_m_self_n rose" means **buy on the month's 2nd session**.
- **Why it matters here:** all five BETTER setups of run 001 had it. They are month-start setups with a market filter.
- **What the run does with it:** it names every month-bound input (kept in the search, so the split tests the same
  search) and shows each setup's share of entries in a month's first 3 sessions. A setup that ignores the month sits
  near 14%.

anydaylab sits beside setuplab and soullab (`PyCharmMiscProject\anydaylab`) and uses their tested code (read only).
- **What it reads:** production, the watchlist, the panel, Soul and the daily cache, all read only.
- **Where it writes:** only under `C:\QuantData\anydaylab`.
- **What it does not change:** the frozen setups, the tree, the paper test and production.
- **Its rules:** `ANYDAY_DECLARATION.json`, written before any run and sha256-checked. An edited file is refused.

## Why the weekly setups only buy on Tuesdays

S1, S2, S3, C1, C2 and C3 all need **"w_ret_13w fell"**.
- **What that value is:** the stock's 13-week return, worked out once a week from Friday's close.
- **Where it changes:** the panel changes it only on the week's first session.
- **What follows:** the setups read it at the next open, so they can only buy at a **Tuesday open**.

A pick signalled on a Wednesday waits until the next Tuesday (about D4). It is skipped if the conditions don't hold that
day. N1 has no weekly condition.

## What it does, in plain words

**The bar: WEEKLY.**
- **What it is:** the weekly setups as the tree uses them. Each pick takes its earliest S1–C3 fill.
- **How a candidate is measured:** its net per trade, on the same picks and at the same exit as WEEKLY.
- **The picks:** D and ENS, every rank, with ETFs left out (the tree skips them). A stock picked twice on a day counts once.

**Part A: the twins (declared, nothing searched).** Each weekly setup keeps its other conditions, and its "bad
completed week" is swapped for a daily rolling version, worked out at every close from the stock's own daily bars in
the cache:
- **tw13:** the 13-week return (close vs 65 sessions back) is lower than it was 5 sessions ago. This is the weekly
  condition's own meaning, available on any day.
- **tw5:** the last 5 sessions fell.

That gives 12 twins, plus two "lanes" (each pick's earliest twin fill). All are judged on every pick against WEEKLY.

**Part B: the open search.**
- **The conditions:**
  - every input of engine D that isn't weekly, every Soul value and both twins: rose or fell at the close before the
    entry, or sits in its low or high third;
  - price conditions: dips under the D1 open in % and in ATR, gap down or gap up, the previous close, and a red or
    green previous candle.
- **The rules:** 1 to 3 conditions each. A rule buys at the first open (D1–D5, any weekday) where all its conditions
  hold, which is the frozen setups' own rule. Each condition must earn its place.
- **How the stocks are split:** the search sees only **half A** (a fixed hash of the symbol).
- **How a rule qualifies on half A:** 25+ trades a year, net per trade above 0 (95%), above WEEKLY's net, and at most 2
  losing years.
- **The judge:** the best 5 per exit (the D5 close, or 4 sessions after entry) are checked **once on half B**, against
  WEEKLY on half B's picks. The search never saw half B.
- **Versions are skipped:** a setup that shares two of three conditions' families with one already kept doesn't take
  a second judge slot.
- **Each condition is checked again on half B.** The report names any condition that adds nothing there; the setup
  without it is the cleaner candidate.

**BETTER** means the setup's net per trade minus WEEKLY's has a one-sided p at most 0.05 / K, where K is the number of
setups judged in that part. This correction stops a lucky setup out of thousands from passing. **TIE** means no clear
difference either way. **WORSE** means the 95% interval is below 0.

**Part D: stratlab's trigger (added in v1.0.1).** This is stratlab run 001's one real result, in two versions, exactly as
stratlab found it.
- **The rule:** the pick closes in the bottom third of its 20-day range, its candle-body average fell twice, and the
  market is down too (cross-sectionally the stock isn't unusually low). Buy the next open and sell at the D5 close.
- **How it's judged:** on the stocks stratlab hid from its own search, against WEEKLY on the same picks.
- **In the tree:** it also enters Part C's money table as STRATLAB and STRATLAB+WEEKLY.

**v1.0.1 fixes:**
- **Day-of-week inputs are never searched.** D's `DOW_` dummies slipped past v1.0's weekday filter.
- **A verdict needs trades on at least 30 signal days.** A setup with fewer is TOO FEW, as is one whose resamples
  have no spread.

**Part C: money in the tree.** These are TREE.json's own books: ranks 1-3, D and ENS, Rs 5 L, 3 positions, from 2021.
- **FROZEN:** the tree as frozen. It must reproduce TREE.json's history, and the report says whether it does.
- **TWINS-13 and TWINS-5:** the six weekly setups replaced by their twins.
- **FOUND:** the weekly six replaced by Part B's BETTER setups.
- **FOUND+WEEKLY:** the frozen seven and the found ones together.

For each tree you get the yearly return, the worst fall, trades a week, and the daily difference against FROZEN.

**Example:**
- **The twin of S2:** buys a pick at the first open (D1–D5, any weekday) where minus-DI's 5-day change rose, the open
  gapped down, and the stock's 13-week return is lower than 5 sessions ago. That's S2's recipe without the Tuesday.
- **How it's judged:** suppose WEEKLY makes +1.40 a trade and the twin makes +1.90 with three times the trades. The twin
  is BETTER only if that +0.50 clears the corrected bar. Either way, Part C shows what it does to the tree's money.

## Install and run

Copy the `anydaylab` folder to `C:\Users\karanvsi\PyCharmMiscProject\anydaylab`, beside `setuplab` and `soullab`. Then
in `cmd`:

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\anydaylab
python tests\test_anydaylab.py
```

It must end `59 checks, 0 failed` / `VERIFIED (anydaylab v1.0.2)`. That takes about 6-10 minutes, on synthetic data
only.

```
python anydaylab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\anydaylab --soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet --check-only
```

This takes a few minutes and ends `CHECK OK`. It prints:
- the picks;
- how much of the twins the cache gives;
- whether the frozen setups replay FINAL_001's numbers;
- whether the frozen tree reproduces TREE.json's history;
- the time estimate.

Then the real run, the same without `--check-only`:

```
python anydaylab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\anydaylab --soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet
```

- **How long it takes:** about 10 minutes.
- **When it ends:** it prints `ANYDAY WRITTEN C:\QuantData\anydaylab\ANYDAY_<date>_<nnn>`, THE DECISION (CONFIRMED /
  LEAD / DEAD), then how many twins and found setups are BETTER than WEEKLY.
- **Running beside stratlab:** it can run in a second cmd window while stratlab runs.

## What you get (`C:\QuantData\anydaylab\ANYDAY_<date>_<nnn>\`)

- **`ANYDAY.md` - read this first.** It contains, in order:
  - **THE DECISION:** each start day's a year and worst fall for FROZEN and FOUND+WEEKLY from 1 Jan 2024, the cut with
    its reruns' interval, the setups added, and each book's worst fall with its dates;
  - the per-trade verdict and the bar (WEEKLY and each frozen setup);
  - Part A's twins;
  - Part B's judged setups (found before 2024), with their half A and half B numbers, Tuesday share and month-start
    entries, then the same setups on every stock after 2024 (descriptive);
  - Part D;
  - Part C's money: the test window (from 2024), then 2021 on;
  - the checks.
- **`split_decision.csv`:** the 5 start days of the test.
- **`curves.csv`:** the daily value of every tree's D book, ENS book and both, from 2024 and from 2021 (start day 1;
  1.0 = the start). Chart it in Excel.
- **`falls.csv`:** the 3 deepest falls of every book, with the peak, trough and recovery dates.
- **`bound.csv`:** every searched input's weekday share and month-first-session share.
- `twins.csv`, `found_d5.csv`, `found_fresh.csv`: every finalist, with its judged numbers where judged, its month-start
  share and (judged ones) its numbers after 2024.
- `ANYDAY_CANDIDATES.json`: every twin and judged setup in setuplab's own condition format, ready for a freeze, plus the
  decision. It is hash-checked.
- `money.csv` (now with a `window` column: test / full), `weekly_bar.csv`, `frozen_vs_final_001.csv`,
  `conditions.csv`, `excluded.csv`, `part_d.csv`, `DECLARATION.json`, `RUN.json`, `outputs.sha256`.
- A start and an end line in `C:\QuantData\anydaylab\anydaylab_ledger.jsonl` (the end line carries the decision).

Send me `ANYDAY.md`.

## Limits

- **2024-26 is one stretch of history.** It holds one or two big falls.
  - **What CONFIRMED means:** the cut held on those unseen days, on every start day, and survived 200 reruns.
  - **What it doesn't promise:** that the next fall will go the same way.
  - **Either way:** the setups go to the paper ledger beside FROZEN before any money.
- **stratlab's triggers (Part D) searched every day,** so the test window is NOT unseen for STRATLAB trees.
- **Every year before the test window has been seen before.**
  - **The weekly setups:** chosen on 2020-2026 and every stock, so their half-B numbers are not new. That favours
    WEEKLY.
  - **The twins:** pre-declared, but judged on the same history.
  - **Part C:** descriptive.
  - **What counts:** a BETTER setup goes to a new freeze with its own date, and the forward paper ledger judges it
    beside the frozen tree.
- **Where the twins come from:** the cache's daily closes, as stored. A stock with no cache file has no twin.
- **What the search doesn't do:** profit targets, brackets and day-of-week conditions are not searched.
