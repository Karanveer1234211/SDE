"""
anydaylab.py - anydaylab v1.0.2: entry setups that can fire on ANY weekday, judged against the tree's weekly (Tuesday)
setups - v1.0.2: THE 2024 SPLIT. The search and its judge see only picks whose every price is before 2024-01-01; the
tree is then replayed on 2024-26 (never seen by the search) and a rule declared before the run decides whether adding
the found setups to the weekly ones (FOUND+WEEKLY) cuts the worst fall: CONFIRMED / LEAD / DEAD.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\anydaylab
    python anydaylab.py run --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --out C:\\QuantData\\anydaylab
                            --soul %CACHE_DAILY_ROOT%\\panel\\soul\\soul_v3.parquet [--check-only]

Karan, 22 Nov 2026 00:21: "Lets go back to tree. Non Tuesday(weekly) setups which are better than weekly setups. Find.
Non-negotiable." The rules are fixed in ANYDAY_DECLARATION.json (beside this file, sha256-checked, written before any
run).

Why the weekly setups are Tuesday-only: S1, S2, S3, C1, C2 and C3 need "w_ret_13w fell" - a weekly value that changes
only on a week's first session and is read at the next open, so they can only buy at a Tuesday open. N1 has no weekly
condition. This tool finds setups with NO weekly input (and no weekday condition): they can buy on any weekday.

What it does, in plain words:
  The bar   WEEKLY = the tree's weekly setups as the tree uses them: each pick's earliest S1-C3 fill.
  Part A    THE TWINS (declared, nothing searched): S1-S3 and C1-C3 with the weekly condition swapped for a daily
            rolling twin computed from the stock's own daily closes - TW13: the 13-week return (65 sessions) is lower
            than 5 sessions earlier; TW5: the last 5 sessions fell. Judged on every pick against WEEKLY.
  Part B    THE OPEN SEARCH: every input of engine D that is not weekly, every Soul value and both twins (rose / fell at
            the close before the entry, low / high third) plus price conditions (dips under the D1 open in % and in
            ATR, gaps, the previous session's close and candle). Rules of 1-3 conditions, entered at the first open
            where all hold (the frozen setups' own rule). Searched on half A of the stocks; the best checked ONCE on
            half B (never searched) against WEEKLY on the same half-B picks.
  Part C    MONEY: the tree's own books (TREE.json: ranks 1-3, Rs 5 L, 3 positions, 2021 on) with the weekly setups
            replaced by the twins / by the found setups, and with the found setups added.
  BETTER = the setup's net per trade minus WEEKLY's, same picks and exit, 95% block bootstrap over signal days, one-sided
  p at most 0.05 / K (K = setups judged in that part).
  v1.0.2 THE SPLIT: Part B searches and judges only picks whose every price (D1-D5 opens, D1-D9 closes) is before
            2024-01-01. Part C replays the tree twice: 2021 on (descriptive; FROZEN must reproduce TREE.json) and from
            2024-01-01 (THE TEST: no found setup saw these days). The decision (ANYDAY_DECLARATION.json):
            CONFIRMED = FOUND+WEEKLY's worst fall (both books) lower than FROZEN's on all 5 start days, its a year at
            most 5 points under FROZEN's, and the 95% interval of the worst-fall cut above 0 over 200 paired reruns
            (setuplab's reruns: a random start day of the 5 and 2% of the picks dropped at random, the same draws for
            both trees); LEAD = the first two only (-> the paper ledger beside FROZEN); DEAD = anything else. Shown,
            not deciding: the cut with history re-ordered (a day-block bootstrap of the two daily value paths). The daily value paths and each fall's dates are written (curves.csv,
            falls.csv). Inputs whose changes fall on a month's first session (Soul's monthly memory, e.g.
            soul_m_self_n) are measured and named; each setup's share of entries in a month's first 3 sessions shown.
Example: the twin of S2 buys a pick at the first open (D1-D5, any weekday) where minus-DI's 5-day change rose, the open
gapped down, and the stock's 13-week return is lower than it was 5 sessions earlier - S2's recipe without the Tuesday.
Example (the split): a setup found on 2020-23 picks is added to S1-C3 + N1; the tree starts again with Rs 5 L a book on
1 Jan 2024; if its worst fall to Sep 2026 is lower on every start day, costs at most 5 points a year and the cut's 95%
interval is above 0, it is CONFIRMED.

Writes only under --out: ANYDAY_<date>_<nnn>\\ (ANYDAY.md first) and a line per run in anydaylab_ledger.jsonl.
Research only: nothing here changes the frozen setups, the tree, the paper test or production.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
for _d in (os.environ.get("SOULLAB_DIR") or str(HERE.parent / "soullab"),
           os.environ.get("SETUPLAB_DIR") or str(HERE.parent / "setuplab")):
    if _d not in sys.path:
        sys.path.insert(0, _d)
import soullab as SL  # noqa: E402
import setuplab as SU  # noqa: E402

VERSION = "anydaylab v1.0.2"
NEEDS = {"setuplab": "setuplab v1.1", "soullab": "soullab v1.0"}
DECL_FILE = "ANYDAY_DECLARATION.json"
SALT = "anydaylab-v1"
WEEKLY_RE = re.compile(r"^w_|weekly")
CALENDAR_RE = re.compile(r"^(d_)?dow(_\d+)?$|day_of_week|week_of|weekday|expiry|holiday")   # v1.0.1: never searched
MIN_DAYS = 30                  # v1.0.1: a verdict needs trades on this many signal days (and resamples with spread)
STRAT_SALT = "stratlab-v1"     # Part D is judged on the stocks stratlab hid from its own search
PART_D = (
    ("ST1", "stratlab run STRATLAB_20261122_001, PICKS TRIGGER, CONFIRMED rule 1",
     (("d_donch_pos_20", "<=", 0.21609196066856384), ("d_body_ratio_rmean20_change", "<", 0.0),
      ("d_body_ratio_rmean20_change_prev", "<", 0.0), ("x_z_d_donch_pos_20", ">", -0.29099416732788086))),
    ("ST2", "stratlab run STRATLAB_20261122_001, PICKS TRIGGER, CONFIRMED rule 2",
     (("d_donch_pos_20", "<=", 0.21609196066856384), ("d_body_ratio_rmean50_change", "<", 0.0),
      ("d_body_ratio_rmean50_change_prev", "<", 0.0), ("x_z_d_donch_pos_20", ">", -0.29099416732788086))),
)
WEEKDAY_BOUND = 0.5            # a feature whose changes fall on one weekday more than half the time is weekday-bound
R13, R1W = 65, 5               # the twins: 13 weeks = 65 sessions, a week = 5 sessions
TWINS = (("tw13", "dw_ret_13w", "the 13-week return (close / close 65 sessions before - 1) is lower than it was 5 "
                                "sessions before"),
         ("tw5", "d_ret_5s", "the last 5 sessions fell (close / close 5 sessions before - 1 is below 0)"))
TWIN_FEATS = tuple(t[1] for t in TWINS)
EXITS = (("d5", "original_d5", "sold at the pick's D5 close"), ("fresh", "fresh", "sold 4 sessions after the entry"))
PRICE_ATOMS = (
    ("dip1", "P|dip", ("pc_vs_d1", "<", -1.0), "the previous close at least 1% under the D1 open"),
    ("dip2", "P|dip", ("pc_vs_d1", "<", -2.0), "the previous close at least 2% under the D1 open"),
    ("dip3", "P|dip", ("pc_vs_d1", "<", -3.0), "the previous close at least 3% under the D1 open"),
    ("dip5", "P|dip", ("pc_vs_d1", "<", -5.0), "the previous close at least 5% under the D1 open"),
    ("dipatr05", "P|dip", ("pc_vs_d1_atr", "<", -0.5), "the previous close at least 0.5 ATR under the D1 open"),
    ("dipatr1", "P|dip", ("pc_vs_d1_atr", "<", -1.0), "the previous close at least 1 ATR under the D1 open"),
    ("dipatr15", "P|dip", ("pc_vs_d1_atr", "<", -1.5), "the previous close at least 1.5 ATR under the D1 open"),
    ("gapdn", "P|gap", ("gap_pct", "<", 0.0), "the open below the previous close (a gap down)"),
    ("gapdn1", "P|gap", ("gap_pct", "<", -1.0), "the open at least 1% below the previous close"),
    ("gapup", "P|gap", ("gap_pct", ">", 0.0), "the open above the previous close (a gap up)"),
    ("prevdn", "P|prev", ("prev_ret", "<", 0.0), "the previous session closed lower than the one before"),
    ("prevup", "P|prev", ("prev_ret", ">", 0.0), "the previous session closed higher than the one before"),
    ("red", "P|candle", ("prev_intraday", "<", 0.0), "the previous session closed below its open (red)"),
    ("green", "P|candle", ("prev_intraday", ">", 0.0), "the previous session closed above its open (green)"),
)
MIN_PER_YEAR = 25              # trades a year a rule must keep in the searched half (pooled picks)
MAX_BAD_YEARS = 2
KEEP, EARN_WALK, TRIPLE_PAIRS, FINALISTS = SL.KEEP, SL.EARN_WALK, SL.TRIPLE_PAIRS, SL.FINALISTS
TOP = 5                        # per exit list, the qualifiers judged on half B
OVERLAP = 0.70
ALPHA = 0.05
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
SPLIT = "2024-01-01"           # v1.0.2: Part B sees only picks whose every price is before this day; the test starts here
RERUNS, RERUN_DROP, RERUN_SEED = 200, 0.02, 11   # v1.0.2 decides: setuplab's reruns (2% of picks dropped, a random
#                                                  start day of the 5), the same draws for both trees -> paired cuts
DD_BLOCK = 21                  # v1.0.2 shown: the day-block bootstrap of the worst fall (a month of sessions per block)
RET_TOL = 5.0                  # v1.0.2: FOUND+WEEKLY's a year may sit at most this many points under FROZEN's
MONTH_START = 3                # v1.0.2: 'month-start entries' = entries in a month's first 3 sessions
GROUP = 8
COST = SU.COST
BITS = SL.BITS
FIRST = SL.FIRST
LOG = SL.say
WD = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


class ADError(Exception):
    pass


def constants():
    return {"salt": SALT, "weekly_names": WEEKLY_RE.pattern, "weekday_bound": WEEKDAY_BOUND, "r13": R13, "r1w": R1W,
            "twins": [[t[0], t[1]] for t in TWINS], "exits": [e[1] for e in EXITS],
            "price_atoms": [[p[0], p[1], list(p[2])] for p in PRICE_ATOMS], "feature_atoms": ["up", "dn", "L3", "H3"],
            "min_per_year": MIN_PER_YEAR, "max_bad_years": MAX_BAD_YEARS, "keep": KEEP, "earn_walk": EARN_WALK,
            "triple_pairs": TRIPLE_PAIRS, "finalists": FINALISTS, "top": TOP, "overlap": OVERLAP, "alpha": ALPHA,
            "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "cost_pp": COST, "tree_slots": SU.TREE_SLOTS,
            "calendar": CALENDAR_RE.pattern, "min_days": MIN_DAYS, "strat_salt": STRAT_SALT,
            "part_d": [[i, [list(c) for c in cc]] for i, _, cc in PART_D],
            "split": SPLIT, "reruns": [RERUNS, RERUN_DROP, RERUN_SEED], "dd_boot": [BOOT_B, DD_BLOCK, BOOT_SEED],
            "ret_tol": RET_TOL, "month_start": MONTH_START}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise ADError("no declaration at %s (it ships beside anydaylab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise ADError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise ADError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def half_of(sym):
    """0 = half A (searched), 1 = half B (hidden): the parity of sha256('anydaylab-v1|SYMBOL')."""
    return int(hashlib.sha256((SALT + "|" + str(sym).strip().upper()).encode()).hexdigest(), 16) % 2


def halves(symbols):
    u = {s: half_of(s) for s in set(symbols)}
    return np.array([u[s] for s in symbols], np.int8)


def is_weekly_name(f):
    return bool(WEEKLY_RE.search(SU.base_name(str(f)).lower()))


def is_calendar_name(f):
    return bool(CALENDAR_RE.search(SU.base_name(str(f)).lower()))


def base_of(field):
    """The panel feature behind a condition field (f, f_change, f_change_prev); None for a price field."""
    if field in SU.PRICE_FIELDS:
        return None
    for suf in ("_change_prev", "_change"):
        if field.endswith(suf):
            return field[:-len(suf)]
    return field


def add_prev_changes(bk, fields):
    """f_change_prev at watch day k = f's change one session earlier (the 'fell twice' half of soullab's moves)."""
    for fld in fields:
        if fld.endswith("_change_prev") and fld not in bk.F:
            src = bk.F.get(fld[:-len("_prev")])
            if src is None:
                continue
            A = np.full(src.shape, np.nan)
            A[:, 1:] = np.asarray(src, float)[:, :-1]
            bk.F[fld] = A


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(), SL.HERE.resolve(),
              SL._SL_DIR.resolve()):
        if o == b or b in o.parents:
            raise ADError("--out %s is inside %s - outputs go under C:\\QuantData\\anydaylab" % (o, b))
    return o


def ledger(out, rec):
    with open(Path(out) / "anydaylab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


# ====================================================================================================== inputs
def twin_frame(root, symbols, log=LOG):
    """The two rolling twins at every close of each stock, from the cache's own daily bars (<SYMBOL>_daily.parquet):
    dw_ret_13w = r65 - r65 five sessions earlier (r65 = close / close 65 sessions before - 1, %), d_ret_5s = close /
    close 5 sessions before - 1 (%). -> (frame symbol / timestamp / twins, symbols without a cache file)."""
    import pyarrow.parquet as pq
    parts, missing = [], []
    for s in sorted(set(symbols)):
        p = Path(root) / ("%s_daily.parquet" % s)
        if not p.is_file():
            missing.append(s)
            continue
        low = {c.lower(): c for c in pq.read_schema(p).names}
        dk = low.get("timestamp") or low.get("date")
        if not dk or "close" not in low:
            missing.append(s)
            continue
        b = pd.read_parquet(p, columns=[dk, low["close"]])
        t = pd.to_datetime(b[dk])
        if t.dt.tz is not None:
            t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        b = pd.DataFrame({"t": t.dt.normalize(), "c": pd.to_numeric(b[low["close"]], errors="coerce")})
        b = b.sort_values("t").drop_duplicates("t", keep="last")
        c = b["c"].to_numpy(float)
        c = np.where(c > 0, c, np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            r65 = np.full(len(c), np.nan)
            r65[R13:] = (c[R13:] / c[:-R13] - 1) * 100
            dw = np.full(len(c), np.nan)
            dw[R1W:] = r65[R1W:] - r65[:-R1W]
            r5 = np.full(len(c), np.nan)
            r5[R1W:] = (c[R1W:] / c[:-R1W] - 1) * 100
        parts.append(pd.DataFrame({"symbol": s, "timestamp": b["t"].to_numpy(), "dw_ret_13w": dw, "d_ret_5s": r5}))
    F = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(
        columns=["symbol", "timestamp", "dw_ret_13w", "d_ret_5s"])
    log(" twins: %d stocks from the cache's daily bars, %d without a cache file" % (len(parts), len(missing)))
    return F, missing


def load_book(data, panel, soul, pcols, scols, exact, root, log=LOG):
    """setuplab's Book of every pick (D and ENS, every rank) with each feature at the session before each watch day
    (column 0 = the session before the signal day); search-only columns kept as float32, the frozen setups' and the
    twins' columns as float64 (exact replays)."""
    data = Path(data)
    for nm in ("watchlist.parquet", "calendar.parquet"):
        if not (data / nm).is_file():
            raise ADError("no %s in %s (setuplab build writes the watchlist folder)" % (nm, data))
    wl = pd.read_parquet(data / "watchlist.parquet")
    cal = pd.read_parquet(data / "calendar.parquet")["date"]
    book = SU.Book(wl, cal, None, None, None, None)
    book.prev_session = True
    missing = []
    for src, cols, nm in ((panel, pcols, "the panel"), (soul, scols, "Soul")):
        t0 = time.time()
        for s in range(0, len(cols), GROUP):
            got, ms = book.attach(src, cols[s:s + GROUP], chunk=GROUP)
            missing += ms
            for c in got:
                if c in exact:
                    continue
                for k in (c, c + "_change"):
                    if k in book.F and book.F[k].dtype != np.float32:
                        book.F[k] = book.F[k].astype(np.float32)
            if (s // GROUP) % 5 == 4 or s + GROUP >= len(cols):
                log(" read %s: %d of %d columns (%.0f s)" % (nm, min(s + GROUP, len(cols)), len(cols), time.time() - t0))
    tw, tmiss = twin_frame(root, book.symbols, log)
    if len(tw):
        first = pd.Timestamp(book.cal[max(0, int(book.i1.min()) - 2)]) - pd.Timedelta(days=200)
        book._join(tw, list(TWIN_FEATS), append=True, min_date=first)
    else:
        for f in TWIN_FEATS:
            book.F[f] = np.full((book.n, SU.WATCH + 1), np.nan)
            book.F[f + "_change"] = np.full((book.n, SU.WATCH + 1), np.nan)
            book.features = list(book.features) + [f]
    return book, missing, tmiss


def complete_rows(bk):
    """Settled picks with every D1-D5 open and D1-D9 close (both exits of every entry day are known)."""
    with np.errstate(invalid="ignore"):
        return (bk.ok & np.isfinite(bk.O[:, 1:6]).all(1) & np.isfinite(bk.C[:, 1:10]).all(1) & (bk.O[:, 1] > 0))


def pooled_rows(bk, ok):
    """One row per (signal day, stock): a stock picked by both engines (or twice) counts once - its best rank, D first."""
    key = np.char.add(np.char.add(pd.DatetimeIndex(bk.signal_day).strftime("%Y-%m-%d").to_numpy().astype(str), "|"),
                      bk.symbols.astype(str))
    eo = np.where(bk.engine_arr == "D", 0, np.where(bk.engine_arr == "ENS", 1, 2))
    idx = np.flatnonzero(ok)
    o = idx[np.lexsort((eo[idx], bk.rank[idx], key[idx]))]
    ks = key[o]
    first = o[np.r_[True, ks[1:] != ks[:-1]]] if len(o) else o
    return np.sort(first), key


def weekday_bound(bk, R, feats):
    """For each feature: the largest share of its non-zero changes (at the sessions the watch reads) that fall on one
    weekday. Weekly values change on the week's first session (Monday) only."""
    j = np.clip(bk.i1[R][:, None] + np.arange(0, SU.WATCH + 1)[None, :] - 2, 0, len(bk.cal) - 1)
    wd = pd.DatetimeIndex(bk.cal[j.ravel()]).weekday.to_numpy().reshape(j.shape)
    out = {}
    for f in feats:
        ch = np.asarray(bk.F[f + "_change"][R], float)
        m = np.isfinite(ch) & (ch != 0)
        if m.sum() < 50:
            out[f] = (np.nan, -1)
            continue
        sh = np.bincount(wd[m], minlength=7) / m.sum()
        out[f] = (float(sh.max()), int(sh.argmax()))
    return out


def session_of_month(cal):
    """For every calendar index: its place in its month (1 = the month's first session)."""
    per = pd.DatetimeIndex(cal).to_period("M").to_numpy()
    start = np.r_[True, per[1:] != per[:-1]]
    first = np.maximum.accumulate(np.where(start, np.arange(len(per)), 0))
    return np.arange(len(per)) - first + 1


def month_bound(bk, R, feats, som=None):
    """v1.0.2. For each feature: the share of its non-zero changes (at the sessions the watch reads) that fall on a
    month's first session. Soul's memory is rebuilt monthly, so a memory count (soul_m_self_n) changes only there."""
    som = session_of_month(bk.cal) if som is None else som
    j = np.clip(bk.i1[R][:, None] + np.arange(0, SU.WATCH + 1)[None, :] - 2, 0, len(bk.cal) - 1)
    first = som[j] == 1
    out = {}
    for f in feats:
        ch = np.asarray(bk.F[f + "_change"][R], float)
        m = np.isfinite(ch) & (ch != 0)
        out[f] = float(first[m].mean()) if m.sum() >= 50 else np.nan
    return out


def before_split(bk, rows):
    """v1.0.2: picks whose every price the search reads (D1-D5 opens, D1-D9 closes) is before SPLIT."""
    rows = np.asarray(rows, int)
    last = np.clip(bk.i1[rows] + 8, 0, len(bk.cal) - 1)
    return (np.asarray(bk.cal[last]).astype("datetime64[D]") < np.datetime64(SPLIT)) & (bk.i1[rows] + 8 < len(bk.cal))


def after_split(bk, rows):
    """v1.0.2: picks with a signal day on or after SPLIT (the test window's picks)."""
    rows = np.asarray(rows, int)
    return np.asarray(bk.signal_day[rows]).astype("datetime64[D]") >= np.datetime64(SPLIT)


# ====================================================================================================== rules
def canon(conds):
    return tuple(sorted((str(f), str(op), round(float(v), 9)) for f, op, v in conds))


class Ctx:
    """The book, its replays (cached by rule) and the populations."""

    def __init__(self, bk):
        self.bk = bk
        self.cache = {}
        self.som = session_of_month(bk.cal)          # v1.0.2: each session's place in its month

    def rep(self, conds):
        k = canon(conds)
        if k not in self.cache:
            day, st = SU.trigger(self.bk, list(conds))
            nets = {mode: SU.exits_arr(self.bk, day, st, mode)["ret"] for _, mode, _ in EXITS}
            self.cache[k] = (np.where(st == "Filled", day, 0).astype(np.int64), nets)
        return self.cache[k]


def lane(ctx, rules):
    """Each pick's earliest fill among the rules (a tie: the first in the list) -> (day, nets at both exits)."""
    bk = ctx.bk
    day = np.zeros(bk.n, np.int64)
    for c in rules:
        d, _ = ctx.rep(c)
        better = (d > 0) & ((day == 0) | (d < day))
        day[better] = d[better]
    st = np.where(day > 0, "Filled", "No entry")
    nets = {mode: SU.exits_arr(bk, day, st, mode)["ret"] for _, mode, _ in EXITS}
    return day, nets


def twin_conds(conds, feat):
    """The frozen setup's conditions with its weekly condition swapped for the twin (feat < 0)."""
    out, n = [], 0
    for f, op, v in conds:
        if is_weekly_name(f):
            out.append((feat, "<", 0.0))
            n += 1
        else:
            out.append((f, op, float(v)))
    if n != 1:
        raise ADError("a weekly setup has %d weekly conditions (expected 1): %s" % (n, conds))
    return out


def feature_atoms(feats, soulset, bk, refR):
    """Four conditions per feature, read at the close before the entry: rose, fell, low third, high third (the cut-offs:
    thirds of the searched picks' values at the signal close); for the twins also below 0."""
    A = []
    for f in feats:
        fam = "F|" + f
        tag = " [Soul]" if f in soulset else ""
        A.append({"id": f + ":up", "fam": fam, "cond": (f + "_change", ">", 0.0), "soul": f in soulset,
                  "words": "%s rose%s" % (f, tag)})
        A.append({"id": f + ":dn", "fam": fam, "cond": (f + "_change", "<", 0.0), "soul": f in soulset,
                  "words": "%s fell%s" % (f, tag)})
        x = np.asarray(bk.F[f][refR, 1], float)
        x = x[np.isfinite(x)]
        if len(x) >= 30:
            q = np.quantile(x, [1 / 3, 2 / 3])
            A.append({"id": f + ":L3", "fam": fam, "cond": (f, "<=", float(q[0])), "soul": f in soulset,
                      "words": "%s in its low third (<= %.6g)%s" % (f, q[0], tag)})
            A.append({"id": f + ":H3", "fam": fam, "cond": (f, ">", float(q[1])), "soul": f in soulset,
                      "words": "%s in its high third (> %.6g)%s" % (f, q[1], tag)})
        if f in TWIN_FEATS:
            w = dict((t[1], t[2]) for t in TWINS)[f]
            A.append({"id": f + "<0", "fam": fam, "cond": (f, "<", 0.0), "soul": False, "words": w})
    return A


def price_atoms():
    return [{"id": i, "fam": fam, "cond": tuple(c), "soul": False, "words": w} for i, fam, c, w in PRICE_ATOMS]


def masks(bk, R, atoms):
    """(atoms, picks) uint8: bit k-1 = the condition holds at the open of watch day k (setuplab's reading and
    rounding; a missing value = not this day) and the session exists."""
    sess = np.isfinite(bk.O[R, 1:SU.WATCH + 1])
    DM = np.zeros((len(atoms), len(R)), np.uint8)
    last = (None, None)
    for i, a in enumerate(atoms):
        fld, op, val = a["cond"]
        if last[0] != fld:
            last = (fld, bk.field(fld)[R][:, 1:SU.WATCH + 1])
        V = last[1]
        nan = np.isnan(V)
        r = SU.OPS[op](np.round(np.where(nan, 0, V), 9), round(float(val), 9))
        ok = ~nan & r & sess
        DM[i] = (ok.astype(np.uint8) * BITS).sum(1).astype(np.uint8)
    return DM


def tl_tables(bk, R):
    """Net (%, after 0.35) for an entry at the open of watch day k (rows k-1) at each exit; row 5 = no entry (0)."""
    O, C = bk.O[R], bk.C[R]
    out = {}
    with np.errstate(invalid="ignore", divide="ignore"):
        no = np.vstack([(C[:, 5] / O[:, k] - 1) * 100 - COST for k in range(1, 6)] + [np.zeros(len(R))])
        nf = np.vstack([(C[:, k + 4] / O[:, k] - 1) * 100 - COST for k in range(1, 6)] + [np.zeros(len(R))])
    for nm, T in (("original_d5", no), ("fresh", nf)):
        T = T.copy()
        T[~np.isfinite(T)] = 0.0
        out[nm] = T
    return out


def conds_of(atoms, c):
    return [tuple(atoms[x]["cond"]) for x in c]


# ====================================================================================================== numbers
def pval(diff, sd):
    """One-sided p that the true difference is above 0 (normal approximation from the bootstrap standard deviation)."""
    if not np.isfinite(diff):
        return 1.0
    if not (sd > 0):                  # v1.0.1: resamples without spread prove nothing
        return 1.0
    return float(0.5 * math.erfc((diff / sd) / math.sqrt(2.0)))


class Pop:
    """A population of pooled picks (rows of the book) with its days, bootstrap and the WEEKLY lane's trades."""

    def __init__(self, ctx, rows, wk_day, wk_nets, name):
        bk = ctx.bk
        self.name, self.rows = name, np.asarray(rows, int)
        self.day = bk.signal_day[self.rows].astype("datetime64[D]")
        self.days = np.unique(self.day)
        self.di = np.searchsorted(self.days, self.day)
        self.nd = len(self.days)
        self.year = self.day.astype("datetime64[Y]").astype(int) + 1970
        self.years = SU._years(self.day) if len(self.day) else 0.5
        self.boot = SU.Boot(self.day, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED) if self.nd >= 2 else None
        self.bdi = self.boot.index(self.day) if self.boot is not None else None
        self.wk_day = wk_day[self.rows]
        self.wk = {m: wk_nets[m][self.rows] for _, m, _ in EXITS}

    def stats(self, ctx, conds, mode, versus=True, sub_rules=()):
        """The rule's trades in this population: n, a year, mean, 95%, vs WEEKLY (difference, 95%, p), years,
        entry days and weekdays, and (sub_rules) whether each condition earns its place."""
        bk = ctx.bk
        day, nets = ctx.rep(conds)
        d = day[self.rows]
        v = nets[mode][self.rows]
        m = (d > 0) & np.isfinite(v)
        n = int(m.sum())
        r = {"n": n, "per_year": n / self.years, "mean": float(v[m].mean()) if n else np.nan,
             "days": int(len(np.unique(self.day[m]))) if n else 0}
        r["lo"], r["hi"] = SL._ci(self.boot, self.bdi, np.where(m, v, np.nan)) if self.boot is not None and n >= 2 \
            else (np.nan, np.nan)
        r["entry_day"] = float(d[m].mean()) if n else np.nan
        ei = np.clip(bk.i1[self.rows][m] + d[m] - 1, 0, len(bk.cal) - 1)
        ent = bk.cal[ei]
        wd = pd.DatetimeIndex(ent).weekday.to_numpy() if n else np.zeros(0, int)
        r["weekdays"] = {WD[i]: float((wd == i).mean()) for i in range(5)} if n else {}
        r["tuesday_share"] = float((wd == 1).mean()) if n else np.nan
        r["month_start_share"] = float((ctx.som[ei] <= MONTH_START).mean()) if n else np.nan
        if n:
            u = np.unique(self.year[m])
            r["years_n"] = int(len(u))
            r["bad_years"] = int(sum(float(v[m][self.year[m] == y].mean()) <= 0 for y in u))
        else:
            r["years_n"], r["bad_years"] = 0, 0
        r["keys"] = set(np.flatnonzero(m).tolist())
        if versus:
            w = self.wk[mode]
            wm = (self.wk_day > 0) & np.isfinite(w)
            r["wk_n"], r["wk_mean"] = int(wm.sum()), float(w[wm].mean()) if wm.any() else np.nan
            if self.boot is not None and n >= 2 and wm.sum() >= 2:
                lo, hi, sd = self.boot.ci_diff(self.bdi[m], v[m], self.bdi[wm], w[wm])
            else:
                lo, hi, sd = np.nan, np.nan, np.nan
            r["diff"] = r["mean"] - r["wk_mean"] if n and wm.any() else np.nan
            r["diff_lo"], r["diff_hi"], r["diff_sd"] = lo, hi, sd
            r["p"] = pval(r["diff"], sd)
        if sub_rules:
            los = []
            for sc in sub_rules:
                ds, ns = ctx.rep(sc)
                xs = (ds[self.rows] > 0) & np.isfinite(ns[mode][self.rows]) & ~m
                if self.boot is not None and n >= 2 and xs.sum() >= 2:
                    los.append(self.boot.ci_diff(self.bdi[m], v[m], self.bdi[xs], ns[mode][self.rows][xs])[0])
                else:
                    los.append(-np.inf if xs.sum() >= 2 or n < 2 else np.inf)
            r["earn_lo"] = float(np.min(los)) if los else np.inf
        else:
            r["earn_lo"] = np.inf
        return r


def adds(ctx, pop, conds, mode):
    """Each condition's own contribution in a population: the rule's trades minus the trades its simpler version (that
    condition dropped) adds, 95% interval. -> [(condition in words, difference, lo, hi)]"""
    if len(conds) < 2:
        return []
    day, nets = ctx.rep(conds)
    v = nets[mode][pop.rows]
    m = (day[pop.rows] > 0) & np.isfinite(v)
    out = []
    for i in range(len(conds)):
        sub = conds[:i] + conds[i + 1:]
        ds, ns = ctx.rep(sub)
        vs = ns[mode][pop.rows]
        x = (ds[pop.rows] > 0) & np.isfinite(vs) & ~m
        if pop.boot is None or m.sum() < 2 or x.sum() < 2:
            out.append((words([conds[i]]), np.nan, np.nan, np.nan))
            continue
        lo, hi, _ = pop.boot.ci_diff(pop.bdi[m], v[m], pop.bdi[x], vs[x])
        out.append((words([conds[i]]), float(v[m].mean() - vs[x].mean()), lo, hi))
    return out


def verdict(r, thr):
    if not np.isfinite(r.get("diff", np.nan)) or r.get("days", 0) < MIN_DAYS or not (r.get("diff_sd", 0) > 0):
        return "TOO FEW"
    if r["p"] <= thr and r["diff_lo"] > 0:
        return "BETTER"
    if r["diff_hi"] < 0:
        return "WORSE"
    return "TIE"


# ====================================================================================================== the search
def search(ctx, popA, atoms, DMa, TLa, mode, log=LOG):
    """Singles, pairs (different families) and the best earning pairs with a third condition on half A; the first
    FINALISTS rules whose every condition earns its place get the exact replay (setuplab's trigger) and the
    qualification."""
    fam = SL.fam_ids(atoms)
    min_n = MIN_PER_YEAR * popA.years
    S = SL.screen_trigger(DMa, TLa, fam, min_n, KEEP, log)

    def earnf(c):
        return SL.earn_quick_trig(DMa, c, TLa, popA.di, popA.nd)
    pairs, _, w0 = SL.walk([S["pairs"]], min_n, TRIPLE_PAIRS, earnf, size=2)
    T3 = SL.screen_trigger_triples(DMa, TLa, fam, pairs, min_n, KEEP)
    fin, qb, w1 = SL.walk([S["singles"], S["pairs"], T3], min_n, FINALISTS, earnf)
    rows = []
    for c, q in zip(fin, qb):
        cc = conds_of(atoms, c)
        subs = [conds_of(atoms, c[:d] + c[d + 1:]) for d in range(len(c))] if len(c) > 1 else []
        r = popA.stats(ctx, cc, mode, True, subs)
        r.update({"cand": c, "screen_lb": q})
        r["qualifies"] = bool(r["per_year"] >= MIN_PER_YEAR and r["lo"] > 0 and r["mean"] > r["wk_mean"]
                              and r["bad_years"] <= MAX_BAD_YEARS and (len(c) == 1 or r["earn_lo"] > 0)
                              and r["days"] >= MIN_DAYS)
        r["score"] = r["lo"]
        rows.append(r)
    cnt = {"atoms": len(atoms), "singles": int(np.isfinite(S["singles"]["lb"]).sum()),
           "pairs_kept": len(S["pairs"]["lb"]) if S["pairs"] is not None else 0,
           "triples_kept": len(T3["lb"]) if T3 is not None else 0, "earn_checked": w0 + w1, "finalists": len(rows),
           "qualify": int(sum(r["qualifies"] for r in rows)), "min_n": min_n}
    rows.sort(key=lambda r: (not r["qualifies"], -(r["score"] if np.isfinite(r["score"]) else -1e9)))
    return rows, cnt


def is_version(a, b, fam):
    """Versions of one setup: the conditions' families a subset / superset, two of three families shared, or 70% of
    the trades shared."""
    ca, cb = {int(fam[x]) for x in a["cand"]}, {int(fam[x]) for x in b["cand"]}
    if ca <= cb or cb <= ca or (max(len(a["cand"]), len(b["cand"])) == 3 and len(ca & cb) >= 2):
        return True
    ka, kb = a["keys"], b["keys"]
    return len(ka & kb) / max(1, min(len(ka), len(kb))) >= OVERLAP


def pick_top(rows, fam, k=TOP):
    out = []
    for r in rows:
        if not r["qualifies"]:
            continue
        if any(is_version(r, x, fam) for x in out):
            continue
        out.append(r)
        if len(out) == k:
            break
    return out


# ====================================================================================================== the split (v1.0.2)
def worst_fall(v):
    """The worst fall of a value path, % (marked to market: the value against its running peak)."""
    v = np.asarray(v, float)
    if len(v) == 0:
        return np.nan
    return float(100 * np.max(1 - v / np.maximum.accumulate(v)))


def dd_boot(a, b, B=BOOT_B, block=DD_BLOCK, seed=BOOT_SEED):
    """The worst-fall cut of path b against path a (a's worst fall minus b's, points; above 0 = b falls less), with a
    paired circular block bootstrap: each draw strings together blocks of `block` consecutive sessions' daily log
    returns - the SAME sessions for both paths - rebuilds both paths and takes each one's worst fall.
    -> (cut, 2.5th and 97.5th percentiles of the draws' cuts, share of draws with b falling less)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    obs = worst_fall(a) - worst_fall(b)
    with np.errstate(divide="ignore", invalid="ignore"):
        ra = np.diff(np.log(np.maximum(a, 1e-12)))
        rb = np.diff(np.log(np.maximum(b, 1e-12)))
    n = len(ra)
    if n < 2 or not (np.isfinite(ra).all() and np.isfinite(rb).all()):
        return obs, np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    nb = int(np.ceil(n / block))
    st = rng.integers(0, n, size=(B, nb))
    ix = ((st[:, :, None] + np.arange(block)[None, None, :]) % n).reshape(B, -1)[:, :n]

    def falls_of(r):
        v = np.concatenate([np.zeros((r.shape[0], 1)), np.cumsum(r, axis=1)], axis=1)
        return 100 * (1 - np.exp(v - np.maximum.accumulate(v, axis=1))).max(axis=1)
    cut = falls_of(ra[ix]) - falls_of(rb[ix])
    return float(obs), float(np.percentile(cut, 2.5)), float(np.percentile(cut, 97.5)), float((cut > 0).mean())


def falls(v, days, k=3):
    """The k deepest separate falls of a value path: (depth %, the peak's day, the trough's day, the day it was back at
    the peak or None)."""
    v = np.asarray(v, float)
    pk = np.maximum.accumulate(v)
    under = v < pk * (1 - 1e-12)
    out, i, n = [], 0, len(v)
    while i < n:
        if not under[i]:
            i += 1
            continue
        j = i
        while j < n and under[j]:
            j += 1
        seg = np.arange(i, j)
        dd = 1 - v[seg] / pk[seg]
        t = int(seg[int(np.argmax(dd))])
        out.append((float(100 * dd.max()), days[max(i - 1, 0)], days[t], days[j] if j < n else None))
        i = j
    out.sort(key=lambda x: -x[0])
    return out[:k]


def split_verdict(fz, fw, cut_lo, ret_tol=RET_TOL):
    """The declared decision. fz, fw: FROZEN's and FOUND+WEEKLY's (a year, worst fall) on each of the 5 start days of
    the test window (both books); cut_lo: the lower end of the worst-fall cut's 95% interval.
    -> (CONFIRMED / LEAD / DEAD, the three conditions)"""
    if not fw or not fz or len(fw) != len(fz):
        return "DEAD", {"lower_all": False, "ret_ok": False, "interval_above_0": False, "why": "no FOUND+WEEKLY"}
    lower_all = all(np.isfinite(b) and np.isfinite(a) and b < a for (_, a), (_, b) in zip(fz, fw))
    ay_fz = float(np.mean([x for x, _ in fz]))
    ay_fw = float(np.mean([x for x, _ in fw]))
    ret_ok = bool(np.isfinite(ay_fw) and ay_fw >= ay_fz - ret_tol)
    above = bool(np.isfinite(cut_lo) and cut_lo > 0)
    c = {"lower_all": bool(lower_all), "ret_ok": ret_ok, "interval_above_0": above, "a_year_frozen": ay_fz,
         "a_year_found_weekly": ay_fw}
    if lower_all and ret_ok:
        return ("CONFIRMED" if above else "LEAD"), c
    return "DEAD", c


# ====================================================================================================== the tree's money
def first_fill(su, order, primary, i1):
    """setuplab's tree_first_setup for any setups: su = {id: (filled, watch day, net at the primary exit)}; the
    earliest fill per pick (a tie: the order) -> id, day, entry index, exit index, net."""
    n = len(i1)
    sid = np.full(n, "", dtype=object)
    sk = np.zeros(n, dtype=np.int64)
    snet = np.full(n, np.nan)
    for s_ in order:
        f, k, net = su[s_]
        k = np.asarray(k, float)
        f = np.asarray(f, bool) & np.isfinite(k)
        better = f & ((sk == 0) | (np.where(f, k, 1e9) < sk))
        sid[better], sk[better], snet[better] = s_, k[better].astype(np.int64), np.asarray(net, float)[better]
    has = sk > 0
    ent = np.where(has, np.asarray(i1) + sk - 1, -1)
    ex = np.full(n, -1, dtype=np.int64)
    for s_ in order:
        m = has & (sid == s_)
        ex[m] = np.where(primary[s_] == "fresh", ent[m] + 4, np.asarray(i1)[m] + 4)
    return sid, sk, ent, ex, snet


def tree_picks(bk, su, order, primary, tdoc, cuts):
    """setuplab's tree_history_picks with the setups given (not read from a TAGS run)."""
    sid, sk, sent, sex, snet = first_fill(su, order, primary, bk.i1)
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    lane_ = SU.tree_lanes(bk.atr, years, cuts)
    O1, C5 = bk.O[:, 1], bk.C[:, 5]
    P = pd.DataFrame({"trade_id": bk.ids, "engine": bk.engine_arr, "rank": bk.rank, "symbol": bk.symbols,
                      "sday": bk.signal_day, "i1": bk.i1, "o1": O1, "sc": bk.sc, "c5": C5, "s_atr14": bk.atr,
                      "lane": lane_, "etf": SU.tree_etf(bk.symbols, tdoc), "complete": SU.tree_complete(bk),
                      "su_id": sid, "su_k": sk, "su_ent": sent, "su_ex": sex,
                      "su_net": np.where(sk > 0, snet, np.nan)})
    return P


def su_of(ctx, rules, primary):
    """{id: (filled, watch day, net at the primary exit)} from the exact replays on the whole book."""
    out = {}
    for sid, c in rules.items():
        d, nets = ctx.rep(c)
        out[sid] = (d > 0, np.where(d > 0, d, np.nan), nets[primary[sid]])
    return out


def tree_cuts(bk, tdoc):
    comp = SU.tree_complete(bk)
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    declared = {int(k): float(v) for k, v in tdoc["lane"]["cutoffs"].items()}
    cuts = {}
    for y in sorted(set(int(x) for x in years)):
        v, _ = SU.tree_cutoff(bk.atr, bk.signal_day, comp, y)
        if np.isfinite(v):
            cuts[y] = v
        elif y in declared:
            cuts[y] = declared[y]
    return cuts


BOTH = "both trees (Rs 2.5 L each)"


def rerun_cut(rr_base, rr_other):
    """v1.0.2. Paired reruns (setuplab's tree_history with the same seed: the same start day and the same 2% of picks
    dropped in rerun d for both trees): each rerun's worst-fall cut = the base's worst fall minus the other's (both books).
    -> (median, 2.5th, 97.5th percentile, share of reruns with the other falling less)"""
    if not rr_base or not rr_other or len(rr_base) != len(rr_other):
        return np.nan, np.nan, np.nan, np.nan
    c = np.array([a[1] - b[1] for a, b in zip(rr_base, rr_other)], float)
    c = c[np.isfinite(c)]
    if not len(c):
        return np.nan, np.nan, np.nan, np.nan
    return float(np.median(c)), float(np.percentile(c, 2.5)), float(np.percentile(c, 97.5)), float((c > 0).mean())


def tree_money(ctx, variants, tdoc, log=LOG, start=None, t1=None, reruns_for=()):
    """Each variant's tree books (setuplab's tree_plan / tree_sim on 5 start days) from the first cut-off year (or, v1.0.2,
    from the first session on or after `start`, picks with a signal day from then on) to the end of the FROZEN variant's
    trades (or t1); the daily difference of the two-book value against FROZEN (start day 1, 95% block bootstrap over
    days) and (v1.0.2) the worst-fall cut against FROZEN: the mean of the 5 start days, the paired reruns' interval
    (for the trees in reruns_for and FROZEN) and the day-block bootstrap of start day 1. Keeps each start day's numbers
    and the start-day-1 daily values of D tree, ENS tree and both."""
    bk = ctx.bk
    cuts = tree_cuts(bk, tdoc)
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    lane_years = sorted(y for y in cuts if (years == y).any())
    if not lane_years:
        raise ADError("no year of the watchlist has a tree cut-off")
    if start is None:
        s_ = int(np.searchsorted(bk.cal, np.datetime64("%d-01-01" % lane_years[0])))
    else:
        s_ = int(np.searchsorted(bk.cal, np.datetime64(start)))
    if s_ >= len(bk.cal):
        raise ADError("no session on or after %s" % start)
    out, curves = {}, {}
    for name, (rules, order, primary) in variants.items():
        P = tree_picks(bk, su_of(ctx, rules, primary), order, primary, tdoc, cuts)
        books, plan = SU.tree_run_books(P, bk, s_)
        if t1 is None:
            t1 = int(min(len(bk.cal) - 1, max(int(b[0]["ex"].max()) for b in books.values() if len(b[0]))))
        if t1 <= s_ + 5:
            raise ADError("the window %s .. %s is too short" % (pd.Timestamp(bk.cal[s_]).date(),
                                                                 pd.Timestamp(bk.cal[t1]).date()))
        nre = RERUNS if (name in reruns_for or (reruns_for and name == "FROZEN")) else 0
        res, rr, taken = SU.tree_history(bk, P, books, s_, t1, reruns=nre, seed=RERUN_SEED, log=lambda *a: None)
        eq = {}
        for nm in SU.TREE_BOOKS:
            T_, prow = books[nm]
            eq[nm] = SU.tree_sim(T_, prow, bk.O, bk.C, bk.i1, s_, t1)[1]
        curves[name] = 0.5 * eq["D tree"] + 0.5 * eq["ENS tree"]
        via = {}
        for e in ("D", "ENS"):
            tk = taken[e + " tree"]
            via[e] = {"trades": int(len(tk)), "via_setups": int((tk["how"] != "open").sum()),
                      "setup_net": float(tk.loc[tk["how"] != "open", "net"].mean()) if (tk["how"] != "open").any()
                      else np.nan}
        out[name] = {"res": {g: {k: float(np.mean([d.get(k, np.nan) for d in L])) for k in
                                 ("a_year", "fall", "end", "per_week", "mean")} for g, L in res.items()}, "via": via,
                     "per_start": {g: [(float(d["a_year"]), float(d["fall"])) for d in L] for g, L in res.items()},
                     "eq": {"D tree": eq["D tree"], "ENS tree": eq["ENS tree"], "both": curves[name]},
                     "rr": [(float(x), float(y)) for x, y in rr[BOTH]] if nre else []}
        log(" money: %-15s D tree %+.1f%% a year (worst fall %.1f%%), ENS tree %+.1f%% (%.1f%%), both %+.1f%% (%.1f%%)" % (
            name, out[name]["res"]["D tree"]["a_year"], out[name]["res"]["D tree"]["fall"],
            out[name]["res"]["ENS tree"]["a_year"], out[name]["res"]["ENS tree"]["fall"],
            out[name]["res"][BOTH]["a_year"], out[name]["res"][BOTH]["fall"]))
    days = bk.cal[s_:t1 + 1]
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    base = curves.get("FROZEN")
    for name in out:
        if base is None or name == "FROZEN":
            out[name]["vs_frozen"] = (np.nan, np.nan, np.nan)
            out[name]["cut"] = (np.nan, np.nan, np.nan, np.nan)
            out[name]["cut_rr"] = (np.nan, np.nan, np.nan, np.nan)
            out[name]["cut_mean"] = np.nan
            continue
        with np.errstate(invalid="ignore", divide="ignore"):
            x = np.diff(np.log(np.maximum(curves[name], 1e-12))) - np.diff(np.log(np.maximum(base, 1e-12)))
        x = np.r_[0.0, x] * 1e4
        lo, hi = B_.ci_idx(np.arange(len(x)), x)
        out[name]["vs_frozen"] = (float(x.mean()), lo, hi)
        out[name]["cut"] = dd_boot(base, curves[name])                       # shown: re-ordered history
        out[name]["cut_rr"] = rerun_cut(out["FROZEN"]["rr"], out[name]["rr"])  # decides: paired reruns
        out[name]["cut_mean"] = float(out["FROZEN"]["res"][BOTH]["fall"] - out[name]["res"][BOTH]["fall"])
    window = [str(pd.Timestamp(bk.cal[s_]).date()), str(pd.Timestamp(bk.cal[t1]).date())]
    ref = tdoc.get("history_reference", {})
    fr = out.get("FROZEN", {}).get("res", {})
    ok = bool(fr) and window == ref.get("window") and all(
        abs(fr[g]["a_year"] - ref[g]["a_year_pct"]) <= SU.TREE_TOL and abs(fr[g]["fall"] - ref[g]["worst_fall_pct"])
        <= SU.TREE_TOL for g, _ in SU.TREE_GROUPS if g in ref and g in fr)
    return out, {"window": window, "reconciled": ok, "cuts": cuts, "days": days, "s_": s_, "t1": t1}


# ====================================================================================================== report
def _p(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "-"
    return ("%+." + str(nd) + "f") % x if sign else ("%." + str(nd) + "f") % x


def _ci(lo, hi, nd=2):
    return "[%s, %s]" % (_p(lo, nd), _p(hi, nd))


def words(conds):
    out = []
    for f, op, v in conds:
        hit = next((p for p in PRICE_ATOMS if tuple(p[2]) == (f, op, float(v))), None)
        if hit:
            out.append(hit[3])
            continue
        if f.endswith("_change_prev"):
            out.append("%s %s the session before" % (f[:-len("_change_prev")], "rose" if op in (">", ">=") else "fell"))
            continue
        if f in TWIN_FEATS and op == "<" and float(v) == 0:
            out.append(dict((t[1], t[2]) for t in TWINS)[f])
            continue
        base = SU.base_name(f)
        if f.endswith("_change"):
            out.append("%s %s" % (base, "rose" if op in (">", ">=") and float(v) >= 0 else "fell" if
                                   op in ("<", "<=") and float(v) <= 0 else "%s %g" % (op, v)))
        else:
            out.append("%s %s %.6g" % (f, op, v))
    return " AND ".join(out)


def wd_text(r):
    w = r.get("weekdays") or {}
    return " ".join("%s %.0f%%" % (k, 100 * v) for k, v in w.items()) if w else "-"


def _yn(x):
    return "**yes**" if x else "**no**"


def money_table(books, base_note):
    """Part C's table for one window: every tree's books, the daily difference and the worst-fall cut vs FROZEN."""
    L = ["| tree | D: a year, worst fall | ENS: a year, worst fall | both (Rs 2.5 L each): a year, worst fall | "
         "trades a week (both) | both vs FROZEN, bp a day [95%%] | both: worst-fall cut vs FROZEN, points [95%%, %d "
         "paired reruns] | the cut with history re-ordered [95%%] |" % RERUNS,
         "|---|---|---|---|---:|---|---|---|"]
    for name, r in books.items():
        g = r["res"]
        both = g[BOTH]
        vf, ct, cr = r["vs_frozen"], r["cut"], r["cut_rr"]
        L.append("| %s | %+.1f%%, %.1f%% | %+.1f%%, %.1f%% | %+.1f%%, %.1f%% | %.2f | %s | %s | %s |" % (
            name, g["D tree"]["a_year"], g["D tree"]["fall"], g["ENS tree"]["a_year"], g["ENS tree"]["fall"],
            both["a_year"], both["fall"], both["per_week"],
            "-" if name == "FROZEN" else "%s %s" % (_p(vf[0]), _ci(vf[1], vf[2])),
            "-" if name == "FROZEN" else ("%s %s" % (_p(r["cut_mean"]), _ci(cr[1], cr[2])) if np.isfinite(cr[1])
                                          else _p(r["cut_mean"])),
            "-" if name == "FROZEN" else "%s %s" % (_p(ct[0]), _ci(ct[1], ct[2]))))
    L += ["", base_note, ""]
    return L


def write_report(d, info, A, B, C, checks, Dp=None, T=None):
    L = ["# %s - setups for any weekday vs the tree's weekly setups, with the 2024 split (%s)" % (VERSION, d.name), "",
         "Karan, 22 Nov 2026: *\"Non Tuesday(weekly) setups which are better than weekly setups. Find.\"* - then, on "
         "FOUND+WEEKLY's smaller worst fall in ANYDAY_20261122_001: *\"Go\"* (search before 2024, test on 2024-26). "
         "Rules: `ANYDAY_DECLARATION.json` sha256 `%s` (declared before any run). Picks: %s." % (
             info["declaration_sha256"][:16], info["picks"]), ""]
    if T is not None:
        tb, sc = T["books"], T["conds"]
        fz = tb["FROZEN"]["per_start"][BOTH]
        fw = tb["FOUND+WEEKLY"]["per_start"][BOTH] if "FOUND+WEEKLY" in tb else None
        L += ["## THE DECISION - does FOUND+WEEKLY cut the worst fall in %s .. %s? **%s**" % (
                  T["window"][0], T["window"][1], T["verdict"]), "",
              "Declared before the run. Part B searched and judged only picks whose every price is before %s; both "
              "trees then started again with Rs 5 L a book on %s and ran to %s - days no found setup saw. Both books "
              "together (Rs 2.5 L each):" % (SPLIT, T["window"][0], T["window"][1]), ""]
        if fw is None:
            L += ["**DEAD: no setup was found before %s, so there is nothing to add to the weekly ones.**" % SPLIT, ""]
        else:
            L += ["| start day | FROZEN: a year, worst fall | FOUND+WEEKLY: a year, worst fall | worst fall lower |",
                  "|---|---|---|---|"]
            days = T.get("start_days") or []
            for i, (a_, b_) in enumerate(zip(fz, fw)):
                L.append("| %d%s | %+.1f%%, %.1f%% | %+.1f%%, %.1f%% | %s |" % (
                    i + 1, (" (%s)" % days[i]) if i < len(days) else "", a_[0], a_[1], b_[0], b_[1],
                    "yes" if b_[1] < a_[1] else "no"))
            L.append("| mean | %+.1f%%, %.1f%% | %+.1f%%, %.1f%% | |" % (
                np.mean([x[0] for x in fz]), np.mean([x[1] for x in fz]), np.mean([x[0] for x in fw]),
                np.mean([x[1] for x in fw])))
            ct, cr = sc["cut"], sc["cut_rr"]
            L += ["",
                  "- Worst fall lower on all 5 start days: %s" % _yn(sc["lower_all"]),
                  "- A year at most %.0f points under FROZEN's: %s (FOUND+WEEKLY %+.1f%%, FROZEN %+.1f%%)" % (
                      RET_TOL, _yn(sc["ret_ok"]), sc["a_year_found_weekly"], sc["a_year_frozen"]),
                  "- The worst-fall cut (FROZEN's minus FOUND+WEEKLY's, mean of the 5 start days): %s points. Its 95%% "
                  "interval over %d paired reruns (each: a random start day of the 5 and %.0f%% of the picks dropped at "
                  "random - the same for both trees): %s, the cut above 0 in %.0f%% of them. Above 0: %s" % (
                      _p(sc["cut_mean"]), RERUNS, 100 * RERUN_DROP, _ci(cr[1], cr[2]),
                      100 * cr[3] if np.isfinite(cr[3]) else 0, _yn(sc["interval_above_0"])), "",
                  "CONFIRMED = all three. LEAD = the first two (FOUND+WEEKLY goes on the paper ledger beside FROZEN). "
                  "DEAD = anything else.", "",
                  "Shown, not deciding - the same cut with history re-ordered (the two daily value paths rebuilt from "
                  "%d-session blocks, the same blocks for both, %d draws, start day 1): %s points %s, above 0 in %.0f%% "
                  "of the draws. A worst fall is one episode, so this check rarely clears 0 even when a cut is real "
                  "(README: the planted crash world)." % (
                      DD_BLOCK, BOOT_B, _p(ct[0]), _ci(ct[1], ct[2]), 100 * ct[3] if np.isfinite(ct[3]) else 0), ""]
            fl = [r for r in B["judged"] if r.get("fid")]
            L += ["FOUND+WEEKLY = S1 S2 S3 C1 C2 C3 N1 + " + "; ".join(
                "**%s** = %s (%s)" % (r["fid"], words(r["conds"]), "D5 close" if r["mode"] == "original_d5"
                                      else "fresh exit") for r in fl) + ". Found on half A before %s." % SPLIT, ""]
            L += ["The worst fall of each book, start day 1 (every fall's dates in `falls.csv`, the daily values in "
                  "`curves.csv`):", "",
                  "| window | tree | D tree: worst fall, peak -> trough | ENS tree | both |", "|---|---|---|---|---|"]
            for wname in ("test", "full"):
                for name in ("FROZEN", "FOUND+WEEKLY"):
                    cells = []
                    for bkname in ("D tree", "ENS tree", "both"):
                        f1 = [x for x in T["falls"] if x["window"] == wname and x["tree"] == name and
                              x["book"] == bkname and x["rank"] == 1]
                        cells.append("%.1f%%, %s -> %s" % (f1[0]["fall_pct"], f1[0]["peak"], f1[0]["trough"])
                                     if f1 else "-")
                    L.append("| %s | %s | %s |" % ("2024 on" if wname == "test" else "2021 on", name, " | ".join(cells)))
            L.append("")
    nA = sum(1 for r in A["rows"] if r["verdict"] == "BETTER")
    nB = sum(1 for r in B["judged"] if r["verdict"] == "BETTER")
    L += ["## Verdict (per trade)", "",
          "| part | what | judged | BETTER than WEEKLY | TIE | WORSE |", "|---|---|---:|---:|---:|---:|",
          "| A | the twins (S1-S3, C1-C3 with a daily rolling 'bad week'), every pick | %d | **%d** | %d | %d |" % (
              len(A["rows"]), nA, sum(1 for r in A["rows"] if r["verdict"] == "TIE"),
              sum(1 for r in A["rows"] if r["verdict"] == "WORSE")),
          "| B | the open search: found on half A before %s, judged once on half B before it | %d | **%d** | %d | "
          "%d |" % (SPLIT, len(B["judged"]), nB, sum(1 for r in B["judged"] if r["verdict"] == "TIE"),
                    sum(1 for r in B["judged"] if r["verdict"] == "WORSE"))]
    if Dp:
        dr = [r for r in Dp["rows"] if r["verdict"] != "NOT AVAILABLE"]
        L.append("| D | stratlab's two confirmed triggers, on the stocks stratlab hid from its search | %d | **%d** | %d "
                 "| %d |" % (len(dr), sum(1 for r in dr if r["verdict"] == "BETTER"),
                             sum(1 for r in dr if r["verdict"] == "TIE"), sum(1 for r in dr if r["verdict"] == "WORSE")))
    L.append("")
    L += ["BETTER = the setup's net per trade minus WEEKLY's on the same picks and exit has a one-sided p at most "
          "0.05 / K (Part A: K = %d, p <= %.4f; Part B: K = %d, p <= %.4f%s) and its 95%% interval above 0. TIE = no "
          "clear difference either way. WORSE = the 95%% interval below 0. TOO FEW = trades on fewer than %d signal "
          "days (or resamples without spread): no verdict." % (
              A["K"], A["thr"], B["K"], B["thr"], ("; Part D: K = %d, p <= %.4f" % (Dp["K"], Dp["thr"])) if Dp else "",
              MIN_DAYS), ""]
    wk = A["weekly"]
    L += ["## The bar: WEEKLY (S1-S3, C1-C3 as the tree uses them - each pick's earliest fill)", "",
          "| setup | trades | a year | net/trade at the D5 close [95%] | net/trade, fresh exit | Tuesday entries |",
          "|---|---:|---:|---|---:|---:|"]
    for r in A["bar"]:
        L.append("| %s | %d | %.0f | %s %s | %s | %.0f%% |" % (r["name"], r["n"], r["per_year"], _p(r["mean"]),
                                                              _ci(r["lo"], r["hi"]), _p(r.get("mean_fresh")),
                                                              100 * r["tuesday_share"] if np.isfinite(
                                                                  r["tuesday_share"]) else 0))
    L += ["", "WEEKLY on all pooled picks: %d trades, %s per trade %s at the D5 close." % (
        wk["n"], _p(wk["mean"]), _ci(wk["lo"], wk["hi"])), ""]
    L += ["## Part A - the twins (declared; nothing searched)", "",
          "Each weekly setup with `w_ret_13w fell` swapped for a twin read at every close: **tw13** = %s; **tw5** = %s. "
          "Exit: the D5 close (the originals' exit). Every pooled pick." % (TWINS[0][2], TWINS[1][2]), "",
          "| twin | trades | a year | net/trade [95%] | Tuesday entries | vs WEEKLY [95%] | p | verdict | vs its "
          "weekly original [95%] |", "|---|---:|---:|---|---:|---|---:|---|---|"]
    for r in A["rows"]:
        L.append("| %s | %d | %.0f | %s %s | %.0f%% | %s %s | %.4f | **%s** | %s |" % (
            r["name"], r["n"], r["per_year"], _p(r["mean"]), _ci(r["lo"], r["hi"]),
            100 * r["tuesday_share"] if np.isfinite(r["tuesday_share"]) else 0, _p(r["diff"]),
            _ci(r["diff_lo"], r["diff_hi"]), r["p"], r["verdict"],
            ("%s %s" % (_p(r["vs_orig"]), _ci(r["vs_orig_lo"], r["vs_orig_hi"]))) if "vs_orig" in r else "-"))
    L += ["", "A twin's conditions: its weekly original's, with the weekly one swapped (see `twins.csv`).", ""]
    mn = B.get("month_named") or []
    L += ["## Part B - the open search (before %s only)" % SPLIT, "",
          "%d conditions (%d features x 4 + the twins' 'below 0' + %d price conditions); %d features left out as weekly "
          "or weekday-bound (`excluded.csv`). Searched: %d pooled picks of half A whose every price is before %s; "
          "hidden: %d of half B, the same days. The thirds' cut-offs: half A before %s." % (
              B["atoms"], B["n_feats"], len(PRICE_ATOMS), len(checks.get("excluded_weekly", [])), B["nA"], SPLIT,
              B["nB"], SPLIT), "",
          "Month-bound inputs (kept in the search, named here): %s. Their changes fall on a month's first session - "
          "Soul's memory is rebuilt once a month, so 'soul_m_self_n rose' means the session before the entry was a "
          "month's first: the entry is the month's 2nd session. 'Month-start entries' = a setup's entries in a month's "
          "first %d sessions (about %d%% if a setup ignored the month; `bound.csv` has every input)." % (
              ", ".join("%s (%.0f%% of its changes)" % (f, 100 * s) for f, s in mn) or "none", MONTH_START,
              round(100 * MONTH_START / 21)), ""]
    for key, rows in B["lists"].items():
        cnt = B["counts"][key]
        L += ["### %s (%s)" % (key, dict((e[0], e[2]) for e in EXITS)[key]), "",
              "Screened: %d singles, %d pairs kept, %d triples kept; %d checked for every condition earning its place; "
              "%d finalists, %d qualify. WEEKLY on half A: %s per trade; on half B: %s." % (
                  cnt["singles"], cnt["pairs_kept"], cnt["triples_kept"], cnt["earn_checked"], cnt["finalists"],
                  cnt["qualify"], _p(B["wkA"][key]), _p(B["wkB"][key])), "",
              "| # | setup | half A: trades a year, net [95%] | half B: trades, net [95%] | half B vs WEEKLY [95%] | p | "
              "Tuesday share | month-start entries | verdict | adds nothing on half B |",
              "|---|---|---|---|---|---:|---:|---:|---|---|"]
        for i, r in enumerate(B["judged_by"][key], 1):
            j = r["judge"]
            L.append("| %d | %s | %.0f, %s %s | %d, %s %s | %s %s | %.4f | %.0f%% | %.0f%% | **%s** | %s |" % (
                i, words(r["conds"]), r["per_year"], _p(r["mean"]), _ci(r["lo"], r["hi"]), j["n"], _p(j["mean"]),
                _ci(j["lo"], j["hi"]), _p(j["diff"]), _ci(j["diff_lo"], j["diff_hi"]), j["p"],
                100 * j["tuesday_share"] if np.isfinite(j["tuesday_share"]) else 0,
                100 * j["month_start_share"] if np.isfinite(j["month_start_share"]) else 0, r["verdict"],
                "; ".join(j["adds_nothing"]) if j["adds_nothing"] else ("-" if len(r["conds"]) == 1 else "none")))
        if not B["judged_by"][key]:
            L.append("| - | no rule qualified on half A | | | | | | | | |")
        L.append("")
    L += ["### The judged setups after %s (every stock; never searched; descriptive)" % SPLIT, "",
          "%d pooled picks with a signal day on or after %s. WEEKLY there: %s per trade at the D5 close (the weekly "
          "setups were chosen on every day, which favours WEEKLY)." % (B["n_post"], SPLIT, _p(B["wk_post"])), "",
          "| id | setup | exit | trades | net/trade [95%] | vs WEEKLY [95%] | month-start entries |",
          "|---|---|---|---:|---|---|---:|"]
    for r in B["judged"]:
        q = r.get("post") or {}
        L.append("| %s | %s | %s | %d | %s %s | %s %s | %.0f%% |" % (
            r.get("fid", "") or "-", words(r["conds"]), "D5 close" if r["mode"] == "original_d5" else "fresh",
            q.get("n", 0), _p(q.get("mean")), _ci(q.get("lo"), q.get("hi")), _p(q.get("diff")),
            _ci(q.get("diff_lo"), q.get("diff_hi")),
            100 * q["month_start_share"] if np.isfinite(q.get("month_start_share", np.nan)) else 0))
    if not B["judged"]:
        L.append("| - | nothing judged | | | | | |")
    L.append("")
    if Dp:
        L += ["## Part D - stratlab's confirmed triggers (STRATLAB_20261122_001)", "",
              "Declared before this run. Judged on the %d pooled picks of the stocks stratlab hid from its own search "
              "(sha256('stratlab-v1|SYMBOL') odd), against WEEKLY on those picks (%s per trade), sold at the D5 close. "
              "'Fell twice' = it fell at the close before the entry and at the close before that." % (
                  Dp["n_rows"], _p(Dp["wk_mean"])), "",
              "| setup | conditions | trades (days) | net/trade [95%] | fresh exit | Tuesday entries | vs WEEKLY [95%] | "
              "p | verdict | every pick: net, vs WEEKLY |", "|---|---|---|---|---:|---:|---|---:|---|---|"]
        for r in Dp["rows"]:
            if r["verdict"] == "NOT AVAILABLE":
                L.append("| %s | %s | - | - | - | - | - | - | NOT AVAILABLE (missing %s) | - |" % (
                    r["name"], words(r["conds"]), ", ".join(r["missing"])))
                continue
            al = r.get("all") or {}
            L.append("| %s | %s | %d (%d) | %s %s | %s | %.0f%% | %s %s | %.4f | **%s** | %s, %s |" % (
                r["name"], words(r["conds"]), r["n"], r["days"], _p(r["mean"]), _ci(r["lo"], r["hi"]),
                _p(r.get("mean_fresh")), 100 * r["tuesday_share"] if np.isfinite(r["tuesday_share"]) else 0,
                _p(r["diff"]), _ci(r["diff_lo"], r["diff_hi"]), r["p"], r["verdict"], _p(al.get("mean")),
                _p(al.get("diff"))))
        L.append("")
    L += ["## Part C - money in the tree (TREE.json's books)", ""]
    names = ("FROZEN = S1 S2 S3 C1 C2 C3 N1. TWINS-13 / TWINS-5 = the six weekly setups replaced by their twins (N1 "
             "kept; declared, never searched). FOUND = Part B's judged setups that are BETTER (if none: those not WORSE) "
             "+ N1, in place of the weekly six. FOUND+WEEKLY = the frozen seven and the found ones together. STRATLAB / "
             "STRATLAB+WEEKLY = the same with Part D's triggers (stratlab searched every day, so 2024 on is NOT unseen "
             "for them). A pick takes its earliest fill (a tie: the listed order). The worst-fall cut = FROZEN's worst "
             "fall minus the tree's (both books, the mean of the 5 start days; above 0 = it falls less); its 95%% "
             "interval over %d paired reruns (a random start day, %.0f%% of the picks dropped, the same draws for both "
             "trees; FOUND+WEEKLY only). Re-ordered history = the cut of start day 1 with both daily value paths rebuilt "
             "from the same %d-session blocks (%d draws; shown, not deciding)." % (RERUNS, 100 * RERUN_DROP, DD_BLOCK,
                                                                                   BOOT_B))
    if T is not None:
        L += ["### THE TEST: %s .. %s (the tree started again on the split; FOUND's setups never saw these days)" % (
            T["window"][0], T["window"][1]), "",
              "Ranks 1-3, D and ENS, Rs 5 L a book on the first session on or after %s, picks with a signal day from "
              "then on, 3 positions, the mean of 5 start days." % SPLIT, ""]
        L += money_table(T["books"], names)
    L += ["### 2021 on (descriptive: FROZEN %s TREE.json's own history; FOUND's setups saw 2021-23)" % (
        "reproduces" if C["reconciled"] else "does NOT reproduce"), "",
          "Ranks 1-3, D and ENS, Rs 5 L a book, 3 positions, %s .. %s, the mean of 5 start days." % (
              C["window"][0], C["window"][1]), ""]
    L += money_table(C["books"], names)
    L += ["## Checks", ""]
    for k, v in checks.items():
        if isinstance(v, (list, dict)) and len(json.dumps(v, default=str)) > 400:
            v = "%d items (see the csv files)" % len(v)
        L.append("- %s: %s" % (k, v))
    L += ["", "## How to read it", "",
          "- Net per trade = sell price / buy price - 1 - 0.35 points. Every setup buys at the open of the first watch "
          "day (D1-D5) where all its conditions hold, reading the values at the close before - the frozen setups' own "
          "rule.",
          "- WEEKLY's trades are all Tuesday entries; the twins and the found setups can enter on any weekday (the "
          "'Tuesday entries' column shows how often they still do).",
          "- 'Adds nothing on half B' names a condition whose own contribution (the setup's trades against the trades "
          "it would add without that condition) is not clearly above 0 on half B: the setup without it is the cleaner "
          "candidate.",
          "- Part A judges 14 declared setups on every pick. Part B's numbers on half A are where the setups were found "
          "(optimistic); half B never took part in the search, so its numbers are the fair ones. WEEKLY's half-B "
          "numbers are not new (the weekly setups were chosen on every stock), which favours WEEKLY.",
          "- A BETTER setup still goes to a new freeze with its own date and is judged by the forward ledger beside "
          "the frozen tree; nothing here changes the tree.",
          "- v1.0.2 THE SPLIT: half B shares its days with half A, so a setup built on market-wide conditions (VIX, "
          "Nifty RSI, a sector's day) is not checked by the hidden stocks alone. The split fixes that: the search saw "
          "nothing from %s on, and the tree is then run on those days. A worst fall is one episode; the bootstrap "
          "rebuilds the two paths from the same blocks of sessions to show how much of a cut is luck." % SPLIT,
          "- Worst fall = the two-book value against its running peak, marked to market daily (setuplab's rule).", ""]
    (d / "ANYDAY.md").write_text("\n".join(L), encoding="utf-8")


# ====================================================================================================== the run
def resolve_inputs(a):
    root = Path(a.root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    soul = Path(a.soul) if a.soul else root / "panel" / "soul" / "soul_v3_open.parquet"
    if not panel.is_file():
        raise ADError("panel not found: %s" % panel)
    return root, panel, soul


def cmd_run(a, log=LOG):
    t0 = time.time()
    try:
        dp, ddoc = load_declaration()
        if SU.VERSION != NEEDS["setuplab"] or SL.VERSION != NEEDS["soullab"]:
            raise ADError("needs %s and %s beside this folder (found %s, %s)" % (
                NEEDS["setuplab"], NEEDS["soullab"], SU.VERSION, SL.VERSION))
        root, panel, soul = resolve_inputs(a)
        out = guard_out(a.out, root)
        _, fdoc = SU.load_frozen()
        _, tdoc = SU.load_tree()
        smeta, scols, _ = SL.soul_meta(soul)
        dfeats, dsrc, dsha = SL.d_features(root)
        dcols, dexcl = SL.choose_features(dfeats, panel)
        import pyarrow.parquet as pq
        have = {c.lower() for c in pq.read_schema(panel).names}
        fconds = SU.frozen_conds(fdoc)
        ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
        need = [f for f in ffeats if f not in have]
        if need:
            raise ADError("the panel lacks the frozen setups' inputs: %s" % ", ".join(need))
        weekly_ids = [s for s, cc in fconds.items() if any(is_weekly_name(f) for f, _, _ in cc)]
        anyday_ids = [s for s in fconds if s not in weekly_ids]
        if not weekly_ids:
            raise ADError("no frozen setup has a weekly condition - nothing to compare against")
    except (ADError, ValueError, SL.SLError) as e:
        print("REFUSED: %s" % e)
        return 3
    log("%s: declaration %s; frozen setups %s (weekly: %s; any day: %s); tree %s" % (
        VERSION, ddoc["sha256"][:16], fdoc["sha256"][:16], " ".join(weekly_ids), " ".join(anyday_ids) or "-",
        tdoc["sha256"][:16]))
    wk_named = [f for f in dcols if is_weekly_name(f)]
    cal_named = [f for f in dcols if is_calendar_name(f) and not is_weekly_name(f)]
    dsearch = [f for f in dcols if not is_weekly_name(f) and not is_calendar_name(f)]
    dfields = [f for _, _, cc in PART_D for f, _, _ in cc]
    dbase = [b for b in dict.fromkeys(base_of(f) for f in dfields) if b]
    d_have = [b for b in dbase if b in have]
    exact = set(ffeats) | set(TWIN_FEATS) | set(d_have)
    pcols = list(dict.fromkeys(ffeats + d_have + (dsearch[:GROUP] if a.check_only else dsearch)))
    scl = scols[:GROUP] if a.check_only else scols
    log(" D's inputs: %d listed, %d usable, %d of them weekly by name (%s), %d calendar (%s); Soul %d (%s, lag %s)" % (
        len(dfeats), len(dcols), len(wk_named), ", ".join(wk_named) or "-", len(cal_named),
        ", ".join(cal_named) or "-", len(scols), smeta.get("code", "?"), (smeta.get("config") or {}).get("lag")))
    try:
        bk, miss, tmiss = load_book(a.data, panel, soul, pcols, scl, exact, root, log)
    except (ADError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    add_prev_changes(bk, dfields)
    ctx = Ctx(bk)
    etf = SU.tree_etf(bk.symbols, tdoc)
    ok = complete_rows(bk) & ~etf
    R, _ = pooled_rows(bk, ok)
    half = halves(bk.symbols)
    pre = before_split(bk, R)                      # v1.0.2: the search and its judge see only these
    Rpre, Rpost = R[pre], R[after_split(bk, R)]
    RA, RB = Rpre[half[Rpre] == 0], Rpre[half[Rpre] == 1]
    tw_have = {f: float(np.isfinite(bk.F[f][R, 1]).mean()) if len(R) else 0.0 for f in TWIN_FEATS}
    checks = {"picks": "%d rows (D %d, ENS %d; %d ETF rows left out), complete %d, pooled %d, signal days %s .. %s; "
                       "every price before %s: %d (half A %d, half B %d; signal days %s .. %s); signal day on or after "
                       "it: %d" % (
        bk.n, int((bk.engine_arr == "D").sum()), int((bk.engine_arr == "ENS").sum()), int(etf.sum()), int(ok.sum()),
        len(R), pd.Timestamp(bk.signal_day.min()).date(), pd.Timestamp(bk.signal_day.max()).date(), SPLIT, len(Rpre),
        len(RA), len(RB), pd.Timestamp(bk.signal_day[Rpre].min()).date() if len(Rpre) else "-",
        pd.Timestamp(bk.signal_day[Rpre].max()).date() if len(Rpre) else "-", len(Rpost)),
        "twins": "%s known at the signal close on %s of the pooled picks; %d stocks without a cache file%s" % (
            " and ".join(TWIN_FEATS), " / ".join("%.1f%%" % (100 * v) for v in tw_have.values()), len(tmiss),
            (" (e.g. %s)" % ", ".join(tmiss[:5])) if tmiss else ""),
        "missing columns": ", ".join(miss) or "none"}
    if min(tw_have.values()) < 0.5:
        print("REFUSED: the twins are known on fewer than half of the picks (%s) - is --root the daily cache "
              "(<SYMBOL>_daily.parquet)?" % checks["twins"])
        return 3
    if len(Rpost) < 100 or len(RA) < 100 or len(RB) < 100:
        print("REFUSED: the split needs picks on both sides of %s (%d with every price before it: half A %d, half B %d; "
              "%d from it on) - is the watchlist the full 2020-26 research watchlist?" % (
                  SPLIT, len(Rpre), len(RA), len(RB), len(Rpost)))
        return 3
    # the frozen setups replayed: FINAL_001's own numbers (per engine)
    recon = []
    for e in ("D", "ENS"):
        m = bk.engine_arr == e
        if m.any():
            _, _, rc = SU.tag_book(bk.take(m, e), fconds, fdoc)
            recon += rc
    nsame = sum(1 for r in recon if r["same"])
    checks["frozen setups vs FINAL_001"] = "%d of %d (setup, engine, exit) give FINAL_001's trades and net exactly" % (
        nsame, len(recon))
    for k, v in checks.items():
        log(" %s: %s" % (k, v))
    wk_rules = [fconds[s] for s in weekly_ids]
    wk_day, wk_nets = lane(ctx, wk_rules)
    primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
    frozen_v = {"FROZEN": ({s: fconds[s] for s in SU.TREE_ORDER if s in fconds},
                           [s for s in SU.TREE_ORDER if s in fconds], primary)}
    try:
        m0, mchk = tree_money(ctx, frozen_v, tdoc, log=lambda *x: None)
    except ADError as e:
        print("REFUSED: %s" % e)
        return 3
    checks["the tree replayed"] = "%s .. %s; FROZEN %s TREE.json's history (D tree %+.2f%% a year, worst fall %.2f%%)" % (
        mchk["window"][0], mchk["window"][1], "REPRODUCES" if mchk["reconciled"] else "does NOT reproduce",
        m0["FROZEN"]["res"]["D tree"]["a_year"], m0["FROZEN"]["res"]["D tree"]["fall"])
    log(" the tree replayed: " + checks["the tree replayed"])
    nat = 4 * (len(dsearch) + len(scols) + 2) + 2 + len(PRICE_ATOMS)
    est = 2 * (nat ** 2 / 2) * max(len(RA), 1) * 6e-9 + 300
    checks["estimated time"] = "about %.1f to %.1f hours" % (est / 3600 * 0.6, est / 3600 * 2.5)
    log(" estimated time: " + checks["estimated time"])
    if a.check_only:
        log("CHECK OK - inputs readable; nothing searched or written. Run again without --check-only.")
        return 0
    d = SU.new_run_dir(out, "ANYDAY")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": ddoc["sha256"], "frozen_sha256": fdoc["sha256"],
                 "tree_sha256": tdoc["sha256"], "d_features": dsrc, "d_features_sha256": dsha,
                 "soul": str(soul), "watchlist": str(Path(a.data) / "watchlist.parquet")})
    # ---- the populations
    popAll = Pop(ctx, R, wk_day, wk_nets, "all")
    popA = Pop(ctx, RA, wk_day, wk_nets, "half A before the split")
    popB = Pop(ctx, RB, wk_day, wk_nets, "half B before the split")
    popPost = Pop(ctx, Rpost, wk_day, wk_nets, "every stock after the split")
    # ---- the bar
    bar = []
    for s in weekly_ids + anyday_ids:
        r = popAll.stats(ctx, fconds[s], "original_d5", versus=False)
        rf = popAll.stats(ctx, fconds[s], "fresh", versus=False)
        r.update({"name": s + ("" if s in weekly_ids else " (any day)"), "mean_fresh": rf["mean"]})
        bar.append(r)
    wv = popAll.wk["original_d5"]
    wm = (popAll.wk_day > 0) & np.isfinite(wv)
    wlo, whi = SL._ci(popAll.boot, popAll.bdi, np.where(wm, wv, np.nan))
    wkr = {"name": "WEEKLY (earliest of %s)" % " ".join(weekly_ids), "n": int(wm.sum()), "per_year": wm.sum() /
           popAll.years, "mean": float(wv[wm].mean()) if wm.any() else np.nan, "lo": wlo, "hi": whi,
           "mean_fresh": float(np.nanmean(popAll.wk["fresh"][wm])) if wm.any() else np.nan,
           "tuesday_share": float((pd.DatetimeIndex(bk.cal[np.clip(bk.i1[R][wm] + popAll.wk_day[wm] - 1, 0,
                                                                     len(bk.cal) - 1)]).weekday == 1).mean())
           if wm.any() else np.nan}
    bar.insert(0, wkr)
    log(" WEEKLY: %d trades on the pooled picks, %s per trade at the D5 close %s" % (
        wkr["n"], _p(wkr["mean"]), _ci(wkr["lo"], wkr["hi"])))
    # ---- Part A: the twins
    log("Part A: the twins")
    arow, twin_rules = [], {}
    for tag, feat, _ in TWINS:
        lane_rules = []
        for s in weekly_ids:
            cc = twin_conds(fconds[s], feat)
            nm = "%s-%s" % (s, tag)
            twin_rules[nm] = cc
            lane_rules.append(cc)
            r = popAll.stats(ctx, cc, "original_d5")
            ro = popAll.stats(ctx, fconds[s], "original_d5", versus=False)
            dt, _ = ctx.rep(cc)
            do, _ = ctx.rep(fconds[s])
            vt = ctx.rep(cc)[1]["original_d5"][R]
            vo = ctx.rep(fconds[s])[1]["original_d5"][R]
            mt, mo = dt[R] > 0, do[R] > 0
            lo_, hi_, _ = popAll.boot.ci_diff(popAll.bdi[mt], vt[mt], popAll.bdi[mo], vo[mo]) if mt.sum() >= 2 and \
                mo.sum() >= 2 else (np.nan, np.nan, np.nan)
            r.update({"name": nm, "conds": cc, "vs_orig": r["mean"] - ro["mean"], "vs_orig_lo": lo_,
                      "vs_orig_hi": hi_, "mean_fresh": popAll.stats(ctx, cc, "fresh", versus=False)["mean"]})
            arow.append(r)
        lday, lnets = lane(ctx, lane_rules)
        lv = lnets["original_d5"][R]
        lm = (lday[R] > 0) & np.isfinite(lv)
        wv_ = popAll.wk["original_d5"]
        wm_ = (popAll.wk_day > 0) & np.isfinite(wv_)
        lo_, hi_, sd_ = popAll.boot.ci_diff(popAll.bdi[lm], lv[lm], popAll.bdi[wm_], wv_[wm_]) if lm.sum() >= 2 \
            else (np.nan, np.nan, np.nan)
        mlo, mhi = SL._ci(popAll.boot, popAll.bdi, np.where(lm, lv, np.nan))
        ent = bk.cal[np.clip(bk.i1[R][lm] + lday[R][lm] - 1, 0, len(bk.cal) - 1)]
        wdl = pd.DatetimeIndex(ent).weekday.to_numpy()
        mean_l = float(lv[lm].mean()) if lm.any() else np.nan
        arow.append({"name": "%s lane (earliest of the six)" % tag, "conds": None, "n": int(lm.sum()),
                     "per_year": lm.sum() / popAll.years, "mean": mean_l, "lo": mlo, "hi": mhi,
                     "tuesday_share": float((wdl == 1).mean()) if lm.any() else np.nan,
                     "weekdays": {WD[i]: float((wdl == i).mean()) for i in range(5)} if lm.any() else {},
                     "diff": mean_l - wkr["mean"], "diff_lo": lo_, "diff_hi": hi_, "diff_sd": sd_,
                     "p": pval(mean_l - wkr["mean"], sd_), "keys": set(), "lane_rules": lane_rules,
                     "days": int(len(np.unique(popAll.day[lm]))) if lm.any() else 0})
    KA = len(arow)
    thrA = ALPHA / KA
    for r in arow:
        r["verdict"] = verdict(r, thrA)
        log("   %-34s %5d trades, %s per trade %s; vs WEEKLY %s %s p %.4f -> %s" % (
            r["name"], r["n"], _p(r["mean"]), _ci(r["lo"], r["hi"]), _p(r["diff"]), _ci(r["diff_lo"], r["diff_hi"]),
            r["p"], r["verdict"]))
    A = {"rows": arow, "K": KA, "thr": thrA, "weekly": wkr, "bar": bar}
    # ---- Part D: stratlab's confirmed triggers, judged on the stocks stratlab hid from its search
    log("Part D: stratlab's triggers")
    sth = np.array([int(hashlib.sha256((STRAT_SALT + "|" + str(x)).encode()).hexdigest(), 16) % 2
                    for x in bk.symbols], np.int8)
    popS = Pop(ctx, R[sth[R] == 1], wk_day, wk_nets, "stratlab's hidden stocks")
    drow = []
    for sid, src, cc in PART_D:
        cc = [tuple(c) for c in cc]
        miss_f = [f for f, _, _ in cc if base_of(f) is not None and f not in bk.F]
        if miss_f:
            drow.append({"name": sid, "source": src, "conds": cc, "verdict": "NOT AVAILABLE", "n": 0, "days": 0,
                         "missing": miss_f})
            continue
        r = popS.stats(ctx, cc, "original_d5")
        r.update({"name": sid, "source": src, "conds": cc, "verdict": "",
                  "mean_fresh": popS.stats(ctx, cc, "fresh", versus=False)["mean"],
                  "all": popAll.stats(ctx, cc, "original_d5")})
        drow.append(r)
    KD = max(1, sum(1 for r in drow if r["verdict"] != "NOT AVAILABLE"))
    thrD = ALPHA / KD
    for r in drow:
        if r["verdict"] == "NOT AVAILABLE":
            log("   %s: not available (missing %s)" % (r["name"], ", ".join(r["missing"])))
            continue
        r["verdict"] = verdict(r, thrD)
        log("   %s %5d trades on %d days, %s per trade %s; vs WEEKLY %s %s p %.4f -> %s" % (
            r["name"], r["n"], r["days"], _p(r["mean"]), _ci(r["lo"], r["hi"]), _p(r["diff"]),
            _ci(r["diff_lo"], r["diff_hi"]), r["p"], r["verdict"]))
    Dp = {"rows": drow, "K": KD, "thr": thrD, "n_rows": len(popS.rows),
          "wk_mean": float(np.nanmean(popS.wk["original_d5"][popS.wk_day > 0])) if (popS.wk_day > 0).any()
          else np.nan}
    # ---- Part B: the open search
    log("Part B: the open search")
    feats = [f for f in dsearch + scols + list(TWIN_FEATS) if f in bk.F and f + "_change" in bk.F]
    wb = weekday_bound(bk, Rpre, feats)                       # v1.0.2: measured before the split
    mb = month_bound(bk, Rpre, feats, ctx.som)                # v1.0.2: measured and named, never a reason to leave out
    excluded = [(f, "weekly by name") for f in wk_named] + [(f, "calendar (day of week)") for f in cal_named] + [
        (f, "weekday-bound: %.0f%% of its changes on %s" % (100 * wb[f][0], WD[wb[f][1]]))
        for f in feats if np.isfinite(wb[f][0]) and wb[f][0] > WEEKDAY_BOUND]
    bound_rows = [{"feature": f, "weekday_share": wb[f][0], "weekday": WD[wb[f][1]] if wb[f][1] >= 0 else "",
                   "month_first_session_share": mb[f],
                   "searched": not (np.isfinite(wb[f][0]) and wb[f][0] > WEEKDAY_BOUND)} for f in feats]
    feats = [f for f in feats if not (np.isfinite(wb[f][0]) and wb[f][0] > WEEKDAY_BOUND)]
    month_named = sorted([f for f in feats if np.isfinite(mb[f]) and mb[f] > 0.5], key=lambda f: -mb[f])
    checks["excluded_weekly"] = [f for f, _ in excluded]
    checks["month-bound inputs (kept, named)"] = ", ".join("%s %.0f%%" % (f, 100 * mb[f]) for f in month_named) or \
        "none"
    atoms = feature_atoms(feats, set(scols), bk, RA) + price_atoms()     # the thirds: half A before the split
    DMa = masks(bk, RA, atoms)
    TLa = tl_tables(bk, RA)
    log(" %d conditions from %d features (%d left out as weekly / weekday-bound) and %d price conditions; before %s: "
        "half A %d pooled picks, half B %d; month-bound inputs (kept): %s" % (
            len(atoms), len(feats), len(excluded), len(PRICE_ATOMS), SPLIT, len(RA), len(RB),
            checks["month-bound inputs (kept, named)"]))
    lists, counts, judged_by, wkA, wkB = {}, {}, {}, {}, {}
    for key, mode, _ in EXITS:
        log(" searching %s (%s)" % (key, mode))
        rows, cnt = search(ctx, popA, atoms, DMa, TLa[mode], mode, log)
        for r in rows:
            r["conds"] = conds_of(atoms, r["cand"])
            r["mode"] = mode
        lists[key], counts[key] = rows, cnt
        judged_by[key] = pick_top(rows, SL.fam_ids(atoms))
        w = popA.wk[mode]
        wkA[key] = float(np.nanmean(w[popA.wk_day > 0])) if (popA.wk_day > 0).any() else np.nan
        w = popB.wk[mode]
        wkB[key] = float(np.nanmean(w[popB.wk_day > 0])) if (popB.wk_day > 0).any() else np.nan
        log("   %s: %d finalists, %d qualify, %d judged" % (key, cnt["finalists"], cnt["qualify"],
                                                          len(judged_by[key])))
    judged = [r for key in judged_by for r in judged_by[key]]
    KB = max(1, len(judged))
    thrB = ALPHA / KB
    for r in judged:
        j = popB.stats(ctx, r["conds"], r["mode"])
        j["adds"] = adds(ctx, popB, r["conds"], r["mode"])
        j["adds_nothing"] = [w_ for w_, _, lo_, _ in j["adds"] if not (lo_ > 0)]
        r["judge"] = j
        r["verdict"] = verdict(j, thrB)
        r["post"] = popPost.stats(ctx, r["conds"], r["mode"])       # v1.0.2: descriptive, never searched
        log("   judged %-6s %s: half B %d trades %s %s; vs WEEKLY %s %s p %.4f -> %s; after %s (every stock): %d "
            "trades, vs WEEKLY %s %s; month-start entries %.0f%%" % (
                "d5" if r["mode"] == "original_d5" else "fresh", words(r["conds"])[:70], j["n"], _p(j["mean"]),
                _ci(j["lo"], j["hi"]), _p(j["diff"]), _ci(j["diff_lo"], j["diff_hi"]), j["p"], r["verdict"], SPLIT,
                r["post"]["n"], _p(r["post"]["diff"]), _ci(r["post"]["diff_lo"], r["post"]["diff_hi"]),
                100 * j["month_start_share"] if np.isfinite(j["month_start_share"]) else 0))
    B = {"lists": lists, "counts": counts, "judged_by": judged_by, "judged": judged, "K": KB, "thr": thrB,
         "atoms": len(atoms), "n_feats": len(feats), "nA": len(RA), "nB": len(RB), "wkA": wkA, "wkB": wkB,
         "n_post": len(Rpost), "month_named": [(f, mb[f]) for f in month_named],
         "wk_post": float(np.nanmean(popPost.wk["original_d5"][popPost.wk_day > 0])) if (popPost.wk_day > 0).any()
         else np.nan}
    # ---- Part C: money
    log("Part C: money in the tree")
    variants = dict(frozen_v)
    for tag, _, _ in TWINS:
        rules = {"%s-%s" % (s, tag): twin_rules["%s-%s" % (s, tag)] for s in weekly_ids}
        rules.update({s: fconds[s] for s in anyday_ids})
        pr = {k: "original_d5" for k in rules}
        pr.update({s: primary[s] for s in anyday_ids})
        variants["TWINS-%s" % tag[2:]] = (rules, list(rules), pr)
    found = [r for r in judged if r["verdict"] == "BETTER"] or [r for r in judged if r["verdict"] != "WORSE"]
    if found:
        rules, pr = {}, {}
        for i, r in enumerate(found, 1):
            nm = "F%d" % i
            r["fid"] = nm
            rules[nm], pr[nm] = r["conds"], r["mode"]
        fr = dict(rules)
        fr.update({s: fconds[s] for s in anyday_ids})
        fp = dict(pr)
        fp.update({s: primary[s] for s in anyday_ids})
        variants["FOUND"] = (fr, list(fr), fp)
        fw = {s: fconds[s] for s in SU.TREE_ORDER if s in fconds}
        fw.update(rules)
        pw = dict(primary)
        pw.update(pr)
        variants["FOUND+WEEKLY"] = (fw, list(fw), pw)
    dav = [r for r in drow if r["verdict"] != "NOT AVAILABLE"]
    if dav:
        rules = {r["name"]: r["conds"] for r in dav}
        sr = dict(rules)
        sr.update({s: fconds[s] for s in anyday_ids})
        sp = {k: "original_d5" for k in rules}
        sp.update({s: primary[s] for s in anyday_ids})
        variants["STRATLAB"] = (sr, list(sr), sp)
        sw = {s: fconds[s] for s in SU.TREE_ORDER if s in fconds}
        sw.update(rules)
        pw2 = dict(primary)
        pw2.update({k: "original_d5" for k in rules})
        variants["STRATLAB+WEEKLY"] = (sw, list(sw), pw2)
    rf = ("FOUND+WEEKLY",) if "FOUND+WEEKLY" in variants else ()
    books, mchk = tree_money(ctx, variants, tdoc, log, reruns_for=rf)
    C = {"books": books, "window": mchk["window"], "reconciled": mchk["reconciled"]}
    # ---- v1.0.2: the test window - the tree started again on the split, no found setup saw these days
    log("Part C: THE TEST - the tree from %s (no found setup saw these days)" % SPLIT)
    try:
        tbooks, tchk = tree_money(ctx, variants, tdoc, log, start=SPLIT, t1=mchk["t1"], reruns_for=rf)
    except ADError as e:
        print("REFUSED: %s" % e)
        return 3
    fw_ = tbooks.get("FOUND+WEEKLY")
    nan4 = (np.nan, np.nan, np.nan, np.nan)
    if fw_ is not None:
        sv, sc = split_verdict(tbooks["FROZEN"]["per_start"][BOTH], fw_["per_start"][BOTH], fw_["cut_rr"][1])
    else:
        sv, sc = split_verdict(None, None, np.nan)
    sc["cut_rr"] = fw_["cut_rr"] if fw_ is not None else nan4
    sc["cut"] = fw_["cut"] if fw_ is not None else nan4
    sc["cut_mean"] = fw_["cut_mean"] if fw_ is not None else np.nan
    T = {"books": tbooks, "window": tchk["window"], "verdict": sv, "conds": sc,
         "start_days": [str(pd.Timestamp(tchk["days"][i]).date()) for i in range(min(5, len(tchk["days"])))]}
    log(" THE DECISION: %s (worst fall lower on all 5 start days: %s; a year within %.0f points of FROZEN: %s; the cut "
        "%s points, its 95%% interval over %d paired reruns %s above 0: %s; re-ordered history %s, %s of draws above 0)" % (
            sv, sc["lower_all"], RET_TOL, sc["ret_ok"], _p(sc["cut_mean"]), RERUNS,
            _ci(sc["cut_rr"][1], sc["cut_rr"][2]), sc["interval_above_0"], _ci(sc["cut"][1], sc["cut"][2]),
            "%.0f%%" % (100 * sc["cut"][3]) if np.isfinite(sc["cut"][3]) else "-"))
    fall_rows, curve_frames = [], []
    for wname, bks, chk in (("test", tbooks, tchk), ("full", books, mchk)):
        days = chk["days"]
        for name, r in bks.items():
            for bkname, v in r["eq"].items():
                for rank, (dep, pkd, trd, rec) in enumerate(falls(v, days, 3), 1):
                    fall_rows.append({"window": wname, "tree": name, "book": bkname, "rank": rank, "fall_pct": dep,
                                      "peak": str(pd.Timestamp(pkd).date()), "trough": str(pd.Timestamp(trd).date()),
                                      "back_at_peak": str(pd.Timestamp(rec).date()) if rec is not None else ""})
            curve_frames.append(pd.DataFrame({"window": wname, "tree": name, "date": pd.DatetimeIndex(days).date,
                                              "d_tree": r["eq"]["D tree"], "ens_tree": r["eq"]["ENS tree"],
                                              "both": r["eq"]["both"]}))
    T["falls"] = fall_rows
    # ---- outputs
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    tw_rows = [{"setup": r["name"], "conditions": words(r["conds"]) if r.get("conds") else "earliest of the six",
                "conds": json.dumps(r.get("conds")) if r.get("conds") else "", "trades": r["n"],
                "per_year": r["per_year"], "net": r["mean"], "net_lo": r["lo"], "net_hi": r["hi"],
                "net_fresh": r.get("mean_fresh", np.nan), "entry_day": r.get("entry_day", np.nan),
                "tuesday_share": r["tuesday_share"], "weekdays": wd_text(r), "vs_weekly": r["diff"],
                "vs_weekly_lo": r["diff_lo"], "vs_weekly_hi": r["diff_hi"], "p": r["p"], "verdict": r["verdict"],
                "vs_original": r.get("vs_orig", np.nan), "vs_original_lo": r.get("vs_orig_lo", np.nan),
                "vs_original_hi": r.get("vs_orig_hi", np.nan)} for r in arow]
    pd.DataFrame(tw_rows).to_csv(d / "twins.csv", index=False)
    pd.DataFrame([{"setup": r["name"], "trades": r["n"], "per_year": r["per_year"], "net_d5": r["mean"],
                   "net_d5_lo": r["lo"], "net_d5_hi": r["hi"], "net_fresh": r.get("mean_fresh"),
                   "tuesday_share": r["tuesday_share"]} for r in bar]).to_csv(d / "weekly_bar.csv", index=False)
    files = ["ANYDAY.md", "twins.csv", "weekly_bar.csv"]
    for key, rows in lists.items():
        jt = {id(r) for r in judged_by[key]}
        recs = []
        for r in rows:
            j = r.get("judge", {}) if id(r) in jt else {}
            recs.append({"rule": " & ".join(atoms[x]["id"] for x in r["cand"]), "conditions": words(r["conds"]),
                         "conds": json.dumps(r["conds"]), "size": len(r["cand"]), "qualifies": r["qualifies"],
                         "judged": id(r) in jt, "verdict": r.get("verdict", "") if id(r) in jt else "",
                         "A_trades": r["n"], "A_per_year": r["per_year"], "A_net": r["mean"], "A_net_lo": r["lo"],
                         "A_net_hi": r["hi"], "A_weekly": r["wk_mean"], "A_vs_weekly": r["diff"],
                         "A_bad_years": r["bad_years"], "A_earn_lo": r["earn_lo"], "A_tuesday_share": r["tuesday_share"],
                         "B_trades": j.get("n"), "B_net": j.get("mean"), "B_net_lo": j.get("lo"),
                         "B_net_hi": j.get("hi"), "B_weekly": j.get("wk_mean"), "B_vs_weekly": j.get("diff"),
                         "B_vs_weekly_lo": j.get("diff_lo"), "B_vs_weekly_hi": j.get("diff_hi"), "B_p": j.get("p"),
                         "B_tuesday_share": j.get("tuesday_share"), "B_weekdays": wd_text(j) if j else "",
                         "B_adds": "; ".join("%s %+.2f [%+.2f, %+.2f]" % a_ for a_ in j.get("adds", [])) if j else "",
                         "B_adds_nothing": "; ".join(j.get("adds_nothing", [])) if j else "",
                         "A_month_start_share": r.get("month_start_share"),
                         "B_month_start_share": j.get("month_start_share"),
                         "after_trades": (r.get("post") or {}).get("n") if j else None,
                         "after_net": (r.get("post") or {}).get("mean") if j else None,
                         "after_net_lo": (r.get("post") or {}).get("lo") if j else None,
                         "after_net_hi": (r.get("post") or {}).get("hi") if j else None,
                         "after_vs_weekly": (r.get("post") or {}).get("diff") if j else None,
                         "after_vs_weekly_lo": (r.get("post") or {}).get("diff_lo") if j else None,
                         "after_vs_weekly_hi": (r.get("post") or {}).get("diff_hi") if j else None})
        pd.DataFrame(recs).to_csv(d / ("found_%s.csv" % key), index=False)
        files.append("found_%s.csv" % key)
    mrows = []
    for wname, bks, wnd in (("test", tbooks, T["window"]), ("full", books, C["window"])):
        for name, r in bks.items():
            for g, v in r["res"].items():
                mrows.append({"window": wname, "from": wnd[0], "to": wnd[1], "tree": name, "group": g,
                              "a_year_pct": v["a_year"], "worst_fall_pct": v["fall"],
                              "rs_5l_became_lakh": 5 * v["end"], "trades_per_week": v["per_week"],
                              "mean_net_per_trade": v["mean"]})
            mrows.append({"window": wname, "from": wnd[0], "to": wnd[1], "tree": name,
                          "group": "both vs FROZEN (bp a day)", "a_year_pct": r["vs_frozen"][0],
                          "worst_fall_pct": np.nan, "vs_frozen_lo": r["vs_frozen"][1], "vs_frozen_hi": r["vs_frozen"][2]})
            mrows.append({"window": wname, "from": wnd[0], "to": wnd[1], "tree": name,
                          "group": "both: worst-fall cut vs FROZEN (points; mean of 5 start days; 95%% over %d paired "
                                   "reruns)" % RERUNS, "a_year_pct": np.nan,
                          "worst_fall_pct": r["cut_mean"], "vs_frozen_lo": r["cut_rr"][1],
                          "vs_frozen_hi": r["cut_rr"][2]})
            mrows.append({"window": wname, "from": wnd[0], "to": wnd[1], "tree": name,
                          "group": "both: worst-fall cut vs FROZEN (points; start day 1; 95% day-block bootstrap, shown)",
                          "a_year_pct": np.nan, "worst_fall_pct": r["cut"][0], "vs_frozen_lo": r["cut"][1],
                          "vs_frozen_hi": r["cut"][2]})
    pd.DataFrame(mrows).to_csv(d / "money.csv", index=False)
    srows = []
    for i in range(5):
        fz = tbooks["FROZEN"]["per_start"][BOTH][i]
        fw = fw_["per_start"][BOTH][i] if fw_ is not None else (np.nan, np.nan)
        srows.append({"start_day": i + 1, "start": str(pd.Timestamp(tchk["days"][i]).date()),
                      "frozen_a_year_pct": fz[0], "frozen_worst_fall_pct": fz[1], "found_weekly_a_year_pct": fw[0],
                      "found_weekly_worst_fall_pct": fw[1], "lower": bool(np.isfinite(fw[1]) and fw[1] < fz[1])})
    pd.DataFrame(srows).to_csv(d / "split_decision.csv", index=False)
    pd.DataFrame(fall_rows).to_csv(d / "falls.csv", index=False)
    pd.concat(curve_frames, ignore_index=True).to_csv(d / "curves.csv", index=False, float_format="%.6f")
    pd.DataFrame(bound_rows).to_csv(d / "bound.csv", index=False)
    files += ["split_decision.csv", "falls.csv", "curves.csv", "bound.csv"]
    pd.DataFrame(recon).to_csv(d / "frozen_vs_final_001.csv", index=False)
    pd.DataFrame([{"id": x["id"], "family": x["fam"], "field": x["cond"][0], "op": x["cond"][1],
                   "value": x["cond"][2], "words": x["words"]} for x in atoms]).to_csv(d / "conditions.csv",
                                                                                        index=False)
    pd.DataFrame(excluded + [(f, w) for f, w in dexcl], columns=["feature", "why"]).to_csv(d / "excluded.csv",
                                                                                           index=False)
    pd.DataFrame([{"setup": r["name"], "source": r["source"], "conditions": words(r["conds"]),
                   "conds": json.dumps(r["conds"]), "verdict": r["verdict"], "trades": r.get("n"),
                   "days": r.get("days"), "per_year": r.get("per_year"), "net": r.get("mean"), "net_lo": r.get("lo"),
                   "net_hi": r.get("hi"), "net_fresh": r.get("mean_fresh"), "weekly": r.get("wk_mean"),
                   "vs_weekly": r.get("diff"), "vs_weekly_lo": r.get("diff_lo"), "vs_weekly_hi": r.get("diff_hi"),
                   "p": r.get("p"), "tuesday_share": r.get("tuesday_share"), "weekdays": wd_text(r),
                   "all_picks_net": (r.get("all") or {}).get("mean"), "all_picks_vs_weekly": (r.get("all") or {}).get(
                       "diff")} for r in drow]).to_csv(d / "part_d.csv", index=False)
    files += ["money.csv", "frozen_vs_final_001.csv", "conditions.csv", "excluded.csv", "part_d.csv"]
    cand = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
            "declaration_sha256": ddoc["sha256"], "entry_rule": fdoc["entry_rule"],
            "twins": [{"id": r["name"], "conds": r["conds"], "primary_exit": "original_d5", "verdict": r["verdict"]}
                      for r in arow if r.get("conds")],
            "found": [{"id": r.get("fid", ""), "conds": r["conds"], "primary_exit": r["mode"], "verdict": r["verdict"],
                       "found_on": "half A, every price before %s" % SPLIT,
                       "half_b": {k: r["judge"][k] for k in ("n", "mean", "lo", "hi", "diff", "diff_lo", "diff_hi",
                                                             "p", "month_start_share")},
                       "after_split_every_stock": {k: r["post"][k] for k in ("n", "mean", "lo", "hi", "diff",
                                                                              "diff_lo", "diff_hi")}}
                      for r in judged],
            "split_decision": {"verdict": sv, "window": T["window"], "found_weekly": [r.get("fid") for r in found],
                               "conditions": {k: v for k, v in sc.items() if k not in ("cut", "cut_rr", "cut_mean")},
                               "cut_points_mean_of_5_start_days": sc["cut_mean"],
                               "cut_paired_reruns": {"median": sc["cut_rr"][0], "lo": sc["cut_rr"][1],
                                                     "hi": sc["cut_rr"][2], "share_above_0": sc["cut_rr"][3],
                                                     "reruns": RERUNS},
                               "cut_day_block_bootstrap_shown": {"points": sc["cut"][0], "lo": sc["cut"][1],
                                                                 "hi": sc["cut"][2], "share_above_0": sc["cut"][3]}},
            "stratlab": [{"id": r["name"], "conds": r["conds"], "primary_exit": "original_d5", "verdict": r["verdict"],
                          "stratlab_hidden": {k: r.get(k) for k in ("n", "days", "mean", "lo", "hi", "diff", "diff_lo",
                                                                   "diff_hi", "p")}} for r in drow]}
    cand = json.loads(json.dumps(cand, default=lambda x: x.item() if hasattr(x, "item") else str(x)))
    cand["sha256"] = SU.frozen_hash(cand)
    (d / "ANYDAY_CANDIDATES.json").write_text(json.dumps(cand, indent=1, default=str), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    info = {"version": VERSION, "declaration_sha256": ddoc["sha256"], "picks": checks["picks"],
            "frozen_sha256": fdoc["sha256"], "tree_sha256": tdoc["sha256"], "root": str(root), "panel": str(panel),
            "soul": str(soul), "data": str(a.data), "checks": checks, "split_verdict": sv}
    write_report(d, info, A, B, C, checks, Dp, T)
    (d / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    files += ["ANYDAY_CANDIDATES.json", "DECLARATION.json", "RUN.json"]
    SU.write_hashes(d, files)
    nb = sum(1 for r in arow if r["verdict"] == "BETTER") + sum(1 for r in judged if r["verdict"] == "BETTER")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "better": nb, "twins_better": [r["name"] for r in arow if r["verdict"] == "BETTER"],
                 "found_better": [words(r["conds"]) for r in judged if r["verdict"] == "BETTER"],
                 "stratlab_triggers": {r["name"]: r["verdict"] for r in drow},
                 "split_decision": sv, "split_cut": [sc["cut_mean"], sc["cut_rr"][1], sc["cut_rr"][2]],
                 "minutes": round((time.time() - t0) / 60, 1)})
    log("ANYDAY WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    log(" THE DECISION (FOUND+WEEKLY vs FROZEN, %s .. %s): %s" % (T["window"][0], T["window"][1], sv))
    log(" Part A twins: %d judged, %d BETTER than WEEKLY" % (KA, sum(1 for r in arow if r["verdict"] == "BETTER")))
    log(" Part B found: %d judged, %d BETTER than WEEKLY" % (len(judged), sum(1 for r in judged
                                                                             if r["verdict"] == "BETTER")))
    log(" Part D stratlab's triggers: %s" % ", ".join("%s %s" % (r["name"], r["verdict"]) for r in drow))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="anydaylab", description=VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="the twins, the open search and the money (or --check-only)")
    r.add_argument("--root", required=True, help="CACHE_DAILY_ROOT (the daily cache: <SYMBOL>_daily.parquet, panel_oc)")
    r.add_argument("--data", required=True, help="setuplab's watchlist folder (watchlist.parquet, calendar.parquet)")
    r.add_argument("--out", required=True, help="output folder, e.g. C:\\QuantData\\anydaylab")
    r.add_argument("--soul", default=None, help="the Soul file (default <root>\\panel\\soul\\soul_v3_open.parquet)")
    r.add_argument("--panel", default=None, help="default <root>\\panel_oc\\panel.parquet")
    r.add_argument("--check-only", action="store_true", help="inputs, the frozen replays and the tree check; no search")
    a = ap.parse_args(argv)
    return cmd_run(a)


if __name__ == "__main__":
    raise SystemExit(main())
