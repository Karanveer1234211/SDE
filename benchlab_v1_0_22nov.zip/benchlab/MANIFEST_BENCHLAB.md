# MANIFEST - benchlab v1.0 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\benchlab` (a research folder beside `tradelab`, `setuplab`, `treelab` and `triggerlab`). Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\benchlab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `benchlab.py` | 8d7ee32976898eb3 | 52960 |
| `BENCHLAB_DECLARATION.json` | 13b253fbb5488303 | 11767 |
| `README_BENCHLAB.md` | df186f4a6987287c | 5658 |
| `tests\test_benchlab.py` | 9ae4d6c9166dc5c9 | 32132 |
| `MANIFEST_BENCHLAB.md` | this file | - |

Needs, read only, as sibling folders (versions checked at every start):
- setuplab v1.1 (setuplab.py sha16 9979d418aecec6de: Boot, the ETF rule, TREE.json);
- tradelab v1.3.1 (tl_data.py sha16 46ceff88fdadda7f, tl_common.py sha16 ad7e75715da7556a): stage E's daily bars;
- through tradelab's env (env_tradelab.bat): stage_e_execution (the shipped v1.2) and stage_b_screen (ELIG_COL) from bigmove_deploy\open_close.

Declaration: `BENCHLAB_DECLARATION.json`, internal sha256 `7cb5cfaaa3ef5cd1...`. Declared at 2026-11-22 20:15 IST; amended 2026-11-22 21:35 IST. It is checked at every start against this code's settings, and an edited file is refused.

Inputs:
- `%CACHE_DAILY_ROOT%\panel_oc\frozen\FROZEN_ENGINES.json` and the D and ENS runs' `preds.parquet` (sha256-checked);
- `%CACHE_DAILY_ROOT%\panel_oc\panel.parquet` (eligibility, label_oc_5);
- the daily cache through stage E's loader;
- optional: IIMA's daily four-factor CSV (survivorship-bias adjusted), for B6 and the factor tilts.

## History
- v1.0 (22 Nov 2026): first build - the research report's Part 2 horse race.

## Verified (synthetic data only)
`tests\test_benchlab.py` ends `VERIFIED (benchlab v1.0) - 32 checks` on Python 3.13 with pandas 3.0.5 + numpy 2.5.3 and with pandas 2.3.3 + numpy 2.4.1 (about 16 s).
- every simple signal against an independent loop over the raw bars (gaps, carried closes, minimums);
- the universe, each ranking's daily top 3, excess, IC and top-decile IC by hand (scipy's spearmanr);
- the bootstrap, Holm, Newey-West, the alpha OLS and its resamples, disagreement days, Jaccard by hand;
- B6 by an independent regression; an IIMA file in fractions refused;
- the decision rule on hand-made comparisons (BEATS by money / by IC, LOSES, FAIL, INCONCLUSIVE);
- PLANTED world (the engines see what no simple ranking sees): both BEAT SIMPLE, all 24 comparisons;
- ABSENT world (D = momentum + noise): D LOSES TO SIMPLE; REDUNDANT world (D = the 1-week return): D FAIL;
- refusals: edited declaration, preds sha256 mismatch, wrong target, label in points, rows not eligible, --out inside the cache, no eligibility column; --check-only writes nothing; outputs hash-checked.

**Mutation test:** 20 deliberate bugs, each in its own copy of benchlab.py; every one makes the tests fail (momentum's skip month, returns across a gap, Nagel's weights, low volatility's sign, the 52-week high from closes, a missing score ranked first, a top 4, the excess, ETFs kept, Holm, Newey-West, the disagreement days, B6's months, BEATS without Holm, the hardest ranking, FAIL without the alpha, the eligibility check, the bootstrap interval, the sha256 check, the 1-week window).
