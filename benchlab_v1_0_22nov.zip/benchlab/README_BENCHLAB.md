# benchlab v1.0 - do D and ENS beat simple rankings?

Your ask (22 Nov 2026), on the research report: *"Test D/ENS against it"* - then *"Go"* on the plan.

## What it does

Each engine's walk-forward top 3 races 12 simple rankings on the same days, the same stocks, the same entry
(D1 open), the same exit (D5 close) and the same 0.35 cost.

**The engines:** the frozen D run and ENS run named in `FROZEN_ENGINES.json`. Their `preds.parquet` must have the
sha256 the manifest records, or the run is refused. These are the walk-forward scores of every eligible stock on every
test day.

**The universe of a day:** every stock both engines scored that the panel marks eligible, with `label_oc_5` known,
ETFs out. A day needs 30 such stocks.

**The 12 simple rankings** (higher score = buy; everything known at the signal close; r(a,b) = log return from the
close a sessions ago to the close b sessions ago):

| code | ranking | score |
|---|---|---|
| B1 | 1-week reversal | -r(5,0) |
| B2 | 1-week momentum | r(5,0) |
| B3r / B3m | 1-month reversal / momentum | -r(21,0) / r(21,0) |
| B4 | 12-1 momentum | r(252,21) |
| B5 | 52-week high | close / highest high of 252 sessions |
| B6 | residual momentum | IIMA factors, 36-month regressions (only with `--iima`) |
| B7 | low volatility | -(sd of 252 daily returns) |
| B8 | Nagel-style volatility-timed momentum | weighted last 12 weekly returns / 60-session variance |
| B2s / B4s / B8s | the same, risk-scaled | B2 / B4 / B8 divided by the 60-session sd |

The report counted 11 rules; its table has B3 in both signs, so there are 12 (22 comparisons without B6, 24 with).

## How it is judged (declared before any run - `BENCHLAB_DECLARATION.json`)

For each engine against each ranking, day by day:
- **Top-3 difference:** engine's top-3 net minus the ranking's, with a 95% interval (blocks of 10 days, 2,000
  resamples, seed 7).
- **Rank IC:** Spearman of score vs net across every stock, each day; the difference with Newey-West (5 lags).
- **Alpha:** the engine's daily excess regressed on the ranking's.
- **Disagreement days:** days when none of the engine's top 3 is in the ranking's top decile. Does the engine still
  win there? If it wins only when it agrees with momentum, it is momentum.
- **Holm** over all the comparisons.

**Example.** On a day D's top 3 return +1.4 points net and B8's top 3 +0.9, the day's difference is +0.5. The mean of
those differences over every race day, with its interval, says whether D adds anything momentum does not.

Verdicts per engine (the "hardest ranking" is the one closest to beating it):
- **BEATS SIMPLE** - beats the hardest ranking (Holm p <= 0.025), or beats the best ranking's IC (Holm) and still
  wins on the disagreement days. Keep the engine; the hardest ranking goes into the forward ledger as a shadow book.
- **LOSES TO SIMPLE** - the hardest ranking beats the engine (Holm p <= 0.025). The ranking becomes a shadow book;
  month 6 and month 12 decide whether it replaces the engine.
- **FAIL** - not better by 0.15 points a trade (3 bp a day), alpha not above 0, no disagreement-day edge: the engine
  is redundant at current evidence.
- **INCONCLUSIVE** - none of these. The forward ledger decides.

Nothing is re-run with other settings to change a verdict.

**Amended before any real run (21:35 IST):** LOSES TO SIMPLE was added. A synthetic engine that was clearly worse
than momentum read INCONCLUSIVE because its alpha against momentum was positive - diversification, not skill.

## Run

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\benchlab
python tests\test_benchlab.py
python benchlab.py run --root %CACHE_DAILY_ROOT% --out C:\QuantData\benchlab --check-only
python benchlab.py run --root %CACHE_DAILY_ROOT% --out C:\QuantData\benchlab --iima C:\QuantData\benchlab\iima\2025-12_FourFactors_and_Market_Returns_Daily_SurvivorshipBiasAdjusted.csv
```

`--iima` is optional. Without it B6 and the factor tilts are skipped. The IIMA file ends Dec 2025, so B6 is blank
after that.

## What it writes (`C:\QuantData\benchlab\BENCHLAB_<date>_<nnn>\`)

- `BENCHLAB.md` - the verdicts first, then every table
- `comparisons.csv` - every engine x ranking: difference, interval, Holm p's, IC, overlap, disagreement days, alpha, per year
- `rankings.csv` - every ranking's own top-3 net (at 0.35 and 0.50), excess, IC, per year
- `daily.csv`, `picks.csv` - each day's numbers and every ranking's daily top 3 (for a shadow book)
- `spanning.csv`, `fama_macbeth.csv`, `factors.csv` (with `--iima`)
- `BENCHLAB_RESULT.json`, `DECLARATION.json`, `RUN.json`, `outputs.sha256`; a line per run in `benchlab_ledger.jsonl`

## Safety gates (it refuses rather than guess)

- the declaration must be the shipped file;
- each `preds.parquet` must match `FROZEN_ENGINES.json`'s sha256, and the manifest's target must be `label_oc_5`;
- 99.9% of the scored rows must be the panel's eligible rows;
- `label_oc_5` must be a fraction (its median |value| 0.002-0.2);
- 98% of the race's stock-days need a daily close in the cache;
- the eligibility column comes from `stage_b_screen.ELIG_COL` (tradelab's env) or `--elig-col`;
- `--out` may not be inside the cache or a tool folder.

## Limits

- The engines' scores are out of sample fold by fold, but their design was chosen on these years: a head start the
  simple rankings don't have.
- The cache has no point-in-time surveillance lists (ASM/GSM/T2T). Every ranking picks from the same panel universe,
  so none gains from that.
- `label_oc_5` is the plain open-to-close return (no wait on a locked circuit), the engines' own yardstick.
