"""
benchlab.py - benchlab v1.0: do engines D and ENS beat simple rankings? Each engine's walk-forward top 3 against 12
simple point-in-time rankings, on the same days, the same stocks, the same entry and exit and the same cost.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\benchlab
    python tests\\test_benchlab.py
    python benchlab.py run --root %CACHE_DAILY_ROOT% --out C:\\QuantData\\benchlab
                           [--iima C:\\QuantData\\benchlab\\iima\\2025-12_FourFactors_and_Market_Returns_Daily_SurvivorshipBiasAdjusted.csv]

Karan, 22 Nov 2026: "Test D/ENS against it" (the research report's Part 2: a pre-declared, identically executed top-3
race against simple rankings, Nagel-style volatility-timed momentum among them) ... "Go".

WHAT IT DOES
  The engines: FROZEN_ENGINES.json's D and ENS runs (their preds.parquet, sha256-checked) - every eligible stock scored
  on every day of the walk-forward test windows. The universe of a signal day: every stock both engines scored that
  panel_oc marks eligible, with label_oc_5 known, ETFs out. Every ranking buys its top 3 at the D1 open and sells at the
  D5 close (label_oc_5), 0.35 points a round trip. The 12 simple rankings (higher score = buy), from tradelab's daily
  bars, known at the signal close:
      B1 1-week reversal  -r(5,0)          B2 1-week momentum  r(5,0)
      B3r 1-month reversal -r(21,0)        B3m 1-month momentum r(21,0)
      B4 12-1 momentum r(252,21)           B5 52-week high: close / the highest high of 252 sessions
      B6 residual momentum (IIMA factors; only with --iima)
      B7 low volatility: -(sd of 252 daily returns)
      B8 Nagel-style volatility-timed momentum: sum_k (12-k)/78 x weekly return k (k = 0..11) / 60-session variance
      B2s, B4s, B8s = B2, B4, B8 / the 60-session sd
  r(a,b) = log return from the close a sessions ago to the close b sessions ago.

HOW IT IS JUDGED (BENCHLAB_DECLARATION.json, declared before any run)
  For each engine and each ranking, day by day: the engine's top-3 net minus the ranking's (a 95% block bootstrap over
  the days), the daily rank IC (Spearman of score vs net across every stock; Newey-West, 5 lags), the alpha of the
  engine's excess over buy-everything against the ranking's, the days the engine disagrees with the ranking's top
  decile, Holm over every comparison.
    BEATS SIMPLE   = the engine's top 3 beats the hardest ranking (Holm-adjusted p <= 0.025, one-sided), OR its IC
                     beats the best ranking's IC (Holm-adjusted) with a positive edge on the disagreement days.
    LOSES TO SIMPLE = the hardest ranking's top 3 beats the engine's (Holm-adjusted p <= 0.025, one-sided).
    FAIL           = not better by 0.15 points a trade (3 bp a day) with the lower bound under 0, the alpha's interval
                     not above 0, and no edge on the disagreement days: the engine is redundant at current evidence.
    INCONCLUSIVE   = none of these.

Example: on a day D's top 3 return +1.4 points net and B8's top 3 +0.9, the day's difference is +0.5; the mean of
those differences over ~1,800 days, with its interval, says whether D's ranking adds anything momentum does not.

Writes only under --out: BENCHLAB_<date>_<nnn>\\ (BENCHLAB.md first) and a line per run in benchlab_ledger.jsonl.
Research only: nothing in production, the paper test or the frozen tree changes.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
for _env, _name in (("SETUPLAB_DIR", "setuplab"), ("TRADELAB_DIR", "tradelab")):
    _d = os.environ.get(_env) or str(HERE.parent / _name)
    if _d not in sys.path:
        sys.path.insert(0, _d)
import setuplab as SU  # noqa: E402
import tl_common as TC  # noqa: E402
import tl_data as TD  # noqa: E402

VERSION = "benchlab v1.0"
NEEDS = {"setuplab": "setuplab v1.1", "tradelab": "tradelab v1.3.1"}
DECL_FILE = "BENCHLAB_DECLARATION.json"
TARGET = "label_oc_5"
ENGINES = ("D", "ENS")
COST = 0.35                        # points a round trip (the project's 35 bp)
COST_STRESS = 0.50                 # the stress test
TOP = 3
DECILE = 0.10
MIN_UNIVERSE = 30                  # stocks a signal day needs
MIN_SCORED = 30                    # stocks a ranking must score on a day to pick that day
DEC_IC_MIN = 10                    # stocks the top-decile IC needs
LABEL_MED_ABS = (0.002, 0.2)       # panel_oc's labels are fractions (0.012 = +1.2%)
ELIG_MIN_SHARE = 0.999             # the engines' scored rows must be the panel's eligible rows
BARS_MIN_SHARE = 0.98              # universe rows with a daily close on the signal day
BENCH = {
    "B1": "1-week reversal: -r(5,0)",
    "B2": "1-week momentum: r(5,0)",
    "B3r": "1-month reversal: -r(21,0)",
    "B3m": "1-month momentum: r(21,0)",
    "B4": "12-1 momentum: r(252,21)",
    "B5": "52-week high: the close / the highest high of the last 252 sessions",
    "B6": "residual momentum: the sum of the residuals of months m-12..m-2 / their sd, from 36-month regressions of the "
          "stock's monthly excess return on IIMA's MF, SMB and HML",
    "B7": "low volatility: -(the sd of the last 252 daily log returns)",
    "B8": "Nagel-style volatility-timed momentum: sum over k = 0..11 of (12-k)/78 x the log return of week k (5 sessions "
          "each, week 0 ending at the signal close), / the mean squared daily log return of the last 60 sessions",
    "B2s": "B2 / the sd of the last 60 daily log returns (root of B8's variance)",
    "B4s": "B4 / the same sd",
    "B8s": "B8 / the same sd",
}
WIN = {"week": 5, "month": 21, "year": 252, "skip": 21, "high": 252, "high_min": 200, "lowvol": 252,
       "lowvol_min": 200, "nagel_weeks": 12, "var": 60, "var_min": 50}
RESMOM = {"reg_months": 36, "reg_min": 24, "form": [12, 2], "factor_min_days": 15}
FM_SIGNALS = ["engine", "r5", "r21", "mom12_1", "high52", "lowvol", "nagel", "resmom"]
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
NW_LAGS = 5
ALPHA1 = 0.025                     # one-sided = a two-sided 95% interval's lower bound
MARGIN = 0.15                      # points a 5-session trade (= 3 bp a day)
IIMA_COLS = ("date", "mf", "smb", "hml", "wml", "rf")
LOG = (lambda m: print("%s  %s" % (time.strftime("%H:%M:%S"), m), flush=True))


class BLError(Exception):
    pass


def constants():
    return {"target": TARGET, "engines": list(ENGINES), "cost_pp": COST, "cost_stress_pp": COST_STRESS, "top": TOP,
            "decile": DECILE, "min_universe": MIN_UNIVERSE, "min_scored": MIN_SCORED, "decile_ic_min": DEC_IC_MIN,
            "label_med_abs": list(LABEL_MED_ABS), "elig_min_share": ELIG_MIN_SHARE, "bars_min_share": BARS_MIN_SHARE,
            "benchmarks": BENCH, "windows": WIN, "resmom": RESMOM, "fm_signals": FM_SIGNALS,
            "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "nw_lags": NW_LAGS, "alpha_one_sided": ALPHA1,
            "margin_pp": MARGIN}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise BLError("no declaration at %s (it ships beside benchlab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise BLError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise BLError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(),
              Path(SU.__file__).resolve().parent, Path(TD.__file__).resolve().parent):
        if o == b or b in o.parents:
            raise BLError("--out %s is inside %s - outputs go under C:\\QuantData\\benchlab" % (o, b))
    return o


def ledger(out, rec):
    with open(Path(out) / "benchlab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def elig_column(arg):
    if arg:
        return arg
    try:
        import stage_b_screen as SB
        return str(SB.ELIG_COL)
    except Exception as e:  # noqa: BLE001
        raise BLError("cannot read stage_b_screen.ELIG_COL (start with env_tradelab.bat, or pass --elig-col): %s: %s"
                      % (type(e).__name__, e))


def to_days(s):
    t = pd.to_datetime(pd.Series(s))
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t.dt.normalize().to_numpy().astype("datetime64[D]")


def norm_sym(s):
    return pd.Series(s).astype(str).str.strip().str.upper().to_numpy()


def phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


# ====================================================================================================== inputs
def read_engines(root):
    """FROZEN_ENGINES.json's D and ENS runs: every preds.parquet row of the target (day, symbol, score), each file's
    sha256 equal to the one the manifest records."""
    fz = Path(root) / "panel_oc" / "frozen" / "FROZEN_ENGINES.json"
    if not fz.is_file():
        raise BLError("%s not found" % fz)
    man = json.loads(fz.read_text(encoding="utf-8"))
    if man.get("target") != TARGET:
        raise BLError("FROZEN_ENGINES.json's target is %s, not %s" % (man.get("target"), TARGET))
    eng, files = man.get("engines") or {}, man.get("files") or {}
    import pyarrow.parquet as pq
    out, info = {}, {}
    for tag in ENGINES:
        run = (eng.get(tag) or {}).get("run")
        if not run:
            raise BLError("FROZEN_ENGINES.json names no %s run" % tag)
        p = Path(root) / "panel_oc" / "stage_d" / run / "preds.parquet"
        if not p.is_file():
            raise BLError("%s not found" % p)
        rec = files.get("runs/%s/%s/preds.parquet" % (tag, run))
        if not rec:
            raise BLError("FROZEN_ENGINES.json records no sha256 for runs/%s/%s/preds.parquet" % (tag, run))
        got = TC.sha256_file(p)
        if got != rec:
            raise BLError("%s has sha256 %s, not the frozen %s (FROZEN_ENGINES.json) - refusing" % (p, got[:16],
                                                                                                   rec[:16]))
        names = pq.read_schema(p).names
        tk = "timestamp" if "timestamp" in names else ("date" if "date" in names else None)
        if tk is None or "symbol" not in names or "score" not in names:
            raise BLError("%s needs timestamp, symbol and score columns (it has %s)" % (p.name, names[:12]))
        P = pd.read_parquet(p, columns=[tk, "symbol", "score"] + (["target"] if "target" in names else []))
        if "target" in P.columns:
            P = P[P["target"].astype(str) == TARGET]
        df = pd.DataFrame({"day": to_days(P[tk]), "symbol": norm_sym(P["symbol"]),
                           "score": pd.to_numeric(P["score"], errors="coerce").to_numpy(float)})
        df = df[np.isfinite(df["score"].to_numpy())]
        if df.duplicated(["day", "symbol"]).any():
            raise BLError("%s holds two %s scores for one stock and day" % (p, TARGET))
        out[tag] = df.reset_index(drop=True)
        info[tag] = {"run": run, "sha256": got, "rows": int(len(df)),
                     "first_day": str(df["day"].min()) if len(df) else None,
                     "last_day": str(df["day"].max()) if len(df) else None}
    return out, info


def read_panel(panel, elig):
    import pyarrow.parquet as pq
    names = pq.read_schema(panel).names
    low = {c.lower(): c for c in names}
    dk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or not dk:
        raise BLError("the panel needs symbol and timestamp columns")
    if elig.lower() not in low:
        raise BLError("the panel has no eligibility column %s" % elig)
    if TARGET not in low:
        raise BLError("the panel has no %s (buy the next open, sell the 5th close)" % TARGET)
    T = pq.read_table(panel, columns=[low["symbol"], dk, low[elig.lower()], low[TARGET]]).to_pandas()
    df = pd.DataFrame({"day": to_days(T[dk]), "symbol": norm_sym(T[low["symbol"]]),
                       "elig": pd.to_numeric(T[low[elig.lower()]], errors="coerce").to_numpy(float),
                       "label": pd.to_numeric(T[low[TARGET]], errors="coerce").to_numpy(float)})
    if df.duplicated(["day", "symbol"]).any():
        raise BLError("the panel has duplicated symbol / day rows")
    return df


def build_universe(S, PN, root, log=LOG):
    """Rows both engines scored x the panel: label known, ETFs out, eligible; days with MIN_UNIVERSE stocks."""
    U = S["D"].rename(columns={"score": "s_D"}).merge(S["ENS"].rename(columns={"score": "s_ENS"}),
                                                      on=["day", "symbol"], how="inner")
    n_both = len(U)
    U = U.merge(PN, on=["day", "symbol"], how="inner")
    n_panel = len(U)
    _, tdoc = SU.load_tree()
    us = np.unique(U["symbol"].to_numpy())
    etf_u = SU.tree_etf(us, tdoc, SU.etf_list(root))
    etf = etf_u[np.searchsorted(us, U["symbol"].to_numpy())]
    lab = U["label"].to_numpy(float)
    keep = np.isfinite(lab) & ~etf
    U = U[keep]
    if not len(U):
        raise BLError("no stock-day has both engines' scores, the panel's row and a known %s" % TARGET)
    share = float((U["elig"].to_numpy() == 1).mean())
    if share < ELIG_MIN_SHARE:
        raise BLError("only %.2f%% of the engines' scored rows are eligible in the panel (needs %.1f%%) - not the "
                      "frozen runs' universe" % (100 * share, 100 * ELIG_MIN_SHARE))
    U = U[U["elig"].to_numpy() == 1]
    med = float(np.nanmedian(np.abs(U["label"].to_numpy(float))))
    if not (LABEL_MED_ABS[0] <= med <= LABEL_MED_ABS[1]):
        raise BLError("%s's median |value| is %.4g - not a fraction return (0.012 = +1.2%%) as panel_oc stores it - "
                      "stopping rather than guessing" % (TARGET, med))
    cnt = U.groupby("day")["symbol"].transform("size").to_numpy()
    small_days = int(U.loc[cnt < MIN_UNIVERSE, "day"].nunique())
    U = U[cnt >= MIN_UNIVERSE].sort_values(["day", "symbol"], kind="mergesort").reset_index(drop=True)
    info = {"rows_both_engines": n_both, "rows_with_panel": n_panel, "etf_rows": int(etf.sum()),
            "eligible_share": share, "label_median_abs": med, "days_too_small": small_days, "rows": int(len(U)),
            "days": int(U["day"].nunique()), "stocks": int(U["symbol"].nunique()),
            "first_day": str(U["day"].min()) if len(U) else None, "last_day": str(U["day"].max()) if len(U) else None}
    return U, info


def load_bars(root, syms, stage_e_any=False, log=LOG):
    """tradelab's daily bars (stage E's loader) on NIFTY50's sessions: close and high, NaN where a stock has no bar."""
    prod = TD.Production(stage_e_any=stage_e_any)
    mk = TD.Market(root, prod)
    cal = np.asarray(mk.cal).astype("datetime64[D]")
    t0 = time.time()
    for i in range(0, len(syms), 200):
        mk.load(list(syms[i:i + 200]))
        log(" bars: %d of %d stocks read (%.0f s)" % (min(i + 200, len(syms)), len(syms), time.time() - t0))
    C = np.full((len(syms), len(cal)), np.nan)
    H = np.full((len(syms), len(cal)), np.nan)
    for i, s in enumerate(syms):
        ds = mk.series(str(s))
        if ds is None or not len(ds):
            continue
        d = np.asarray(ds.dates).astype("datetime64[D]")
        pos = np.searchsorted(cal, d)
        ok = (pos < len(cal))
        ok[ok] = cal[pos[ok]] == d[ok]
        C[i, pos[ok]] = np.asarray(ds.c, float)[ok]
        H[i, pos[ok]] = np.asarray(ds.h, float)[ok]
    return cal, C, H, mk


def read_iima(path):
    """IIMA's daily four-factor file (Date, SMB, HML, WML, MF, RF; percent; NA = missing) -> DataFrame by day."""
    p = Path(path)
    if not p.is_file():
        raise BLError("--iima %s not found" % p)
    df = pd.read_csv(p)
    low = {str(c).strip().lower(): c for c in df.columns}
    miss = [c for c in IIMA_COLS if c not in low]
    if miss:
        raise BLError("%s lacks columns %s (IIMA's daily file has Date, SMB, HML, WML, MF, RF)" % (p.name, miss))
    day = pd.to_datetime(df[low["date"]], errors="coerce")
    F = pd.DataFrame({c.upper(): pd.to_numeric(df[low[c]], errors="coerce").to_numpy(float) for c in IIMA_COLS[1:]})
    F["day"] = day.to_numpy().astype("datetime64[D]")
    F = F[day.notna().to_numpy()].drop_duplicates("day", keep="last").sort_values("day").reset_index(drop=True)
    med = float(np.nanmedian(np.abs(F["MF"].to_numpy())))
    if not (0.05 <= med <= 5.0):
        raise BLError("%s: the median |MF| is %.4g - not daily percent returns (IIMA's daily file)" % (p.name, med))
    return F


# ====================================================================================================== signals
def _lag(a, k):
    out = np.full_like(a, np.nan)
    if k == 0:
        return a.copy()
    out[k:] = a[:-k]
    return out


def base_signals(C, H):
    """Per (day, stock) arrays (days x stocks) of every simple signal, from data up to that day's close."""
    W = WIN
    Ct = C.T
    Cf = pd.DataFrame(Ct).ffill().to_numpy()
    with np.errstate(invalid="ignore", divide="ignore"):
        L = np.log(np.where(Cf > 0, Cf, np.nan))
        Lr = np.log(np.where(Ct > 0, Ct, np.nan))
        lr = Lr - _lag(Lr, 1)                                    # a daily return needs both bars
    r5 = L - _lag(L, W["week"])
    r21 = L - _lag(L, W["month"])
    mom = _lag(L, W["skip"]) - _lag(L, W["year"])
    v60 = pd.DataFrame(lr ** 2).rolling(W["var"], min_periods=W["var_min"]).mean().to_numpy()
    sd252 = pd.DataFrame(lr).rolling(W["lowvol"], min_periods=W["lowvol_min"]).std(ddof=1).to_numpy()
    hi = pd.DataFrame(H.T).rolling(W["high"], min_periods=W["high_min"]).max().to_numpy()
    nag = np.zeros_like(L)
    for k in range(W["nagel_weeks"]):
        nag = nag + (W["nagel_weeks"] - k) / 78.0 * (_lag(L, W["week"] * k) - _lag(L, W["week"] * (k + 1)))
    with np.errstate(invalid="ignore", divide="ignore"):
        v = np.where(v60 > 0, v60, np.nan)
        sd60 = np.sqrt(v)
        high52 = np.where(np.isfinite(Ct) & (hi > 0), Ct / hi, np.nan)
        nagel = nag / v
    return {"r5": r5, "r21": r21, "mom12_1": mom, "high52": high52, "lowvol": -sd252, "nagel": nagel, "sd60": sd60}


def bench_scores(G, si, ti):
    """The 12 rankings' scores (B6 apart) for rows (stock index si, calendar index ti)."""
    g = {k: v[ti, si] for k, v in G.items()}
    with np.errstate(invalid="ignore", divide="ignore"):
        return {"B1": -g["r5"], "B2": g["r5"], "B3r": -g["r21"], "B3m": g["r21"], "B4": g["mom12_1"],
                "B5": g["high52"], "B7": g["lowvol"], "B8": g["nagel"], "B2s": g["r5"] / g["sd60"],
                "B4s": g["mom12_1"] / g["sd60"], "B8s": g["nagel"] / g["sd60"]}, g


def month_code(days):
    """Calendar month as an integer (year x 12 + month - 1)."""
    return np.asarray(days).astype("datetime64[M]").astype(np.int64)


def monthly_factors(F):
    """IIMA's daily factors compounded into calendar months (fractions), indexed by month_code; a month with fewer
    than factor_min_days values is missing."""
    m = month_code(F["day"].to_numpy())
    out = {}
    for c in ("MF", "SMB", "HML", "RF"):
        x = 1.0 + F[c].to_numpy(float) / 100.0
        g = pd.DataFrame({"m": m, "x": x}).groupby("m")["x"]
        val = g.prod(min_count=1) - 1.0
        n = g.count()
        val[n < RESMOM["factor_min_days"]] = np.nan
        out[c] = val
    return pd.DataFrame(out)


def resmom(C, cal, F):
    """B6 per (day, stock): for the signal day's month m, OLS of the stock's monthly excess return (last close of the
    month / last close of the month before - 1 - RF) on [1, MF, SMB, HML] over months m-36..m-1 (every factor month
    present, at least reg_min stock months); score = the sum of the residuals of months m-12..m-2 / their sd (all 11
    present). The same score for every day of month m."""
    n_reg, n_min = RESMOM["reg_months"], RESMOM["reg_min"]
    f0, f1 = RESMOM["form"]
    mon = month_code(cal)
    months = np.arange(mon.min() - n_reg, mon.max() + 1)        # a window may reach back before the bars begin
    last = pd.DataFrame(C.T).groupby(mon).last()                 # the last close of each month (per stock)
    last = last.reindex(months)
    R = last.to_numpy() / _lag(last.to_numpy(), 1) - 1.0         # months x stocks
    FM = monthly_factors(F).reindex(months)
    X_all = np.column_stack([np.ones(len(months)), FM["MF"].to_numpy(), FM["SMB"].to_numpy(), FM["HML"].to_numpy()])
    rf = FM["RF"].to_numpy()
    score_m = np.full((len(months), C.shape[0]), np.nan)
    form = np.arange(n_reg - f0, n_reg - f1 + 1)                  # positions of months m-12..m-2 in the window
    for mi in range(n_reg, len(months)):
        w = np.arange(mi - n_reg, mi)
        X = X_all[w]
        if not np.isfinite(X).all() or not np.isfinite(rf[w]).all():
            continue
        Y = R[w] - rf[w][:, None]
        ok = np.isfinite(Y)
        nv = ok.sum(0)
        full = np.flatnonzero(nv == n_reg)
        if len(full):
            b, *_ = np.linalg.lstsq(X, Y[:, full], rcond=None)
            E = Y[:, full] - X @ b
            e = E[form]
            sd = e.std(axis=0, ddof=1)
            with np.errstate(invalid="ignore", divide="ignore"):
                score_m[mi, full] = np.where(sd > 0, e.sum(0) / sd, np.nan)
        part = np.flatnonzero((nv >= n_min) & (nv < n_reg) & ok[form].all(0))
        for j in part:
            r = ok[:, j]
            b, *_ = np.linalg.lstsq(X[r], Y[r, j], rcond=None)
            e = (Y[form, j] - X[form] @ b)
            sd = e.std(ddof=1)
            if sd > 0:
                score_m[mi, j] = e.sum() / sd
    mpos = np.searchsorted(months, mon)
    return score_m[mpos]                                           # days x stocks


# ====================================================================================================== the race
class Race:
    """The universe rows (sorted by day, symbol) with every ranking's picks and daily numbers."""

    def __init__(self, U):
        self.day = U["day"].to_numpy().astype("datetime64[D]")
        self.days, self.di = np.unique(self.day, return_inverse=True)
        self.nd = len(self.days)
        self.sym = U["symbol"].to_numpy().astype(str)
        self.net = 100.0 * U["label"].to_numpy(float) - COST
        self.n = len(self.net)
        self.cnt = np.bincount(self.di, minlength=self.nd).astype(float)
        self.all = np.bincount(self.di, weights=self.net, minlength=self.nd) / self.cnt
        self.R = {}

    def positions(self, s):
        """Each row's place in its day by score (descending, ties by symbol; no score last) and the day's count of
        scored rows."""
        fin = np.isfinite(s)
        key = np.where(fin, -s, np.inf)
        o = np.lexsort((self.sym, key, self.di))
        d = self.di[o]
        first = np.r_[True, d[1:] != d[:-1]]
        gstart = np.flatnonzero(first)
        pos = np.empty(self.n, np.int64)
        pos[o] = np.arange(self.n) - np.repeat(gstart, np.diff(np.r_[gstart, self.n]))
        nfin = np.bincount(self.di, weights=fin.astype(float), minlength=self.nd)
        return pos, nfin

    def spearman(self, s, y, mask, min_n):
        """Daily Spearman of s vs y over the rows in mask (average ranks), NaN on a day with fewer than min_n."""
        m = mask & np.isfinite(s) & np.isfinite(y)
        out = np.full(self.nd, np.nan)
        if not m.any():
            return out
        F = pd.DataFrame({"d": self.di[m], "a": s[m], "b": y[m]})
        g = F.groupby("d")
        r1 = g["a"].rank(method="average").to_numpy(float)
        r2 = g["b"].rank(method="average").to_numpy(float)
        d = F["d"].to_numpy()
        n = np.bincount(d, minlength=self.nd).astype(float)
        s1, s2 = np.bincount(d, r1, self.nd), np.bincount(d, r2, self.nd)
        s11, s22, s12 = np.bincount(d, r1 * r1, self.nd), np.bincount(d, r2 * r2, self.nd), np.bincount(d, r1 * r2,
                                                                                                         self.nd)
        with np.errstate(invalid="ignore", divide="ignore"):
            cov = s12 / n - (s1 / n) * (s2 / n)
            rho = cov / np.sqrt((s11 / n - (s1 / n) ** 2) * (s22 / n - (s2 / n) ** 2))
        out[n >= min_n] = rho[n >= min_n]
        return out

    def add(self, name, s):
        s = np.asarray(s, float)
        pos, nfin = self.positions(s)
        valid = nfin >= MIN_SCORED
        fin = np.isfinite(s)
        top = (pos < TOP) & fin & valid[self.di]
        kdec = np.ceil(DECILE * nfin).astype(np.int64)
        dec = (pos < kdec[self.di]) & fin & valid[self.di]
        with np.errstate(invalid="ignore", divide="ignore"):
            t3 = np.where(valid, np.bincount(self.di[top], weights=self.net[top], minlength=self.nd) / TOP, np.nan)
        ic = self.spearman(s, self.net, np.ones(self.n, bool), MIN_SCORED)
        ic[~valid] = np.nan
        dic = self.spearman(s, self.net, dec, DEC_IC_MIN)
        dic[~valid] = np.nan
        self.R[name] = {"s": s, "pos": pos, "top": top, "dec": dec, "valid": valid, "t3": t3, "ex": t3 - self.all,
                        "ic": ic, "dic": dic, "nfin": nfin}
        return self.R[name]


def boot_mean(B_, di, x):
    """Mean of x (rows on days di), its 95% interval and sd from the day-block resamples."""
    n = B_.M.shape[1]
    s = np.bincount(di, weights=x, minlength=n)
    c = np.bincount(di, minlength=n).astype(float)
    S, Cn = B_.M @ s, B_.M @ c
    with np.errstate(invalid="ignore", divide="ignore"):
        m = S / np.where(Cn > 0, Cn, np.nan)
    est = float(s.sum() / c.sum()) if c.sum() > 0 else np.nan
    if not np.isfinite(m).any():
        return est, np.nan, np.nan, np.nan
    lo, hi = np.nanpercentile(m, [2.5, 97.5])
    return est, float(lo), float(hi), float(np.nanstd(m, ddof=1))


def p_one(est, sd):
    """One-sided p (H1: mean > 0) from the bootstrap sd."""
    if not (np.isfinite(est) and np.isfinite(sd)) or sd <= 0:
        return np.nan
    return 1.0 - phi(est / sd)


def nw_mean(x, lags=NW_LAGS):
    """Mean of a daily series and its Newey-West (Bartlett) standard error."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < lags + 2:
        return np.nan, np.nan
    e = x - x.mean()
    s = e @ e / n
    for lg in range(1, lags + 1):
        s += 2.0 * (1.0 - lg / (lags + 1.0)) * (e[lg:] @ e[:-lg]) / n
    return float(x.mean()), float(math.sqrt(max(s, 0.0) / n))


def holm(p):
    """Holm's step-down adjusted p-values (NaN stays NaN; the rest count in m)."""
    p = np.asarray(p, float)
    fin = np.flatnonzero(np.isfinite(p))
    m = len(fin)
    adj = np.full(len(p), np.nan)
    order = fin[np.argsort(p[fin], kind="mergesort")]
    run = 0.0
    for i, j in enumerate(order):
        run = max(run, min(1.0, (m - i) * p[j]))
        adj[j] = run
    return adj


def boot_ols(B_, di, y, X):
    """OLS of y on X (rows on days di) and the day-block resamples' coefficients -> (beta, betas (B x k))."""
    n = B_.M.shape[1]
    k = X.shape[1]
    XX = np.zeros((n, k * k))
    Xy = np.zeros((n, k))
    np.add.at(XX, di, (X[:, :, None] * X[:, None, :]).reshape(len(y), k * k))
    np.add.at(Xy, di, X * y[:, None])
    beta = np.linalg.lstsq(XX.sum(0).reshape(k, k), Xy.sum(0), rcond=None)[0]
    A = (B_.M @ XX).reshape(-1, k, k)
    b = B_.M @ Xy
    try:
        betas = np.linalg.solve(A, b[..., None])[..., 0]
    except np.linalg.LinAlgError:
        betas = np.stack([np.linalg.lstsq(A[i], b[i], rcond=None)[0] for i in range(len(A))])
    return beta, betas


def nmean(v):
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    return float(v.mean()) if len(v) else np.nan


def ci(v):
    v = np.asarray(v, float)
    v = v[np.isfinite(v)]
    if not len(v):
        return np.nan, np.nan
    lo, hi = np.percentile(v, [2.5, 97.5])
    return float(lo), float(hi)


def compare(Rc, B_, e, b, years):
    """Engine e vs ranking b: the top-3 difference, the IC difference, overlap, disagreement days, the alpha."""
    E, Bk = Rc.R[e], Rc.R[b]
    both = E["valid"] & Bk["valid"]
    dd = np.flatnonzero(both)
    x = (E["t3"] - Bk["t3"])[dd]
    est, lo, hi, sd = boot_mean(B_, dd, x)
    icd = (E["ic"] - Bk["ic"])[dd]
    ic_m, ic_se = nw_mean(icd)
    # overlap of the top-3 sets and the agreement with b's top decile
    t_e, t_b = E["top"], Bk["top"]
    inter = np.bincount(Rc.di[t_e & t_b], minlength=Rc.nd)
    jac = inter / (2 * TOP - inter)
    in_dec = np.bincount(Rc.di[t_e & Bk["dec"]], minlength=Rc.nd)
    dis = both & (in_dec == 0)
    di_ = np.flatnonzero(dis)
    xdis = (E["t3"] - Bk["t3"])[di_]
    d_est, d_lo, d_hi, _ = boot_mean(B_, di_, xdis) if len(di_) >= 2 else (
        float(xdis.mean()) if len(xdis) else np.nan, np.nan, np.nan, np.nan)
    ag = np.flatnonzero(both & (in_dec > 0))
    a_est = float((E["t3"] - Bk["t3"])[ag].mean()) if len(ag) else np.nan
    rho = Rc.spearman(E["s"], Bk["s"], np.ones(Rc.n, bool), MIN_SCORED)
    # alpha of the engine's excess on the ranking's excess
    y = E["ex"][dd]
    X = np.column_stack([np.ones(len(dd)), Bk["ex"][dd]])
    beta, betas = boot_ols(B_, dd, y, X)
    a_lo, a_hi = ci(betas[:, 0])
    row = {"engine": e, "ranking": b, "days": int(len(dd)), "engine_net": float(E["t3"][dd].mean()),
           "ranking_net": float(Bk["t3"][dd].mean()), "diff": est, "diff_lo": lo, "diff_hi": hi, "diff_sd": sd,
           "p": p_one(est, sd), "p_rev": p_one(-est, sd), "ic_engine": nmean(E["ic"][dd]), "ic_ranking": nmean(Bk["ic"][dd]),
           "ic_diff": ic_m, "ic_se": ic_se, "ic_lo": ic_m - 1.96 * ic_se, "ic_hi": ic_m + 1.96 * ic_se,
           "p_ic": (1.0 - phi(ic_m / ic_se)) if (np.isfinite(ic_se) and ic_se > 0) else np.nan,
           "jaccard": float(np.mean(jac[dd])), "score_rho": nmean(rho[dd]),
           "dis_days": int(len(di_)), "dis_diff": d_est, "dis_lo": d_lo, "dis_hi": d_hi, "agree_days": int(len(ag)),
           "agree_diff": a_est, "alpha": float(beta[0]), "alpha_lo": a_lo, "alpha_hi": a_hi, "beta": float(beta[1])}
    for y_ in years:
        m = pd.DatetimeIndex(Rc.days[dd]).year == y_
        row["diff_%d" % y_] = float(x[m].mean()) if m.any() else np.nan
    return row


def spanning(Rc, B_, e, names):
    """The engine's excess on every ranking's excess together (days all are defined): the alpha and its interval."""
    E = Rc.R[e]
    ok = E["valid"].copy()
    for b in names:
        ok &= Rc.R[b]["valid"]
    dd = np.flatnonzero(ok)
    if len(dd) < len(names) + 30:
        return {"engine": e, "days": int(len(dd)), "alpha": np.nan, "alpha_lo": np.nan, "alpha_hi": np.nan}
    X = np.column_stack([np.ones(len(dd))] + [Rc.R[b]["ex"][dd] for b in names])
    beta, betas = boot_ols(B_, dd, E["ex"][dd], X)
    lo, hi = ci(betas[:, 0])
    return {"engine": e, "days": int(len(dd)), "alpha": float(beta[0]), "alpha_lo": lo, "alpha_hi": hi,
            "rankings": " ".join(names)}


def factor_tilts(Rc, B_, e, F, cal):
    """The engine's daily excess on IIMA's factors summed over the hold (sessions D1..D5): alpha and betas."""
    fp = {d: i for i, d in enumerate(F["day"].to_numpy().astype("datetime64[D]"))}
    cpos = {d: i for i, d in enumerate(cal)}
    cols = ("MF", "SMB", "HML", "WML")
    V = F[list(cols)].to_numpy(float)
    W = np.full((Rc.nd, len(cols)), np.nan)
    for j, d in enumerate(Rc.days):
        t = cpos.get(d)
        if t is None or t + 5 >= len(cal):
            continue
        idx = [fp.get(cal[t + k]) for k in range(1, 6)]
        if any(i is None for i in idx):
            continue
        W[j] = V[idx].sum(0)
    E = Rc.R[e]
    ok = E["valid"] & np.isfinite(W).all(1)
    dd = np.flatnonzero(ok)
    if len(dd) < 60:
        return None
    X = np.column_stack([np.ones(len(dd)), W[dd]])
    beta, betas = boot_ols(B_, dd, E["ex"][dd], X)
    out = {"engine": e, "days": int(len(dd)), "from": str(Rc.days[dd[0]]), "to": str(Rc.days[dd[-1]])}
    for i, nm in enumerate(("alpha",) + cols):
        lo, hi = ci(betas[:, i])
        out[nm], out[nm + "_lo"], out[nm + "_hi"] = float(beta[i]), lo, hi
    return out


def fama_macbeth(Rc, e, G):
    """Each day: OLS across stocks of net on the day's rank-standardised engine score and base signals (rows with all
    of them); the coefficients' means with Newey-West intervals."""
    names = ["engine"] + [k for k in FM_SIGNALS[1:] if k in G]
    cols = [Rc.R[e]["s"]] + [G[k] for k in names[1:]]
    ok = np.ones(Rc.n, bool)
    for c in cols:
        ok &= np.isfinite(c)
    idx = np.flatnonzero(ok)
    if not len(idx):
        return []
    F = pd.DataFrame({"d": Rc.di[idx]})
    Z = []
    for c in cols:
        F["x"] = c[idx]
        r = F.groupby("d")["x"].rank(method="average").to_numpy(float)
        F["r"] = r
        g = F.groupby("d")["r"]
        mu, sd = g.transform("mean").to_numpy(), g.transform("std").to_numpy()
        with np.errstate(invalid="ignore", divide="ignore"):
            Z.append(np.where(sd > 0, (r - mu) / sd, 0.0))
    X = np.column_stack([np.ones(len(idx))] + Z)
    y = Rc.net[idx]
    d = Rc.di[idx]
    k = X.shape[1]
    XX = np.zeros((Rc.nd, k * k))
    Xy = np.zeros((Rc.nd, k))
    np.add.at(XX, d, (X[:, :, None] * X[:, None, :]).reshape(len(y), k * k))
    np.add.at(Xy, d, X * y[:, None])
    nday = np.bincount(d, minlength=Rc.nd)
    coef = np.full((Rc.nd, k), np.nan)
    for j in np.flatnonzero(nday >= MIN_SCORED):
        A = XX[j].reshape(k, k)
        try:
            coef[j] = np.linalg.solve(A, Xy[j])
        except np.linalg.LinAlgError:
            coef[j] = np.linalg.lstsq(A, Xy[j], rcond=None)[0]
    out = []
    for i, nm in enumerate(names):
        m, se = nw_mean(coef[:, i + 1])
        out.append({"engine": e, "signal": nm, "days": int(np.isfinite(coef[:, i + 1]).sum()), "coef": m,
                    "se": se, "lo": m - 1.96 * se, "hi": m + 1.96 * se})
    return out


def decide(rows):
    """The declared rule for one engine's comparisons (Holm already applied: p_holm, p_ic_holm, p_rev_holm)."""
    R = pd.DataFrame(rows)
    bp = R.loc[R["diff"].idxmin()]
    bi = R.loc[R["ic_diff"].idxmin()] if R["ic_diff"].notna().any() else bp
    beats_pl = bool(np.isfinite(bp["p_holm"]) and bp["p_holm"] <= ALPHA1)
    beats_ic = bool(np.isfinite(bi["p_ic_holm"]) and bi["p_ic_holm"] <= ALPHA1 and np.isfinite(bi["dis_diff"])
                    and bi["dis_diff"] > 0)
    loses = bool(np.isfinite(bp.get("p_rev_holm", np.nan)) and bp["p_rev_holm"] <= ALPHA1)
    no_dis_edge = bool(bp["dis_days"] < 2 or not np.isfinite(bp["dis_lo"]) or bp["dis_lo"] <= 0)
    fail = bool(np.isfinite(bp["diff"]) and bp["diff"] < MARGIN and np.isfinite(bp["diff_lo"]) and bp["diff_lo"] < 0
                and np.isfinite(bp["alpha_lo"]) and bp["alpha_lo"] <= 0 and no_dis_edge)
    verdict = "BEATS SIMPLE" if (beats_pl or beats_ic) else ("LOSES TO SIMPLE" if loses else
                                                             ("FAIL" if fail else "INCONCLUSIVE"))
    return {"verdict": verdict, "best_pl": str(bp["ranking"]), "best_ic": str(bi["ranking"]), "beats_pl": beats_pl,
            "beats_ic": beats_ic, "loses": loses, "fail_conditions": fail}


# ====================================================================================================== report
def _p(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "n/a"
    return ("%+.*f" if sign else "%.*f") % (nd, x)


def _ci(lo, hi, nd=2):
    if not (np.isfinite(lo) and np.isfinite(hi)):
        return "[n/a]"
    return "[%+.*f, %+.*f]" % (nd, lo, nd, hi)


def _pv(p):
    return "n/a" if p is None or not np.isfinite(p) else ("%.4f" % p if p >= 0.0001 else "<0.0001")


def write_report(d, info, res):
    L = ["# benchlab v1.0 - D and ENS against simple rankings", "",
         "Run %s, %s. Declaration %s. Race days %s .. %s (%d days, %d stock-days, median %d stocks a day)." % (
             d.name, info["made"], info["declaration_sha256"][:16], info["universe"]["first_day"],
             info["universe"]["last_day"], info["universe"]["days"], info["universe"]["rows"], info["median_stocks"]),
         "", "## The verdicts", ""]
    for e in ENGINES:
        v = res["decisions"][e]
        C = {r["ranking"]: r for r in res["comparisons"] if r["engine"] == e}
        bp, bi = C[v["best_pl"]], C[v["best_ic"]]
        L.append("**%s: %s.**" % (e, v["verdict"]))
        L.append("")
        L.append("- Hardest ranking by money: %s (%s). %s top 3 minus its top 3: %s points a trade %s, Holm p %s "
                 "(BEATS needs <= 0.025; the other way, %s)." % (
                     bp["ranking"], BENCH[bp["ranking"]].split(":")[0], e, _p(bp["diff"], 3),
                     _ci(bp["diff_lo"], bp["diff_hi"], 3), _pv(bp["p_holm"]), _pv(bp["p_rev_holm"])))
        L.append("- Best ranking by IC: %s. IC %s %s vs %s: difference %s %s, Holm p %s; on the %d days %s's top 3 sat "
                 "outside its top decile: %s points a trade %s." % (
                     bi["ranking"], e, _p(bi["ic_engine"], 4), _p(bi["ic_ranking"], 4), _p(bi["ic_diff"], 4),
                     _ci(bi["ic_lo"], bi["ic_hi"], 4), _pv(bi["p_ic_holm"]), bi["dis_days"], e, _p(bi["dis_diff"], 3),
                     _ci(bi["dis_lo"], bi["dis_hi"], 3)))
        L.append("- Alpha of %s's daily excess on %s's: %s points a trade %s (beta %.2f); disagreement days vs %s: %d, "
                 "%s %s." % (e, bp["ranking"], _p(bp["alpha"], 3), _ci(bp["alpha_lo"], bp["alpha_hi"], 3),
                             bp["beta"], bp["ranking"], bp["dis_days"], _p(bp["dis_diff"], 3),
                             _ci(bp["dis_lo"], bp["dis_hi"], 3)))
        L.append("")
    L += ["What the verdicts mean (declared): BEATS SIMPLE - keep the engine; the hardest ranking becomes a shadow book "
          "in the forward paper ledger. LOSES TO SIMPLE - the simple ranking earned more on these days: it becomes a "
          "shadow book beside the engine, and the forward ledger's month 6 and month 12 decide whether it replaces "
          "the engine (a positive alpha alone means the engine diversifies it, not that it is better). FAIL - the ML "
          "ranking is redundant at current evidence: replace it with the simple rule or keep the engine only as a "
          "tie-breaker inside that rule's top decile; do not retrain to beat it on the same history. INCONCLUSIVE - "
          "the forward ledger decides; the IC and disagreement-day numbers are the strongest evidence here. Points a "
          "trade = a 5-session hold; divide by 5 for a day.", ""]
    L += ["## Every ranking (each day's top 3, D1 open to D5 close)", "",
          "| ranking | what | days | top-3 net (0.35) | at 0.50 | excess over all | 95% | mean IC | top-decile IC |",
          "|---|---|---|---|---|---|---|---|---|"]
    for r in res["rankings"]:
        L.append("| %s | %s | %d | %s | %s | %s | %s | %s | %s |" % (
            r["ranking"], (BENCH.get(r["ranking"], "engine") or "").split(":")[0], r["days"], _p(r["net"], 3),
            _p(r["net_stress"], 3), _p(r["excess"], 3), _ci(r["excess_lo"], r["excess_hi"], 3), _p(r["ic"], 4),
            _p(r["dic"], 4)))
    L += ["", "## Each engine against each ranking (Holm over all %d comparisons)" % len(res["comparisons"]), "",
          "| engine | ranking | days | engine - ranking | 95% | Holm p | IC diff | 95% (NW) | Holm p | Jaccard | "
          "score rho | disagree days | diff on them | 95% | alpha | 95% |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in res["comparisons"]:
        L.append("| %s | %s | %d | %s | %s | %s | %s | %s | %s | %.3f | %.3f | %d | %s | %s | %s | %s |" % (
            r["engine"], r["ranking"], r["days"], _p(r["diff"], 3), _ci(r["diff_lo"], r["diff_hi"], 3),
            _pv(r["p_holm"]), _p(r["ic_diff"], 4), _ci(r["ic_lo"], r["ic_hi"], 4), _pv(r["p_ic_holm"]),
            r["jaccard"], r["score_rho"], r["dis_days"], _p(r["dis_diff"], 3), _ci(r["dis_lo"], r["dis_hi"], 3),
            _p(r["alpha"], 3), _ci(r["alpha_lo"], r["alpha_hi"], 3)))
    L += ["", "## Spanning: each engine's excess on every ranking's together", ""]
    for s in res["spanning"]:
        L.append("- %s: alpha %s points a trade %s over %d days." % (s["engine"], _p(s["alpha"], 3),
                                                                      _ci(s["alpha_lo"], s["alpha_hi"], 3), s["days"]))
    L += ["", "## Fama-MacBeth (shown, not deciding): net on rank-standardised signals, each day", "",
          "| engine | signal | days | coefficient (points per sd) | 95% (NW) |", "|---|---|---|---|---|"]
    for r in res["fm"]:
        L.append("| %s | %s | %d | %s | %s |" % (r["engine"], r["signal"], r["days"], _p(r["coef"], 4),
                                                  _ci(r["lo"], r["hi"], 4)))
    if res["factors"]:
        L += ["", "## IIMA factor tilts (shown): the engine's excess on MF, SMB, HML, WML summed over D1..D5", "",
              "| engine | days | alpha | 95% | MF | SMB | HML | WML |", "|---|---|---|---|---|---|---|---|"]
        for f in res["factors"]:
            L.append("| %s | %d (%s .. %s) | %s | %s | %.3f | %.3f | %.3f | %.3f |" % (
                f["engine"], f["days"], f["from"], f["to"], _p(f["alpha"], 3), _ci(f["alpha_lo"], f["alpha_hi"], 3),
                f["MF"], f["SMB"], f["HML"], f["WML"]))
    else:
        L += ["", "IIMA factors: not given (--iima), so B6 and the factor tilts were not run."]
    L += ["", "## Checks", ""] + ["- %s: %s" % (k, v) for k, v in info["checks"].items()]
    L += ["", "Limits: the engines' scores are out of sample fold by fold, but their design was chosen on these years "
          "(a head start the simple rankings do not have). No point-in-time surveillance lists (ASM/GSM/T2T) exist "
          "in the cache: every ranking chooses from the same panel universe, so none gains from it. The returns are "
          "panel_oc's label_oc_5 (the plain D1-open to D5-close return), the engines' own yardstick."]
    (d / "BENCHLAB.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ====================================================================================================== run
def resolve_inputs(a):
    root = Path(a.root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    if not panel.is_file():
        raise BLError("panel not found: %s" % panel)
    return root, panel


def cmd_run(a, log=LOG):
    t0 = time.time()
    try:
        dp, ddoc = load_declaration()
        found = {"setuplab": SU.VERSION, "tradelab": TC.VERSION}
        bad = ["%s (found %s)" % (v, found[k]) for k, v in NEEDS.items() if found[k] != v]
        if bad:
            raise BLError("needs %s beside this folder" % ", ".join(bad))
        root, panel = resolve_inputs(a)
        out = guard_out(a.out, root)
        elig = elig_column(getattr(a, "elig_col", None))
        S, einfo = read_engines(root)
        PN = read_panel(panel, elig)
        U, uinfo = build_universe(S, PN, root, log)
        F = read_iima(a.iima) if getattr(a, "iima", None) else None
        syms = np.unique(U["symbol"].to_numpy())
        cal, C, H, mk = load_bars(root, syms, bool(getattr(a, "stage_e_any", False)), log)
    except (BLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    del PN
    log("%s: declaration %s; D %s (%s), ENS %s (%s)" % (VERSION, ddoc["sha256"][:16], einfo["D"]["run"],
                                                       einfo["D"]["sha256"][:16], einfo["ENS"]["run"],
                                                       einfo["ENS"]["sha256"][:16]))
    si = np.searchsorted(syms, U["symbol"].to_numpy())
    dpos = np.searchsorted(cal, U["day"].to_numpy())
    inside = (dpos < len(cal))
    inside[inside] = cal[dpos[inside]] == U["day"].to_numpy()[inside]
    if inside.mean() < 0.99:
        print("REFUSED: %.1f%% of the race's days are not NIFTY50 sessions in the cache" % (100 * (1 - inside.mean())))
        return 3
    U, si, dpos = U[inside].reset_index(drop=True), si[inside], dpos[inside]
    has_c = np.isfinite(C[si, dpos])
    if has_c.mean() < BARS_MIN_SHARE:
        print("REFUSED: only %.1f%% of the race's stock-days have a daily close in the cache (needs %.0f%%)" % (
            100 * has_c.mean(), 100 * BARS_MIN_SHARE))
        return 3
    checks = {
        "engines": "; ".join("%s %s: %d scored rows %s .. %s, sha256 %s = FROZEN_ENGINES.json" % (
            t, einfo[t]["run"], einfo[t]["rows"], einfo[t]["first_day"], einfo[t]["last_day"],
            einfo[t]["sha256"][:16]) for t in ENGINES),
        "universe": "%d rows both engines scored; %d with the panel's row; %d ETF rows out; eligible share %.4f%%; "
                    "%s median |value| %.4f (a fraction); %d days under %d stocks dropped -> %d stock-days, %d days, "
                    "%d stocks" % (uinfo["rows_both_engines"], uinfo["rows_with_panel"], uinfo["etf_rows"],
                                   100 * uinfo["eligible_share"], TARGET, uinfo["label_median_abs"],
                                   uinfo["days_too_small"], MIN_UNIVERSE, uinfo["rows"], uinfo["days"],
                                   uinfo["stocks"]),
        "daily bars": "%d stocks read, %d without bars; %.2f%% of the race's stock-days have a close that day" % (
            len(syms), int((~np.isfinite(C).any(1)).sum()), 100 * has_c.mean()),
        "IIMA factors": ("%s: %d days %s .. %s" % (Path(a.iima).name, len(F), F["day"].min(), F["day"].max())
                         if F is not None else "not given - B6 and the factor tilts are not run"),
    }
    for k, v in checks.items():
        log(" %s: %s" % (k, v))
    if a.check_only:
        log("CHECK OK - inputs readable and checked; nothing computed or written.")
        return 0
    d = SU.new_run_dir(out, "BENCHLAB")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": ddoc["sha256"], "D": einfo["D"], "ENS": einfo["ENS"],
                 "iima": str(a.iima) if F is not None else None})
    log("signals")
    G = base_signals(C, H)
    Bs, g = bench_scores(G, si, dpos)
    names = [b for b in BENCH if b != "B6"]
    if F is not None:
        RM = resmom(C, cal, F)
        Bs["B6"] = RM[dpos, si]
        g["resmom"] = Bs["B6"]
        names = list(BENCH)
    del G
    Rc = Race(U)
    for e in ENGINES:
        Rc.add(e, U["s_" + e].to_numpy(float))
    for b in names:
        Rc.add(b, Bs[b])
    log("the race: %d days, %d rankings" % (Rc.nd, len(names)))
    B_ = SU.Boot(Rc.days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    years = sorted(set(pd.DatetimeIndex(Rc.days).year))
    rankings = []
    for nm in list(ENGINES) + names:
        r = Rc.R[nm]
        dd = np.flatnonzero(r["valid"])
        est, lo, hi, _ = boot_mean(B_, dd, r["ex"][dd])
        row = {"ranking": nm, "days": int(len(dd)), "net": float(np.mean(r["t3"][dd])),
               "net_stress": float(np.mean(r["t3"][dd])) - (COST_STRESS - COST), "excess": est, "excess_lo": lo,
               "excess_hi": hi, "ic": nmean(r["ic"][dd]), "dic": nmean(r["dic"][dd]),
               "scored_median": float(np.median(r["nfin"][dd])) if len(dd) else np.nan}
        for y_ in years:
            m = pd.DatetimeIndex(Rc.days[dd]).year == y_
            row["net_%d" % y_] = float(r["t3"][dd][m].mean()) if m.any() else np.nan
            row["ic_%d" % y_] = nmean(r["ic"][dd][m])
        rankings.append(row)
    comps = []
    for e in ENGINES:
        for b in names:
            comps.append(compare(Rc, B_, e, b, years))
    ph = holm([c["p"] for c in comps])
    pih = holm([c["p_ic"] for c in comps])
    prh = holm([c["p_rev"] for c in comps])
    for c, a1, a2, a3 in zip(comps, ph, pih, prh):
        c["p_holm"], c["p_ic_holm"], c["p_rev_holm"] = float(a1), float(a2), float(a3)
    decisions = {e: decide([c for c in comps if c["engine"] == e]) for e in ENGINES}
    span = [spanning(Rc, B_, e, names) for e in ENGINES]
    fm = []
    for e in ENGINES:
        fm += fama_macbeth(Rc, e, g)
    facs = [x for x in (factor_tilts(Rc, B_, e, F, cal) for e in ENGINES) if x] if F is not None else []
    for e in ENGINES:
        v = decisions[e]
        log(" %s: %s (hardest by money %s, best IC %s)" % (e, v["verdict"], v["best_pl"], v["best_ic"]))
    # ---- outputs
    res = {"rankings": rankings, "comparisons": comps, "decisions": decisions, "spanning": span, "fm": fm,
           "factors": facs}
    pd.DataFrame(rankings).to_csv(d / "rankings.csv", index=False)
    pd.DataFrame(comps).to_csv(d / "comparisons.csv", index=False)
    pd.DataFrame(fm).to_csv(d / "fama_macbeth.csv", index=False)
    pd.DataFrame(span).to_csv(d / "spanning.csv", index=False)
    files = ["rankings.csv", "comparisons.csv", "fama_macbeth.csv", "spanning.csv"]
    if facs:
        pd.DataFrame(facs).to_csv(d / "factors.csv", index=False)
        files.append("factors.csv")
    daily = {"day": pd.DatetimeIndex(Rc.days).date, "all_net": Rc.all, "stocks": Rc.cnt.astype(int)}
    for nm in list(ENGINES) + names:
        daily[nm + "_top3_net"] = Rc.R[nm]["t3"]
        daily[nm + "_ic"] = Rc.R[nm]["ic"]
    pd.DataFrame(daily).to_csv(d / "daily.csv", index=False, float_format="%.6f")
    picks = []
    for nm in list(ENGINES) + names:
        t = Rc.R[nm]["top"]
        picks.append(pd.DataFrame({"ranking": nm, "day": Rc.day[t], "place": Rc.R[nm]["pos"][t] + 1,
                                   "symbol": Rc.sym[t], "score": Rc.R[nm]["s"][t], "net": Rc.net[t]}))
    pd.concat(picks, ignore_index=True).sort_values(["ranking", "day", "place"]).to_csv(
        d / "picks.csv", index=False, float_format="%.6g")
    files += ["daily.csv", "picks.csv"]
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": ddoc["sha256"], "engines": einfo, "universe": uinfo, "rankings_run": names,
              "decisions": decisions,
              "best": {e: {k: next(c for c in comps if c["engine"] == e and c["ranking"] == decisions[e][k])
                           for k in ("best_pl", "best_ic")} for e in ENGINES}}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "BENCHLAB_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info = {"version": VERSION, "made": result["made"], "declaration_sha256": ddoc["sha256"], "universe": uinfo,
            "median_stocks": int(np.median(Rc.cnt)), "checks": checks, "root": str(root), "panel": str(panel),
            "elig_col": elig}
    write_report(d, info, res)
    (d / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    files += ["BENCHLAB_RESULT.json", "DECLARATION.json", "BENCHLAB.md", "RUN.json"]
    SU.write_hashes(d, files)
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "decisions": {e: decisions[e]["verdict"] for e in ENGINES},
                 "minutes": round((time.time() - t0) / 60, 1)})
    log("BENCHLAB WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    for e in ENGINES:
        log(" %s: %s" % (e, decisions[e]["verdict"]))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="benchlab", description=VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="the race (BENCHLAB_DECLARATION.json)")
    r.add_argument("--root", required=True, help="the cache root (%%CACHE_DAILY_ROOT%%)")
    r.add_argument("--out", required=True, help="the output folder (C:\\QuantData\\benchlab)")
    r.add_argument("--panel", help="panel_oc's panel.parquet (default: <root>\\panel_oc\\panel.parquet)")
    r.add_argument("--iima", help="IIMA's daily four-factor CSV (survivorship-bias adjusted) - B6 and factor tilts")
    r.add_argument("--elig-col", dest="elig_col", help="the panel's eligibility column (default: stage_b_screen's)")
    r.add_argument("--check-only", action="store_true", help="check the inputs, write nothing")
    r.add_argument("--stage-e-any", dest="stage_e_any", action="store_true",
                   help="accept a stage_e_execution.py that is not the shipped v1.2")
    a = ap.parse_args(argv)
    if a.cmd == "run":
        return cmd_run(a)
    return 2


if __name__ == "__main__":
    sys.exit(main())
