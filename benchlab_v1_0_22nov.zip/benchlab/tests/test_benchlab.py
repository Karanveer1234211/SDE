"""
tests for benchlab v1.0 - synthetic worlds only; nothing real is read, nothing outside a temporary folder is written.

    python tests\\test_benchlab.py          (from the benchlab folder, in tradelab's env)

Ends with  VERIFIED (benchlab v1.0)  or  FAILED.
  u1  every simple signal = an independent stock-by-stock loop over the raw bars (gaps in the bars, carried closes,
      returns needing both bars, the 200 / 50 minimums), at 400 random stock-days
  u2  each ranking's daily top 3 (score, then symbol), the excess, the IC (scipy's spearmanr) and the top-decile IC by
      hand on 40 days; the universe (both engines, the panel, label known, eligible, ETFs out, 30-stock days)
  u3  the statistics by hand: the bootstrap mean / interval / sd against an explicit loop over the resamples, Holm,
      Newey-West, the alpha's OLS and its resampled coefficients, the disagreement days and the Jaccard share
  u4  B6 (residual momentum) for 30 stock-months by an independent regression; the IIMA file's checks
  u5  the decision rule on hand-made comparisons (BEATS by money, BEATS by IC with / without a disagreement-day edge,
      LOSES, FAIL, INCONCLUSIVE)
  w1  PLANTED world (the engines see a component of the 5-session return no simple ranking sees): both BEATS SIMPLE;
      the outputs hash-checked; the top 3 in picks.csv = the hand-ranked top 3
  w2  ABSENT world (D = 1-week momentum plus noise; the returns follow momentum): D LOSES TO SIMPLE; REDUNDANT
      world (D = the 1-week return itself): D FAIL
  w3  refusals: an edited declaration, a preds file whose sha256 differs from FROZEN_ENGINES.json, a wrong target, the
      label in points, scored rows that are not the panel's eligible ones, --out inside the cache, no eligibility
      column; --check-only writes nothing
"""
from __future__ import annotations

import hashlib
import importlib
import io
import json
import math
import re
import shutil
import sys
import tempfile
import textwrap
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import benchlab as BL  # noqa: E402

SU, TD, TC = BL.SU, BL.TD, BL.TC
FAILS = []
N_OK = [0]
IST = "Asia/Kolkata"
ELIG = "label_buyable_o1"


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)


STAGE_E = '''
"""TEST STAND-IN for stage_e_execution (load_bars, lower_locked) - NOT the production file."""
from pathlib import Path
import numpy as np
import pandas as pd
CODE_VERSION = "stage_e_execution TEST STAND-IN"


class Bars:
    def __init__(self, ts, o, h, l, c, v):
        self.ts, self.o, self.h, self.l, self.c, self.v = ts, o, h, l, c, v


def load_bars(root, syms):
    out = {}
    for s in syms:
        p = Path(root) / f"{s}_daily.parquet"
        if not p.exists():
            continue
        df = pd.read_parquet(p)
        t = pd.to_datetime(df["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        out[s] = Bars(t.values.astype("datetime64[ns]"), *(df[k].to_numpy(float) for k in ("open", "high", "low",
                                                                                              "close", "volume")))
    return out


def lower_locked(b, j, side):
    return False
'''
SB = '''
"""TEST STAND-IN for stage_b_screen (ELIG_COL) - NOT the production file."""
ELIG_COL = "label_buyable_o1"
'''


def use_mods(root, with_sb=True):
    d = Path(root) / "_mods"
    d.mkdir(parents=True, exist_ok=True)
    for nm in ("stage_e_execution", "stage_b_screen"):
        (d / (nm + ".py")).unlink(missing_ok=True)
        sys.modules.pop(nm, None)
    (d / "stage_e_execution.py").write_text(textwrap.dedent(STAGE_E), encoding="utf-8")
    if with_sb:
        (d / "stage_b_screen.py").write_text(textwrap.dedent(SB), encoding="utf-8")
    sys.path[:] = [x for x in sys.path if not x.endswith("_mods")]     # one world's stand-ins at a time
    sys.path.insert(0, str(d))
    importlib.invalidate_caches()


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


# ---------------------------------------------------------------------------------------------- the world
def make_world(base: Path, seed: int, mode: str, n_sym=48, start="2016-01-01", end="2020-12-31",
               race_from="2018-01-01"):
    """root: <SYM>_daily.parquet (+ NIFTY50; a few stocks with missing sessions), panel_oc\\panel.parquet (eligibility,
    label_oc_5), FROZEN_ENGINES.json and the D and ENS runs' preds.parquet (every eligible stock from race_from).
    planted:   label = 0.02 z + noise; D sees z (+ noise), ENS = 0.5 rank(D) + 0.5 rank(z + noise).
    absent:    label = 0.02 x (1-week return / its sd) + noise; D = that momentum + noise: worse than momentum.
    redundant: label = 0.4 x the 1-week return + noise; D = the 1-week return + a hair of noise: B2 itself."""
    rng = np.random.default_rng(seed)
    root = base / "root"
    (root / "panel_oc" / "frozen").mkdir(parents=True, exist_ok=True)
    use_mods(root)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]
    n = len(syms)
    sig = rng.uniform(0.01, 0.03, n)
    lr = rng.normal(0, 1, (n, T)) * sig[:, None]
    C = 100 * np.exp(np.cumsum(lr, axis=1))
    O = C * np.exp(rng.normal(0, 0.003, (n, T)))
    H = np.maximum(O, C) * np.exp(np.abs(rng.normal(0, 0.006, (n, T))))
    L = np.minimum(O, C) * np.exp(-np.abs(rng.normal(0, 0.006, (n, T))))
    gaps = np.zeros((n, T), bool)
    for s in (3, 7, 11):                                       # missing sessions
        gaps[s, rng.choice(np.arange(300, T - 20), 15, replace=False)] = True
    late = 19                                                  # a stock listed late
    gaps[late, :400] = True
    for s in range(n):
        keep = ~gaps[s]
        pd.DataFrame({"timestamp": pd.DatetimeIndex(cal[keep]).tz_localize(IST), "open": O[s, keep],
                      "high": H[s, keep], "low": L[s, keep], "close": C[s, keep],
                      "volume": 1e5}).to_parquet(root / ("%s_daily.parquet" % syms[s]), index=False)
    nifty = 10000 * np.exp(np.cumsum(rng.normal(0, 0.008, T)))
    pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": nifty, "high": nifty * 1.004,
                  "low": nifty * 0.996, "close": nifty, "volume": np.nan}).to_parquet(root / "NIFTY50_daily.parquet",
                                                                                     index=False)
    # 1-week momentum from the bars (the carried close), standardised by the stock's sd
    Cf = pd.DataFrame(np.where(gaps, np.nan, C).T).ffill().to_numpy().T
    with np.errstate(invalid="ignore", divide="ignore"):
        r5 = np.log(Cf) - np.log(np.c_[np.full((n, 5), np.nan), Cf[:, :-5]])
    zmom = r5 / (sig[:, None] * np.sqrt(5))
    z = rng.normal(0, 1, (n, T))
    if mode == "planted":
        lab = 0.02 * z + rng.normal(0, 0.03, (n, T))
        sD = z + 0.5 * rng.normal(0, 1, (n, T))
        sC = z + 1.0 * rng.normal(0, 1, (n, T))
    elif mode == "absent":
        lab = 0.02 * np.nan_to_num(zmom) + rng.normal(0, 0.03, (n, T))
        sD = np.nan_to_num(zmom) + 0.8 * rng.normal(0, 1, (n, T))
        sC = np.nan_to_num(zmom) + 1.0 * rng.normal(0, 1, (n, T))
    else:                                                      # redundant: D is the 1-week momentum (B2)
        lab = 0.4 * np.nan_to_num(r5) + rng.normal(0, 0.03, (n, T))
        sD = np.nan_to_num(r5) + 0.002 * rng.normal(0, 1, (n, T))
        sC = np.nan_to_num(r5) + 0.02 * rng.normal(0, 1, (n, T))
    lab[:, -5:] = np.nan
    lab[gaps] = np.nan
    elig = (rng.random((n, T)) > 0.03).astype(float)
    elig[gaps] = 0.0
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(pd.DatetimeIndex(cal).tz_localize(IST), n),
                      ELIG: elig.ravel(), "label_oc_5": lab.ravel(), "d_other": rng.normal(size=n * T)})
    P = P[~gaps.ravel()]
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the engines: every eligible row from race_from
    t0 = int(np.searchsorted(cal, pd.Timestamp(race_from)))
    mask = (elig == 1) & ~gaps
    mask[:, :t0] = False
    si, ti = np.nonzero(mask)
    ts = pd.DatetimeIndex(cal[ti]).tz_localize(IST)
    pdD = pd.DataFrame({"timestamp": ts, "symbol": np.array(syms)[si], "target": "label_oc_5",
                        "score": sD[si, ti].astype("float32")})
    other = pdD.assign(target="label_oc_1", score=rng.normal(size=len(pdD)).astype("float32"))
    sdir = root / "panel_oc" / "stage_d"
    for run in ("STAGED_T1", "STAGEDXC_T1", "STAGEDXE_T1"):
        (sdir / run).mkdir(parents=True, exist_ok=True)
    pd.concat([pdD, other], ignore_index=True).to_parquet(sdir / "STAGED_T1" / "preds.parquet", index=False)
    pc = pd.DataFrame({"timestamp": ts, "symbol": np.array(syms)[si], "target": "label_oc_5",
                       "score": sC[si, ti].astype("float32")})
    pc.to_parquet(sdir / "STAGEDXC_T1" / "preds.parquet", index=False)
    M = pdD[["timestamp", "symbol", "score"]].merge(pc[["timestamp", "symbol", "score"]], on=["timestamp", "symbol"],
                                                    suffixes=("_d", "_c"))
    g = M.groupby("timestamp")
    M["score"] = 0.5 * g["score_d"].rank(pct=True) + 0.5 * g["score_c"].rank(pct=True)
    M[["timestamp", "symbol"]].assign(target="label_oc_5", score=M["score"]).to_parquet(
        sdir / "STAGEDXE_T1" / "preds.parquet", index=False)
    write_frozen(root)
    return root, {"cal": cal, "syms": syms, "C": np.where(gaps, np.nan, C), "H": np.where(gaps, np.nan, H),
                  "lab": lab, "elig": elig, "gaps": gaps, "z": z, "t0": t0, "sD": sD}


def write_frozen(root, target="label_oc_5"):
    sdir = root / "panel_oc" / "stage_d"
    man = {"target": target, "engines": {"D": {"run": "STAGED_T1"},
                                         "ENS": {"run": "STAGEDXE_T1", "c_run": "STAGEDXC_T1", "d_run": "STAGED_T1"}},
           "files": {"runs/D/STAGED_T1/preds.parquet": sha(sdir / "STAGED_T1" / "preds.parquet"),
                     "runs/ENS/STAGEDXE_T1/preds.parquet": sha(sdir / "STAGEDXE_T1" / "preds.parquet"),
                     "runs/C/STAGEDXC_T1/preds.parquet": sha(sdir / "STAGEDXC_T1" / "preds.parquet")}}
    (root / "panel_oc" / "frozen" / "FROZEN_ENGINES.json").write_text(json.dumps(man), encoding="utf-8")


def make_iima(path, cal_from="2012-01-02", cal_to="2020-06-30", seed=5):
    rng = np.random.default_rng(seed)
    d = pd.bdate_range(cal_from, cal_to)
    df = pd.DataFrame({"Date": d.strftime("%Y-%m-%d"), "SMB": rng.normal(0, 0.5, len(d)),
                       "HML": rng.normal(0, 0.5, len(d)), "WML": rng.normal(0, 0.6, len(d)),
                       "MF": rng.normal(0.04, 1.0, len(d)), "RF": 0.02})
    df.loc[0, "MF"] = np.nan
    df.loc[0, "RF"] = np.nan
    df.to_csv(path, index=False, na_rep="NA")
    return path


def run(root, out, extra=()):
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = BL.main(["run", "--root", str(root), "--out", str(out), "--stage-e-any"] + list(extra))
    return rc, buf.getvalue()


def runs(out):
    return sorted(p for p in Path(out).iterdir() if p.is_dir() and re.fullmatch(r"BENCHLAB_\d{8}_\d{3}", p.name)) \
        if Path(out).exists() else []


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return len(lines) >= 8 and all(
        hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0] for ln in lines)


# ---------------------------------------------------------------------------------------------- references
def ref_signal(Ci, Hi, t):
    """The simple signals of one stock at calendar index t, written out loop by loop."""
    Cf = Ci.copy()
    for k in range(1, len(Cf)):
        if not np.isfinite(Cf[k]) and np.isfinite(Cf[k - 1]):
            Cf[k] = Cf[k - 1]

    def r(a, b):
        if t - a < 0 or not (np.isfinite(Cf[t - a]) and np.isfinite(Cf[t - b])):
            return np.nan
        return math.log(Cf[t - b] / Cf[t - a])
    lrs = []
    for k in range(max(1, t - 251), t + 1):
        lrs.append(math.log(Ci[k] / Ci[k - 1]) if (np.isfinite(Ci[k]) and np.isfinite(Ci[k - 1])) else np.nan)
    lrs = np.array(lrs)
    w = lrs[np.isfinite(lrs)]
    lowvol = -float(np.std(w, ddof=1)) if (len(lrs) == 252 and len(w) >= 200) else np.nan
    l60 = lrs[-60:] if len(lrs) >= 60 else np.array([])
    w60 = l60[np.isfinite(l60)]
    v60 = float(np.mean(w60 ** 2)) if (len(l60) == 60 and len(w60) >= 50) else np.nan
    hs = Hi[max(0, t - 251):t + 1]
    hv = hs[np.isfinite(hs)]
    high = (Ci[t] / hv.max()) if (len(hs) == 252 and len(hv) >= 200 and np.isfinite(Ci[t])) else np.nan
    nag = 0.0
    for k in range(12):
        nag += (12 - k) / 78.0 * r(5 * k + 5, 5 * k)
    out = {"B1": -r(5, 0), "B2": r(5, 0), "B3r": -r(21, 0), "B3m": r(21, 0), "B4": r(252, 21), "B5": high,
           "B7": lowvol, "B8": nag / v60 if (np.isfinite(v60) and v60 > 0) else np.nan}
    sd = math.sqrt(v60) if (np.isfinite(v60) and v60 > 0) else np.nan
    out["B2s"], out["B4s"], out["B8s"] = out["B2"] / sd, out["B4"] / sd, out["B8"] / sd
    return out


def same(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


def build_race(root, W, iima=None):
    """What cmd_run builds before the statistics."""
    S, einfo = BL.read_engines(root)
    PN = BL.read_panel(root / "panel_oc" / "panel.parquet", ELIG)
    U, uinfo = BL.build_universe(S, PN, root, log=lambda *a: None)
    syms = np.unique(U["symbol"].to_numpy())
    cal, C, H, mk = BL.load_bars(root, syms, True, log=lambda *a: None)
    si = np.searchsorted(syms, U["symbol"].to_numpy())
    dpos = np.searchsorted(cal, U["day"].to_numpy())
    G = BL.base_signals(C, H)
    Bs, g = BL.bench_scores(G, si, dpos)
    names = [b for b in BL.BENCH if b != "B6"]
    F = None
    if iima is not None:
        F = BL.read_iima(iima)
        RM = BL.resmom(C, cal, F)
        Bs["B6"] = RM[dpos, si]
        g["resmom"] = Bs["B6"]
        names = list(BL.BENCH)
    Rc = BL.Race(U)
    for e in BL.ENGINES:
        Rc.add(e, U["s_" + e].to_numpy(float))
    for b in names:
        Rc.add(b, Bs[b])
    return {"S": S, "U": U, "uinfo": uinfo, "syms": syms, "cal": cal, "C": C, "H": H, "si": si, "dpos": dpos,
            "Bs": Bs, "g": g, "names": names, "Rc": Rc, "F": F}


# ---------------------------------------------------------------------------------------------- unit checks
def unit_checks(tmp):
    print("unit checks")
    root, W = make_world(tmp / "u", 11, "planted")
    iima = make_iima(tmp / "iima.csv")
    X = build_race(root, W, iima)
    U, Rc, cal = X["U"], X["Rc"], X["cal"]
    # u1 signals
    rng = np.random.default_rng(3)
    idx = rng.choice(len(U), 400, replace=False)
    sym_pos = {s: i for i, s in enumerate(W["syms"])}
    bad = []
    for i in idx:
        s = U["symbol"].iloc[i]
        wi = sym_pos[s]
        t = int(X["dpos"][i])
        ref = ref_signal(W["C"][wi], W["H"][wi], t)
        for k, v in ref.items():
            if not same(X["Bs"][k][i], v):
                bad.append((s, str(cal[t]), k, X["Bs"][k][i], v))
    check(not bad, "u1 every simple signal = the independent loop over the raw bars at 400 stock-days (gaps, carried "
                   "closes, both-bar returns, the minimums) %s" % (bad[:3] if bad else ""))
    late = U["symbol"] == "S019"
    early = late & (U["day"] < np.datetime64(cal[400 + 251]))
    check(early.any() and np.isnan(X["Bs"]["B4"][early.to_numpy()]).all() and
          np.isfinite(X["Bs"]["B2"][early.to_numpy() & (U["day"] > np.datetime64(cal[410])).to_numpy()]).any(),
          "u1b a stock listed late has no 12-1 momentum before 252 sessions of closes, a 1-week momentum after 5")
    # u2 the universe and the daily picks
    P = pd.read_parquet(root / "panel_oc" / "panel.parquet")
    P["day"] = BL.to_days(P["timestamp"])
    want = P[(P[ELIG] == 1) & np.isfinite(P["label_oc_5"]) & (P["symbol"] != "LIQUIDBEES") &
             (P["day"] >= np.datetime64(cal[W["t0"]]))]
    cnt = want.groupby("day")["symbol"].transform("size")
    want = want[cnt >= 30]
    check(len(want) == len(U) and set(zip(want["symbol"], want["day"])) == set(zip(U["symbol"], U["day"])) and
          "LIQUIDBEES" not in set(U["symbol"]),
          "u2a the universe = both engines' rows x the panel: eligible, label known, ETF out, 30-stock days (%d rows)"
          % len(U))
    from scipy.stats import spearmanr
    days = Rc.days
    bad = []
    for j in rng.choice(len(days), 40, replace=False):
        m = Rc.di == j
        for nm in ("D", "ENS", "B2", "B5", "B7", "B8s", "B6"):
            r = Rc.R[nm]
            s_ = r["s"][m]
            fin = np.isfinite(s_)
            sy = Rc.sym[m]
            order = sorted(np.flatnonzero(fin), key=lambda k: (-s_[k], sy[k]))
            top = set(sy[order[:3]]) if fin.sum() >= 30 else set()
            got = set(Rc.sym[m & r["top"]])
            net = Rc.net[m]
            t3 = np.mean(net[order[:3]]) if top else np.nan
            ic = spearmanr(s_[fin], net[fin])[0] if fin.sum() >= 30 else np.nan
            kd = int(math.ceil(0.1 * fin.sum()))
            dsel = order[:kd]
            dic = spearmanr(s_[dsel], net[dsel])[0] if (fin.sum() >= 30 and kd >= 10) else np.nan
            if top != got or not same(r["t3"][j], t3) or not same(r["ex"][j], t3 - net.mean()) or \
                    not same(r["ic"][j], ic, 1e-7) or not same(r["dic"][j], dic, 1e-7):
                bad.append((str(days[j]), nm, top, got, r["ic"][j], ic))
    check(not bad, "u2b each ranking's daily top 3 (score, then symbol), excess, IC and top-decile IC by hand on 40 "
                   "days x 7 rankings %s" % (bad[:2] if bad else ""))
    # u3 statistics
    B_ = SU.Boot(days, B=300, block=10, seed=7)
    E, Bk = Rc.R["D"], Rc.R["B8"]
    both = np.flatnonzero(E["valid"] & Bk["valid"])
    x = (E["t3"] - Bk["t3"])[both]
    est, lo, hi, sd = BL.boot_mean(B_, both, x)
    pos = {d: i for i, d in enumerate(days)}
    xs = {pos[days[k]]: v for k, v in zip(both, x)}
    ms = []
    for b in range(300):
        vals = [xs[i] for i in B_.ix[b] if i in xs]
        ms.append(np.mean(vals))
    check(same(est, x.mean()) and same([lo, hi], np.percentile(ms, [2.5, 97.5]), 1e-9) and
          same(sd, np.std(ms, ddof=1), 1e-9), "u3a the bootstrap mean, interval and sd = an explicit loop over the "
                                              "resampled days")
    check(same(BL.holm([0.01, 0.04, 0.03, 0.005]), [0.03, 0.06, 0.06, 0.02]) and
          same(BL.holm([0.5, np.nan, 0.01]), [0.5, np.nan, 0.02]), "u3b Holm's adjusted p-values by hand")
    y = rng.normal(size=300) + 0.3 * np.r_[0, rng.normal(size=299)]
    e_ = y - y.mean()
    g0 = np.mean(e_ * e_)
    s_ = g0 + 2 * sum((1 - l / 6) * np.sum(e_[l:] * e_[:-l]) / 300 for l in range(1, 6))
    check(same(BL.nw_mean(y), (y.mean(), math.sqrt(s_ / 300))), "u3c Newey-West (Bartlett, 5 lags) by hand")
    yy = E["ex"][both]
    Xx = np.column_stack([np.ones(len(both)), Bk["ex"][both]])
    beta, betas = BL.boot_ols(B_, both, yy, Xx)
    b_ref = np.linalg.lstsq(Xx, yy, rcond=None)[0]
    rows_b = []
    for b in (0, 7, 199):
        ii = [k for k in B_.ix[b] for kk in [k] if kk in {pos[days[q]] for q in both}]
        sel = np.array([np.flatnonzero(both == k)[0] for k in ii])
        rows_b.append(np.linalg.lstsq(Xx[sel], yy[sel], rcond=None)[0])
    check(same(beta, b_ref, 1e-8) and same(betas[[0, 7, 199]], np.array(rows_b), 1e-7),
          "u3d the alpha regression = numpy's OLS; three resamples' coefficients = OLS on the resampled days")
    row = BL.compare(Rc, B_, "D", "B8", [2018, 2019, 2020])
    dis_days, jac = [], []
    for k in both:
        m = Rc.di == k
        te, tb = set(Rc.sym[m & E["top"]]), set(Rc.sym[m & Bk["top"]])
        dec = set(Rc.sym[m & Bk["dec"]])
        jac.append(len(te & tb) / len(te | tb))
        if not (te & dec):
            dis_days.append(k)
    dd = np.array(dis_days)
    check(row["dis_days"] == len(dd) and same(row["dis_diff"], (E["t3"] - Bk["t3"])[dd].mean()) and
          same(row["jaccard"], np.mean(jac)) and same(row["diff"], x.mean()) and row["days"] == len(both),
          "u3e the disagreement days (none of D's top 3 in B8's top decile), their mean, the Jaccard share by hand")
    # u4 B6 by hand
    F = X["F"]
    FM = BL.monthly_factors(F)
    mon = BL.month_code(cal)
    months = np.arange(mon.min(), mon.max() + 1)
    bad, n_ok = [], 0
    for _ in range(60):
        i = int(rng.integers(len(U)))
        s = U["symbol"].iloc[i]
        wi = sym_pos[s]
        t = int(X["dpos"][i])
        m = mon[t]
        Ci = W["C"][wi]
        lastc = {}
        for k in range(len(cal)):
            if np.isfinite(Ci[k]):
                lastc[mon[k]] = Ci[k]
        rows = []
        for mm in range(m - 36, m):
            f = FM.reindex([mm])
            r_ = lastc[mm] / lastc[mm - 1] - 1 if (mm in lastc and (mm - 1) in lastc) else np.nan
            rows.append([r_ - f["RF"].iloc[0], f["MF"].iloc[0], f["SMB"].iloc[0], f["HML"].iloc[0]])
        A = np.array(rows, float)
        if not np.isfinite(A[:, 1:]).all():
            ref = np.nan
        else:
            ok = np.isfinite(A[:, 0])
            if ok.sum() < 24 or not ok[24:35].all():
                ref = np.nan
            else:
                Xr = np.column_stack([np.ones(36), A[:, 1:]])
                b = np.linalg.lstsq(Xr[ok], A[ok, 0], rcond=None)[0]
                e = A[24:35, 0] - Xr[24:35] @ b
                ref = e.sum() / e.std(ddof=1)
        got = X["Bs"]["B6"][i]
        n_ok += np.isfinite(ref)
        if not same(got, ref, 1e-7):
            bad.append((s, str(cal[t]), got, ref))
    check(not bad and n_ok >= 20, "u4a B6 by an independent regression at 60 stock-days (%d with a score) %s" % (
        n_ok, bad[:2] if bad else ""))
    late_b6 = X["Bs"]["B6"][(U["day"] >= np.datetime64("2020-08-01")).to_numpy()]
    check(len(late_b6) and np.isnan(late_b6).all(), "u4b B6 is blank where its months run past the IIMA file's end")
    bad_csv = tmp / "bad_iima.csv"
    pd.read_csv(iima).assign(MF=lambda d: d["MF"] / 100).to_csv(bad_csv, index=False)
    try:
        BL.read_iima(bad_csv)
        ok_ = False
    except BL.BLError:
        ok_ = True
    check(ok_, "u4c an IIMA file in fractions (not percent) is refused")
    # u5 the decision rule
    base = {"engine": "D", "diff": 0.5, "diff_lo": 0.2, "p": 0.001, "ic_diff": 0.02, "p_ic": 0.001,
            "dis_diff": 0.3, "dis_lo": 0.05, "alpha": 0.4, "alpha_lo": 0.1, "p_rev_holm": 1.0, "dis_days": 50}

    def mk(**kw):
        r = dict(base)
        r.update(kw)
        return r
    rows = [mk(ranking="B1", diff=0.9, p_holm=0.001, p_ic_holm=0.001),
            mk(ranking="B2", diff=0.3, p_holm=0.01, ic_diff=0.05, p_ic_holm=0.2)]
    v1 = BL.decide(rows)
    rows = [mk(ranking="B1", diff=0.9, p_holm=0.001, p_ic_holm=0.3),
            mk(ranking="B2", diff=0.1, diff_lo=-0.1, p_holm=0.2, ic_diff=0.01, p_ic_holm=0.01, dis_diff=0.2)]
    v2 = BL.decide(rows)
    rows2 = [dict(r, dis_diff=-0.1) if r["ranking"] == "B2" else r for r in rows]
    v3 = BL.decide(rows2)
    rows = [mk(ranking="B1", diff=0.9, p_holm=0.001, p_ic_holm=0.3),
            mk(ranking="B2", diff=0.1, diff_lo=-0.1, p_holm=0.2, ic_diff=0.01, p_ic_holm=0.3, alpha_lo=-0.1,
               dis_lo=-0.2)]
    v4 = BL.decide(rows)
    v5 = BL.decide([dict(r, alpha_lo=0.05) if r["ranking"] == "B2" else r for r in rows])
    v6 = BL.decide([dict(r, diff=0.2) if r["ranking"] == "B2" else r for r in rows])
    v7 = BL.decide([dict(r, diff=-0.4, diff_hi=-0.1, p_rev_holm=0.004, alpha_lo=0.2) if r["ranking"] == "B2" else r
                    for r in rows])
    v8 = BL.decide([dict(r, dis_days=0, dis_lo=np.nan, dis_diff=np.nan) if r["ranking"] == "B2" else r
                    for r in rows])
    v9 = BL.decide([dict(r, dis_days=30, dis_lo=0.01) if r["ranking"] == "B2" else r for r in rows])
    check(v1["verdict"] == "BEATS SIMPLE" and v1["best_pl"] == "B2" and v2["verdict"] == "BEATS SIMPLE" and
          v2["beats_ic"] and v3["verdict"] != "BEATS SIMPLE" and v4["verdict"] == "FAIL" and
          v5["verdict"] == "INCONCLUSIVE" and v6["verdict"] == "INCONCLUSIVE" and v7["verdict"] == "LOSES TO SIMPLE"
          and v8["verdict"] == "FAIL" and v9["verdict"] == "INCONCLUSIVE",
          "u5 the decision rule: BEATS by money, BEATS by IC only with a disagreement-day edge, LOSES (even with a "
          "positive alpha), FAIL (also with no disagreement days), INCONCLUSIVE (alpha above 0; short of the margin; a "
          "disagreement-day edge)")
    return root, W


# ---------------------------------------------------------------------------------------------- worlds
def world_checks(tmp):
    print("planted world")
    root, W = make_world(tmp / "w1", 21, "planted")
    iima = make_iima(tmp / "w1_iima.csv", cal_to="2020-12-31")
    out = tmp / "w1_out"
    rc, log = run(root, out, ["--iima", str(iima)])
    R = runs(out)
    ok = rc == 0 and len(R) == 1
    check(ok, "w1a the planted world runs (rc %s) %s" % (rc, "" if ok else log[-2000:]))
    if not ok:
        return
    d = R[0]
    res = json.loads((d / "BENCHLAB_RESULT.json").read_text(encoding="utf-8"))
    C = pd.read_csv(d / "comparisons.csv")
    check(res["decisions"]["D"]["verdict"] == "BEATS SIMPLE" and res["decisions"]["ENS"]["verdict"] == "BEATS SIMPLE"
          and len(C) == 24 and (C["p_holm"] <= 0.025).all(),
          "w1b PLANTED: D and ENS both BEAT SIMPLE (every one of the 24 comparisons Holm-significant)")
    check(outputs_ok(d) and (d / "BENCHLAB.md").read_text(encoding="utf-8").startswith("# benchlab v1.0") and
          SU.frozen_hash(res) == res["sha256"], "w1c the outputs are hash-checked; the result carries its own sha256")
    X = build_race(root, W, iima)
    pk = pd.read_csv(d / "picks.csv")
    Rc = X["Rc"]
    bad = 0
    for nm in ("D", "ENS", "B6", "B8"):
        sub = pk[pk["ranking"] == nm]
        got = {(str(r.day), r.symbol) for r in sub.itertuples()}
        want = {(str(Rc.day[i]), Rc.sym[i]) for i in np.flatnonzero(Rc.R[nm]["top"])}
        bad += got != want
    check(bad == 0, "w1d picks.csv = the race's top 3 of D, ENS, B6 and B8 every day")
    L = (tmp / "w1_out" / "benchlab_ledger.jsonl").read_text(encoding="utf-8").splitlines()
    check(len(L) == 2 and json.loads(L[1])["decisions"] == {"D": "BEATS SIMPLE", "ENS": "BEATS SIMPLE"},
          "w1e the ledger has the start and the end of the run")
    print("absent world")
    root2, _ = make_world(tmp / "w2", 22, "absent")
    out2 = tmp / "w2_out"
    rc, log = run(root2, out2)
    R2 = runs(out2)
    ok = rc == 0 and len(R2) == 1
    check(ok, "w2a the absent world runs without --iima (rc %s) %s" % (rc, "" if ok else log[-2000:]))
    if ok:
        res2 = json.loads((R2[0] / "BENCHLAB_RESULT.json").read_text(encoding="utf-8"))
        C2 = pd.read_csv(R2[0] / "comparisons.csv")
        v = res2["decisions"]["D"]
        check(v["verdict"] == "LOSES TO SIMPLE" and v["best_pl"] in ("B2", "B2s") and len(C2) == 22 and
              res2["decisions"]["ENS"]["verdict"] != "BEATS SIMPLE",
              "w2b ABSENT (D = 1-week momentum + noise): D %s against %s, ENS %s; 22 comparisons without B6" % (
                  v["verdict"], v["best_pl"], res2["decisions"]["ENS"]["verdict"]))
    print("redundant world")
    root3, _ = make_world(tmp / "w4", 23, "redundant")
    out3 = tmp / "w4_out"
    rc, log = run(root3, out3)
    R3 = runs(out3)
    if rc == 0 and len(R3) == 1:
        res3 = json.loads((R3[0] / "BENCHLAB_RESULT.json").read_text(encoding="utf-8"))
        v = res3["decisions"]["D"]
        b = res3["best"]["D"]["best_pl"]
        check(v["verdict"] == "FAIL" and v["best_pl"] == "B2",
              "w2c REDUNDANT (D = the 1-week return + a hair): D FAIL against %s (diff %+.3f [%+.3f, %+.3f], alpha "
              "[%+.3f, %+.3f], %d disagreement days) - verdict %s" % (v["best_pl"], b["diff"], b["diff_lo"],
                                                                     b["diff_hi"], b["alpha_lo"], b["alpha_hi"],
                                                                     b["dis_days"], v["verdict"]))
    else:
        check(False, "w2c the redundant world runs (rc %s) %s" % (rc, log[-1500:]))
    return root


def refusals(tmp, root):
    print("refusals")
    out = tmp / "r_out"
    good_decl = (BL.HERE / BL.DECL_FILE).read_text(encoding="utf-8")
    try:
        doc = json.loads(good_decl)
        doc["decision"]["FAIL"] = doc["decision"]["FAIL"].replace("0.15", "0.25")
        (BL.HERE / BL.DECL_FILE).write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
        rc, log = run(root, out)
        check(rc == 3 and "changed after it was declared" in log, "w3a an edited declaration is refused")
    finally:
        (BL.HERE / BL.DECL_FILE).write_text(good_decl, encoding="utf-8")
    rc, log = run(root, out, ["--check-only"])
    check(rc == 0 and "CHECK OK" in log and not runs(out), "w3b --check-only checks and writes no run")
    pp = root / "panel_oc" / "stage_d" / "STAGED_T1" / "preds.parquet"
    keep = pp.read_bytes()
    try:
        P = pd.read_parquet(pp)
        P.loc[0, "score"] = P.loc[0, "score"] + 1
        P.to_parquet(pp, index=False)
        rc, log = run(root, out)
        check(rc == 3 and "not the frozen" in log, "w3c a preds file whose sha256 differs from FROZEN_ENGINES.json")
    finally:
        pp.write_bytes(keep)
    write_frozen(root, target="label_oc_3")
    rc, log = run(root, out)
    check(rc == 3 and "target is label_oc_3" in log, "w3d FROZEN_ENGINES.json with another target is refused")
    write_frozen(root)
    pan = root / "panel_oc" / "panel.parquet"
    keep = pan.read_bytes()
    try:
        P = pd.read_parquet(pan)
        P["label_oc_5"] = P["label_oc_5"] * 100
        P.to_parquet(pan, index=False)
        rc, log = run(root, out)
        check(rc == 3 and "not a fraction" in log, "w3e a label in points (not a fraction) is refused")
        P = pd.read_parquet(io.BytesIO(keep))
        P[ELIG] = 0.0
        P.to_parquet(pan, index=False)
        rc, log = run(root, out)
        check(rc == 3 and "eligible" in log, "w3f scored rows that are not the panel's eligible rows are refused")
    finally:
        pan.write_bytes(keep)
    rc, log = run(root, root / "outs")
    check(rc == 3 and "inside" in log, "w3g --out inside the cache is refused")
    use_mods(root, with_sb=False)
    try:
        rc, log = run(root, out)
        check(rc == 3 and "ELIG_COL" in log, "w3h no stage_b_screen and no --elig-col is refused")
        rc, log = run(root, out, ["--elig-col", ELIG, "--check-only"])
        check(rc == 0 and "CHECK OK" in log, "w3i --elig-col names the column when stage_b_screen is absent")
    finally:
        use_mods(root)
    check(not runs(out), "w3j no refused run wrote a run folder")


def main():
    print("%s self-test (pandas %s, numpy %s)" % (BL.VERSION, pd.__version__, np.__version__))
    tmp = Path(tempfile.mkdtemp(prefix="benchlab_test_"))
    try:
        p, doc = BL.load_declaration()
        check(doc["tool"] == BL.VERSION and doc["constants"] == json.loads(json.dumps(BL.constants())),
              "u0 the declaration is this version's, unchanged (%s)" % doc["sha256"][:16])
        unit_checks(tmp)
        root = world_checks(tmp)
        if root is not None:
            refusals(tmp, root)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print("FAILED: %d of %d checks" % (len(FAILS), len(FAILS) + N_OK[0]))
        for f in FAILS:
            print("   - " + f)
        return 1
    print("VERIFIED (%s) - %d checks" % (BL.VERSION, N_OK[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
