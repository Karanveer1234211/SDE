# MANIFEST - branchlab v1.0 (study BR1)

Built 13 Nov 2026. Folder: C:\Users\karanvsi\PyCharmMiscProject\branchlab (beside tradelab and setuplab, never inside bigmove_deploy). Outputs: C:\QuantData\branchlab. Reads production, setuplab's runs and the panel READ ONLY. Needs tradelab setups add-on v1.7 (tl_setups v1.7) and setuplab (unchanged).

Declaration sha256: 1ec45a66b982f903c371cf1d9e79faa934d2639e570977b96e50d395951bab0e
strategies\branchlab.py (tradelab) sha256: 77529c56f87dda84ab4ae7629029dcfdb0877edda9b35dc45905c7a731dfd11a

| file | version | sha256 (first 16) | role |
|---|---|---|---|
| branchlab.py | branchlab v1.0 | 14a03edbea25a7d3 | COMMAND: check / run (Stage 1: every variant's day on every tree pick, the reconciliation, coverage, the blocking count, descriptive trades, run_stage2.bat) / holm (Stage 2: Holm per engine, the forward pick) |
| BRANCHLAB_DECLARATION.json | BR1, declared 13 Nov 2026 | 1ec45a66b982f903 | the study, fixed before any run (branchlab.py refuses another sha256) |
| env_branchlab.bat | branchlab v1.0 | 2a8cf97e4afa90ee | start a session: env_daily.bat, PYTHONPATH (branchlab, tradelab, setuplab, open_close, bigmove_deploy), SETUPLAB_OUT, BRANCHLAB_OUT (CRLF) |
| README_BRANCHLAB.md | branchlab v1.0 | 25fdbdc3c7ae847f | the question, the 24 variants, Stage 1 and 2, install and run, outputs, tests |
| tests/test_branchlab.py | branchlab v1.0 | 577540abd695ed73 | the self-test (39 checks; must end VERIFIED (branchlab v1.0)); genuine setuplab TAGS / TREE runs on a synthetic world, an independent oracle, planted / absent worlds, Holm |
