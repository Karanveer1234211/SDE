# branchlab v1.0 — the entry tree's open branches (study BR1)

**Question.** The frozen tree buys a jumpy pick only through a frozen setup, and six of the seven setups can fire only on the session after the week's 13-week return is posted (a Tuesday open). Does any of 24 declared changes improve the frozen tree's account on the same picks?

Everything was declared before any run, in **`BRANCHLAB_DECLARATION.json`** (13 Nov 2026). `branchlab.py` refuses any other sha256, and `check` confirms tradelab's `strategies\branchlab.py` is the declared file.

**Prior evidence (why expectations are low).**
- 7 Nov: moving the weekly read one session earlier wrecked B (−1.8907 pp a trade [−2.3001, −1.4739]). Later entries were never tested.
- v2engine drop 3: breakouts, retests and failed-breakdown reclaims all lost to buying at the open. B_BRK, B_RET and B_RCL repeat them on D1's levels.
- JL1: every jumpy-pick variant failed against the tree (32 of 32).

## The 24 variants (each = the frozen tree + one change)

| group | variants | what changes | picks |
|-|-|-|-|
| P — bad week held | P_S1 … P_C3, P_ALL; P_ALL1, P_ALL2 | the weekly condition reads the week's posted change held until the next weekly update (P) or for 1 / 2 sessions after it | jumpy |
| N — no weekly gate | N_S1 … N_C3, N_ALL | the weekly condition removed | jumpy |
| B — D1 levels | B_BRK, B_RET, B_RCL | a close above D1's high; then a dip to it that closes above; a close back above D1's low | jumpy |
| K — calm D picks | K_SLOT, K_LATE, K_BOTH | every calm pick opening at/above its close (not only the day's best); a calm pick that opened lower, at the first later open at/above its close | calm, D only |
| E_OPEN | E_OPEN | an ENS calm pick that opens below its close goes through the frozen setups instead (D's open check) | calm, ENS only |
| X_D2 | X_D2 | control: every jumpy pick at the D2 open | jumpy |

"Jumpy" = the tree's JUMPY or NO ATR picks (routed through setups only), not ETFs. Every such pick is eligible on every watch day until it is bought — never only the picks the tree turns out to skip. Rules are read at the close before the watch day and buy at its open; the variant's buy sells at the 5th close (E_OPEN: the setup's own exit). A pick is bought on the earlier of the tree's own buy and the variant's day; on the same day the tree's buy stands.

## Stage 1 — `branchlab.py run` (descriptive)

Reads setuplab's newest TREE and TAGS runs (hash-checked — the runs tradelab replays), the research watchlist and panel the TAGS run used, and the picks' daily bars.

- **Reconciliation (required):** the six bad-week setups rebuilt with the frozen one-day pulse must give the TAGS run's entry day on every pick of ranks 1–3. If not: `DIFFERS`, exit 3, no `br_scores.parquet`.
- Coverage per variant: picks it buys, how many the tree skips / buys later / buys the same day; days and weekdays.
- The blocking count: why the frozen setups skipped each jumpy pick (R1 the one-day pulse, R2 not a bad week, R3 other conditions, R4 missing data).
- Each variant's own trades, descriptive only (setuplab's convention, not honest exits).

## Stage 2 — what decides (tradelab add-on v1.7)

44 backtests, each against the frozen tree (`strategies\tree.py`): D 23 (all but E_OPEN), ENS 21 (all but K_*).

**PASS rule** per run: the daily-return difference has a 95% interval above 0, AND the CAGR is higher, AND the worst drawdown is no deeper. Then Holm per engine across its whole family (0.025, one-sided). `holm` also prints the 18 Oct goal check (descriptive).

A FINAL PASS is a forward candidate only. **At most two go forward** (the smallest p), each as a new shadow book; the frozen tree, setups and paper ledger stay exactly as they are. Nothing passes → each question closes for this history.

## Install and run

1. Copy the `branchlab` folder to `C:\Users\karanvsi\PyCharmMiscProject\branchlab`, beside tradelab and setuplab.
2. Install tradelab add-on v1.7 (the other zip) over `C:\Users\karanvsi\PyCharmMiscProject\tradelab`.

```
call C:\Users\karanvsi\PyCharmMiscProject\branchlab\env_branchlab.bat
python tests\test_branchlab.py
python branchlab.py check
python branchlab.py run --root %CACHE_DAILY_ROOT%
```

Then double-click `C:\QuantData\branchlab\runs\BR_<date>_<nnn>\run_stage2.bat`. It runs the 44 backtests from the tradelab folder (about 2 minutes each — roughly 1.5 to 2 hours, unattended), then Holm. The commands are also in `stage2_commands.txt`.

**Outputs** (`C:\QuantData\branchlab\runs\BR_<date>_<nnn>\`): REPORT.md (verdict first), br_scores.parquet (tradelab's `--branchlab` reads it, hash-checked), coverage.csv, blocking.csv, trades_desc.csv, stage2_commands.txt, run_stage2.bat, run.json, DECLARATION.json, outputs.sha256; one line per run in `C:\QuantData\branchlab\branchlab_ledger.jsonl`.

## Tests (`tests\test_branchlab.py`, 39 checks)

- The declaration and the strategies file against their frozen sha256.
- By hand: the weekly state (posting rows, held 0–2 rows and all week, a zero week resets, a midweek change posts, missing stays missing); the D1 price levels (strict levels, the retest after the breakout session, a missing bar ends the search, no look-ahead); the calm days; E_OPEN's plan; the earliest-day tie order.
- A synthetic world with GENUINE setuplab TAGS and TREE runs (setuplab's own commands): RECONCILED; every variant's day equals an independent per-pick oracle on every pick; eligibility; the held week never later than the frozen pulse; coverage and the blocking count by the oracle; the run folder (44 commands, CRLF bat, hashes); tradelab reads it, and refuses a run from another tree run or a tampered file; a disagreeing TAGS run → DIFFERS.
- Planted world: +6% after the held-week entry is found (+6 pp, interval above 0); absent world: nothing found.
- Holm by hand, the forward pick (at most two), and every guard.

18 planted bugs, each caught. tradelab's section 22 covers Stage 2's mechanics (10 more planted bugs).
