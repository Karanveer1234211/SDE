"""
branchlab.py - branchlab v1.0: the entry tree's open branches (study BR1).

    python branchlab.py check                                      the declaration and tradelab's strategies\\branchlab.py
                                                                   are the frozen ones (sha256)
    python branchlab.py run --root %CACHE_DAILY_ROOT% [--setups %SETUPLAB_OUT%] [--out <folder>] [--stage-e-any]
                            [--data <watchlist folder>] [--features <panel.parquet>]
                                                                   Stage 1 -> BRANCHLAB_OUT\\runs\\BR_<date>_<nnn>
    python branchlab.py holm [<TLB folder> ...] | --scan <tradelab backtest folder>
                                                                   Stage 2: Holm across each engine's runs

BRANCHLAB_DECLARATION.json (beside this file, frozen 13 Nov 2026 before any run) holds the study: the picks, the weekly
state, the 24 variants, the descriptive Stage 1 and the Stage 2 book (tradelab add-on v1.7, strategies\\branchlab.py).

READS (read only): setuplab's newest TREE and TAGS runs under SETUPLAB_OUT (hash-checked, the runs tradelab replays),
FROZEN_SETUPS.json through setuplab (hash-checked), the research watchlist and the panel the TAGS run used, the stocks'
daily bars through setuplab's LiveData (tradelab's tl_data: production's loader). WRITES only under --out /
BRANCHLAB_OUT: BR_<date>_<nnn>\\ REPORT.md, br_scores.parquet (tradelab's --branchlab reads it), coverage.csv,
blocking.csv, trades_desc.csv, stage2_commands.txt, run_stage2.bat, run.json, DECLARATION.json, outputs.sha256; one
line per run in branchlab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import tl_common as TC
import tl_setups as SU

VERSION = "branchlab v1.0"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "BRANCHLAB_DECLARATION.json"
DECL_SHA = "1ec45a66b982f903c371cf1d9e79faa934d2639e570977b96e50d395951bab0e"
STRAT_FILE = HERE.parent / "tradelab" / "strategies" / "branchlab.py"
LEDGER = "branchlab_ledger.jsonl"
SIX = ("S1", "S2", "S3", "C1", "C2", "C3")
ORDER = ("S1", "S2", "S3", "C1", "C2", "C3", "N1")        # setuplab's tie order (TREE_ORDER)
WEEKLY = "w_ret_13w_change"
STATES = ("L0", "L1", "L2", "P")                           # the bad-week state: frozen pulse, held 1 / 2 rows, held
D_ONLY = ("K_SLOT", "K_LATE", "K_BOTH")
ENS_ONLY = ("E_OPEN",)
WATCH = 5
COST = 0.35
WEEK_BACK_DAYS = 140                                       # panel rows read before the first watch row


class BRError(Exception):
    pass


def say(msg: str) -> None:
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def sha256(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def variants_for(engine: str) -> List[str]:
    return [v for v in SU.BR_VARIANTS if not (engine == "D" and v in ENS_ONLY) and not (engine == "ENS" and v in D_ONLY)]


def setuplab():
    try:
        import setuplab as SL
    except ImportError as e:
        raise BRError(f"cannot import setuplab ({e}) - start with env_branchlab.bat (it puts setuplab on PYTHONPATH)")
    return SL


# ---------------------------------------------------------------------------------------------------- declaration
def load_decl(path: Path = DECL_FILE, check: bool = True) -> Tuple[dict, str]:
    if not Path(path).is_file():
        raise BRError(f"{path} is missing - it ships beside branchlab.py")
    sha = sha256(path)
    if check and sha != DECL_SHA:
        raise BRError(f"{path} has sha256 {sha[:16]}, not the frozen declaration's {DECL_SHA[:16]}. The declaration is "
                      f"fixed before any run; a changed study is a new declaration (ask Claude).")
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    sb = d["stage2_book"]
    if tuple(sb["variants"]) != SU.BR_VARIANTS or sb["engines"]["D"] != variants_for("D") or \
            sb["engines"]["ENS"] != variants_for("ENS"):
        raise BRError(f"{path}: the Stage 2 variants differ from the ones this code and tradelab know")
    return d, sha


def out_base(arg: Optional[str], root: Optional[Path]) -> Path:
    v = arg or os.environ.get("BRANCHLAB_OUT")
    if not v:
        raise BRError("no output folder: pass --out or start with env_branchlab.bat (sets BRANCHLAB_OUT)")
    b = Path(v).resolve()
    guards = ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                          ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise BRError(f"output folder {b} is inside {g}; branchlab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


# ---------------------------------------------------------------------------------------------------- the weekly state
def read_weekly(panel: Path, symbols, first) -> pd.DataFrame:
    """symbol, date, w (w_ret_13w) and chg (the panel's w_ret_13w_change if it has one, else the row-to-row difference,
    setuplab's rule) for the given stocks from `first` on; dates normalised as setuplab does (zoned -> IST, no zone)."""
    import pyarrow.parquet as pq
    names = pq.read_schema(panel).names
    low = {c.lower(): c for c in names}
    dk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or not dk or "w_ret_13w" not in low:
        raise BRError(f"{panel}: needs symbol, timestamp (or date) and w_ret_13w")
    cols = [low["symbol"], dk, low["w_ret_13w"]] + ([low[WEEKLY]] if WEEKLY in low else [])
    syms = sorted({str(s).strip().upper() for s in symbols})
    try:
        F = pq.read_table(panel, columns=cols, filters=[(low["symbol"], "in", syms)]).to_pandas()
    except Exception:
        F = None
    if F is None or not len(F):
        F = pd.read_parquet(panel, columns=cols)
    if any(n is not None for n in F.index.names):
        F = F.reset_index()
    F.columns = [str(c).lower() for c in F.columns]
    dkl = dk.lower()
    F["symbol"] = F["symbol"].astype(str).str.strip().str.upper()
    t = pd.to_datetime(F[dkl])
    if t.dt.tz is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    F["date"] = t.dt.normalize()
    F = F[F["symbol"].isin(set(syms)) & (F["date"] >= pd.Timestamp(first))]
    if F.duplicated(["symbol", "date"]).any():
        raise BRError(f"{panel}: duplicated symbol/date rows")
    F = F.sort_values(["symbol", "date"]).reset_index(drop=True)
    F["w"] = pd.to_numeric(F["w_ret_13w"], errors="coerce").astype(float)
    F["chg"] = (pd.to_numeric(F[WEEKLY], errors="coerce").astype(float) if WEEKLY in F.columns
                else F.groupby("symbol")["w"].diff())
    return F[["symbol", "date", "w", "chg"]]


def weekly_states(F: pd.DataFrame) -> pd.DataFrame:
    """The bad-week state on every stock row (declaration 'weekly_state'). A posting row = the stock's first row of a
    calendar week (ISO) or a row whose change is not zero at 9 decimals (setuplab compares at 9 decimals, so float noise
    never posts); posted = the change at the latest posting row at or before
    the row, age = rows since it. L0 = posted on the posting row itself, else 0 (= the frozen w_ret_13w_change);
    L1 / L2 = posted while age <= 1 / 2, else 0; P = posted (held until the next posting row). A row whose own change
    is missing is missing in every state (nothing assumed)."""
    X = F.copy().reset_index(drop=True)
    iso = X["date"].dt.isocalendar()
    wk = (iso["year"].astype(int) * 100 + iso["week"].astype(int)).to_numpy()
    sym = X["symbol"].to_numpy()
    new_sym = np.r_[True, sym[1:] != sym[:-1]]
    first_wk = new_sym | np.r_[True, wk[1:] != wk[:-1]]
    chg = X["chg"].to_numpy(float)
    with np.errstate(invalid="ignore"):
        post = first_wk | (np.isfinite(chg) & (np.round(chg, 9) != 0))
    n = len(X)
    rowno = np.arange(n)
    start = np.maximum.accumulate(np.where(new_sym, rowno, 0))          # first row of the row's stock
    pidx = np.maximum.accumulate(np.where(post, rowno, -1))
    ok = pidx >= start                                                    # a posting row of the same stock
    posted = np.where(ok, chg[np.clip(pidx, 0, None)], np.nan)
    age = np.where(ok, rowno - pidx, 10 ** 6)
    miss = ~np.isfinite(chg)
    X["post"], X["posted"], X["age"] = post, posted, age
    X["L0"] = np.where(miss, np.nan, np.where(age == 0, posted, 0.0))
    X["L1"] = np.where(miss, np.nan, np.where(age <= 1, posted, 0.0))
    X["L2"] = np.where(miss, np.nan, np.where(age <= 2, posted, 0.0))
    X["P"] = np.where(miss, np.nan, posted)
    return X


def attach_states(book, X: pd.DataFrame) -> None:
    """book.F['br_w13_<L>'] = the state at the row before each watch day (k = 1..5: the session i1 + k - 2), aligned
    exactly as setuplab aligns a feature (symbol + calendar date; a missing row = missing)."""
    rows, ks, keys_s, keys_d = [], [], [], []
    for k in range(1, WATCH + 1):
        j = book.i1 + k - 2
        ok = (j >= 0) & (j < len(book.cal))
        rows.append(np.flatnonzero(ok))
        ks.append(np.full(ok.sum(), k))
        keys_s.append(book.symbols[ok])
        keys_d.append(book.cal[j[ok]])
    L = pd.DataFrame({"row": np.concatenate(rows), "k": np.concatenate(ks), "symbol": np.concatenate(keys_s),
                      "date": pd.to_datetime(np.concatenate(keys_d)).normalize()})
    M = L.merge(X[["symbol", "date"] + list(STATES)], on=["symbol", "date"], how="left")
    for s_ in STATES:
        A = np.full((book.n, WATCH + 1), np.nan)
        A[M["row"].to_numpy(), M["k"].to_numpy()] = M[s_].to_numpy(float)
        book.F["br_w13_" + s_] = A


def with_weekly(conds, field: Optional[str]):
    """The setup's conditions with the weekly condition replaced by `field` < 0 (None = removed)."""
    out = []
    for c in conds:
        if c[0] == WEEKLY:
            if field is not None:
                out.append((field, "<", 0.0))
        else:
            out.append(c)
    return out


def earliest(days: Dict[str, np.ndarray], order=ORDER) -> Tuple[np.ndarray, np.ndarray]:
    """The earliest day (0 = none) across setups and which setup (setuplab's tie order)."""
    n = len(next(iter(days.values())))
    best = np.zeros(n, dtype=np.int64)
    who = np.full(n, "", dtype=object)
    for s_ in order:
        if s_ not in days:
            continue
        d = np.asarray(days[s_], dtype=np.int64)
        better = (d > 0) & ((best == 0) | (d < best))
        best[better], who[better] = d[better], s_
    return best, who


# ---------------------------------------------------------------------------------------------------- price levels
def bars_hlc(book, ohlcv: Callable, forget: Callable = lambda s: None) -> Tuple[np.ndarray, ...]:
    """(H, L, C), each (picks, 6): column k = the stock's own bar ON watch day k's calendar date (D1..D5); a missing bar
    or date = NaN."""
    n = book.n
    H, L, C = (np.full((n, WATCH + 1), np.nan) for _ in range(3))
    rows_of = pd.Series(np.arange(n)).groupby(book.symbols).indices
    syms = sorted(rows_of)
    want = {k: book.cal[np.clip(book.i1 + k - 1, 0, len(book.cal) - 1)].astype("datetime64[D]")
            for k in range(1, WATCH + 1)}
    past = {k: (book.i1 + k - 1) >= len(book.cal) for k in range(1, WATCH + 1)}
    for i in range(0, len(syms), 100):
        part = syms[i:i + 100]
        got = ohlcv(part)
        for s_ in part:
            if s_ not in got:
                continue
            dates, o, h, l, c = got[s_][:5]
            dates = np.asarray(dates).astype("datetime64[D]")
            h, l, c = (np.asarray(x, float) for x in (h, l, c))
            rr = np.asarray(rows_of[s_], dtype=np.int64)
            for k in range(1, WATCH + 1):
                d = want[k][rr]
                j = np.searchsorted(dates, d)
                hit = (j < len(dates)) & ~past[k][rr]
                hit[hit] &= dates[j[hit]] == d[hit]
                r2, j2 = rr[hit], j[hit]
                H[r2, k], L[r2, k], C[r2, k] = h[j2], l[j2], c[j2]
        forget(part)
    return H, L, C


def price_days(H: np.ndarray, L: np.ndarray, C: np.ndarray) -> Dict[str, np.ndarray]:
    """B_BRK / B_RET / B_RCL: the watch day (3..5) bought at the open after the close of session s (D2..D4) that
    completes the pattern; 0 = none. A missing bar on D1..D_s ends the search (nothing assumed)."""
    n = len(H)
    H1, L1 = H[:, 1], L[:, 1]
    alive = np.isfinite(H1) & np.isfinite(L1) & np.isfinite(C[:, 1])
    brk, ret, rcl = (np.zeros(n, dtype=np.int64) for _ in range(3))
    broke = np.zeros(n, dtype=bool)                       # a close above H1 happened on an earlier session
    for s in range(2, WATCH):                             # s = 2, 3, 4 -> buy at the open of s + 1
        alive &= np.isfinite(H[:, s]) & np.isfinite(L[:, s]) & np.isfinite(C[:, s])
        cs, ls = C[:, s], L[:, s]
        with np.errstate(invalid="ignore"):
            up = alive & (cs > H1)
            ret_hit = alive & broke & (ls <= H1) & (cs > H1)
            below_prev = (C[:, s - 1] < L1) if s >= 3 else np.zeros(n, dtype=bool)
            rcl_hit = alive & (((ls < L1) & (cs > L1)) | (below_prev & (cs > L1)))
        brk[(brk == 0) & up] = s + 1
        ret[(ret == 0) & ret_hit] = s + 1
        rcl[(rcl == 0) & rcl_hit] = s + 1
        broke |= up
    return {"B_BRK": brk, "B_RET": ret, "B_RCL": rcl}


# ---------------------------------------------------------------------------------------------------- calm and ENS
def calm_days(book, calm_d: np.ndarray, opened_up: np.ndarray) -> Dict[str, np.ndarray]:
    """K_SLOT: day 1 for a calm D pick whose D1 open >= its close; K_LATE: after a lower D1 open, the first D2..D5 open
    >= its close (a missing open ends the search); K_BOTH: either."""
    n = book.n
    slot = np.where(calm_d & (opened_up == 1), 1, 0).astype(np.int64)
    late = np.zeros(n, dtype=np.int64)
    live = calm_d & (opened_up == 0)
    for k in range(2, WATCH + 1):
        o = book.O[:, k]
        live &= np.isfinite(o)
        with np.errstate(invalid="ignore"):
            hit = live & (late == 0) & (o >= book.sc)
        late[hit] = k
    both = np.where(slot > 0, slot, late)
    return {"K_SLOT": slot, "K_LATE": late, "K_BOTH": both}


def e_open_plan(tags: pd.DataFrame, ids: np.ndarray, primary: dict) -> Tuple[np.ndarray, np.ndarray]:
    """E_OPEN's plan per pick from the TAGS run: the first frozen setup's watch day (setuplab's tie order) and the close
    it sells at (the 5th; a 'fresh' setup 4 sessions after its entry). 0 = no setup."""
    T = tags.set_index(tags["trade_id"].astype(str)).reindex([str(x) for x in ids])
    days = {}
    for s_ in ORDER:
        col = f"su_{s_}_day"
        if col in T.columns:
            days[s_] = np.nan_to_num(pd.to_numeric(T[col], errors="coerce").to_numpy(float), nan=0).astype(np.int64)
    day, who = earliest(days)
    ex = np.where(day > 0, np.where([primary.get(w) == "fresh" for w in who], day + 4, 5), 0)
    return day, ex


# ---------------------------------------------------------------------------------------------------- the audit
def blocking(book, conds: dict, skip: np.ndarray) -> Tuple[pd.DataFrame, np.ndarray]:
    """For the jumpy picks the frozen tree skips: per setup, why it did not buy -
    R1 the other conditions held on a watch day while the week's held state was bad but its one-day pulse was not;
    R2 they held only while the week was not bad; R3 they never all held on a day with every value; R4 no day had
    every value. The family reason = the first of R1..R4 any setup has."""
    rows, fam = [], np.full(book.n, 9)
    for s_ in SIX:
        other = with_weekly(conds[s_], None)
        r1 = np.zeros(book.n, bool)
        r2 = np.zeros(book.n, bool)
        r3 = np.zeros(book.n, bool)
        for k in range(1, WATCH + 1):
            vals = [book.field(f)[:, k] for f, _, _ in other]
            fin = np.all([np.isfinite(v) for v in vals], axis=0) if vals else np.ones(book.n, bool)
            okk = fin.copy()
            for (f, op, v), a in zip(other, vals):
                with np.errstate(invalid="ignore"):
                    okk &= SL_OPS[op](np.round(np.where(np.isfinite(a), a, 0), 9), round(float(v), 9))
            p = book.F["br_w13_P"][:, k]
            pulse = book.F[WEEKLY][:, k]
            wfin = np.isfinite(p) & np.isfinite(pulse)
            with np.errstate(invalid="ignore"):
                r1 |= okk & wfin & (p < 0) & ~(pulse < 0)
                r2 |= okk & wfin & ~(p < 0)
            r3 |= fin & wfin
        reason = np.where(r1, 1, np.where(r2, 2, np.where(r3, 3, 4)))
        fam = np.minimum(fam, np.where(skip, reason, 9))
        for r in (1, 2, 3, 4):
            rows.append({"engine": book.engine, "setup": s_, "reason": f"R{r}", "picks": int((skip & (reason == r)).sum())})
    for r in (1, 2, 3, 4):
        rows.append({"engine": book.engine, "setup": "family", "reason": f"R{r}", "picks": int((skip & (fam == r)).sum())})
    return pd.DataFrame(rows), fam


SL_OPS = {">": np.greater, "<": np.less, ">=": np.greater_equal, "<=": np.less_equal}


# ---------------------------------------------------------------------------------------------------- one engine
def engine_study(SL, book, conds: dict, tree: pd.DataFrame, tags: pd.DataFrame, primary: dict,
                 ohlcv: Callable, forget: Callable, X: pd.DataFrame, log=say) -> dict:
    """Everything for one engine's ranks 1-3 book: the reconciliation, every variant's day, the audit and the
    descriptive trades."""
    eng = book.engine
    attach_states(book, X)
    n = book.n
    ids = book.ids.astype(str)
    # the frozen pulse rebuilt = setuplab's own feature, and the frozen setups = the TAGS run
    f0, fr = book.F["br_w13_L0"], book.F[WEEKLY]
    pulse_same = bool(np.array_equal(np.isfinite(f0), np.isfinite(fr)) and
                      np.allclose(np.nan_to_num(f0), np.nan_to_num(fr), rtol=0, atol=1e-12))
    TG = tags.set_index(tags["trade_id"].astype(str)).reindex(ids)
    recon, mism = {}, []
    for s_ in SIX + ("N1",):
        cc = with_weekly(conds[s_], "br_w13_L0") if s_ in SIX else conds[s_]
        d, _ = SL.trigger(book, cc)
        ref = np.nan_to_num(pd.to_numeric(TG[f"su_{s_}_day"], errors="coerce").to_numpy(float), nan=0).astype(np.int64)
        bad = np.flatnonzero(d != ref)
        recon[s_] = int(len(bad))
        mism += [(ids[i], s_, int(d[i]), int(ref[i])) for i in bad[:3]]
    # the tree's routing per pick (the TREE run tradelab replays)
    TR = tree.set_index(tree["trade_id"].astype(str)).reindex(ids)
    lane = TR["lane"].fillna("").astype(str).to_numpy()
    etf = TR["etf"].astype("boolean").fillna(False).to_numpy(bool)
    action = TR["action"].fillna("").astype(str).to_numpy()
    how = TR["how"].fillna("").astype(str).to_numpy()
    up = TR["opened_up"].astype("boolean")
    opened_up = np.where(up.isna().to_numpy(), -1, up.fillna(False).astype(int).to_numpy())
    routed = (action != "") & ~etf & (lane != "NO CUT-OFF") & book.ok
    jumpy = routed & np.isin(lane, ["JUMPY", "NO ATR"])
    calm = routed & (lane == "CALM")
    tree_day = np.zeros(n, dtype=np.int64)
    for i, h in enumerate(how):
        if h == "open":
            tree_day[i] = 1
        elif "@D" in h:
            tree_day[i] = int(h.split("@D")[1])
    tree_net = np.where(how == "open", pd.to_numeric(TR["d1_net"], errors="coerce").to_numpy(float),
                        np.where(how != "", pd.to_numeric(TR["setup_net"], errors="coerce").to_numpy(float), 0.0))
    # the variants
    days: Dict[str, np.ndarray] = {}
    for s_ in SIX:
        days[f"P_{s_}"] = SL.trigger(book, with_weekly(conds[s_], "br_w13_P"))[0]
        days[f"N_{s_}"] = SL.trigger(book, with_weekly(conds[s_], None))[0]
    days["P_ALL"] = earliest({s_: days[f"P_{s_}"] for s_ in SIX})[0]
    days["N_ALL"] = earliest({s_: days[f"N_{s_}"] for s_ in SIX})[0]
    for lv, nm in (("L1", "P_ALL1"), ("L2", "P_ALL2")):
        days[nm] = earliest({s_: SL.trigger(book, with_weekly(conds[s_], "br_w13_" + lv))[0] for s_ in SIX})[0]
    log(f" {eng}: reading the picks' daily bars (D1-D5 highs, lows, closes)")
    H, L_, C_ = bars_hlc(book, ohlcv, forget)
    days.update(price_days(H, L_, C_))
    days["X_D2"] = np.where(np.isfinite(book.O[:, 2]), 2, 0).astype(np.int64)
    jm = jumpy
    for v in [x for x in days]:
        days[v] = np.where(jm & book.ok, days[v], 0)
    kd = calm_days(book, calm & (eng == "D"), opened_up)
    days.update({k: np.where(book.ok, v, 0) for k, v in kd.items()})
    e_flag = calm & (eng == "ENS") & (opened_up == 0)
    e_day, e_exit = e_open_plan(tags, ids, primary)
    days["E_OPEN"] = np.where(e_flag, e_day, 0)
    e_exit = np.where(e_flag & (e_day > 0), e_exit, 0)
    # the per-pick frame (tradelab's br_* attributes)
    B = pd.DataFrame({"trade_id": ids})
    B["br_jumpy"] = np.where(routed, jumpy.astype(float), np.nan)
    for v in SU.BR_VARIANTS:
        d = days.get(v, np.zeros(n, dtype=np.int64))
        if v not in variants_for(eng):
            d = np.zeros(n, dtype=np.int64)
        B[f"br_{v}_day"] = np.where(d > 0, d, np.nan).astype(float)
    B["br_E_OPEN"] = np.where(routed, e_flag.astype(float), np.nan) if eng == "ENS" else np.where(routed, 0.0, np.nan)
    B["br_E_OPEN_exit"] = np.where(e_exit > 0, e_exit, np.nan).astype(float)
    # coverage, weekdays, the audit, the descriptive trades
    skip = jumpy & (tree_day == 0)
    aud, fam = blocking(book, conds, skip)
    boot = SL.Boot(book.signal_day)
    di = boot.index(book.signal_day)
    d1 = SL.exits_arr(book, np.ones(n, dtype=np.int64), np.where(book.ok, "Filled", "Unsettled"), "original_d5")
    cov, desc = [], []
    for v in variants_for(eng):
        d = np.asarray(B[f"br_{v}_day"].fillna(0).to_numpy(), dtype=np.int64)
        has = d > 0
        if v == "E_OPEN":
            elig = e_flag
            changed = e_flag
        else:
            elig = jumpy if not v.startswith("K_") else calm & (eng == "D")
            changed = has & ((tree_day == 0) | (d < tree_day))
        ent = np.clip(book.i1 + np.maximum(d, 1) - 1, 0, len(book.cal) - 1)
        wd = pd.DatetimeIndex(book.cal[ent]).weekday.to_numpy()
        row = {"engine": eng, "variant": v, "eligible": int(elig.sum()), "with_day": int(has.sum()),
               "tree_skips": int((has & (tree_day == 0)).sum()), "before_tree": int((has & (tree_day > 0) & (d < tree_day)).sum()),
               "same_day": int((has & (d == tree_day)).sum()), "after_tree": int((has & (tree_day > 0) & (d > tree_day)).sum())}
        for k in range(1, WATCH + 1):
            row[f"D{k}"] = int((d == k).sum())
        for w, nm in enumerate(("Mon", "Tue", "Wed", "Thu", "Fri")):
            row[nm] = int((has & (wd == w)).sum())
        cov.append(row)
        # the variant's own trades (setuplab's convention: the D_k open -> its exit close, 35 bp, no honest exits)
        st = np.where(has & book.ok, "Filled", "No entry")
        r5 = SL.exits_arr(book, np.maximum(d, 1), st, "original_d5")
        rf = SL.exits_arr(book, np.maximum(d, 1), st, "fresh")
        if v == "E_OPEN":
            fresh = has & (np.asarray(B["br_E_OPEN_exit"].fillna(0).to_numpy(), dtype=np.int64) != 5)
            vret = np.where(fresh, rf["ret"], r5["ret"])
            vf = np.where(fresh, rf["f"], r5["f"])
            vnet_changed = np.where(vf, vret, np.where(changed & ~has, 0.0, np.nan))   # no setup = cash, 0
        else:
            vret, vf = r5["ret"], r5["f"]
            vnet_changed = np.where(vf, vret, np.nan)
        own = vf & has
        lo, hi = boot.ci_idx(di[own], vret[own]) if own.sum() > 1 else (np.nan, np.nan)
        m = changed & np.isfinite(vnet_changed) & np.isfinite(tree_net)
        diff = vnet_changed - tree_net
        dlo, dhi = boot.ci_idx(di[m], diff[m]) if m.sum() > 1 else (np.nan, np.nan)
        m1 = own & d1["f"]
        desc.append({"engine": eng, "variant": v, "trades": int(own.sum()),
                     "net_pct": float(np.mean(vret[own])) if own.any() else np.nan, "net_lo": lo, "net_hi": hi,
                     "d1_same_picks_pct": float(np.mean(d1["ret"][m1])) if m1.any() else np.nan,
                     "changed_picks": int(m.sum()),
                     "changed_variant_pct": float(np.mean(vnet_changed[m])) if m.any() else np.nan,
                     "changed_tree_pct": float(np.mean(tree_net[m])) if m.any() else np.nan,
                     "changed_diff_pct": float(np.mean(diff[m])) if m.any() else np.nan, "diff_lo": dlo, "diff_hi": dhi})
    return {"B": B, "coverage": pd.DataFrame(cov), "desc": pd.DataFrame(desc), "audit": aud,
            "recon": recon, "mismatch": mism, "pulse_same": pulse_same, "picks": n, "jumpy": int(jumpy.sum()),
            "calm": int(calm.sum()), "skip": int(skip.sum()), "routed": int(routed.sum())}


# ---------------------------------------------------------------------------------------------------- the study
def study(SL, data_dir: Path, panel: Path, tree: pd.DataFrame, tags: pd.DataFrame, primary: dict, ohlcv: Callable,
          forget: Callable, frozen=None, log=say) -> dict:
    fp, fdoc = SL.load_frozen(frozen)
    conds, feats = SL.frozen_conds(fdoc), SL.frozen_features(fdoc)
    if set(SIX + ("N1",)) - set(conds):
        raise BRError(f"{fp}: the frozen setups are not S1-S3 / C1-C3 / N1")
    if any(not any(c[0] == WEEKLY for c in conds[s_]) for s_ in SIX):
        raise BRError(f"{fp}: S1-S3 / C1-C3 should each hold {WEEKLY} < 0")
    out = {"frozen_sha256": fdoc["sha256"], "engines": {}}
    Xs = []
    for eng in ("D", "ENS"):
        log(f" {eng}: the research watchlist (ranks 1-3) and the setups' features from the panel")
        try:
            book = SL.load(str(data_dir), str(panel), eng, feats, [1, 2, 3], lambda *a: None, 8)
        except ValueError as e:
            raise BRError(f"setuplab could not load the watchlist / panel: {e}")
        if book.n == 0:
            raise BRError(f"no {eng} picks of ranks 1-3 in {data_dir}")
        miss = [f for f in feats if f not in book.features]
        if miss:
            raise BRError(f"the panel lacks {miss} (the frozen setups need them)")
        first = pd.Timestamp(book.cal[max(0, int(book.i1.min()) - 2)]) - pd.Timedelta(days=WEEK_BACK_DAYS)
        Xe = weekly_states(read_weekly(Path(panel), book.symbols, first))
        Xs.append(Xe[["symbol", "date", "chg"]])
        out["engines"][eng] = engine_study(SL, book, conds, tree, tags, primary, ohlcv, forget, Xe, log)
    W = pd.concat(Xs).drop_duplicates(["symbol", "date"]).sort_values(["symbol", "date"]).reset_index(drop=True)
    nz = np.isfinite(W["chg"].to_numpy(float)) & (np.round(W["chg"].to_numpy(float), 9) != 0)
    out["weekly_audit"] = {"stock_rows": int(len(W)), "changes": int(nz.sum()),
                           "changes_on_first_row_of_week": int((nz & weekly_first(W)).sum())}
    return out


def weekly_first(W: pd.DataFrame) -> np.ndarray:
    iso = W["date"].dt.isocalendar()
    wk = (iso["year"].astype(int) * 100 + iso["week"].astype(int)).to_numpy()
    sym = W["symbol"].to_numpy()
    return np.r_[True, (sym[1:] != sym[:-1]) | (wk[1:] != wk[:-1])]


# ---------------------------------------------------------------------------------------------------- outputs
def stage2_commands(run: Path, pm_run: str) -> List[str]:
    return [f'python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run {pm_run} --strategy strategies\\branchlab.py#{v} '
            f'--compare strategies\\tree.py --engines {e} --branchlab "{run}" --declare "branchlab BR1 {v} {e}"'
            for e in ("D", "ENS") for v in variants_for(e)]


def stage2_bat(cmds: List[str], base: Path) -> str:
    tl = HERE.parent / "tradelab"
    L = ["@echo off", f"rem run_stage2.bat - branchlab BR1 Stage 2: the {len(cmds)} declared backtests, then Holm "
         f"(written by {VERSION})", f'call "{tl / "env_tradelab.bat"}"', "if errorlevel 1 goto :fail",
         f'set "BRANCHLAB_OUT={base}"', f'cd /d "{tl}"']
    for c in cmds:
        L += [c, "if errorlevel 1 goto :fail"]
    L += [f'cd /d "{HERE}"', 'python branchlab.py holm --scan "%TRADELAB_OUT%\\backtest"', "echo RESULT: Stage 2 done",
          "pause", "goto :eof", ":fail", "echo RESULT: FAILED - send Claude the lines above", "pause", "exit /b 1"]
    return "\r\n".join(L) + "\r\n"


def _p(x, nd=2):
    return "-" if x is None or not np.isfinite(x) else f"{x:+.{nd}f}"


def report(res: dict, decl: dict, sha: str, info: dict, cmds: List[str], secs: float) -> str:
    wa = res["weekly_audit"]
    share = wa["changes_on_first_row_of_week"] / wa["changes"] if wa["changes"] else np.nan
    L = [f"# branchlab - {decl['name']} ({VERSION})", "",
         f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). Tree run {info['tree_run']} "
         f"(tree_tags sha256 {info['tree_sha256'][:16]}), TAGS run {info['tags_run']}, freeze "
         f"{res['frozen_sha256'][:16]}; watchlist `{info['data']}`, panel `{info['panel']}`. {secs:.0f} s.", "",
         "## Verdict first", "",
         "Stage 1 is descriptive: it builds every variant's day on every tree pick and checks them. **Stage 2 decides** "
         f"(the {len(cmds)} declared backtests against the frozen tree, then `python branchlab.py holm`): double-click "
         "`run_stage2.bat` in this folder.", ""]
    ok = all(sum(e["recon"].values()) == 0 and e["pulse_same"] for e in res["engines"].values())
    L.append(f"- **{'RECONCILED' if ok else 'DIFFERS'}**: the six bad-week setups rebuilt with the frozen one-day pulse "
             f"(and N1 unchanged) give the TAGS run's entry day on every pick of ranks 1-3 "
             + ("(D and ENS)." if ok else "- see below; br_scores.parquet was NOT written."))
    L.append(f"- Weekly values: {wa['changes']:,} changes of w_ret_13w on {wa['stock_rows']:,} stock rows read, "
             f"{share:.1%} on a stock's first row of a calendar week (the 7 Nov audit found 99.3%).")
    L += ["", "## Coverage (picks of ranks 1-3 in the tree's window)", "",
          "with day = picks the variant buys; the tree skips = new picks; before the tree = the variant buys earlier than "
          "the tree's own buy (it replaces it in Stage 2); same day / after = the tree's buy stands.", "",
          "| engine | variant | eligible | with day | tree skips | before tree | same day | after tree | D1 | D2 | D3 | D4 "
          "| D5 | Mon | Tue | Wed | Thu | Fri |", "|---|---|" + "---:|" * 16]
    for eng, e in res["engines"].items():
        for r in e["coverage"].to_dict("records"):
            L.append("| " + " | ".join([eng, r["variant"]] + [f"{r[k]:,}" for k in (
                "eligible", "with_day", "tree_skips", "before_tree", "same_day", "after_tree", "D1", "D2", "D3", "D4", "D5",
                "Mon", "Tue", "Wed", "Thu", "Fri")]) + " |")
    L += ["", "## Why the frozen setups skipped the jumpy picks (the blocking count)", "",
          "R1 = the other conditions held on a watch day while the week was bad but the one-day pulse was not (the held "
          "state would buy); R2 = they held only in a week that was not bad; R3 = they never all held on a day with every "
          "value; R4 = no day had every value. family = the first reason any of the six has.", "",
          "| engine | skipped jumpy picks | setup | R1 pulse | R2 not a bad week | R3 other conditions | R4 missing |",
          "|---|---:|---|---:|---:|---:|---:|"]
    for eng, e in res["engines"].items():
        A = e["audit"].pivot_table(index="setup", columns="reason", values="picks", aggfunc="sum")
        for s_ in list(SIX) + ["family"]:
            L.append(f"| {eng} | {e['skip']:,} | {s_} | " + " | ".join(f"{int(A.at[s_, r]):,}" for r in
                                                                       ("R1", "R2", "R3", "R4")) + " |")
    L += ["", "## Each variant's own trades (descriptive)", "",
          "setuplab's convention: the D_k open to the 5th close (E_OPEN: its setup's exit), 35 bp, a locked close sold at "
          "that close - NOT tradelab's honest exits or account. 'changed picks' = the picks where the variant changes "
          "the frozen tree's plan; their net under the variant minus under the tree (a skip = 0, cash). 95% intervals: "
          "10-day blocks of signal days, 2,000 resamples. History already seen: none of this is evidence on its own.", "",
          "| engine | variant | trades | net % | 95% | D1 open, same picks % | changed picks | variant % | tree % | "
          "difference % | 95% |", "|---|---|---:|---:|---|---:|---:|---:|---:|---:|---|"]
    for eng, e in res["engines"].items():
        for r in e["desc"].to_dict("records"):
            L.append(f"| {eng} | {r['variant']} | {r['trades']:,} | {_p(r['net_pct'])} | [{_p(r['net_lo'])}, "
                     f"{_p(r['net_hi'])}] | {_p(r['d1_same_picks_pct'])} | {r['changed_picks']:,} | "
                     f"{_p(r['changed_variant_pct'])} | {_p(r['changed_tree_pct'])} | {_p(r['changed_diff_pct'])} | "
                     f"[{_p(r['diff_lo'])}, {_p(r['diff_hi'])}] |")
    if not ok:
        L += ["", "## Reconciliation differences", ""]
        for eng, e in res["engines"].items():
            L.append(f"- {eng}: per setup {e['recon']}; one-day pulse identical: {e['pulse_same']}; first: "
                     f"{e['mismatch'][:6]}")
    L += ["", "## Stage 2 - what decides", "",
          f"`run_stage2.bat` runs these {len(cmds)} backtests from the tradelab folder (about 2 minutes each on your PC), "
          "then `python branchlab.py holm --scan`. PASS per run = the daily-return difference against the frozen tree "
          "has a 95% interval above 0, AND the CAGR is higher, AND the worst drawdown is no deeper; then Holm per "
          "engine (D 23, ENS 21; 0.025 one-sided). A FINAL PASS is a forward candidate only; at most two go forward "
          "(the declaration's rule).", "", "```"] + cmds + ["```", ""]
    return "\n".join(L)


def execute(decl: dict, sha: str, tree: pd.DataFrame, trinfo: dict, tags: pd.DataFrame, tinfo: dict, data_dir: Path,
            panel: Path, pm_run: str, bout: Path, ohlcv: Callable, forget: Callable, t0=None, frozen=None) -> Tuple[int, Path]:
    """Stage 1 on resolved inputs: the study, then the run folder (br_scores.parquet only when RECONCILED)."""
    t0 = t0 or dt.datetime.now()
    SL = setuplab()
    res = study(SL, data_dir, panel, tree, tags, tinfo["primary_exit"], ohlcv, forget, frozen)
    ok = all(sum(e["recon"].values()) == 0 and e["pulse_same"] for e in res["engines"].values())
    run = SL.new_run_dir(bout / "runs", "BR")
    info = {"tree_run": trinfo["run"], "tree_sha256": trinfo["sha256"], "tags_run": tinfo["run"], "data": str(data_dir),
            "panel": str(panel)}
    cmds = stage2_commands(run, pm_run)
    secs = (dt.datetime.now() - t0).total_seconds()
    (run / "REPORT.md").write_text(report(res, decl, sha, info, cmds, secs), encoding="utf-8")
    names = ["REPORT.md"]
    if ok:
        B = pd.concat([e["B"] for e in res["engines"].values()], ignore_index=True)
        B.to_parquet(run / SU.BR_FILE, index=False)
        names.append(SU.BR_FILE)
    pd.concat([e["coverage"] for e in res["engines"].values()]).to_csv(run / "coverage.csv", index=False)
    pd.concat([e["audit"] for e in res["engines"].values()]).to_csv(run / "blocking.csv", index=False)
    pd.concat([e["desc"] for e in res["engines"].values()]).to_csv(run / "trades_desc.csv", index=False,
                                                                     float_format="%.10g")
    (run / "stage2_commands.txt").write_bytes(("\r\n".join(cmds) + "\r\n").encode("utf-8"))
    (run / "run_stage2.bat").write_bytes(stage2_bat(cmds, bout).encode("utf-8"))
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    rj = {"tool": VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "declaration_sha256": sha,
          "tree_run": trinfo["run"], "tree_run_sha256": trinfo["sha256"], "tags_run": tinfo["run"],
          "tags_sha256": tinfo["sha256"], "frozen_sha256": res["frozen_sha256"], "watchlist": str(data_dir),
          "panel": str(panel), "pm_run": pm_run, "reconciled": ok, "weekly_audit": res["weekly_audit"],
          "engines": {k: {x: v[x] for x in ("picks", "routed", "jumpy", "calm", "skip", "recon", "pulse_same")}
                      for k, v in res["engines"].items()}, "seconds": round(secs, 1)}
    (run / "run.json").write_text(json.dumps(rj, indent=1, default=str), encoding="utf-8")
    names += ["coverage.csv", "blocking.csv", "trades_desc.csv", "stage2_commands.txt", "run_stage2.bat",
              "DECLARATION.json", "run.json"]
    SL.write_hashes(run, names)
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "event": "run",
                            "run": run.name, "declaration_sha256": sha, "reconciled": ok,
                            "tree_run": trinfo["run"], "tags_run": tinfo["run"]}) + "\n")
    say(f"wrote {run}")
    if not ok:
        say("RESULT: DIFFERS - the rebuilt frozen setups do not match the TAGS run; br_scores.parquet NOT written "
            "(send Claude REPORT.md)")
        return 3, run
    say(f"RESULT: Stage 1 done ({len(cmds)} Stage 2 backtests in run_stage2.bat)")
    return 0, run


def resolve(base: Path, data: Optional[str], features: Optional[str]):
    """setuplab's newest TREE and TAGS runs (hash-checked: the runs tradelab replays) and the watchlist and panel the
    TAGS run used (or the ones given)."""
    tree, trinfo = SU.load_tree(base, need=True)
    tags, tinfo = SU.load_tags(base, need=True)
    if trinfo.get("frozen_sha256") and tinfo.get("frozen_sha256") and trinfo["frozen_sha256"] != tinfo["frozen_sha256"]:
        raise BRError(f"tree run {trinfo['run']} and TAGS run {tinfo['run']} come from different freezes - refusing")
    meta = json.loads((Path(tinfo["folder"]) / "TAGS.json").read_text(encoding="utf-8"))
    data_dir = Path(data) if data else Path(meta.get("watchlist", "")).parent
    panel = Path(features) if features else Path(meta.get("panel", ""))
    for p_, what in ((data_dir / "watchlist.parquet", "the research watchlist"), (panel, "the panel")):
        if not p_.is_file():
            raise BRError(f"{what} the TAGS run used is not at {p_} - pass --data <folder> / --features <panel.parquet>")
    return tree, trinfo, tags, tinfo, data_dir, panel


def cmd_run(a) -> int:
    t0 = dt.datetime.now()
    decl, sha = load_decl()
    SL = setuplab()
    root = Path(a.root) if a.root else None
    if root is None or not root.is_dir():
        raise BRError("--root must be the daily cache (%CACHE_DAILY_ROOT%)")
    base = SU.base_dir(a.setups)
    if base is None:
        raise BRError("setuplab's output folder: pass --setups or start with env_branchlab.bat (sets SETUPLAB_OUT)")
    tree, trinfo, tags, tinfo, data_dir, panel = resolve(base, a.data, a.features)
    pm_run = a.pm_run or decl["stage2_book"]["pm_run"]
    bout = out_base(a.out, root)
    say(f"{VERSION} run | declaration {sha[:16]} | tree {trinfo['run']} | tags {tinfo['run']} | out {bout}")
    data = SL.LiveData(str(root), a.stage_e_any, panel=None)
    return execute(decl, sha, tree, trinfo, tags, tinfo, data_dir, panel, pm_run, bout, data.ohlcv, data.forget, t0)[0]


# ---------------------------------------------------------------------------------------------------- Stage 2
def holm(rows: List[dict], alpha: float = 0.025) -> List[dict]:
    out = []
    for eng in sorted({r["engine"] for r in rows}):
        g = sorted([r for r in rows if r["engine"] == eng],
                   key=lambda r: (np.inf if not np.isfinite(r["p"]) else r["p"], SU.BR_VARIANTS.index(r["variant"])))
        m, going = len(g), True
        for i, r in enumerate(g):
            lim = alpha / (m - i)
            keep = going and np.isfinite(r["p"]) and r["p"] <= lim
            going = keep
            out.append(dict(r, family=m, holm_limit=lim, holm_kept=bool(keep),
                            final="PASS" if keep and r["rule_verdict"] == "PASS" else "FAIL"))
    return out


def forward_pick(H: List[dict], k: int = 2) -> List[dict]:
    """At most k forward candidates: the FINAL PASS runs with the smallest p (D before ENS, then the declared order)."""
    P = [r for r in H if r["final"] == "PASS"]
    P.sort(key=lambda r: (r["p"], 0 if r["engine"] == "D" else 1, SU.BR_VARIANTS.index(r["variant"])))
    return P[:k]


def read_backtest(folder: Path, want_sha: str) -> dict:
    sj = folder / "summary.json"
    if not sj.is_file():
        raise BRError(f"{folder}: no summary.json")
    s = json.loads(sj.read_text(encoding="utf-8"))
    st, dec = s.get("strategy") or {}, s.get("decision") or {}
    copies = sorted(folder.glob("strategy_*.py"))
    if not st.get("variant") or not copies:
        raise BRError(f"{folder}: not a run of strategies\\branchlab.py#NAME")
    if want_sha and sha256(copies[0]) != want_sha:
        raise BRError(f"{folder}: its strategy file is not the declared strategies\\branchlab.py (sha256 "
                      f"{sha256(copies[0])[:16]} vs {want_sha[:16]})")
    eng = (st.get("picks") or {}).get("engines") or []
    if len(eng) != 1:
        raise BRError(f"{folder}: one engine per run (this one {eng})")
    if (s.get("compare") or {}).get("name") != "tree":
        raise BRError(f"{folder}: compared with {(s.get('compare') or {}).get('name')}, not the frozen tree")
    if st["variant"] not in variants_for(eng[0]):
        raise BRError(f"{folder}: {st['variant']} is not declared for engine {eng[0]}")
    if not (s.get("branchlab") or {}).get("used"):
        raise BRError(f"{folder}: run without --branchlab")
    cg, dd = dec.get("cagr") or [np.nan, np.nan], dec.get("max_drawdown") or [np.nan, np.nan]
    return {"folder": folder.name, "engine": eng[0], "variant": st["variant"], "rule_verdict": dec.get("verdict"),
            "p": float(dec["p_one_sided"]) if dec.get("p_one_sided") is not None else np.nan,
            "cagr": cg[0], "cagr_tree": cg[1], "dd": dd[0], "dd_tree": dd[1],
            "br_run": (s.get("branchlab") or {}).get("run")}


def cmd_holm(a) -> int:
    decl, sha = load_decl()
    want = decl["stage2_book"]["strategies_sha256"]
    folders = [Path(x) for x in a.folders]
    if a.scan:
        for f in sorted(Path(a.scan).glob("TLB_*")):
            sj = f / "summary.json"
            if sj.is_file():
                st = json.loads(sj.read_text(encoding="utf-8")).get("strategy") or {}
                if st.get("variant") and str(st.get("name", "")).startswith("branchlab_"):
                    folders.append(f)
    if not folders:
        raise BRError("no tl_backtest runs given (folders, or --scan <TRADELAB_OUT>\\backtest)")
    rows = [read_backtest(f, want) for f in folders]
    seen = {}
    for r in rows:
        k = (r["engine"], r["variant"])
        if k in seen:
            raise BRError(f"{r['variant']} on {r['engine']} appears twice ({seen[k]}, {r['folder']}): a declared test "
                          f"is run once - give the folders to use")
        seen[k] = r["folder"]
    runs_ = {r["br_run"] for r in rows}
    if len(runs_) > 1:
        raise BRError(f"the runs used different branchlab runs {sorted(map(str, runs_))} - one Stage 1 run per study")
    H = holm(rows, decl["stage2_book"].get("holm_alpha", 0.025))
    say(f"{VERSION} holm | declaration {sha[:16]} | {len(H)} runs | branchlab run {next(iter(runs_))}")
    for eng in ("D", "ENS"):
        n_ = sum(1 for r in H if r["engine"] == eng)
        if n_ != len(variants_for(eng)):
            say(f"NOTE: {eng} has {n_} of the {len(variants_for(eng))} declared runs - the family is incomplete, "
                f"verdicts provisional")
    say("engine | variant | rule | p (one-sided) | Holm limit | kept | FINAL | CAGR (tree) | worst DD (tree) | goal | run")
    for r in H:
        goal = (np.isfinite(r["dd"]) and r["dd"] >= -0.25 and np.isfinite(r["cagr"]) and np.isfinite(r["cagr_tree"])
                and r["cagr"] >= 0.7 * r["cagr_tree"])
        r["goal"] = bool(goal)
        say(f"{r['engine']} | {r['variant']} | {r['rule_verdict']} | {r['p']:.4f} | {r['holm_limit']:.5f} | "
            f"{'yes' if r['holm_kept'] else 'no'} | {r['final']} | {r['cagr']:+.2%} ({r['cagr_tree']:+.2%}) | "
            f"{r['dd']:.2%} ({r['dd_tree']:.2%}) | {'MET' if goal else 'no'} | {r['folder']}")
    fw = forward_pick(H)
    say("FORWARD CANDIDATES (at most two, declared): " + (", ".join(f"{r['variant']} on {r['engine']} (p {r['p']:.4f})"
                                                                     for r in fw) if fw else "none"))
    out = a.out or os.environ.get("BRANCHLAB_OUT")
    if out:
        b = Path(out)
        b.mkdir(parents=True, exist_ok=True)
        with open(b / LEDGER, "a", encoding="utf-8") as f:
            f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION,
                                "event": "holm", "declaration_sha256": sha, "rows": H,
                                "forward": [(r["engine"], r["variant"]) for r in fw]}, default=str) + "\n")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="branchlab: the entry tree's open branches (BR1)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="the declaration and tradelab's strategies\\branchlab.py are the frozen ones")
    r = sub.add_parser("run", help="Stage 1: every variant's day on every tree pick, the audit, the descriptive trades")
    r.add_argument("--root")
    r.add_argument("--setups", default=None)
    r.add_argument("--data", default=None)
    r.add_argument("--features", default=None)
    r.add_argument("--pm-run", default=None)
    r.add_argument("--out", default=None)
    r.add_argument("--stage-e-any", action="store_true")
    h = sub.add_parser("holm", help="Stage 2: Holm across each engine's tl_backtest runs of strategies\\branchlab.py")
    h.add_argument("folders", nargs="*")
    h.add_argument("--scan", default=None)
    h.add_argument("--out", default=None)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            want = d["stage2_book"]["strategies_sha256"]
            if not STRAT_FILE.is_file():
                raise BRError(f"{STRAT_FILE} not found (tradelab add-on v1.7 beside branchlab)")
            have = sha256(STRAT_FILE)
            if have != want:
                raise BRError(f"{STRAT_FILE} has sha256 {have[:16]}, not the declared {want[:16]} - refusing")
            if SU.SETUPS_VERSION != "tl_setups v1.7":
                raise BRError(f"tradelab's tl_setups is {SU.SETUPS_VERSION}; branchlab needs tl_setups v1.7 (add-on v1.7)")
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['name']}, declared {d['declared']}): Stage 2 = "
                f"{len(variants_for('D'))} D + {len(variants_for('ENS'))} ENS backtests; strategies\\branchlab.py "
                f"sha256 {have[:16]} as declared; {SU.SETUPS_VERSION}")
            return 0
        if a.cmd == "holm":
            return cmd_holm(a)
        return cmd_run(a)
    except (BRError, TC.TLError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
