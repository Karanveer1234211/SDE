@echo off
rem env_branchlab.bat - branchlab v1.0 (the entry tree's open branches, study BR1): start a session.
rem   call C:\Users\karanvsi\PyCharmMiscProject\branchlab\env_branchlab.bat
rem Reads production (the daily cache and stage E's bar loader through tradelab's tl_data) and setuplab's runs READ ONLY.
rem Writes only under BRANCHLAB_OUT. Edit the paths below if your folders differ.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "SETUPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\setuplab"
set "SETUPLAB_OUT=C:\QuantData\setuplab"
set "BRANCHLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\branchlab"
set "BRANCHLAB_OUT=C:\QuantData\branchlab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_setups.py" goto :no_tradelab
if not exist "%SETUPLAB_DIR%\setuplab.py" goto :no_setuplab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%BRANCHLAB_DIR%;%TRADELAB_DIR%;%SETUPLAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%BRANCHLAB_OUT%" mkdir "%BRANCHLAB_OUT%"
cd /d "%BRANCHLAB_DIR%"
echo branchlab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   SETUPLAB_OUT=%SETUPLAB_OUT%   BRANCHLAB_OUT=%BRANCHLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_branchlab.bat
exit /b 1
:no_tradelab
echo ERROR: %TRADELAB_DIR%\tl_setups.py not found - branchlab needs tradelab add-on v1.7 (edit TRADELAB_DIR)
exit /b 1
:no_setuplab
echo ERROR: %SETUPLAB_DIR%\setuplab.py not found - branchlab rebuilds the frozen setups with setuplab (edit SETUPLAB_DIR)
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
