"""
tests/test_branchlab.py - branchlab v1.0 self-test (study BR1).

    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\branchlab
    python tests\\test_branchlab.py

Builds synthetic worlds with GENUINE setuplab TAGS and TREE runs (setuplab's own tag and tree commands), runs branchlab
on them with a stand-in bar reader, and checks every number against an independent per-pick oracle. Ends
'VERIFIED (branchlab v1.0)' when every check passes; exit code 1 otherwise.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import shutil
import sys
import tempfile
import types
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import branchlab as BL  # noqa: E402
import tl_setups as SU  # noqa: E402

SL = BL.setuplab()
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(("  ok   " if ok else "  FAIL ") + name + ("" if ok else f"   <- {detail}"), flush=True)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        out = fn(*a, **k)
    return out, buf.getvalue()


# ---------------------------------------------------------------------------------------------------- 1 declaration
def t1_declaration():
    d, sha = BL.load_decl()
    check("t1a declaration hash is the pinned one", sha == BL.DECL_SHA)
    sb = d["stage2_book"]
    check("t1b 23 D + 21 ENS runs, the variants tradelab knows",
          sb["runs"] == 44 and sb["engines"]["D"] == BL.variants_for("D") and len(sb["engines"]["D"]) == 23 and
          sb["engines"]["ENS"] == BL.variants_for("ENS") and len(sb["engines"]["ENS"]) == 21 and
          "E_OPEN" not in sb["engines"]["D"] and not any(v.startswith("K_") for v in sb["engines"]["ENS"]))
    check("t1c strategies\\branchlab.py is the declared file",
          hashlib.sha256(BL.STRAT_FILE.read_bytes()).hexdigest() == sb["strategies_sha256"])
    rc, out = quiet(BL.main, ["check"])
    check("t1d 'branchlab.py check' says OK", rc == 0 and "OK" in out, out[-300:])
    with tempfile.TemporaryDirectory() as t:
        p = Path(t) / "D.json"
        p.write_text(BL.DECL_FILE.read_text(encoding="utf-8").replace('"holm_alpha": 0.025', '"holm_alpha": 0.05'),
                     encoding="utf-8")
        try:
            BL.load_decl(p)
            check("t1e a changed declaration is refused", False)
        except BL.BRError:
            check("t1e a changed declaration is refused", True)
    import runpy
    S = runpy.run_path(str(BL.STRAT_FILE))["STRATEGIES"]
    e = S["E_OPEN"]["entries"][0]
    check("t1f every variant is the frozen tree + one also_day; E_OPEN replaces where br_E_OPEN == 1",
          tuple(S) == SU.BR_VARIANTS and all(S[v]["entries"][0]["also_day"] == f"br_{v}_day" for v in S) and
          e["also_mode"] == "replace" and e["also_if"] == "br_E_OPEN == 1" and e["also_exit"] == "br_E_OPEN_exit"
          and all(S[v]["entries"][0]["also_mode"] == "first" and S[v]["entries"][0]["also_exit"] == 5
                  for v in S if v != "E_OPEN"))


# ---------------------------------------------------------------------------------------------------- 2 weekly state
def t2_weekly():
    d = pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05",      # week 1
                        "2024-01-08", "2024-01-09", "2024-01-10", "2024-01-11", "2024-01-12",      # week 2: -2 posted
                        "2024-01-16", "2024-01-17", "2024-01-18", "2024-01-19",                    # Mon holiday; 0 posted;
                        "2024-01-22", "2024-01-23", "2024-01-24"])                                 # Thu -1 midweek
    w = [10, 10, 10, 10, 10, 8, 8 + 1e-12, 8 + 1e-12, 8 + 1e-12, 8 + 1e-12, 8, 8, 7, 7, 7.5, np.nan, 7.5]
    F = pd.DataFrame({"symbol": "A", "date": d, "w": w})
    F2 = pd.DataFrame({"symbol": "B", "date": pd.to_datetime(["2024-01-10", "2024-01-11", "2024-01-15"]),
                       "w": [5.0, 5.0, 4.0]})
    F = pd.concat([F, F2], ignore_index=True)
    F["chg"] = F.groupby("symbol")["w"].diff()
    X = BL.weekly_states(F)
    N = np.nan
    exp = {  # row: (L0, L1, L2, P)
        0: (N, N, N, N), 1: (0, N, N, N), 2: (0, 0, N, N), 3: (0, 0, 0, N), 4: (0, 0, 0, N),
        5: (-2, -2, -2, -2), 6: (0, -2, -2, -2), 7: (0, 0, -2, -2), 8: (0, 0, 0, -2), 9: (0, 0, 0, -2),
        10: (0, 0, 0, 0), 11: (0, 0, 0, 0), 12: (-1, -1, -1, -1), 13: (0, -1, -1, -1),
        14: (0.5, 0.5, 0.5, 0.5), 15: (N, N, N, N), 16: (N, N, N, N),
        17: (N, N, N, N), 18: (0, N, N, N), 19: (-1, -1, -1, -1)}
    bad = []
    for r, e in exp.items():
        got = tuple(X.loc[r, s_] for s_ in BL.STATES)
        if not all((np.isnan(a) and np.isnan(b)) or abs(a - b) < 1e-9 for a, b in zip(got, e)):
            bad.append((r, got, e))
    check("t2a states by hand: posting rows (week's first row / any change), ages 0-2, held, a zero week resets, a "
          "midweek change posts, float noise (1e-12) neither posts nor ends the week, missing stays missing, stocks never "
          "mix", not bad, bad[:3])
    check("t2b L0 = the frozen one-day change wherever it is known (to float noise)",
          np.allclose(X["L0"].to_numpy(float)[np.isfinite(X["chg"])], X["chg"].to_numpy(float)[np.isfinite(X["chg"])],
                      rtol=0, atol=1e-9))
    with tempfile.TemporaryDirectory() as t:
        P = pd.DataFrame({"symbol": ["A", "A", "A"], "timestamp": pd.to_datetime(
            ["2024-01-01 09:15", "2024-01-02 09:15", "2024-01-03 09:15"]).tz_localize("Asia/Kolkata"),
                          "w_ret_13w": [1.0, 2.0, 2.0], "w_ret_13w_change": [np.nan, 7.0, 0.0]})
        P.to_parquet(Path(t) / "p.parquet", index=False)
        R = BL.read_weekly(Path(t) / "p.parquet", ["A"], "2023-12-01")
        check("t2c the panel's own w_ret_13w_change is used when present; zoned times -> IST dates",
              list(R["chg"].fillna(-99)) == [-99, 7.0, 0.0] and list(R["date"].dt.day) == [1, 2, 3] and
              set(R["symbol"]) == {"A"}, R.to_dict("list"))


# ---------------------------------------------------------------------------------------------------- 3 price levels
def t3_levels():
    N = np.nan
    H = np.full((10, 6), N)
    L = np.full((10, 6), N)
    C = np.full((10, 6), N)

    def row(i, h, lo, c):
        H[i, 1:], L[i, 1:], C[i, 1:] = h, lo, c
    row(0, [100, 99.5, 101.5, 100.8, 101], [95, 97, 99, 99.5, 99], [98, 99, 101, 100.5, 100])
    row(1, [100, 101.5, 102.5, 103, 103], [95, 98, 100, 101, 101], [98, 101, 102, 102, 102])
    row(2, [100, 101.2, 103.5, 101, 101], [95, 99, 101.5, 100, 100], [98, 101, 103, 100, 100])
    row(3, [100, 97, 97, 97, 97], [95, 94, 95.5, 95.5, 95.5], [98, 96, 96, 96, 96])
    row(4, [100, 96, 97, 97, 97], [95, 93, 95.5, 95.5, 95.5], [98, 94, 96, 96, 96])
    row(5, [100, 99, N, 102, 102], [95, 97, N, 99, 99], [98, 98, N, 101.5, 101.5])
    row(6, [N, 99, 102, 102, 102], [95, 97, 99, 99, 99], [98, 98, 101, 101, 101])
    row(7, [100, 99, 99, 101.5, 101], [95, 97, 97, 99, 99], [98, 98, 98, 101, 101])
    row(8, [100, 100.5, 99, 99, 99], [95, 97, 97, 97, 97], [98, 100, 98, 98, 98])
    row(9, [100, 98, 98, 98, 98], [95, 95, 95, 95, 95], [98, 97, 97, 97, 97])
    D = BL.price_days(H, L, C)
    exp = {"B_BRK": [4, 3, 3, 0, 0, 0, 0, 5, 0, 0], "B_RET": [5, 4, 0, 0, 0, 0, 0, 0, 0, 0],
           "B_RCL": [0, 0, 0, 3, 4, 0, 0, 0, 0, 0]}
    bad = {k: (list(D[k]), v) for k, v in exp.items() if list(D[k]) != v}
    check("t3a breakout / retest / reclaim by hand (strict levels, the retest after the breakout session, a missing bar "
          "ends the search, D1 missing = nothing)", not bad, bad)
    H2, L2, C2 = H.copy(), L.copy(), C.copy()
    H2[:, 5], L2[:, 5], C2[:, 5] = 1e6, -1e6, 1e6            # D5's bar can never matter
    H2[1, 4], L2[1, 4], C2[1, 4] = 1, 1, 1                   # nor a bar after pick 1's patterns completed
    D2 = BL.price_days(H2, L2, C2)
    check("t3b no look-ahead: bars after the deciding close change nothing",
          all(list(D2[k]) == list(D[k]) for k in D))


# ---------------------------------------------------------------------------------------------------- 4 calm, ENS
def t4_calm_ens():
    N = np.nan
    O = np.full((5, 11), N)
    O[:, 1:6] = [[101, 99, 99, 99, 99], [97, 98, 100.5, 101, 99], [97, N, 101, 101, 101], [101, 101, 101, 101, 101],
                 [97, 101, 101, 101, 101]]
    bk = types.SimpleNamespace(n=5, O=O, sc=np.full(5, 100.0))
    calm = np.array([True, True, True, False, True])
    up = np.array([1, 0, 0, 1, -1])
    K = BL.calm_days(bk, calm, up)
    check("t4a calm by hand: SLOT = D1 for an up-open calm pick, LATE = the first later open at or above the close (a "
          "missing open ends it), unknown open = nothing, BOTH = either",
          list(K["K_SLOT"]) == [1, 0, 0, 0, 0] and list(K["K_LATE"]) == [0, 3, 0, 0, 0] and
          list(K["K_BOTH"]) == [1, 3, 0, 0, 0])
    tags = pd.DataFrame({"trade_id": ["a", "b", "c"], "su_S1_day": [N, 4, N], "su_S2_day": [3, N, N],
                         "su_C3_day": [N, 4, N], "su_N1_day": [2, N, N]})
    d, x = BL.e_open_plan(tags, np.array(["a", "b", "c", "zz"]), {"S1": "original_d5", "S2": "original_d5",
                                                                 "C3": "original_d5", "N1": "fresh"})
    check("t4b E_OPEN plan by hand: the first frozen setup (tie order), N1 sells 4 sessions after its entry",
          list(d) == [2, 4, 0, 0] and list(x) == [6, 5, 0, 0], (list(d), list(x)))
    b, w = BL.earliest({"C1": np.array([3, 0]), "S3": np.array([3, 2]), "N1": np.array([1, 0])}, order=BL.SIX)
    check("t4c earliest: the earliest day, ties by setuplab's order, N1 outside the six",
          list(b) == [3, 2] and list(w) == ["S3", "S3"])


# ---------------------------------------------------------------------------------------------------- the world
FEATS = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_bb_bw_20", "d_wq_44",
         "d_bb_pctb_20", "d_atr_pct"]


def make_world(root: Path, seed=5):
    """Calendar with Monday holidays, 40 stocks + GOLDBEES (an ETF), daily bars, a panel (weekly w_ret_13w posted on
    the week's first row, a few midweek changes), D and ENS picks ranks 1-3 every session with their paths."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-07-01", "2023-11-30")
    cal = cal[~((cal.weekday == 0) & (cal.day <= 7) & np.isin(cal.month, [1, 4, 7, 10]))]
    syms = [f"S{i:03d}" for i in range(40)] + ["GOLDBEES"]
    n = len(cal)
    bars, rows = {}, []
    iso = cal.isocalendar()
    wk = (iso["year"].astype(int) * 100 + iso["week"].astype(int)).to_numpy()
    wfirst = np.r_[True, wk[1:] != wk[:-1]]
    for s in syms:
        c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
        o = np.r_[c[0], c[:-1]] * np.exp(rng.normal(0, 0.008, n))
        hi = np.maximum(o, c) * np.exp(np.abs(rng.normal(0, 0.008, n)))
        lo = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, 0.008, n)))
        bars[s] = (np.asarray(cal).astype("datetime64[D]"), o, hi, lo, c, np.full(n, 1e5))
        w = np.cumsum(np.where(wfirst, rng.normal(0, 1, n), 0.0))
        mid = (~wfirst) & (rng.random(n) < 0.01)
        w = w + np.cumsum(np.where(mid, rng.normal(0, 0.5, n), 0.0))
        f = {"symbol": s, "timestamp": cal, "w_ret_13w": w}
        for x in FEATS:
            f[x] = np.cumsum(rng.normal(0, 1, n)) if x != "d_atr_pct" else np.abs(rng.normal(3, 1, n))
        f["d_bb_pctb_20"] = rng.normal(0.4, 0.5, n)
        rows.append(pd.DataFrame(f))
    panel = pd.concat(rows, ignore_index=True)
    (root / "panel").mkdir(parents=True, exist_ok=True)
    panel.to_parquet(root / "panel" / "panel.parquet", index=False)
    picks = []
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-02")))
    for t in range(t0, n - 12):
        for eng in ("D", "ENS"):
            ch = rng.choice(len(syms), 3, replace=False)
            for r, si in enumerate(ch, 1):
                s = syms[si]
                _, o, hi, lo, c, _ = bars[s]
                ent = o[t + 1]
                rec = {"trade_id": f"{eng}-{cal[t]:%Y%m%d}-{r}", "engine": eng, "rank": r, "symbol": s,
                       "signal_day": cal[t], "entry_day": cal[t + 1], "entry": ent, "signal_close": c[t],
                       "status": "ok", "net_bp": (c[t + 5] / ent - 1) * 1e4 - 35,
                       "s_atr14": float(np.exp(rng.normal(np.log(0.05), 0.35))) if s != "GOLDBEES" else 0.01,
                       "pre_state": ""}
                for k in range(1, 11):
                    rec[f"close_{k}"] = c[t + k] / ent - 1
                for k in range(2, 11):
                    rec[f"overnight_{k}"] = o[t + k] / c[t + k - 1] - 1
                picks.append(rec)
    WL = pd.DataFrame(picks)
    return {"cal": cal, "bars": bars, "panel": panel, "wl": WL, "root": root}


def write_wl(W, folder: Path, wl=None):
    folder.mkdir(parents=True, exist_ok=True)
    (wl if wl is not None else W["wl"]).to_parquet(folder / "watchlist.parquet", index=False)
    pd.DataFrame({"date": W["cal"]}).to_parquet(folder / "calendar.parquet", index=False)


def tree_doc(folder: Path) -> Path:
    tp, d = SL.load_tree()
    d = json.loads(json.dumps(d))
    d.pop("sha256", None)
    d["lane"]["cutoffs"] = {str(y): 0.057 for y in range(2020, 2024)}
    d.pop("history_reference", None)
    d["sha256"] = SL.frozen_hash(d)
    p = folder / "TREE_test.json"
    p.write_text(json.dumps(d), encoding="utf-8")
    return p


def setuplab_runs(W, wl_dir: Path, out: Path, tdoc: Path):
    rc1, log1 = quiet(SL.main, ["tag", "--data", str(wl_dir), "--features", str(W["root"] / "panel" / "panel.parquet"),
                                "--out", str(out)])
    rc2, log2 = quiet(SL.main, ["tree", "--data", str(wl_dir), "--out", str(out), "--tree", str(tdoc), "--reruns", "2"])
    return rc1, rc2, log1 + log2


def fake_ohlcv(W):
    def f(symbols):
        return {s: W["bars"][s] for s in symbols if s in W["bars"]}
    return f


# ---------------------------------------------------------------------------------------------------- the oracle
def oracle(W, wl: pd.DataFrame, tags: pd.DataFrame, tree: pd.DataFrame, conds: dict, primary: dict) -> dict:
    """An independent per-pick, per-day re-implementation of every variant (plain Python loops over dates)."""
    cal = pd.DatetimeIndex(W["cal"])
    pos = {d: i for i, d in enumerate(cal)}
    P = W["panel"].sort_values(["symbol", "timestamp"])
    per = {}
    for s, g in P.groupby("symbol"):
        dates = pd.DatetimeIndex(g["timestamp"]).normalize()
        isow = dates.isocalendar()
        per[s] = {"idx": {d: i for i, d in enumerate(dates)}, "wk": (isow["year"] * 100 + isow["week"]).to_numpy(),
                  **{c: g[c].to_numpy(float) for c in ["w_ret_13w"] + FEATS}}

    def change(st, col, r):
        return st[col][r] - st[col][r - 1] if r >= 1 else np.nan

    def wstate(st, r, kind):
        ch = change(st, "w_ret_13w", r)
        if not np.isfinite(ch):
            return np.nan
        q = r
        while q > 0 and not (st["wk"][q] != st["wk"][q - 1] or (np.isfinite(change(st, "w_ret_13w", q)) and
                                                                round(change(st, "w_ret_13w", q), 9) != 0)):
            q -= 1
        posted, age = change(st, "w_ret_13w", q), r - q
        lim = {"L0": 0, "L1": 1, "L2": 2, "P": 10 ** 9}[kind]
        return posted if age <= lim else 0.0

    ops = {">": lambda a, b: a > b, "<": lambda a, b: a < b}
    TR = tree.set_index("trade_id")
    TG = tags.set_index("trade_id")
    out = {}
    for rec in wl[wl["rank"] <= 3].itertuples(index=False):
        tid = rec.trade_id
        if tid not in TR.index:
            continue
        tr = TR.loc[tid]
        st = per[rec.symbol]
        i1 = pos[pd.Timestamp(rec.entry_day)]
        ent = rec.entry
        Cc = {k: ent * (1 + getattr(rec, f"close_{k}")) for k in range(1, 11)}
        Oo = {1: ent}
        for k in range(2, 11):
            Oo[k] = Cc[k - 1] * (1 + getattr(rec, f"overnight_{k}"))
        PC = {1: rec.signal_close, **{k: Cc[k - 1] for k in range(2, 11)}}
        routed = bool(tr["action"]) and not bool(tr["etf"]) and tr["lane"] != "NO CUT-OFF" and \
            rec.status == "ok" and np.isfinite(rec.net_bp)
        jumpy = routed and tr["lane"] in ("JUMPY", "NO ATR")
        calm = routed and tr["lane"] == "CALM"

        def val(fld, k, wkind):
            if i1 + k - 2 < 0:
                return np.nan
            d = cal[i1 + k - 2]
            r = st["idx"].get(d)
            if fld == "pc_vs_d1":
                return 0.0 if k == 1 else (Cc[k - 1] / Oo[1] - 1) * 100
            if fld == "pc_vs_d1_atr":
                return 0.0 if k == 1 else (Cc[k - 1] / Oo[1] - 1) / rec.s_atr14
            if fld == "gap_pct":
                return (Oo[k] / PC[k] - 1) * 100
            if r is None:
                return np.nan
            if fld == BL.WEEKLY:
                return wstate(st, r, wkind)
            if fld.endswith("_change"):
                return change(st, fld[:-7], r)
            return st[fld][r]

        def first(cc, wkind):
            for k in range(1, 6):
                anyF, anyN = False, False
                for fld, op, v in cc:
                    a = val(fld, k, wkind)
                    if not np.isfinite(a):
                        anyN = True
                    elif not ops[op](round(a, 9), round(float(v), 9)):
                        anyF = True
                if anyF:
                    continue
                return k if not anyN else 0
            return 0
        o = {"routed": routed, "jumpy": jumpy, "calm": calm}
        drop = lambda cc: [c for c in cc if c[0] != BL.WEEKLY]  # noqa: E731
        for s_ in BL.SIX:
            o[f"F_{s_}"] = first(conds[s_], "L0")
            o[f"P_{s_}"] = first(conds[s_], "P") if jumpy else 0
            o[f"N_{s_}"] = first(drop(conds[s_]), None) if jumpy else 0
        for nm, kind in (("P_ALL1", "L1"), ("P_ALL2", "L2")):
            ds = [first(conds[s_], kind) for s_ in BL.SIX] if jumpy else [0]
            o[nm] = min([d for d in ds if d > 0], default=0)
        o["P_ALL"] = min([o[f"P_{s_}"] for s_ in BL.SIX if o[f"P_{s_}"] > 0], default=0)
        o["N_ALL"] = min([o[f"N_{s_}"] for s_ in BL.SIX if o[f"N_{s_}"] > 0], default=0)
        # price levels from the stock's bars on the watch days' dates
        bd, bo, bh, bl, bc, _ = W["bars"][rec.symbol]
        bi = {pd.Timestamp(x): j for j, x in enumerate(bd)}
        hh, ll, cc_ = {}, {}, {}
        for k in range(1, 6):
            j = bi.get(cal[i1 + k - 1]) if i1 + k - 1 < len(cal) else None
            hh[k], ll[k], cc_[k] = (bh[j], bl[j], bc[j]) if j is not None else (np.nan,) * 3
        brk = ret = rcl = 0
        broke = False
        for s in range(2, 5):
            if jumpy:
                if not brk and cc_[s] > hh[1]:
                    brk = s + 1
                if not ret and broke and ll[s] <= hh[1] and cc_[s] > hh[1]:
                    ret = s + 1
                if not rcl and ((ll[s] < ll[1] and cc_[s] > ll[1]) or (s >= 3 and cc_[s - 1] < ll[1] and cc_[s] > ll[1])):
                    rcl = s + 1
                broke = broke or cc_[s] > hh[1]
        o.update({"B_BRK": brk, "B_RET": ret, "B_RCL": rcl, "X_D2": 2 if jumpy else 0})
        up = None if pd.isna(tr["opened_up"]) else bool(tr["opened_up"])
        slot = 1 if (calm and rec.engine == "D" and up is True) else 0
        late = 0
        if calm and rec.engine == "D" and up is False:
            for k in range(2, 6):
                if Oo[k] >= rec.signal_close:
                    late = k
                    break
        o.update({"K_SLOT": slot, "K_LATE": late, "K_BOTH": slot or late})
        ef = calm and rec.engine == "ENS" and up is False
        best, who = 0, ""
        for s_ in BL.ORDER:
            v = TG.loc[tid, f"su_{s_}_day"] if tid in TG.index else np.nan
            if np.isfinite(v) and v > 0 and (best == 0 or v < best):
                best, who = int(v), s_
        o.update({"E_flag": ef, "E_OPEN": best if ef else 0,
                  "E_exit": (best + 4 if primary.get(who) == "fresh" else 5) if ef and best else 0})
        h = str(tr["how"])
        o["tree_day"] = 1 if h == "open" else (int(h.split("@D")[1]) if "@D" in h else 0)
        out[tid] = o
    return out


# ---------------------------------------------------------------------------------------------------- 5-7 the world
def t5_to_7():
    tmp = Path(tempfile.mkdtemp(prefix="branchlab_test_"))
    try:
        W = make_world(tmp)
        wl_dir, outA = tmp / "WL", tmp / "setuplab_A"
        write_wl(W, wl_dir)
        tdoc = tree_doc(tmp)
        rc1, rc2, log = setuplab_runs(W, wl_dir, outA, tdoc)
        check("t5a setuplab's own tag and tree commands ran on the world", rc1 == 0 and rc2 in (0, 1), log[-500:])
        tree, trinfo, tags, tinfo, data_dir, panel = BL.resolve(outA, None, None)
        check("t5b resolve: the newest hash-checked TREE and TAGS runs and the watchlist / panel the tags used",
              data_dir == wl_dir and panel == W["root"] / "panel" / "panel.parquet" and trinfo["used"] and tinfo["used"])
        d, sha = BL.load_decl()
        bout = tmp / "branchlab_out"
        bout.mkdir()
        (rc, run), log = quiet(BL.execute, d, sha, tree, trinfo, tags, tinfo, data_dir, panel, "PM_X", bout,
                               fake_ohlcv(W), lambda s: None)
        check("t5c Stage 1 ran and RECONCILED", rc == 0 and "RECONCILED" in (run / "REPORT.md").read_text(
            encoding="utf-8"), log[-600:])
        B = pd.read_parquet(run / SU.BR_FILE).set_index("trade_id")
        fp, fdoc = SL.load_frozen()
        conds = SL.frozen_conds(fdoc)
        O = oracle(W, W["wl"], tags, tree, conds, tinfo["primary_exit"])
        common = [t for t in O if t in B.index]
        check("t5d br_scores covers every tree pick of ranks 1-3 once",
              len(common) == len(O) and B.index.is_unique and len(B) == int((W["wl"]["rank"] <= 3).sum()))
        bad = {}
        for v in SU.BR_VARIANTS:
            got = B.loc[common, f"br_{v}_day"].fillna(0).astype(int).to_numpy()
            exp = np.array([O[t][v] for t in common])
            if v in BL.D_ONLY:
                exp = np.where([t.startswith("D-") for t in common], exp, 0)
            if not np.array_equal(got, exp):
                i = np.flatnonzero(got != exp)
                bad[v] = (len(i), [(common[j], int(got[j]), int(exp[j])) for j in i[:3]])
        check("t5e every variant's day = the independent oracle on every pick (24 variants, D and ENS)", not bad, bad)
        ex = B.loc[common, "br_E_OPEN_exit"].fillna(0).astype(int).to_numpy()
        check("t5f E_OPEN's flag and exit = the oracle (N1: 4 sessions after its entry)",
              np.array_equal(ex, [O[t]["E_exit"] for t in common]) and
              np.array_equal(B.loc[common, "br_E_OPEN"].fillna(0).to_numpy(float), [float(O[t]["E_flag"]) for t in common]))
        jm = np.array([O[t]["jumpy"] for t in common])
        cm = np.array([O[t]["calm"] for t in common])
        etf = tree.set_index("trade_id").loc[common, "etf"].astype(bool).to_numpy()
        J = [f"br_{v}_day" for v in SU.BR_VARIANTS if v[:2] in ("P_", "N_", "B_", "X_")]
        K = [f"br_{v}_day" for v in BL.D_ONLY]
        check("t5g eligibility: jumpy days only on jumpy routed picks, calm days only on calm D picks, never an ETF",
              B.loc[common, J].notna().any(axis=1).to_numpy()[~jm].sum() == 0 and
              B.loc[common, K].notna().any(axis=1).to_numpy()[~cm].sum() == 0 and
              B.loc[common, J + K + ["br_E_OPEN_day"]].notna().any(axis=1).to_numpy()[etf].sum() == 0 and
              (B.loc[common, "br_jumpy"].to_numpy(float)[jm] == 1).all() and jm.sum() > 500 and cm.sum() > 500)
        sup = all(O[t][f"P_{s_}"] <= O[t][f"F_{s_}"] or O[t][f"F_{s_}"] == 0 for t in common for s_ in BL.SIX
                  if O[t]["jumpy"]) and all(O[t]["P_ALL"] > 0 for t in common if O[t]["jumpy"] and
                                            any(O[t][f"F_{s_}"] > 0 for s_ in BL.SIX))
        later = sum(1 for t in common if O[t]["jumpy"] and O[t]["P_ALL"] > 0 and
                    not any(O[t][f"F_{s_}"] == O[t]["P_ALL"] for s_ in BL.SIX))
        check("t5h the held week contains the frozen pulse (never later than the frozen setup) and adds days", sup and
              later > 50, later)
        cov = pd.read_csv(run / "coverage.csv")
        r_ = cov[(cov.engine == "D") & (cov.variant == "P_ALL")].iloc[0]
        ch = sum(1 for t in common if t.startswith("D-") and O[t]["P_ALL"] > 0 and
                 (O[t]["tree_day"] == 0 or O[t]["P_ALL"] < O[t]["tree_day"]))
        check("t5i coverage counts = the oracle (D P_ALL: picks the tree skips + buys later)",
              int(r_.tree_skips + r_.before_tree) == ch and int(r_.with_day) == sum(
                  1 for t in common if t.startswith("D-") and O[t]["P_ALL"] > 0), (dict(r_), ch))
        aud = pd.read_csv(run / "blocking.csv")
        fam = aud[(aud.engine == "D") & (aud.setup == "family")]
        skip = sum(1 for t in common if t.startswith("D-") and O[t]["jumpy"] and O[t]["tree_day"] == 0)
        r1 = sum(1 for t in common if t.startswith("D-") and O[t]["jumpy"] and O[t]["tree_day"] == 0 and
                 O[t]["P_ALL"] > 0)
        check("t5j the blocking count adds up to the skipped jumpy picks, and R1 covers every skipped pick the held "
              "week buys", int(fam.picks.sum()) == skip and int(fam[fam.reason == "R1"].picks.iloc[0]) >= r1,
              (int(fam.picks.sum()), skip, fam.to_dict("records"), r1))
        # ---- 6 the run folder and tradelab
        txt = (run / "stage2_commands.txt").read_bytes()
        bat = (run / "run_stage2.bat").read_bytes()
        lines = [x for x in txt.decode().split("\r\n") if x]
        labels = [x for x in bat.decode().split("\r\n") if x.startswith(":")]
        check("t6a 44 Stage 2 commands (D 23, ENS 21), CRLF, each with --branchlab and --compare strategies\\tree.py",
              len(lines) == 44 and b"\n" not in txt.replace(b"\r\n", b"") and
              sum(" --engines D " in x for x in lines) == 23 and sum(" --engines ENS " in x for x in lines) == 21 and
              all("--branchlab" in x and "--compare strategies\\tree.py" in x for x in lines) and
              not any("#E_OPEN" in x and "--engines D " in x for x in lines) and
              not any("#K_" in x and "--engines ENS " in x for x in lines))
        check("t6b run_stage2.bat: CRLF, unique labels, every command then Holm",
              b"\n" not in bat.replace(b"\r\n", b"") and len(labels) == len(set(labels)) and
              bat.decode().count("tl_backtest.py") == 44 and "branchlab.py holm --scan" in bat.decode())
        hs = dict(x.split("  ", 1)[::-1] for x in (run / "outputs.sha256").read_text().splitlines() if x.strip())
        allok = all(hashlib.sha256((run / k).read_bytes()).hexdigest() == v for k, v in hs.items())
        check("t6c outputs.sha256 covers every file and matches", allok and set(hs) == {
            "REPORT.md", SU.BR_FILE, "coverage.csv", "blocking.csv", "trades_desc.csv", "stage2_commands.txt",
            "run_stage2.bat", "DECLARATION.json", "run.json"}, sorted(hs))
        rj = json.loads((run / "run.json").read_text())
        Bt, binfo = SU.load_br(str(run))
        Tq = pd.DataFrame({"trade_id": common[:50], "calm": [1.0 if O[t]["calm"] else 0.0 for t in common[:50]]})
        X, _ = SU.add_br(Tq, Bt, binfo, trinfo)
        check("t6d tradelab reads it: hash-checked, tied to the tree run, days on the picks",
              rj["tree_run_sha256"] == trinfo["sha256"] and binfo["tree_sha256"] == trinfo["sha256"] and
              np.array_equal(X["br_P_ALL_day"].fillna(0).to_numpy(), B.loc[common[:50], "br_P_ALL_day"].fillna(0)))
        try:
            SU.add_br(Tq, Bt, binfo, dict(trinfo, sha256="f" * 64, run="TREE_other"))
            check("t6e a branchlab run built from another tree run is refused by tradelab", False)
        except Exception as e:
            check("t6e a branchlab run built from another tree run is refused by tradelab", "rebuild" in str(e))
        bb = (run / SU.BR_FILE).read_bytes()
        (run / SU.BR_FILE).write_bytes(bb + b"\0")
        try:
            SU.load_br(str(run))
            check("t6f a tampered br_scores.parquet is refused", False)
        except Exception as e:
            check("t6f a tampered br_scores.parquet is refused", "does not match" in str(e), str(e))
        (run / SU.BR_FILE).write_bytes(bb)
        # DIFFERS: a TAGS run that disagrees with the rebuilt setups
        tg2 = tags.copy()
        i = int(np.flatnonzero(tg2["su_S2_day"].notna().to_numpy())[0])
        tg2.loc[i, "su_S2_day"] = 5 if tg2.loc[i, "su_S2_day"] != 5 else 4
        (rc3, run3), _ = quiet(BL.execute, d, sha, tree, trinfo, tg2, tinfo, data_dir, panel, "PM_X", bout,
                               fake_ohlcv(W), lambda s: None)
        check("t6g a TAGS run that differs -> DIFFERS, exit 3, no br_scores.parquet",
              rc3 == 3 and not (run3 / SU.BR_FILE).exists() and "DIFFERS" in (run3 / "REPORT.md").read_text())
        # ---- 7 planted vs absent (descriptive chain)
        D0 = pd.read_csv(run / "trades_desc.csv")
        a0 = D0[(D0.engine == "D") & (D0.variant == "P_ALL")].iloc[0]
        plant = 0.06
        wl1 = W["wl"].copy()
        idx = {t: i for i, t in enumerate(wl1["trade_id"])}
        n_pl = 0
        for t in common:
            o = O[t]
            if o["jumpy"] and o["P_ALL"] > 0 and (o["tree_day"] == 0 or o["P_ALL"] < o["tree_day"]):
                k, i = o["P_ALL"], idx[t]
                for j in range(k, 11):
                    wl1.loc[i, f"close_{j}"] = (1 + wl1.loc[i, f"close_{j}"]) * (1 + plant) - 1
                n_pl += 1
        wl1_dir, outB = tmp / "WL1", tmp / "setuplab_B"
        write_wl(W, wl1_dir, wl1)
        rc1, rc2, log = setuplab_runs(W, wl1_dir, outB, tdoc)
        tree1, trinfo1, tags1, tinfo1, dd1, pp1 = BL.resolve(outB, None, None)
        (rc4, run4), _ = quiet(BL.execute, d, sha, tree1, trinfo1, tags1, tinfo1, dd1, pp1, "PM_X", bout,
                               fake_ohlcv(W), lambda s: None)
        D1 = pd.read_csv(run4 / "trades_desc.csv")
        a1 = D1[(D1.engine == "D") & (D1.variant == "P_ALL")].iloc[0]
        check(f"t7a planted world (+6% after the held-week entry on {n_pl:,} picks): the changed picks' difference "
              f"rises by about +6 pp and its interval is above 0", rc4 == 0 and a1.diff_lo > 0 and
              5.0 < a1.changed_diff_pct - a0.changed_diff_pct < 7.0, (a0.changed_diff_pct, a1.changed_diff_pct,
                                                                       a1.diff_lo))
        check("t7b absent world: no gain found (the interval's lower end is not above 0)", a0.diff_lo <= 0,
              (a0.changed_diff_pct, a0.diff_lo, a0.diff_hi))
        x0 = D0[(D0.engine == "D") & (D0.variant == "X_D2")].iloc[0]
        check("t7c the X_D2 control on a random walk: no gain", x0.diff_lo <= 0, dict(x0))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------------------------------------------- 8 Holm
def t8_holm():
    rows = [{"engine": "D", "variant": "P_ALL", "p": 0.0005, "rule_verdict": "PASS"},
            {"engine": "D", "variant": "K_SLOT", "p": 0.0011, "rule_verdict": "PASS"},
            {"engine": "D", "variant": "B_BRK", "p": 0.0010, "rule_verdict": "FAIL"},
            {"engine": "D", "variant": "X_D2", "p": 0.2, "rule_verdict": "FAIL"},
            {"engine": "ENS", "variant": "E_OPEN", "p": 0.004, "rule_verdict": "PASS"},
            {"engine": "ENS", "variant": "P_S1", "p": 0.02, "rule_verdict": "PASS"}]
    H = {(r["engine"], r["variant"]): r for r in BL.holm(rows)}
    ok = (H[("D", "P_ALL")]["holm_limit"] == 0.025 / 4 and H[("D", "P_ALL")]["final"] == "PASS" and
          H[("D", "B_BRK")]["holm_limit"] == 0.025 / 3 and H[("D", "B_BRK")]["holm_kept"] and
          H[("D", "B_BRK")]["final"] == "FAIL" and H[("D", "K_SLOT")]["holm_limit"] == 0.025 / 2 and
          H[("D", "K_SLOT")]["final"] == "PASS" and not H[("D", "X_D2")]["holm_kept"] and
          H[("ENS", "E_OPEN")]["final"] == "PASS" and H[("ENS", "P_S1")]["final"] == "PASS")
    check("t8a Holm by hand: step-down per engine, a kept FAIL rule stays FAIL, families separate", ok, H)
    fw = BL.forward_pick(list(H.values()))
    check("t8b at most two forward candidates: the smallest p among FINAL PASS",
          [(r["engine"], r["variant"]) for r in fw] == [("D", "P_ALL"), ("D", "K_SLOT")])
    rows2 = [dict(r, p=0.001) for r in rows if r["rule_verdict"] == "PASS"]
    fw2 = BL.forward_pick(BL.holm(rows2))
    check("t8c ties: D before ENS, then the declared order", [(r["engine"], r["variant"]) for r in fw2] ==
          [("D", "P_ALL"), ("D", "K_SLOT")])
    with tempfile.TemporaryDirectory() as t:
        sha = hashlib.sha256(BL.STRAT_FILE.read_bytes()).hexdigest()

        def tlb(name, eng, var, p, verdict="PASS", compare="tree", used=True, strat=None, br="BR_1"):
            f = Path(t) / name
            f.mkdir()
            (f / "strategy_branchlab.py").write_bytes(strat if strat is not None else BL.STRAT_FILE.read_bytes())
            (f / "summary.json").write_text(json.dumps({
                "strategy": {"name": f"branchlab_{var}", "variant": var, "picks": {"engines": [eng]}},
                "compare": {"name": compare}, "branchlab": {"used": used, "run": br},
                "decision": {"verdict": verdict, "p_one_sided": p, "cagr": [0.9, 0.8], "max_drawdown": [-0.2, -0.3]}}))
            return f
        a = tlb("TLB_1", "D", "P_ALL", 0.001)
        b = tlb("TLB_2", "ENS", "E_OPEN", 0.3)
        c = tlb("TLB_3", "D", "P_ALL", 0.001)
        ok = []
        for fl, why in (([a, c], "twice"), ([tlb("TLB_4", "ENS", "K_SLOT", 0.1)], "not declared"),
                        ([tlb("TLB_5", "D", "P_S1", 0.1, compare="plan")], "frozen tree"),
                        ([tlb("TLB_6", "D", "P_S2", 0.1, strat=b"x = 1\n")], "not the declared"),
                        ([tlb("TLB_7", "D", "P_S3", 0.1, used=False)], "without --branchlab"),
                        ([a, tlb("TLB_8", "D", "P_C1", 0.1, br="BR_2")], "different branchlab runs")):
            try:
                quiet(BL.cmd_holm, types.SimpleNamespace(folders=[str(x) for x in fl], scan=None, out=None))
                ok.append((why, "accepted"))
            except BL.BRError as e:
                if why not in str(e):
                    ok.append((why, str(e)))
        check("t8d guards: a run twice, an undeclared engine, another compare, another strategy file, no --branchlab, "
              "two Stage 1 runs", not ok, ok)
        rc, out = quiet(BL.cmd_holm, types.SimpleNamespace(folders=[str(a), str(b)], scan=None, out=str(Path(t) / "o")))
        led = (Path(t) / "o" / BL.LEDGER).read_text().splitlines()
        check("t8e holm prints FINAL verdicts, the goal check and forward candidates, and logs to the ledger",
              rc == 0 and "FORWARD CANDIDATES" in out and "incomplete" in out and len(led) == 1 and
              json.loads(led[0])["event"] == "holm", out[-400:])


def main():
    print(f"{BL.VERSION} self-test")
    for t in (t1_declaration, t2_weekly, t3_levels, t4_calm_ens, t5_to_7, t8_holm):
        print(f"- {t.__name__}")
        try:
            t()
        except Exception as e:  # a crash is a failure, with its trace
            import traceback
            traceback.print_exc()
            check(f"{t.__name__} ran without an error", False, repr(e))
    nf = sum(1 for _, ok in RESULTS if not ok)
    print(f"{len(RESULTS)} checks, {nf} failed")
    if nf == 0:
        print(f"VERIFIED ({BL.VERSION})")
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
