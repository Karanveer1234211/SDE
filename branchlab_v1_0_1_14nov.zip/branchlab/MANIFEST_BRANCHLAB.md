# MANIFEST - branchlab v1.0.1 (study BR1)

Built 13 Nov 2026; v1.0.1 14 Nov 2026. Folder: C:\Users\karanvsi\PyCharmMiscProject\branchlab (beside tradelab and setuplab, never inside bigmove_deploy). Outputs: C:\QuantData\branchlab. Reads production, setuplab's runs and the panel READ ONLY. Needs tradelab setups add-on v1.7 (tl_setups v1.7) and setuplab (unchanged).

v1.0.1 changes four files: branchlab.py, tests\test_branchlab.py, README_BRANCHLAB.md and this manifest. The declaration, env_branchlab.bat and tradelab's strategies\branchlab.py are unchanged (same sha256).

Declaration sha256: 1ec45a66b982f903c371cf1d9e79faa934d2639e570977b96e50d395951bab0e
strategies\branchlab.py (tradelab) sha256: 77529c56f87dda84ab4ae7629029dcfdb0877edda9b35dc45905c7a731dfd11a

| file | version | sha256 (first 16) | role |
|---|---|---|---|
| branchlab.py | branchlab v1.0.1 | 1aa070b57aab226e | COMMAND: check / run (Stage 1: every variant's day on every tree pick, the reconciliation incl. the full pulse comparison, coverage, the blocking count, descriptive trades, run_stage2.bat) / holm (Stage 2: Holm per engine, the forward pick) |
| BRANCHLAB_DECLARATION.json | BR1, declared 13 Nov 2026 | 1ec45a66b982f903 | the study, fixed before any run (branchlab.py refuses another sha256) - unchanged |
| env_branchlab.bat | branchlab v1.0 | 2a8cf97e4afa90ee | start a session: env_daily.bat, PYTHONPATH (branchlab, tradelab, setuplab, open_close, bigmove_deploy), SETUPLAB_OUT, BRANCHLAB_OUT (CRLF) - unchanged |
| README_BRANCHLAB.md | branchlab v1.0.1 | 7c3bd0442b1d0dc5 | the v1.0.1 note, the question, the 24 variants, Stage 1 and 2, install and run, outputs, tests |
| tests/test_branchlab.py | branchlab v1.0.1 | a333d5c056e369d1 | the self-test (46 checks; must end VERIFIED (branchlab v1.0.1)); genuine setuplab TAGS / TREE runs on a synthetic world whose panel is float32 with no change column (like the real one), an independent oracle, planted / absent worlds, planted pulse values, Holm |
