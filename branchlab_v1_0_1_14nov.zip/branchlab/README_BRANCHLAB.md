# branchlab v1.0.1 — the entry tree's open branches (study BR1)

**v1.0.1 (14 Nov 2026).** BR1's first run said DIFFERS although every setup matched on every pick (0 differences per setup, D and ENS). Cause (reproduced on a float32 test panel; the rerun's pulse line confirms it on the real one): the panel stores `w_ret_13w` as float32 with no change column, so setuplab takes the week-on-week change in float32; v1.0 took it in float64. Same sign always (that is why every setup matched), different low digits (up to 5.9e-05 when replayed on the float32 `w_ret_13w` values in the tree's dataset.parquet), so the pulse check failed. v1.0.1 takes the change exactly as setuplab does (same dtype, same 120-day window; only NaN is missing, as in setuplab's trigger) and the report prints the pulse comparison in full. The declaration is unchanged.

**Question.** The frozen tree buys a jumpy pick only through a frozen setup, and six of the seven setups can fire only on the session after the week's 13-week return is posted (a Tuesday open). Does any of 24 declared changes improve the frozen tree's account on the same picks?

Everything was declared before any run, in **`BRANCHLAB_DECLARATION.json`** (13 Nov 2026). `branchlab.py` refuses any other sha256, and `check` confirms tradelab's `strategies\branchlab.py` is the declared file.

**Prior evidence (why expectations are low).**
- 7 Nov: moving the weekly read one session earlier wrecked B (−1.8907 pp a trade [−2.3001, −1.4739]). Later entries were never tested.
- v2engine drop 3: breakouts, retests and failed-breakdown reclaims all lost to buying at the open. B_BRK, B_RET and B_RCL repeat them on D1's levels.
- JL1: every jumpy-pick variant failed against the tree (32 of 32).

## The 24 variants (each = the frozen tree + one change)

| group | variants | what changes | picks |
|-|-|-|-|
| P — bad week held | P_S1 … P_C3, P_ALL; P_ALL1, P_ALL2 | the weekly condition reads the week's posted change held until the next weekly update (P) or for 1 / 2 sessions after it | jumpy |
| N — no weekly gate | N_S1 … N_C3, N_ALL | the weekly condition removed | jumpy |
| B — D1 levels | B_BRK, B_RET, B_RCL | a close above D1's high; then a dip to it that closes above; a close back above D1's low | jumpy |
| K — calm D picks | K_SLOT, K_LATE, K_BOTH | every calm pick opening at/above its close (not only the day's best); a calm pick that opened lower, at the first later open at/above its close | calm, D only |
| E_OPEN | E_OPEN | an ENS calm pick that opens below its close goes through the frozen setups instead (D's open check) | calm, ENS only |
| X_D2 | X_D2 | control: every jumpy pick at the D2 open | jumpy |

"Jumpy" = the tree's JUMPY or NO ATR picks (routed through setups only), not ETFs. Every such pick is eligible on every watch day until it is bought — never only the picks the tree turns out to skip. Rules are read at the close before the watch day and buy at its open; the variant's buy sells at the 5th close (E_OPEN: the setup's own exit). A pick is bought on the earlier of the tree's own buy and the variant's day; on the same day the tree's buy stands.

## Stage 1 — `branchlab.py run` (descriptive)

Reads setuplab's newest TREE and TAGS runs (hash-checked — the runs tradelab replays), the research watchlist and panel the TAGS run used, and the picks' daily bars.

- **Reconciliation (required):** the six bad-week setups rebuilt with the frozen one-day pulse must give the TAGS run's entry day on every pick of ranks 1–3, AND the rebuilt pulse must equal setuplab's own `w_ret_13w_change` on every watch value (the same values missing, equal at 9 decimals — setuplab rounds every value to 9 decimals before comparing). The report and the console print the pulse comparison: values compared, bit-identical, differing only below 9 decimals, differing at 9 decimals, missing on one side only. If not: `DIFFERS`, exit 3, no `br_scores.parquet`.
- Coverage per variant: picks it buys, how many the tree skips / buys later / buys the same day; days and weekdays.
- The blocking count: why the frozen setups skipped each jumpy pick (R1 the one-day pulse, R2 not a bad week, R3 other conditions, R4 missing data).
- Each variant's own trades, descriptive only (setuplab's convention, not honest exits).

## Stage 2 — what decides (tradelab add-on v1.7)

44 backtests, each against the frozen tree (`strategies\tree.py`): D 23 (all but E_OPEN), ENS 21 (all but K_*).

**PASS rule** per run: the daily-return difference has a 95% interval above 0, AND the CAGR is higher, AND the worst drawdown is no deeper. Then Holm per engine across its whole family (0.025, one-sided). `holm` also prints the 18 Oct goal check (descriptive).

A FINAL PASS is a forward candidate only. **At most two go forward** (the smallest p), each as a new shadow book; the frozen tree, setups and paper ledger stay exactly as they are. Nothing passes → each question closes for this history.

## Install and run

1. Copy the `branchlab` folder to `C:\Users\karanvsi\PyCharmMiscProject\branchlab`, beside tradelab and setuplab.
2. Install tradelab add-on v1.7 (the other zip) over `C:\Users\karanvsi\PyCharmMiscProject\tradelab`.

```
call C:\Users\karanvsi\PyCharmMiscProject\branchlab\env_branchlab.bat
python tests\test_branchlab.py
python branchlab.py check
python branchlab.py run --root %CACHE_DAILY_ROOT%
```

Then double-click `C:\QuantData\branchlab\runs\BR_<date>_<nnn>\run_stage2.bat`. It runs the 44 backtests from the tradelab folder (about 2 minutes each — roughly 1.5 to 2 hours, unattended), then Holm. The commands are also in `stage2_commands.txt`.

**Outputs** (`C:\QuantData\branchlab\runs\BR_<date>_<nnn>\`): REPORT.md (verdict first), br_scores.parquet (tradelab's `--branchlab` reads it, hash-checked), coverage.csv, blocking.csv, trades_desc.csv, stage2_commands.txt, run_stage2.bat, run.json, DECLARATION.json, outputs.sha256; one line per run in `C:\QuantData\branchlab\branchlab_ledger.jsonl`.

## Tests (`tests\test_branchlab.py`, 46 checks)

- The declaration and the strategies file against their frozen sha256.
- By hand: the weekly state (posting rows, held 0–2 rows and all week, a zero week resets, a midweek change posts, missing stays missing, an infinite change is a value); a float32 panel with no change column gives setuplab's change to the bit (where a float64 subtraction differs) and setuplab's own window; the pulse check (missing on one side and a 9-decimal difference fail, below 9 decimals passes); the D1 price levels (strict levels, the retest after the breakout session, a missing bar ends the search, no look-ahead); the calm days; E_OPEN's plan; the earliest-day tie order.
- A synthetic world with GENUINE setuplab TAGS and TREE runs (setuplab's own commands), its panel float32 with no change column like the real one: RECONCILED, the pulse bit-identical on every watch value; every variant's day equals an independent per-pick oracle on every pick; eligibility; the held week never later than the frozen pulse; coverage and the blocking count by the oracle; the run folder (44 commands, CRLF bat, hashes); tradelab reads it, and refuses a run from another tree run or a tampered file; a disagreeing TAGS run → DIFFERS; one planted pulse value per engine → DIFFERS at 9 decimals or missing on one side, RECONCILED (and counted) below 9 decimals.
- Planted world: +6% after the held-week entry is found (+6 pp, interval above 0); absent world: nothing found.
- Holm by hand, the forward pick (at most two), and every guard.

26 planted bugs, each caught (v1.0.1 adds the float64 subtraction that made BR1 say DIFFERS, the window, infinite = missing, and four pulse-check bugs). tradelab's section 22 covers Stage 2's mechanics (10 more planted bugs).
