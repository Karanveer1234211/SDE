# MANIFEST - clashlab v1.0 + CL2 (13 Nov 2026)

Folder: C:\Users\karanvsi\PyCharmMiscProject\clashlab\ (tests in clashlab\tests\), beside tradelab and setuplab. A new tool: nothing else changes (bigmove_deploy, open_close, tradelab, setuplab are read only). Writes only under C:\QuantData\clashlab. Python with numpy, pandas, pyarrow; needs setuplab v1.1 (the installed one; clashlab checks for the functions it uses) and tradelab's tl_data on PYTHONPATH (env_clashlab.bat sets it).

| file | sha256 (first 16) | bytes | lines |
|---|---|---|---|
| clashlab.py | 9c3cb437f1f5d3ea | 35443 | 647 |
| CLASHLAB_DECLARATION.json | 8279f96553aaabc6 | 6487 | 71 |
| cl2.py | 39c2ad1a883d6f16 | 43619 | 760 |
| CL2_DECLARATION.json | b7d99cb7f90e6c17 | 3853 | 38 |
| env_clashlab.bat | 69ad9ad5f5493207 | 1852 | 33 |
| README_CLASHLAB.md | 1f88031fe6e243ed | 9718 | 147 |
| tests\test_clashlab.py | dfad620c7aa2719a | 29930 | 510 |

Declarations pinned in the code: CLASHLAB_DECLARATION.json 8279f96553aaabc63c02bec1f3f4f0bd88b6b9131208e81f8bb831035a2639cc; CL2_DECLARATION.json b7d99cb7f90e6c17923f71f18ae2779879f48bb3f9238fb3dd32a5801925bd48

Verified where it was built: clashlab 31 self-test checks, 39 planted bugs caught; cl2 14 checks, 17 planted bugs caught; both on pandas 3.0.5 and 2.3.3. The CL2 add-on ships cl2.py, CL2_DECLARATION.json and this README and MANIFEST; clashlab.py, its declaration, env_clashlab.bat and tests are unchanged.
