# clashlab v1.0 — do bars where 3+ frozen setups clash continue well? (study CL1)

**Question.** Karan's chart finding (13 Nov 2026): when 3 or more of the seven frozen setups (S1 S2 S3 C1 C2 C3 N1, `FROZEN_SETUPS.json`) enter one stock together, the next days continue well. Is that true across the whole universe, and on BigMove's own picks?

Everything was declared before any run, in **`CLASHLAB_DECLARATION.json`** (13 Nov 2026). `clashlab.py` refuses any file whose sha256 differs from the pinned one; `python clashlab.py check` confirms it.

## What is counted

| | clash | compared with |
|-|-|-|
| **same bar** | 3+ setups enter at the SAME open (the BM Setups Pine's triangle lists 3+ ids) | bars where 1–2 setups enter |
| **within 3** | 3+ DIFFERENT setups enter within 3 sessions (the bar and the 2 before), counted once, at the open that completes the cluster | entry bars whose 3-session count is under 3 |

**Two places.**
- **Universe:** every stock in the panel the TAGS run used, every session from 2020-01-01 treated as a pseudo-pick, through setuplab's whole-market engine (`market_entries`, the same rule as the Pine marks and setuplab's zones study). One row = one entry bar of one stock.
- **Picks:** D and ENS ranks 1–10 of setuplab's newest TAGS run (hash-checked). A stock and signal day picked twice counts once (lowest rank, D on a tie). One row = one watch day with a setup entry.

**Outcome.** Buy at the entry bar's open; sell at the close of session 3, 5 or 10 (2, 4 or 9 bars later); 35 bp round trip. **Excess** = that net minus the net of buying EVERY universe stock at the same open with the same hold (this takes out the market's day: clashes bunch on sell-off days).

## The rule (declared)

12 tests = 2 places × 2 clash definitions × 3 holds. Each needs both:
- **A:** the clash entries' mean excess has a 95% interval above 0 (they beat buying everything), and
- **B:** clash minus the comparison entries has a 95% interval above 0 (they beat the 1–2-setup bars).

Intervals: circular block bootstrap over entry days (10-day blocks, 2,000 resamples, seed 7). A test's p = the larger of A's and B's. Then Holm across all 12 at 0.025. **FINAL PASS** = Holm-kept AND both A and B.

- A FINAL PASS is a **forward candidate only**: a declared shadow record of clash entries in the nightly scan, judged on new data before any use. The frozen tree, the setups and the paper ledger stay as they are.
- Nothing passes → the clash question closes for this history. No re-run with another threshold, window or hold.

## Descriptive tables (they decide nothing)

- How many setups on the bar: 1, 2, 3, 4, 5+ (the dose).
- **With and without S2.** S2 is the only setup that reads the entry bar's own open (a gap down). See the warning below.
- By year (5-session hold).
- Picks: clash entries against simply buying the same picks at the D1 open.
- Reconciliation: the marks against setuplab's newest ZONES run (a warning under 99%).

## What a PASS would not prove

A 3+ clash is a deeper dip in a bad week. A pass could therefore be the dip bouncing, or high-beta stocks in a rising market, not the clash itself.

The S2 point was found while testing this tool. In a synthetic world where a gap-down open tends to bounce back, these tests passed with no clash effect at all. The reason: S2 (bought at a gap-down open) sat in 39% of clash bars against 15% of 1–2 bars. If the "with S2" rows carry the edge and the "without S2" rows do not, the edge is the gap, not the clash. Separating dip, gap and clash would be a follow-up study.

## Install and run

1. Unzip `clashlab_v1_0_13nov.zip` into `C:\Users\karanvsi\PyCharmMiscProject\`. This creates the `clashlab` folder beside tradelab and setuplab. Nothing else changes; production, tradelab and setuplab are only read.
2. Run in cmd:

```
call C:\Users\karanvsi\PyCharmMiscProject\clashlab\env_clashlab.bat
python tests\test_clashlab.py
python clashlab.py check
python clashlab.py run --root %CACHE_DAILY_ROOT%
```

The test must end `VERIFIED (clashlab v1.0)`; it runs in under a minute and touches nothing outside a temp folder.

**Run time.** Computing takes about 9 ms a stock (measured: 500 synthetic stocks × 2,205 sessions in 4.7 s). On your PC the time goes on reading the panel and every stock's bars: an estimate of 5–20 minutes (not measured there).

**Outputs** go to `C:\QuantData\clashlab\runs\CL_<date>_<nnn>\`:

| file | contents |
|-|-|
| REPORT.md | verdict first, then every table |
| tests.csv | the 12 tests |
| dose.csv | the dose table |
| composition.csv | the with/without S2 table |
| by_year.csv | the by-year table |
| universe_marks.parquet | every entry bar: its setups, counts and outcomes |
| picks_marks.parquet | every pick watch day with an entry |
| bench.parquet | the buy-everything benchmark per day |
| DECLARATION.json, run.json | the declaration and the run's details |
| outputs.sha256 | hashes of every file |

Every run also adds one line to `C:\QuantData\clashlab\clashlab_ledger.jsonl`.

## Tests (`tests\test_clashlab.py`, 31 checks)

- **Declaration:** pinned by sha256; any change refused. An older setuplab is refused, naming what it lacks.
- **By hand:** the 3-session counts, the cluster entries, the outcomes and the benchmark rows on one stock, the excess, the bootstrap (block structure, seeded), Holm (step-down; stops at the first miss), and the 12 tests' groups and rule. A alone FAILS. A resample with an empty group counts against the test.
- **Picks by hand from a TAGS run:**
  - ranks 1–10 only;
  - de-duplication (lowest rank, D on a tie);
  - the within-3 day;
  - outcomes from the watch-day open and the D1 open;
  - a tampered run is refused.
- **A synthetic universe through setuplab's own engine:**
  - the marks equal `market_entries` stock by stock;
  - the benchmark by hand;
  - loading in batches gives the same answer;
  - **planted** +4% after same-bar clashes: passes on every hold;
  - **absent:** nothing passes;
  - **gap-down opens bounce back:** the S2 table shows it.
- **The whole run folder:** 12 tests, the hashes, the ledger line, ZONES reconciled 100%, and a differing ZONES run reported.
- **The command line:** the newest TAGS and ZONES runs, the panel from TAGS.json, the bars released; an output folder inside the cache is refused.

39 planted bugs, each caught.

**Calibration (where built).** 200 synthetic worlds with no effect anywhere were checked at the declared 10-day blocks:
- the true spread across worlds was 0.90–1.05 times what the bootstrap reported, at every hold (at most 5% too narrow);
- the declared rule passed in 0.0%–2.0% of worlds per test before Holm (the one-sided level is 2.5%).

## CL2 — the 5 best filters for S2 + 3 or more setups (`cl2.py`, 13 Nov 2026)

**Question (Karan).** Find the top 5 stock-state and market-environment combinations where S2 + 3 or more setups did best in 2020, 2021 and 2022. Fix them, then test them on the remaining years.

Everything is declared in **`CL2_DECLARATION.json`**, pinned in `cl2.py` before any run.

- **The trades:** every bar where S2 enters with at least 2 other frozen setups (CL1's universe marks). Buy at the open, sell at the 3rd close, 35 bp.
- **The measures:**
  - the 12 zone measures of setuplab's zones study (8 about the stock, 4 about the market; their own buckets);
  - the 60 panel features of `features_final.txt`, cut into quarters at the quartiles of the 2020–2022 trades.
  - Every value is read at the close before the entry.
- **The candidates:** one range of one measure, or two ranges of two measures — about 190,000.
- **Choosing (2020–2022 only):**
  - at least 90 trades on at least 20 sessions;
  - in each of 2020, 2021 and 2022, at least 10 trades and a positive average;
  - ranked by the best average net per trade;
  - the top 5, skipping any combination that is more than half inside one already chosen.
- **The test (2023 to the data's end, never used to choose):** a filter HOLDS when its trades beat the rest of S2 + 3 or more AND beat buying everything, both with a 95% interval above 0. Holm across the 5 at 0.025. The report also shows each test year and the money view: weekly baskets for each filter, any of the 5, the whole base, and everything on the same sessions.

```
call C:\Users\karanvsi\PyCharmMiscProject\clashlab\env_clashlab.bat
python cl2.py selftest
python cl2.py run --root %CACHE_DAILY_ROOT%
```

It reads the newest CL run (hash-checked), the panel that run used, setuplab's newest ZONES run (hash-checked) and `features_final.txt` beside `setuplab.py`. Outputs go to `C:\QuantData\clashlab\cl2\runs\CL2_<date>_<nnn>\`:

| file | contents |
|-|-|
| REPORT.md | verdict first, then every table |
| filters.csv | the 5 filters with their training and test numbers |
| top25_training.csv | the 25 best eligible combinations in training |
| dataset.parquet | every trade with all its measures, for follow-up questions |
| run.json, DECLARATION.json, outputs.sha256 | the run's details, the declaration, the hashes |

Every run adds one line to `C:\QuantData\clashlab\cl2\cl2_ledger.jsonl`.

**Tests (`python cl2.py selftest`, 14 checks):**
- the data: each trade's zone, and its features from the panel row of the session before the entry; a value placed on the entry day never reaches the trade;
- the search equals setuplab's own `zone_screen` on the 12 zone measures (every candidate's trades and average identical);
- choosing, judging, Holm and the money view, by hand;
- a combination planted in every year is found and HOLDS; planted in 2020–2022 only, it is found and does NOT hold; absent, nothing holds.

17 planted bugs, each caught. Checked on pandas 3.0.5 and 2.3.3.
