"""
cl2.py - study CL2: the 5 best stock-state and market-environment filters for S2 + 3 or more setups, found on
2020-2022 and judged untouched on 2023 to the data's end. CL2_DECLARATION.json (pinned below) holds the rules.

    python cl2.py check                          the declaration is the pinned one
    python cl2.py selftest                       synthetic worlds (planted / planted in training only / absent)
    python cl2.py run --root %CACHE_DAILY_ROOT%  -> CLASHLAB_OUT\\cl2\\runs\\CL2_<date>_<nnn>

READS (read only): clashlab's newest CL run (universe_marks.parquet, hash-checked, and the panel it used), setuplab's
newest ZONES run (market_zone_trades.parquet, hash-checked) and features_final.txt beside setuplab.py.
WRITES only under CLASHLAB_OUT\\cl2 (or --out).
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "cl2 v1.0"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "CL2_DECLARATION.json"
DECL_SHA = "b7d99cb7f90e6c17923f71f18ae2779879f48bb3f9238fb3dd32a5801925bd48"
FROM, TRAIN_END = np.datetime64("2020-01-01"), np.datetime64("2023-01-01")
TRAIN_YEARS = (2020, 2021, 2022)
HOLD, TOP, ALPHA = 3, 5, 0.025
MIN_TRADES, MIN_SESSIONS, MIN_YEAR_TRADES, MAX_OVERLAP, STALE_DAYS = 90, 20, 10, 0.5, 5
LEDGER = "cl2_ledger.jsonl"
SL_NEEDS = ("ZONE_DIMS", "ZDIM", "Boot", "zone_eval", "zone_mask", "read_hashed_run", "latest_run", "new_run_dir",
            "write_hashes")


class CL2Error(Exception):
    pass


def say(msg):
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def setuplab():
    try:
        import setuplab as SL
    except ImportError as e:
        raise CL2Error(f"cannot import setuplab ({e}) - start with env_clashlab.bat")
    miss = [k for k in SL_NEEDS if not hasattr(SL, k)]
    if miss:
        raise CL2Error(f"{getattr(SL, 'VERSION', 'setuplab')} lacks {', '.join(miss)} - cl2 needs setuplab v1.1")
    return SL


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_decl():
    sha = sha256(DECL_FILE)
    if sha != DECL_SHA:
        raise CL2Error(f"{DECL_FILE.name} has sha256 {sha[:16]}, not the pinned {DECL_SHA[:16]} - refusing")
    return json.loads(DECL_FILE.read_text(encoding="utf-8")), sha


def ist_dates(s):
    t = pd.to_datetime(s)
    if t.dt.tz is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t.dt.normalize()


# ---------------------------------------------------------------------------------------------------- the data
def build(SL, marks, zones, panel, feats, log=say):
    """The base's trades (S2 + 2 or more other setups) with their 3-session net / excess, the 12 zone buckets, the
    panel features of the session before the entry, the exit day and the panel's calendar."""
    import pyarrow.parquet as pq
    U = pd.read_parquet(marks, columns=["symbol", "day", "n", "setups", "net3", "ex3"])
    U["day"] = pd.to_datetime(U["day"]).dt.normalize().astype("datetime64[ns]")
    U["symbol"] = U["symbol"].astype(str).str.strip().str.upper()
    s2 = U["setups"].astype(str).str.split(" ").map(lambda s: "S2" in s).to_numpy(bool)
    X = U[s2 & (U["n"].to_numpy() >= 3) & np.isfinite(U["net3"].to_numpy(float)) &
          np.isfinite(U["ex3"].to_numpy(float))].copy()
    X["b3"] = X["net3"] - X["ex3"]
    dims = list(SL.ZDIM)
    Z = pd.read_parquet(zones, columns=["symbol", "day"] + dims)
    Z["day"] = pd.to_datetime(Z["day"]).dt.normalize().astype("datetime64[ns]")
    Z["symbol"] = Z["symbol"].astype(str).str.strip().str.upper()
    Z = Z.drop_duplicates(["symbol", "day"])
    X = X.merge(Z, on=["symbol", "day"], how="left")
    for d in dims:
        X[d] = X[d].fillna(-1).astype(np.int8)
    pf = pq.ParquetFile(panel)
    low = {c.lower(): c for c in pf.schema_arrow.names}
    tk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or tk is None:
        raise CL2Error(f"{panel} needs symbol and timestamp (or date) columns")
    miss = [f for f in feats if f.lower() not in low]
    if miss:
        raise CL2Error(f"{panel} lacks {', '.join(miss)} (features_final.txt)")
    syms = set(X["symbol"])
    cal = set()
    for b in pf.iter_batches(batch_size=1_000_000, columns=[tk]):
        cal.update(ist_dates(b.to_pandas().iloc[:, 0]).unique())
    cal = np.array(sorted(cal), dtype="datetime64[D]")          # the market's sessions (any stock's panel row)
    dd = X["day"].to_numpy().astype("datetime64[D]")
    i = np.searchsorted(cal, dd)                                  # the session before the entry, on that calendar
    prev = np.where(i > 0, cal[np.maximum(i - 1, 0)], np.datetime64("NaT", "D"))
    prev[(dd - prev) > np.timedelta64(STALE_DAYS, "D")] = np.datetime64("NaT", "D")
    X["prev"] = pd.to_datetime(prev).astype("datetime64[ns]")
    need = X[["symbol", "prev"]].dropna().drop_duplicates()
    parts = []
    for b in pf.iter_batches(batch_size=300_000, columns=[low["symbol"], tk] + [low[f.lower()] for f in feats]):
        f = b.to_pandas()
        f.columns = ["symbol", "prev"] + list(feats)
        f["symbol"] = f["symbol"].astype(str).str.strip().str.upper()
        f = f[f["symbol"].isin(syms)]
        if not len(f):
            continue
        f["prev"] = ist_dates(f["prev"]).astype("datetime64[ns]")
        f = f.merge(need, on=["symbol", "prev"], how="inner").assign(found=1)
        for c in feats:
            f[c] = pd.to_numeric(f[c], errors="coerce").astype(np.float32)
        parts.append(f)
    Fp = pd.concat(parts, ignore_index=True).drop_duplicates(["symbol", "prev"]) if parts else \
        pd.DataFrame(columns=["symbol", "prev", "found"] + list(feats))
    X = X.merge(Fp, on=["symbol", "prev"], how="left")
    X["found"] = X["found"].fillna(0).astype(bool)
    i = np.searchsorted(cal, X["day"].to_numpy().astype("datetime64[D]"))
    X["exit"] = cal[np.minimum(i + HOLD - 1, len(cal) - 1)]
    X = X.sort_values(["day", "symbol"]).reset_index(drop=True)
    info = {"trades": int(len(X)), "first": str(X["day"].min().date()), "last": str(X["day"].max().date()),
            "zone_known": float((X[dims].to_numpy() >= 0).all(axis=1).mean()),
            "features_known": float(X[list(feats)].notna().all(axis=1).mean()) if feats else 1.0,
            "prev_found": float(X["found"].mean())}
    log(f" {info['trades']:,} trades of S2 + 2 or more setups; zones known {info['zone_known']:.1%}, panel row of the "
        f"session before found {info['prev_found']:.1%}")
    return X, cal, info


# ---------------------------------------------------------------------------------------------------- measures
def make_dims(SL, X, feats, train):
    """The 12 zone measures (setuplab's buckets) and each feature cut at the quartiles of the training trades."""
    dims, B = [], {}
    for name, what, edges, labels in SL.ZONE_DIMS:
        dims.append({"name": name, "kind": "zone", "what": what, "nb": len(labels), "labels": list(labels),
                     "edges": None if edges is None else list(edges)})
        B[name] = X[name].to_numpy().astype(np.int8)
    for f in feats:
        v = X[f].to_numpy(float)
        t = v[train & np.isfinite(v)]
        if len(t) < 40:
            continue
        e = [float(x) for x in np.quantile(t, [0.25, 0.5, 0.75])]
        b = np.full(len(v), -1, np.int8)
        ok = np.isfinite(v)
        b[ok] = np.searchsorted(np.asarray(e), v[ok], side="right").astype(np.int8)
        dims.append({"name": f, "kind": "feature", "what": f, "nb": 4, "labels": ["Q1", "Q2", "Q3", "Q4"], "edges": e})
        B[f] = b
    return dims, B


def ranges(nb):
    return [(lo, hi) for lo in range(nb) for hi in range(lo, nb) if not (lo == 0 and hi == nb - 1)]


def zkey(z):
    return " + ".join(f"{d}:{lo}:{hi}" for d, lo, hi in z)


def ztext(z, dims):
    D = {d["name"]: d for d in dims}
    out = []
    for name, lo, hi in z:
        d = D[name]
        lab, e = d["labels"], d["edges"]
        if d["kind"] == "feature":
            v = (f"below {e[hi]:.4g}" if lo == 0 else f"{e[lo - 1]:.4g} and above" if hi == 3 else
                 f"{e[lo - 1]:.4g} to {e[hi]:.4g}")
            out.append(f"{name} {v} ({'Q' + str(lo + 1) if lo == hi else 'Q%d-Q%d' % (lo + 1, hi + 1)})")
        elif e is None:
            out.append(f"{name} ({d['what']}) {lab[lo] if lo == hi else lab[lo] + ' to ' + lab[hi]}")
        else:
            v = f"below {e[hi]:g}" if lo == 0 else f"{e[lo - 1]:g} and above" if hi == d["nb"] - 1 else \
                f"{e[lo - 1]:g} to {e[hi]:g}"
            out.append(f"{name} ({d['what']}) {v}")
    return " AND ".join(out)


def zmask(z, B):
    m = np.ones(len(next(iter(B.values()))), bool)
    for name, lo, hi in z:
        b = B[name]
        m &= (b >= lo) & (b <= hi)
    return m


# ---------------------------------------------------------------------------------------------------- the search
def screen(days, years, net, B, dims):
    """Every candidate on these trades: trades inside, mean net, entry sessions, trades and mean net per year.
    Day-level sums with cumulative bucket sums, so every range of a measure (or of two) costs one subtraction."""
    ud, di = np.unique(days, return_inverse=True)
    nd = len(ud)
    yrs = np.array(sorted(set(years)))
    Y = (pd.DatetimeIndex(ud).year.to_numpy()[None, :] == yrs[:, None]).astype(float)
    keys, out = [], {"n": [], "s": [], "ses": [], "yn": [], "ys": []}

    def push(Sr, Nr, cands):
        out["n"].append(Nr.sum(0)), out["s"].append(Sr.sum(0)), out["ses"].append((Nr > 0).sum(0))
        out["yn"].append(Y @ Nr), out["ys"].append(Y @ Sr)
        keys.extend(cands)

    code_of = {}
    for d in dims:
        b = B[d["name"]].astype(np.int64)
        code_of[d["name"]] = np.where(b < 0, d["nb"], b)
    for d in dims:
        nb, c = d["nb"], code_of[d["name"]]
        S = np.bincount(di * (nb + 1) + c, weights=net, minlength=nd * (nb + 1)).reshape(nd, nb + 1)[:, :nb]
        N = np.bincount(di * (nb + 1) + c, minlength=nd * (nb + 1)).reshape(nd, nb + 1)[:, :nb].astype(float)
        Cs = np.concatenate([np.zeros((nd, 1)), np.cumsum(S, 1)], 1)
        Cn = np.concatenate([np.zeros((nd, 1)), np.cumsum(N, 1)], 1)
        R = ranges(nb)
        lo, hi = np.array([r[0] for r in R]), np.array([r[1] for r in R])
        push(Cs[:, hi + 1] - Cs[:, lo], Cn[:, hi + 1] - Cn[:, lo], [((d["name"], a, b_),) for a, b_ in R])
    for i, d1 in enumerate(dims):
        for d2 in dims[i + 1:]:
            n1, n2 = d1["nb"], d2["nb"]
            code = (di * (n1 + 1) + code_of[d1["name"]]) * (n2 + 1) + code_of[d2["name"]]
            S = np.bincount(code, weights=net, minlength=nd * (n1 + 1) * (n2 + 1)).reshape(nd, n1 + 1, n2 + 1)[:, :n1, :n2]
            N = np.bincount(code, minlength=nd * (n1 + 1) * (n2 + 1)).reshape(nd, n1 + 1, n2 + 1)[:, :n1, :n2].astype(float)
            Cs = np.zeros((nd, n1 + 1, n2 + 1))
            Cn = np.zeros((nd, n1 + 1, n2 + 1))
            Cs[:, 1:, 1:] = S.cumsum(1).cumsum(2)
            Cn[:, 1:, 1:] = N.cumsum(1).cumsum(2)
            R1, R2 = ranges(n1), ranges(n2)
            a = np.array([(r1[0], r1[1], r2[0], r2[1]) for r1 in R1 for r2 in R2])
            l1, h1, l2, h2 = a[:, 0], a[:, 1] + 1, a[:, 2], a[:, 3] + 1
            push(Cs[:, h1, h2] - Cs[:, l1, h2] - Cs[:, h1, l2] + Cs[:, l1, l2],
                 Cn[:, h1, h2] - Cn[:, l1, h2] - Cn[:, h1, l2] + Cn[:, l1, l2],
                 [((d1["name"], r1[0], r1[1]), (d2["name"], r2[0], r2[1])) for r1 in R1 for r2 in R2])
    n, s = np.concatenate(out["n"]), np.concatenate(out["s"])
    yn, ys = np.concatenate(out["yn"], axis=1), np.concatenate(out["ys"], axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        return {"keys": keys, "n": n, "mean": s / n, "ses": np.concatenate(out["ses"]), "years": yrs, "yn": yn,
                "ymean": ys / yn}


def choose(Sc, Btr, top=TOP):
    """Eligible: enough trades and sessions, and every training year with 10+ trades and a positive mean. The best
    by mean net; a candidate mostly inside a filter already chosen is skipped."""
    elig = ((Sc["n"] >= MIN_TRADES) & (Sc["ses"] >= MIN_SESSIONS) & np.all(Sc["yn"] >= MIN_YEAR_TRADES, axis=0) &
            np.all(Sc["ymean"] > 0, axis=0) & np.isfinite(Sc["mean"]))
    idx = np.flatnonzero(elig)
    idx = idx[np.lexsort((-Sc["n"][idx], -Sc["mean"][idx]))]
    chosen, masks, skipped = [], [], 0
    for i in idx:
        m = zmask(Sc["keys"][i], Btr)
        if any((m & mc).sum() > MAX_OVERLAP * m.sum() for mc in masks):
            skipped += 1
            continue
        chosen.append(int(i))
        masks.append(m)
        if len(chosen) == top:
            break
    return chosen, idx, int(elig.sum()), skipped


# ---------------------------------------------------------------------------------------------------- judging
def judge(SL, X, m):
    days = X["day"].to_numpy().astype("datetime64[D]")
    boot = SL.Boot(days)
    di = np.searchsorted(boot.days, days)
    net, chk = X["net3"].to_numpy(float), X["ex3"].to_numpy(float)
    e = SL.zone_eval(boot, di, net, chk, m)
    nd = len(boot.days)
    cols = np.column_stack([np.bincount(di[m], weights=net[m], minlength=nd), np.bincount(di[m], minlength=nd),
                            np.bincount(di[~m], weights=net[~m], minlength=nd), np.bincount(di[~m], minlength=nd),
                            np.bincount(di[m], weights=chk[m], minlength=nd)]).astype(float)
    R = boot.M @ cols
    with np.errstate(invalid="ignore", divide="ignore"):
        mi, mo, mc = R[:, 0] / R[:, 1], R[:, 2] / R[:, 3], R[:, 4] / R[:, 1]
    e["p_diff"] = float((1 + np.sum(~(mi - mo > 0))) / (len(mi) + 1))
    e["p_chk"] = float((1 + np.sum(~(mc > 0))) / (len(mc) + 1))
    e["p"] = max(e["p_diff"], e["p_chk"])
    e["win"] = float((net[m] > 0).mean()) if m.any() else np.nan
    e["rule"] = "HOLDS" if (np.isfinite(e["diff_lo"]) and e["diff_lo"] > 0 and np.isfinite(e["chk_lo"]) and
                            e["chk_lo"] > 0) else "NOT HELD"
    return e


def holm(rows, alpha=ALPHA):
    order = sorted(range(len(rows)), key=lambda i: (rows[i]["p"], i))
    going = True
    for k, i in enumerate(order):
        lim = alpha / (len(rows) - k)
        keep = going and rows[i]["p"] <= lim
        going = keep
        rows[i].update(holm_limit=lim, holm_kept=bool(keep),
                       final="HOLDS" if keep and rows[i]["rule"] == "HOLDS" else "NOT HELD")
    return rows


def money(X, m, cal, span_years):
    """One equal-weight basket a signal session of the rows in m (buy the open, sell the 3rd close, whole account,
    compounded, one basket at a time) and every stock on the same sessions."""
    per = X[m].groupby("day")["net3"].mean()
    mk = X.groupby("day")["b3"].first()
    pos = np.searchsorted(cal, per.index.to_numpy().astype("datetime64[D]"))
    keep, last = [], -10
    for p in pos:
        keep.append(p > last + HOLD - 1)
        if keep[-1]:
            last = p
    per = per[keep]
    out = {}
    for nm, r in (("basket", per), ("everything", mk.reindex(per.index))):
        eq = np.cumprod(1 + r.to_numpy(float) / 100)
        out[nm] = {"baskets": int(len(r)), "avg": float(r.mean()) if len(r) else np.nan,
                   "pos": float((r > 0).mean()) if len(r) else np.nan,
                   "a_year": float(eq[-1] ** (1 / span_years) - 1) if len(r) else np.nan,
                   "worst_dd": float((eq / np.maximum.accumulate(eq) - 1).min()) if len(r) else np.nan,
                   "by_year": {int(y): float((np.prod(1 + g / 100) - 1) * 100) for y, g in r.groupby(r.index.year)}}
    return out


# ---------------------------------------------------------------------------------------------------- the study
def study(SL, X, cal, feats, log=say):
    d = X["day"].to_numpy().astype("datetime64[D]")
    ex = X["exit"].to_numpy().astype("datetime64[D]")
    train, test = (d >= FROM) & (ex < TRAIN_END), d >= TRAIN_END
    dims, B = make_dims(SL, X, feats, train)
    Btr = {k: v[train] for k, v in B.items()}
    Xtr, Xte = X[train].reset_index(drop=True), X[test].reset_index(drop=True)
    Bte = {k: v[test] for k, v in B.items()}
    log(f" searching {len(dims)} measures on {len(Xtr):,} training trades (2020-2022)")
    Sc = screen(Xtr["day"].to_numpy().astype("datetime64[D]"), pd.DatetimeIndex(Xtr["day"]).year.to_numpy(),
                Xtr["net3"].to_numpy(float), Btr, dims)
    chosen, ranked, n_elig, skipped = choose(Sc, Btr)
    log(f" {len(Sc['keys']):,} candidates, {n_elig:,} eligible; {len(chosen)} chosen")
    span = max(1e-9, float((cal[-1] - TRAIN_END).astype(int)) / 365.25)
    yrs_te = sorted(set(pd.DatetimeIndex(Xte["day"]).year))
    filters, rows = [], []
    for rank, i in enumerate(chosen, 1):
        z = Sc["keys"][i]
        mtr, mte = zmask(z, Btr), zmask(z, Bte)
        f = {"rank": rank, "key": zkey(z), "text": ztext(z, dims), "train_n": int(Sc["n"][i]),
             "train_mean": float(Sc["mean"][i]), "train_sessions": int(Sc["ses"][i]),
             "train_years": {int(y): (int(Sc["yn"][k, i]), float(Sc["ymean"][k, i])) for k, y in enumerate(Sc["years"])},
             "train_ex": float(Xtr["ex3"][mtr].mean()), "train_win": float((Xtr["net3"][mtr] > 0).mean())}
        f["test"] = judge(SL, Xte, mte) if len(Xte) else {}
        f["test_years"] = {int(y): (int((mte & (Xte["day"].dt.year == y).to_numpy()).sum()),
                                    float(Xte["net3"][mte & (Xte["day"].dt.year == y).to_numpy()].mean())
                                    if (mte & (Xte["day"].dt.year == y).to_numpy()).any() else np.nan,
                                    float(Xte["net3"][~mte & (Xte["day"].dt.year == y).to_numpy()].mean()))
                           for y in yrs_te}
        f["money"] = money(Xte, mte, cal, span)
        filters.append(f)
        rows.append(dict(f["test"], rank=rank))
    if rows:
        for h in holm(rows):
            filters[h["rank"] - 1]["test"].update(holm_limit=h["holm_limit"], holm_kept=h["holm_kept"], final=h["final"])
    anym = np.zeros(len(Xte), bool)
    for f in filters:
        anym |= zmask(tuple((p.split(":")[0], int(p.split(":")[1]), int(p.split(":")[2])) for p in f["key"].split(" + ")), Bte)
    res = {"filters": filters, "dims": dims, "n_cands": len(Sc["keys"]), "n_elig": n_elig, "skipped": skipped,
           "train_n": int(len(Xtr)), "test_n": int(len(Xte)), "train_base_mean": float(Xtr["net3"].mean()),
           "test_base_mean": float(Xte["net3"].mean()) if len(Xte) else np.nan, "test_years": yrs_te,
           "money_base": money(Xte, np.ones(len(Xte), bool), cal, span), "money_any": money(Xte, anym, cal, span),
           "any_n": int(anym.sum())}
    top = []
    for i in ranked[:25]:
        z = Sc["keys"][i]
        top.append({"key": zkey(z), "text": ztext(z, dims), "n": int(Sc["n"][i]), "mean": float(Sc["mean"][i]),
                    "sessions": int(Sc["ses"][i]), **{f"mean_{y}": float(Sc["ymean"][k, i]) for k, y in enumerate(Sc["years"])},
                    "chosen": int(i) in chosen})
    return res, pd.DataFrame(top)


# ---------------------------------------------------------------------------------------------------- report
def _f(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "-"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


def _pc(x):
    return "-" if x is None or not np.isfinite(x) else f"{x:+.1%}"


def report(res, decl, sha, info, ins, secs):
    F = res["filters"]
    fin = [f for f in F if f["test"].get("final") == "HOLDS"]
    last = info["last"][:4]
    L = [f"# CL2 - the 5 best filters for S2 + 3 or more setups: found on 2020-2022, tested on 2023-{last} ({VERSION})",
         "", f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). CL run {ins['cl_run']} "
         f"(marks `{ins['marks_sha'][:16]}`), ZONES `{ins['zones_sha'][:16]}`, panel `{ins['panel']}`. {info['trades']:,} "
         f"trades {info['first']} to {info['last']}: training {res['train_n']:,} (base {_f(res['train_base_mean'])}% a "
         f"trade), test {res['test_n']:,} (base {_f(res['test_base_mean'])}%). Zones known {info['zone_known']:.1%}, "
         f"features known {info['features_known']:.1%}. {res['n_cands']:,} combinations searched, {res['n_elig']:,} "
         f"eligible. {secs:.0f} s.", "", "## Verdict first", ""]
    if fin:
        L.append(f"**{len(fin)} of {len(F)} filters HOLD on 2023-{last}: " + "; ".join(f"#{f['rank']} {f['text']}" for f in fin) +
                 ".** Found on 2020-2022 only, each beat the rest of S2 + 3 or more AND buying everything on years it "
                 "never saw (Holm across the 5). Next: their own lanes in the forward record.")
    else:
        L.append(f"**None of the {len(F)} filters held on 2023-{last}** (beating the rest of the base AND buying "
                 "everything, after Holm). The base stays unfiltered (the declaration's rule).")
    L += ["", "Every trade: buy the entry bar's open, sell the 3rd close, 35 bp. Intervals: 10-day blocks of entry days, "
              "2,000 resamples.", "", "## The 5 filters", "",
          "| # | filter (fixed on 2020-2022) | train trades | train net % | " +
          " | ".join(f"{y}" for y in TRAIN_YEARS) + " | test trades | test net in % | rest of base % | in - rest | 95% | "
          "excess in | 95% | p | Holm limit | FINAL |",
          "|---|---|---:|---:|" + "---:|" * len(TRAIN_YEARS) + "---:|---:|---:|---:|---|---:|---|---:|---:|---|"]
    for f in F:
        t = f["test"]
        L.append(f"| {f['rank']} | {f['text']} | {f['train_n']:,} | {_f(f['train_mean'])} | " +
                 " | ".join(_f(f["train_years"][y][1]) for y in TRAIN_YEARS) +
                 f" | {t.get('n', 0):,} | {_f(t.get('net'))} | {_f(t.get('net_out'))} | {_f(t.get('diff'))} | "
                 f"[{_f(t.get('diff_lo'))}, {_f(t.get('diff_hi'))}] | {_f(t.get('chk'))} | [{_f(t.get('chk_lo'))}, "
                 f"{_f(t.get('chk_hi'))}] | {_f(t.get('p'), 4, False)} | {_f(t.get('holm_limit'), 4, False)} | "
                 f"**{t.get('final', '-')}** |")
    ys = res["test_years"]
    L += ["", "## Test years, one by one (net % a trade: inside / rest of the base)", "",
          "| # | " + " | ".join(str(y) for y in ys) + " |", "|---|" + "---|" * len(ys)]
    for f in F:
        L.append(f"| {f['rank']} | " + " | ".join(f"{_f(f['test_years'][y][1])} / {_f(f['test_years'][y][2])} "
                                                  f"({f['test_years'][y][0]})" for y in ys) + " |")
    L += ["", f"## Money on the test years (2023-{last}, descriptive)", "",
          "One equal-weight basket a signal session, whole account, compounded, one basket at a time.", "",
          "| basket | baskets | avg % | positive | a year | worst drawdown | everything, same sessions: a year | its drawdown |",
          "|---|---:|---:|---:|---:|---:|---:|---:|"]
    rows = [(f"#{f['rank']} {f['text']}", f["money"]) for f in F] + \
           [(f"any of the 5 ({res['any_n']:,} trades)", res["money_any"]), ("the whole base (no filter)", res["money_base"])]
    for nm, M in rows:
        mb, me = M["basket"], M["everything"]
        L.append(f"| {nm} | {mb['baskets']} | {_f(mb['avg'])} | {_pc(mb['pos'])} | {_pc(mb['a_year'])} | "
                 f"{_pc(mb['worst_dd'])} | {_pc(me['a_year'])} | {_pc(me['worst_dd'])} |")
    L += ["", "### By year (compounded %)", "", "| basket | " + " | ".join(map(str, ys)) + " |", "|---|" + "---:|" * len(ys)]
    for nm, M in rows:
        L.append(f"| {nm} | " + " | ".join(_f(M["basket"]["by_year"].get(y), 1) for y in ys) + " |")
    L.append(f"| everything (the base's sessions) | " +
             " | ".join(_f(res["money_base"]["everything"]["by_year"].get(y), 1) for y in ys) + " |")
    L += ["", "## What this is not", ""] + [f"- {x}" for x in decl["what_this_is_not"]] + [""]
    return "\n".join(L)


def out_base(arg, root):
    v = arg or (str(Path(os.environ["CLASHLAB_OUT"]) / "cl2") if os.environ.get("CLASHLAB_OUT") else None)
    if not v:
        raise CL2Error("no output folder: pass --out or start with env_clashlab.bat (sets CLASHLAB_OUT)")
    b = Path(v).resolve()
    for g in ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                         ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]:
        if b == g or g in b.parents:
            raise CL2Error(f"output folder {b} is inside {g}; cl2 never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


def execute(SL, marks, zones, panel, feats, bout, decl, sha, ins, log=say):
    t0 = dt.datetime.now()
    X, cal, info = build(SL, marks, zones, panel, feats, log)
    res, top = study(SL, X, cal, feats, log)
    secs = (dt.datetime.now() - t0).total_seconds()
    run = SL.new_run_dir(Path(bout) / "runs", "CL2")
    (run / "REPORT.md").write_text(report(res, decl, sha, info, ins, secs), encoding="utf-8")
    pd.DataFrame([{k: v for k, v in f.items() if k not in ("test", "money", "train_years", "test_years")} |
                  {f"test_{k}": v for k, v in f["test"].items()} for f in res["filters"]]).to_csv(
        run / "filters.csv", index=False, float_format="%.10g")
    top.to_csv(run / "top25_training.csv", index=False, float_format="%.10g")
    X.drop(columns=["prev", "found"]).to_parquet(run / "dataset.parquet", index=False)
    rj = {"tool": VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "declaration_sha256": sha, **ins,
          **info, "seconds": round(secs, 1), "candidates": res["n_cands"], "eligible": res["n_elig"],
          "filters": [{k: v for k, v in f.items() if k != "money"} for f in res["filters"]],
          "dims": res["dims"]}
    (run / "run.json").write_text(json.dumps(rj, indent=1, default=str), encoding="utf-8")
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    names = ["REPORT.md", "filters.csv", "top25_training.csv", "dataset.parquet", "run.json", "DECLARATION.json"]
    SL.write_hashes(run, names)
    with open(Path(bout) / LEDGER, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"time": rj["made"], "tool": VERSION, "event": "run", "run": run.name,
                             "declaration_sha256": sha, "marks_sha": ins["marks_sha"], "zones_sha": ins["zones_sha"],
                             "filters": [{"rank": f["rank"], "key": f["key"], "final": f["test"].get("final"),
                                          "p": f["test"].get("p")} for f in res["filters"]]}, default=str) + "\n")
    return run, res


def cmd_run(a):
    decl, sha = load_decl()
    SL = setuplab()
    root = Path(a.root) if a.root else None
    if root is None or not root.is_dir():
        raise CL2Error("--root must be the daily cache (%CACHE_DAILY_ROOT%)")
    cb, sb = a.clash or os.environ.get("CLASHLAB_OUT"), a.setups or os.environ.get("SETUPLAB_OUT")
    if not cb or not sb:
        raise CL2Error("clashlab's and setuplab's output folders: start with env_clashlab.bat (sets CLASHLAB_OUT and "
                       "SETUPLAB_OUT) or pass --clash and --setups")
    cbase, sbase = Path(cb), Path(sb)
    runs = sorted(p for p in (cbase / "runs").glob("CL_*") if (p / "universe_marks.parquet").is_file()
                  and (p / "run.json").is_file())
    if not runs:
        raise CL2Error(f"no clashlab CL run with universe_marks.parquet under {cbase / 'runs'}")
    cl = runs[-1]
    SL.read_hashed_run(cl, ["universe_marks.parquet", "run.json"])
    panel = Path(a.features or json.loads((cl / "run.json").read_text(encoding="utf-8")).get("panel", ""))
    if not panel.is_file():
        raise CL2Error(f"the panel the CL run used is not at {panel} - pass --features <panel.parquet>")
    zr = SL.latest_run(sbase, "ZONES", ["market_zone_trades.parquet"])
    if zr is None:
        raise CL2Error(f"no ZONES run with market_zone_trades.parquet under {sbase}")
    SL.read_hashed_run(zr, ["market_zone_trades.parquet"])
    ff = Path(SL.__file__).resolve().with_name("features_final.txt")
    feats = [x.strip() for x in ff.read_text(encoding="utf-8").splitlines() if x.strip() and not x.startswith("#")]
    if any(f.lower().startswith("label_") for f in feats):
        raise CL2Error("features_final.txt lists a label_ column - refusing (the label firewall)")
    bout = out_base(a.out, root)
    ins = {"cl_run": cl.name, "marks": str(cl / "universe_marks.parquet"), "marks_sha": sha256(cl / "universe_marks.parquet"),
           "zones": str(zr / "market_zone_trades.parquet"), "zones_sha": sha256(zr / "market_zone_trades.parquet"),
           "panel": str(panel), "features_file": str(ff), "features_sha": sha256(ff), "features": len(feats)}
    say(f"{VERSION} run | declaration {sha[:16]} | {cl.name} | {zr.name} | {len(feats)} features | out {bout}")
    run, res = execute(SL, cl / "universe_marks.parquet", zr / "market_zone_trades.parquet", panel, feats, bout, decl,
                       sha, ins)
    say(f"wrote {run}")
    for f in res["filters"]:
        say(f"#{f['rank']} {f['text']}: train {f['train_mean']:+.2f}% ({f['train_n']}) -> test "
            f"{f['test'].get('net', float('nan')):+.2f}% vs rest {f['test'].get('net_out', float('nan')):+.2f}% "
            f"-> {f['test'].get('final')}")
    say("RESULT: " + (", ".join(f"#{f['rank']} HOLDS" for f in res["filters"] if f["test"].get("final") == "HOLDS")
                      or "no filter holds") + " (send Claude REPORT.md)")
    return 0


# ---------------------------------------------------------------------------------------------------- self-test
def _world(SL, root: Path, feats, plant=None, seed=5):
    """A fake universe with the real file shapes: marks (Tuesday-heavy), the ZONES file (market measures shared by a
    day, stock measures per stock-day), and a panel (zoned timestamps) whose feature on each date is random, plus
    'LEAK' = the 3-session return of a trade entering the NEXT session (it must never reach the trade).
    plant = (period, cond, add): cond(X) -> rows; period 'all' or 'train' (entries before 2022-12-20)."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-12-02", "2026-09-23")
    syms = np.array([f"S{i:03d}" for i in range(300)])
    mdim = {"IDX": 4, "VIXP": 3, "VIX5": 3, "NIFTY20": 3}
    mv = {k: rng.integers(0, v, len(cal)) for k, v in mdim.items()}
    rows = []
    for j, d in enumerate(cal):
        if d < pd.Timestamp("2020-01-06"):
            continue
        k = int(rng.integers(20, 45)) if d.weekday() == 1 else int(rng.integers(0, 6))
        if not k:
            continue
        r = pd.DataFrame({"symbol": rng.choice(syms, k, replace=False), "day": d, "j": j})
        r["n"] = rng.integers(1, 8, k)
        r["s2"] = rng.random(k) < 0.55
        b3 = rng.normal(0, 1.2)
        r["net3"] = rng.normal(0.3, 5, k)
        r["ex3"] = r["net3"] - b3
        for dim in mdim:
            r[dim] = mv[dim][j]
        rows.append(r)
    X = pd.concat(rows, ignore_index=True)
    for dim, _, _, labels in SL.ZONE_DIMS:
        if dim not in mdim:
            X[dim] = np.where(rng.random(len(X)) < 0.03, -1, rng.integers(0, len(labels), len(X)))
    others = np.array(["S1", "S3", "C1", "C2", "C3", "N1"])
    X["setups"] = [" ".join((["S2"] if s else []) + list(rng.choice(others, min(6, max(0, n - int(s))), replace=False)))
                   for n, s in zip(X["n"], X["s2"])]
    X["n"] = X["setups"].str.split(" ").map(len)
    # the panel: every stock every session (a few rows missing), features random; LEAK placed on the entry day
    P = pd.DataFrame({"symbol": np.repeat(syms, len(cal)), "date": np.tile(cal, len(syms))})
    P = P.sample(frac=0.995, random_state=seed).sort_values(["symbol", "date"]).reset_index(drop=True)
    for f in feats:
        P[f] = rng.normal(0, 1, len(P)).astype(np.float32)
    X = X.merge(P[["symbol", "date"] + list(feats)].rename(columns={"date": "pday"}).assign(
        day=lambda p: p["pday"].map(dict(zip(cal[:-1], cal[1:])))), on=["symbol", "day"], how="left")
    if plant:
        period, cond, add = plant
        hit = cond(X).to_numpy(bool) & X["s2"].to_numpy(bool) & (X["n"].to_numpy() >= 3)
        if period == "train":
            hit &= X["day"].to_numpy() < np.datetime64("2022-12-20")
        X.loc[hit, "net3"] += add
        X.loc[hit, "ex3"] += add
    leak = X.groupby(["symbol", "day"])["net3"].first()
    P["LEAK"] = P.set_index(["symbol", "date"]).index.map(leak).to_numpy(float)
    P["timestamp"] = (pd.DatetimeIndex(P["date"]).tz_localize("Asia/Kolkata") + pd.Timedelta(hours=15, minutes=30)
                      ).tz_convert("UTC")
    root.mkdir(parents=True, exist_ok=True)
    P.drop(columns=["date"]).to_parquet(root / "panel.parquet", index=False)
    X[["symbol", "day", "n", "setups", "net3", "ex3"]].assign(day=lambda x: x["day"].astype("datetime64[ms]")).to_parquet(
        root / "marks.parquet", index=False)
    Z = X[["symbol", "day"] + list(SL.ZDIM)].assign(day=lambda x: x["day"].astype("datetime64[s]"))
    pd.concat([Z, Z.iloc[:40]]).assign(setup="S1").to_parquet(root / "zones.parquet", index=False)
    return root, X, P


def selftest():
    SL = setuplab()
    ok_all = True

    def check(name, ok, detail=""):
        nonlocal ok_all
        ok_all &= bool(ok)
        print(("  ok   " if ok else "  FAIL ") + name + ("" if ok else f"   <- {str(detail)[:700]}"), flush=True)

    decl, sha = load_decl()
    check("s1 the declaration is the pinned one", sha == DECL_SHA)
    global DECL_FILE
    keep, bad = DECL_FILE, Path(tempfile.mkdtemp(prefix="cl2d_")) / "CL2_DECLARATION.json"
    bad.write_text(DECL_FILE.read_text(encoding="utf-8").replace('"at least 90 trades', '"at least 60 trades'),
                   encoding="utf-8")
    DECL_FILE = bad
    try:
        load_decl()
        refused = False
    except CL2Error:
        refused = True
    finally:
        DECL_FILE = keep
    check("s1b a changed declaration is refused", refused)
    tmp = Path(tempfile.mkdtemp(prefix="cl2_"))
    feats = [f"F{i}" for i in range(6)]
    root, W, P = _world(SL, tmp / "absent", feats + ["LEAK"])
    X, cal, info = build(SL, root / "marks.parquet", root / "zones.parquet", root / "panel.parquet", feats + ["LEAK"],
                         lambda *a: None)
    base = W[W["s2"] & (W["n"] >= 3)]
    J = X.merge(base[["symbol", "day", "F0", "VIXP", "ATRP"]], on=["symbol", "day"], suffixes=("", "_w"))
    ok_f = np.allclose(J["F0"].to_numpy(float), J["F0_w"].to_numpy(float), equal_nan=True)
    check("s2 the data: the base (S2 + 2 or more others), each trade's zone, its features from the panel row of the "
          "session BEFORE the entry (zoned timestamps -> Indian dates), a missing row stays missing",
          len(X) == len(base) and len(J) == len(X) and ok_f and (J["VIXP"] == J["VIXP_w"]).all() and
          (J["ATRP"] == J["ATRP_w"]).all(), (len(X), len(base), info))
    lk = X["LEAK"].to_numpy(float)
    check("s3 no look-ahead: a value placed on the entry day itself never reaches the trade",
          not np.any(np.isclose(lk, X["net3"].to_numpy(float))), int(np.isclose(lk, X["net3"]).sum()))
    i = np.searchsorted(cal, X["day"].to_numpy().astype("datetime64[D]"))
    check("s4 the exit = the 3rd session's close on the panel's calendar",
          (X["exit"].to_numpy().astype("datetime64[D]") == cal[np.minimum(i + 2, len(cal) - 1)]).all())
    # the screen = setuplab's zone_screen on the 12 zone measures (same n and mean for every candidate)
    tr = (X["day"].to_numpy() >= FROM) & (X["exit"].to_numpy() < TRAIN_END)
    dims, B = make_dims(SL, X, [], tr)
    Xt = X[tr]
    Bt = {k: v[tr] for k, v in B.items()}
    Sc = screen(Xt["day"].to_numpy().astype("datetime64[D]"), Xt["day"].dt.year.to_numpy(), Xt["net3"].to_numpy(float),
                Bt, dims)
    days = Xt["day"].to_numpy().astype("datetime64[D]")
    ud, di = np.unique(days, return_inverse=True)
    n_sl, m_sl, _ = SL.zone_screen(di, Xt["net3"].to_numpy(float), Bt, len(ud))
    ref = {SL.zone_key(z).replace("+", " + "): (n, m) for z, n, m in zip(SL.ZONE_CANDS, n_sl, m_sl)}
    mine = {zkey(k): (n, m) for k, n, m in zip(Sc["keys"], Sc["n"], Sc["mean"])}
    same = set(ref) == set(mine) and all(ref[k][0] == mine[k][0] and (np.isclose(ref[k][1], mine[k][1]) or
                                                                       (np.isnan(ref[k][1]) and np.isnan(mine[k][1])))
                                         for k in ref)
    j = 1234
    zz = Sc["keys"][j]
    mm = zmask(zz, Bt)
    yrs = Xt["day"].dt.year.to_numpy()
    by_hand = (mm.sum() == Sc["n"][j] and np.isclose(Xt["net3"].to_numpy()[mm].mean(), Sc["mean"][j]) and
               len(np.unique(days[mm])) == Sc["ses"][j] and
               all(np.isclose(Xt["net3"].to_numpy()[mm & (yrs == y)].mean(), Sc["ymean"][k, j])
                   for k, y in enumerate(Sc["years"]) if (mm & (yrs == y)).any()))
    dimsF, BF = make_dims(SL, X, ["F0"], tr)
    e = [d for d in dimsF if d["name"] == "F0"][0]["edges"]
    check("s5a each feature is cut at the quartiles of the TRAINING trades only",
          np.allclose(e, np.quantile(X["F0"].to_numpy(float)[tr & X["F0"].notna().to_numpy()], [0.25, 0.5, 0.75])) and
          not np.allclose(e, np.nanquantile(X["F0"].to_numpy(float), [0.25, 0.5, 0.75])), e)
    check(f"s5 the search = setuplab's zone_screen on the 12 zone measures ({len(ref):,} candidates: trades and mean "
          "identical); one candidate's sessions and yearly means by hand", same and by_hand, (len(ref), len(mine)))
    # eligibility and the overlap rule by hand
    fake = {"keys": [(("F0", 0, 0),), (("F0", 0, 0), ("F2", 0, 0)), (("F1", 3, 3),), (("F2", 3, 3),)],
            "n": np.array([200, 400, 200, 50]), "mean": np.array([3.0, 2.5, 2.0, 9.0]), "ses": np.array([40, 60, 40, 30]),
            "years": np.array([2020, 2021, 2022]), "yn": np.full((3, 4), 30), "ymean": np.ones((3, 4))}
    Bf = {"F0": np.repeat([0, 1, 2, 3], 100).astype(np.int8), "F1": np.tile([0, 1, 2, 3], 100).astype(np.int8),
          "F2": np.zeros(400, np.int8)}
    ch, _, ne, sk = choose(fake, Bf, top=5)
    fake2 = dict(fake, ymean=np.array([[1, 1, 1, 1], [1, 1, -1, 1], [1, 1, 1, 1]], float))
    ch2, _, _, _ = choose(fake2, Bf, top=5)
    check("s6 choosing by hand: best mean first; too few trades out; a near-copy of a chosen filter (more than half "
          "inside it) skipped; a losing training year out", ch == [0, 2] and ne == 3 and sk == 1 and ch2 == [0],
          (ch, ne, sk, ch2))
    rr = holm([{"p": 0.004, "rule": "HOLDS"}, {"p": 0.02, "rule": "HOLDS"}, {"p": 0.0001, "rule": "NOT HELD"}])
    cal2 = np.array(["2023-01-02", "2023-01-03", "2023-01-04", "2023-01-05", "2023-01-06", "2023-01-09"], "datetime64[D]")
    Xm = pd.DataFrame({"day": pd.to_datetime(["2023-01-02", "2023-01-02", "2023-01-03", "2023-01-05"]),
                       "net3": [2.0, 4.0, 10.0, -1.0], "b3": [0.5, 0.5, 1.0, -2.0]})
    M = money(Xm, np.ones(4, bool), cal2, 1.0)
    dj = pd.bdate_range("2023-01-02", periods=60)
    Xj = pd.DataFrame({"day": np.repeat(dj, 2), "net3": np.tile([2.0, 0.0], 60), "ex3": np.tile([-1.0, 0.0], 60)})
    ej = judge(SL, Xj, np.tile([True, False], 60))
    check("s7a judging: inside beats the rest but not buying everything -> NOT HELD, p = the larger of the two",
          ej["rule"] == "NOT HELD" and ej["p"] == max(ej["p_diff"], ej["p_chk"]) == 1.0 and ej["p_diff"] < 0.001, ej)
    check("s7 Holm and the money view by hand", rr[2]["final"] == "NOT HELD" and rr[0]["final"] == "HOLDS" and
          abs(rr[0]["holm_limit"] - 0.0125) < 1e-12 and M["basket"]["baskets"] == 2 and
          abs(M["basket"]["a_year"] - (1.03 * 0.99 - 1)) < 1e-12 and abs(M["everything"]["a_year"] - (1.005 * 0.98 - 1)) < 1e-12)
    r0, _ = study(SL, X, cal, feats, lambda *a: None)
    check("s8 absent world: no filter holds", not any(f["test"].get("final") == "HOLDS" for f in r0["filters"]),
          [(f["text"], f["test"].get("diff_lo")) for f in r0["filters"]])
    cond = lambda D: (D["F3"] > 0.6745) & (D["VIXP"] == 2)           # noqa: E731  (F3 in its top quarter, high VIX)
    root, W, P = _world(SL, tmp / "both", feats, plant=("all", cond, 4.0), seed=6)
    X, cal, _ = build(SL, root / "marks.parquet", root / "zones.parquet", root / "panel.parquet", feats, lambda *a: None)
    r1, _ = study(SL, X, cal, feats, lambda *a: None)
    f1 = r1["filters"][0] if r1["filters"] else {"key": "", "test": {}}
    check("s9 planted in every year (+4% when F3 is in its top quarter AND VIX is high): it is filter #1 and it HOLDS "
          "on 2023 on", "F3:3:3" in f1["key"] and "VIXP:2:2" in f1["key"] and f1["test"].get("final") == "HOLDS",
          [(f["key"], f["test"].get("final")) for f in r1["filters"]])
    root, W, P = _world(SL, tmp / "train", feats, plant=("train", cond, 4.0), seed=7)
    X, cal, _ = build(SL, root / "marks.parquet", root / "zones.parquet", root / "panel.parquet", feats, lambda *a: None)
    r2, _ = study(SL, X, cal, feats, lambda *a: None)
    f2 = r2["filters"][0] if r2["filters"] else {"key": "", "test": {}}
    check("s10 planted in 2020-2022 only: it is filter #1 and it does NOT hold later",
          "F3:3:3" in f2["key"] and "VIXP:2:2" in f2["key"] and f2["test"].get("final") != "HOLDS",
          [(f["key"], f["test"].get("final"), f["test"].get("diff_lo")) for f in r2["filters"]])
    out = tmp / "out"
    ins = {"cl_run": "CL_TEST", "marks_sha": sha256(root / "marks.parquet"), "zones_sha": sha256(root / "zones.parquet"),
           "panel": str(root / "panel.parquet")}
    run, _ = execute(SL, root / "marks.parquet", root / "zones.parquet", root / "panel.parquet", feats, out, decl, sha,
                     ins, lambda *a: None)
    hs = dict(x.split("  ", 1)[::-1] for x in (run / "outputs.sha256").read_text().splitlines() if x.strip())
    rep = (run / "REPORT.md").read_text(encoding="utf-8")
    try:
        out_base(str(tmp / "cache" / "x"), tmp / "cache")
        guard = False
    except CL2Error:
        guard = True
    check("s11 the run folder: verdict first, every file hashed, one ledger line; an output inside the cache refused",
          "## Verdict first" in rep and len(hs) == 6 and all(sha256(run / k) == v for k, v in hs.items()) and
          len((out / LEDGER).read_text().splitlines()) == 1 and guard)
    print("VERIFIED (cl2 v1.0)" if ok_all else "FAILED")
    return 0 if ok_all else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description="CL2: the 5 best filters for S2 + 3 or more setups (2020-2022 -> 2023 on)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check")
    sub.add_parser("selftest")
    r = sub.add_parser("run")
    r.add_argument("--root")
    r.add_argument("--clash", default=None, help="clashlab's output folder (default CLASHLAB_OUT)")
    r.add_argument("--setups", default=None, help="setuplab's output folder (default SETUPLAB_OUT)")
    r.add_argument("--features", default=None, help="the panel (default: the one the CL run used)")
    r.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['declared']})")
            return 0
        if a.cmd == "selftest":
            return selftest()
        return cmd_run(a)
    except (CL2Error, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
