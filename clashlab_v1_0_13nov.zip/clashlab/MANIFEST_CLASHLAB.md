# MANIFEST - clashlab v1.0 (13 Nov 2026)

Folder: C:\Users\karanvsi\PyCharmMiscProject\clashlab\ (tests in clashlab\tests\), beside tradelab and setuplab. A new tool: nothing else changes (bigmove_deploy, open_close, tradelab, setuplab are read only). Writes only under C:\QuantData\clashlab. Python with numpy, pandas, pyarrow; needs setuplab v1.1 (the installed one; clashlab checks for the functions it uses) and tradelab's tl_data on PYTHONPATH (env_clashlab.bat sets it).

| file | sha256 (first 16) | bytes | lines |
|---|---|---|---|
| clashlab.py | 9c3cb437f1f5d3ea | 35443 | 647 |
| CLASHLAB_DECLARATION.json | 8279f96553aaabc6 | 6487 | 71 |
| env_clashlab.bat | 69ad9ad5f5493207 | 1852 | 33 |
| README_CLASHLAB.md | 6a63362f7cff71a5 | 6706 | 102 |
| tests\test_clashlab.py | dfad620c7aa2719a | 29930 | 510 |

Declaration sha256 (pinned in clashlab.py): 8279f96553aaabc63c02bec1f3f4f0bd88b6b9131208e81f8bb831035a2639cc

Verified where it was built: 31 self-test checks, 0 failed; 39 planted bugs, each caught; 400 synthetic worlds for calibration (200 with no effect: the declared rule passed 0.0-2.0% per test before Holm).
