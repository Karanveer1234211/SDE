"""
clashlab.py - clashlab v1.0: do bars where 3 or more frozen setups clash continue well? (study CL1)

    python clashlab.py check                                  the declaration is the frozen one (sha256)
    python clashlab.py run --root %CACHE_DAILY_ROOT% [--setups %SETUPLAB_OUT%] [--features <panel.parquet>]
                           [--out <folder>] [--stage-e-any]   -> CLASHLAB_OUT\\runs\\CL_<date>_<nnn>

CLASHLAB_DECLARATION.json (beside this file, frozen 13 Nov 2026 before any run) holds the study:
  * a CLASH: (1) SAME BAR - 3 or more of the seven frozen setups enter at one open of one stock (the BM Setups Pine's
    triangle lists 3+ ids); (2) WITHIN 3 SESSIONS - 3 or more DIFFERENT setups enter one stock within 3 sessions,
    counted once, at the open that completes the cluster;
  * continuation: buy at that open, sell at the close 3, 5 or 10 sessions in (2, 4, 9 sessions later), 35 bp;
  * where: the whole universe (every stock-day of the panel from 2020 as a pseudo-pick - setuplab's whole-market
    engine, the Pine's marks) and BigMove's picks (D / ENS ranks 1-10, the frozen tags of setuplab's newest TAGS run);
  * PASS (each of the 12 = 2 places x 2 definitions x 3 holds): the clash entries beat buying every stock at the same
    open with the same hold (A) AND beat the entries where only 1-2 setups enter (B), both with a 95% interval above
    0; then Holm across the 12 (0.025, one-sided, on the larger of the two p-values). A PASS is a forward candidate.

READS (read only): the panel (the TAGS run's, or --features), every stock's daily bars through setuplab's LiveData
(tradelab's tl_data: production's loader), setuplab's newest TAGS run and, when present, its newest ZONES run (a
reconciliation only). WRITES only under --out / CLASHLAB_OUT.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

VERSION = "clashlab v1.0"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "CLASHLAB_DECLARATION.json"
DECL_SHA = "8279f96553aaabc63c02bec1f3f4f0bd88b6b9131208e81f8bb831035a2639cc"
LEDGER = "clashlab_ledger.jsonl"
ORDER = ("S1", "S2", "S3", "C1", "C2", "C3", "N1")
HOLDS = (3, 5, 10)
THRESH = 3
WINDOW = 3
COST = 0.35
FROM = np.datetime64("2020-01-01")
BLOCK, NBOOT, SEED, ALPHA = 10, 2000, 7, 0.025
DEFS = ("same_bar", "within_3")
PLACES = ("universe", "picks")
CHUNK = 100                     # stocks per batch of daily bars (memory)


class CLError(Exception):
    pass


def say(msg: str) -> None:
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def sha256(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


SL_NEEDS = ("LiveData", "align_panel", "atr_simple", "frozen_conds", "frozen_features", "latest_run", "load_frozen",
            "market_entries", "new_run_dir", "panel_frame", "read_hashed_run", "write_hashes")


def setuplab():
    try:
        import setuplab as SL
    except ImportError as e:
        raise CLError(f"cannot import setuplab ({e}) - start with env_clashlab.bat (it puts setuplab on PYTHONPATH)")
    miss = [k for k in SL_NEEDS if not hasattr(SL, k)]
    if miss:
        raise CLError(f"{getattr(SL, 'VERSION', 'setuplab')} lacks {', '.join(miss)} - clashlab needs setuplab v1.1")
    return SL


def load_decl(path: Path = DECL_FILE, check: bool = True) -> Tuple[dict, str]:
    if not Path(path).is_file():
        raise CLError(f"{path} is missing - it ships beside clashlab.py")
    sha = sha256(path)
    if check and sha != DECL_SHA:
        raise CLError(f"{path} has sha256 {sha[:16]}, not the frozen declaration's {DECL_SHA[:16]}. The declaration is "
                      f"fixed before any run; a changed study is a new declaration (ask Claude).")
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    r = d["rules"]
    if (tuple(r["holds"]) != HOLDS or r["threshold"] != THRESH or r["window_sessions"] != WINDOW or
            r["bootstrap"]["block_days"] != BLOCK or r["bootstrap"]["resamples"] != NBOOT or r["holm_alpha"] != ALPHA):
        raise CLError(f"{path}: its rules differ from this code's")
    return d, sha


def out_base(arg: Optional[str], root: Optional[Path]) -> Path:
    v = arg or os.environ.get("CLASHLAB_OUT")
    if not v:
        raise CLError("no output folder: pass --out or start with env_clashlab.bat (sets CLASHLAB_OUT)")
    b = Path(v).resolve()
    guards = ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                          ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise CLError(f"output folder {b} is inside {g}; clashlab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


# ---------------------------------------------------------------------------------------------------- counting
def window_counts(mask: np.ndarray, w: int = WINDOW) -> np.ndarray:
    """Distinct setups with an entry in the w sessions ending at each bar (the bar and the w-1 before it)."""
    n = len(mask)
    any_ = np.zeros_like(mask, dtype=bool)
    for lag in range(w):
        any_[lag:] |= mask[:n - lag] if lag else mask
    return any_.sum(axis=1)


def cluster_entries(nbar: np.ndarray, cw: np.ndarray, w: int = WINDOW, thr: int = THRESH) -> np.ndarray:
    """WITHIN-w clash entries: a bar where some setup enters, the w-session distinct count reaches thr, and no
    earlier entry bar in the w-1 sessions before already had it (one entry per cluster)."""
    n = len(nbar)
    hit = (nbar > 0) & (cw >= thr)
    out = hit.copy()
    for lag in range(1, w):
        prev = np.zeros(n, dtype=bool)
        prev[lag:] = hit[:n - lag]
        out &= ~prev
    return out


def forward(o: np.ndarray, c: np.ndarray, t: np.ndarray, h: int) -> np.ndarray:
    """Net % of buying at bar t's open and selling at the close h-1 bars later (35 bp); blank past the data."""
    t = np.asarray(t, dtype=np.int64)
    e = t + h - 1
    ok = e < len(c)
    out = np.full(len(t), np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        out[ok] = (c[e[ok]] / o[t[ok]] - 1) * 100 - COST
    out[~np.isfinite(out)] = np.nan
    return out


def stock_pass(SL, dates, o, h, l, c, F, have, setups: dict, d_from=FROM):
    """One stock: every setup entry bar (setuplab's whole-market engine = the Pine's marks), the clash counts, each
    entry bar's outcome for the holds, and the buy-everything outcomes (every open whose evening before had a panel
    row, from d_from) for the same-day benchmark."""
    dates = np.asarray(dates).astype("datetime64[D]")
    o, c = np.asarray(o, float), np.asarray(c, float)
    n = len(c)
    atrf = SL.atr_simple(h, l, c)
    d_ok = np.asarray(have, bool) & (dates >= d_from)
    ent = SL.market_entries(dates, o, c, F, atrf, setups, d_ok)
    mask = np.zeros((n, len(ORDER)), dtype=bool)
    for j, sid in enumerate(ORDER):
        if sid in ent and len(ent[sid]):
            mask[np.asarray(ent[sid], dtype=np.int64), j] = True
    nbar = mask.sum(axis=1)
    cw = window_counts(mask)
    clu = cluster_entries(nbar, cw)
    t = np.flatnonzero(nbar > 0)
    M = pd.DataFrame({"day": dates[t], "n": nbar[t], "cw": cw[t], "within": clu[t],
                      "setups": [" ".join(s for s, m in zip(ORDER, mask[i]) if m) for i in t]})
    for hh in HOLDS:
        M[f"net{hh}"] = forward(o, c, t, hh)
    i = np.arange(1, n) if n > 1 else np.array([], dtype=np.int64)
    i = i[np.asarray(have, bool)[i - 1] & (dates[i] >= d_from)] if len(i) else i
    bench = {hh: (dates[i], forward(o, c, i, hh)) for hh in HOLDS}
    return M, bench


def universe(SL, panel: Path, setups: dict, feats: List[str], ohlcv: Callable, forget: Callable, d_from=FROM,
             symbols=None, log=say) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Every stock in the panel: the entry bars (marks) with counts and outcomes, and the same-day benchmark per hold
    (the mean over every stock bought at that open)."""
    P, want = SL.panel_frame(str(panel), feats, d_from - np.timedelta64(400, "D"), symbols, log)
    idx = P.groupby("symbol", sort=False, observed=True).indices
    syms = sorted(idx)
    marks = []
    bs = {hh: pd.Series(dtype=float) for hh in HOLDS}
    bn = {hh: pd.Series(dtype=float) for hh in HOLDS}
    for k in range(0, len(syms), CHUNK):
        chunk = syms[k:k + CHUNK]
        bars = ohlcv(chunk)
        parts = {hh: [] for hh in HOLDS}
        for s in chunk:
            if s not in bars:
                continue
            dates, o, h, l, c = bars[s][:5]
            dates = np.asarray(dates).astype("datetime64[D]")
            F, have = SL.align_panel(P.iloc[idx[s]], want, dates)
            M, B = stock_pass(SL, dates, o, h, l, c, F, have, setups, d_from)
            if len(M):
                M.insert(0, "symbol", s)
                marks.append(M)
            for hh in HOLDS:
                d_, v_ = B[hh]
                ok = np.isfinite(v_)
                parts[hh].append(pd.DataFrame({"day": d_[ok], "v": v_[ok]}))
        for hh in HOLDS:
            if parts[hh]:
                X = pd.concat(parts[hh], ignore_index=True).groupby("day")["v"].agg(["sum", "count"])
                bs[hh] = bs[hh].add(X["sum"], fill_value=0)
                bn[hh] = bn[hh].add(X["count"], fill_value=0)
        forget(chunk)
        log(f" universe: {min(k + CHUNK, len(syms))} of {len(syms)} stocks")
    if not marks:
        raise CLError("no setup ever entered in the universe - check the panel and the bars")
    U = pd.concat(marks, ignore_index=True)
    bench = pd.DataFrame({f"b{hh}": bs[hh] / bn[hh] for hh in HOLDS})
    bench.index = pd.DatetimeIndex(bench.index).astype("datetime64[ns]")
    for hh in HOLDS:
        bench[f"n{hh}"] = bn[hh]
    U = add_excess(U, bench)
    return U, bench


def add_excess(U: pd.DataFrame, bench: pd.DataFrame) -> pd.DataFrame:
    X = U.copy()
    d = pd.DatetimeIndex(pd.to_datetime(X["day"])).astype("datetime64[ns]")
    for hh in HOLDS:
        X[f"ex{hh}"] = X[f"net{hh}"].to_numpy(float) - bench[f"b{hh}"].reindex(d).to_numpy(float)
    return X


# ---------------------------------------------------------------------------------------------------- the picks
def picks(SL, tags_dir: Path, ohlcv: Callable, forget: Callable, bench: pd.DataFrame, log=say) -> pd.DataFrame:
    """BigMove's picks (D / ENS ranks 1-10 of the TAGS run; a stock and signal day picked twice counts once, the
    lowest rank, D first): each watch day with a setup entry, its count of setups entering there, the WITHIN-3
    cluster entry, and the outcomes from that open (the stock's own bars) and from the D1 open."""
    SL.read_hashed_run(tags_dir, ["setup_tags.parquet", "setup_trades.parquet"])
    W = pd.read_parquet(Path(tags_dir) / "setup_tags.parquet", columns=["trade_id", "engine", "rank", "symbol",
                                                                         "signal_day"])
    L = pd.read_parquet(Path(tags_dir) / "setup_trades.parquet",
                        columns=["trade_id", "setup", "watch_day", "entry_date"])
    W = W[W["engine"].isin(["D", "ENS"]) & W["rank"].between(1, 10)].copy()
    W["eo"] = (W["engine"] != "D").astype(int)
    W = W.sort_values(["symbol", "signal_day", "rank", "eo"]).drop_duplicates(["symbol", "signal_day"])
    L = L[L["trade_id"].isin(set(W["trade_id"]))].merge(W[["trade_id", "engine", "rank", "symbol", "signal_day"]],
                                                         on="trade_id")
    if not len(L):
        raise CLError(f"{tags_dir}: no setup entries")
    G = L.groupby(["trade_id", "watch_day"]).agg(n=("setup", "nunique"), entry_date=("entry_date", "first"),
                                                 setups=("setup", lambda s: " ".join(x for x in ORDER if x in set(s))),
                                                 engine=("engine", "first"), rank=("rank", "first"),
                                                 symbol=("symbol", "first"), signal_day=("signal_day", "first"))
    G = G.reset_index().sort_values(["trade_id", "watch_day"])
    # WITHIN-3 on watch days: distinct setups entered in [k-2, k]; the first such k with an entry
    days_of: Dict[str, dict] = {}
    for tid_, s_, k_ in zip(L["trade_id"], L["setup"], L["watch_day"]):
        days_of.setdefault(tid_, {})[s_] = int(k_)
    cw = []
    for tid, k in zip(G["trade_id"], G["watch_day"]):
        dd = days_of[tid]
        cw.append(sum(1 for v in dd.values() if k - WINDOW < v <= k))
    G["cw"] = cw
    first = {}
    for tid, k, c_ in zip(G["trade_id"], G["watch_day"], G["cw"]):
        if c_ >= THRESH and tid not in first:
            first[tid] = k
    G["within"] = [first.get(t) == k for t, k in zip(G["trade_id"], G["watch_day"])]
    # outcomes from the stock's own bars: the watch day's open and the D1 open
    out = {f"net{hh}": np.full(len(G), np.nan) for hh in HOLDS}
    out.update({f"d1net{hh}": np.full(len(G), np.nan) for hh in HOLDS})
    syms = sorted(G["symbol"].unique())
    rows_of = pd.Series(np.arange(len(G))).groupby(G["symbol"].to_numpy()).indices
    for k0 in range(0, len(syms), CHUNK):
        chunk = syms[k0:k0 + CHUNK]
        bars = ohlcv(chunk)
        for s in chunk:
            if s not in bars:
                continue
            dates, o, h, l, c = bars[s][:5]
            dates = np.asarray(dates).astype("datetime64[D]")
            o, c = np.asarray(o, float), np.asarray(c, float)
            rr = np.asarray(rows_of[s], dtype=np.int64)
            ed = pd.to_datetime(G["entry_date"].to_numpy()[rr]).to_numpy().astype("datetime64[D]")
            j = np.searchsorted(dates, ed)
            hit = (j < len(dates))
            hit[hit] &= dates[j[hit]] == ed[hit]
            sd = pd.to_datetime(G["signal_day"].to_numpy()[rr]).to_numpy().astype("datetime64[D]")
            j1 = np.searchsorted(dates, sd, side="right")
            hit1 = j1 < len(dates)
            for hh in HOLDS:
                v = np.full(len(rr), np.nan)
                v[hit] = forward(o, c, j[hit], hh)
                out[f"net{hh}"][rr] = v
                v1 = np.full(len(rr), np.nan)
                v1[hit1] = forward(o, c, j1[hit1], hh)
                out[f"d1net{hh}"][rr] = v1
        forget(chunk)
    for k_, v_ in out.items():
        G[k_] = v_
    G["day"] = pd.to_datetime(G["entry_date"])
    return add_excess(G, bench)


# ---------------------------------------------------------------------------------------------------- statistics
def boot_weights(days: np.ndarray, B: int = NBOOT, block: int = BLOCK, seed: int = SEED) -> Tuple[np.ndarray, np.ndarray]:
    """Circular block bootstrap over the sorted distinct days: (the days, a B x days matrix of how often each day is
    drawn in each resample)."""
    ud = np.unique(np.asarray(days).astype("datetime64[D]"))
    D = len(ud)
    rng = np.random.default_rng(seed)
    nb = int(np.ceil(D / block))
    starts = rng.integers(0, D, size=(B, nb))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]).reshape(B, -1)[:, :D] % D
    Wm = np.zeros((B, D), dtype=np.float64)
    for b in range(B):
        Wm[b] = np.bincount(idx[b], minlength=D)
    return ud, Wm


def day_sums(ud, days, vals):
    di = np.searchsorted(ud, np.asarray(days).astype("datetime64[D]"))
    S = np.bincount(di, weights=vals, minlength=len(ud))
    N = np.bincount(di, minlength=len(ud)).astype(float)
    return S, N


def interval(x: np.ndarray) -> Tuple[float, float]:
    """The 2.5th and 97.5th percentiles of the resamples; a resample where a group had no entries (blank) is the worst
    case on each side, as p counts it at or below 0."""
    return (float(np.percentile(np.where(np.isfinite(x), x, -np.inf), 2.5, method="lower")),
            float(np.percentile(np.where(np.isfinite(x), x, np.inf), 97.5, method="higher")))


def test_one(days_c, ex_c, days_k, ex_k) -> dict:
    """A: the clash entries' mean excess over the same-day benchmark; B: minus the 1-2-setup entries' mean excess.
    95% circular block bootstrap (10-day blocks of entry days, 2,000 resamples, seed 7); one-sided p = (1 + resamples
    at or below 0 or blank) / 2,001."""
    okc, okk = np.isfinite(ex_c), np.isfinite(ex_k)
    days_c, ex_c, days_k, ex_k = days_c[okc], ex_c[okc], days_k[okk], ex_k[okk]
    r = {"n_clash": int(len(ex_c)), "n_comp": int(len(ex_k))}
    if len(ex_c) < 2 or len(ex_k) < 2:
        return dict(r, a=np.nan, a_lo=np.nan, a_hi=np.nan, p_a=np.nan, b=np.nan, b_lo=np.nan, b_hi=np.nan, p_b=np.nan)
    ud, Wm = boot_weights(np.concatenate([days_c, days_k]))
    Sc, Nc = day_sums(ud, days_c, ex_c)
    Sk, Nk = day_sums(ud, days_k, ex_k)
    with np.errstate(invalid="ignore", divide="ignore"):
        bc = (Wm @ Sc) / (Wm @ Nc)
        bk = (Wm @ Sk) / (Wm @ Nk)
    bd = bc - bk
    a, b = float(np.mean(ex_c)), float(np.mean(ex_c) - np.mean(ex_k))
    pa = (1 + np.sum(~(bc > 0))) / (len(bc) + 1)
    pb = (1 + np.sum(~(bd > 0))) / (len(bd) + 1)
    (alo, ahi), (blo, bhi) = interval(bc), interval(bd)
    return dict(r, a=a, a_lo=alo, a_hi=ahi, p_a=float(pa), b=b, b_lo=blo, b_hi=bhi, p_b=float(pb))


def groups(X: pd.DataFrame, definition: str) -> Tuple[np.ndarray, np.ndarray]:
    """(clash entries, comparison entries) for one definition: SAME BAR - n >= 3 vs n 1-2; WITHIN 3 - the cluster's
    completing entry vs entries whose 3-session distinct count is under 3."""
    if definition == "same_bar":
        return (X["n"] >= THRESH).to_numpy(), X["n"].between(1, THRESH - 1).to_numpy()
    return X["within"].to_numpy(bool), (X["cw"] < THRESH).to_numpy()


def all_tests(U: pd.DataFrame, PK: pd.DataFrame) -> List[dict]:
    rows = []
    for place, X in (("universe", U), ("picks", PK)):
        d = pd.to_datetime(X["day"]).to_numpy().astype("datetime64[D]")
        for df_ in DEFS:
            gc, gk = groups(X, df_)
            for hh in HOLDS:
                ex = X[f"ex{hh}"].to_numpy(float)
                r = test_one(d[gc], ex[gc], d[gk], ex[gk])
                r.update({"place": place, "definition": df_, "hold": hh,
                          "net_clash": float(np.nanmean(X[f"net{hh}"].to_numpy(float)[gc])) if gc.any() else np.nan,
                          "rule": "PASS" if (np.isfinite(r["a_lo"]) and r["a_lo"] > 0 and np.isfinite(r["b_lo"]) and
                                             r["b_lo"] > 0) else "FAIL",
                          "p": float(max(r["p_a"], r["p_b"])) if np.isfinite(r["p_a"]) else np.nan})
                rows.append(r)
    return holm(rows)


def holm(rows: List[dict], alpha: float = ALPHA) -> List[dict]:
    m = len(rows)
    order = sorted(range(m), key=lambda i: (np.inf if not np.isfinite(rows[i]["p"]) else rows[i]["p"], i))
    going = True
    out = [dict(r) for r in rows]
    for rank, i in enumerate(order):
        lim = alpha / (m - rank)
        keep = going and np.isfinite(out[i]["p"]) and out[i]["p"] <= lim
        going = keep
        out[i].update(holm_limit=lim, holm_kept=bool(keep), final="PASS" if keep and out[i]["rule"] == "PASS" else "FAIL")
    return out


# ---------------------------------------------------------------------------------------------------- descriptive
def dose(X: pd.DataFrame, place: str) -> pd.DataFrame:
    n5 = np.minimum(X["n"].to_numpy(), 5)
    rows = []
    for k in range(1, 6):
        m = n5 == k
        r = {"place": place, "setups_on_the_bar": f"{k}+" if k == 5 else str(k), "entries": int(m.sum())}
        for hh in HOLDS:
            r[f"net{hh}"] = float(np.nanmean(X[f"net{hh}"].to_numpy(float)[m])) if m.any() else np.nan
            r[f"ex{hh}"] = float(np.nanmean(X[f"ex{hh}"].to_numpy(float)[m])) if m.any() else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


def composition(X: pd.DataFrame, place: str) -> pd.DataFrame:
    """The clash and comparison entries with and without S2 - the only frozen setup that reads the entry bar's own open
    (a gap down), so the one whose edge could come from the open itself rather than from the clash."""
    s2 = X["setups"].str.split(" ").map(lambda s: "S2" in s).to_numpy(bool)
    rows = []
    for df_ in DEFS:
        for grp, m0 in zip(("clash", "comparison"), groups(X, df_)):
            for lab, m in (("with S2", m0 & s2), ("without S2", m0 & ~s2)):
                r = {"place": place, "definition": df_, "group": grp, "S2": lab, "entries": int(m.sum())}
                for hh in HOLDS:
                    v = X[f"ex{hh}"].to_numpy(float)[m]
                    r[f"ex{hh}"] = float(np.nanmean(v)) if np.isfinite(v).any() else np.nan
                rows.append(r)
    return pd.DataFrame(rows)


def by_year(X: pd.DataFrame, place: str) -> pd.DataFrame:
    y = pd.to_datetime(X["day"]).dt.year.to_numpy()
    rows = []
    for df_ in DEFS:
        gc, gk = groups(X, df_)
        for yr in sorted(set(y)):
            m, k = gc & (y == yr), gk & (y == yr)
            rows.append({"place": place, "definition": df_, "year": int(yr), "clash": int(m.sum()),
                         "clash_ex5": float(np.nanmean(X["ex5"].to_numpy(float)[m])) if m.any() else np.nan,
                         "comp_ex5": float(np.nanmean(X["ex5"].to_numpy(float)[k])) if k.any() else np.nan})
    return pd.DataFrame(rows)


def reconcile_zones(U: pd.DataFrame, Z: Optional[pd.DataFrame]) -> dict:
    """The newest ZONES run's whole-market setup trades (symbol, setup, day, net held 5 sessions) against these marks,
    within the ZONES run's days - a check that the marks are setuplab's own (the data may have grown since)."""
    if Z is None:
        return {"used": False}
    Z = Z[["symbol", "setup", "day", "net"]].copy()
    Z["day"] = pd.to_datetime(Z["day"]).dt.normalize()
    last = Z["day"].max()
    E = U[["symbol", "day", "setups", "net5"]].copy()
    E["day"] = pd.to_datetime(E["day"]).dt.normalize()
    E = E[(E["day"] <= last) & np.isfinite(E["net5"])]
    E = E.assign(setup=E["setups"].str.split(" ")).explode("setup")[["symbol", "setup", "day", "net5"]]
    M = Z.merge(E, on=["symbol", "setup", "day"], how="outer", indicator=True)
    both = M["_merge"] == "both"
    same = both & (np.abs(M["net"] - M["net5"]) < 1e-6)
    return {"used": True, "zones_rows": int(len(Z)), "marks_rows": int(len(E)), "matched": int(same.sum()),
            "share_of_zones": float(same.sum() / max(len(Z), 1)), "share_of_marks": float(same.sum() / max(len(E), 1)),
            "last_day": str(last.date())}


# ---------------------------------------------------------------------------------------------------- report
def _f(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "-"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


def report(T: List[dict], decl: dict, sha: str, info: dict, Dz: pd.DataFrame, Yr: pd.DataFrame, rec: dict,
           PK: pd.DataFrame, secs: float, Cz: pd.DataFrame) -> str:
    fin = [r for r in T if r["final"] == "PASS"]
    L = [f"# clashlab - {decl['name']} ({VERSION})", "",
         f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). Panel `{info['panel']}`; "
         f"TAGS run {info['tags_run']}; universe {info['stocks']:,} stocks, {info['marks']:,} setup entry bars from "
         f"{info['from']}; picks: {info['picks']:,} pick-days with a setup entry. {secs:.0f} s.", "",
         "## Verdict first", ""]
    if fin:
        L.append("**FINAL PASS: " + "; ".join(f"{r['place']} {r['definition']} {r['hold']} sessions" for r in fin) +
                 ".** A forward candidate only (the declaration's rule) - nothing changes in the frozen tree, setups "
                 "or paper ledger.")
    else:
        L.append("**No test passes.** Clash bars do not beat both buying every stock at the same open and the entries "
                 "where only 1-2 setups enter, after Holm across the 12 tests. The clash question closes for this "
                 "history (the declaration's rule).")
    L += ["", "Excess = the entry's net minus the mean net of buying EVERY stock at the same open with the same hold "
              "(both after 35 bp). A = the clash entries' mean excess; B = A minus the 1-2-setup entries' mean excess. "
              "Intervals: 95% circular block bootstrap, 10-day blocks of entry days. Holm across all 12 on the larger p.",
          "", "| place | clash | hold | clash entries | comparison | net % | A excess % | 95% | B vs 1-2 % | 95% | p | "
              "Holm limit | rule | FINAL |", "|---|---|---:|---:|---:|---:|---:|---|---:|---|---:|---:|---|---|"]
    for r in T:
        L.append(f"| {r['place']} | {r['definition'].replace('_', ' ')} | {r['hold']} | {r['n_clash']:,} | "
                 f"{r['n_comp']:,} | {_f(r['net_clash'])} | {_f(r['a'])} | [{_f(r['a_lo'])}, {_f(r['a_hi'])}] | "
                 f"{_f(r['b'])} | [{_f(r['b_lo'])}, {_f(r['b_hi'])}] | {_f(r['p'], 4, False)} | "
                 f"{_f(r['holm_limit'], 5, False)} | {r['rule']} | **{r['final']}** |")
    L += ["", "## How many setups on the bar (descriptive)", "",
          "| place | setups entering | entries | net 3 | excess 3 | net 5 | excess 5 | net 10 | excess 10 |",
          "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in Dz.to_dict("records"):
        L.append(f"| {r['place']} | {r['setups_on_the_bar']} | {r['entries']:,} | {_f(r['net3'])} | {_f(r['ex3'])} | "
                 f"{_f(r['net5'])} | {_f(r['ex5'])} | {_f(r['net10'])} | {_f(r['ex10'])} |")
    L += ["", "## With and without S2 (descriptive)", "",
          "S2 is the only frozen setup that reads the entry bar's own open (a gap down). In a synthetic world where "
          "gap-down opens bounce back, these tests passed with no clash effect at all, through S2 alone - an edge that "
          "lives only in the 'with S2' rows is the gap, not the clash.", "",
          "| place | clash | group | S2 | entries | excess 3 % | excess 5 % | excess 10 % |",
          "|---|---|---|---|---:|---:|---:|---:|"]
    for r in Cz.to_dict("records"):
        L.append(f"| {r['place']} | {r['definition'].replace('_', ' ')} | {r['group']} | {r['S2']} | "
                 f"{r['entries']:,} | {_f(r['ex3'])} | {_f(r['ex5'])} | {_f(r['ex10'])} |")
    L += ["", "## By year, 5-session hold (descriptive)", "",
          "| place | clash | year | clash entries | clash excess % | 1-2 excess % |", "|---|---|---:|---:|---:|---:|"]
    for r in Yr.to_dict("records"):
        L.append(f"| {r['place']} | {r['definition'].replace('_', ' ')} | {r['year']} | {r['clash']:,} | "
                 f"{_f(r['clash_ex5'])} | {_f(r['comp_ex5'])} |")
    if len(PK):
        L += ["", "## Picks: clash entries against the D1 open on the same picks (descriptive)", "",
              "| clash | hold | entries | clash net % | D1 open net % | difference % | of which ranks 1-3 |",
              "|---|---:|---:|---:|---:|---:|---:|"]
        for df_ in DEFS:
            gc, _ = groups(PK, df_)
            for hh in HOLDS:
                a_, b_ = PK[f"net{hh}"].to_numpy(float)[gc], PK[f"d1net{hh}"].to_numpy(float)[gc]
                m = np.isfinite(a_) & np.isfinite(b_)
                r3 = int((gc & (PK["rank"].to_numpy() <= 3)).sum())
                L.append(f"| {df_.replace('_', ' ')} | {hh} | {int(m.sum()):,} | {_f(np.mean(a_[m]) if m.any() else np.nan)}"
                         f" | {_f(np.mean(b_[m]) if m.any() else np.nan)} | "
                         f"{_f(np.mean(a_[m] - b_[m]) if m.any() else np.nan)} | {r3:,} |")
    L += ["", "## Reconciliation with setuplab's whole-market study", ""]
    if rec.get("used"):
        L.append(f"The newest ZONES run's setup trades (to {rec['last_day']}): {rec['matched']:,} of "
                 f"{rec['zones_rows']:,} matched here with the same 5-session net ({rec['share_of_zones']:.2%}); of "
                 f"these marks in that window, {rec['share_of_marks']:.2%} are in it. "
                 + ("" if rec["share_of_zones"] >= 0.99 else "**WARNING: under 99% - send Claude this report.**"))
    else:
        L.append("No ZONES run with market_zone_trades.parquet under SETUPLAB_OUT - not reconciled (the marks are "
                 "setuplab's own market_entries).")
    L += ["", "## What this is not", "",
          "History already seen (2020-2026). The setups were found on BigMove's picks; the universe is new ground for "
          "them, but the clash idea came from looking at charts. A FINAL PASS is a forward candidate; adoption needs "
          "forward evidence. Nothing here changes the frozen tree, the setups or the paper ledger.", "",
          "Not proof that the clash itself matters: a 3+ clash is a deeper dip in a bad week, so a pass may be the dip "
          "bouncing (or a high-beta stock in a rising market) rather than the clash, and it includes S2's gap-down open "
          "more often. The dose and S2 tables are the first look; separating these is a follow-up study.", ""]
    return "\n".join(L)


# ---------------------------------------------------------------------------------------------------- run
def execute(decl: dict, sha: str, panel: Path, tags_dir: Path, zones_file: Optional[Path], bout: Path,
            ohlcv: Callable, forget: Callable, frozen=None, symbols=None, t0=None) -> Tuple[int, Path]:
    t0 = t0 or dt.datetime.now()
    SL = setuplab()
    fp, fdoc = SL.load_frozen(frozen)
    conds, feats = SL.frozen_conds(fdoc), SL.frozen_features(fdoc)
    if tuple(conds) != ORDER:
        raise CLError(f"{fp}: the frozen setups are not {ORDER}")
    say(f" the universe: every stock-day of the panel from {FROM} (setuplab's whole-market engine)")
    U, bench = universe(SL, panel, conds, feats, ohlcv, forget, FROM, symbols)
    say(f" the picks: setuplab's TAGS run {tags_dir.name}")
    PK = picks(SL, tags_dir, ohlcv, forget, bench)
    T = all_tests(U, PK)
    Dz = pd.concat([dose(U, "universe"), dose(PK, "picks")], ignore_index=True)
    Yr = pd.concat([by_year(U, "universe"), by_year(PK, "picks")], ignore_index=True)
    Cz = pd.concat([composition(U, "universe"), composition(PK, "picks")], ignore_index=True)
    Z = None
    if zones_file is not None:
        SL.read_hashed_run(zones_file.parent, [zones_file.name])
        Z = pd.read_parquet(zones_file)
    rec = reconcile_zones(U, Z)
    run = SL.new_run_dir(bout / "runs", "CL")
    secs = (dt.datetime.now() - t0).total_seconds()
    info = {"panel": str(panel), "tags_run": tags_dir.name, "stocks": int(U["symbol"].nunique()), "marks": int(len(U)),
            "from": str(FROM), "picks": int(len(PK))}
    (run / "REPORT.md").write_text(report(T, decl, sha, info, Dz, Yr, rec, PK, secs, Cz), encoding="utf-8")
    pd.DataFrame(T).to_csv(run / "tests.csv", index=False, float_format="%.10g")
    Dz.to_csv(run / "dose.csv", index=False, float_format="%.10g")
    Yr.to_csv(run / "by_year.csv", index=False, float_format="%.10g")
    Cz.to_csv(run / "composition.csv", index=False, float_format="%.10g")
    U.to_parquet(run / "universe_marks.parquet", index=False)
    PK.to_parquet(run / "picks_marks.parquet", index=False)
    bench.reset_index(names="day").to_parquet(run / "bench.parquet", index=False)
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    rj = {"tool": VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "declaration_sha256": sha,
          "frozen_sha256": fdoc["sha256"], **info, "zones": rec, "seconds": round(secs, 1),
          "final_pass": [f"{r['place']} {r['definition']} {r['hold']}" for r in T if r["final"] == "PASS"]}
    (run / "run.json").write_text(json.dumps(rj, indent=1, default=str), encoding="utf-8")
    names = ["REPORT.md", "tests.csv", "dose.csv", "composition.csv", "by_year.csv", "universe_marks.parquet",
             "picks_marks.parquet", "bench.parquet", "DECLARATION.json", "run.json"]
    SL.write_hashes(run, names)
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "event": "run",
                            "run": run.name, "declaration_sha256": sha, "tests": [
                                {k: r[k] for k in ("place", "definition", "hold", "a", "b", "p", "rule", "final")}
                                for r in T]}, default=str) + "\n")
    say(f"wrote {run}")
    fin = [r for r in T if r["final"] == "PASS"]
    say("RESULT: " + ("FINAL PASS - " + "; ".join(f"{r['place']} {r['definition']} {r['hold']}" for r in fin)
                      if fin else "no test passes") + " (REPORT.md has every number)")
    return 0, run


def cmd_run(a) -> int:
    t0 = dt.datetime.now()
    decl, sha = load_decl()
    SL = setuplab()
    root = Path(a.root) if a.root else None
    if root is None or not root.is_dir():
        raise CLError("--root must be the daily cache (%CACHE_DAILY_ROOT%)")
    base = Path(a.setups or os.environ.get("SETUPLAB_OUT") or "")
    if not str(base) or not base.is_dir():
        raise CLError("setuplab's output folder: pass --setups or start with env_clashlab.bat (sets SETUPLAB_OUT)")
    tags_dir = SL.latest_run(base, "TAGS", ["setup_tags.parquet", "setup_trades.parquet"])
    if tags_dir is None:
        raise CLError(f"no TAGS run under {base}")
    meta = json.loads((tags_dir / "TAGS.json").read_text(encoding="utf-8")) if (tags_dir / "TAGS.json").is_file() else {}
    panel = Path(a.features) if a.features else Path(meta.get("panel", ""))
    if not panel.is_file():
        raise CLError(f"the panel the TAGS run used is not at {panel} - pass --features <panel.parquet>")
    zr = SL.latest_run(base, "ZONES", ["market_zone_trades.parquet"])
    bout = out_base(a.out, root)
    say(f"{VERSION} run | declaration {sha[:16]} | panel {panel} | tags {tags_dir.name} | zones "
        f"{zr.name if zr else '-'} | out {bout}")
    data = SL.LiveData(str(root), a.stage_e_any, panel=None)
    return execute(decl, sha, panel, tags_dir, (zr / "market_zone_trades.parquet") if zr else None, bout, data.ohlcv,
                   data.forget, t0=t0)[0]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="clashlab: do bars where 3+ frozen setups clash continue well? (CL1)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="the declaration is the frozen one")
    r = sub.add_parser("run", help="the study: the universe and the picks, 12 declared tests, Holm")
    r.add_argument("--root")
    r.add_argument("--setups", default=None)
    r.add_argument("--features", default=None)
    r.add_argument("--out", default=None)
    r.add_argument("--stage-e-any", action="store_true")
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['name']}, declared {d['declared']}): 12 tests "
                f"(universe and picks x same bar / within 3 sessions x holds {', '.join(map(str, HOLDS))}), Holm "
                f"{ALPHA}")
            return 0
        return cmd_run(a)
    except CLError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
