@echo off
rem env_clashlab.bat - clashlab v1.0 (do bars where 3+ frozen setups clash continue well? study CL1): start a session.
rem   call C:\Users\karanvsi\PyCharmMiscProject\clashlab\env_clashlab.bat
rem Reads production (the daily cache and stage E's bar loader through setuplab and tradelab's tl_data) and setuplab's
rem runs READ ONLY. Writes only under CLASHLAB_OUT. Edit the paths below if your folders differ.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "SETUPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\setuplab"
set "SETUPLAB_OUT=C:\QuantData\setuplab"
set "CLASHLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\clashlab"
set "CLASHLAB_OUT=C:\QuantData\clashlab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_data.py" goto :no_tradelab
if not exist "%SETUPLAB_DIR%\setuplab.py" goto :no_setuplab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%CLASHLAB_DIR%;%TRADELAB_DIR%;%SETUPLAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%CLASHLAB_OUT%" mkdir "%CLASHLAB_OUT%"
cd /d "%CLASHLAB_DIR%"
echo clashlab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   SETUPLAB_OUT=%SETUPLAB_OUT%   CLASHLAB_OUT=%CLASHLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_clashlab.bat
exit /b 1
:no_tradelab
echo ERROR: %TRADELAB_DIR%\tl_data.py not found - setuplab loads the daily bars through tradelab's tl_data (edit TRADELAB_DIR)
exit /b 1
:no_setuplab
echo ERROR: %SETUPLAB_DIR%\setuplab.py not found - clashlab finds the setup entries with setuplab's engine (edit SETUPLAB_DIR)
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
