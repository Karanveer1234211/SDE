"""
tests/test_clashlab.py - clashlab v1.0 self-test (study CL1).

    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\clashlab
    python tests\\test_clashlab.py

Counts, windows, outcomes, benchmarks, the bootstrap and Holm by hand; the picks by hand from a small TAGS run; a
synthetic universe run through setuplab's own whole-market engine where continuation is PLANTED after 3+ clash bars
(it must pass), where it is ABSENT (nothing may pass), and where gap-down opens bounce back (the S2 table must show
it); batches; the run folder. Ends 'VERIFIED (clashlab v1.0)'.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import shutil
import sys
import tempfile
import types
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import clashlab as CL  # noqa: E402

SL = CL.setuplab()
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(("  ok   " if ok else "  FAIL ") + name + ("" if ok else f"   <- {str(detail)[:900]}"), flush=True)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        out = fn(*a, **k)
    return out, buf.getvalue()


# ---------------------------------------------------------------------------------------------------- 1
def t1_declaration():
    d, sha = CL.load_decl()
    check("t1a the declaration is the pinned one; its rules = the code's (threshold 3, window 3, holds 3/5/10, "
          "10-day blocks, 2,000 resamples, Holm 0.025)", sha == CL.DECL_SHA and d["rules"]["threshold"] == 3)
    with tempfile.TemporaryDirectory() as t:
        p = Path(t) / "D.json"
        p.write_text(CL.DECL_FILE.read_text(encoding="utf-8").replace('"threshold": 3', '"threshold": 2'),
                     encoding="utf-8")
        try:
            CL.load_decl(p)
            ok = False
        except CL.CLError:
            ok = True
        check("t1b a changed declaration is refused", ok)
        p.write_text(CL.DECL_FILE.read_text(encoding="utf-8").replace('"declared": "2026-11-13"', '"declared": "2026-11-14"'),
                     encoding="utf-8")
        try:
            CL.load_decl(p)
            ok = False
        except CL.CLError as e:
            ok = "sha256" in str(e)
        check("t1d a declaration changed anywhere (not only its rules) is refused by its sha256", ok)
    rc, out = quiet(CL.main, ["check"])
    check("t1c 'clashlab.py check' says OK", rc == 0 and "OK" in out, out)
    real = sys.modules.get("setuplab")
    sys.modules["setuplab"] = types.SimpleNamespace(VERSION="setuplab v0.6")
    try:
        CL.setuplab()
        ok = False
    except CL.CLError as e:
        ok = "needs setuplab v1.1" in str(e) and "market_entries" in str(e)
    finally:
        sys.modules["setuplab"] = real
    check("t1e an older setuplab (without the functions clashlab uses) is refused, naming what is missing", ok)


# ---------------------------------------------------------------------------------------------------- 2
def t2_counting():
    names = {s: j for j, s in enumerate(CL.ORDER)}
    marks = {0: ["S1"], 1: ["S2"], 2: ["C1"], 3: ["C2"], 6: ["S1", "S2", "S3"], 7: ["N1"], 9: ["C3"], 11: ["S1"],
             12: ["S1"], 13: ["S1"]}
    mask = np.zeros((14, 7), bool)
    for b, ss in marks.items():
        for s in ss:
            mask[b, names[s]] = True
    nbar = mask.sum(1)
    cw = CL.window_counts(mask)
    ce = CL.cluster_entries(nbar, cw)
    check("t2a the 3-session count of DIFFERENT setups by hand (a setup repeated in the window counts once)",
          list(cw) == [1, 2, 3, 3, 2, 1, 3, 4, 4, 2, 1, 2, 1, 1], list(cw))
    check("t2b WITHIN 3: the entry bar completing the cluster, once per cluster (bars 2 and 6; not 3 or 7)",
          list(np.flatnonzero(ce)) == [2, 6], list(np.flatnonzero(ce)))
    check("t2c SAME BAR: the bars where 3+ setups enter (bar 6 only)", list(np.flatnonzero(nbar >= 3)) == [6])


# ---------------------------------------------------------------------------------------------------- 3
def t3_outcomes():
    o = np.array([100, 101, 102, 103, 104, 105, 106, 107, 108, 109.0])
    c = np.array([100.5, 101.5, 102.5, 103.5, 104.5, 105.5, 106.5, 107.5, 108.5, 109.5])
    f = CL.forward(o, c, np.array([0, 5, 8]), 3)
    exp = [(102.5 / 100 - 1) * 100 - 0.35, (107.5 / 105 - 1) * 100 - 0.35, np.nan]
    check("t3a the outcome by hand: the entry bar's open to the close 2 bars later (3 sessions), 35 bp; past the "
          "data = blank", np.allclose(f, exp, equal_nan=True), f)
    # stock_pass with a stand-in engine: the marks, counts, outcomes and the buy-everything rows by hand
    seen = {}
    stub = types.SimpleNamespace(
        atr_simple=lambda h, l, c: np.full(len(c), 0.02),
        market_entries=lambda dates, o, c, F, atrf, setups, d_ok: seen.update(d_ok=np.array(d_ok)) or {
            "S1": np.array([2, 6]), "S2": np.array([6]), "C1": np.array([6]), "N1": np.array([3])})
    dates = (np.datetime64("2023-12-25") + np.arange(10)).astype("datetime64[D]")
    have = np.array([1, 1, 1, 0, 1, 1, 1, 1, 1, 1], bool)
    M, B = CL.stock_pass(stub, dates, o, o + 1, o - 1, c, {}, have, {}, d_from=np.datetime64("2023-12-27"))
    ok_m = (list(M["n"]) == [1, 1, 3] and list(M["setups"]) == ["S1", "N1", "S1 S2 C1"] and
            list(M["within"]) == [False, False, True] and np.allclose(M["net5"], CL.forward(o, c, np.array([2, 3, 6]), 5),
                                                                     equal_nan=True))
    bi = np.array([2, 3, 5, 6, 7, 8, 9])            # opens from d_from whose evening before had a panel row (not 4)
    ok_b = (list(B[5][0]) == list(dates[bi]) and np.allclose(B[5][1], CL.forward(o, c, bi, 5), equal_nan=True) and
            np.array_equal(seen["d_ok"], have & (dates >= np.datetime64("2023-12-27"))))
    check("t3b one stock by hand: entry bars with their setups and counts, the WITHIN-3 entry, the outcomes; the "
          "buy-everything rows = every open from the start whose evening before had a panel row; the engine gets the "
          "days with a panel row from the start", ok_m and ok_b,
          (M.to_dict("list"), B[5]))
    bench = pd.DataFrame({"b3": [1.0], "b5": [2.0], "b10": [3.0]}, index=pd.DatetimeIndex(["2023-12-31"]))
    X = CL.add_excess(pd.DataFrame({"day": pd.to_datetime(["2023-12-31", "2024-01-01"]), "net3": [5.0, 5.0],
                                    "net5": [5.0, 5.0], "net10": [5.0, 5.0]}), bench)
    check("t3c excess = net minus the same day's benchmark (blank without one)",
          np.allclose(X[["ex3", "ex5", "ex10"]].to_numpy(), [[4, 3, 2], [np.nan] * 3], equal_nan=True))


# ---------------------------------------------------------------------------------------------------- 4
def t4_stats():
    d = pd.date_range("2022-01-03", periods=60, freq="B").to_numpy().astype("datetime64[D]")
    r = CL.test_one(d, np.ones(60), d, np.zeros(60))
    check("t4a a sure effect: A = +1 and B = +1 with intervals [1, 1], p = 1/2,001",
          r["a"] == 1 and r["a_lo"] == 1 and r["b_lo"] == 1 and abs(r["p_a"] - 1 / 2001) < 1e-12 and
          abs(r["p_b"] - 1 / 2001) < 1e-12, r)
    rng = np.random.default_rng(3)
    r2 = CL.test_one(d, rng.normal(0, 1, 60), d, rng.normal(0, 1, 60))
    check("t4b noise: both intervals hold 0 and p is far from significant",
          r2["a_lo"] < 0 < r2["a_hi"] and r2["b_lo"] < 0 < r2["b_hi"] and r2["p_a"] > 0.05, r2)
    ud, W = CL.boot_weights(d)
    ud2, W2 = CL.boot_weights(d)
    check("t4c the bootstrap: every resample draws as many days as there are (10-day circular blocks), seeded",
          W.shape == (2000, 60) and np.all(W.sum(1) == 60) and np.array_equal(W, W2) and W.max() <= 6 and
          (W > 0).sum(1).min() >= 10, (W.max(), (W > 0).sum(1).min()))
    r3 = CL.test_one(d[[5, 5]], np.array([5.0, 5.0]), d, np.zeros(60))
    check("t4e a clash group on one day only: resamples that miss it count against it (p about a third; neither "
          "interval above 0)", r3["p_a"] > 0.25 and r3["p_b"] > 0.25 and not r3["a_lo"] > 0 and not r3["b_lo"] > 0, r3)
    rows = [{"p": p, "rule": "PASS"} for p in (0.0001, 0.0019, 0.0024, 0.003, 0.2, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.0)]
    rows[1]["rule"] = "FAIL"
    H = CL.holm(rows)
    exp_lim = [0.025 / 12, 0.025 / 11, 0.025 / 10, 0.025 / 9]
    ok = (all(abs(H[i]["holm_limit"] - exp_lim[i]) < 1e-15 for i in range(4)) and H[0]["final"] == "PASS" and
          H[1]["holm_kept"] and H[1]["final"] == "FAIL" and H[2]["holm_kept"] and H[2]["final"] == "PASS" and
          not H[3]["holm_kept"] and not any(r["holm_kept"] for r in H[3:]))
    H2 = CL.holm([{"p": p, "rule": "PASS"} for p in [0.0001, 0.0023, 0.0024] + [0.5] * 9])
    ok = ok and H2[0]["holm_kept"] and not H2[1]["holm_kept"] and not H2[2]["holm_kept"]
    check("t4d Holm by hand: step-down across 12 (0.025/12, /11, ...), stops at the first miss (0.0024 under 0.025/10 "
          "is not kept after a miss), a kept rule FAIL stays FAIL", ok,
          [(r["p"], r["holm_limit"], r["holm_kept"], r["final"]) for r in H[:4] + H2[:3]])
    rows = []
    for t in d:
        rows += [dict(day=t, n=3, cw=3, within=True, v=1.0), dict(day=t, n=1, cw=1, within=False, v=0.0),
                 dict(day=t, n=2, cw=2, within=False, v=0.0), dict(day=t, n=1, cw=3, within=False, v=0.0)]
    X = pd.DataFrame(rows)
    for hh in CL.HOLDS:
        X[f"net{hh}"] = X["v"]
        X[f"ex{hh}"] = X["v"]
    T1 = CL.all_tests(X, X)
    X2 = X.copy()
    for hh in CL.HOLDS:
        X2[f"ex{hh}"] = 1.0
    T2 = CL.all_tests(X2, X2)
    ok1 = (len(T1) == 12 and all(r["rule"] == "PASS" and r["final"] == "PASS" and r["n_clash"] == 60 and
                                 r["n_comp"] == (180 if r["definition"] == "same_bar" else 120) for r in T1))
    ok2 = all(r["rule"] == "FAIL" and r["final"] == "FAIL" and r["a_lo"] == 1 and r["p"] == max(r["p_a"], r["p_b"]) == 1
              for r in T2)
    check("t4f the 12 tests by hand: clash = 3+ on the bar / the cluster's completing bar; comparison = 1-2 on the bar "
          "/ a 3-session count under 3 (a cluster's later bar is in neither); A and B both needed (A alone FAILS); p = "
          "the larger", ok1 and ok2, ([(r["definition"], r["n_clash"], r["n_comp"], r["rule"]) for r in T1[:6]],
                                      [(r["rule"], r["a_lo"], r["b_lo"], r["p"]) for r in T2[:3]]))


# ---------------------------------------------------------------------------------------------------- 5 picks
def write_tags(folder: Path, tags: pd.DataFrame, trades: pd.DataFrame):
    folder.mkdir(parents=True, exist_ok=True)
    tags.to_parquet(folder / "setup_tags.parquet", index=False)
    trades.to_parquet(folder / "setup_trades.parquet", index=False)
    (folder / "outputs.sha256").write_text("".join(
        f"{hashlib.sha256((folder / f).read_bytes()).hexdigest()}  {f}\n" for f in ("setup_tags.parquet",
                                                                                    "setup_trades.parquet")))


def t5_picks():
    days = pd.bdate_range("2024-01-01", periods=40)
    bars = {}
    for i, s in enumerate(("AAA", "BBB", "CCC")):
        c = 100 + i * 10 + np.arange(40) * (1 + i)
        o = c - 0.5
        bars[s] = (np.asarray(days).astype("datetime64[D]"), o.astype(float), c + 1.0, o - 1.0, c.astype(float),
                   np.ones(40))
    D = lambda k: str(days[k].date())  # noqa: E731
    tags = pd.DataFrame({"trade_id": ["D-a-1", "ENS-a-2", "D-b-4", "ENS-b-4", "ENS-c-1", "D-c-3", "D-a-11", "D-d-2"],
                         "engine": ["D", "ENS", "D", "ENS", "ENS", "D", "D", "D"], "rank": [1, 2, 4, 4, 1, 3, 11, 2],
                         "symbol": ["AAA", "AAA", "BBB", "BBB", "CCC", "CCC", "AAA", "BBB"],
                         "signal_day": [D(4), D(4), D(9), D(9), D(14), D(14), D(20), D(24)]})
    tr = [("D-a-1", "S1", 2, D(6)), ("D-a-1", "S2", 2, D(6)), ("D-a-1", "C1", 2, D(6)), ("D-a-1", "N1", 4, D(8)),
          ("ENS-a-2", "S1", 2, D(6)), ("ENS-a-2", "S2", 2, D(6)), ("ENS-a-2", "C1", 2, D(6)),
          ("D-b-4", "S1", 1, D(10)), ("D-b-4", "S2", 2, D(11)), ("D-b-4", "C1", 3, D(12)), ("ENS-c-1", "S3", 2, D(16)),
          ("ENS-b-4", "S1", 1, D(10)), ("D-c-3", "S3", 2, D(16)), ("D-c-3", "N1", 3, D(17)),
          ("D-a-11", "S1", 1, D(21)), ("D-d-2", "S1", 1, D(25)), ("D-d-2", "S2", 2, D(26)), ("D-d-2", "C1", 4, D(28))]
    trades = pd.DataFrame(tr, columns=["trade_id", "setup", "watch_day", "entry_date"])
    with tempfile.TemporaryDirectory() as t:
        td = Path(t) / "TAGS" / "TAGS_20261113_001"
        write_tags(td, tags, trades)
        bench = pd.DataFrame({"b3": 0.5, "b5": 1.0, "b10": 2.0}, index=pd.DatetimeIndex(days).astype("datetime64[ns]"))
        G = CL.picks(SL, td, lambda syms: {s: bars[s] for s in syms if s in bars}, lambda s: None, bench)
        G = G.set_index(["trade_id", "watch_day"])
        old, released = CL.CHUNK, []
        CL.CHUNK = 1
        try:
            G1 = CL.picks(SL, td, lambda syms: {s: bars[s] for s in syms if s in bars}, released.extend, bench)
        finally:
            CL.CHUNK = old
        ok5 = G1.set_index(["trade_id", "watch_day"]).equals(G) and sorted(released) == ["AAA", "BBB", "CCC"]
        ok1 = (len(G) == 9 and not {"ENS-a-2", "ENS-b-4", "D-c-3", "D-a-11"} & set(G.index.get_level_values(0)) and
               G.loc[("D-a-1", 2), "n"] == 3 and
               G.loc[("D-a-1", 2), "setups"] == "S1 S2 C1" and G.loc[("D-a-1", 4), "n"] == 1)
        ok2 = (list(G.loc["D-b-4", "cw"]) == [1, 2, 3] and list(G.loc["D-b-4", "within"]) == [False, False, True] and
               G.loc[("D-a-1", 2), "within"] and G.loc[("D-a-1", 2), "cw"] == 3 and
               not G.loc[("D-a-1", 4), "within"] and G.loc[("D-a-1", 4), "cw"] == 4 and
               list(G.loc["D-d-2", "cw"]) == [1, 2, 2] and not G.loc["D-d-2", "within"].any())

        def net(s, k, h):
            _, o, _, _, c, _ = bars[s]
            return (c[k + h - 1] / o[k] - 1) * 100 - 0.35
        ok3 = (np.isclose(G.loc[("D-b-4", 3), "net5"], net("BBB", 12, 5)) and
               np.isclose(G.loc[("D-b-4", 3), "ex5"], net("BBB", 12, 5) - 1.0) and
               np.isclose(G.loc[("D-a-1", 2), "net10"], net("AAA", 6, 10)) and
               np.isclose(G.loc[("D-a-1", 2), "d1net3"], net("AAA", 5, 3)) and
               np.isclose(G.loc[("ENS-c-1", 2), "ex3"], net("CCC", 16, 3) - 0.5))
        check("t5a picks: ranks 1-10 only; a stock and day picked twice counts once (the lowest rank - ENS rank 1 over "
              "D rank 3 - and D on a tie); the setups entering on each watch day", ok1, G.reset_index()[["trade_id", "watch_day", "n", "setups"]].to_dict("list"))
        check("t5b picks WITHIN 3: different setups in the watch day and the 2 before; the first day reaching 3 (a "
              "same-day 3 completes one too; a later day of the same cluster does not; watch days 1, 2, 4 are not 3 "
              "within 3)",
              ok2, G.reset_index()[["trade_id", "watch_day", "cw", "within"]].to_dict("list"))
        check("t5c picks' outcomes from the stock's own bars by hand: the watch day's open, the D1 open (the first bar "
              "after the signal day), excess over the day's benchmark", ok3)
        check("t5e picks loaded one stock at a time = all at once; every stock's bars released", ok5)
        (td / "setup_trades.parquet").write_bytes((td / "setup_trades.parquet").read_bytes() + b"x")
        try:
            CL.picks(SL, td, lambda syms: {}, lambda s: None, bench)
            ok4 = False
        except Exception as e:
            ok4 = "does not match" in str(e) or "outputs.sha256" in str(e) or "hash" in str(e).lower()
        check("t5d a tampered TAGS run is refused", ok4)


# ---------------------------------------------------------------------------------------------------- 6-7 world
FEATS = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_bb_bw_20", "d_wq_44",
         "d_bb_pctb_20", "d_atr_pct"]


def make_world(root: Path, n_syms=80, seed=11, noisy_open=False):
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-06-03", "2023-06-30")
    n = len(cal)
    iso = cal.isocalendar()
    wk = (iso["year"].astype(int) * 100 + iso["week"].astype(int)).to_numpy()
    wfirst = np.r_[True, wk[1:] != wk[:-1]]
    bars, rows = {}, []
    for i in range(n_syms):
        s = f"T{i:03d}"
        if noisy_open:      # the open = noise around a close-to-close walk: a gap-down open bounces back (no clash effect)
            c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
            o = np.r_[c[0], c[:-1]] * np.exp(rng.normal(0, 0.01, n))
        else:               # the close moves on from the open: nothing known at the open says anything after it
            gap, intra = rng.normal(0, 0.01, n), rng.normal(0, 0.018, n)
            lc = np.log(100) + np.cumsum(gap + intra)
            c = np.exp(lc)
            o = np.exp(lc - intra)
        h = np.maximum(o, c) * np.exp(np.abs(rng.normal(0, 0.008, n)))
        l = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, 0.008, n)))
        bars[s] = [np.asarray(cal).astype("datetime64[D]"), o, h, l, c, np.full(n, 1e5)]
        f = {"symbol": s, "timestamp": cal, "w_ret_13w": np.cumsum(np.where(wfirst, rng.normal(0, 1, n), 0.0))}
        for x in FEATS:
            f[x] = np.cumsum(rng.normal(0, 1, n)) if x != "d_atr_pct" else np.abs(rng.normal(3, 1, n))
        f["d_bb_pctb_20"] = rng.normal(0.4, 0.5, n)
        rows.append(pd.DataFrame(f))
    root.mkdir(parents=True, exist_ok=True)
    pd.concat(rows, ignore_index=True).to_parquet(root / "panel.parquet", index=False)
    return {"bars": bars, "cal": cal, "panel": root / "panel.parquet"}


def ohlcv_of(bars):
    return lambda syms: {s: tuple(bars[s]) for s in syms if s in bars}


def world_tags(W, folder: Path, seed=3):
    """A small TAGS run on the world's stocks (random picks and setup entries) so the whole run executes."""
    rng = np.random.default_rng(seed)
    cal = W["cal"]
    tg, tr = [], []
    for j in range(300):
        s = f"T{rng.integers(0, len(W['bars'])):03d}"
        t = int(rng.integers(300, len(cal) - 30))
        tid = f"D-{j}"
        tg.append({"trade_id": tid, "engine": "D", "rank": int(rng.integers(1, 11)), "symbol": s,
                   "signal_day": str(cal[t].date())})
        for sid in rng.choice(CL.ORDER, int(rng.integers(1, 5)), replace=False):
            k = int(rng.integers(1, 6))
            tr.append({"trade_id": tid, "setup": sid, "watch_day": k, "entry_date": str(cal[t + k].date())})
    write_tags(folder, pd.DataFrame(tg), pd.DataFrame(tr))


def t6_world():
    tmp = Path(tempfile.mkdtemp(prefix="clashlab_test_"))
    try:
        fp, fdoc = SL.load_frozen()
        conds, feats = SL.frozen_conds(fdoc), SL.frozen_features(fdoc)
        W = make_world(tmp / "w")
        (U0, b0), _ = quiet(CL.universe, SL, W["panel"], conds, feats, ohlcv_of(W["bars"]), lambda s: None)
        # independent: the marks = setuplab's own market_entries union, counted by hand per stock
        P, want = SL.panel_frame(str(W["panel"]), feats, CL.FROM - np.timedelta64(400, "D"), None, lambda *a: None)
        idx = P.groupby("symbol", sort=False, observed=True).indices
        bad = 0
        for s in list(W["bars"])[:12]:
            d, o, h, l, c, v = W["bars"][s]
            F, have = SL.align_panel(P.iloc[idx[s]], want, d)
            ent = SL.market_entries(d, o, c, F, SL.atr_simple(h, l, c), conds, have & (d >= CL.FROM))
            cnt = {}
            for sid, e in ent.items():
                for x in e:
                    cnt[int(x)] = cnt.get(int(x), 0) + 1
            mine = U0[U0["symbol"] == s]
            got = dict(zip(np.searchsorted(d, mine["day"].to_numpy().astype("datetime64[D]")), mine["n"]))
            bad += int(got != cnt)
        same3 = int((U0["n"] >= 3).sum())
        check("t6a the universe's entry bars and counts = setuplab's market_entries, stock by stock; 3+ clashes occur",
              bad == 0 and same3 > 300, (bad, same3))
        bd = pd.DatetimeIndex(b0.index)
        all_ok = []
        for hh in CL.HOLDS:
            v = []
            for s, (d, o, h, l, c, _) in W["bars"].items():
                j = int(np.searchsorted(d, np.datetime64("2021-03-01")))
                if j + hh - 1 < len(c):
                    v.append((c[j + hh - 1] / o[j] - 1) * 100 - 0.35)
            all_ok.append(np.isclose(b0.loc[bd == pd.Timestamp("2021-03-01"), f"b{hh}"].iloc[0], np.mean(v)))
        check("t6b the same-day benchmark by hand on one day (every stock bought at that open, each hold)", all(all_ok))
        # the planted world: +4% from the close of every 3+ clash bar on (prices after it scaled), absent = as is
        Wp = {s: [x.copy() if isinstance(x, np.ndarray) else x for x in b] for s, b in W["bars"].items()}
        n_pl = 0
        for s, g in U0[U0["n"] >= 3].groupby("symbol"):
            d = Wp[s][0]
            for t in np.searchsorted(d, g["day"].to_numpy().astype("datetime64[D]")):
                for col in (2, 3, 4):
                    Wp[s][col][t:] *= 1.04
                Wp[s][1][t + 1:] *= 1.04
                n_pl += 1
        (Up, bp), _ = quiet(CL.universe, SL, W["panel"], conds, feats, ohlcv_of(Wp), lambda s: None)
        Tabs = universe_tests(U0)
        Tpl = universe_tests(Up)
        sb = {r["hold"]: r for r in Tpl if r["definition"] == "same_bar"}
        check(f"t6c planted world (+4% after {n_pl:,} same-bar clash bars): the same-bar tests PASS on every hold "
              f"(A and B above 0)", all(sb[hh]["rule"] == "PASS" and sb[hh]["a"] > 2 for hh in CL.HOLDS),
              [(r["definition"], r["hold"], r["a"], r["a_lo"], r["b"], r["b_lo"]) for r in Tpl])
        Habs = CL.holm([dict(r, p=max(r["p_a"], r["p_b"])) for r in Tabs])
        check("t6d absent world (a random walk from every open): no universe test passes (rule or Holm)",
              all(r["rule"] == "FAIL" for r in Tabs) and not any(r["final"] == "PASS" for r in Habs),
              [(r["definition"], r["hold"], r["a"], r["a_lo"], r["b"], r["b_lo"]) for r in Tabs])
        old, released = CL.CHUNK, []
        CL.CHUNK = 7
        try:
            (U7, b7), _ = quiet(CL.universe, SL, W["panel"], conds, feats, ohlcv_of(W["bars"]), released.extend)
        finally:
            CL.CHUNK = old
        cols = [k for k in U0.columns if not k.startswith("ex")]
        check("t6e the universe loaded 7 stocks at a time = all at once (the benchmark summed across batches); every "
              "stock's bars released", sorted(released) == sorted(W["bars"]) and U7[cols].equals(U0[cols]) and b7.index.equals(b0.index) and
              np.allclose(b7.to_numpy(float), b0.to_numpy(float), equal_nan=True) and
              all(np.allclose(U7[f"ex{hh}"], U0[f"ex{hh}"], equal_nan=True) for hh in CL.HOLDS))
        Wn = make_world(tmp / "wn", noisy_open=True)
        (Un, _bn), _ = quiet(CL.universe, SL, Wn["panel"], conds, feats, ohlcv_of(Wn["bars"]), lambda s: None)
        Cz = CL.composition(Un, "universe").set_index(["definition", "group", "S2"])
        C0 = CL.composition(U0, "universe").set_index(["definition", "group", "S2"])
        s2 = Un["setups"].str.split(" ").map(lambda x: "S2" in x).to_numpy(bool)
        okn = True
        for df_ in CL.DEFS:
            gc, gk = CL.groups(Un, df_)
            for grp, m in (("clash", gc), ("comparison", gk)):
                w_, wo = Cz.loc[(df_, grp, "with S2")], Cz.loc[(df_, grp, "without S2")]
                okn &= (w_["entries"] == int((m & s2).sum()) and wo["entries"] == int((m & ~s2).sum()) and
                        np.isclose(w_["ex3"], np.nanmean(Un["ex3"].to_numpy(float)[m & s2])) and
                        w_["ex3"] >= 0.4 and w_["ex3"] - wo["ex3"] >= 0.5 and
                        abs(C0.loc[(df_, grp, "with S2"), "ex3"] - C0.loc[(df_, grp, "without S2"), "ex3"]) < 0.4)
        check("t6f a world where gap-down opens bounce back (no clash effect): the S2 table counts by hand and shows "
              "the edge with S2 (+0.4% or more at 3 sessions, 0.5 above without S2, clash and 1-2); the no-effect world "
              "shows no such gap", okn, (Cz[["entries", "ex3"]].round(3).to_dict("index"),
                                         C0[["entries", "ex3"]].round(3).to_dict("index")))
        # ---- 7 the whole run
        tags = tmp / "setuplab" / "TAGS" / "TAGS_20261113_001"
        world_tags(W, tags)
        Z = U0.assign(setup=U0["setups"].str.split(" ")).explode("setup")
        Z = Z[np.isfinite(Z["net5"])].rename(columns={"net5": "net"})[["symbol", "setup", "day", "net"]]
        zd = tmp / "setuplab" / "ZONES" / "ZONES_20261108_001"
        zd.mkdir(parents=True)
        Z.to_parquet(zd / "market_zone_trades.parquet", index=False)
        (zd / "outputs.sha256").write_text(
            f"{hashlib.sha256((zd / 'market_zone_trades.parquet').read_bytes()).hexdigest()}  market_zone_trades.parquet\n")
        d, sha = CL.load_decl()
        out = tmp / "out"
        (rc, run), log = quiet(CL.execute, d, sha, W["panel"], tags, zd / "market_zone_trades.parquet", out,
                               ohlcv_of(W["bars"]), lambda s: None)
        rep = (run / "REPORT.md").read_text(encoding="utf-8")
        T = pd.read_csv(run / "tests.csv")
        hs = dict(x.split("  ", 1)[::-1] for x in (run / "outputs.sha256").read_text().splitlines() if x.strip())
        rj = json.loads((run / "run.json").read_text())
        led = (out / CL.LEDGER).read_text().splitlines()
        check("t7a the run: 12 tests (2 places x 2 definitions x 3 holds) with Holm, the verdict first, every file "
              "hashed, the ledger line, ZONES reconciled 100%",
              rc == 0 and len(T) == 12 and set(T["place"]) == {"universe", "picks"} and
              "## Verdict first" in rep.split("\n")[4] and all(
                  hashlib.sha256((run / k).read_bytes()).hexdigest() == v for k, v in hs.items()) and len(hs) == 10 and
              "composition.csv" in hs and "## With and without S2" in rep and
              rj["zones"]["share_of_zones"] == 1.0 and len(led) == 1 and "No test passes" in rep,
              (rc, len(T), rj.get("zones"), log[-400:]))
        Z2 = Z.copy()
        Z2.iloc[:50, Z2.columns.get_loc("net")] += 1
        rec = CL.reconcile_zones(U0, Z2)
        check("t7b a ZONES run that differs is reported (share under 100%; the report warns under 99%)",
              rec["share_of_zones"] < 1 and rec["matched"] == len(Z) - 50)
        # the command line: the newest TAGS and ZONES runs under --setups, the panel from TAGS.json, the bars from
        # setuplab's LiveData (here a stand-in serving the world's bars), the output never inside the cache
        (tags / "TAGS.json").write_text(json.dumps({"panel": str(W["panel"])}), encoding="utf-8")
        shutil.copytree(tags, tmp / "setuplab" / "TAGS" / "TAGS_20261101_001")
        (tmp / "setuplab" / "TAGS" / "TAGS_20261101_001" / "TAGS.json").write_text(json.dumps({"panel": "nowhere"}))
        (tmp / "cache").mkdir()
        calls = {}

        class FakeData:
            def __init__(self, root, stage_e_any=False, panel="panel_live"):
                calls.update(root=str(root), stage_e_any=stage_e_any, panel=panel)

            def ohlcv(self, syms):
                return ohlcv_of(W["bars"])(syms)

            def forget(self, syms):
                calls["forgot"] = calls.get("forgot", 0) + len(syms)
        real = SL.LiveData
        SL.LiveData = FakeData
        try:
            rc2, log2 = quiet(CL.main, ["run", "--root", str(tmp / "cache"), "--setups", str(tmp / "setuplab"),
                                        "--out", str(tmp / "out2")])
            rc3, log3 = quiet(CL.main, ["run", "--root", str(tmp / "cache"), "--setups", str(tmp / "setuplab"),
                                        "--out", str(tmp / "cache" / "x")])
        finally:
            SL.LiveData = real
        runs2 = sorted((tmp / "out2" / "runs").glob("CL_*"))
        rj2 = json.loads((runs2[-1] / "run.json").read_text()) if runs2 else {}
        check("t7c the command line: the newest TAGS run (its panel from TAGS.json) and ZONES run, setuplab's LiveData on "
              "--root, every stock's bars released; an output folder inside the cache is refused",
              rc2 == 0 and len(runs2) == 1 and rj2.get("tags_run") == "TAGS_20261113_001" and rj2["zones"]["used"] and
              calls.get("root") == str(tmp / "cache") and calls.get("stage_e_any") is False and
              calls.get("panel") is None and calls.get("forgot", 0) >= len(W["bars"]) and rc3 == 2 and
              "inside" in log3, (rc2, rc3, calls, rj2.get("tags_run"), log2[-300:], log3[-200:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def universe_tests(U):
    d = pd.to_datetime(U["day"]).to_numpy().astype("datetime64[D]")
    out = []
    for df_ in CL.DEFS:
        gc, gk = CL.groups(U, df_)
        for hh in CL.HOLDS:
            ex = U[f"ex{hh}"].to_numpy(float)
            r = CL.test_one(d[gc], ex[gc], d[gk], ex[gk])
            r.update({"definition": df_, "hold": hh, "rule": "PASS" if r["a_lo"] > 0 and r["b_lo"] > 0 else "FAIL"})
            out.append(r)
    return out


def main():
    print(f"{CL.VERSION} self-test")
    for t in (t1_declaration, t2_counting, t3_outcomes, t4_stats, t5_picks, t6_world):
        print(f"- {t.__name__}")
        try:
            t()
        except Exception as e:
            import traceback
            traceback.print_exc()
            check(f"{t.__name__} ran without an error", False, repr(e))
    nf = sum(1 for _, ok in RESULTS if not ok)
    print(f"{len(RESULTS)} checks, {nf} failed")
    if nf == 0:
        print(f"VERIFIED ({CL.VERSION})")
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
