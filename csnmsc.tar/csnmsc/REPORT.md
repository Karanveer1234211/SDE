# Volatility x direction - Volatility x direction study VD1 (voldir v1.0)

Declaration sha256 `0cb7f61653894fe7` (declared 2026-11-12, before any run). Universe 1,455 stocks (50 ETFs / indices out by production's research_common.is_etf_symbol; 0 without bars), 1,676,876 eligible stock-days, calendar 2015-01-01..2026-11-11. 306 s.

## Verdict first

- **Buy survivors: 0** - no buy rule beats the universe and its parent out of sample and in replication.
- **Vetoes confirmed: 0** - no subset is reliably worse than its parent.
- **Forecast race (Stage 0): nothing beats ATR14 in 2021 on** (lower QLIKE and a daily rank-correlation gain whose 95% interval is above 0).

Stage 2 (the frozen tree, tradelab add-on v1.5): run these 4 backtests from the tradelab folder (stage2_commands.txt), then `python voldir.py holm --scan %TRADELAB_OUT%\backtest` from the sdelab folder:

```
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\voldir.py#B1 --compare strategies\tree.py --engines D --voldir "C:\QuantData\sdelab\runs\VD_20261112_001" --declare "voldir VD1 Stage 2 B1 D"
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\voldir.py#B2 --compare strategies\tree.py --engines D --voldir "C:\QuantData\sdelab\runs\VD_20261112_001" --declare "voldir VD1 Stage 2 B2 D"
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\voldir.py#B1 --compare strategies\tree.py --engines ENS --voldir "C:\QuantData\sdelab\runs\VD_20261112_001" --declare "voldir VD1 Stage 2 B1 ENS"
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\voldir.py#B2 --compare strategies\tree.py --engines ENS --voldir "C:\QuantData\sdelab\runs\VD_20261112_001" --declare "voldir VD1 Stage 2 B2 ENS"
```

## Every test

Excess = net minus the same-date mean of every eligible stock (same exit); vs parent = net minus the same-date mean of the parent's stock-days. A = 2016-2020 with the Bonferroni interval (mean +- 2.91 bootstrap SDs, 14 tests); B = 2021 on, 95%. bp.

| test | exit | kind | parent | events A | excess A [Bonf.] | vs parent A [Bonf.] | events B | excess B [95%] | vs parent B [95%] | years | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| V1L | X1 | buy | E0 | 16,090 | +3.2 [-10.5, +17.0] | +3.2 [-10.5, +17.0] | 42,473 | +1.5 [-4.9, +7.6] | +1.5 [-4.9, +7.6] | 7 | fails A, B, C, D |
| V1H | X1 | buy | E0 | 15,685 | -16.0 [-34.1, +2.0] | -16.0 [-34.1, +2.0] | 40,403 | -11.6 [-20.4, -2.5] | -11.6 [-20.4, -2.5] | 3 | fails A, B, C, D |
| V2L | X1 | buy | N1 | 8,213 | -16.9 [-42.1, +8.3] | -15.5 [-32.2, +1.2] | 23,034 | +4.7 [-4.0, +14.1] | -3.7 [-10.0, +2.9] | 5 | fails A, B, C, D |
| V2H | X1 | veto | N1 | 4,741 | +22.8 [-5.6, +51.1] | +18.9 [-8.1, +45.9] | 10,967 | +11.5 [-1.3, +24.1] | -0.8 [-12.1, +9.6] | 5 | fails A, B, D |
| V3D | X1 | buy | N1 | 15,132 | +5.9 [-12.9, +24.8] | +4.5 [-3.9, +12.9] | 40,952 | +13.4 [+6.9, +20.3] | +3.1 [-0.6, +6.8] | 9 | fails A, C |
| V3C | X1 | veto | N1 | 3,697 | -13.4 [-44.4, +17.6] | -10.2 [-41.9, +21.4] | 9,455 | -14.5 [-25.2, -3.3] | -20.8 [-30.6, -11.3] | 9 | fails A |
| V4F | X1 | buy | N1 | 1,803 | +26.0 [-63.2, +115.2] | +1.6 [-15.0, +18.3] | 4,148 | -3.2 [-37.7, +24.2] | -6.1 [-13.2, -0.2] | 5 | TOO FEW EVENTS |
| V4R | X1 | veto | N1 | 5,237 | +0.1 [-42.3, +42.5] | +2.9 [-9.2, +14.9] | 13,125 | +15.5 [+2.4, +26.8] | +4.2 [-1.9, +11.1] | 3 | fails A, B, D |
| V5K | X1 | veto | E0 | 667 | +35.2 [-99.0, +169.3] | +35.2 [-99.0, +169.3] | 1,940 | -23.1 [-76.9, +25.3] | -23.1 [-76.9, +25.3] | 7 | fails A, B, D |
| V5D | X1 | veto | N1 | 271 | +65.1 [-180.6, +310.9] | +37.9 [-193.4, +269.1] | 618 | +44.3 [-78.0, +139.9] | +22.3 [-96.9, +116.0] | 3 | TOO FEW EVENTS |
| V6H | X0 | buy | J | 7,308 | -23.2 [-42.0, -4.4] | -13.0 [-29.4, +3.4] | 22,003 | -19.2 [-27.4, -10.7] | -14.2 [-21.2, -7.1] | 0 | fails A, B, C, D |
| V6H | X1 | buy | J | 7,308 | -26.2 [-58.6, +6.2] | -11.8 [-37.7, +14.2] | 21,967 | -13.3 [-28.4, +1.8] | -14.6 [-26.3, -2.9] | 2 | fails A, B, C, D |
| V6L | X0 | veto | J | 447 | -9.7 [-63.3, +43.8] | +5.1 [-51.3, +61.6] | 681 | -44.8 [-78.1, -13.3] | -41.9 [-75.0, -10.8] | 7 | fails A, D |
| V6L | X1 | veto | J | 447 | -60.2 [-148.1, +27.7] | -33.5 [-123.6, +56.5] | 681 | -41.8 [-90.1, +8.1] | -48.4 [-95.9, +1.9] | 7 | fails A, B, D |

Years = years (of 11) whose mean excess (buy) is above 0 / whose mean vs parent (veto) is below 0, each with at least 30 events; 8 needed.

### The rules

- **V1L** (buy, parent E0): rsj10 <= the day's 10th percentile - variance made of falls - US: the next week outperforms.
- **V1H** (buy, parent E0): rsj10 >= the day's 90th percentile - variance made of rises - Pakistan: the next week outperforms.
- **V2L** (buy, parent N1): sde10 < -0.5 and turn_rel <= the day's 33rd percentile - a quiet orderly fall = liquidity selling, which reverses.
- **V2H** (veto, parent N1): sde10 < -0.5 and turn_rel >= the day's 67th percentile - an orderly fall on heavy turnover = information, which continues.
- **V3D** (buy, parent N1): sde10 < -0.5 and lds10 < 0.35 and not shock - a drift, not one panic candle.
- **V3C** (veto, parent N1): sde10 < -0.5 and (lds10 >= 0.35 or shock) - one big loss carries news (left-tail momentum).
- **V4F** (buy, parent N1): sde10 < -0.5 and mvol_high and mvol_falling - losers rebound as high market volatility subsides.
- **V4R** (veto, parent N1): sde10 < -0.5 and mvol_high and not mvol_falling - buying a fall while market volatility is still rising.
- **V5K** (veto, parent E0): lock3 - lower-limit closes continue (NSE).
- **V5D** (veto, parent N1): sde10 < -0.5 and lock3 - a dip that hit the lower band.
- **V6H** (buy, parent J): atrp >= the day's 67th percentile and ret20 >= the day's 90th percentile and turn_rel >= the day's 67th percentile - high-volatility winners on heavy turnover continue, briefly.
- **V6L** (veto, parent J): atrp >= the day's 67th percentile and ret20 >= the day's 90th percentile and turn_rel <= the day's 33rd percentile - high-volatility winners on thin turnover reverse.

## Stage 0 - the volatility forecast race

Target: the mean squared log return of the 5 sessions after the signal close. 1,421,901 rows where all five forecasts exist. Each forecast is scaled by one constant from 2016-2020 (QLIKE's best level). Spearman = the day's rank correlation of the forecast with the outcome across stocks (what a lane cut-off uses); vs ATR = its daily difference, 95% block bootstrap. Period A is in sample for HAR, GJR and the scales.

| method | period | QLIKE | Spearman | vs ATR [95%] | scale | beats ATR |
|---|---|---|---|---|---|---|
| ATR | A | 0.5881 | 0.4195 | +0.0000 [+0.0000, +0.0000] | 0.445 |  |
| EWMA | A | 0.6043 | 0.4400 | +0.0205 [+0.0166, +0.0245] | 1.186 |  |
| YZ | A | 0.6094 | 0.3987 | -0.0208 [-0.0246, -0.0172] | 0.891 |  |
| HAR | A | 0.5872 | 0.4121 | -0.0074 [-0.0119, -0.0027] | 0.963 |  |
| GJR | A | 0.5535 | 0.4534 | +0.0339 [+0.0294, +0.0384] | 1.005 |  |
| ATR | B | 0.5650 | 0.4396 | +0.0000 [+0.0000, +0.0000] | 0.445 | no |
| EWMA | B | 0.5725 | 0.4466 | +0.0071 [+0.0038, +0.0102] | 1.186 | no |
| YZ | B | 0.5745 | 0.4229 | -0.0167 [-0.0192, -0.0143] | 0.891 | no |
| HAR | B | 0.5691 | 0.4182 | -0.0214 [-0.0255, -0.0171] | 0.963 | no |
| GJR | B | 0.5731 | 0.4139 | -0.0257 [-0.0297, -0.0215] | 1.005 | no |

HAR (pooled, 2016-2020): RV5 = 0.000358 + 0.042 r^2 + 0.167 mean5 + 0.257 mean22.

## Market volatility (NIFTY50 GJR-GARCH, refitted each January on the past only)

| year | returns fitted | alpha | gamma (leverage) | beta | nu |
|---|---|---|---|---|---|
| 2016 | 247 | 0.000 | 0.069 | 0.873 | 6.2 |
| 2017 | 494 | 0.000 | 0.081 | 0.893 | 6.3 |
| 2018 | 742 | 0.000 | 0.088 | 0.930 | 6.3 |
| 2019 | 988 | 0.000 | 0.131 | 0.891 | 8.0 |
| 2020 | 1,233 | 0.000 | 0.136 | 0.890 | 8.0 |
| 2021 | 1,485 | 0.000 | 0.128 | 0.902 | 7.1 |
| 2022 | 1,733 | 0.000 | 0.141 | 0.893 | 7.3 |
| 2023 | 1,981 | 0.000 | 0.145 | 0.892 | 8.0 |
| 2024 | 2,227 | 0.000 | 0.133 | 0.897 | 8.0 |
| 2025 | 2,476 | 0.000 | 0.138 | 0.887 | 6.7 |
| 2026 | 2,725 | 0.000 | 0.135 | 0.892 | 6.8 |

## How to read it

- signal at the close of t; buy at the open of the next session; exits: X0 the 2nd close; X1 the 5th close; a close locked at the lower circuit (production's stage E rule) sells at the first open within 20 sessions that is not locked; none = sold at the 20th session's close ('stuck'); data ending first = 'pending' (left out) - as R1; 35 bp; one event per stock until 5 sessions have passed.
- Buy survivor: all of: (A) excess Bonferroni lower bound > 0 in period A; (B) excess 95% lower bound > 0 in period B; (C) incremental 95% lower bound > 0 in A and incremental mean > 0 in B; (D) mean excess > 0 in at least 8 of the 11 years 2016-2026 (a year with fewer than 30 events is not positive); at least 300 events on 100 days in each period.
- Veto confirmed: all of: (A) incremental Bonferroni upper bound < 0 in period A; (B) incremental 95% upper bound < 0 in period B; (D) mean incremental < 0 in at least 8 of the 11 years (a year with fewer than 30 events is not negative); at least 300 events on 100 days in each period.
- Period roles: A out of sample for these measures (never computed on it); R1 looked at SDE x environments on it, so it is lightly used, not untouched; B replication.
- Stage 2: B1: the Calmar ratio (CAGR / |worst drawdown|) is higher than the frozen tree's with the 95% paired block-bootstrap interval of the difference above 0, and the worst drawdown no deeper. Every other: the money view's daily-return difference against the frozen tree has a 95% interval above 0, the CAGR is higher and the worst drawdown no deeper. every Stage 2 strategy run on one engine is one family: the one-sided bootstrap p-values (share of resamples at or below 0) are Holm-corrected at 0.025 ('python voldir.py holm <TLB folders>'); a strategy PASSES only if its own rule passes AND Holm keeps it. the tree was found on 2021-2026, so a PASS makes the change a forward candidate (a new tree with its own freeze date); the frozen tree keeps running unchanged either way.
- Known bias: the cache holds the stocks it holds today: stocks delisted after a fall are probably missing, which flatters buy-the-fall rules, most in period A.
- Files: verdicts.csv, results.csv, years.csv, race.csv, market_vol.csv, gjr_params.csv, daily_cuts.parquet (tradelab's --voldir C:\QuantData\sdelab\runs\VD_20261112_001), stage2_commands.txt.
