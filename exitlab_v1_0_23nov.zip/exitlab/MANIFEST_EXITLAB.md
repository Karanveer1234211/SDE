# MANIFEST - exitlab v1.0 (23 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\exitlab`. It is a new research folder beside `vollab`, `triggerlab`,
`treelab`, `setuplab` and `tradelab`. Nothing here goes into `bigmove_deploy`, and no file name here exists in
production. It writes only under `C:\QuantData\exitlab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `exitlab.py` | e20850af8aa7f4a1 | 55272 |
| `EXITLAB_DECLARATION.json` | 7a151989eab4b129 | 13537 |
| `README_EXITLAB.md` | 9c2e23d536de7c44 | 5549 |
| `tests\test_exitlab.py` | 4dc032b907595d85 | 43275 |
| `tests\ex_world.py` | 75d52dfdb09ef3ad | 8683 |
| `MANIFEST_EXITLAB.md` | this file | - |

## Needs

These are read only, as sibling folders. Their versions are checked at every start.
- vollab v1.0 (`vollab.py` sha16 59fbb6467f5e7a06: tree_setup, book_sim2, account_returns, nifty_state, Boot helpers).
  Its tests folder is also needed, for the tests only:
  - `tests\vl_world.py` 0606e264d95840d5;
  - `tests\test_m5tree.py` 24d3458808d1e9f7 (its hand fill rule);
  - `tests\m5_world.py` 855e2695e5bc2062;
  - `m5tree.py` b975b167123f456c.
- triggerlab v1.0 (`triggerlab.py` sha16 a0342ef93421a11b): Universe, load_paths, frozen_trades, book_sim, the gate.
- treelab v1.0 (`treelab.py` sha16 64ac932f584fade1).
- setuplab v1.1 (`setuplab.py` sha16 9979d418aecec6de, with FROZEN_SETUPS.json and TREE.json).
- tradelab v1.3.1 (`tl_data.py` sha16 46ceff88fdadda7f).
- Through tradelab's env (`env_tradelab.bat`), from `bigmove_deploy\open_close`:
  - stage_e_execution (the shipped v1.2);
  - intraday_cache;
  - stage_b_screen (ELIG_COL).
- scikit-learn and pyarrow.

## Inputs (read only)

- `%CACHE_DAILY_ROOT%` daily cache, through stage E's loader and lock rule. No 3-minute bars.
- `%CACHE_DAILY_ROOT%\panel_oc\panel.parquet`: eligibility, the frozen setups' inputs, setuplab's 53 final features.
- `C:\QuantData\setuplab\WL_R1_10`: D and ENS ranks 1-10.
- `C:\QuantData\vollab\VOLLAB_20261122_001\pick_forecasts.csv`: M5.

## Declaration

`EXITLAB_DECLARATION.json`, internal sha256 `7c5b2067aaee4c0a...`. It was declared at 23 Nov 2026 11:30 IST, and the
wording of the rows was completed at 12:00 IST. Both were before any real-data run. It is checked at every start
against the code's settings, and an edited file is refused.

The declared choices made while building:
- 200 iterations without early stopping (pick_meta's settings).
- A column with no value in a year's training rows is left out of that year's model. scikit-learn 1.9 refuses such
  columns; in 1.5 the result is the same.
- A sale at an open uses triggerlab's lock rule for open sales.
- Evenings after the watchlist calendar's last session are left out and counted.

## History

- v1.0 (23 Nov 2026): first build, from Karan's four instructions of 11:08 IST.

## Verified (synthetic data only)

`tests\test_exitlab.py` ends `VERIFIED (exitlab v1.0) - 103 checks` on Python 3.13 with both library sets:
- pandas 3.0.5, numpy 2.5.3, scikit-learn 1.9.1 (about 120 s);
- pandas 2.3.3, numpy 2.4.1, scikit-learn 1.5.2 (about 110 s).

What it checks:
- **Rows on hand-made paths:**
  - S1 at D5 has 0 evenings, N1 at D5 has 4, a D1 open buy has 4;
  - locked opens wait for the next unlocked open, and a locked scheduled close sells at the next open;
  - moot sales;
  - stuck sales are at a close.
- **The tree's trades and the ranks 4-10 replays**, rebuilt from the world's bars and panel with setuplab's fill rule
  in a loop.
- **Every row by hand** (about 60,000 per world): the mechanics from the fill, tomorrow's sale, the scheduled exit,
  valid or moot, and the label.
- **The inputs by hand:** tonight's ranks, NIFTY returns and stress, the panel at tonight's close, M5.
- **The walk-forward:**
  - each year's training rows by hand (outcome known before 1 January);
  - the clip;
  - a refit of M0, M1 and M2 from the declaration's settings gives the same predictions.
- **The exit rules by hand:** the first valid evening below 0; the scheduled exits; OPEN6.
- **The books by a separate loop:** 3 slots, freed slots reused, a sale at an open frees its slot for that open, 5
  starts, 50:50 restarted each January. Also a year, worst fall, every interval and p, the M5 test, and the decision
  rule on hand-made cases.
- **Planted worlds:**
  - exit (a panel input warns of a fall): M1 PASSES and M5 adds nothing;
  - m5 (M5 warns of a fall): M5 ADDS;
  - absent: M1 FAILS and M5 adds nothing.
- **Refusals, outputs and edge cases:**
  - refused: no forecasts, no M5 column, `--out` inside the cache, an edited declaration, settings that differ;
  - `--check-only` writes nothing;
  - the hashes, the ledger and the report sections;
  - a cache that runs past the watchlist's calendar.

**Mutation test: 39 deliberate bugs, all caught.** The first round left 2 survivors (stuck sales); the stuck-sale
unit cases were added, and both are now caught.

**Clean unzip:** the zip unpacked beside fresh copies of the sibling folders passes the same test.
