# exitlab v1.0 - an exit meta model for the frozen tree (research only)

Karan, 23 Nov 2026: "Exit model. The missing piece is an exit meta model." Approved for research at 11:08 IST with
four instructions, all built in. The question: once a setup has bought a stock, can information that arrives after
the entry tell you when selling early beats that setup's scheduled exit?

What is new (Karan's correction): trailing stops and the recovery study already reacted to events after entry.
exitlab learns the value of holding on at each eligible close, across the calm open buys and all seven setups.

## What it does

1. **Trades.** The frozen tree's planned trades (D and ENS ranks 1-3, before the three-slot limit) plus ranks 4-10
   replayed with the same entries. Ranks 4-10 are labelled hypothetical: they only train the models. Money is
   scored on the D and ENS top-three books.
2. **Rows.** One row per evening a trade can decide: from the close of its entry session to the close before its
   scheduled exit. Examples:
   - an open buy at D1 has 4 evenings (D1-D4);
   - an N1 bought at the D5 open has 4 (it exits 4 sessions after entry);
   - an S1 bought at the D5 open has none.
   Profit, best move and worst move are measured from the actual fill.
3. **Label.** At tonight's close: the return from tomorrow's executable open to the scheduled exit, in bp. A locked
   open waits for the first unlocked one (stage E's rule). Below 0 means selling tomorrow would have been better.
   A sale that could only happen after the scheduled exit is moot: it is not trained on and not acted on.
4. **Three models** (HistGradientBoosting with pick_meta's settings), walk-forward by year 2023-2026. Each year is
   trained only on rows whose outcome was known before 1 January.
   - M0: mechanics only.
   - M1: mechanics + the trade + tonight's ranks in both engines + 53 panel features + NIFTY.
   - M2: M1 + M5.
5. **Rule.** At the first evening a model predicts below 0, sell at tomorrow's open. Nothing else changes.
6. **Books.** The frozen books are reproduced first. Each rule then runs the tree's 3-slot books:
   - freed slots are reused in the existing order;
   - 5 start days, D and ENS 50:50, restarted each January;
   - results are compared on paired days with block-bootstrap intervals.

## The decision (declared before the run: `EXITLAB_DECLARATION.json`)

- **EXIT MODEL (M1) PASSES** only if all three hold:
  - its daily gain over the frozen exits has a 95% interval above 0;
  - its worst fall is no deeper than the frozen tree's;
  - its gain over mechanics only (M0) has a 95% interval above 0.
- **M5 ADDS** only if, on identical decisions with an M5 forecast, M2's squared error is lower than M1's with a 95%
  interval above 0. M5's coverage is reported for every year; the 2023 model has almost no M5 history.
- **Shown, not deciding:** M0, M2, OPEN6 (sell at the open after the scheduled close: more time in the trade), and D
  and ENS separately.
- A PASS earns a forward paper book beside the frozen tree, nothing more.

## Copy and run (Windows cmd)

Unzip `exitlab_v1_0_23nov.zip` into `C:\Users\karanvsi\PyCharmMiscProject`. It creates the new folder `exitlab` beside
`vollab`. Nothing goes into `bigmove_deploy`, and no existing file is replaced.

```
tar -xf %USERPROFILE%\Downloads\exitlab_v1_0_23nov.zip -C C:\Users\karanvsi\PyCharmMiscProject
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\exitlab
python tests\test_exitlab.py
python exitlab.py --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --run C:\QuantData\vollab\VOLLAB_20261122_001 --out C:\QuantData\exitlab --check-only
python exitlab.py --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --run C:\QuantData\vollab\VOLLAB_20261122_001 --out C:\QuantData\exitlab
```

- The test must end `VERIFIED (exitlab v1.0)`. It takes about 2 minutes.
- `--check-only` reproduces the frozen tree and matches the picks to the cache, and writes nothing.
- The real run should take roughly 10-20 minutes. That is an estimate: it loads ranks 1-10 and reads 53 panel
  columns.
- Needs the sibling folders `vollab`, `triggerlab`, `treelab`, `setuplab` and `tradelab`, plus scikit-learn.

## What it writes (`C:\QuantData\exitlab\EXITLAB_<date>_<nnn>\`)

- `EXITLAB.md`: the verdict first, then every table. **Send this back.**
- `exitlab_rules.csv`: each rule's numbers (a year, worst fall, D and ENS books) and every comparison with its interval
  and p.
- `exitlab_daily.csv`: each rule's 5-start daily returns (the account, D and ENS).
- `exitlab_trades.csv`: every tree trade with its exit and net under each rule.
- `exitlab_folds.csv`: each year's rows, M5 coverage, R2, rank correlation, share sold, and the columns left blank.
- `exitlab_sales.csv`: the exit model's early sales by entry kind and evening. Shows losses avoided against gains
  missed.
- `exitlab_rows.parquet`: every decision row (label, features, the three predictions).
- `EXITLAB_RESULT.json`, `DECLARATION.json`, `RUN.json` (library versions included), `outputs.sha256`.
- One line per run in `C:\QuantData\exitlab\exitlab_ledger.jsonl`.

## Limits

- The lockbox is spent, and the frozen tree was drawn on 2020-26 data.
- Decisions use daily bars only (no 3-minute inputs in v1). A sale at an open is assumed filled at that open.
- Holding past the scheduled exit is not a choice in v1 (OPEN6 is shown only).
- The models' numbers depend on the scikit-learn version, which `RUN.json` records.
