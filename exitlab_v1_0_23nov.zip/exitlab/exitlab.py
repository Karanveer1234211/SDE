"""
exitlab.py - exitlab v1.0: an exit meta model for the frozen tree (research only).

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\exitlab
    python tests\\test_exitlab.py
    python exitlab.py --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --run C:\\QuantData\\vollab\\VOLLAB_20261122_001 --out C:\\QuantData\\exitlab

Karan, 23 Nov 2026 11:02: "Exit model. The missing piece is an exit meta model." 11:08: "Once a setup has bought a
stock, can information arriving after entry tell you when selling early is better than taking that setup's scheduled
exit?" - with four instructions, all followed here:
  1 rows from the fill to the scheduled exit: one row per evening a trade can decide (the close of its entry session
    to the close before its scheduled exit session; an S1 bought at the D5 open has none, an N1 bought there has
    four); profit, best and worst move from the actual fill; ranks 4-10 replayed with comparable entries as
    hypothetical training trades; money only on the D and ENS top-three books;
  2 the label is the executable decision: tonight's estimate of the return from tomorrow's executable open (stage
    E's lock rule) to the scheduled exit; below 0 = sell tomorrow;
  3 three models on identical rows: mechanics only (M0), mechanics + the trade, the engine tonight, the stock and the
    market (M1), and M1 + M5 (M2), with M5's coverage reported (it starts in December 2022);
  4 the frozen three-slot books reproduced first; freed slots reused in the existing order; 5 start days; paired
    days, blocks of dates; D and ENS separately; the D6-open shadow (more time in the trade) beside it.
PASS (the exit model, M1) = its daily gain over the frozen tree has a 95% interval above 0 with a worst fall no deeper,
AND its gain over the mechanics-only rule has a 95% interval above 0. M5 ADDS when its squared-error gain over M1 on
identical rows has a 95% interval above 0.

Reads production, the panel, the watchlist, the daily cache (stage E's loader and lock rule) and vollab's
pick_forecasts.csv, read only. Writes only EXITLAB_<date>_<nnn>\\ under --out and a line in exitlab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
VOLLAB = Path(os.environ.get("VOLLAB_DIR") or (HERE.parent / "vollab"))
sys.path.insert(0, str(VOLLAB))
import vollab as VL  # noqa: E402

SU, TL, TG, TD, TC = VL.SU, VL.TL, VL.TG, VL.TD, VL.TC
VERSION = "exitlab v1.0"
NEEDS = {"vollab": "vollab v1.0", "setuplab": "setuplab v1.1", "treelab": "treelab v1.0",
         "triggerlab": "triggerlab v1.0", "tradelab": "tradelab v1.3.1"}
DECL_FILE = "EXITLAB_DECLARATION.json"
IST = "Asia/Kolkata"
TEST_YEARS = (2023, 2024, 2025, 2026)
RANKS_ALL = 10
STARTS = 5
HGB = {"max_iter": 200, "learning_rate": 0.03, "max_leaf_nodes": 7, "min_samples_leaf": 100,
       "l2_regularization": 3.0, "early_stopping": False, "random_state": 7}
WINSOR = (0.01, 0.99)
MIN_TRAIN = 1000
M5_MIN_ROWS = 50
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
START = "2023-01-01"
COST = SU.COST
STRESS_Z, STRESS_N, STRESS_MIN = 1.25, 250, 120
HOWS = ("open",) + tuple(TG.SETUPS)
MECH = ("held", "left", "pnl_pct", "pnl_atr", "mfe_atr", "mae_atr", "day_atr", "range_atr", "clv", "atr_pct")
TRADE = ("eng_d", "lane", "how", "srank")
ENGINE = ("rank_own", "rank_other")
MARKET = ("nifty_r1", "nifty_r5", "nifty_z", "nifty_stress")
M5F = ("m5_sigma5", "m5_left")
PANEL = ("d_ema20_angle_deg", "w_ret_13w", "d_bb_bw_20", "d_wq_44", "d_mdi14_diff1", "d_wq_12", "d_wq_33",
         "d_cmf20_rmean50", "d_donch_pos_50_rmean50", "d_rsi14_obv_x", "d_vol_yz_50", "d_n_5pct_up_252",
         "d_dist_from_52wl", "d_wq_29", "d_wq_16", "d_slope_stability", "d_realvol_ratio_20_60", "d_adx14",
         "d_upside_vol_ratio", "d_atr_pct", "d_realvol_20", "d_wq_26", "d_wq_13", "d_lh_run", "d_wq_40",
         "d_rsi14_z252", "d_ret_skew_60", "d_cpr_width_pct", "d_amihud_20", "d_intraday_ret_pct",
         "d_ret_5d_roll_std", "d_realvol_60", "d_vol_yz_20", "x_z_d_downside_dev_60", "d_n_5pct_up_60",
         "x_relvol_20", "d_amihud_60", "d_mdi14_diff5", "d_range_pct", "d_mdi14_rrank20", "d_ema20_angle_z252",
         "d_mdi14_rrank10", "d_dist_from_20h", "d_wq_38", "d_slope_stability_rmean50", "d_mdi14", "d_rsi7",
         "d_ll_run", "d_wq_35", "x_z_d_dvol_z252", "d_donch_pos_20", "d_wq_20", "d_bb_pctb_20")
FEATURES = MECH + TRADE + ENGINE + MARKET + PANEL + M5F
MODELS = {"M0": "mechanics only", "M1": "mechanics + the trade + the engine tonight + the stock + the market",
          "M2": "M1 + M5"}
RULES = ("FROZEN", "M0", "M1", "M2", "OPEN6")
WORDS = {"FROZEN": "the frozen tree (scheduled exits)", "M0": "sell when the mechanics-only model says so",
         "M1": "sell when the full model says so (THE EXIT MODEL)", "M2": "sell when the full model + M5 says so",
         "OPEN6": "every trade sells at the first executable open after its scheduled exit close"}
PAIRS = (("M1", "FROZEN", "decision (a): the exit model against the frozen exits"),
         ("M1", "M0", "decision (b): the exit model against mechanics only"),
         ("M0", "FROZEN", "mechanics only against the frozen exits"),
         ("M2", "FROZEN", "the exit model + M5 against the frozen exits"),
         ("M2", "M1", "what M5 adds to the exit model, in money"),
         ("OPEN6", "FROZEN", "more time in the trade (the D6-open shadow)"))
LOG = VL.LOG


class ExitError(Exception):
    pass


def constants():
    return {"test_years": list(TEST_YEARS), "ranks_all": RANKS_ALL, "starts": STARTS, "hgb": HGB,
            "winsor": list(WINSOR), "min_train": MIN_TRAIN, "m5_min_rows": M5_MIN_ROWS,
            "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "start": START, "cost": COST,
            "stress": [STRESS_Z, STRESS_N, STRESS_MIN], "hows": list(HOWS), "mech": list(MECH),
            "trade": list(TRADE), "engine": list(ENGINE), "market": list(MARKET), "panel": list(PANEL),
            "m5": list(M5F), "models": {k: list(model_cols(k)) for k in MODELS}, "rules": list(RULES),
            "pairs": [list(p[:2]) for p in PAIRS]}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise ExitError("no declaration at %s (it ships beside exitlab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise ExitError("%s was changed after it was declared (its sha256 does not match) - restore the shipped "
                        "file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise ExitError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), VOLLAB.resolve(), (HERE.parent / "bigmove_deploy").resolve(),
              Path(SU.__file__).resolve().parent, Path(TL.__file__).resolve().parent,
              Path(TG.__file__).resolve().parent, Path(TD.__file__).resolve().parent):
        if o == b or b in o.parents:
            raise ExitError("--out %s is inside %s - outputs go under C:\\QuantData\\exitlab" % (o, b))
    return o


def ledger(out, rec):
    Path(out).mkdir(parents=True, exist_ok=True)
    with open(Path(out) / "exitlab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def model_cols(name):
    if name == "M0":
        return MECH
    full = MECH + TRADE + ENGINE + MARKET + PANEL
    return full + M5F if name == "M2" else full


# ====================================================================================================== picks, bars
class Picks(TG.Universe):
    """triggerlab's Universe for ranks 1..ranks (D and ENS, complete, not ETFs, from the window start, with a cut-off
    and an ATR): one row per engine pick, u = its distinct (symbol, signal day)."""

    def __init__(self, bk, cuts23, tdoc, s_, ranks):  # noqa: super().__init__ is triggerlab's ranks-1-3 version
        comp = SU.tree_complete(bk)
        etf = SU.tree_etf(bk.symbols, tdoc)
        sday = np.asarray(bk.signal_day).astype("datetime64[D]")
        yrs = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
        cut = np.array([cuts23.get(int(y), np.nan) for y in yrs])
        atr = np.asarray(bk.atr, float)
        base = np.isin(bk.engine_arr, TG.ENGINES) & (bk.rank <= ranks) & comp & ~etf & \
            (sday >= np.asarray(bk.cal[s_]).astype("datetime64[D]")) & np.isfinite(cut)
        with np.errstate(invalid="ignore"):
            m = base & np.isfinite(atr) & (atr > 0)
        self.no_atr = int((base & ~m).sum())
        r = np.flatnonzero(m)
        self.br, self.eng, self.rank, self.sym, self.tid = r, bk.engine_arr[r], bk.rank[r], bk.symbols[r], bk.ids[r]
        self.sday, self.i1 = sday[r], bk.i1[r]
        with np.errstate(invalid="ignore"):
            self.lane = (atr[r] > cut[r]).astype(np.int64)
        key = np.char.add(np.char.add(self.sym.astype(str), "|"), self.sday.astype(str))
        self.ukey, first, self.u = np.unique(key, return_index=True, return_inverse=True)
        self.nu = len(self.ukey)
        self.ubr, self.usym, self.usday, self.ui1 = r[first], self.sym[first], self.sday[first], self.i1[first]
        self.n = len(r)


class LeanPaths:
    """triggerlab's Paths without the 3-minute arrays (daily bars D0..D31, the locks of D1..D10, where a locked sale
    goes)."""

    def __init__(self, nu):
        sh = (nu, TG.LOAD_D + 1)
        self.O, self.H, self.L, self.C = (np.full(sh, np.nan) for _ in range(4))
        self.lockO, self.lockC, self.frz = (np.zeros((nu, TG.LAST_D + 1), bool) for _ in range(3))
        self.hon_k = np.full((nu, TG.LAST_D + 1), 99, np.int64)
        self.hon_px = np.full((nu, TG.LAST_D + 1), np.nan)
        self.hon_stuck = np.zeros((nu, TG.LAST_D + 1), bool)
        self.us3 = np.zeros((nu, TG.LAST_D + 1), bool)
        self.A = np.full(nu, np.nan)
        self.ok = np.zeros(nu, bool)


PATH_FIELDS = ("O", "H", "L", "C", "lockO", "lockC", "frz", "hon_k", "hon_px", "hon_stuck", "us3", "A", "ok")


def load_lean(U, bk, mk, log=LOG):
    """triggerlab's load_paths (stage E's loader and lock rule) on the daily bars only, without the 3-minute arrays."""
    keep = TG.Paths
    TG.Paths = LeanPaths
    try:
        return TG.load_paths(U, bk, VL._DailyOnly(mk), log)
    finally:
        TG.Paths = keep


def slice_paths(PA, idx):
    out = LeanPaths(len(idx))
    for nm in PATH_FIELDS:
        setattr(out, nm, getattr(PA, nm)[idx].copy())
    return out


def hold_exit(PA, u, x):
    """The scheduled exit as triggerlab's frozen_trades sells it: the close of day x; a lower-locked close -> the first
    unlocked open after it (none within 20 sessions = that last close, stuck). -> (day, price, at an open)."""
    u, x = np.asarray(u, np.int64), np.asarray(x, np.int64)
    xp = PA.C[u, x].copy()
    xk = x.copy()
    xo = np.zeros(len(u), bool)
    lk = PA.lockC[u, np.clip(x, 0, TG.LAST_D)]
    if lk.any():
        xk[lk], xp[lk] = PA.hon_k[u[lk], x[lk]], PA.hon_px[u[lk], x[lk]]
        xo[lk] = ~PA.hon_stuck[u[lk], x[lk]]
    return xk, xp, xo


def sell_at(PA, u, k):
    """A sale ordered for the open of day k, as triggerlab's exits sells at an open: that open, or, when it is
    lower-locked, the first unlocked open after it (none within 20 sessions = that last close, stuck).
    -> (day, price, at an open)."""
    u, k = np.asarray(u, np.int64), np.asarray(k, np.int64)
    kk = np.clip(k, 0, TG.LAST_D)
    sk, sp, so = k.copy(), PA.O[u, k].copy(), np.ones(len(u), bool)
    lk = PA.lockO[u, kk]
    if lk.any():
        sk[lk], sp[lk] = PA.hon_k[u[lk], kk[lk]], PA.hon_px[u[lk], kk[lk]]
        so[lk] = ~PA.hon_stuck[u[lk], kk[lk]]
    return sk, sp, so


def scheduled_day(how, ek, primary):
    """The frozen tree's exit day: the D5 close; a setup whose primary exit is 'fresh' (N1) 4 sessions after entry."""
    return np.array([e + 4 if primary.get(str(h)) == "fresh" else 5 for h, e in zip(how, ek)], np.int64)


# ====================================================================================================== the trades
def tree_trades(TS, U3, PA3, map3):
    """The frozen tree's planned trades per engine (triggerlab's frozen_trades, before the slot limit) and a table."""
    bk, primary = TS["bk"], TS["primary"]
    T3, rows = {}, []
    for e, Eg, calm in (("D", TS["ED"], "first_up"), ("ENS", TS["EE"], "all")):
        T, _ = TG.frozen_trades(U3, PA3, bk, Eg, calm, primary)
        T3[e] = T
        how = np.array([str(g).split(":", 1)[-1] for g in T["g"]], dtype=object)
        ek = T["d"].astype(np.int64)
        rows.append(pd.DataFrame({"src": 0, "eng": e, "tix": np.arange(len(ek)), "tid": T["tid"], "sym": T["sym"],
                                  "sday": T["sday"], "srank": T["rank"], "lane": T["lane"], "how": how,
                                  "u10": map3[T["u"]], "i1": T["i1"], "ek": ek, "x": scheduled_day(how, ek, primary),
                                  "p0": T["p0"], "atr": np.asarray(bk.atr, float)[U3.br[T["r"]]]}))
    return T3, pd.concat(rows, ignore_index=True)


def hypo_trades(TS, U10, PA10):
    """Ranks 4-10, replayed with the tree's entries: a calm pick at the D1 open (D only when it opens at or above the
    signal close); every other pick by the earliest of the seven frozen setups' fills (TREE_ORDER on ties)."""
    bk, fills, primary = TS["bk"], TS["fills"], TS["primary"]
    j = np.flatnonzero(U10.rank > 3)
    br = U10.br[j]
    o1, sc = bk.O[br, 1], bk.sc[br]
    with np.errstate(invalid="ignore"):
        up = np.isfinite(o1) & np.isfinite(sc) & (o1 >= sc)
    calm_open = (U10.lane[j] == 0) & ((U10.eng[j] == "ENS") | up)
    sk = np.zeros(len(j), np.int64)
    sid = np.full(len(j), "", dtype=object)
    for s in TG.SETUPS:
        k = np.asarray(fills[s][0], np.int64)[br]
        better = ~calm_open & (k > 0) & ((sk == 0) | (k < sk))
        sk[better], sid[better] = k[better], s
    ek = np.where(calm_open, 1, sk).astype(np.int64)
    how = np.where(calm_open, "open", sid).astype(object)
    keep = ek >= 1
    j, br, ek, how = j[keep], br[keep], ek[keep], how[keep]
    u10 = U10.u[j]
    return pd.DataFrame({"src": 1, "eng": U10.eng[j], "tix": -1, "tid": U10.tid[j], "sym": U10.sym[j],
                         "sday": U10.sday[j], "srank": U10.rank[j], "lane": U10.lane[j], "how": how, "u10": u10,
                         "i1": U10.i1[j], "ek": ek, "x": scheduled_day(how, ek, primary), "p0": PA10.O[u10, ek],
                         "atr": np.asarray(bk.atr, float)[br]})


# ====================================================================================================== the rows
def build_rows(TT, PA):
    """One row per evening a trade can decide (the closes of ek .. x-1), its mechanics and its label."""
    xk, xp, xo = hold_exit(PA, TT["u10"].to_numpy(), TT["x"].to_numpy())
    TT = TT.assign(xk=xk, xp=xp, xo=xo)
    p0_ = TT["p0"].to_numpy(float)
    with np.errstate(invalid="ignore"):
        ok = (xk < 99) & np.isfinite(xp) & np.isfinite(p0_) & (p0_ > 0)
    nd = np.where(ok, TT["x"].to_numpy() - TT["ek"].to_numpy(), 0).clip(0)
    j = np.repeat(np.arange(len(TT)), nd)
    off = np.arange(nd.sum()) - np.repeat(np.cumsum(nd) - nd, nd)
    ek = TT["ek"].to_numpy()[j]
    c = ek + off
    u = TT["u10"].to_numpy()[j]
    p0 = p0_[j]
    atr = TT["atr"].to_numpy(float)[j]
    x = TT["x"].to_numpy()[j]
    Cc, Cp, Hc, Lc = PA.C[u, c], PA.C[u, c - 1], PA.H[u, c], PA.L[u, c]
    mh, ml = PA.H[u, ek].copy(), PA.L[u, ek].copy()
    for d in range(1, TG.LAST_D):
        m = ek + d <= c
        if not m.any():
            break
        mh[m] = np.fmax(mh[m], PA.H[u[m], ek[m] + d])
        ml[m] = np.fmin(ml[m], PA.L[u[m], ek[m] + d])
    with np.errstate(invalid="ignore", divide="ignore"):
        R = pd.DataFrame({
            "j": j, "c": c, "held": (c - ek + 1).astype(float), "left": (x - c).astype(float),
            "pnl_pct": (Cc / p0 - 1) * 100, "pnl_atr": np.log(Cc / p0) / atr, "mfe_atr": np.log(mh / p0) / atr,
            "mae_atr": np.log(ml / p0) / atr, "day_atr": np.log(Cc / Cp) / atr, "range_atr": np.log(Hc / Lc) / atr,
            "clv": np.where(Hc > Lc, (Cc - Lc) / (Hc - Lc), 0.5), "atr_pct": atr * 100})
    sk, sp, so = sell_at(PA, u, c + 1)
    hk, hp, ho = TT["xk"].to_numpy()[j], TT["xp"].to_numpy(float)[j], TT["xo"].to_numpy(bool)[j]
    skey = sk + np.where(so, 0.0, 0.5)
    hkey = hk + np.where(ho, 0.0, 0.5)
    with np.errstate(invalid="ignore", divide="ignore"):
        valid = (sk < 99) & np.isfinite(sp) & (sp > 0) & (skey < hkey)
        y = np.where(valid, np.log(hp / sp) * 1e4, np.nan)
    i1 = TT["i1"].to_numpy()[j]
    R["valid"], R["y"] = valid, y
    R["sk"], R["sp"], R["so"], R["hk"], R["hp"], R["ho"] = sk, sp, so, hk, hp, ho
    R["dcal"] = i1 + c - 1
    R["end"] = i1 + np.maximum(np.where(sk < 99, sk, 0), hk) - 1
    return TT, R


def engine_ranks(bk, eng, dcal, sym):
    """The stock's rank in tonight's watchlist of its own engine and of the other (11 = not in the top 10)."""
    W = pd.DataFrame({"eng": np.asarray(bk.engine_arr).astype(str), "sidx": np.asarray(bk.i1, np.int64) - 1,
                      "sym": np.asarray(bk.symbols).astype(str), "rank": np.asarray(bk.rank, float)})
    W = W.groupby(["eng", "sidx", "sym"], as_index=False)["rank"].min()
    key = pd.DataFrame({"eng": np.asarray(eng).astype(str), "sidx": np.asarray(dcal, np.int64),
                        "sym": np.asarray(sym).astype(str)})
    own = key.merge(W, on=["eng", "sidx", "sym"], how="left")["rank"].to_numpy(float)
    oth = key.assign(eng=np.where(key["eng"] == "D", "ENS", "D")).merge(
        W, on=["eng", "sidx", "sym"], how="left")["rank"].to_numpy(float)
    return np.where(np.isfinite(own), own, 11.0), np.where(np.isfinite(oth), oth, 11.0)


def day_numbers(x):
    return np.asarray(pd.DatetimeIndex(np.asarray(x)).normalize().to_numpy()).astype("datetime64[D]").astype(np.int64)


def read_panel(path, cols, syms, days, log=LOG, chunk=8):
    """setuplab's attach: the panel's columns a few at a time, only the rows' stocks -> ({column: values aligned to
    the (symbol, day) rows}, missing columns)."""
    import pyarrow.parquet as pq
    names = pq.read_schema(path).names
    low = {c.lower(): c for c in names}
    dk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or not dk:
        raise ExitError("the panel needs symbol and timestamp columns")
    want = [c for c in cols if c in low]
    miss = [c for c in cols if c not in low]
    q = pd.DataFrame({"symbol": np.asarray(syms).astype(str), "dn": day_numbers(days)})
    need_dn = set(np.unique(q["dn"]).tolist())
    us = sorted(set(q["symbol"]))
    out = {c: np.full(len(q), np.nan) for c in cols}
    for i in range(0, len(want), chunk):
        part = want[i:i + chunk]
        rc = [low["symbol"], dk] + [low[c] for c in part]
        F = None
        try:
            F = pq.read_table(path, columns=rc, filters=[(low["symbol"], "in", us)]).to_pandas()
        except Exception:  # noqa: BLE001
            F = None
        if F is None or len(F) == 0:
            F = pd.read_parquet(path, columns=rc)
        if any(n is not None for n in F.index.names):
            F = F.reset_index()
        F.columns = [str(c_).lower() for c_ in F.columns]
        dkl = dk.lower()
        F["symbol"] = F["symbol"].astype(str).str.strip().str.upper()
        t = pd.to_datetime(F[dkl])
        if t.dt.tz is not None:
            t = t.dt.tz_convert(IST).dt.tz_localize(None)
        F["dn"] = day_numbers(t)
        F = F[F["dn"].isin(need_dn)].drop(columns=[dkl]).drop_duplicates(["symbol", "dn"], keep="last")
        M = q.merge(F, on=["symbol", "dn"], how="left")
        for c_ in part:
            out[c_] = pd.to_numeric(M[c_], errors="coerce").to_numpy(float)
        del F, M
        log(" panel: %d of %d features read" % (min(i + chunk, len(want)), len(want)))
    return out, miss


def market_state(mk, days):
    """NIFTY at each decision day's close: 1- and 5-session log returns; vollab's 5-session forecast (nifty_state's
    R forecast) against its median over the 250 sessions before (at least 120) and the flag at 1.25 (m5tree's rule)."""
    ds = mk.series("NIFTY50")
    if ds is None:
        raise ExitError("no NIFTY50 daily bars in the cache")
    cal = np.asarray(mk.cal).astype("datetime64[D]")
    _, _, _, Fh, _, _ = VL.nifty_state(ds, cal)
    _, _, _, Cn, _ = VL.daily_on_cal(ds, cal)
    n = len(cal)
    z = np.full(n, np.nan)
    for t in range(n):
        if np.isfinite(Fh[t]):
            w = Fh[max(0, t - STRESS_N):t]
            w = w[np.isfinite(w)]
            if len(w) >= STRESS_MIN:
                z[t] = Fh[t] / np.median(w)
    r1, r5 = np.full(n, np.nan), np.full(n, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        r1[1:] = np.log(Cn[1:] / Cn[:-1])
        r5[5:] = np.log(Cn[5:] / Cn[:-5])
    d = np.asarray(days).astype("datetime64[D]")
    pos = np.searchsorted(cal, d)
    ok = pos < n
    ok[ok] = cal[pos[ok]] == d[ok]
    p = np.minimum(pos, n - 1)
    zz = np.where(ok, z[p], np.nan)
    with np.errstate(invalid="ignore"):
        st = np.where(np.isfinite(zz), (zz >= STRESS_Z).astype(float), np.nan)
    return np.where(ok, r1[p], np.nan), np.where(ok, r5[p], np.nan), zz, st


def read_m5(path, sym, sday):
    """sigma5 (M5, %) at each trade's (symbol, signal day) from vollab's pick_forecasts.csv; NaN when missing or not
    positive."""
    F = pd.read_csv(path)
    need = {"symbol", "signal_day", "sigma5_M5_pct"}
    if not need <= set(F.columns):
        raise ExitError("%s lacks %s" % (Path(path).name, ", ".join(sorted(need - set(F.columns)))))
    s = pd.Series(pd.to_numeric(F["sigma5_M5_pct"], errors="coerce").to_numpy(float),
                  index=pd.MultiIndex.from_arrays([F["symbol"].astype(str).str.strip().str.upper().to_numpy(),
                                                   pd.to_datetime(F["signal_day"]).to_numpy().astype(
                                                       "datetime64[D]").astype(str)]))
    s = s[~s.index.duplicated(keep="last")]
    k = pd.MultiIndex.from_arrays([np.asarray(sym).astype(str), np.asarray(sday).astype("datetime64[D]").astype(str)])
    v = s.reindex(k).to_numpy(float)
    with np.errstate(invalid="ignore"):
        return np.where(np.isfinite(v) & (v > 0), v, np.nan), int(len(F))


def feature_frame(R, TT, bk, mk, panel, m5_tt, log=LOG):
    j = R["j"].to_numpy()
    X = {c: R[c].to_numpy(float) for c in MECH}
    eng = TT["eng"].to_numpy()[j].astype(str)
    X["eng_d"] = (eng == "D").astype(float)
    X["lane"] = TT["lane"].to_numpy()[j].astype(float)
    code = {h: float(i) for i, h in enumerate(HOWS)}
    X["how"] = np.array([code.get(str(h), np.nan) for h in TT["how"].to_numpy()[j]], float)
    X["srank"] = TT["srank"].to_numpy()[j].astype(float)
    sym = TT["sym"].to_numpy()[j].astype(str)
    X["rank_own"], X["rank_other"] = engine_ranks(bk, eng, R["dcal"].to_numpy(), sym)
    days = np.asarray(bk.cal)[R["dcal"].to_numpy()]
    X["nifty_r1"], X["nifty_r5"], X["nifty_z"], X["nifty_stress"] = market_state(mk, days)
    P, miss = read_panel(panel, list(PANEL), sym, days, log)
    for c in PANEL:
        X[c] = P[c]
    sig = m5_tt[j]
    X["m5_sigma5"] = sig
    with np.errstate(invalid="ignore"):
        X["m5_left"] = sig * np.sqrt(R["left"].to_numpy(float) / 5.0)
    X = pd.DataFrame({c: X[c] for c in FEATURES})
    A = np.array(X.to_numpy(float), dtype=float, copy=True)
    A[~np.isfinite(A)] = np.nan
    return pd.DataFrame(A, columns=list(FEATURES)), miss


# ====================================================================================================== the models
def year_bounds(cal, Y):
    return (int(np.searchsorted(cal, np.datetime64("%d-01-01" % Y))),
            int(np.searchsorted(cal, np.datetime64("%d-01-01" % (Y + 1)))))


def fit_predict(Xtr, ytr, Xte, cols):
    """One model: a column with no value in the training rows is left out (no split is possible on it; newer
    scikit-learn refuses it). -> (predictions, the columns left out)."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    keep = np.isfinite(Xtr).any(0)
    used = [c for c, k in zip(cols, keep) if k]
    cat = np.array([c == "how" for c in used])
    mdl = HistGradientBoostingRegressor(categorical_features=cat if cat.any() else None, **HGB)
    mdl.fit(Xtr[:, keep], ytr)
    return mdl.predict(Xte[:, keep]), [c for c, k in zip(cols, keep) if not k]


def walk_forward(R, X, cal, s_, log=LOG):
    """Per test year: models trained on the rows (tree and hypothetical) whose outcome finished before 1 January of
    that year -> predictions of that year's rows, and each fold's numbers."""
    y = R["y"].to_numpy(float)
    valid = R["valid"].to_numpy(bool)
    dcal, end = R["dcal"].to_numpy(), R["end"].to_numpy()
    pred = {m: np.full(len(R), np.nan) for m in MODELS}
    clip = np.full((len(R), 2), np.nan)
    m5 = np.isfinite(X["m5_sigma5"].to_numpy(float))
    folds = []
    for Y in TEST_YEARS:
        sY, eY = year_bounds(cal, Y)
        tr = valid & (end < sY) & (dcal >= s_) & np.isfinite(y)
        te = (dcal >= sY) & (dcal < eY)
        rec = {"year": Y, "train_rows": int(tr.sum()), "train_m5_rows": int((tr & m5).sum()),
               "test_rows": int(te.sum())}
        if tr.sum() < MIN_TRAIN or not te.any():
            rec["note"] = "too few training rows or no test rows: the frozen exits kept"
            folds.append(rec)
            continue
        lo, hi = np.quantile(y[tr], WINSOR)
        yc = np.clip(y[tr], lo, hi)
        clip[te] = (lo, hi)
        rec.update({"clip_lo": float(lo), "clip_hi": float(hi), "train_mean": float(yc.mean())})
        for m in MODELS:
            cols = list(model_cols(m))
            A = X[cols].to_numpy(float)
            pred[m][te], unused = fit_predict(A[tr], yc, A[te], cols)
            rec["blank_" + m] = len(unused)
            rec["blank_cols_" + m] = " ".join(unused)
        folds.append(rec)
        log(" %d: trained on %d rows (%d with M5), predicted %d" % (Y, rec["train_rows"], rec["train_m5_rows"],
                                                                     rec["test_rows"]))
    return pred, clip, folds


# ====================================================================================================== rules, books
def first_sales(R, src, pred):
    """Each tree trade's first eligible close whose prediction is below 0 -> (trade row j, sale day, price, at an
    open)."""
    sell = R["valid"].to_numpy(bool) & np.isfinite(pred) & (pred < 0) & (src == 0)
    S = R.loc[sell, ["j", "c", "sk", "sp", "so"]].sort_values(["j", "c"], kind="mergesort")
    return S.drop_duplicates("j", keep="first").reset_index(drop=True)


def apply_sales(T3, TT, S):
    out = {}
    for e, T in T3.items():
        T = {k: v.copy() for k, v in T.items()}
        jj = S["j"].to_numpy(np.int64)
        s = S[TT["eng"].to_numpy()[jj] == e]
        ix = TT["tix"].to_numpy()[s["j"].to_numpy(np.int64)]
        if len(ix):
            sk, sp, so = s["sk"].to_numpy(np.int64), s["sp"].to_numpy(float), s["so"].to_numpy(bool)
            T["ex"][ix] = np.where(sk < 99, T["i1"][ix] + sk - 1, TG.FAR)
            T["oexit"][ix] = so
            with np.errstate(invalid="ignore", divide="ignore"):
                T["net"][ix] = (sp / T["p0"][ix] - 1) * 100 - COST
            T["held"][ix] = np.where(so, sk - T["d"][ix], sk - T["d"][ix] + 1)
        out[e] = T
    return out


def open6_sales(TT, PA):
    """Every tree trade sells at the first executable open after its scheduled exit close (a scheduled close that is
    locked already sells at a later open: unchanged)."""
    tt = TT[(TT["src"] == 0).to_numpy()]
    u, x = tt["u10"].to_numpy(), tt["x"].to_numpy()
    xk, _, xo = hold_exit(PA, u, x)
    sk, sp, so = sell_at(PA, u, x + 1)
    ch = (xk == x) & ~xo & (sk < 99) & np.isfinite(sp)
    return pd.DataFrame({"j": tt.index.to_numpy()[ch], "sk": sk[ch], "sp": sp[ch], "so": so[ch]})


def run_books(Ts, C, cal, p0, t1):
    """Every start day's books and account; the 5-start account and each engine's 5-start book from the 5th start."""
    c0 = p0 + STARTS - 1
    acc, eng, per = [], {"D": [], "ENS": []}, []
    for s in range(p0, p0 + STARTS):
        B = {e: VL.book_sim2(Ts[e], C, s, t1) for e in ("D", "ENS")}
        r = VL.account_returns(B["D"][1], B["ENS"][1], cal, s, t1)
        acc.append(r[c0 - s:])
        rec = {"start": s, "r": r}
        for e in ("D", "ENS"):
            v = np.r_[1.0, B[e][1]]
            with np.errstate(invalid="ignore", divide="ignore"):
                re_ = np.where(v[:-1] > 0, v[1:] / v[:-1] - 1, 0.0)
            eng[e].append(re_[c0 - s:])
            rec["r_" + e] = re_
            rec["taken_" + e] = int(B[e][2].sum())
        rec["exposure"] = float(np.mean(0.5 * B["D"][4] + 0.5 * B["ENS"][4]))
        per.append(rec)
    return {"r": np.mean(acc, axis=0), "D": np.mean(eng["D"], axis=0), "ENS": np.mean(eng["ENS"], axis=0),
            "per": per}


def compare(B_, r, rb):
    x = (np.log1p(r) - np.log1p(rb)) * 1e4
    est, lo, hi, sd = VL.boot_mean(B_, np.arange(len(x)), x)
    p = (1.0 - VL.phi(est / sd)) if (np.isfinite(sd) and sd > 0) else np.nan
    return {"diff": est, "diff_lo": lo, "diff_hi": hi, "p_one": p}


def path_means(BK, cal, t1, key="r"):
    ay, fl = [], []
    for rec in BK["per"]:
        pn = VL.path_numbers(rec[key], cal[rec["start"]:t1 + 1])
        ay.append(pn["a_year"])
        fl.append(pn["fall"])
    return float(np.mean(ay)), float(np.mean(fl))


def decide(rows, pairs):
    a, b = pairs["M1 vs FROZEN"], pairs["M1 vs M0"]
    ok = bool(np.isfinite(a["diff_lo"]) and a["diff_lo"] > 0 and rows["M1"]["fall"] <= rows["FROZEN"]["fall"] and
              np.isfinite(b["diff_lo"]) and b["diff_lo"] > 0)
    return "PASS" if ok else "FAIL"


def m5_test(R, src, pred, clip, cal):
    """M2 against M1 on identical rows (the tree's valid decisions of the test years with an M5 forecast): the mean of
    (y - M1)^2 - (y - M2)^2, y clipped at the fold's training 1% / 99%; Boot over the decision days."""
    y = R["y"].to_numpy(float)
    m = (src == 0) & R["valid"].to_numpy(bool) & np.isfinite(R["m5_sigma5"].to_numpy(float)) & \
        np.isfinite(pred["M1"]) & np.isfinite(pred["M2"]) & np.isfinite(clip[:, 0]) & np.isfinite(y)
    res = {"rows": int(m.sum()), "diff": np.nan, "diff_lo": np.nan, "diff_hi": np.nan, "verdict": "ADDS NOTHING"}
    if m.sum() < M5_MIN_ROWS:
        return res
    yc = np.clip(y[m], clip[m, 0], clip[m, 1])
    d = (yc - pred["M1"][m]) ** 2 - (yc - pred["M2"][m]) ** 2
    days, di = np.unique(R["dcal"].to_numpy()[m], return_inverse=True)
    B_ = SU.Boot(np.asarray(cal)[days], B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    est, lo, hi, _ = VL.boot_mean(B_, di, d)
    res.update({"diff": est, "diff_lo": lo, "diff_hi": hi,
                "verdict": "ADDS" if (np.isfinite(lo) and lo > 0) else "ADDS NOTHING"})
    return res


def fold_table(R, src, pred, folds):
    y = R["y"].to_numpy(float)
    yrs = pd.DatetimeIndex(np.asarray(R["day"])).year.to_numpy()
    m5 = np.isfinite(R["m5_sigma5"].to_numpy(float))
    rows = []
    for f in folds:
        te = (yrs == f["year"]) & (src == 0) & R["valid"].to_numpy(bool) & np.isfinite(y)
        base = {k: f.get(k) for k in ("year", "train_rows", "train_m5_rows", "test_rows")}
        base.update({"tree_rows": int(te.sum()), "tree_rows_m5": int((te & m5).sum())})
        for m in MODELS:
            p = pred[m]
            k = te & np.isfinite(p)
            r = dict(base, model=m)
            if k.sum() >= 20 and "train_mean" in f:
                yc = np.clip(y[k], f["clip_lo"], f["clip_hi"])
                r["r2_oos"] = float(1 - np.sum((yc - p[k]) ** 2) / np.sum((yc - f["train_mean"]) ** 2))
                r["rank_corr"] = float(pd.Series(p[k]).rank().corr(pd.Series(y[k]).rank()))
                r["sold_pct"] = float(100 * (p[k] < 0).mean())
                r["y_if_sell"] = float(y[k][p[k] < 0].mean()) if (p[k] < 0).any() else np.nan
                r["y_if_hold"] = float(y[k][p[k] >= 0].mean()) if (p[k] >= 0).any() else np.nan
            rows.append(r)
    return pd.DataFrame(rows)


def sales_table(T3, rules, cal, p0, t1):
    """The exit model's (M1) sales on the tree's planned trades in the period: changed = net with M1's exit minus with
    the scheduled exit (points)."""
    out = []
    for e in ("D", "ENS"):
        T0, T1_ = T3[e], rules["M1"][e]
        ch = (T0["ent"] >= p0) & (T0["ent"] <= t1) & (T1_["ex"] != T0["ex"])
        dlt = T1_["net"][ch] - T0["net"][ch]
        how = np.array([str(g).split(":", 1)[-1] for g in T0["g"][ch]])
        held = T1_["held"][ch]
        groups = [("%s all sold early" % e, np.ones(int(ch.sum()), bool))]
        groups += [("%s bought by %s" % (e, h), how == h) for h in HOWS if (how == h).any()]
        groups += [("%s sold after %d close(s)" % (e, k), held == k) for k in range(0, 10) if (held == k).any()]
        for nm, g in groups:
            dd = dlt[g]
            ok = np.isfinite(dd)
            out.append({"group": nm, "trades": int(len(dd)), "changed_avg": float(dd[ok].mean()) if ok.any() else
                        np.nan, "changed_sum": float(dd[ok].sum()),
                        "better_pct": float(100 * (dd[ok] > 0).mean()) if ok.any() else np.nan})
    return pd.DataFrame(out, columns=["group", "trades", "changed_avg", "changed_sum", "better_pct"])


# ====================================================================================================== the report
def _md(df, cols, fmt):
    L = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for r in df.to_dict("records"):
        L.append("| " + " | ".join(fmt.get(c, lambda v: "-" if v is None else str(v))(r.get(c)) for c in cols)
                 + " |")
    return L


def _f(nd, sign=False):
    def g(v):
        try:
            if v is None or not np.isfinite(float(v)):
                return "-"
        except (TypeError, ValueError):
            return str(v)
        return (("%+." if sign else "%.") + str(nd) + "f") % float(v)
    return g


def write_report(d, info, Rp):
    rows, pairs, m5 = Rp["rows"], Rp["pairs"], Rp["m5"]
    fz, m1 = rows["FROZEN"], rows["M1"]
    a, b = pairs["M1 vs FROZEN"], pairs["M1 vs M0"]
    L = ["# %s - an exit meta model for the frozen tree" % VERSION, "",
         "%s .. %s (%d sessions; every rule averaged over %d start days); declaration %s; vollab run %s." % (
             info["from"], info["to"], info["days"], STARTS, info["declaration_sha256"][:16], info["vollab_run"]),
         "", "## Verdict", "",
         "**EXIT MODEL (M1): %s.** Against the frozen exits %s bp a day %s; against mechanics only %s bp a day %s; "
         "a year %s%% vs %s%%; worst fall %.2f%% vs %.2f%% (means of %d starts)." % (
             Rp["verdict"], VL._p(a["diff"]), VL._ci(a["diff_lo"], a["diff_hi"]), VL._p(b["diff"]),
             VL._ci(b["diff_lo"], b["diff_hi"]), VL._p(m1["a_year"]), VL._p(fz["a_year"]), m1["fall"], fz["fall"],
             STARTS),
         "PASS needs both intervals above 0 and a worst fall no deeper. A PASS is a candidate exit rule for a forward "
         "paper book beside the frozen tree; nothing in the frozen tree changes.", "",
         "**M5: %s.** On %d identical decisions with an M5 forecast, M1's squared error minus M2's: %s %s (bp^2; above "
         "0 = M5 predicts better)." % (m5["verdict"], m5["rows"], VL._p(m5["diff"], 1),
                                       VL._ci(m5["diff_lo"], m5["diff_hi"], 1)), "",
         "## Every rule (%d starts, paired days)" % STARTS, "",
         "| rule | what | a year | worst fall | D a year | D worst fall | ENS a year | ENS worst fall | trades taken "
         "| exposure |", "|---|---|---|---|---|---|---|---|---|---|"]
    for v in RULES:
        r = rows[v]
        L.append("| %s | %s | %s%% | %.2f%% | %s%% | %.2f%% | %s%% | %.2f%% | %.0f | %.2f |" % (
            v, WORDS[v], VL._p(r["a_year"]), r["fall"], VL._p(r["a_year_D"]), r["fall_D"], VL._p(r["a_year_ENS"]),
            r["fall_ENS"], r["trades"], r["exposure"]))
    L += ["", "| comparison | what it shows | account, bp a day | p (one-sided) | D book | ENS book |",
          "|---|---|---|---|---|---|"]
    for x, y_, w in PAIRS:
        k = "%s vs %s" % (x, y_)
        c = pairs[k]
        L.append("| %s | %s | %s %s | %s | %s %s | %s %s |" % (
            k, w, VL._p(c["diff"]), VL._ci(c["diff_lo"], c["diff_hi"]), _f(4)(c["p_one"]), VL._p(c["D"]["diff"]),
            VL._ci(c["D"]["diff_lo"], c["D"]["diff_hi"]), VL._p(c["ENS"]["diff"]),
            VL._ci(c["ENS"]["diff_lo"], c["ENS"]["diff_hi"])))
    L += ["", "Karan's goal (worst fall -25% or better, keeping 70% of the frozen tree's return): " + "; ".join(
        "%s %s" % (v, "met" if (rows[v]["fall"] <= 25 and rows[v]["a_year"] >= 0.7 * fz["a_year"]) else "not met")
        for v in RULES) + ".", "", "## Does each model predict? (the tree's valid decisions of each year)", "",
        "y = the return from tomorrow's executable open to the scheduled exit, bp. R2 against the training mean (y "
        "clipped as in training); sold = predicted below 0; M5 coverage = rows with an M5 forecast.", ""]
    L += _md(Rp["folds"], ["year", "model", "train_rows", "train_m5_rows", "tree_rows", "tree_rows_m5", "r2_oos",
                           "rank_corr", "sold_pct", "y_if_sell", "y_if_hold"],
             {"r2_oos": _f(4, True), "rank_corr": _f(3, True), "sold_pct": _f(1), "y_if_sell": _f(1, True),
              "y_if_hold": _f(1, True)})
    L += ["", "## The exit model's sales (the tree's planned trades in the period, before the slot limit)", ""]
    L += _md(Rp["sales"], ["group", "trades", "changed_avg", "changed_sum", "better_pct"],
             {"changed_avg": _f(2, True), "changed_sum": _f(1, True), "better_pct": _f(1)})
    L += ["", "changed = the trade's net with the model's exit minus with the scheduled exit (points): above 0 = a "
          "loss avoided or a gain locked, below 0 = a gain missed.", "", "## The rows", ""]
    L += ["- %s: %s" % kv for kv in info["counts"].items()]
    L += ["", "## Read this", "",
          "- What is new (Karan's correction): trailing stops and the recovery study already reacted to events after "
          "entry; this learns the value of holding on at every eligible close, across the calm open buys and all "
          "seven setups.",
          "- Ranks 4-10 are hypothetical trades used for training only; money is the D and ENS top-three books.",
          "- The lockbox is spent and the frozen tree was drawn on 2020-26 data; a PASS earns a forward paper book, "
          "nothing more.", "", "## Checks", ""] + ["- %s: %s" % kv for kv in info["checks"].items()]
    (d / "EXITLAB.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ====================================================================================================== the run
def prepare(a, log=LOG):
    dp, ddoc = load_declaration()
    found = {"vollab": VL.VERSION, "setuplab": SU.VERSION, "treelab": TL.VERSION, "triggerlab": TG.VERSION,
             "tradelab": TC.VERSION}
    bad = ["%s (found %s)" % (v, found[k]) for k, v in NEEDS.items() if found[k] != v]
    if bad:
        raise ExitError("needs %s" % ", ".join(bad))
    root, panel = VL.resolve_inputs(a)
    out = guard_out(a.out, root)
    pf = Path(a.run) / "pick_forecasts.csv"
    if not pf.is_file():
        raise ExitError("%s not found (give --run a VOLLAB_<date>_<nnn> folder)" % pf)
    need = {"symbol", "signal_day", "sigma5_M5_pct"} - set(pd.read_csv(pf, nrows=0).columns)
    if need:
        raise ExitError("%s lacks %s" % (pf.name, ", ".join(sorted(need))))
    TS = VL.tree_setup(a, root, panel, log)
    bk = TS["bk"]
    checks = dict(TS["checks"])
    mk = TD.Market(root, TD.Production(stage_e_any=bool(getattr(a, "stage_e_any", False))))
    U10 = Picks(bk, TS["cuts"]["2/3"], TS["tdoc"], TS["s_"], RANKS_ALL)
    PA10, why = load_lean(U10, bk, mk, log)
    off = int((~PA10.ok).sum())
    if U10.nu == 0 or off > TG.MISMATCH_MAX * U10.nu:
        raise ExitError("%d of %d picks could not be matched to the cache's bars (%s)" % (off, U10.nu, why))
    U3 = TG.Universe(bk, TS["cuts"]["2/3"], TS["tdoc"], TS["s_"])
    pos = {k: i for i, k in enumerate(U10.ukey)}
    k3 = np.char.add(np.char.add(U3.usym.astype(str), "|"), U3.usday.astype(str))
    map3 = np.array([pos.get(k, -1) for k in k3], np.int64)
    if (map3 < 0).any():
        raise ExitError("the top-3 picks are not all among ranks 1-10 - send Claude this line")
    PA3 = slice_paths(PA10, map3)
    U3.keep(PA3.ok)
    U10.keep(PA10.ok)
    checks["picks"] = "%d engine picks of D and ENS ranks 1-10 (%d distinct), %d of them ranks 1-3; %d distinct " \
                      "dropped (prices not matched: %s)" % (U10.n, int(PA10.ok.sum()), U3.n, off, why or "none")
    p0 = int(np.searchsorted(bk.cal, np.datetime64(START)))
    t1 = int(TS["t1"])
    if p0 + STARTS - 1 >= t1:
        raise ExitError("the frozen trades end before %s" % START)
    return {"dp": dp, "ddoc": ddoc, "root": root, "panel": panel, "out": out, "pf": pf, "TS": TS, "mk": mk,
            "U10": U10, "PA10": PA10, "U3": U3, "PA3": PA3, "map3": map3, "p0": p0, "t1": t1, "checks": checks}


def run(a, log=LOG):
    t0 = time.time()
    G = prepare(a, log)
    TS, U3, PA3, U10, PA10 = G["TS"], G["U3"], G["PA3"], G["U10"], G["PA10"]
    bk, p0, t1, checks = TS["bk"], G["p0"], G["t1"], G["checks"]
    cal = np.asarray(bk.cal)
    cal_d = cal.astype("datetime64[D]")
    for k_, v_ in checks.items():
        log(" %s: %s" % (k_, v_))
    if getattr(a, "check_only", False):
        log("CHECK OK - the frozen tree reproduced, %d picks matched; nothing computed or written." % U10.n)
        return None
    # ---- the trades and their rows
    T3, TTt = tree_trades(TS, U3, PA3, G["map3"])
    TT = pd.concat([TTt, hypo_trades(TS, U10, PA10)], ignore_index=True)
    TT, R = build_rows(TT, PA10)
    late = R["dcal"].to_numpy() >= len(cal)
    if late.any():                      # the cache runs past the watchlist's calendar: those evenings have no date
        R = R[~late].reset_index(drop=True)
    src = TT["src"].to_numpy()[R["j"].to_numpy()]
    for e in ("D", "ENS"):
        tt = TT[((TT["src"] == 0) & (TT["eng"] == e)).to_numpy()]
        T = T3[e]
        ix = tt["tix"].to_numpy()
        hk = tt["xk"].to_numpy()
        ok = hk < 99
        with np.errstate(invalid="ignore", divide="ignore"):
            nt = (tt["xp"].to_numpy(float) / tt["p0"].to_numpy(float) - 1) * 100 - COST
        same = len(ix) == len(T["ex"]) and np.array_equal(T["ex"][ix][ok], (tt["i1"].to_numpy() + hk - 1)[ok]) and \
            np.array_equal(T["oexit"][ix][ok], tt["xo"].to_numpy(bool)[ok]) and \
            np.allclose(T["net"][ix][ok], nt[ok], atol=1e-9, equal_nan=True) and \
            np.array_equal(T["d"][ix], tt["ek"].to_numpy())
        if not same:
            raise ExitError("the scheduled exits rebuilt here differ from triggerlab's %s trades - send Claude this "
                            "line" % e)
    checks["exits"] = "the scheduled exits rebuilt here equal triggerlab's frozen trades (D and ENS)"
    m5_tt, m5_file = read_m5(G["pf"], TT["sym"].to_numpy(), TT["sday"].to_numpy())
    R["day"] = cal[R["dcal"].to_numpy()]
    X, miss = feature_frame(R, TT, bk, G["mk"], G["panel"], m5_tt, log)
    R["m5_sigma5"] = X["m5_sigma5"].to_numpy()
    pred, clip, folds = walk_forward(R, X, cal_d, int(TS["s_"]), log)
    # ---- the rules and their books
    for e in ("D", "ENS"):
        if not np.array_equal(VL.book_sim2(T3[e], PA3.C, p0, t1)[1], TG.book_sim(T3[e], PA3.C, p0, t1)[1]):
            raise ExitError("vollab's book differs from triggerlab's on the frozen %s trades - send Claude this "
                            "line" % e)
    none_ = apply_sales(T3, TT, first_sales(R, src, np.full(len(R), np.inf)))
    if not all(np.array_equal(none_[e]["ex"], T3[e]["ex"]) and np.array_equal(none_[e]["oexit"], T3[e]["oexit"]) and
               np.array_equal(none_[e]["net"], T3[e]["net"], equal_nan=True) for e in T3):
        raise ExitError("a rule that never sells does not give the frozen trades - send Claude this line")
    checks["identity"] = "the frozen books are triggerlab's (vollab's book = triggerlab's book on the frozen trades); " \
                         "a rule that never sells gives the frozen trades exactly"
    rules, sales = {"FROZEN": T3}, {}
    for m in MODELS:
        sales[m] = first_sales(R, src, pred[m])
        rules[m] = apply_sales(T3, TT, sales[m])
    rules["OPEN6"] = apply_sales(T3, TT, open6_sales(TT, PA10))
    BK = {v: run_books(rules[v], PA3.C, cal, p0, t1) for v in RULES}
    c0 = p0 + STARTS - 1
    days = cal[c0:t1 + 1]
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    rows = {}
    for v in RULES:
        ay, fl = path_means(BK[v], cal, t1)
        ayd, fld = path_means(BK[v], cal, t1, "r_D")
        aye, fle = path_means(BK[v], cal, t1, "r_ENS")
        rows[v] = {"a_year": ay, "fall": fl, "a_year_D": ayd, "fall_D": fld, "a_year_ENS": aye, "fall_ENS": fle,
                   "trades": float(np.mean([p["taken_D"] + p["taken_ENS"] for p in BK[v]["per"]])),
                   "exposure": float(np.mean([p["exposure"] for p in BK[v]["per"]]))}
    pairs = {}
    for x, y_, _ in PAIRS:
        c = compare(B_, BK[x]["r"], BK[y_]["r"])
        c["D"] = compare(B_, BK[x]["D"], BK[y_]["D"])
        c["ENS"] = compare(B_, BK[x]["ENS"], BK[y_]["ENS"])
        pairs["%s vs %s" % (x, y_)] = c
    verdict = decide(rows, pairs)
    m5 = m5_test(R, src, pred, clip, cal)
    ft = fold_table(R, src, pred, folds)
    Rp = {"rows": rows, "pairs": pairs, "verdict": verdict, "m5": m5, "folds": ft,
          "sales": sales_table(T3, rules, cal, p0, t1)}
    info = {"from": str(pd.Timestamp(days[0]).date()), "to": str(pd.Timestamp(days[-1]).date()), "days": len(days),
            "declaration_sha256": G["ddoc"]["sha256"], "vollab_run": Path(a.run).name,
            "counts": {
                "trades": "%d tree (planned, before the slot limit, the whole window) + %d hypothetical (ranks "
                          "4-10)" % (int((TT["src"] == 0).sum()), int((TT["src"] == 1).sum())),
                "rows": "%d (tree %d, hypothetical %d); valid decisions %d; moot %d (a sale that could not come "
                        "before the scheduled exit); %d evenings after the watchlist's calendar left out" % (
                            len(R), int((src == 0).sum()), int((src == 1).sum()), int(R["valid"].sum()),
                            int((~R["valid"]).sum()), int(late.sum())),
                "panel features missing from the panel": ", ".join(miss) or "none",
                "M5": "%s: %d rows; %d of %d trades with a forecast" % (G["pf"].name, m5_file,
                                                                       int(np.isfinite(m5_tt).sum()), len(TT))}}
    checks["period"] = "%s .. %s, %d sessions, each rule the mean of %d accounts started %s .. %s" % (
        info["from"], info["to"], len(days), STARTS, str(pd.Timestamp(cal[p0]).date()),
        str(pd.Timestamp(cal[c0]).date()))
    # ---- outputs
    d = SU.new_run_dir(G["out"], "EXITLAB")
    ledger(G["out"], {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                      "tool": VERSION, "declaration_sha256": G["ddoc"]["sha256"]})
    files = ["exitlab_rules.csv", "exitlab_daily.csv", "exitlab_trades.csv", "exitlab_folds.csv",
             "exitlab_sales.csv", "exitlab_rows.parquet"]
    rr = []
    for v in RULES:
        r = {"rule": v, "what": WORDS[v]}
        r.update(rows[v])
        rr.append(r)
    for k, c in pairs.items():
        for part in ("", "D", "ENS"):
            cc = c if part == "" else c[part]
            rr.append({"rule": k + ("" if part == "" else " (%s book)" % part), "what": "comparison",
                       "diff": cc["diff"], "diff_lo": cc["diff_lo"], "diff_hi": cc["diff_hi"], "p_one": cc["p_one"]})
    pd.DataFrame(rr).to_csv(d / files[0], index=False, float_format="%.12g")
    DD = {"date": pd.DatetimeIndex(days).strftime("%Y-%m-%d")}
    for v in RULES:
        DD["r_" + v], DD["r_%s_D" % v], DD["r_%s_ENS" % v] = BK[v]["r"], BK[v]["D"], BK[v]["ENS"]
    pd.DataFrame(DD).to_csv(d / files[1], index=False, float_format="%.12g")
    TR = []
    for e in ("D", "ENS"):
        T0 = T3[e]
        df = pd.DataFrame({"engine": e, "trade_id": T0["tid"], "symbol": T0["sym"],
                           "signal_day": pd.DatetimeIndex(T0["sday"]).strftime("%Y-%m-%d"),
                           "how": [str(g).split(":", 1)[-1] for g in T0["g"]], "rank": T0["rank"],
                           "entry_day": pd.DatetimeIndex(cal[T0["ent"]]).strftime("%Y-%m-%d"), "entry_k": T0["d"],
                           "entry_price": T0["p0"], "in_period": (T0["ent"] >= p0) & (T0["ent"] <= t1)})
        for v in RULES:
            Tv = rules[v][e]
            df["exit_" + v] = [str(pd.Timestamp(cal[x]).date()) if x < len(cal) else "pending" for x in Tv["ex"]]
            df["at_open_" + v] = Tv["oexit"]
            df["net_" + v] = Tv["net"]
        TR.append(df)
    pd.concat(TR, ignore_index=True).to_csv(d / files[2], index=False, float_format="%.10g")
    ft.to_csv(d / files[3], index=False, float_format="%.10g")
    Rp["sales"].to_csv(d / files[4], index=False, float_format="%.10g")
    j = R["j"].to_numpy()
    RO = pd.DataFrame({"src": np.where(src == 0, "tree", "hypothetical"), "engine": TT["eng"].to_numpy()[j],
                       "trade_id": TT["tid"].to_numpy()[j], "symbol": TT["sym"].to_numpy()[j],
                       "signal_day": pd.DatetimeIndex(TT["sday"].to_numpy()[j]).strftime("%Y-%m-%d"),
                       "how_name": TT["how"].to_numpy()[j].astype(str), "entry_k": TT["ek"].to_numpy()[j],
                       "exit_k": TT["x"].to_numpy()[j], "entry_price": TT["p0"].to_numpy(float)[j],
                       "close_k": R["c"].to_numpy(),
                       "decision_day": pd.DatetimeIndex(R["day"]).strftime("%Y-%m-%d"),
                       "valid": R["valid"].to_numpy(), "y_bp": R["y"].to_numpy(), "sell_k": R["sk"].to_numpy(),
                       "sell_price": R["sp"].to_numpy(), "sell_at_open": R["so"].to_numpy(),
                       "hold_k": R["hk"].to_numpy(), "hold_price": R["hp"].to_numpy(),
                       "hold_at_open": R["ho"].to_numpy(),
                       "end_day": pd.DatetimeIndex(cal[np.minimum(R["end"].to_numpy(), len(cal) - 1)]).strftime(
                           "%Y-%m-%d")})
    for c_ in FEATURES:
        RO[c_] = X[c_].to_numpy()
    for m in MODELS:
        RO["pred_" + m] = pred[m]
    RO["clip_lo"], RO["clip_hi"] = clip[:, 0], clip[:, 1]
    RO.to_parquet(d / files[5], index=False)
    import platform
    import sklearn
    import pyarrow
    checks["libraries"] = "python %s, pandas %s, numpy %s, scikit-learn %s, pyarrow %s (the models' numbers depend on " \
                          "scikit-learn's version)" % (platform.python_version(), pd.__version__, np.__version__,
                                                       sklearn.__version__, pyarrow.__version__)
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info["checks"] = checks
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": G["ddoc"]["sha256"], "period": [info["from"], info["to"]], "rules": rows,
              "pairs": pairs, "m5": m5, "decision": {"EXIT MODEL (M1)": verdict, "M5": m5["verdict"]},
              "folds": folds, "missing_panel_features": miss, "counts": info["counts"],
              "libraries": checks["libraries"]}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "EXITLAB_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(G["dp"].read_text(encoding="utf-8"), encoding="utf-8")
    write_report(d, info, Rp)
    (d / "RUN.json").write_text(json.dumps({"version": VERSION, "root": str(G["root"]), "panel": str(G["panel"]),
                                            "data": str(a.data), "run": str(a.run), "checks": checks},
                                           indent=1, default=str), encoding="utf-8")
    files += ["EXITLAB_RESULT.json", "DECLARATION.json", "EXITLAB.md", "RUN.json"]
    SU.write_hashes(d, files)
    ledger(G["out"], {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                      "decision": result["decision"], "minutes": round((time.time() - t0) / 60, 1)})
    pa, pb, po = pairs["M1 vs FROZEN"], pairs["M1 vs M0"], pairs["OPEN6 vs FROZEN"]
    log("EXITLAB WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    log(" EXIT MODEL (M1): %s (vs frozen %s bp a day %s; vs mechanics only %s %s; a year %s%% vs %s%%; worst fall "
        "%.2f%% vs %.2f%%)" % (verdict, VL._p(pa["diff"]), VL._ci(pa["diff_lo"], pa["diff_hi"]), VL._p(pb["diff"]),
                               VL._ci(pb["diff_lo"], pb["diff_hi"]), VL._p(rows["M1"]["a_year"]),
                               VL._p(rows["FROZEN"]["a_year"]), rows["M1"]["fall"], rows["FROZEN"]["fall"]))
    log(" M5: %s (%d identical rows, %s %s bp^2)" % (m5["verdict"], m5["rows"], VL._p(m5["diff"], 1),
                                                    VL._ci(m5["diff_lo"], m5["diff_hi"], 1)))
    log(" OPEN6 vs frozen: %s bp a day %s" % (VL._p(po["diff"]), VL._ci(po["diff_lo"], po["diff_hi"])))
    return d


def main(argv=None):
    ap = argparse.ArgumentParser(prog="exitlab", description=VERSION)
    ap.add_argument("--root", required=True, help="the cache root (%%CACHE_DAILY_ROOT%%)")
    ap.add_argument("--data", required=True, help="setuplab's watchlist folder (C:\\QuantData\\setuplab\\WL_R1_10)")
    ap.add_argument("--run", required=True,
                    help="the vollab run folder with pick_forecasts.csv (C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn>)")
    ap.add_argument("--out", required=True, help="the output folder (C:\\QuantData\\exitlab)")
    ap.add_argument("--panel", help="panel_oc's panel.parquet (default: <root>\\panel_oc\\panel.parquet)")
    ap.add_argument("--check-only", dest="check_only", action="store_true", help="check the inputs, write nothing")
    ap.add_argument("--stage-e-any", dest="stage_e_any", action="store_true",
                    help="accept a stage_e_execution.py that is not the shipped v1.2")
    a = ap.parse_args(argv)
    try:
        run(a)
    except (ExitError, VL.VLError, TG.TGError, TL.TLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
