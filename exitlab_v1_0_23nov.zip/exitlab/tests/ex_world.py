"""
tests/ex_world.py - synthetic worlds for exitlab's tests (daily bars only; nothing here ships to production).

make_world(base, seed, kind) writes the cache root (<SYM>_daily.parquet, NIFTY50_daily.parquet, panel_oc\\panel.parquet,
vollab's test stand-ins for the production modules), setuplab's watchlist folder (D and ENS ranks 1-10 a day from 2020)
and a vollab run folder with pick_forecasts.csv (sigma5_M5_pct for the D and ENS ranks 1-3 picks from sig_from, 3%
left blank).
Every world: 2% a day per stock around a NIFTY drifting 0.04% a day; the frozen setups S2 and C3 never fill (their
inputs only fall); lower circuits on 0.4% of stock-days (half a close at the 5% band with the low there, half a frozen
day: open = high = low = close at the band), so locked closes and opens, waits for an unlocked open and moot decisions
all occur.
  absent: d_rsi7 = 50 + noise; sigma5 = noise.
  exit:   on 5% of stock-days (2020 on) d_rsi7 reads 80 at the close and the stock then falls 2% in each of the next
          three sessions, after the next open (that day has no overnight move); on another 5% it reads 20 and the
          stock rises the same way (else 50; sd 5): the full model reads d_rsi7 and sells the falls at the next open;
          mechanics only cannot see them coming. The rises keep the average stock's drift where it was.
  m5:     from sig_from, a quarter of the stocks picked (D or ENS, ranks 1-10) fall 1.5% a session from D2 to D5 (after
          the D2 open) and a quarter rise the same way; the ranks 1-3 picks' sigma5 is 6 for a fall, 2 for a rise, else
          3 (x noise): with M5 the model sells the falls at the D2 open; without it, it cannot tell them in advance.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
VOLLAB = Path(os.environ.get("VOLLAB_DIR") or (HERE.parent.parent / "vollab"))
sys.path.insert(0, str(VOLLAB / "tests"))
import vl_world as VW  # noqa: E402

IST = "Asia/Kolkata"
FZ = VW.FZ
ELIG = VW.ELIG
KINDS = ("absent", "exit", "m5")


def make_world(base: Path, seed: int, kind: str, n_sym=30, per_day=10, start="2019-05-01", end="2026-06-30",
               sig_from="2022-10-01", SU=None, lock_rate=0.004):
    assert kind in KINDS
    rng = np.random.default_rng(seed)
    root, data, run = base / "root", base / "data", base / "vollab_run" / "VOLLAB_20261122_001"
    for p in (root / "panel_oc", data, run):
        p.mkdir(parents=True, exist_ok=True)
    VW.use_mods(root)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    sig_t = int(np.searchsorted(cal, pd.Timestamp(sig_from)))
    rp = np.random.default_rng(seed + 1000)
    chosen = {(t, e): rp.choice(n_sym, per_day, replace=False) for t in range(t0, T - 12) for e in ("D", "ENS")}
    m = rng.normal(0.0004, 0.008, T)
    beta = rng.uniform(0.8, 1.2, n_sym)
    R = beta[:, None] * m[None, :] + 0.02 * rng.normal(0, 1, (n_sym, T))
    on = rng.uniform(0.2, 0.4, (n_sym, T))                     # the overnight share of each day's move
    flag = np.zeros((n_sym, T), np.int64)                     # +1: falls ahead, -1: rises ahead
    fate = {}
    if kind == "exit":
        u_ = rng.random((n_sym, T - 12 - t0))
        flag[:, t0:T - 12] = np.where(u_ < 0.05, 1, np.where(u_ < 0.10, -1, 0))
        for s, t in zip(*np.nonzero(flag)):
            R[s, t + 1:t + 4] -= 0.02 * flag[s, t]
            on[s, t + 1] = 0.0
    if kind == "m5":
        for t in range(max(t0, sig_t), T - 12):
            for s in sorted(set(chosen[(t, "D")]) | set(chosen[(t, "ENS")])):
                u_ = rng.random()
                f_ = 1 if u_ < 0.25 else (-1 if u_ < 0.5 else 0)
                fate[(s, t)] = f_
                if f_:
                    R[s, t + 2:t + 6] -= 0.015 * f_
                    on[s, t + 2] = 0.0
    C = 100.0 * np.exp(rng.normal(0, 0.4, n_sym))[:, None] * np.exp(np.cumsum(R, axis=1))
    Cp = np.c_[C[:, :1] / np.exp(R[:, :1]), C[:, :-1]]
    O = Cp * np.exp(on * R)
    H = np.maximum(O, C) * np.exp(np.abs(rng.normal(0, 0.3, (n_sym, T))) * 0.02)
    L = np.minimum(O, C) * np.exp(-np.abs(rng.normal(0, 0.3, (n_sym, T))) * 0.02)
    # lower circuits: the path from the locked close on is scaled so the close sits at the 5% band
    lk = rng.random((n_sym, T)) < lock_rate
    lk[:, :t0], lk[:, T - 12:] = False, False
    frozen_day = rng.random((n_sym, T)) < 0.5
    for s, t in zip(*np.nonzero(lk)):
        band = round(C[s, t - 1] * 0.95, 2)
        f = band / C[s, t]
        C[s, t:] *= f
        O[s, t + 1:] *= f
        H[s, t + 1:] *= f
        L[s, t + 1:] *= f
        if frozen_day[s, t]:
            O[s, t] = H[s, t] = L[s, t] = C[s, t] = band
        else:
            C[s, t] = L[s, t] = band
            O[s, t] = C[s, t - 1] * 0.985
            H[s, t] = max(O[s, t], band) * 1.004
    V = rng.lognormal(13, 0.15, (n_sym, T))
    for s in range(n_sym):
        pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": O[s], "high": H[s], "low": L[s],
                      "close": C[s], "volume": V[s]}).to_parquet(root / ("%s_daily.parquet" % syms[s]), index=False)
    nc = 18000 * np.exp(np.cumsum(m))
    no = np.r_[18000, nc[:-1]] * np.exp(0.3 * m)
    nh = np.maximum(no, nc) * np.exp(np.abs(rng.normal(0, 0.3 * 0.008, T)))
    nl = np.minimum(no, nc) * np.exp(-np.abs(rng.normal(0, 0.3 * 0.008, T)))
    pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": no, "high": nh, "low": nl,
                  "close": nc, "volume": np.nan}).to_parquet(root / "NIFTY50_daily.parquet", index=False)
    # the panel: the frozen setups' inputs, two of exitlab's stock inputs and the eligibility column
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)), axis=1) for f in FZ}
    for f in ("d_mdi14_diff5", "d_bb_bw_20"):                  # only falling: S2 and C3 never fill
        X[f] = -np.cumsum(np.abs(rng.normal(0, 1, (n_sym, T))) + 0.01, axis=1)
    X["d_bb_pctb_20"] = rng.normal(0.3, 0.5, (n_sym, T))
    X["w_ret_13w"] = np.cumsum(rng.normal(0, 3, (n_sym, T)), axis=1)
    X["d_rsi7"] = 50 + 30 * flag + rng.normal(0, 5, (n_sym, T))   # 80 before a fall, 20 before a rise
    X["d_adx14"] = rng.normal(25, 8, (n_sym, T))
    X[ELIG] = (rng.random((n_sym, T)) > 0.03).astype(float)
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(pd.DatetimeIndex(cal).tz_localize(IST), n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the watchlist and M5
    atr = np.vstack([SU.atr_simple(H[s], L[s], C[s]) for s in range(n_sym)])
    rows, fc = [], {}
    for t in range(t0, T - 12):
        for eng in ("D", "ENS"):
            for rk, s in enumerate(chosen[(t, eng)], 1):
                e1 = O[s, t + 1]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": C[s, t], "entry": e1, "status": "ok",
                       "net_bp": (C[s, t + 5] / e1 - 1) * 1e4 - 35, "s_atr14": atr[s, t], "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[s, t + k] / e1 - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[s, t + k] / C[s, t + k - 1] - 1
                rows.append(row)
                if rk <= 3 and t >= sig_t and (syms[s], t) not in fc:
                    if kind == "m5":
                        v = {1: 6.0, -1: 2.0, 0: 3.0}[fate.get((s, t), 0)] * np.exp(rng.normal(0, 0.1))
                    else:
                        v = 100 * 0.02 * np.sqrt(5) * np.exp(rng.normal(0, 0.25))
                    fc[(syms[s], t)] = v if rng.random() > 0.03 else np.nan
    pd.DataFrame(rows).to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    pd.DataFrame({"symbol": [k[0] for k in fc], "signal_day": [str(cal[k[1]].date()) for k in fc],
                  "row_found": True, "sigma5_M5_pct": list(fc.values())}).to_csv(run / "pick_forecasts.csv",
                                                                                 index=False, float_format="%.5g")
    return root, data, run, {"cal": cal, "syms": syms, "O": O, "H": H, "L": L, "C": C, "flag": flag, "fate": fate,
                             "locks": lk, "frozen_day": frozen_day & lk, "nifty": nc}
