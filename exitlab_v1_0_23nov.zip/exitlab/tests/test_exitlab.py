"""
tests for exitlab v1.0 - three synthetic worlds (tests/ex_world.py: daily bars only) run through exitlab, and the
rules rebuilt by hand from the worlds' own bars, watchlist, panel and forecasts. Ends with  VERIFIED (exitlab v1.0)
or  FAILED.
  t1  the rows and the label on hand-made paths: how many evenings each trade decides (S1 at D5: none, N1 at D5: four,
      a D1 open buy: four), a locked open waits for the next unlocked one, a locked scheduled close sells at the next
      open, a sale that cannot come before the scheduled exit is moot, stuck sales, the scheduled exit day
  t2  the trades: the tree's (ranks 1-3: D's first calm pick opening at or above the signal close, ENS's every calm
      pick, every other pick the earliest of the seven setups' fills, by setuplab's rule in a loop) and the
      hypothetical ones (ranks 4-10), rebuilt from the world's bars and panel
  t3  every row by hand: the mechanics from the fill, the sale tomorrow and the scheduled exit under stage E's lock
      rule, valid / moot, the label
  t4  the inputs by hand: tonight's ranks in both engines, NIFTY's returns and stress, the panel's values at tonight's
      close, M5 and M5 x sqrt(left / 5), the trade's inputs
  t5  the walk-forward by hand: each year's training rows (outcome finished before 1 January), the clip, a refit of
      M0, M1 and M2 with scikit-learn from the declaration's settings gives the same predictions
  t6  the exit rules by hand: the first valid evening below 0 sells tomorrow; the scheduled exits; OPEN6
  t7  the books by hand (3 slots, 1/3 of the closed value, freed slots reused, a sale at an open frees its slot for
      that open, marks at the closes), the 5 starts, the 50:50 account restarted each January, a year, worst fall,
      the comparisons, intervals and p's, the M5 test, the decision rule on hand-made cases
  t8  the planted worlds pass their own rule (exit: the exit model PASSES and M5 adds nothing; m5: M5 ADDS); the
      absent world passes neither
  t9  refusals (no pick_forecasts.csv, no M5 column, --out inside the cache, an edited declaration), --check-only
      writes nothing, the outputs' hashes, the ledger, the report's sections
  t10 a cache that runs past the watchlist's calendar: those evenings are left out and counted, nothing breaks
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import os
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import exitlab as X  # noqa: E402
import ex_world as EW  # noqa: E402

sys.path.insert(0, str(X.VOLLAB / "tests"))
import test_m5tree as TM  # noqa: E402  (hand_fill, hand_cuts, panel: setuplab's fill rule by a loop)

VL, SU, TG = X.VL, X.SU, X.TG
FAILS, N_OK = [], [0]
SEED = 31
BANDS = (0.02, 0.05, 0.10, 0.20)
HOWS = ("open", "S1", "S2", "S3", "C1", "C2", "C3", "N1")
WINDOW = pd.Timestamp("2021-01-01")


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)
        if os.environ.get("EXITLAB_FAILFAST"):
            raise SystemExit(1)


def same(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


def run_world(tmp, kind):
    root, data, run, W = EW.make_world(tmp / kind, SEED, kind, SU=SU)
    out = tmp / kind / "out"
    with redirect_stdout(io.StringIO()) as buf:
        rc = X.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(out),
                     "--stage-e-any"])
    d = sorted(out.glob("EXITLAB_*"))
    return {"root": root, "data": data, "run": run, "W": W, "out": out, "rc": rc, "d": d[-1] if d else None,
            "log": buf.getvalue()}


def outputs(d):
    return {"R": pd.read_parquet(d / "exitlab_rows.parquet"), "T": pd.read_csv(d / "exitlab_trades.csv"),
            "D": pd.read_csv(d / "exitlab_daily.csv"), "U": pd.read_csv(d / "exitlab_rules.csv"),
            "F": pd.read_csv(d / "exitlab_folds.csv"),
            "J": json.loads((d / "EXITLAB_RESULT.json").read_text(encoding="utf-8")),
            "md": (d / "EXITLAB.md").read_text(encoding="utf-8")}


# ====================================================================================================== hand rules
class Hand:
    """stage E's lock rule as the test stand-in has it, on the world's own bars (every stock trades every session)."""

    def __init__(self, W):
        self.O, self.H, self.L, self.C = W["O"], W["H"], W["L"], W["C"]
        self.T = self.C.shape[1]

    @staticmethod
    def band_down(price, prev):
        return any(abs(price - round(prev * (1 - b), 2)) <= 0.011 for b in BANDS)

    def lock(self, s, i, side):
        if i <= 0:
            return False
        p = self.O[s, i] if side == "open" else self.C[s, i]
        return bool(self.band_down(p, self.C[s, i - 1]) and p <= self.L[s, i] * (1 + 1e-9))

    def honest(self, s, i):
        for k in range(i + 1, min(i + 20, self.T - 1) + 1):
            if not self.lock(s, k, "open"):
                return k, self.O[s, k], True
        if i + 20 <= self.T - 1:
            return i + 20, self.C[s, i + 20], False
        return None

    def sale(self, s, i):
        """A sale at the open of session i -> (session, price, at an open) or None (pending)."""
        if self.lock(s, i, "open"):
            return self.honest(s, i)
        return i, self.O[s, i], True

    def hold(self, s, i):
        """The scheduled exit at the close of session i."""
        if self.lock(s, i, "close"):
            return self.honest(s, i)
        return i, self.C[s, i], False


def hand_trades(w, conds, primary):
    """Every trade of D and ENS ranks 1-10 by the tree's rules (ranks 1-3) and the replay (ranks 4-10)."""
    W = w["W"]
    cal = pd.DatetimeIndex(W["cal"])
    spos = {s: i for i, s in enumerate(W["syms"])}
    wl = pd.read_parquet(w["data"] / "watchlist.parquet")
    wl["signal_day"] = pd.to_datetime(wl["signal_day"])
    cuts = TM.hand_cuts(wl)
    X_ = TM.panel(w["root"], W["syms"], cal)
    O, C = W["O"], W["C"]
    cpos = {d: i for i, d in enumerate(cal)}
    E = wl[(wl["symbol"] != "LIQUIDBEES") & (wl["signal_day"] >= WINDOW)].copy()
    E["t"] = E["signal_day"].map(cpos)
    E["s"] = E["symbol"].map(spos)
    E["cut"] = [cuts.get(d.year, np.nan) for d in E["signal_day"]]
    E = E[np.isfinite(E["cut"]) & (E["s_atr14"] > 0)]
    E["calm"] = E["s_atr14"] <= E["cut"]
    E["up"] = E["entry"] >= E["signal_close"]
    fills = {}

    def fill(s, t, atr):
        if (s, t) not in fills:
            best, how = 0, ""
            for sid in SU.TREE_ORDER:
                den = (lambda k: atr) if any(f == "pc_vs_d1_atr" for f, _, _ in conds[sid]) else (lambda k: 1.0)
                k = TM.hand_fill(conds[sid], X_, C, O, s, t, None, den)
                if k > 0 and (best == 0 or k < best):
                    best, how = k, sid
            fills[(s, t)] = (best, how)
        return fills[(s, t)]

    out = []
    for (e, t), g in E.groupby(["engine", "t"], sort=True):
        g = g.sort_values("rank")
        first_up = None
        if e == "D":
            cand = g[(g["rank"] <= 3) & g["calm"] & g["up"]]
            first_up = cand["trade_id"].iloc[0] if len(cand) else None
        for r in g.itertuples():
            tree = r.rank <= 3
            if tree:
                opn = (r.trade_id == first_up) if e == "D" else bool(r.calm)
            else:
                opn = bool(r.calm) and (e == "ENS" or bool(r.up))
            if opn:
                ek, how = 1, "open"
            else:
                ek, how = fill(r.s, t, r.s_atr14)
                if ek == 0:
                    continue
            x = ek + 4 if primary.get(how) == "fresh" else 5
            out.append({"engine": e, "trade_id": r.trade_id, "tree": tree, "how": how, "ek": ek, "x": x,
                        "s": r.s, "t": t, "atr": r.s_atr14, "p0": O[r.s, t + ek], "rank": r.rank, "lane":
                        int(not r.calm), "symbol": r.symbol, "signal_day": r.signal_day})
    return pd.DataFrame(out), wl, X_, cuts


# ====================================================================================================== t1
def t1_unit():
    print("t1 the rows and the label on hand-made paths")
    PA = X.LeanPaths(8)
    base = 100 * np.exp(np.cumsum(np.linspace(0.01, -0.01, 32)))
    for u in range(8):
        PA.O[u], PA.C[u] = base * (1 + 0.001 * u), base * (1.002 + 0.001 * u)
        PA.H[u], PA.L[u] = np.maximum(PA.O[u], PA.C[u]) * 1.01, np.minimum(PA.O[u], PA.C[u]) * 0.99
    PA.ok[:] = True
    # 0: open buy; the D3 open locked -> the D4 open; 1: open buy, the D5 close locked -> the D6 open
    PA.lockO[0, 3], PA.hon_k[0, 3], PA.hon_px[0, 3] = True, 4, PA.O[0, 4]
    PA.lockC[1, 5], PA.hon_k[1, 5], PA.hon_px[1, 5] = True, 6, PA.O[1, 6]
    # 2: N1 bought at D5 (exit the D9 close); 3: S1 bought at D5 (exit the D5 close: no evening)
    # 4: open buy; the D5 open locked -> the D6 open, after the D5 close: moot; the D3 open locked and stuck: moot
    PA.lockO[4, 5], PA.hon_k[4, 5], PA.hon_px[4, 5] = True, 6, PA.O[4, 6]
    PA.lockO[4, 3], PA.hon_k[4, 3], PA.hon_px[4, 3], PA.hon_stuck[4, 3] = True, 23, PA.C[4, 23], True
    # 5: open buy whose D5 close and D5 open are both locked and both go to the D6 open: the D4 evening is moot
    PA.lockO[5, 5], PA.hon_k[5, 5], PA.hon_px[5, 5] = True, 6, PA.O[5, 6]
    PA.lockC[5, 5] = True
    PA.hon_k[5, 5], PA.hon_px[5, 5] = 6, PA.O[5, 6]
    # 6: a sale stuck at the D5 close (a unit case: the sale and the scheduled exit are the same close): moot
    PA.lockO[6, 3], PA.hon_k[6, 3], PA.hon_px[6, 3], PA.hon_stuck[6, 3] = True, 5, PA.C[6, 5], True
    # 7: the scheduled close and the D4 open both locked for 20 sessions: stuck at the D25 and D24 closes
    PA.lockC[7, 5], PA.hon_k[7, 5], PA.hon_px[7, 5], PA.hon_stuck[7, 5] = True, 25, PA.C[7, 25], True
    PA.lockO[7, 4], PA.hon_k[7, 4], PA.hon_px[7, 4], PA.hon_stuck[7, 4] = True, 24, PA.C[7, 24], True
    prim = {"S1": "original_d5", "N1": "fresh", "C1": "original_d5"}
    how = ["open", "open", "N1", "S1", "open", "open", "open", "open"]
    ek = np.array([1, 1, 5, 5, 1, 1, 1, 1])
    x = X.scheduled_day(how, ek, prim)
    check(list(x) == [5, 5, 9, 5, 5, 5, 5, 5], "the scheduled exit: the D5 close; N1 4 sessions after its entry (%s)" %
          list(x))
    TT = pd.DataFrame({"src": 0, "u10": np.arange(8), "x": x, "ek": ek, "p0": PA.O[np.arange(8), ek], "atr": 0.02,
                       "i1": 100})
    TT2, R = X.build_rows(TT, PA)
    n = R.groupby("j").size().reindex(range(8), fill_value=0).tolist()
    check(n == [4, 4, 4, 0, 4, 4, 4, 4], "evenings per trade: D1 open buys 4, N1 at D5 4, S1 at D5 0 (%s)" % n)
    r6 = R[R["j"] == 6].set_index("c")
    r7 = R[R["j"] == 7].set_index("c")
    check(not bool(r6.loc[2, "valid"]) and not bool(r6.loc[2, "so"]) and bool(r7.loc[3, "valid"]) and
          not bool(r7.loc[3, "so"]) and not bool(r7.loc[3, "ho"]) and
          abs(r7.loc[3, "y"] - 1e4 * np.log(PA.C[7, 25] / PA.C[7, 24])) < 1e-7,
          "a stuck sale is at a close: moot when it is the scheduled close; before a later stuck exit it is valid")
    r0 = R[R["j"] == 0].set_index("c")
    want_y = {1: np.log(PA.C[0, 5] / PA.O[0, 2]), 2: np.log(PA.C[0, 5] / PA.O[0, 4]),
              3: np.log(PA.C[0, 5] / PA.O[0, 4]), 4: np.log(PA.C[0, 5] / PA.O[0, 5])}
    check(all(abs(r0.loc[c, "y"] - 1e4 * v) < 1e-7 for c, v in want_y.items()) and r0["valid"].all() and
          list(r0["sk"]) == [2, 4, 4, 5],
          "a locked D3 open: the D2 evening's sale waits for the D4 open; the label = ln(D5 close / sale price)")
    r1 = R[R["j"] == 1].set_index("c")
    check(abs(r1.loc[4, "y"] - 1e4 * np.log(PA.O[1, 6] / PA.O[1, 5])) < 1e-7 and bool(r1.loc[4, "valid"]) and
          (r1["hk"] == 6).all() and r1["ho"].all(),
          "a locked scheduled close sells at the D6 open: the D4 evening compares the D5 open with the D6 open")
    r2 = R[R["j"] == 2]
    check(list(r2["c"]) == [5, 6, 7, 8] and list(r2["left"]) == [4, 3, 2, 1] and list(r2["held"]) == [1, 2, 3, 4],
          "N1 bought at the D5 open decides at the D5-D8 closes (held 1-4, left 4-1)")
    r4 = R[R["j"] == 4].set_index("c")
    check(not bool(r4.loc[4, "valid"]) and not bool(r4.loc[2, "valid"]) and bool(r4.loc[1, "valid"]) and
          bool(r4.loc[3, "valid"]) and np.isnan(r4.loc[4, "y"]) and np.isnan(r4.loc[2, "y"]),
          "moot: a sale that lands after the scheduled close (locked D5 open -> D6), a stuck sale (D3 open)")
    r5 = R[R["j"] == 5].set_index("c")
    check(not bool(r5.loc[4, "valid"]) and bool(r5.loc[3, "valid"]),
          "moot: the sale and the scheduled exit land on the same D6 open")
    c = 3
    p0 = PA.O[0, 1]
    mh = max(PA.H[0, 1:c + 1])
    ml = min(PA.L[0, 1:c + 1])
    m = r0.loc[c]
    check(abs(m["pnl_pct"] - (PA.C[0, c] / p0 - 1) * 100) < 1e-9 and abs(m["mfe_atr"] - np.log(mh / p0) / 0.02) < 1e-9
          and abs(m["mae_atr"] - np.log(ml / p0) / 0.02) < 1e-9 and
          abs(m["day_atr"] - np.log(PA.C[0, c] / PA.C[0, c - 1]) / 0.02) < 1e-9 and
          abs(m["clv"] - (PA.C[0, c] - PA.L[0, c]) / (PA.H[0, c] - PA.L[0, c])) < 1e-9 and m["dcal"] == 100 + c - 1,
          "the mechanics from the fill (the entry session's high and low count), the decision's calendar day")
    check(int(R.loc[R["j"] == 0, "end"].max()) == 100 + 5 - 1 and
          int(R[(R["j"] == 1) & (R["c"] == 4)]["end"].iloc[0]) == 100 + 6 - 1,
          "a row's outcome ends at the later of the sale and the scheduled exit")


# ====================================================================================================== main
def main():
    print("%s self-test (pandas %s, numpy %s)" % (X.VERSION, pd.__version__, np.__version__))
    tmp = Path(tempfile.mkdtemp(prefix="exitlab_test_"))
    try:
        t1_unit()
        _, fdoc = SU.load_frozen()
        conds = {s["id"]: [tuple(c) for c in s["conds"]] for s in fdoc["setups"]}
        primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
        decl = json.loads((HERE.parent / X.DECL_FILE).read_text(encoding="utf-8"))
        Wd = {}
        for kind in ("exit", "m5", "absent"):
            Wd[kind] = w = run_world(tmp, kind)
            if w["rc"] != 0 or w["d"] is None:
                print(w["log"][-3000:])
                check(False, "exitlab runs on the %s world" % kind)
                return 1
            if kind == "absent":
                continue
            O_ = outputs(w["d"])
            check("window 2021-01-01" in O_["md"], "%s: the window starts 2021-01-01" % kind)
            HT, wl, Xp, cuts = hand_trades(w, conds, primary)
            t2_trades(kind, w, O_, HT)
            t3_rows(kind, w, O_, HT)
            t4_inputs(kind, w, O_, HT, wl, Xp)
            t5_walk(kind, w, O_, decl)
            t6_rules(kind, w, O_, HT)
            t7_books(kind, w, O_, HT, decl)
        t8_verdicts(Wd)
        t9_refusals(tmp, Wd)
        t10_calendar_end(tmp, Wd)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print("FAILED: %d of %d checks" % (len(FAILS), len(FAILS) + N_OK[0]))
        for f in FAILS:
            print("  - " + f)
        return 1
    print("VERIFIED (%s) - %d checks" % (X.VERSION, N_OK[0]))
    return 0


# ====================================================================================================== t2
def t2_trades(kind, w, O_, HT):
    print("t2 the trades (%s world)" % kind)
    T = O_["T"]
    hand = HT[HT["tree"]].set_index(["engine", "trade_id"])
    got = T.set_index(["engine", "trade_id"])
    common = hand.index.intersection(got.index)
    check(len(common) == len(hand) == len(got),
          "%s: the tree's planned trades: %d by hand, %d in exitlab (%d in both)" % (kind, len(hand), len(got),
                                                                                    len(common)))
    if len(common):
        h, g = hand.loc[common], got.loc[common]
        check((h["how"].to_numpy() == g["how"].to_numpy()).all() and (h["ek"].to_numpy() == g["entry_k"].to_numpy()).all()
              and same(h["p0"], g["entry_price"]),
              "%s: each tree trade's entry kind, entry day and fill price as by hand" % kind)
    R = O_["R"]
    hyp = R[R["src"] == "hypothetical"].groupby(["engine", "trade_id"]).agg(
        n=("close_k", "size"), how=("how_name", "first"), ek=("entry_k", "first"), x=("exit_k", "first"),
        c0=("close_k", "min"), c1=("close_k", "max"))
    hh = HT[~HT["tree"] & (HT["x"] > HT["ek"])].set_index(["engine", "trade_id"])
    common = hh.index.intersection(hyp.index)
    check(len(common) == len(hh) and len(hyp) == len(hh) and len(hh) > 2000,
          "%s: hypothetical trades with an evening: %d by hand, %d in the rows (%d in both)" % (
              kind, len(hh), len(hyp), len(common)))
    if len(common):
        a, b = hh.loc[common], hyp.loc[common]
        check((a["how"].to_numpy() == b["how"].to_numpy()).all() and (a["ek"].to_numpy() == b["ek"].to_numpy()).all()
              and (a["x"].to_numpy() == b["x"].to_numpy()).all() and
              ((a["x"] - a["ek"]).to_numpy() == b["n"].to_numpy()).all() and
              (b["c0"].to_numpy() == a["ek"].to_numpy()).all() and (b["c1"].to_numpy() == a["x"].to_numpy() - 1).all(),
              "%s: each hypothetical trade's entry, exit and evenings (entry close .. the close before the exit)" % kind)
    kinds = set(HT["how"])
    check({"open", "S1", "N1"} <= kinds, "%s: the worlds exercise open buys, S1 and N1 (%s)" % (kind, sorted(kinds)))
    n1 = R[(R["how_name"] == "N1") & (R["entry_k"] == 5)].groupby(["engine", "trade_id"]).size()
    s1 = HT[(HT["how"] == "S1") & (HT["ek"] == 5)]
    check(len(n1) > 0 and (n1 == 4).all() and len(s1) > 0 and
          not R.set_index(["engine", "trade_id"]).index.isin(list(zip(s1["engine"], s1["trade_id"]))).any(),
          "%s: N1 bought at the D5 open decides four evenings; S1 bought at the D5 open none (%d, %d trades)" % (
              kind, len(n1), len(s1)))


# ====================================================================================================== t3
def t3_rows(kind, w, O_, HT):
    print("t3 every row by hand (%s world)" % kind)
    H = Hand(w["W"])
    R = O_["R"]
    key = HT.set_index(["engine", "trade_id"])
    tr = key.loc[list(zip(R["engine"], R["trade_id"]))]
    s, t, ek, x, p0, atr = (tr[k].to_numpy() for k in ("s", "t", "ek", "x", "p0", "atr"))
    c = R["close_k"].to_numpy()
    bad = {"mech": 0, "label": 0, "valid": 0, "sale": 0, "hold": 0}
    nm = 0
    MM = R[list(X.MECH)].to_numpy(float)
    rv, ry = R["valid"].to_numpy(bool), R["y_bp"].to_numpy(float)
    rsk, rsp, rso = R["sell_k"].to_numpy(), R["sell_price"].to_numpy(float), R["sell_at_open"].to_numpy(bool)
    rhk, rhp, rho = R["hold_k"].to_numpy(), R["hold_price"].to_numpy(float), R["hold_at_open"].to_numpy(bool)
    for i in range(len(R)):
        si, ti, ci, ei = int(s[i]), int(t[i]), int(c[i]), int(ek[i])
        O, Hh, L, C = H.O[si], H.H[si], H.L[si], H.C[si]
        cc, a = C[ti + ci], atr[i]
        mh, ml = Hh[ti + ei:ti + ci + 1].max(), L[ti + ei:ti + ci + 1].min()
        hi, lo = Hh[ti + ci], L[ti + ci]
        mech = [ci - ei + 1, x[i] - ci, (cc / p0[i] - 1) * 100, np.log(cc / p0[i]) / a, np.log(mh / p0[i]) / a,
                np.log(ml / p0[i]) / a, np.log(cc / C[ti + ci - 1]) / a, np.log(hi / lo) / a,
                (cc - lo) / (hi - lo) if hi > lo else 0.5, a * 100]
        bad["mech"] += not same(MM[i], mech, 1e-9)
        sl = H.sale(si, ti + ci + 1)
        hd = H.hold(si, ti + int(x[i]))
        if sl is None or hd is None:
            continue
        sk_, sp_, so_ = sl
        hk_, hp_, ho_ = hd
        valid = (sk_ + (0 if so_ else 0.5)) < (hk_ + (0 if ho_ else 0.5))
        nm += not valid
        bad["valid"] += bool(rv[i]) != valid
        bad["sale"] += not (rsk[i] == sk_ - ti and abs(rsp[i] - sp_) < 1e-9 * sp_ and bool(rso[i]) == so_)
        bad["hold"] += not (rhk[i] == hk_ - ti and abs(rhp[i] - hp_) < 1e-9 * hp_ and bool(rho[i]) == ho_)
        y = 1e4 * np.log(hp_ / sp_) if valid else np.nan
        bad["label"] += not same(ry[i], y, 1e-9)
    check(all(v == 0 for v in bad.values()) and len(R) > 30000,
          "%s: %d rows by hand: mechanics, tomorrow's sale, the scheduled exit, valid, label (mismatches %s)" % (
              kind, len(R), bad))
    lk = int(w["W"]["locks"].sum())
    check(nm > 0 and (~R["valid"]).sum() == nm and lk > 50,
          "%s: the planted circuits (%d) give moot decisions (%d) and locked sales" % (kind, lk, nm))
    d = pd.to_datetime(R["decision_day"])
    cal = pd.DatetimeIndex(w["W"]["cal"])
    check((d.to_numpy() == cal[t + c].to_numpy()).all(), "%s: each row's decision day is the close it decides at" % kind)


# ====================================================================================================== t4
def t4_inputs(kind, w, O_, HT, wl, Xp):
    print("t4 the inputs by hand (%s world)" % kind)
    R = O_["R"]
    W = w["W"]
    cal = pd.DatetimeIndex(W["cal"])
    cpos = {d: i for i, d in enumerate(cal)}
    key = HT.set_index(["engine", "trade_id"])
    tr = key.loc[list(zip(R["engine"], R["trade_id"]))]
    s, t = tr["s"].to_numpy(), tr["t"].to_numpy()
    c = R["close_k"].to_numpy()
    dc = t + c
    rk = {(e, cpos[d], sy): r for e, d, sy, r in zip(wl["engine"], wl["signal_day"], wl["symbol"], wl["rank"])}
    eng = R["engine"].to_numpy()
    sym = R["symbol"].to_numpy()
    own = np.array([rk.get((e, d, sy), 11) for e, d, sy in zip(eng, dc, sym)], float)
    oth = np.array([rk.get(("ENS" if e == "D" else "D", d, sy), 11) for e, d, sy in zip(eng, dc, sym)], float)
    check(same(R["rank_own"], own) and same(R["rank_other"], oth) and (own < 11).any() and (oth < 11).any(),
          "%s: tonight's rank in the stock's own engine and in the other (11 = not in the top 10)" % kind)
    n = W["nifty"]
    r1 = np.log(n[dc] / n[dc - 1])
    r5 = np.log(n[dc] / n[dc - 5])
    check(same(R["nifty_r1"], r1) and same(R["nifty_r5"], r5), "%s: NIFTY's 1- and 5-session log returns" % kind)
    mk = X.TD.Market(w["root"], X.TD.Production(stage_e_any=True))
    cald = np.asarray(mk.cal).astype("datetime64[D]")
    _, _, _, Fh, _, _ = VL.nifty_state(mk.series("NIFTY50"), cald)
    z = np.full(len(Fh), np.nan)
    for i in range(len(Fh)):
        if np.isfinite(Fh[i]):
            v = [f for f in Fh[max(0, i - 250):i] if np.isfinite(f)]
            if len(v) >= 120:
                z[i] = Fh[i] / np.median(v)
    zp = np.searchsorted(cald, cal[dc].to_numpy().astype("datetime64[D]"))
    zz = z[zp]
    st = np.where(np.isfinite(zz), (zz >= 1.25).astype(float), np.nan)
    check(same(R["nifty_z"], zz) and same(R["nifty_stress"], st) and np.isfinite(zz).mean() > 0.9,
          "%s: NIFTY's forecast against the median of the 250 before (>= 120) and the flag at 1.25" % kind)
    present = [f for f in X.PANEL if f in Xp]
    okp = all(same(R[f], Xp[f][s, dc]) for f in present)
    miss = [f for f in X.PANEL if f not in Xp]
    check(okp and len(present) == 11 and all(R[f].isna().all() for f in miss),
          "%s: the panel's %d stock inputs at tonight's close; the %d it lacks left blank" % (kind, len(present),
                                                                                            len(miss)))
    F = pd.read_csv(w["run"] / "pick_forecasts.csv")
    fc = {(sy, d): v for sy, d, v in zip(F["symbol"], F["signal_day"], F["sigma5_M5_pct"])}
    sd = R["signal_day"].to_numpy()
    m5 = np.array([fc.get((sy, d), np.nan) for sy, d in zip(sym, sd)], float)
    m5 = np.where(np.isfinite(m5) & (m5 > 0), m5, np.nan)
    check(same(R["m5_sigma5"], m5) and same(R["m5_left"], m5 * np.sqrt(R["left"] / 5.0)) and
          np.isfinite(m5).sum() > 1000,
          "%s: M5 at the pick's (symbol, signal day) and M5 x sqrt(left / 5)" % kind)
    how = np.array([HOWS.index(h) for h in tr["how"]], float)
    check(same(R["how"], how) and same(R["srank"], tr["rank"]) and same(R["lane"], tr["lane"]) and
          same(R["eng_d"], (eng == "D").astype(float)),
          "%s: the trade's inputs (entry kind as a category, rank, lane by the year's cut-off, engine)" % kind)


# ====================================================================================================== t5
def t5_walk(kind, w, O_, decl):
    print("t5 the walk-forward by hand (%s world)" % kind)
    from sklearn.ensemble import HistGradientBoostingRegressor
    R, F = O_["R"], O_["F"]
    cons = decl["constants"]
    hgb = cons["hgb"]
    dday = pd.to_datetime(R["decision_day"])
    eday = pd.to_datetime(R["end_day"])
    y = R["y_bp"].to_numpy(float)
    ok_all = True
    for Y in cons["test_years"]:
        start = pd.Timestamp("%d-01-01" % Y)
        tr = (R["valid"] & (eday < start) & (dday >= WINDOW) & np.isfinite(y)).to_numpy()
        te = ((dday >= start) & (dday < pd.Timestamp("%d-01-01" % (Y + 1)))).to_numpy()
        f = F[F["year"] == Y]
        cnt = (int(f["train_rows"].iloc[0]) == tr.sum() and int(f["test_rows"].iloc[0]) == te.sum() and
               int(f["train_m5_rows"].iloc[0]) == int((tr & np.isfinite(R["m5_sigma5"].to_numpy())).sum()))
        check(cnt, "%s %d: %d training rows (outcome known before 1 January), %d test rows" % (kind, Y, tr.sum(),
                                                                                              te.sum()))
        if not te.any() or tr.sum() < cons["min_train"]:
            continue
        lo, hi = np.quantile(y[tr], cons["winsor"])
        yc = np.clip(y[tr], lo, hi)
        check(same(R["clip_lo"].to_numpy()[te], np.full(te.sum(), lo)) and
              same(R["clip_hi"].to_numpy()[te], np.full(te.sum(), hi)), "%s %d: the label clipped at the training "
                                                                         "rows' 1%% and 99%%" % (kind, Y))
        for m, cols in cons["models"].items():
            A = R[cols].to_numpy(float)
            keep = np.isfinite(A[tr]).any(0)
            used = [cc for cc, k in zip(cols, keep) if k]
            cat = np.array([cc == "how" for cc in used])
            mdl = HistGradientBoostingRegressor(categorical_features=cat if cat.any() else None, **hgb)
            p = mdl.fit(A[tr][:, keep], yc).predict(A[te][:, keep])
            good = same(R["pred_" + m].to_numpy()[te], p, 1e-9)
            ok_all &= good
            if not good:
                print("     %s %d %s differs" % (kind, Y, m))
    check(ok_all, "%s: M0, M1 and M2 refitted from the declaration's settings give exitlab's predictions" % kind)
    other = ~((dday >= pd.Timestamp("2023-01-01")).to_numpy())
    check(R.loc[other, ["pred_M0", "pred_M1", "pred_M2"]].isna().all().all(),
          "%s: no prediction before 2023 (those rows only train)" % kind)


# ====================================================================================================== t6
def t6_rules(kind, w, O_, HT):
    print("t6 the exit rules by hand (%s world)" % kind)
    H = Hand(w["W"])
    cal = pd.DatetimeIndex(w["W"]["cal"])
    R, T = O_["R"], O_["T"]
    key = HT.set_index(["engine", "trade_id"])
    Tt = T.set_index(["engine", "trade_id"])
    tr = key.loc[Tt.index]
    bad = 0
    for (e, tid), r in tr.iterrows():
        s_, t_ = int(r["s"]), int(r["t"])
        hk, hp, ho = H.hold(s_, t_ + int(r["x"]))
        g = Tt.loc[(e, tid)]
        bad += not (g["exit_FROZEN"] == str(cal[hk].date()) and bool(g["at_open_FROZEN"]) == ho and
                    abs(g["net_FROZEN"] - ((hp / r["p0"] - 1) * 100 - 0.35)) < 1e-7)
    check(bad == 0, "%s: the frozen tree's scheduled exits and nets by hand (%d trades, %d differ)" % (kind, len(tr),
                                                                                                      bad))
    for m in ("M0", "M1", "M2"):
        Rt = R[(R["src"] == "tree") & R["valid"] & (R["pred_" + m] < 0)].sort_values(
            ["engine", "trade_id", "close_k"])
        first = Rt.groupby(["engine", "trade_id"]).head(1).set_index(["engine", "trade_id"])
        bad, nsold = 0, 0
        for (e, tid), g in Tt.iterrows():
            r = tr.loc[(e, tid)]
            if (e, tid) in first.index:
                f = first.loc[(e, tid)]
                nsold += 1
                day = int(r["t"]) + int(f["sell_k"])
                ok = (g["exit_" + m] == str(cal[day].date()) and bool(g["at_open_" + m]) == bool(f["sell_at_open"]) and
                      abs(g["net_" + m] - ((f["sell_price"] / r["p0"] - 1) * 100 - 0.35)) < 1e-7)
            else:
                ok = g["exit_" + m] == g["exit_FROZEN"] and same(g["net_" + m], g["net_FROZEN"])
            bad += not ok
        check(bad == 0 and nsold > 100, "%s: %s sells at the first valid evening below 0, tomorrow's executable open "
                                        "(%d trades sold early, %d differ)" % (kind, m, nsold, bad))
    bad, nch = 0, 0
    for (e, tid), g in Tt.iterrows():
        r = tr.loc[(e, tid)]
        s_, t_, x_ = int(r["s"]), int(r["t"]), int(r["x"])
        hk, hp, ho = H.hold(s_, t_ + x_)
        if hk == t_ + x_ and not ho:
            sl = H.sale(s_, t_ + x_ + 1)
            nch += 1
            ok = sl is not None and g["exit_OPEN6"] == str(cal[sl[0]].date()) and \
                abs(g["net_OPEN6"] - ((sl[1] / r["p0"] - 1) * 100 - 0.35)) < 1e-7
        else:
            ok = g["exit_OPEN6"] == g["exit_FROZEN"] and same(g["net_OPEN6"], g["net_FROZEN"])
        bad += not ok
    check(bad == 0 and nch > 100, "%s: OPEN6 sells at the first executable open after the scheduled close; a locked "
                                  "scheduled close is unchanged (%d moved, %d differ)" % (kind, nch, bad))


# ====================================================================================================== t7
def hand_book(tr, C, s0, t1, k=3):
    """The tree's book by a loop: entries in setuplab's order, 1/k of the closed value, all busy = skipped, a position
    frees its slot after its exit (at an open: for that open), marked at each close. -> marked values s0..t1."""
    taken = []
    for r in tr:
        if r["ent"] < s0 or r["ent"] > t1:
            continue
        busy = [q for q in taken if q["key"] >= r["ent"]]
        if len(busy) < k:
            closed = 1.0 + sum(q["size"] * q["net"] / 100 for q in taken if q["key"] < r["ent"])
            size = closed / k
            if size > 0:
                taken.append(dict(r, size=size))
    vals = np.zeros(t1 - s0 + 1)
    for d in range(s0, t1 + 1):
        v = 1.0
        for q in taken:
            if q["ex"] <= d:
                v += q["size"] * q["net"] / 100
            elif q["ent"] <= d:
                v += q["size"] * (C[q["s"], d] / q["p0"] - 1)
        vals[d - s0] = max(v, 0.0)
    return vals


def hand_account(vD, vE, years):
    out = np.zeros(len(vD))
    pd_, pe = 1.0, 1.0
    for i in range(len(vD)):
        if i > 0 and years[i] != years[i - 1]:
            base_d, base_e = vD[i - 1], vE[i - 1]
        elif i == 0:
            base_d, base_e = 1.0, 1.0
        if i == 0 or years[i] != years[i - 1]:
            prev = 1.0
        cur = 0.5 * vD[i] / base_d + 0.5 * vE[i] / base_e
        out[i] = cur / prev - 1
        prev = cur
    return out


def t7_books(kind, w, O_, HT, decl):
    print("t7 the books by hand (%s world)" % kind)
    W = w["W"]
    cal = pd.DatetimeIndex(W["cal"])
    cpos = {d: i for i, d in enumerate(cal)}
    T, D, U = O_["T"], O_["D"], O_["U"]
    key = HT.set_index(["engine", "trade_id"])
    p0 = int(np.searchsorted(cal, pd.Timestamp("2023-01-01")))
    days = pd.to_datetime(D["date"])
    t1 = cpos[days.iloc[-1]]
    c0 = p0 + 4
    check(cpos[days.iloc[0]] == c0, "%s: the account starts at the 5th start day" % kind)
    years = cal.year.to_numpy()
    res = {}
    for rule in ("FROZEN", "M1"):
        books = {}
        for e in ("D", "ENS"):
            g = T[T["engine"] == e].copy()
            g["ent"] = pd.to_datetime(g["entry_day"]).map(cpos)
            g["ex"] = [cpos[pd.Timestamp(v)] if v != "pending" else 10 ** 6 for v in g["exit_" + rule]]
            g["key"] = g["ex"] - 0.5 * g["at_open_" + rule].astype(float)
            g["net"] = g["net_" + rule]
            g["s"] = [key.loc[(e, tid), "s"] for tid in g["trade_id"]]
            g["p0"] = g["entry_price"]
            g = g.sort_values(["ent", "rank", "symbol", "trade_id"], kind="mergesort")
            books[e] = g[["ent", "ex", "key", "net", "s", "p0"]].to_dict("records")
        acc, accD, accE, ay, fl = [], [], [], [], []
        for s0 in range(p0, p0 + 5):
            vD = hand_book(books["D"], W["C"], s0, t1)
            vE = hand_book(books["ENS"], W["C"], s0, t1)
            r = hand_account(vD, vE, years[s0:t1 + 1])
            acc.append(r[c0 - s0:])
            for v, lst in ((vD, accD), (vE, accE)):
                vv = np.r_[1.0, v]
                lst.append((vv[1:] / vv[:-1] - 1)[c0 - s0:])
            v = np.r_[1.0, np.cumprod(1 + r)]
            yrs = (cal[t1] - cal[s0]).days / 365.25
            ay.append((v[-1] ** (1 / yrs) - 1) * 100)
            fl.append(100 * np.max(1 - v / np.maximum.accumulate(v)))
        res[rule] = np.mean(acc, axis=0)
        check(same(D["r_" + rule], res[rule], 1e-8) and same(D["r_%s_D" % rule], np.mean(accD, axis=0), 1e-8) and
              same(D["r_%s_ENS" % rule], np.mean(accE, axis=0), 1e-8),
              "%s: %s's account (5 starts, 50:50 restarted each January) and its D and ENS books by hand" % (kind,
                                                                                                          rule))
        u = U.set_index("rule").loc[rule]
        check(abs(u["a_year"] - np.mean(ay)) < 1e-6 and abs(u["fall"] - np.mean(fl)) < 1e-6,
              "%s: %s's a year %.4f%% and worst fall %.4f%% (means of 5 starts) by hand" % (kind, rule, np.mean(ay),
                                                                                           np.mean(fl)))
    B_ = SU.Boot(days.to_numpy(), B=2000, block=10, seed=7)
    ok = True
    for a, b in decl["constants"]["pairs"]:
        x = (np.log1p(D["r_" + a]) - np.log1p(D["r_" + b])).to_numpy() * 1e4
        n = len(B_.days)
        m = (B_.M @ x) / (B_.M @ np.ones(n))
        lo, hi = np.percentile(m, [2.5, 97.5])
        sd = np.std(m, ddof=1)
        p = 1 - 0.5 * (1 + math.erf(x.mean() / sd / math.sqrt(2)))
        u = U.set_index("rule").loc["%s vs %s" % (a, b)]
        ok &= abs(u["diff"] - x.mean()) < 1e-6 and abs(u["diff_lo"] - lo) < 1e-6 and abs(u["diff_hi"] - hi) < 1e-6 \
            and abs(u["p_one"] - p) < 1e-6
    check(ok, "%s: every comparison's mean, 95%% interval (blocks of 10, 2,000, seed 7) and one-sided p by hand" % kind)
    J = O_["J"]
    a, b = J["pairs"]["M1 vs FROZEN"], J["pairs"]["M1 vs M0"]
    want = "PASS" if (a["diff_lo"] > 0 and J["rules"]["M1"]["fall"] <= J["rules"]["FROZEN"]["fall"] and
                      b["diff_lo"] > 0) else "FAIL"
    check(J["decision"]["EXIT MODEL (M1)"] == want, "%s: the decision follows the declared rule (%s)" % (kind, want))
    R = O_["R"]
    y = R["y_bp"].to_numpy(float)
    m = ((R["src"] == "tree") & R["valid"] & R["m5_sigma5"].notna() & R["pred_M1"].notna() & R["pred_M2"].notna() &
         R["clip_lo"].notna()).to_numpy() & np.isfinite(y)
    yc = np.clip(y[m], R["clip_lo"].to_numpy()[m], R["clip_hi"].to_numpy()[m])
    dd = (yc - R["pred_M1"].to_numpy()[m]) ** 2 - (yc - R["pred_M2"].to_numpy()[m]) ** 2
    dday = pd.to_datetime(R["decision_day"]).to_numpy()[m]
    B2 = SU.Boot(dday, B=2000, block=10, seed=7)
    ix = B2.index(dday)
    S = B2.M @ np.bincount(ix, weights=dd, minlength=len(B2.days))
    Cn = B2.M @ np.bincount(ix, minlength=len(B2.days)).astype(float)
    lo, hi = np.nanpercentile(S / Cn, [2.5, 97.5])
    j5 = J["m5"]
    check(j5["rows"] == int(m.sum()) and abs(j5["diff"] - dd.mean()) < 1e-6 * (1 + abs(dd.mean())) and
          abs(j5["diff_lo"] - lo) < 1e-6 * (1 + abs(lo)) and abs(j5["diff_hi"] - hi) < 1e-6 * (1 + abs(hi)) and
          j5["verdict"] == ("ADDS" if lo > 0 else "ADDS NOTHING"),
          "%s: the M5 test on identical rows by hand (%d rows, %+.1f [%+.1f, %+.1f], %s)" % (
              kind, m.sum(), dd.mean(), lo, hi, j5["verdict"]))


# ====================================================================================================== t8
def t8_verdicts(Wd):
    print("t8 the planted worlds pass their own rule; the absent world passes none")
    J = {k: outputs(w["d"])["J"] for k, w in Wd.items()}
    for k in Wd:
        a = J[k]["pairs"]["M1 vs FROZEN"]
        b = J[k]["pairs"]["M1 vs M0"]
        print("     %-6s M1: %s (vs frozen %+.2f [%+.2f, %+.2f], vs M0 %+.2f [%+.2f, %+.2f]); M5: %s" % (
            k, J[k]["decision"]["EXIT MODEL (M1)"], a["diff"], a["diff_lo"], a["diff_hi"], b["diff"], b["diff_lo"],
            b["diff_hi"], J[k]["decision"]["M5"]))
    check(J["exit"]["decision"]["EXIT MODEL (M1)"] == "PASS", "exit world: the exit model PASSES")
    check(J["exit"]["decision"]["M5"] == "ADDS NOTHING", "exit world: M5 (noise there) adds nothing")
    check(J["m5"]["decision"]["M5"] == "ADDS", "m5 world: M5 ADDS")
    check(J["absent"]["decision"]["EXIT MODEL (M1)"] == "FAIL" and J["absent"]["decision"]["M5"] == "ADDS NOTHING",
          "absent world: the exit model FAILS and M5 adds nothing")
    rows = {k: X.decide({"M1": {"fall": f1}, "FROZEN": {"fall": 20.0}},
                        {"M1 vs FROZEN": {"diff_lo": la}, "M1 vs M0": {"diff_lo": lb}})
            for k, (la, lb, f1) in {"pass": (0.1, 0.1, 20.0), "zero": (0.0, 0.1, 19.0), "fall": (0.1, 0.1, 20.01),
                                    "m0": (0.1, 0.0, 19.0), "nan": (np.nan, 0.1, 19.0)}.items()}
    check(rows == {"pass": "PASS", "zero": "FAIL", "fall": "FAIL", "m0": "FAIL", "nan": "FAIL"},
          "the decision rule on hand-made cases: both intervals strictly above 0 and a worst fall no deeper (%s)" % rows)


# ====================================================================================================== t9
def t9_refusals(tmp, Wd):
    print("t9 refusals, --check-only, hashes, the ledger, the report")
    w = Wd["absent"]
    d = w["d"]
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").split("\n")
    okh = all(hashlib.sha256((d / ln.split("  ")[1]).read_bytes()).hexdigest() == ln.split("  ")[0]
              for ln in lines if ln.strip())
    check(okh and len([ln for ln in lines if ln.strip()]) == 10, "the outputs' hashes match (10 files)")
    led = [json.loads(ln) for ln in (w["out"] / "exitlab_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
    check([r["event"] for r in led] == ["start", "end"] and led[1]["run"] == d.name, "the ledger: a start and an end")
    md = (d / "EXITLAB.md").read_text(encoding="utf-8")
    check(all(s in md for s in ("## Verdict", "## Every rule", "## Does each model predict?", "## The exit model's sales",
                                "## The rows", "## Read this", "## Checks", "OPEN6 vs FROZEN", "moot")),
          "the report's sections")
    decl = json.loads((d / "DECLARATION.json").read_text(encoding="utf-8"))
    check(decl["sha256"] == SU.frozen_hash(decl) and decl == json.loads((HERE.parent / X.DECL_FILE).read_text(
        encoding="utf-8")), "the run carries the shipped declaration")

    def rc_of(argv):
        with redirect_stdout(io.StringIO()) as buf:
            rc = X.main(argv)
        return rc, buf.getvalue()

    base = ["--root", str(w["root"]), "--data", str(w["data"]), "--stage-e-any"]
    empty = tmp / "norun"
    empty.mkdir()
    o1 = tmp / "o1"
    rc, log = rc_of(base + ["--run", str(empty), "--out", str(o1)])
    check(rc == 3 and "pick_forecasts.csv" in log and not list(o1.glob("EXITLAB_*")),
          "refused: no pick_forecasts.csv in --run")
    nocol = tmp / "nocol"
    nocol.mkdir()
    F = pd.read_csv(w["run"] / "pick_forecasts.csv").rename(columns={"sigma5_M5_pct": "sigma5"})
    F.to_csv(nocol / "pick_forecasts.csv", index=False)
    rc, log = rc_of(base + ["--run", str(nocol), "--out", str(o1)])
    check(rc == 3 and "sigma5_M5_pct" in log and not list(o1.glob("EXITLAB_*")), "refused: no sigma5_M5_pct column")
    rc, log = rc_of(base + ["--run", str(w["run"]), "--out", str(w["root"] / "x")])
    check(rc == 3 and "inside" in log, "refused: --out inside the cache root")
    o2 = tmp / "o2"
    rc, log = rc_of(base + ["--run", str(w["run"]), "--out", str(o2), "--check-only"])
    check(rc == 0 and "CHECK OK" in log and not (o2.exists() and any(o2.iterdir())),
          "--check-only checks and writes nothing")
    ed = tmp / "decl.json"
    doc = json.loads((HERE.parent / X.DECL_FILE).read_text(encoding="utf-8"))
    doc["policy"] = doc["policy"] + " (edited)"
    ed.write_text(json.dumps(doc), encoding="utf-8")
    try:
        X.load_declaration(ed)
        refused = False
    except X.ExitError:
        refused = True
    doc2 = json.loads((HERE.parent / X.DECL_FILE).read_text(encoding="utf-8"))
    doc2["constants"]["min_train"] = 5
    doc2["sha256"] = SU.frozen_hash(doc2)
    ed.write_text(json.dumps(doc2), encoding="utf-8")
    try:
        X.load_declaration(ed)
        refused2 = False
    except X.ExitError:
        refused2 = True
    check(refused and refused2, "refused: an edited declaration, and one whose settings differ from the code's")


# ====================================================================================================== t10
def t10_calendar_end(tmp, Wd):
    print("t10 a cache that runs past the watchlist's calendar")
    w = Wd["absent"]
    data2 = tmp / "data_short"
    data2.mkdir()
    shutil.copy(w["data"] / "watchlist.parquet", data2 / "watchlist.parquet")
    cal = pd.read_parquet(w["data"] / "calendar.parquet")["date"]
    wl = pd.read_parquet(w["data"] / "watchlist.parquet", columns=["signal_day"])
    last = int(np.searchsorted(pd.DatetimeIndex(cal), pd.to_datetime(wl["signal_day"]).max()))
    cal.iloc[:last + 7].to_frame().to_parquet(data2 / "calendar.parquet", index=False)
    out = tmp / "o_short"
    with redirect_stdout(io.StringIO()) as buf:
        rc = X.main(["--root", str(w["root"]), "--data", str(data2), "--run", str(w["run"]), "--out", str(out),
                     "--stage-e-any"])
    d = sorted(out.glob("EXITLAB_*"))
    md = (d[-1] / "EXITLAB.md").read_text(encoding="utf-8") if d else ""
    import re
    m = re.search(r"(\d+) evenings after the watchlist's calendar left out", md)
    R = pd.read_parquet(d[-1] / "exitlab_rows.parquet") if d else None
    check(rc == 0 and m is not None and int(m.group(1)) > 0 and
          pd.to_datetime(R["decision_day"]).max() <= pd.Timestamp(cal.iloc[last + 6]),
          "the evenings after the calendar's last session are left out and counted (%s)" % (m.group(1) if m else
                                                                                            buf.getvalue()[-300:]))


if __name__ == "__main__":
    sys.exit(main())
