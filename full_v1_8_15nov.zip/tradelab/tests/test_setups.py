"""
tests/test_setups.py - the setups add-on (tl_setups v1.0) for tradelab v1.3.1, checked (section 17 of the suite).

Run it through tests/test_tradelab.py. Synthetic worlds only (tests/tl_world.py, tests/tl_ctx_world.py and the watch
world of tests/test_state.py) with a fake setuplab output (tags + a nightly scan) planted by hand:
  17 setups  the tags are read only when their hash matches; a strategy enters at a setup's OWN entry day and nowhere
             else (entry price = that day's open, the D5-close exit and a 'hold' exit by hand); the same-trade line of
             the report; every guard (a filter or rule naming a tag, a setup leg without tags, an unknown setup, a
             hold that cannot fit, a setup leg with a session); tag columns on a plain backtest, documented; the
             simulator's story line; the watch page's setups column and section from the scan (and without one);
             the trade journal's FROZEN SETUPS band; v1.3: the watch page's one line per stock (one card per
             purchase however many setup x pick rows name it; the entry tree's orders, lanes and books)
  18 tree    (setups add-on v1.2) setuplab's entry-tree run read only when its hash matches; the tree strategy buys
             where the tree bought (the D1 open, or the first setup's own open) and sells where it sold (the 5th close;
             N1 4 sessions after its entry, up to session 9) - prices by hand; skipped picks not entered; 'calm' as a
             filter (and refused without the tree); every guard (tree_* / opened_up in a rule, a tree entry without
             its exit or with a session or beside another entry, max_sessions < 9, no tree run, a tree that disagrees
             with the tags); lane / tree columns documented; the report's lane table by hand; the simulator's line;
             the journal's CALM / JUMPY AND THE ENTRY TREE band; without a tree run nothing changes
  19 sde     (setups add-on v1.4) SDE by hand (orderly fall = -1, choppy, flat / missing / split windows blank) and at
             real picks against the world's closes; pre_sde* filters; the tree's open_if buys exactly the jumpy
             non-ETF picks the rule names at the D1 open (5th close) and leaves every other pick as the frozen tree
             (difference 0 against --compare strategies/tree.py); a comparison that trades the tree gets the tree;
             the daily_diff_bp + cagr_and_drawdown decision rule by hand; the SDE section and table by hand; the
             simulator's SDE line; the guards (open_if off the tree, on a tree column, on a bar value)
  20 vol     (setups add-on v1.5, voldir VD1) the volatility values at real picks by hand and the day's flags from a
             hash-checked voldir run; open_exit (the D1-open branch sold at the 2nd close); veto_if read at each tree
             buy's OWN signal close; B1's weight and sizing by hand; the Calmar ratio and the calmar_diff decision by
             hand; strategy variants (file.py#NAME); every guard
  21 jumplab (setups add-on v1.6, jumplab JL1) the scores attached from a hash-checked run; open_untagged (ranks 4-10
             outside the tree bought at the D1 open, by hand); veto_if on the scores; swing targets and trails on jm_*
             levels; the 16 shipped variants compile; every guard
  22 branchlab (setups add-on v1.7, branchlab BR1) the days attached from a hash-checked run tied to the tree run;
             the tree entry's also_day: 'first' (a new buy, an earlier buy replacing the tree's, the same day and a
             later day leaving the tree's buy, an ETF never) and 'replace' (also_if picks re-planned or left unbought)
             by hand with nets from the bars; the 24 shipped variants compile; the report section; every guard
  23 why     (why add-on v1.0, whylab part R) whylab's WHY_YYYYMMDD.csv on the watch page: every D and ENS pick joined
             on (engine, rank, symbol) - the row's leading reason and top inputs, the card's details, a row of
             another stock never joined, the open picks' reasons at tonight's close, the monitor, ON TIME / LATE, no
             file / no folder; the journal's WHY band from a hash-checked part P run and the hash-chained why ledger
             (by hand: lead, the reason's share, the top 3 inputs; ENS's two halves); a pick the export scored
             differently left blank; guards (a changed part P output, an edited ledger line)
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tl_world as W  # noqa: E402
import tl_ctx_world as CW  # noqa: E402

IST = "Asia/Kolkata"


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def fake_tags(base: Path, picks: pd.DataFrame, plan: dict) -> Path:
    """setuplab tag's output for the planted entries: plan = {trade_id: {setup id: watch day}}."""
    run = base / "TAGS" / "TAGS_20261108_001"
    run.mkdir(parents=True, exist_ok=True)
    ids = ["S2", "C1", "N1"]
    rows = []
    for t in picks["trade_id"].astype(str):
        r = {"trade_id": t}
        d = plan.get(t, {})
        for sid in ids:
            r[f"su_{sid}_day"] = float(d[sid]) if sid in d else np.nan
            r[f"su_{sid}_net_d5"] = 1.0 + 0.1 * d[sid] if sid in d else np.nan
            r[f"su_{sid}_net_fresh"] = 2.0 + 0.1 * d[sid] if sid in d else np.nan
        r["setups"] = " ".join(f"{s}@D{d[s]}" for s in ids if s in d)
        r["n_setups"] = len(d)
        rows.append(r)
    T = pd.DataFrame(rows)
    T.to_parquet(run / "setup_tags.parquet", index=False)
    meta = {"version": "setuplab v0.7", "frozen_sha256": "f" * 64, "signal_days": ["2023-01-02", "2023-08-01"],
            "setups": [{"id": "S2", "name": "Bad week + minus-DI 5-day change rising + gap down",
                        "primary_exit": "original_d5"},
                       {"id": "C1", "name": "Bad week + minus-DI rising + 2% dip", "primary_exit": "original_d5"},
                       {"id": "N1", "name": "Below the lower Bollinger band + 2% dip", "primary_exit": "fresh"}]}
    (run / "TAGS.json").write_text(json.dumps(meta), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'setup_tags.parquet')}  setup_tags.parquet\n", encoding="utf-8")
    return run


def run_all(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        """the suite's check(cond, msg); a failing check also names what it saw"""
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("17. setups add-on: frozen setups (setuplab) in the backtester, simulator, watch page and journal")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "su_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    from tl_common import TLError
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    cand = P[(P["engine"] == "D") & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)].sort_values(["sig", "rank"])
    cand = cand.iloc[::9].head(24)
    plan = {}
    for i, t in enumerate(cand["trade_id"]):
        d = {"S2": 1 + i % 5}
        if i % 3 == 0:
            d["C1"] = 1 + (i + 2) % 5
        if i % 4 == 1:
            d["N1"] = 2
        plan[t] = d
    base = TMP / "su_out"
    run = fake_tags(base, P, plan)
    # ---- the tags: read only with their hash
    T0, i0 = SU.load_tags(None)
    try:
        SU.load_tags(None, need=True)
        need_ok = False
    except TLError as e:
        need_ok = "--setups" in str(e)
    tags, info = SU.load_tags(base)
    good = (run / "setup_tags.parquet").read_bytes()
    pd.read_parquet(run / "setup_tags.parquet").assign(n_setups=9).to_parquet(run / "setup_tags.parquet", index=False)
    try:
        SU.load_tags(base)
        tamper = False
    except TLError as e:
        tamper = "does not match" in str(e)
    (run / "setup_tags.parquet").write_bytes(good)
    check(T0 is None and not i0["used"] and need_ok and tags is not None and info["setups"] == ["S2", "C1", "N1"] and
          info["primary_exit"]["N1"] == "fresh" and tamper,
          "tags: none without --setups / SETUPLAB_OUT (and a clear refusal when a strategy needs them); the newest "
          "TAGS run is read only when its outputs.sha256 matches - a changed table is refused")
    # ---- a strategy that enters at S2's own entry day, sold at the D5 close; and with a 'hold' exit
    import tl_backtest as BT
    sdir = TMP / "su_strats"
    sdir.mkdir(exist_ok=True)
    s_d5 = sdir / "s2_d5.py"
    s_d5.write_text('STRATEGY = {"name": "s2_d5", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D"], '
                    '"ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}, "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}], '
                    '"exits": [{"name": "d5", "type": "time", "at": "close", "session": 5}]}\n', encoding="utf-8")
    s_fr = sdir / "s2_fresh.py"
    s_fr.write_text('STRATEGY = {"name": "s2_fresh", "mode": "daily", "max_sessions": 9, "picks": {"engines": ["D"], '
                    '"ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}, "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}], '
                    '"exits": [{"name": "fresh", "type": "time", "hold": 5}]}\n', encoding="utf-8")
    out = TMP / "su_bt"
    daily = {s: pd.read_parquet(root / f"{s}_daily.parquet") for s in w["names"]}
    res = {}
    for nm, sp in (("d5", s_d5), ("fresh", s_fr)):
        rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                                  "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)])
        bt = sorted((out / "backtest").glob("TLB_*"))[-1]
        res[nm] = (rc, log, pd.read_parquet(bt / "trades.parquet"), json.loads((bt / "summary.json").read_text()),
                   (bt / "report.md").read_text(encoding="utf-8"), bt)
    ok_ent, bad = True, []
    for nm, hold in (("d5", None), ("fresh", 5)):
        rc, log, A, sm, rep, bt = res[nm]
        A = A.set_index("trade_id")
        for t, d in plan.items():
            k = d["S2"]
            r = A.loc[t]
            sym = cand.set_index("trade_id").at[t, "symbol"]
            sig = int(cand.set_index("trade_id").at[t, "sig"])
            o = float(daily[sym]["open"].iloc[sig + k])
            xs = 5 if hold is None else k + hold - 1
            c = float(daily[sym]["close"].iloc[sig + xs])
            want = (c / o - 1 - 0.0035) * 1e4
            good_row = (r["status"] == "ok" and int(r["entry_session"]) == k and abs(r["first_entry"] - o) < 1e-9
                        and int(r["exit_session"]) == xs and abs(r["net_bp"] - want) < 1e-6
                        and r["setups"] == plan_txt(d))
            if not good_row:
                bad.append((nm, t, r["status"], r["entry_session"], k, r["exit_session"], xs))
            ok_ent &= good_row
        others = A.drop(index=list(plan))
        ok_ent &= bool((others["status"].isin(["not_entered", "pending"])).all() and
                       (others.loc[others["status"] == "not_entered", "net_bp"] == 0).all() and
                       (others["status"] == "not_entered").mean() > 0.9)
        ok_ent &= rc == 0
    rc, log, A, sm, rep, bt = res["d5"]
    traded = A[A["entered"].astype(bool)]
    same = abs(sm["paired"]["diff_on_traded"][0] - traded["diff_bp"].mean()) < 1e-6
    check(ok_ent and same and "## Frozen setups (setuplab tags)" in rep and "ENTERS at setups ['S2']" in rep and
          sm["setups"]["run"] == run.name and sm["strategy"]["setup_entries"] == ["S2"],
          f"setup entries: each of the {len(plan)} planted S2 picks bought at the open of ITS entry day (D1-D5) and "
          f"nowhere else; sold at the D5 close, or with 'hold': 5 at the close 4 sessions after the entry (net = "
          f"exit / that open - 1 - 35 bp, by hand); every other pick not entered (0 bp); 'on the picks the strategy "
          f"traded' = the setup's own trades vs the plan on the same picks", bad[:4])
    # ---- the guards
    def bt_rc(text, extra=()):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none"] + list(extra))
    g1 = bt_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"], "filter": "su_S2_day > 0"}}\n', ["--setups", str(base)])
    g2 = bt_rc('STRATEGY = {"name": "g2", "picks": {"engines": ["D"]}, "entries": [{"name": "b", "size": 1.0, '
               '"when": "close < open and n_setups > 0", "sessions": [1, 4]}]}\n', ["--setups", str(base)])
    g3 = bt_rc(s_d5.read_text(encoding="utf-8"))
    g4 = bt_rc(s_d5.read_text(encoding="utf-8").replace('"S2"', '"S9"'), ["--setups", str(base)])
    g5 = bt_rc(s_fr.read_text(encoding="utf-8").replace('"max_sessions": 9', '"max_sessions": 8'), ["--setups", str(base)])
    g6 = bt_rc(s_d5.read_text(encoding="utf-8").replace('"setup": "S2"', '"setup": "S2", "session": 2'),
               ["--setups", str(base)])
    check(g1[0] == 2 and "is a setup tag" in g1[1] and g2[0] == 2 and "'n_setups' is a setup tag" in g2[1] and
          g3[0] == 2 and "needs the frozen setups' tags" in g3[1] and g4[0] == 2 and "not frozen setups" in g4[1] and
          g5[0] == 2 and "max_sessions >= 9" in g5[1] and g6[0] == 2 and "takes no 'session'" in g6[1],
          "guards: a filter or an entry rule naming a setup tag is refused (look-ahead), with the way out; a setup "
          "leg without tags, an unknown setup, a 5-session hold that cannot fit after a D5 entry, and a setup leg "
          "with its own session are refused",
          [x[1][-160:] for x in (g1, g2, g3, g4, g5, g6) if x[0] != 2])
    # ---- tag columns on a plain backtest (hindsight), every column documented
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(LAB / "strategies" / "plan.py"), "--no-portfolio", "--context", "none",
                              "--setups", str(base)])
    bt = sorted((out / "backtest").glob("TLB_*"))[-1]
    A = pd.read_parquet(bt / "trades.parquet").set_index("trade_id")
    dd = pd.read_csv(bt / "data_dictionary.csv")
    rep = (bt / "report.md").read_text(encoding="utf-8")
    tag_ok = all(A.at[t, "setups"] == plan_txt(d) and int(A.at[t, "su_S2_day"]) == d["S2"] for t, d in plan.items()
                 if t in A.index)
    check(rc == 0 and tag_ok and {"setups", "n_setups", "su_S2_day", "su_C1_day", "su_N1_day", "setups_tagged"} <=
          set(A.columns) and bool(A["setups_tagged"].all()) and not (dd["meaning"] == "UNDOCUMENTED").any() and
          "hindsight" in rep,
          "the plan's own backtest carries the tags (setups 'S2@D3 C1@D5', su_<ID>_day) as hindsight columns, "
          "documented in the data dictionary; the report says they describe trades, never choose them")
    # ---- the simulator's story
    import tl_sim as SIM
    t1 = next(iter(plan))
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t1, "--strategy", str(s_d5), "--context", "none", "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t1}__s2_d5_story.md").read_text(encoding="utf-8")
    ssum = json.loads((sim / "summary.json").read_text())
    rs = ssum["results"]["s2_d5"][0]
    check(rc == 0 and "Frozen setups on this pick" in story and f"S2 on D{plan[t1]['S2']}" in story and
          int(rs["entry_session"]) == plan[t1]["S2"],
          "the simulator: the story names the pick's frozen setups (hindsight before their day) and a setup "
          "strategy enters on S2's own day")
    # ---- the watch page: the setups column and section from the scan
    import test_state as TST
    winfo = CW.make_ctx_world(TMP / "su_watch_world", "absent", 7, n_days=420)
    wroot = winfo["root"]
    fresh_modules(wroot)
    import tl_watch as WT
    day_idx = 400
    planted = TST._write_planted(wroot, winfo["days"], day_idx)
    day = TST._paper(wroot, winfo, day_idx, planted)
    L = [json.loads(x) for x in (wroot / "paper" / "ledger.jsonl").read_text().splitlines() if x.startswith("{")]
    tonight = [x for x in L if x["date"] == f"{day:%Y-%m-%d}" and x["engine"] == "D"]
    older = [x for x in L if x["date"] < f"{day:%Y-%m-%d}"]
    r1, r2, r3 = tonight[0], tonight[1], older[0]
    scan = pd.DataFrame([
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "C3", "status": "FIRES", "trade_id": "x1", "engine": "D",
         "rank": r1["rank"], "symbol": r1["symbol"], "signal_day": r1["date"], "next_watch_day": 1, "rule_at_open": "",
         "entered_day": "", "entry": np.nan, "zone": "IN"},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "S2", "status": "ARMED", "trade_id": "x2", "engine": "D",
         "rank": r2["rank"], "symbol": r2["symbol"], "signal_day": r2["date"], "next_watch_day": 1,
         "rule_at_open": "open below 123.45", "entered_day": "", "entry": np.nan, "zone": "OUT"},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "C1", "status": "ENTERED", "trade_id": "x3", "engine": r3["engine"],
         "rank": r3["rank"], "symbol": r3["symbol"], "signal_day": r3["date"], "next_watch_day": 4, "rule_at_open": "",
         "entered_day": 3, "entry": 99.5},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "S1", "status": "WATCHING", "trade_id": "x4", "engine": "D",
         "rank": r1["rank"], "symbol": r1["symbol"], "signal_day": r1["date"], "next_watch_day": 1, "rule_at_open": "",
         "entered_day": "", "entry": np.nan}])
    sdir2 = base / "scan"
    sdir2.mkdir(parents=True, exist_ok=True)
    scan.to_csv(sdir2 / f"scan_{day:%Y%m%d}.csv", index=False)
    (sdir2 / "setup_ledger.jsonl").write_text(json.dumps({"event": "scan", "scan_date": f"{day:%Y-%m-%d}",
                                                          "on_time": True, "recorded_at": "x"}) + "\n", encoding="utf-8")
    wout = TMP / "su_watch_out"
    rc, log = quiet(WT.main, ["--root", str(wroot), "--out", str(wout), "--stage-e-any", "--setups", str(base)])
    R = pd.read_csv(wout / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    md = (wout / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    H = (wout / "watch" / f"WATCH_{day:%Y%m%d}.html").read_text(encoding="utf-8")
    g = R.set_index(["engine", "rank"])["setups"].fillna("")
    rc2, log2 = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "su_watch_out2"), "--stage-e-any"])
    md2 = (TMP / "su_watch_out2" / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    R2 = pd.read_csv(TMP / "su_watch_out2" / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    sec = md.split("## Frozen setups and the entry tree at the next open")[1].split("## Stock cards")[0] \
        if "## Frozen setups and the entry tree at the next open" in md else ""
    check(rc == 0 and g[("D", r1["rank"])] == "BUY at the open: C3 in zone" and
          g[("D", r2["rank"])] == "S2 outside zone only if open below 123.45" and
          "recorded ON TIME" in sec and "C1 entered D3 at 99.50" in sec and f"**{r3['symbol']}** bought" in sec and
          "S1" not in sec and "Frozen setups and the entry tree at the next open" in H and "class='scard'" in H and
          rc2 == 0 and "Setup scan: no --setups and no SETUPLAB_OUT" in md2 and R2["setups"].fillna("").eq("").all(),
          "the watch page: tonight's picks show what fires / is armed at the next open (v1.3: 'BUY at the open: C3 in "
          "zone'), a section with one card per stock (FIRES / ARMED / ENTERED of the last five sessions, never "
          "WATCHING; the scan's own rows folded away) that says the scan was on time; without a scan the column is "
          "blank and the page says so")
    # ---- v1.3: one line per stock - the RRKABEL case (one purchase named by 7 setup x pick rows) and the tree
    sa, sb, sc_ = "RRKABEL", "SUYOG", "AIAENG"
    d_a, d_b = "2026-01-05", "2026-01-08"
    dup = [{"scan_date": f"{day:%Y-%m-%d}", "setup": sid, "status": "ENTERED", "trade_id": f"D-a-4", "engine": "D",
            "rank": 4, "symbol": sa, "signal_day": d_a, "next_watch_day": 5, "rule_at_open": "", "entered_day": 3,
            "entry_date": "2026-01-08", "entry": 1970.0, "mark_pct": -2.59, "primary_exit": "original_d5", "zone": ""}
           for sid in ("C1", "C2", "C3", "S1", "S3")]
    dup += [{"scan_date": f"{day:%Y-%m-%d}", "setup": "C3", "status": "ENTERED", "trade_id": f"{e}-b-{k}", "engine": e,
             "rank": k, "symbol": sa, "signal_day": d_b, "next_watch_day": 2, "rule_at_open": "", "entered_day": 1,
             "entry_date": "2026-01-08", "entry": 1970.0, "mark_pct": -2.59, "primary_exit": "original_d5", "zone": ""}
            for e, k in (("ENS", 1), ("D", 2))]
    dup += [{"scan_date": f"{day:%Y-%m-%d}", "setup": "N1", "status": "ENTERED", "trade_id": "D-c-6", "engine": "D",
             "rank": 6, "symbol": sb, "signal_day": d_b, "next_watch_day": 3, "rule_at_open": "", "entered_day": 2,
             "entry_date": "2026-01-09", "entry": 55.5, "mark_pct": 1.25, "primary_exit": "fresh", "zone": ""},
            {"scan_date": f"{day:%Y-%m-%d}", "setup": "N1", "status": "FIRES", "trade_id": "D-d-1", "engine": "D",
             "rank": 1, "symbol": sc_, "signal_day": d_b, "next_watch_day": 3, "rule_at_open": "", "entered_day": "",
             "entry_date": "", "entry": np.nan, "mark_pct": np.nan, "primary_exit": "fresh", "zone": "IN",
             "close_tonight": 101.0},
            {"scan_date": f"{day:%Y-%m-%d}", "setup": "S2", "status": "ARMED", "trade_id": "ENS-d-3", "engine": "ENS",
             "rank": 3, "symbol": sc_, "signal_day": d_a, "next_watch_day": 5, "rule_at_open": "open below 99.00",
             "entered_day": "", "entry_date": "", "entry": np.nan, "mark_pct": np.nan, "primary_exit": "original_d5",
             "zone": "", "close_tonight": 101.0}]
    base3 = TMP / "su_watch_dup"
    (base3 / "scan").mkdir(parents=True, exist_ok=True)
    pd.DataFrame(dup).to_csv(base3 / "scan" / f"scan_{day:%Y%m%d}.csv", index=False)
    (base3 / "scan" / "setup_ledger.jsonl").write_text(json.dumps({"event": "scan", "scan_date": f"{day:%Y-%m-%d}",
                                                                   "on_time": True, "recorded_at": "x"}) + "\n",
                                                       encoding="utf-8")
    trec = {"event": "tree", "scan_date": f"{day:%Y-%m-%d}", "on_time": True,
            "picks": [{"trade_id": "D-t-1", "engine": "D", "rank": 1, "symbol": "CALMONE", "lane": "CALM", "close": 250.0},
                      {"trade_id": "D-t-2", "engine": "D", "rank": 2, "symbol": "CALMTWO", "lane": "CALM", "close": 80.0},
                      {"trade_id": "ENS-t-1", "engine": "ENS", "rank": 1, "symbol": "CALMONE", "lane": "CALM",
                       "close": 250.0},
                      {"trade_id": "D-d-1", "engine": "D", "rank": 1, "symbol": sc_, "lane": "JUMPY", "close": 101.0}],
            "orders": {"D_calm_in_rank_order": ["D-t-1", "D-t-2"], "ENS_calm_at_open": ["ENS-t-1"],
                       "setup_buys": [{"trade_id": "D-d-1", "engine": "D", "setup": "N1", "status": "FIRES",
                                       "rule_at_open": "", "unless_calm_buy": False}]}}
    old_rec = dict(trec, scan_date=f"{day - pd.Timedelta(days=3):%Y-%m-%d}", picks=[{"trade_id": "D-a-4", "lane": "JUMPY"}])
    (base3 / "scan" / "tree_ledger.jsonl").write_text(json.dumps(old_rec) + "\n" + json.dumps(trec) + "\n",
                                                      encoding="utf-8")
    pd.DataFrame([{"book": "D tree", "trade_id": "D-a-4", "engine": "D", "rank": 4, "symbol": sa, "how": "C1@D3",
                   "entry_date": "2026-01-08", "entry": 1970.0, "exit_date": "2026-01-12", "status": "held",
                   "net": np.nan, "now_pct": -2.59},
                  {"book": "ENS tree", "trade_id": "ENS-b-1", "engine": "ENS", "rank": 1, "symbol": sa, "how": "open",
                   "entry_date": "2026-01-08", "entry": 1970.0, "exit_date": "2026-01-14", "status": "held",
                   "net": np.nan, "now_pct": -2.59},
                  {"book": "D baseline", "trade_id": "D-z-1", "engine": "D", "rank": 1, "symbol": "BASEONLY",
                   "how": "open", "entry_date": "2026-01-08", "entry": 10.0, "exit_date": "2026-01-14",
                   "status": "held", "net": np.nan, "now_pct": 0.5}]).to_csv(base3 / "scan" / "tree_book.csv", index=False)
    import tl_setups as SU3
    Sd = pd.read_csv(base3 / "scan" / f"scan_{day:%Y%m%d}.csv", dtype={"trade_id": str})
    tr3 = SU3.read_tree_night(base3, day)
    hg, ng, tg = SU3.held_groups(Sd), SU3.next_open_groups(Sd, tr3), SU3.tree_books_held(tr3)
    ha = [x for x in hg if x["symbol"] == sa]
    hb = [x for x in hg if x["symbol"] == sb]
    nxs = {x["symbol"]: x for x in ng}
    sells_a = " | ".join(ha[0]["sells"]) if ha else ""
    f_ok = (len(hg) == 2 and len(ha) == 1 and ha[0]["n_rows"] == 7 and len(ha[0]["setups"]) == 3 and
            any("C1 C2 C3 S1 S3" in t for t in ha[0]["setups"]) and ha[0]["sells"] == [
                "tomorrow's close: C1 C2 C3 S1 S3 (D #4, 5 Jan pick)",
                "the close in 4 sessions: C3 (ENS #1, 8 Jan pick); C3 (D #2, 8 Jan pick)"] and
            len(hb) == 1 and hb[0]["sells"] == ["the close in 4 sessions: N1 (D #6, 8 Jan pick)"] and
            set(nxs) == {sc_, "CALMONE", "CALMTWO"} and nxs[sc_]["do"] == "BUY at the open" and
            len(nxs[sc_]["setups"]) == 2 and nxs[sc_]["lane"] == "JUMPY" and
            nxs[sc_]["tree"] == ["D tree: buy through N1"] and
            any("D tree: buy at the open if it opens at or above 250.00" in t and "#1 of 2" in t
                for t in nxs["CALMONE"]["tree"]) and "ENS tree: BUY at the open (calm)" in nxs["CALMONE"]["tree"] and
            nxs["CALMONE"]["do"] == "" and [x["symbol"] for x in tg] == [sa] and len(tg[0]["books"]) == 2 and
            tr3["lanes"].get("D-a-4") == "JUMPY")
    wout3 = TMP / "su_watch_out3"
    rc3, log3 = quiet(WT.main, ["--root", str(wroot), "--out", str(wout3), "--stage-e-any", "--setups", str(base3)])
    H3 = (wout3 / "watch" / f"WATCH_{day:%Y%m%d}.html").read_text(encoding="utf-8")
    md3 = (wout3 / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    held_html = H3.split("Frozen setups held")[1].split("Entry tree books held")[0] if "Frozen setups held" in H3 else ""
    # a later scan makes tonight's tree book stale: not shown
    (base3 / "scan" / "tree_ledger.jsonl").write_text(json.dumps(old_rec) + "\n" + json.dumps(trec) + "\n" +
                                                      json.dumps(dict(trec, scan_date="2099-01-01")) + "\n",
                                                      encoding="utf-8")
    stale = SU3.read_tree_night(base3, day)
    check(f_ok and rc3 == 0 and held_html.count(f"<b>{sa}</b>") == 1 and "7 setup rows - one purchase" in H3 and
          f"- **{sa}** bought 2026-01-08 at 1970.00, now -2.59% (gross) - 7 setup rows, one purchase" in md3 and
          "Entry tree books held" in H3 and "BASEONLY" not in H3 and "<details><summary>The scan's rows (" in H3 and
          stale["found"] and stale["book"] is None,
          "v1.3 one line per stock: a purchase named by 7 setup x pick rows (5 setups on one pick + C3 on two more) is "
          "ONE card listing every pick, its setups and when each sells, soonest first (D5 close: tomorrow / in 4 "
          "sessions; N1 fresh: D6); a stock with FIRES and ARMED on two picks is one 'at the next open' line with both; the entry tree's "
          "orders (D calm list with the open rule, ENS calm buy, a setup buy) and lanes per stock; the tree books' "
          "held stocks (baseline books never) and only while no later scan has run; the scan's rows folded away",
          (f_ok, rc3, held_html.count(f"<b>{sa}</b>"), [x.get("sells") for x in hg], [(k_, v["tree"], v["do"]) for k_, v in nxs.items()]))
    # ---- the trade journal: the FROZEN SETUPS band
    import tl_export as X
    import tl_journal as J
    rc, log = quiet(X.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(TMP / "su_exp"),
                             "--stage-e-any", "--features", "none", "--no-benchmark"])
    ex = sorted((TMP / "su_exp" / "export").glob("TLX_*"))[-1]
    from openpyxl import load_workbook
    res_j = {}
    for nm, sb in (("with", str(base)), ("without", None)):
        quiet(J.build, ex, False, f"J_{nm}.xlsx", lambda m: None, sb)
        wb = load_workbook(ex / f"J_{nm}.xlsx", read_only=True)
        ws = wb["Trades"]
        rows = list(ws.iter_rows(values_only=True))
        hdr = next(r for r in rows if r and "Symbol" in r)
        res_j[nm] = (hdr, rows[rows.index(hdr) + 1:])
    hdr, body = res_j["with"]
    traded_tagged = [t for t in plan if int(t.rsplit("-", 1)[1]) <= 3]
    ci = hdr.index("Setups")
    n_tagged = sum(1 for r in body if r[ci])
    check("Setups" in hdr and "S2 %" in hdr and "N1 %" in hdr and n_tagged == len(traded_tagged) and
          "Setups" not in res_j["without"][0],
          f"the trade journal: a FROZEN SETUPS band (which setups entered each traded pick, each setup's net at its "
          f"primary exit) - {len(traded_tagged)} tagged traded picks; no band without the tags",
          (n_tagged, len(traded_tagged)))


def plan_txt(d: dict) -> str:
    return " ".join(f"{s}@D{d[s]}" for s in ("S2", "C1", "N1") if s in d)


def fake_tree(base: Path, picks: pd.DataFrame, rows: dict, frozen: str = "f" * 64) -> Path:
    """setuplab tree's output: rows = {trade_id: {lane, how, action, ...}}; every other pick: lane JUMPY, no action."""
    run = base / "TREE" / "TREE_20261109_001"
    run.mkdir(parents=True, exist_ok=True)
    out = []
    for t, e, rk, sy, sd in zip(picks["trade_id"].astype(str), picks["engine"], picks["rank"], picks["symbol"],
                                picks["signal_day"]):
        r = rows.get(t, {})
        lane = r.get("lane", "JUMPY")
        out.append({"trade_id": t, "engine": e, "rank": int(rk), "symbol": sy, "signal_day": f"{pd.Timestamp(sd):%Y-%m-%d}",
                    "s_atr14": 0.04 if lane == "CALM" else 0.07, "cutoff": 0.055, "lane": lane, "etf": bool(r.get("etf", False)),
                    "gap_pct": r.get("gap", 0.5), "opened_up": r.get("gap", 0.5) >= 0, "dip_2pct": False,
                    "runner": False, "first_setup": r.get("first", ""), "setup_net": r.get("setup_net", np.nan),
                    "bunch": np.nan, "d1_net": r.get("d1_net", 0.25), "action": r.get("action", ""),
                    "how": r.get("how", ""), "in_book_start1": False, "complete": True})
    pd.DataFrame(out).to_parquet(run / "tree_tags.parquet", index=False)
    meta = {"version": "setuplab v1.1", "tree_sha256": "a" * 64, "frozen_sha256": frozen,
            "window": ["2021-01-01", "2026-09-22"], "reconciled": True, "cutoffs": {"2023": 0.055}}
    (run / "TREE_RUN.json").write_text(json.dumps(meta), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'tree_tags.parquet')}  tree_tags.parquet\n", encoding="utf-8")
    return run


def run_tree(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("18. setups add-on v1.2: calm / jumpy and the entry tree in the backtester, simulator and journal")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "tr_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    import tl_backtest as BT
    from tl_common import TLError
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::7].head(30).set_index("trade_id")
    # the planted tree: open buys (calm), S2 / C1 / N1 buys on their own day, skips; tags agree with the setup buys
    kinds = ["open", "S2@D3", "N1@D4", "skip", "C1@D2", "N1@D5", "open", "S2@D1", "skip", "skip"]
    rows, tplan, want = {}, {}, {}
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        if k == "open":
            rows[t] = {"lane": "CALM", "how": "open", "action": "BUY AT OPEN (calm, opened up)", "d1_net": 1.5 + i}
            want[t] = (1, 5)
        elif k == "skip":
            rows[t] = {"lane": "JUMPY", "how": "", "action": "WAIT: jumpy -> no setup: skipped", "gap": -0.4}
            want[t] = None
        else:
            sid, kk = k.split("@D")
            kk = int(kk)
            rows[t] = {"lane": "JUMPY" if i % 2 else "CALM", "how": k, "action": f"WAIT: jumpy -> {k}", "first": k,
                       "setup_net": -2.0 + i, "gap": -1.0}
            tplan[t] = {sid: kk}
            want[t] = (kk, kk + 4 if sid == "N1" else 5)
    base = TMP / "tr_out"
    fake_tags(base, P, tplan)
    run = fake_tree(base, P, rows)
    # ---- the tree run: read only with its hash
    t0_, i0 = SU.load_tree(None)
    try:
        SU.load_tree(None, need=True)
        need_ok = False
    except TLError as e:
        need_ok = "entry tree" in str(e) and "--setups" in str(e)
    tree, tinf = SU.load_tree(base)
    good = (run / "tree_tags.parquet").read_bytes()
    pd.read_parquet(run / "tree_tags.parquet").assign(lane="CALM").to_parquet(run / "tree_tags.parquet", index=False)
    try:
        SU.load_tree(base)
        tamper = False
    except TLError as e:
        tamper = "does not match" in str(e)
    (run / "tree_tags.parquet").write_bytes(good)
    _, i_none = SU.load_tree(TMP / "tr_nothing")
    check(t0_ is None and not i0["used"] and need_ok and tree is not None and tinf["run"] == run.name and
          tinf["reconciled"] is True and tamper and not i_none["used"] and "run setuplab's tree command" in i_none["why"],
          "tree run: none without --setups / SETUPLAB_OUT (a clear refusal when needed, and when the folder has no "
          "TREE run); the newest TREE run is read only when its outputs.sha256 matches - a changed table is refused")
    # ---- the tree strategy: buys where the tree bought, sells where it sold
    sdir = TMP / "tr_strats"
    sdir.mkdir(exist_ok=True)
    tree_src = (LAB / "strategies" / "tree.py").read_text(encoding="utf-8").replace('"from": "2021-01-01"',
                                                                                   '"from": "2023-01-01"')
    s_tree = sdir / "tree.py"
    s_tree.write_text(tree_src, encoding="utf-8")
    out = TMP / "tr_bt"

    def bt(strategy, extra=(), setups=True):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--context", "none"] + list(extra) + (["--setups", str(base)] if setups else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_

    rc, log, d = bt(s_tree)
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    rep = (d / "report.md").read_text(encoding="utf-8")
    dd = pd.read_csv(d / "data_dictionary.csv")
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    ok_t, bad = rc == 0, []
    for t, wv in want.items():
        r = A.loc[t]
        if wv is None:
            g = r["status"] == "not_entered" and r["net_bp"] == 0
        else:
            k, xs = wv
            sym, sig = cand.at[t, "symbol"], int(cand.at[t, "sig"])
            o = float(daily[sym]["open"].iloc[sig + k])
            c = float(daily[sym]["close"].iloc[sig + xs])
            net = (c / o - 1 - 0.0035) * 1e4
            g = (r["status"] == "ok" and int(r["entry_session"]) == k and abs(r["first_entry"] - o) < 1e-9 and
                 int(r["exit_session"]) == xs and abs(r["net_bp"] - net) < 1e-6 and r["tree_how"] == rows[t]["how"])
        if not g:
            bad.append((t, r["status"], r.get("entry_session"), wv, r.get("exit_session")))
        ok_t &= bool(g)
    others = A.drop(index=list(want))
    ok_t &= bool((others["status"].isin(["not_entered", "pending"])).all())
    n_buy = sum(1 for v in want.values() if v)
    check(ok_t and sm["strategy"]["tree_entry"] is True and "This strategy IS the tree" in rep and
          int(A["entered"].astype(bool).sum()) == n_buy and any(v and v[1] == 9 for v in want.values()),
          f"tree strategy: each of the {n_buy} planted tree buys entered at ITS open (D1 for a calm open buy, the setup's "
          f"own day for S2 / C1 / N1) and sold at its close (the 5th; N1 4 sessions after its entry - session 9 for N1 "
          f"on D5); net = exit / open - 1 - 35 bp by hand; every skipped pick and every other pick not entered", bad[:4])
    # ---- columns, documented; the lane table by hand
    tcol = A.loc[list(want)]
    col_ok = all(tcol.at[t, "lane"] == rows[t]["lane"] and tcol.at[t, "tree_action"] == rows[t]["action"] and
                 (tcol.at[t, "calm"] == 1.0) == (rows[t]["lane"] == "CALM") for t in want)
    net_ok = all((abs(tcol.at[t, "tree_net"] - (rows[t]["d1_net"] if rows[t]["how"] == "open" else rows[t]["setup_net"]))
                  < 1e-9) if rows[t]["how"] else not np.isfinite(tcol.at[t, "tree_net"]) for t in want)
    paired = A[A["paired"].astype(bool)]
    lanes = {(r_["engine"], r_["lane"]): r_ for r_ in sm["tree"]["lanes"]}
    lt_ok = True
    for ln in ("CALM", "JUMPY"):
        g = paired[paired["lane"] == ln]
        r_ = lanes.get(("D", ln))
        lt_ok &= r_ is not None and r_["picks"] == len(g) and abs(r_["diff"][0] - (g["net_bp"] - g["net_bp_compare"]).mean()) < 1e-6
    check(rc == 0 and col_ok and net_ok and lt_ok and {"lane", "lane_atr14", "lane_cutoff", "calm", "opened_up",
          "tree_action", "tree_how", "tree_net", "tree_tagged"} <= set(A.columns) and
          not (dd["meaning"] == "UNDOCUMENTED").any() and "## Calm / jumpy lanes and the entry tree" in rep and
          "| D | CALM |" in rep and "| D | JUMPY |" in rep,
          "trades.csv carries the lane (lane, ATR, cut-off, calm) and the tree's action / buy / net on every pick, "
          "documented; the report's lane table = the paired picks by lane, difference by hand",
          (col_ok, net_ok, lt_ok))
    # ---- 'calm' as a filter (and refused without the tree)
    s_calm = sdir / "calm_plan.py"
    s_calm.write_text('STRATEGY = {"name": "calm_plan", "mode": "daily", "picks": {"engines": ["D"], "ranks": [1, 2, 3], '
                      '"filter": "calm == 1"}}\n', encoding="utf-8")
    rc, log, d = bt(s_calm, ["--no-portfolio"])
    C_ = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    calm_ids = {t for t, r_ in rows.items() if r_["lane"] == "CALM"}
    fil = C_.loc[[t for t in rows if t in C_.index]]
    f_ok = all((fil.at[t, "status"] == "filtered") != (t in calm_ids) for t in fil.index) and \
        bool((C_.drop(index=list(fil.index))["status"] == "filtered").all())
    rc2, log2, _ = bt(s_calm, ["--no-portfolio"], setups=False)
    rc_ok = SU.reads_calm({"picks": {"filter": "calm == 1"}}) and SU.reads_calm(
        {"entries": [{"name": "a", "when": "calm > 0 and close > open"}]}) and not SU.reads_calm(
        {"name": "calm", "description": "a calm strategy", "picks": {"filter": "calmness > 1"}})
    check(rc == 0 and f_ok and rc2 == 2 and "needs setuplab's tree run" in log2 and rc_ok,
          "'calm' is a pick attribute (known at the pick's close): filter 'calm == 1' trades the calm picks and filters "
          "the jumpy ones; without a tree run the filter is refused with the reason (a name or description saying 'calm' is "
          "not a rule)", (rc, f_ok, rc2, log2[-200:], rc_ok))
    # ---- the guards
    def g_rc(text, setups=True, root_base=None):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(sp), "--no-portfolio", "--context", "none"]
        if setups:
            args += ["--setups", str(root_base or base)]
        return quiet(BT.main, args)
    g1 = g_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"], "filter": "tree_net > 0"}}\n')
    g2 = g_rc('STRATEGY = {"name": "g2", "picks": {"engines": ["D"]}, "entries": [{"name": "b", "size": 1.0, '
              '"when": "opened_up and close > open", "sessions": [1, 4]}]}\n')
    g3 = g_rc(tree_src.replace('{"name": "tree", "type": "time", "tree": True}', '{"name": "d5", "type": "time", "session": 5}'))
    g4 = g_rc(tree_src.replace('"max_sessions": 9', '"max_sessions": 8'))
    g5 = g_rc(tree_src.replace('{"name": "tree", "size": 1.0, "tree": True}',
                               '{"name": "tree", "size": 1.0, "tree": True, "session": 2}'))
    g6 = g_rc(tree_src.replace('{"name": "tree", "size": 1.0, "tree": True}',
                               '{"name": "tree", "size": 1.0, "tree": True}, {"name": "o", "size": 1.0, "at": "open", '
                               '"session": 1}'))
    g7 = g_rc(tree_src, setups=False)
    bad_base = TMP / "tr_out_bad"
    fake_tags(bad_base, P, {t: {k_: v + 1 if v < 5 else 1 for k_, v in d_.items()} for t, d_ in tplan.items()})
    fake_tree(bad_base, P, rows)
    g8 = g_rc(tree_src, root_base=bad_base)
    other_base = TMP / "tr_out_other"
    fake_tags(other_base, P, tplan)
    fake_tree(other_base, P, rows, frozen="e" * 64)
    g9 = g_rc(tree_src, root_base=other_base)
    gs = (g1, g2, g3, g4, g5, g6, g7, g8, g9)
    check(g1[0] == 2 and "'tree_net' is an entry-tree column" in g1[1] and g2[0] == 2 and
          "'opened_up' is an entry-tree column" in g2[1] and g3[0] == 2 and "go together" in g3[1] and
          g4[0] == 2 and "max_sessions >= 9" in g4[1] and g5[0] == 2 and "takes no 'session'" in g5[1] and
          g6[0] == 2 and "must be the only entry" in g6[1] and g7[0] == 2 and "needs" in g7[1] and
          g8[0] == 2 and "disagree" in g8[1] and g9[0] == 2 and "freeze" in g9[1],
          "guards: a filter or rule naming a tree column (tree_net, opened_up) is refused (look-ahead) with the way out; "
          "a tree entry without the tree exit, with max_sessions 8, with a session, beside another entry, without the "
          "tree run, with tags that disagree with the tree's setup days, or with a tree on another freeze is refused",
          [x[1][-160:] for x in gs if x[0] != 2])
    # ---- without a tree run: nothing changes (no columns, no section)
    nb = TMP / "tr_out_tagsonly"
    fake_tags(nb, P, tplan)
    rc, log, d = bt(LAB / "strategies" / "plan.py", ["--no-portfolio"], setups=False)
    A0 = pd.read_parquet(d / "trades.parquet")
    rep0 = (d / "report.md").read_text(encoding="utf-8")
    rc_b, log_b = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                                  "--strategy", str(LAB / "strategies" / "plan.py"), "--no-portfolio", "--context",
                                  "none", "--setups", str(nb)])
    d_b = sorted((out / "backtest").glob("TLB_*"))[-1]
    A_b = pd.read_parquet(d_b / "trades.parquet")
    check(rc == 0 and rc_b == 0 and "lane" not in A0.columns and "lane" not in A_b.columns and "setups" in A_b.columns
          and "Calm / jumpy" not in rep0 and "Calm / jumpy" not in (d_b / "report.md").read_text(encoding="utf-8"),
          "without a tree run (no --setups, or a setuplab folder with tags only) the backtest runs as before: no lane "
          "columns, no lane section")
    # ---- the simulator's line and a tree strategy there
    import tl_sim as SIM
    t_n1 = next(t for t, v in want.items() if v and v[1] == 9)
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t_n1, "--strategy", str(s_tree), "--context", "none", "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t_n1}__tree_story.md").read_text(encoding="utf-8")
    rs = json.loads((sim / "summary.json").read_text())["results"]["tree"][0]
    check(rc == 0 and "**Entry tree**" in story and f"lane {rows[t_n1]['lane']}" in story and rows[t_n1]["action"] in
          story and int(rs["entry_session"]) == 5 and int(rs["exit_session"]) == 9,
          "the simulator: the story names the pick's lane and the tree's action; the tree strategy buys N1 on D5 and "
          "sells it at session 9", (rc, story[-400:], rs.get("entry_session"), rs.get("exit_session")))
    # ---- the trade journal's band
    import tl_export as X
    import tl_journal as J
    rc, log = quiet(X.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(TMP / "tr_exp"),
                             "--stage-e-any", "--features", "none", "--no-benchmark"])
    ex = sorted((TMP / "tr_exp" / "export").glob("TLX_*"))[-1]
    from openpyxl import load_workbook
    res_j = {}
    for nm, sb in (("with", str(base)), ("without", None), ("tagsonly", str(nb))):
        quiet(J.build, ex, False, f"J_{nm}.xlsx", lambda m: None, sb)
        wb = load_workbook(ex / f"J_{nm}.xlsx", read_only=True)
        rows_x = list(wb["Trades"].iter_rows(values_only=True))
        hdr = next(r_ for r_ in rows_x if r_ and "Symbol" in r_)
        res_j[nm] = (hdr, rows_x[rows_x.index(hdr) + 1:], wb)
    hdr, body, wb = res_j["with"]
    need_h = ("Engine", "Rank", "Symbol", "Lane", "Tree", "Tree buy", "Tree %", "Pick day")
    ix = {h: hdr.index(h) for h in need_h if h in hdr}
    seen, j_ok = 0, len(ix) == len(need_h)
    for r_ in body if j_ok else []:
        if not r_ or r_[ix["Engine"]] != "D":
            continue
        day_ = pd.Timestamp(r_[ix["Pick day"]])
        t = f"D-{day_:%Y%m%d}-{int(r_[ix['Rank']])}"
        if t in rows:
            seen += 1
            rr = rows[t]
            tp = r_[ix["Tree %"]]
            want_pct = (rr["d1_net"] if rr["how"] == "open" else rr.get("setup_net", np.nan)) / 100 if rr["how"] else None
            j_ok &= (r_[ix["Lane"]] == rr["lane"] and r_[ix["Tree"]] == rr["action"] and
                     (r_[ix["Tree buy"]] or "") == ("D1 open" if rr["how"] == "open" else rr["how"]) and
                     ((tp is None) if want_pct is None else (tp is not None and abs(tp - want_pct) < 1e-9)))
    readme = " ".join(str(c) for r_ in wb["Read me"].iter_rows(values_only=True) for c in r_ if c)
    check(seen == len(rows) and j_ok and "Lane" not in res_j["without"][0] and "Lane" not in res_j["tagsonly"][0] and
          "Setups" in res_j["tagsonly"][0] and "Calm / jumpy and the entry tree" in readme,
          f"the trade journal: a CALM / JUMPY AND THE ENTRY TREE band (lane, ATR, cut-off, opened up, the tree's action, "
          f"where it bought, its net) on all {len(rows)} planted picks, explained in the Read me; no band without a "
          f"tree run", (seen, len(rows), j_ok))


def run_sde(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("19. setups add-on v1.4: SDE at the pick and the tree's open_if branch")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "sde_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    import tl_backtest as BT
    # ---- SDE by hand
    fall = np.array([100.0 - 2 * i for i in range(11)])
    chop = np.array([100, 105, 95, 105, 95, 105, 95, 105, 95, 105, 90.0])
    flat = np.full(11, 50.0)
    miss = fall.copy()
    miss[4] = np.nan
    split = fall.copy()
    split[6:] = split[6:] / 2.0                                  # a 1:2 split not adjusted
    up3 = np.array([10, 11, 10.5, 12.0])
    h_ok = (abs(SU.sde_series(fall, 10)[-1] + 1.0) < 1e-12 and
            abs(SU.sde_series(chop, 10)[-1] - (90 - 100) / (5 + 10 * 8 + 15)) < 1e-12 and
            np.isnan(SU.sde_series(flat, 10)[-1]) and np.isnan(SU.sde_series(miss, 10)[-1]) and
            np.isnan(SU.sde_series(split, 10)[-1]) and np.isnan(SU.sde_series(fall[:10], 10)).all() and
            abs(SU.sde_series(up3, 3)[-1] - 2.0 / (1 + 0.5 + 1.5)) < 1e-12 and
            np.isnan(SU.sde_series(fall, 10)[:10]).all() and
            list(SU.bucket_sde([-0.9, -0.5, 0.0, 0.5, np.nan])) == ["NEG < -0.5", "MID", "MID", "POS >= +0.5", ""])
    check(h_ok, "SDE by hand: an orderly fall = -1; a choppy path = net / the sum of the moves; blank for a flat window, "
                "a missing bar, an unadjusted split (a move above 45%) and too little history; buckets NEG < -0.5 / "
                "MID / POS >= +0.5")
    # ---- the world, a planted tree, the tags it agrees with
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    cl = {s_: daily[s_]["close"].to_numpy(float) for s_ in w["names"]}

    def sde_hand(sym, sig, n=10):
        c = cl[sym][sig - n:sig + 1]
        den = np.abs(np.diff(c)).sum()
        return (c[-1] - c[0]) / den if den > 0 else np.nan
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::5].head(40).set_index("trade_id")
    cand["sde_h"] = [sde_hand(s_, int(g)) for s_, g in zip(cand["symbol"], cand["sig"])]
    thr = float(np.nanmedian(cand["sde_h"]))
    rows, tplan = {}, {}
    kinds = ["open", "S2@D3", "skip", "N1@D4", "skip", "skip"]
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        lane = "CALM" if k == "open" else ("JUMPY" if i % 4 else "CALM")
        r = {"lane": lane, "how": "" if k == "skip" else k, "action": "x", "d1_net": 0.5, "setup_net": 0.25,
             "etf": False}
        if "@D" in k:
            sid, kk = k.split("@D")
            tplan[t] = {sid: int(kk)}
            r["first"] = k
        rows[t] = r
    # one ETF the rule would buy (jumpy, SDE10 below the threshold): the tree never buys an ETF
    etf_t = next(t for t in cand.index if rows[t]["lane"] == "JUMPY" and rows[t]["how"] == "" and
                 np.isfinite(cand.at[t, "sde_h"]) and cand.at[t, "sde_h"] < thr)
    rows[etf_t]["etf"] = True
    base = TMP / "sde_out"
    fake_tags(base, P, tplan)
    fake_tree(base, P, rows)
    sdir = TMP / "sde_strats"
    sdir.mkdir(exist_ok=True)
    tree_src = (LAB / "strategies" / "tree.py").read_text(encoding="utf-8").replace('"from": "2021-01-01"',
                                                                                   '"from": "2023-01-01"')
    (sdir / "tree.py").write_text(tree_src, encoding="utf-8")
    sde_src = (LAB / "strategies" / "tree_sde.py").read_text(encoding="utf-8").replace(
        '"from": "2021-01-01"', '"from": "2023-01-01"').replace("pre_sde10 < -0.5", f"pre_sde10 < {thr!r}")
    (sdir / "tree_sde.py").write_text(sde_src, encoding="utf-8")
    out = TMP / "sde_bt"

    def bt(strategy, extra=(), setups=True, nopf=False):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--context", "none"] + list(extra) + (["--setups", str(base)] if setups else []) + \
            (["--no-portfolio"] if nopf else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_
    rc, log, d = bt(sdir / "tree_sde.py", ["--compare", str(sdir / "tree.py")])
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    rep = (d / "report.md").read_text(encoding="utf-8")
    dd = pd.read_csv(d / "data_dictionary.csv")
    # SDE at real picks against the world's closes
    sd_ok = all(abs(A.at[t, "pre_sde10"] - cand.at[t, "sde_h"]) < 1e-9 if np.isfinite(cand.at[t, "sde_h"]) else
                np.isnan(A.at[t, "pre_sde10"]) for t in cand.index)
    # the branch: jumpy, not ETF, SDE10 below the threshold -> D1 open, 5th close; everyone else = the frozen tree
    br_ok, n_br, bad = True, 0, []
    for t in cand.index:
        r, a_ = rows[t], A.loc[t]
        sym, sig = cand.at[t, "symbol"], int(cand.at[t, "sig"])
        hit = r["lane"] == "JUMPY" and not r["etf"] and np.isfinite(cand.at[t, "sde_h"]) and cand.at[t, "sde_h"] < thr
        if hit:
            n_br += 1
            o = float(daily[sym]["open"].iloc[sig + 1])
            c5 = float(daily[sym]["close"].iloc[sig + 5])
            g = (a_["status"] == "ok" and int(a_["entry_session"]) == 1 and int(a_["exit_session"]) == 5 and
                 abs(a_["net_bp"] - (c5 / o - 1 - 0.0035) * 1e4) < 1e-6)
        else:
            g = (a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or
                                                          (np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"]))))
        if not g:
            bad.append((t, r["lane"], r["etf"], cand.at[t, "sde_h"], a_["status"], a_.get("entry_session")))
        br_ok &= bool(g)
    etf_ok = rows[etf_t]["etf"] and A.at[etf_t, "status"] == A.at[etf_t, "status_compare"] == "not_entered"
    # every other pick (the tree run tags them JUMPY, skipped): the rule decides alone - below the threshold = D1 open
    others = A.drop(index=list(cand.index))
    o_hit = (others["lane"] == "JUMPY") & (others["pre_sde10"] < thr)
    oth_ok = bool(((others.loc[o_hit, "entry_session"] == 1) | (others.loc[o_hit, "status"] == "pending")).all() and
                  (others.loc[~o_hit, "status"] == others.loc[~o_hit, "status_compare"]).all() and o_hit.any())
    check(rc == 0 and sd_ok and br_ok and etf_ok and oth_ok and n_br >= 3 and sm["strategy"]["tree_open_if"] and
          sm["compare"]["name"] == "tree",
          f"the tree's open_if: the {n_br} jumpy non-ETF tree picks whose SDE10 (by hand from the world's closes) is "
          f"below the rule's threshold are bought at the D1 open and sold at the 5th close (net by hand); every other "
          f"pick - calm, ETF, above the threshold, untagged - trades exactly as the frozen tree it is compared with",
          (rc, sd_ok, br_ok, etf_ok, oth_ok, n_br, bad[:3], log[-300:]))
    # the decision rule (daily_diff_bp + cagr_and_drawdown) and the SDE section, by hand from the outputs
    dec = sm["decision"]
    pf = sm.get("portfolio") or {}
    sS, sC = pf.get("strategy") or {}, pf.get("compare") or {}
    lo = (pf.get("daily_ret_diff_bp") or [np.nan] * 3)[1]
    want = "PASS" if (lo > 0 and sS.get("cagr", np.nan) > sC.get("cagr", np.nan) and
                      sS.get("max_drawdown", np.nan) >= sC.get("max_drawdown", np.nan)) else "FAIL"
    tab = {(r_["engine"], r_["lane"], r_["sde10"]): r_ for r_ in sm["sde"]["table"]}
    paired = A[A["paired"].astype(bool)].copy()
    paired["b"] = SU.bucket_sde(paired["pre_sde10"].to_numpy(float))
    t_ok = True
    for (e_, ln, bk), r_ in tab.items():
        g = paired[(paired["engine"] == e_) & (paired["lane"].where(paired["lane"].isin(["CALM", "JUMPY"]), "no lane")
                                               == ln) & (paired["b"].replace("", "no SDE") == bk)]
        t_ok &= r_["picks"] == len(g) and abs(r_["diff"][0] - (g["net_bp"] - g["net_bp_compare"]).mean()) < 1e-6
    # decide() by hand on planted money numbers: each condition matters
    ev0 = {"summary": {"diff": [1.0, 0.5, 2.0], "strategy": [1.0, 0.5, 2.0]}}

    def pf0(lo_, cg, dd_):
        return {"stats": {"daily_ret_diff_bp": [1.0, lo_, 3.0], "strategy": {"cagr": cg[0], "max_drawdown": dd_[0]},
                          "compare": {"cagr": cg[1], "max_drawdown": dd_[1]}}}
    rule0 = {"metric": "daily_diff_bp", "pass_if": "lower > 0", "money": "cagr_and_drawdown"}
    d_ok = (BT.decide(rule0, ev0, pf0(0.2, (0.5, 0.4), (-0.2, -0.3)))["verdict"] == "PASS" and
            BT.decide(rule0, ev0, pf0(0.2, (0.5, 0.4), (-0.35, -0.3)))["verdict"] == "FAIL" and
            BT.decide(rule0, ev0, pf0(0.2, (0.3, 0.4), (-0.2, -0.3)))["verdict"] == "FAIL" and
            BT.decide(rule0, ev0, pf0(-0.1, (0.5, 0.4), (-0.2, -0.3)))["verdict"] == "FAIL" and
            BT.decide(rule0, ev0, None)["verdict"].startswith("NO MONEY VIEW") and
            BT.decide({"metric": "daily_diff_bp", "pass_if": "lower > 0"}, ev0, pf0(0.2, (0.3, 0.4), (-0.5, -0.3)))[
                "verdict"] == "PASS")
    m_want = bool(sS.get("cagr", np.nan) > sC.get("cagr", np.nan) and
                  sS.get("max_drawdown", np.nan) >= sC.get("max_drawdown", np.nan))
    check(d_ok and dec.get("verdict") == want and dec.get("money_ok") == m_want and np.isfinite(lo) and
          abs(dec.get("value", np.nan) - lo) < 1e-9 and "cagr" in sS and "## SDE at the pick" in rep and
          "| D | JUMPY |" in rep.split("## SDE at the pick")[1] and t_ok and len(tab) >= 2 and
          {"pre_sde3", "pre_sde5", "pre_sde10", "pre_sde20"} <= set(A.columns) and
          not (dd["meaning"] == "UNDOCUMENTED").any(),
          "decision rule daily_diff_bp + cagr_and_drawdown: PASS only when the daily-difference interval is above 0 AND "
          "the CAGR is higher AND the worst drawdown no deeper (each condition flipped by hand; and against the run's "
          "own money numbers); the "
          "SDE section's table = the paired picks by engine, lane and SDE10, difference by hand; pre_sde* documented",
          (d_ok, dec, want, t_ok, list(tab)[:4]))
    # ---- pre_sde10 in a filter; a comparison that trades the tree gets the tree; SDE without tree / context
    (sdir / "neg.py").write_text(f'STRATEGY = {{"name": "neg", "picks": {{"engines": ["D"], "ranks": [1, 2, 3], '
                                 f'"from": "2023-01-01", "filter": "pre_sde10 < {thr!r}"}}}}\n', encoding="utf-8")
    rc2, log2, d2 = bt(sdir / "neg.py", nopf=True, setups=False)
    N = pd.read_parquet(d2 / "trades.parquet")
    f_ok = bool(((N["status"] == "filtered") == ~(N["pre_sde10"] < thr)).all()) and (N["status"] != "filtered").any()
    rep2 = (d2 / "report.md").read_text(encoding="utf-8")
    (sdir / "plan3.py").write_text('STRATEGY = {"name": "plan3", "picks": {"engines": ["D"], "ranks": [1, 2, 3], '
                                   '"from": "2023-01-01"}, "max_sessions": 9}\n', encoding="utf-8")
    rc3, log3, d3 = bt(sdir / "plan3.py", ["--compare", str(sdir / "tree.py")], nopf=True)
    C3 = pd.read_parquet(d3 / "trades.parquet").set_index("trade_id")
    c_ok = all((C3.at[t, "status_compare"] == "ok") == bool(rows[t]["how"]) or C3.at[t, "status_compare"] == "pending"
               for t in cand.index)
    check(rc2 == 0 and f_ok and "## SDE at the pick" in rep2 and "| D | all |" in rep2 and rc3 == 0 and c_ok,
          "pre_sde10 is a pick attribute: a filter keeps exactly the picks below its threshold; the SDE section runs "
          "without a tree run and without market context (lane 'all'); a plan compared with strategies/tree.py gets "
          "the tree's entries for the comparison (never a silent 'not entered')", (rc2, f_ok, rc3, c_ok, log3[-300:]))
    # ---- guards
    def g_rc(text):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)])
    g1 = g_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"]}, "entries": [{"name": "o", "size": 1.0, "at": '
              '"open", "session": 1, "open_if": "pre_sde10 < 0"}]}\n')
    g2 = g_rc(tree_src.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "tree_net > 0"}],\n    "exits"'))
    g3 = g_rc(tree_src.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "close > 0"}],\n    "exits"'))
    g4 = g_rc(tree_src.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": ""}],\n    "exits"'))
    check(g1[0] == 2 and "open_if belongs to the tree entry" in g1[1] and g2[0] == 2 and "entry-tree column" in g2[1]
          and g3[0] == 2 and "pick attributes only" in g3[1] and g4[0] == 2 and "open_if must be a rule" in g4[1],
          "guards: open_if off the tree entry, naming a tree column (hindsight), reading a bar value (not known at the "
          "pick) or empty is refused with the reason", [x[1][-160:] for x in (g1, g2, g3, g4) if x[0] != 2])
    # ---- the simulator's SDE line
    import tl_sim as SIM
    t_h = next(t for t in cand.index if np.isfinite(cand.at[t, "sde_h"]))
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t_h, "--strategy", str(sdir / "tree_sde.py"), "--context", "none",
                               "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t_h}__tree_sde_story.md").read_text(encoding="utf-8")
    check(rc == 0 and "**SDE at the pick**" in story and f"{cand.at[t_h, 'sde_h']:+.2f}" in story,
          "the simulator: the story gives SDE at the pick (3 / 5 / 10 / 20) and the tree_sde strategy runs there",
          (rc, story[-300:]))


def fake_cuts(run: Path, days, n: int) -> Path:
    """voldir's run folder with daily_cuts.parquet (constants and patterned regime flags) hashed in outputs.sha256."""
    run.mkdir(parents=True, exist_ok=True)
    k = np.arange(len(days))
    C = pd.DataFrame({"date": pd.DatetimeIndex(days).normalize(), "rsj10_p10": -0.30, "rsj10_p90": 0.30,
                      "turn_rel_p33": 0.95, "turn_rel_p67": 1.05, "atrp_p67": 0.02, "ret20_p90": 0.02, "mvol": 1.0,
                      "mvol_p80": 1.0, "mvol_high": (k % 2).astype(float), "mvol_falling": (k % 3 == 0).astype(float),
                      "n_eligible": n})
    C.to_parquet(run / "daily_cuts.parquet", index=False)
    (run / "run.json").write_text(json.dumps({"tool": "voldir v1.0", "declaration_sha256": "d" * 64}), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'daily_cuts.parquet')}  daily_cuts.parquet\n", encoding="utf-8")
    return run


def run_vol(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:700]}")

    print("20. setups add-on v1.5: volatility x direction (voldir VD1) - values at the pick, the day's cuts, open_exit, "
          "veto_if, B1 sizing, the Calmar decision, strategy variants")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "vol_world", "absent", seed=13, n_syms=12, n_days=320, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    import tl_backtest as BT
    import tl_engine as E
    import tl_portfolio as PF
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    cl = {s_: daily[s_]["close"].to_numpy(float) for s_ in w["names"]}
    vo = {s_: daily[s_]["volume"].to_numpy(float) for s_ in w["names"]}

    def rsj_h(sym, i):
        c = cl[sym][i - 10:i + 1]
        r = np.log(c[1:] / c[:-1])
        return ((r[r > 0] ** 2).sum() - (r[r < 0] ** 2).sum()) / (r ** 2).sum()

    def trel_h(sym, i):
        if i < 129:
            return np.nan
        tv = cl[sym] * vo[sym]
        return tv[i - 9:i + 1].mean() / np.median(tv[i - 129:i - 9])
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 60) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::7].head(48).set_index("trade_id")
    cand["rsj"] = [rsj_h(s_, int(g)) for s_, g in zip(cand["symbol"], cand["sig"])]
    rows, tplan = {}, {}
    kinds = ["open", "S2@D3", "skip", "N1@D4", "skip", "C1@D2"]
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        lane = "CALM" if k == "open" else ("JUMPY" if i % 4 else "CALM")
        r = {"lane": lane, "how": "" if k == "skip" else k, "action": "x", "d1_net": 0.5, "setup_net": 0.25, "etf": False}
        if "@D" in k:
            sid, kk = k.split("@D")
            tplan[t] = {sid: int(kk)}
            r["first"] = k
        rows[t] = r
    base = TMP / "vol_out"
    fake_tags(base, P, tplan)
    fake_tree(base, P, rows)
    vrun = fake_cuts(TMP / "vd" / "runs" / "VD_20261112_001", days, 12)
    thr = float(np.nanmedian(cand["rsj"]))
    # the buy's own signal close for every tree buy: the pick's close for the open, session k-1 for a setup on Dk
    bday = {t: (1 if rows[t]["how"] == "open" else int(rows[t]["how"].split("@D")[1])) for t in cand.index
            if rows[t]["how"]}
    at_buy = {t: rsj_h(cand.at[t, "symbol"], int(cand.at[t, "sig"]) + bday[t] - 1) for t in bday}
    thr2 = float(np.nanmedian(list(at_buy.values())))
    sdir = TMP / "vol_strats"
    sdir.mkdir(exist_ok=True)
    (sdir / "vx.py").write_text(
        "import copy\n"
        + (LAB / "strategies" / "tree.py").read_text(encoding="utf-8").split('"""', 2)[2]
        + "STRATEGIES = {}\n"
        + f"STRATEGIES['OX'] = copy.deepcopy(STRATEGY); STRATEGIES['OX']['name'] = 'ox'\n"
        + f"STRATEGIES['OX']['entries'][0].update(open_if='calm == 0 and pre_rsj10 < {thr!r}', open_exit=2)\n"
        + f"STRATEGIES['VT'] = copy.deepcopy(STRATEGY); STRATEGIES['VT']['name'] = 'vt'\n"
        + f"STRATEGIES['VT']['entries'][0].update(veto_if='pre_rsj10 < {thr2!r}')\n"
        + "STRATEGIES['VC'] = copy.deepcopy(STRATEGY); STRATEGIES['VC']['name'] = 'vc'\n"
        + "STRATEGIES['VC']['entries'][0].update(veto_if='pre_rsj_lo == 1 or pre_mvol_high == 1')\n",
        encoding="utf-8")
    out = TMP / "vol_bt"

    def bt(strategy, extra=(), vd=True, nopf=False):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--context", "none", "--setups", str(base)] + list(extra) + \
            (["--voldir", str(vrun)] if vd else []) + (["--no-portfolio"] if nopf else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_
    tree_py = LAB / "strategies" / "tree.py"
    # ---- open_exit: jumpy non-ETF picks below the RSJ threshold -> D1 open, the 2nd close; the rest = frozen tree
    rc, log, d = bt(f"{sdir / 'vx.py'}#OX", ["--compare", str(tree_py)])
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    v_ok, cut_ok, ox_ok, n_ox, bad = True, True, True, 0, []
    for t in cand.index:
        sym, sig = cand.at[t, "symbol"], int(cand.at[t, "sig"])
        a_ = A.loc[t]
        v_ok &= bool(abs(a_["pre_rsj10"] - cand.at[t, "rsj"]) < 1e-9 and
                     (abs(a_["pre_turn_rel"] - trel_h(sym, sig)) < 1e-9 * max(1, trel_h(sym, sig)) if sig >= 129
                      else np.isnan(a_["pre_turn_rel"])) and abs(a_["pre_ret20"] - (cl[sym][sig] / cl[sym][sig - 20] - 1))
                     < 1e-12 and a_["pre_lock3"] in (0.0, 1.0))
        cut_ok &= bool(a_["pre_rsj_lo"] == float(cand.at[t, "rsj"] <= -0.30) and
                       a_["pre_rsj_hi"] == float(cand.at[t, "rsj"] >= 0.30) and a_["pre_mvol_high"] == float(sig % 2) and
                       a_["pre_mvol_falling"] == float(sig % 3 == 0))
        hit = rows[t]["lane"] == "JUMPY" and cand.at[t, "rsj"] < thr
        if hit:
            n_ox += 1
            o1, c2 = float(daily[sym]["open"].iloc[sig + 1]), float(daily[sym]["close"].iloc[sig + 2])
            g = (a_["status"] == "ok" and int(a_["entry_session"]) == 1 and int(a_["exit_session"]) == 2 and
                 abs(a_["net_bp"] - (c2 / o1 - 1 - 0.0035) * 1e4) < 1e-6)
        else:
            g = a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or
                                                         (np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"])))
        if not g:
            bad.append((t, rows[t]["lane"], cand.at[t, "rsj"], a_["status"], a_.get("exit_session")))
        ox_ok &= bool(g)
    check(rc == 0 and v_ok and cut_ok and ox_ok and n_ox >= 3 and sm["strategy"]["tree_open_exit"] == 2 and
          sm["strategy"]["variant"] == "OX" and sm["vol"]["voldir"]["used"],
          f"values at the pick by hand from the world's closes (RSJ10, the turnover ratio - blank before 130 bars - and "
          f"the 20-day return); the day's flags from voldir's cuts (RSJ tails, the market regime by day); open_exit: the "
          f"{n_ox} jumpy picks below the RSJ threshold are bought at the D1 open and sold at the 2nd close (net by hand), "
          f"every other pick trades as the frozen tree", (rc, v_ok, cut_ok, ox_ok, bad[:3], log[-400:]))
    # ---- veto_if: read at each tree buy's OWN signal close
    rc, log, d = bt(f"{sdir / 'vx.py'}#VT", ["--compare", str(tree_py)])
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    vt_ok, n_v, bad = True, 0, []
    differs = sum(1 for t in bday if bday[t] > 1 and (at_buy[t] < thr2) != (cand.at[t, "rsj"] < thr2))
    for t in cand.index:
        a_ = A.loc[t]
        if t in bday and at_buy[t] < thr2:
            n_v += 1
            g = a_["status"] == "not_entered" and "vetoed" in str(a_["note"]) and a_["status_compare"] in ("ok", "pending")
        else:
            g = a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or
                                                         (np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"])))
        if not g:
            bad.append((t, rows[t]["how"], at_buy.get(t), a_["status"], a_["note"]))
        vt_ok &= bool(g)
    rep = (d / "report.md").read_text(encoding="utf-8")
    check(rc == 0 and vt_ok and n_v >= 3 and differs >= 1 and "skips a buy when" in rep,
          f"veto_if is read at each tree buy's own signal close (the pick's close for the open, session k-1 for a "
          f"setup on Dk; {differs} setup buys would be judged differently at the pick's close): the {n_v} buys whose "
          f"RSJ10 there is below the threshold are not made (noted 'vetoed'), every other pick = the frozen tree",
          (rc, vt_ok, n_v, differs, bad[:3], log[-400:]))
    # ---- veto_if on the day's cuts; B1 sizing; the Calmar decision; p-values
    rc3, log3, d3 = bt(f"{sdir / 'vx.py'}#VC", ["--compare", str(tree_py)], nopf=True)
    A3 = pd.read_parquet(d3 / "trades.parquet").set_index("trade_id")
    def vc_hit(t):
        j = int(cand.at[t, "sig"]) + bday[t] - 1
        return rsj_h(cand.at[t, "symbol"], j) <= -0.30 or j % 2 == 1
    vc_n = sum(1 for t in bday if vc_hit(t))
    vc_ok = vc_n >= 3 and all(
        (A3.at[t, "status"] == "not_entered" and "vetoed" in str(A3.at[t, "note"])) if (t in bday and vc_hit(t)) else
        (A3.at[t, "status"] == A3.at[t, "status_compare"]) for t in cand.index)
    rcb, logb, db = bt(f"{LAB / 'strategies' / 'voldir.py'}#B1", ["--compare", str(tree_py)], vd=False)
    B = pd.read_parquet(db / "trades.parquet")
    smb = json.loads((db / "summary.json").read_text())
    bday_ = pd.to_datetime(B["signal_day"]).dt.normalize().to_numpy().astype("datetime64[D]").astype(np.int64)
    sv = B["pre_semivol20"].to_numpy(float)
    eng = B["engine"].astype(str).to_numpy()
    w_ok, n_w = True, 0
    for i in range(0, len(B), 9):
        win = sv[(eng == eng[i]) & (bday_ >= bday_[i] - 365) & (bday_ < bday_[i]) & np.isfinite(sv)]
        want = (min(1.5, np.median(win) / sv[i]) if len(win) >= 50 and np.isfinite(sv[i]) and sv[i] > 0 else 1.0)
        w_ok &= bool(abs(B["pre_semivol_w"].iloc[i] - want) < 1e-12)
        n_w += int(want != 1.0)
    pt = pd.read_csv(db / "portfolio_trades.csv")
    pdl = pd.read_csv(db / "portfolio_daily.csv")
    eqs = np.r_[500000.0, pdl["equity"].to_numpy(float)]
    pt = pt[pt["opened"]].merge(B[["trade_id", "pre_semivol_w"]], on="trade_id")
    size_ok = all(np.min(np.abs(eqs - 3 * tg / ww) / eqs) < 1e-9 for tg, ww in zip(pt["target_rupees"], pt["pre_semivol_w"]))
    sz = PF.Sizer({"rule": "expression", "expression": "equity / 3 * pre_semivol_w", "max_pct": 0.51},
                  SU.VOL_PICK_ATTRS)
    cap_ok = (abs(sz.target(300000, 300000, 0, {"pre_semivol_w": 1.2}, 0.03, np.nan) - 120000) < 1e-6 and
              abs(sz.target(300000, 300000, 0, {"pre_semivol_w": 1.6}, 0.03, np.nan) - 153000) < 1e-6)
    r_ = np.array([-0.01, 0.005, -0.02, 0.005, 0.03, -0.005])          # the first day a loss: the start is a peak
    eq = np.cumprod(1 + r_)
    dd_h = (eq / np.maximum.accumulate(np.r_[1.0, eq])[1:] - 1).min()
    cal_h = (eq[-1] ** (252 / 6) - 1) / abs(dd_h)
    dec = smb["decision"]
    cd = smb["portfolio"]["calmar"]
    rule = {"metric": "calmar_diff", "pass_if": "lower > 0", "money": "drawdown"}

    def pf0(lo_, dd_):
        return {"stats": {"calmar": {"diff": [0.3, lo_, 0.6], "p_one_sided": 0.01}, "daily_ret_diff_p": 0.2,
                          "strategy": {"cagr": 0.1, "max_drawdown": dd_[0]}, "compare": {"cagr": 0.2, "max_drawdown": dd_[1]}}}
    ev0 = {"summary": {"diff": [1.0, 0.5, 2.0], "strategy": [1.0, 0.5, 2.0]}}
    dk = (BT.decide(rule, ev0, pf0(0.1, (-0.2, -0.3)))["verdict"] == "PASS" and
          BT.decide(rule, ev0, pf0(0.1, (-0.35, -0.3)))["verdict"] == "FAIL" and
          BT.decide(rule, ev0, pf0(-0.1, (-0.2, -0.3)))["verdict"] == "FAIL" and
          BT.decide(rule, ev0, pf0(0.1, (-0.2, -0.3)))["p_one_sided"] == 0.01)
    want_v = "PASS" if (cd["diff"][1] > 0 and smb["portfolio"]["strategy"]["max_drawdown"] >=
                        smb["portfolio"]["compare"]["max_drawdown"]) else "FAIL"
    check(rc3 == 0 and vc_ok and rcb == 0 and w_ok and n_w >= 3 and size_ok and len(pt) > 10 and cap_ok and
          abs(float(BT.calmar_rows(r_)[0]) - cal_h) < 1e-12 and dk and dec["verdict"] == want_v and
          0 <= dec["p_one_sided"] <= 1 and 0 <= smb["portfolio"]["daily_ret_diff_p"] <= 1 and
          (smb["portfolio"]["daily_ret_diff_p"] < 0.5) == (smb["portfolio"]["daily_ret_diff_bp"][0] > 0) and
          abs(cd["strategy"] - float(BT.calmar_rows(np.nan_to_num(pd.read_csv(db / "portfolio_daily.csv")
                                                                  ["day_ret"].to_numpy(float)))[0])) < 1e-9,
          "a veto on the day's cuts (RSJ tail or the market regime at the buy's signal close) skips exactly those buys; "
          "B1 (strategies\\voldir.py#B1): pre_semivol_w by hand (the engine's median downside semideviation over the "
          "365 days before / the pick's, cap 1.5, 1 with fewer than 50), every position sized equity at the previous "
          "close / 3 x w (the 51% cap by hand); the Calmar ratio by hand; calmar_diff + drawdown PASS / FAIL flipped by "
          "hand and on the run's own numbers; one-sided p-values recorded",
          (rc3, vc_ok, rcb, w_ok, n_w, size_ok, cap_ok, dk, dec, logb[-400:]))
    # ---- variants, the shipped file, guards
    shipped = {k: E.Strategy(v, None, list(SU.VOL_PICK_ATTRS) + ["calm", "pre_sde10"]) for k, v in
               E.runpy.run_path(str(LAB / "strategies" / "voldir.py"))["STRATEGIES"].items()}
    s1 = E.load_strategy(f"{LAB / 'strategies' / 'voldir.py'}#B1", list(SU.VOL_PICK_ATTRS) + ["calm", "pre_sde10"])
    s2 = E.load_strategy(f"{LAB / 'strategies' / 'voldir.py'}#B2", list(SU.VOL_PICK_ATTRS) + ["calm", "pre_sde10"])

    def err(fn):
        try:
            fn()
            return ""
        except Exception as e:                       # noqa: BLE001
            return str(e)
    e1 = err(lambda: E.read_strategy(f"{LAB / 'strategies' / 'voldir.py'}#NOPE"))
    e2 = err(lambda: E.read_strategy(f"{tree_py}#B1"))
    e3 = err(lambda: E.read_strategy(LAB / "strategies" / "voldir.py"))

    def g_rc(text, vd=True):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)]
                     + (["--voldir", str(vrun)] if vd else []))
    tsrc = tree_py.read_text(encoding="utf-8")
    g1 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "open_exit": 2}],\n    "exits"'))
    g2 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "veto_if": "prob_big > 0.5"}],\n    "exits"'))
    g3 = g_rc('STRATEGY = {"name": "g3", "entries": [{"name": "o", "size": 1.0, "at": "open", "session": 1, '
              '"veto_if": "pre_lock3 == 1"}]}\n')
    g4 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "veto_if": "pre_rsj_lo == 1"}],\n    "exits"'),
              vd=False)
    g5 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "calm == 0", "open_exit": 0}],'
                                                             '\n    "exits"'))
    (vrun / "daily_cuts.parquet").write_bytes((vrun / "daily_cuts.parquet").read_bytes() + b"x")
    g6 = g_rc(tsrc)
    dd_ = pd.read_csv(d / "data_dictionary.csv")
    check(len(shipped) == 13 and s1.sha != s2.sha and s1.variant == "B1" and "has no strategy 'NOPE'" in e1 and
          "B1" in e1 and "has no strategy 'B1'" in e2 and "#NAME" in e3 and
          g1[0] == 2 and "needs open_if" in g1[1] and g2[0] == 2 and "volatility values" in g2[1] and g3[0] == 2 and
          "belongs to the tree entry" in g3[1] and g4[0] == 2 and "--voldir" in g4[1] and g5[0] == 2 and
          "open_exit must be" in g5[1] and g6[0] == 2 and "does not match" in g6[1] and
          not (dd_["meaning"] == "UNDOCUMENTED").any(),
          "strategies\\voldir.py: all 13 variants compile; '#B1' and '#B2' are different strategies in the ledger; an "
          "unknown variant, '#' on a single-strategy file and a many-strategy file without '#' are refused with the "
          "names; guards: open_exit without open_if or out of range, veto_if on a non-volatility value or off the tree "
          "entry, a day-cross-section flag without --voldir, a tampered daily_cuts; every new column documented",
          [x[1][-200:] for x in (g1, g2, g3, g4, g5, g6) if x[0] != 2] + [e1, e2, e3])


def fake_jm(run: Path, P: pd.DataFrame, jumpy: dict, seed: int = 3) -> Path:
    """jumplab's run folder: jm_scores.parquet for every pick of P (trade_id) with patterned values, hashed."""
    run.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    J = pd.DataFrame({"trade_id": P["trade_id"].astype(str).to_numpy()})
    J["jm_jumpy"] = [float(jumpy.get(t, np.nan)) for t in J["trade_id"]]
    n = len(J)
    J["jm_net"] = rng.normal(0, 0.02, n)
    J["jm_net_q"] = rng.uniform(0, 1, n)
    J["jm_dip"] = rng.uniform(0, 0.4, n)
    J["jm_dip_q"] = rng.uniform(0, 1, n)
    J["jm_rand"] = rng.uniform(0, 1, n)
    J["jm_up5"] = rng.uniform(0.2, 0.8, n)
    J["jm_deep"] = rng.uniform(0, 0.3, n)
    J["jm_mfe20"] = rng.uniform(0.0, 0.03, n)
    J["jm_mfe50"] = rng.uniform(0.01, 0.06, n)
    J["jm_mfe80"] = rng.uniform(0.05, 0.12, n)
    J["jm_mae20"] = -rng.uniform(0.03, 0.1, n)
    J["jm_mae50"] = -rng.uniform(0.01, 0.04, n)
    J.to_parquet(run / "jm_scores.parquet", index=False)
    (run / "run.json").write_text(json.dumps({"tool": "jumplab v1.0", "declaration_sha256": "e" * 64}), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'jm_scores.parquet')}  jm_scores.parquet\n", encoding="utf-8")
    return run


def run_jm(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:700]}")

    print("21. setups add-on v1.6: jumplab's scores - attached and hash-checked, open_untagged (ranks 4-10), veto_if on "
          "the scores, swing targets and trails on jm_* levels, guards")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "jm_world", "absent", seed=17, n_syms=14, n_days=200, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_backtest as BT
    import tl_engine as E
    import tl_setups as SU
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 30) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::5].head(36).set_index("trade_id")
    rows, tplan = {}, {}
    kinds = ["open", "S2@D3", "skip", "N1@D4", "skip", "C1@D2"]
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        lane = "CALM" if k == "open" else ("JUMPY" if i % 4 else "CALM")
        r = {"lane": lane, "how": "" if k == "skip" else k, "action": "x", "d1_net": 0.5, "setup_net": 0.25, "etf": False}
        if "@D" in k:
            sid, kk = k.split("@D")
            tplan[t] = {sid: int(kk)}
            r["first"] = k
        rows[t] = r
    base = TMP / "jm_out"
    fake_tags(base, P, tplan)
    fake_tree(base, P[P["rank"] <= 3], rows)                  # the tree covers ranks 1-3 only (TREE.json)
    # jumplab's lane: the tree's for its picks (rows, else JUMPY), alternating for ranks 4-10
    jumpy = {}
    for i, (t, rk) in enumerate(zip(P["trade_id"], P["rank"])):
        jumpy[t] = float(rows.get(t, {"lane": "JUMPY"})["lane"] == "JUMPY") if rk <= 3 else float(i % 2)
    jrun = fake_jm(TMP / "jl" / "runs" / "JL_20261112_001", P, jumpy)
    J = pd.read_parquet(jrun / "jm_scores.parquet").set_index("trade_id")
    sdir = TMP / "jm_strats"
    sdir.mkdir(exist_ok=True)
    tsrc = (LAB / "strategies" / "tree.py").read_text(encoding="utf-8")
    body = tsrc.split('"""', 2)[2]
    (sdir / "jx.py").write_text(
        "import copy\n" + body + "STRATEGIES = {}\n"
        "def v(n, ranks, **e):\n"
        "    s = copy.deepcopy(STRATEGY); s['name'] = n; s['picks']['ranks'] = ranks; s['entries'][0].update(e); return s\n"
        "STRATEGIES['JU'] = v('ju', list(range(1, 11)), open_if='jm_jumpy == 1 and jm_net_q >= 0.7', open_untagged=True)\n"
        "STRATEGIES['JN'] = v('jn', list(range(1, 11)), open_if='jm_jumpy == 1 and jm_net_q >= 0.7')\n"
        "STRATEGIES['JV'] = v('jv', [1, 2, 3], veto_if='jm_jumpy == 1 and jm_net_q <= 0.3')\n"
        "STRATEGIES['TP'] = v('tp', [1, 2, 3])\n"
        "STRATEGIES['TP']['exits'].append({'name': 'tp', 'type': 'target', "
        "'level': 'avg_entry * 1.05 if jm_up5 >= 0.5 else avg_entry * 1000'})\n"
        "STRATEGIES['TR'] = v('tr', [1, 2, 3])\n"
        "STRATEGIES['TR']['exits'].append({'name': 'trail', 'type': 'trail', 'pct': 0.03, "
        "'activate': 'mfe_sofar >= jm_mfe50'})\n", encoding="utf-8")
    out = TMP / "jm_bt"
    tree_py = LAB / "strategies" / "tree.py"

    def bt(strategy, jl=True, nopf=True, extra=()):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--compare", str(tree_py), "--context", "none", "--setups", str(base)] + list(extra) + \
            (["--jumplab", str(jrun)] if jl else []) + (["--no-portfolio"] if nopf else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_
    # ---- open_untagged: jumpy picks of ranks 4-10 (outside the tree) reached; without it they are not
    rc, log, d = bt(f"{sdir / 'jx.py'}#JU")
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    att_ok = all(np.allclose(A[k].to_numpy(float), J.loc[A.index, k].to_numpy(float), equal_nan=True) for k in SU.JM_ATTRS)
    ou_ok, n_u, n_t, bad = True, 0, 0, []
    sig_of = P.set_index("trade_id")["sig"]
    for t, a_ in A.iterrows():
        hit = J.at[t, "jm_jumpy"] == 1 and J.at[t, "jm_net_q"] >= 0.7
        in_tree = int(a_["rank"]) <= 3
        sig = int(sig_of[t])
        if sig + 10 >= len(days):                              # pending: past the data
            continue
        if hit:
            sym = a_["symbol"]
            o1, c5 = float(daily[sym]["open"].iloc[sig + 1]), float(daily[sym]["close"].iloc[sig + 5])
            g = a_["status"] in ("ok", "pending") and (a_["status"] == "pending" or (
                int(a_["entry_session"]) == 1 and int(a_["exit_session"]) == 5 and
                abs(a_["net_bp"] - (c5 / o1 - 1 - 0.0035) * 1e4) < 1e-6 or bool(a_["locked_exit"])))
            n_u += int(not in_tree)
            n_t += int(in_tree)
        elif not in_tree:
            g = a_["status"] == "not_entered" and a_["status_compare"] == "not_entered"
        else:                                                   # the frozen tree's own action
            g = a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or
                                                         (np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"])))
        if not g:
            bad.append((t, in_tree, hit, a_["status"], a_.get("entry_session"), a_.get("exit_session")))
        ou_ok &= bool(g)
    rcn, logn, dn = bt(f"{sdir / 'jx.py'}#JN")
    An = pd.read_parquet(dn / "trades.parquet").set_index("trade_id")
    outside = [t for t in An.index if int(An.at[t, "rank"]) > 3 and int(sig_of[t]) + 10 < len(days)]
    no_ou = len(outside) > 0 and all(An.at[t, "status"] == "not_entered" for t in outside)
    rep = (d / "report.md").read_text(encoding="utf-8")
    check(rc == 0 and att_ok and ou_ok and n_u >= 10 and n_t >= 2 and no_ou and sm["jumplab"]["used"] and
          sm["jumplab"]["lane_agree"] == sm["jumplab"]["lane_checked"] > 0 and "open_untagged" in rep and
          sm["strategy"]["tree_open_untagged"] is True,
          f"jumplab's scores attached to every pick (hash-checked run); open_untagged: {n_u} jumpy picks of ranks 4-10 "
          f"(outside the tree) and {n_t} jumpy tree picks with the meta in its top 30% bought at the D1 open and sold at "
          f"the 5th close (net by hand), every other pick = the frozen tree; without open_untagged no pick outside the "
          f"tree trades; the lane check (jumplab vs tree) agrees", (rc, att_ok, ou_ok, n_u, n_t, no_ou, bad[:3],
                                                                   sm.get("jumplab"), log[-300:]))
    # ---- veto_if on the scores
    rc, log, d = bt(f"{sdir / 'jx.py'}#JV")
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    vt_ok, n_v = True, 0
    for t in cand.index:
        a_ = A.loc[t]
        if rows[t]["how"] and J.at[t, "jm_jumpy"] == 1 and J.at[t, "jm_net_q"] <= 0.3:
            n_v += 1
            vt_ok &= bool(a_["status"] == "not_entered" and "vetoed" in str(a_["note"]))
        else:
            vt_ok &= bool(a_["status"] == a_["status_compare"])
    # ---- targets on jm levels: +5% when jm_up5 >= 0.5
    rc2, log2, d2 = bt(f"{sdir / 'jx.py'}#TP")
    A2 = pd.read_parquet(d2 / "trades.parquet").set_index("trade_id")
    tp_ok, n_tp = True, 0
    for t in cand.index:
        a_ = A2.loc[t]
        if a_["status"] != "ok":
            continue
        if str(a_["exit_reason"]).startswith("tp"):
            n_tp += 1
            lvl = float(a_["avg_entry"]) * 1.05
            tp_ok &= bool(J.at[t, "jm_up5"] >= 0.5 and float(a_["exit_price"]) >= lvl - 1e-6)
        elif J.at[t, "jm_up5"] < 0.5:
            tp_ok &= bool(abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9)
    # ---- a trail that starts only once the gain reaches jm_mfe50
    rc3, log3, d3 = bt(f"{sdir / 'jx.py'}#TR")
    A3 = pd.read_parquet(d3 / "trades.parquet").set_index("trade_id")
    tr_ok = all(float(A3.at[t, "mfe"]) >= float(J.at[t, "jm_mfe50"]) - 1e-9
                for t in A3.index if str(A3.at[t, "exit_reason"]).startswith("trail"))
    check(rc == 0 and vt_ok and n_v >= 1 and rc2 == 0 and tp_ok and n_tp >= 1 and rc3 == 0 and tr_ok,
          f"veto_if on jumplab's scores skips exactly the {n_v} tree buys of jumpy picks in the meta's bottom 30%; a +5% "
          f"target where jm_up5 >= 0.5 fired on {n_tp} trades (at or above the level), never where jm_up5 < 0.5 (those "
          f"= the frozen tree); a trail activated by jm_mfe50 never exits a trade whose best gain stayed below it",
          (rc, vt_ok, n_v, rc2, tp_ok, n_tp, rc3, tr_ok, log2[-300:]))
    # ---- guards and the shipped file
    shipped = {k: E.Strategy(v, None, list(SU.JM_ATTRS) + ["calm", "pre_sde10"]) for k, v in
               E.runpy.run_path(str(LAB / "strategies" / "jumplab.py"))["STRATEGIES"].items()}

    def g_rc(text, jl=True):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)]
                     + (["--jumplab", str(jrun)] if jl else []))
    g1 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "open_untagged": True}],\n    "exits"'))
    g2 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "jm_jumpy == 1", '
                                                             '"open_untagged": "yes"}],\n    "exits"'))
    g3 = g_rc(tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "jm_jumpy == 1"}],\n    "exits"'),
              jl=False)
    g4 = g_rc('STRATEGY = {"name": "g4", "entries": [{"name": "o", "size": 1.0, "at": "open", "session": 1, '
              '"open_untagged": True}]}\n')
    J2 = pd.read_parquet(jrun / "jm_scores.parquet")
    pd.concat([J2, J2.head(1)]).to_parquet(jrun / "jm_scores.parquet", index=False)
    (jrun / "outputs.sha256").write_text(f"{_sha(jrun / 'jm_scores.parquet')}  jm_scores.parquet\n", encoding="utf-8")
    g5 = g_rc(tsrc)
    (jrun / "jm_scores.parquet").write_bytes((jrun / "jm_scores.parquet").read_bytes() + b"x")
    g6 = g_rc(tsrc)
    dd_ = pd.read_csv(d / "data_dictionary.csv")
    check(len(shipped) == 16 and g1[0] == 2 and "needs open_if" in g1[1] and g2[0] == 2 and "true or false" in g2[1] and
          g3[0] == 2 and "--jumplab" in g3[1] and g4[0] == 2 and "belongs to the tree entry" in g4[1] and g5[0] == 2 and
          "appears twice" in g5[1] and g6[0] == 2 and "does not match" in g6[1] and
          not (dd_["meaning"] == "UNDOCUMENTED").any(),
          "strategies\\jumplab.py: all 16 variants compile; guards: open_untagged without open_if or not true / false, "
          "jm_* without --jumplab, open_untagged off the tree entry, a trade_id twice and a tampered jm_scores file "
          "are refused; every new column documented", [x[1][-200:] for x in (g1, g2, g3, g4, g5, g6) if x[0] != 2])


def fake_br(run: Path, P: pd.DataFrame, days: dict, tree_run: Path, extra: dict = None, calm=()) -> Path:
    """branchlab's run folder: br_scores.parquet for every pick of P (trade_id) - days = {variant: {trade_id: day}},
    extra = {column: {trade_id: value}}, calm = the tree's CALM picks (br_jumpy 0) - hashed, its run.json naming the
    tree run (tree_tags sha256)."""
    run.mkdir(parents=True, exist_ok=True)
    ids = P["trade_id"].astype(str).to_numpy()
    B = pd.DataFrame({"trade_id": ids})
    B["br_jumpy"] = [0.0 if t in set(calm) else 1.0 for t in ids]
    for v in TSU_BR_VARIANTS():
        d = days.get(v, {})
        B[f"br_{v}_day"] = [float(d.get(t, np.nan)) for t in ids]
    for c in ("br_E_OPEN", "br_E_OPEN_exit"):
        B[c] = [float((extra or {}).get(c, {}).get(t, np.nan)) for t in ids]
    for c, m in (extra or {}).items():
        if c not in ("br_E_OPEN", "br_E_OPEN_exit"):
            B[c] = [float(m.get(t, B.loc[i, c])) for i, t in enumerate(ids)]
    B.to_parquet(run / "br_scores.parquet", index=False)
    (run / "run.json").write_text(json.dumps({"tool": "branchlab v1.0", "declaration_sha256": "b" * 64,
                                              "tree_run": tree_run.name,
                                              "tree_run_sha256": _sha(tree_run / "tree_tags.parquet")}), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'br_scores.parquet')}  br_scores.parquet\n", encoding="utf-8")
    return run


def TSU_BR_VARIANTS():
    import tl_setups as SU
    return SU.BR_VARIANTS


def run_br(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:700]}")

    print("22. setups add-on v1.7: branchlab's days - attached, hash-checked and tied to the tree run; the tree entry's "
          "also_day ('first' / 'replace') by hand; the 24 shipped variants; guards")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "br_world", "absent", seed=19, n_syms=14, n_days=200, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_backtest as BT
    import tl_engine as E
    import tl_setups as SU
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 30) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::5].head(42).set_index("trade_id")
    kinds = ["open", "S2@D3", "skip", "N1@D4", "skip", "C1@D2", "etf"]
    first_day = {"open": 2, "S2@D3": 2, "skip": 3, "N1@D4": 4, "C1@D2": 5, "etf": 1}
    rows, tplan, kind_of, fday, rep_flag, rep_day, rep_exit = {}, {}, {}, {}, {}, {}, {}
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        skip2 = k == "skip" and (i // len(kinds)) % 2 == 1          # a skip with no day at all
        kind_of[t] = k + ("-none" if skip2 else "")
        r = {"lane": "CALM" if k == "open" else "JUMPY", "how": "" if k in ("skip", "etf") else k, "action": "x",
             "d1_net": 0.5, "setup_net": 0.25, "etf": k == "etf"}
        if "@D" in k:
            sid, kk = k.split("@D")
            tplan[t] = {sid: int(kk)}
            r["first"] = k
        rows[t] = r
        if not skip2:
            fday[t] = first_day[k]
        if k == "open":                       # replace: alternately re-planned to D3 / left unbought
            rep_flag[t] = 1.0
            if (i // len(kinds)) % 2 == 0:
                rep_day[t], rep_exit[t] = 3, 5
        elif k == "S2@D3":
            rep_flag[t], rep_day[t], rep_exit[t] = 1.0, 2, 6
        else:
            rep_flag[t] = 0.0
    base = TMP / "br_out"
    fake_tags(base, P, tplan)
    trun = fake_tree(base, P[P["rank"] <= 3], rows)
    calm = [t for t, r in rows.items() if r["lane"] == "CALM"]
    brun = fake_br(TMP / "bl" / "runs" / "BR_20261113_001", P, {"P_ALL": fday},
                   trun, {"br_E_OPEN": rep_flag, "br_E_OPEN_day": rep_day, "br_E_OPEN_exit": rep_exit}, calm)
    Bf = pd.read_parquet(brun / "br_scores.parquet").set_index("trade_id")
    out = TMP / "br_bt"
    tree_py = LAB / "strategies" / "tree.py"
    strat = LAB / "strategies" / "branchlab.py"

    def bt(strategy, bl=True, extra=(), compare=True):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--context", "none", "--setups", str(base), "--no-portfolio"] + \
            (["--compare", str(tree_py)] if compare else []) + list(extra) + (["--branchlab", str(brun)] if bl else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_

    def net(sym, sig, k_in, k_out):
        o_ = float(daily[sym]["open"].iloc[sig + k_in])
        c_ = float(daily[sym]["close"].iloc[sig + k_out])
        return (c_ / o_ - 1 - 0.0035) * 1e4

    sig_of = cand["sig"]
    # ---- 'first' (the shipped P_ALL)
    rc, log, d = bt(f"{strat}#P_ALL")
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    rep = (d / "report.md").read_text(encoding="utf-8")
    bad, n_new, n_early, n_kept = [], 0, 0, 0
    for t in cand.index:
        a_, k, sig, sym = A.loc[t], kind_of[t], int(sig_of[t]), cand.at[t, "symbol"]
        if k in ("skip", "S2@D3"):              # a new buy (skip, D3) or earlier than the tree's (D2 < D3): exit 5
            v = fday[t]
            ok = a_["status"] == "ok" and ((int(a_["entry_session"]) == v and int(a_["exit_session"]) == 5 and
                                             abs(a_["net_bp"] - net(sym, sig, v, 5)) < 1e-6) or bool(a_["locked_exit"]))
            n_new += int(k == "skip")
            n_early += int(k == "S2@D3")
        elif k == "etf":
            ok = a_["status"] == "not_entered"
        else:                                    # open (D1 < D2), N1@D4 (same day), C1@D2 (D5 later), skip-none
            ok = a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or (
                np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"])))
            n_kept += 1
        if not ok:
            bad.append((t, k, a_["status"], a_.get("entry_session"), a_.get("exit_session"), a_.get("note")))
    att = all(np.allclose(A[c].to_numpy(float), Bf.loc[A.index, c].to_numpy(float), equal_nan=True) for c in SU.BR_ATTRS)
    al = sm["branchlab"].get("also") or {}
    check(rc == 0 and not bad and n_new >= 3 and n_early >= 3 and n_kept >= 12 and att and sm["branchlab"]["used"] and
          sm["strategy"]["tree_also"]["day"] == "br_P_ALL_day" and "## branchlab days (BR1)" in rep and
          al.get("tree_skips", 0) >= 3 and al.get("before_tree", 0) >= 3 and al.get("same_day", 0) >= 3,
          f"also_day 'first' (strategies\\branchlab.py#P_ALL): {n_new} picks the tree skips bought on their day, "
          f"{n_early} bought before the tree's own setup buy (it never happens), both sold at the 5th close (nets from "
          f"the bars); the tree's buy stands on the same day, a later day and without a day ({n_kept} = the frozen "
          f"tree); an ETF never; the days attached to every pick; the report counts them",
          (rc, bad[:4], n_new, n_early, n_kept, att, al, log[-400:]))
    # ---- 'replace' (the shipped E_OPEN, here on D picks)
    rc2, log2, d2 = bt(f"{strat}#E_OPEN")
    A2 = pd.read_parquet(d2 / "trades.parquet").set_index("trade_id")
    bad2, n_re, n_none = [], 0, 0
    for t in cand.index:
        a_, k, sig, sym = A2.loc[t], kind_of[t], int(sig_of[t]), cand.at[t, "symbol"]
        if rep_flag.get(t) == 1 and t in rep_day:
            v, x = rep_day[t], rep_exit[t]
            ok = a_["status"] == "ok" and ((int(a_["entry_session"]) == v and int(a_["exit_session"]) == x and
                                             abs(a_["net_bp"] - net(sym, sig, v, x)) < 1e-6) or bool(a_["locked_exit"]))
            n_re += 1
        elif rep_flag.get(t) == 1:
            ok = a_["status"] == "not_entered" and a_["status_compare"] == "ok"
            n_none += 1
        else:
            ok = a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or (
                np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"])))
        if not ok:
            bad2.append((t, k, a_["status"], a_.get("entry_session"), a_.get("exit_session"), a_.get("note")))
    check(rc2 == 0 and not bad2 and n_re >= 6 and n_none >= 2,
          f"also_mode 'replace' (strategies\\branchlab.py#E_OPEN): where also_if holds the plan is replaced - {n_re} "
          f"picks bought on their day and sold at their own exit session (5 or 6), {n_none} D1-open buys left unbought "
          f"(no day); every other pick = the frozen tree", (rc2, bad2[:4], n_re, n_none, log2[-300:]))
    # ---- the shipped file and the guards
    shipped = {k: E.Strategy(v, None, list(SU.BR_ATTRS) + ["calm"]) for k, v in
               E.runpy.run_path(str(strat))["STRATEGIES"].items()}
    tsrc = tree_py.read_text(encoding="utf-8")
    sdir = TMP / "br_strats"
    sdir.mkdir(exist_ok=True)

    def g_rc(text, bl=True, run_=None):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)]
        return quiet(BT.main, args + (["--branchlab", str(run_ or brun)] if bl else []))

    def tree_with(extra):
        return tsrc.replace('"tree": True}],\n    "exits"', '"tree": True, ' + extra + '}],\n    "exits"')
    g1 = g_rc(tree_with('"also_day": "br_P_ALL_day"'), bl=False)
    g2 = g_rc(tree_with('"also_exit": 5'))
    g3 = g_rc(tree_with('"also_day": "br_P_ALL_day", "also_mode": "sometimes"'))
    g4 = g_rc(tree_with('"also_day": "br_E_OPEN_day", "also_mode": "replace"'))
    g5 = g_rc(tree_with('"also_day": "br_P_ALL_day", "open_if": "calm == 1"'))
    g6 = g_rc('STRATEGY = {"name": "g6", "entries": [{"name": "o", "size": 1.0, "at": "open", "session": 1, '
              '"also_day": "br_P_ALL_day"}]}\n')
    g7 = g_rc(tree_with('"also_day": "br_P_ALL_day", "also_if": "close > 10"'))
    # a run built from another tree run; a day outside 1..5; an exit before the day; a tampered file
    other = fake_br(TMP / "bl" / "runs" / "BR_20261113_002", P, {"P_ALL": fday}, trun, calm=calm)
    rj = json.loads((other / "run.json").read_text())
    rj["tree_run_sha256"] = "0" * 64
    (other / "run.json").write_text(json.dumps(rj), encoding="utf-8")
    g8 = g_rc(tree_with('"also_day": "br_P_ALL_day"'), run_=other)
    bad_day = fake_br(TMP / "bl" / "runs" / "BR_20261113_003", P, {"P_ALL": {t: 7 for t in fday}}, trun, calm=calm)
    g9 = g_rc(tree_with('"also_day": "br_P_ALL_day"'), run_=bad_day)
    ex_bad = fake_br(TMP / "bl" / "runs" / "BR_20261113_004", P, {}, trun,
                     {"br_E_OPEN": {t: 1.0 for t in cand.index}, "br_E_OPEN_day": {t: 4 for t in cand.index},
                      "br_E_OPEN_exit": {t: 2 for t in cand.index}}, calm)
    g10 = g_rc(tree_with('"also_day": "br_E_OPEN_day", "also_exit": "br_E_OPEN_exit", "also_mode": "replace", '
                         '"also_if": "br_E_OPEN == 1"'), run_=ex_bad)
    (other / "br_scores.parquet").write_bytes((other / "br_scores.parquet").read_bytes() + b"x")
    g11 = g_rc(tree_with('"also_day": "br_P_ALL_day"'), run_=other)
    g12 = g_rc(tree_with('"also_day": "pre_sde10"'))          # the engine's own check: not a watch day 1..5
    dd_ = pd.read_csv(d / "data_dictionary.csv")
    gs = (g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11, g12)
    want = ("--branchlab", "go with also_day", "also_mode must be", "needs also_if", "does not combine",
            "belongs to the tree entry", "pick attributes only", "rebuild it", "a day outside 1..5", "is not a session",
            "does not match", "not a watch day")
    miss = [(i + 1, w_, g[1][-220:]) for i, (g, w_) in enumerate(zip(gs, want)) if g[0] != 2 or w_ not in g[1]]
    check(len(shipped) == 24 and all(s_.tree_also is not None for s_ in shipped.values()) and not miss and
          not (dd_["meaning"] == "UNDOCUMENTED").any(),
          "strategies\\branchlab.py: all 24 variants compile; guards: br_* without --branchlab, also_* without "
          "also_day, a bad also_mode, 'replace' without also_if, also_day with open_if, also_* off the tree entry, "
          "also_if on a bar value, a run from another tree run, a day outside 1..5 (in the file and in the engine), "
          "an exit before the day and a tampered br_scores file are refused; every new column documented", miss)



def _why_rows(tn: list) -> list:
    """whylab's WHY csv rows for tonight's picks (planted values): D #3 has none (a row for another stock instead),
    D #10 has none."""
    out = []
    for x in tn:
        e, k, sy = x["engine"], int(x["rank"]), x["symbol"]
        if e == "D" and k in (3, 10):
            continue
        r = {"kind": "pick", "session": x["date"], "engine": e, "rank": k, "symbol": sy, "score": x["score"],
             "recorded_at": f"{x['date']}T21:50:00", "on_time": True,
             "why_d_lead": 1.0 + k / 10, "why_d_reason": ["trend", "volatility and jumpiness"][k % 2],
             "why_d_sure": ["CONFIDENT", "MIXED"][k % 2],
             "why_d_groups": f"trend +{0.5 + k / 100:.2f} (45%); other +0.30 (27%)",
             "why_d_up": f"D_ret_20 = {k}.25 (top 1.0%, +0.{k}0); D_rsi7 = 71 (top 9.5%, +0.20)",
             "why_d_down": "D_atr_pct = 3.1 (top 20.0%, -0.05)", "why_d_pct": 1 - k / 100,
             "why_d_reason_share": 45.0}
        if e == "ENS":
            r.update({"why": f"D {r['why_d_reason']} ({r['why_d_sure']}) · C A_reversal (MIXED)",
                      "why_inputs": f"D top {k}.0%: D_ret_20 = {k}.25 (top 1.0%, +0.{k}0) | C top 2.0%: C_resid_1d = "
                                    f"-0.0{k} (bottom 3.0%, +0.40)",
                      "why_ens": f"{x['score']:.4f} = 0.5 x 0.9900 (D) + 0.5 x 0.9800 (C)",
                      "why_c_lead": 0.8, "why_c_reason": "A_reversal", "why_c_sure": "MIXED",
                      "why_c_groups": "A_reversal +0.50 (62%); B_risk +0.20 (25%)",
                      "why_c_up": f"C_resid_1d = -0.0{k} (bottom 3.0%, +0.40)", "why_c_down": "",
                      "why_c_pct": 0.98, "why_c_reason_share": 62.0})
        else:
            r.update({"why": f"{r['why_d_reason']} ({r['why_d_sure']})", "why_inputs": r["why_d_up"], "why_ens": ""})
        out.append(r)
    return out


def _ledger(recs: list) -> str:
    """The why ledger as whylab writes it: each line = the record + prev, hash = sha256(prev + sorted json)."""
    prev, lines = "genesis", []
    for r in recs:
        r = dict(r, prev=prev)
        h = hashlib.sha256((prev + json.dumps(r, sort_keys=True, default=str)).encode("utf-8")).hexdigest()
        lines.append(json.dumps(dict(r, hash=h), sort_keys=True, default=str))
        prev = h
    return "\n".join(lines) + "\n"


def run_why(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:700]}")

    print("23. why add-on v1.0: whylab's why on the watch page (every D and ENS pick, the card's details, the open "
          "picks, the monitor) and the journal's WHY band (part P's run, the why ledger), by hand; guards")
    for k_ in ("SETUPLAB_OUT", "WHYLAB_OUT"):
        os.environ.pop(k_, None)
    import test_state as TST
    winfo = CW.make_ctx_world(TMP / "why_watch_world", "absent", 7, n_days=420)
    wroot = winfo["root"]
    fresh_modules(wroot)
    import tl_watch as WT
    import tl_dictionary as DD
    day_idx = 400
    planted = TST._write_planted(wroot, winfo["days"], day_idx)
    day = TST._paper(wroot, winfo, day_idx, planted)
    ymd = f"{day:%Y%m%d}"
    L = [json.loads(x) for x in (wroot / "paper" / "ledger.jsonl").read_text().splitlines() if x.startswith("{")]
    tn = [x for x in L if x["date"] == f"{day:%Y-%m-%d}"]
    older = sorted({x["date"] for x in L if x["date"] < f"{day:%Y-%m-%d}"})
    rows = _why_rows(tn)
    rows.append(dict(rows[0], rank=3, symbol="NOTIT", why="WRONG STOCK (CONFIDENT)"))
    o1 = next(x for x in L if x["date"] == older[-1] and x["engine"] == "D" and int(x["rank"]) == 1)
    o2 = next(x for x in L if x["date"] == older[-2] and x["engine"] == "ENS" and int(x["rank"]) == 2)
    o3 = next(x for x in L if x["date"] == older[-1] and x["engine"] == "D" and int(x["rank"]) == 2)
    held = [{"kind": "held", "session": o1["date"], "engine": "D", "rank": 1, "symbol": o1["symbol"], "day_now": 1,
             "why_d_reason": "trend", "why_d_reason_push": 0.45, "why_d_status": "STILL THERE", "why_d_push_now": 0.3},
            {"kind": "held", "session": o2["date"], "engine": "ENS", "rank": 2, "symbol": o2["symbol"], "day_now": 2,
             "why_d_reason": "trend", "why_d_reason_push": 0.5, "why_d_status": "GONE", "why_d_push_now": -0.12,
             "why_c_reason": "A_reversal", "why_c_reason_push": 0.4, "why_c_status": "STILL THERE",
             "why_c_push_now": 0.22},
            {"kind": "held", "session": o3["date"], "engine": "D", "rank": 2, "symbol": o3["symbol"], "day_now": 1,
             "why_d_status": "NOT RECORDED"}]
    wbase = TMP / "why_out"
    (wbase / "why").mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows + held).to_csv(wbase / "why" / f"WHY_{ymd}.csv", index=False)
    pd.DataFrame([{"engine": "D", "half": "D", "group": "trend", "sessions": 20, "picks": 6, "share_last": 0.5,
                   "share_2020_26": 0.4, "picks_2020_26": 4965},
                  {"engine": "D", "half": "D", "group": "calendar", "sessions": 20, "picks": 6, "share_last": 0.0,
                   "share_2020_26": 0.0, "picks_2020_26": 4965},
                  {"engine": "ENS", "half": "C's half", "group": "A_reversal", "sessions": 20, "picks": 6,
                   "share_last": 0.6667}]).to_csv(wbase / "why" / "why_monitor.csv", index=False)
    # Windows matches WHY_*.csv without case, so it also finds why_monitor.csv: a file that sorts after every night
    # stands in for that here (it must not make tonight look older than it is)
    (wbase / "why" / "WHY_monitor_extra.csv").write_text("kind\n", encoding="utf-8")
    wout = TMP / "why_watch_out"
    rc, log = quiet(WT.main, ["--root", str(wroot), "--out", str(wout), "--stage-e-any", "--why", str(wbase)])
    R = pd.read_csv(wout / "watch" / f"WATCH_{ymd}.csv")
    md = (wout / "watch" / f"WATCH_{ymd}.md").read_text(encoding="utf-8")
    H = (wout / "watch" / f"WATCH_{ymd}.html").read_text(encoding="utf-8")
    want = {(r["engine"], int(r["rank"]), r["symbol"]): r for r in rows if r["symbol"] != "NOTIT"}
    ok, bad = rc == 0, []
    for x in R.to_dict("records"):
        w = want.get((x["engine"], int(x["rank"]), x["symbol"]))
        got = {c: ("" if pd.isna(x.get(c)) else x.get(c)) for c in ("why", "why_inputs", "why_ens", "why_d_reason",
                                                                     "why_c_reason", "why_d_up", "why_d_down")}
        if w is None:
            ok &= all(v == "" for v in got.values()) and pd.isna(x.get("why_d_lead"))
            continue
        exp = {c: (w.get(c) or "") for c in got}
        ok &= got == exp and abs(float(x["why_d_lead"]) - w["why_d_lead"]) < 1e-12 and bool(x["why_on_time"])
        if got != exp:
            bad.append((x["engine"], x["rank"], got, exp))
    n_why = int(R["why"].fillna("").ne("").sum())
    r1 = want[("D", 1, next(x["symbol"] for x in tn if x["engine"] == "D" and int(x["rank"]) == 1))]
    e1 = next(r for r in rows if r["engine"] == "ENS" and r["rank"] == 1)
    sec = md.split("## Why each pick was picked (whylab)")[1].split("## Stock cards")[0] if \
        "## Why each pick was picked (whylab)" in md else ""
    card_ok = (f"**Why D #1 picked it** (whylab; {WT.WHY_INFO}): {r1['why']}" in md and
               f"- D.pkl: lead {r1['why_d_lead']:+.2f} points over 100 other stocks; groups {r1['why_d_groups']}" in md
               and f"  - pushed it down: {r1['why_d_down']}" in md and f"; ENS {e1['why_ens']}" in md and
               "- C.pkl: lead +0.80 points over 100 other stocks; groups A_reversal +0.50 (62%); B_risk +0.20 (25%)"
               in md and "  - pushed it down: -" in md)
    held_ok = (f"- D #1 **{o1['symbol']}** (picked {o1['date']}, D1 tonight): D trend +0.45 then -> STILL THERE "
               f"(+0.30 now)" in sec and
               f"- ENS #2 **{o2['symbol']}** (picked {o2['date']}, D2 tonight): D trend +0.50 then -> GONE (-0.12 now); "
               f"C A_reversal +0.40 then -> STILL THERE (+0.22 now)" in sec and
               f"- D #2 **{o3['symbol']}** (picked {o3['date']}, D1 tonight): D: no why record" in sec)
    mon_ok = ("| D | D | trend | 50% of 6 | 40% of 4,965 |" in sec and "| ENS | C's half | A_reversal | 67% of 6 | - |"
              in sec and "calendar" not in sec)
    row_ok = (f"| {r1['why']}: {r1['why_inputs']} |" in md and "WRONG STOCK" not in md + H and
              "why: leading reason &middot; top inputs" in H and "Why it was picked (whylab, information only)" in H)
    check(ok and n_why == len(want) and card_ok and row_ok and "recorded ON TIME" in sec and
          "Information only - it explains a pick" in sec and held_ok and mon_ok and
          f"WHY_{ymd}.csv (SHA-256 " in sec and not DD.undocumented("watch", list(R.columns)),
          f"the watch page: every D and ENS pick with a why row shows its leading reason and top inputs exactly as "
          f"whylab wrote them ({len(want)} of {len(R)}; D #3 and #10 blank - a row for another stock is never joined); "
          f"each card holds the lead, the groups' shares and the inputs that pushed it down (ENS: both halves and "
          f"its formula); the open picks' reasons at tonight's close (STILL THERE / GONE / no record); the monitor "
          f"(groups never seen left out); ON TIME; information only; every column documented",
          (rc, n_why, len(want), bad[:2], card_ok, row_ok, held_ok, mon_ok, sec[:900]))
    # LATE, a missing file, no folder at all
    W2 = pd.read_csv(wbase / "why" / f"WHY_{ymd}.csv")
    W2.loc[W2["kind"] == "pick", "on_time"] = False
    W2.to_csv(wbase / "why" / f"WHY_{ymd}.csv", index=False)
    rc2, _ = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "why_watch_out2"), "--stage-e-any", "--why",
                             str(wbase)])
    md2 = (TMP / "why_watch_out2" / "watch" / f"WATCH_{ymd}.md").read_text(encoding="utf-8")
    rc3, _ = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "why_watch_out3"), "--stage-e-any", "--why",
                             str(TMP / "why_none")])
    md3 = (TMP / "why_watch_out3" / "watch" / f"WATCH_{ymd}.md").read_text(encoding="utf-8")
    R3 = pd.read_csv(TMP / "why_watch_out3" / "watch" / f"WATCH_{ymd}.csv")
    rc4, _ = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "why_watch_out4"), "--stage-e-any"])
    md4 = (TMP / "why_watch_out4" / "watch" / f"WATCH_{ymd}.md").read_text(encoding="utf-8")
    od_ = older[-1]
    tn_o = [x for x in L if x["date"] == od_]
    pd.DataFrame(_why_rows(tn_o)).to_csv(wbase / "why" / f"WHY_{od_.replace('-', '')}.csv", index=False)
    rc5, _ = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "why_watch_out5"), "--stage-e-any", "--why",
                             str(wbase), "--date", od_])
    md5 = (TMP / "why_watch_out5" / "watch" / f"WATCH_{od_.replace('-', '')}.md").read_text(encoding="utf-8")
    R5 = pd.read_csv(TMP / "why_watch_out5" / "watch" / f"WATCH_{od_.replace('-', '')}.csv")
    check(rc2 == 0 and "recorded LATE - not forward evidence" in md2 and rc3 == 0 and
          f"Why: no WHY_{ymd}.csv in " in md3 and "(whylab why runs before this page)" in md3 and
          R3["why"].fillna("").eq("").all() and rc4 == 0 and "Why: no --why and no WHYLAB_OUT." in md4 and
          rc5 == 0 and f"WHY_{od_.replace('-', '')}.csv" in md5 and "### Monitor" not in md5 and
          int(R5["why"].fillna("").ne("").sum()) == len(_why_rows(tn_o)),
          "the watch page: a why recorded after the deadline reads LATE - not forward evidence; without tonight's "
          "WHY file, or without --why / WHYLAB_OUT, the page says so and the why columns are blank; an earlier day's "
          "page reads that day's own file and leaves the monitor (tonight's) out")

    # ---- the journal's WHY band: part P's run (D's ranks 1-3 before the paper test) and the why ledger
    import tl_journal as J
    from openpyxl import load_workbook
    ex = TMP / "why_j" / "export" / "TLX_TEST_001"
    T = J._synthetic_export(ex, seed=11)
    T["score"] = 0.01 + 0.0001 * np.arange(len(T))
    T.to_parquet(ex / "trades.parquet", index=False)
    hl = [ln for ln in (ex / "outputs.sha256").read_text(encoding="utf-8").splitlines() if "trades.parquet" not in ln]
    hl.append(f"{hashlib.sha256((ex / 'trades.parquet').read_bytes()).hexdigest()}  trades.parquet")
    (ex / "outputs.sha256").write_text("\n".join(hl) + "\n", encoding="utf-8")
    Dt = T[(T["engine"] == "D") & T["traded"]].sort_values(["signal_day", "rank"]).reset_index(drop=True)
    Et = T[(T["engine"] == "ENS") & T["traded"]].sort_values(["signal_day", "rank"]).reset_index(drop=True)
    p1, p2, p3, p5 = Dt.iloc[0], Dt.iloc[1], Dt.iloc[2], Dt.iloc[3]
    p4 = Et.iloc[0]
    jb = TMP / "why_j_out"
    prun = jb / "explain" / "P_20261113_001"
    prun.mkdir(parents=True, exist_ok=True)
    groups = ["trend", "volatility and jumpiness", "other"]

    def prow(t, score, reason, conf, pushes):
        r = {"day": f"{t['signal_day']:%Y-%m-%d}", "symbol": t["symbol"], "fold": 1, "rank": int(t["rank"]),
             "score": score, "reason": reason, "v1_top": reason, "v2_top": "other", "confident": conf,
             "category": "MIXED", "second": "other", "period": "P1"}
        r.update({f"push_{g}": v for g, v in zip(groups, pushes)})
        r.update({"push_reason_D1": 9.0, "st_1": 1, "top_1": "trend"})      # not a group: never in the lead
        return r
    PP_ = pd.DataFrame([prow(p1, float(p1["score"]), "trend", True, [0.6, 0.2, 0.2]),
                        prow(p2, float(p2["score"]), "volatility and jumpiness", False, [0.1, 0.5, -0.1]),
                        prow(p3, float(p3["score"]) + 0.002, "trend", True, [0.7, 0.1, 0.1])])
    RS_ = []
    for t in (p1, p2, p3):
        for place, (inp, val, pct, push) in zip((3, 1, 5, 2, 4), [("D_rsi7", 71.0, 0.95, 0.10),
                                                                  ("D_ret_20", 12.5, 0.99, 0.30),
                                                                  ("D_gap", 0.01, 0.60, 0.01),
                                                                  ("D_atr_pct", 3.25, 0.20, 0.2),
                                                                  ("D_obv", 5.0, 0.70, 0.05)]):
            RS_.append({"day": f"{t['signal_day']:%Y-%m-%d}", "symbol": t["symbol"], "place": place, "input": inp,
                        "group": "trend", "push": push, "value": val, "day_percentile": pct})
    PP_.to_csv(prun / "picks.csv", index=False)
    pd.DataFrame(RS_).to_csv(prun / "reasons.csv", index=False)
    (prun / "run.json").write_text(json.dumps({"declaration_sha256": "p" * 64, "stopped": False}), encoding="utf-8")
    (prun / "outputs.sha256").write_text("".join(f"{hashlib.sha256((prun / n).read_bytes()).hexdigest()}  {n}\n"
                                                 for n in ("picks.csv", "reasons.csv", "run.json")), encoding="utf-8")
    dh = {"lead": 1.5, "reason": "trend", "tops": ["trend"] * 3, "sure": "CONFIDENT",
          "groups": [["trend", 0.9], ["other", 0.6]], "up": [["D_ret_20", 12.5, 0.99, 0.7], ["D_rsi7", 71.0, 0.25, 0.2]],
          "down": [["D_atr_pct", 3.1, 0.8, -0.1]]}
    ch = {"lead": 0.8, "reason": "A_reversal", "tops": ["A_reversal", "B_risk", "A_reversal"], "sure": "MIXED",
          "groups": [["A_reversal", 0.5], ["B_risk", 0.3]], "up": [["C_resid_1d", -0.05, 0.03, 0.4]], "down": []}
    led = [{"session": f"{p4['signal_day']:%Y-%m-%d}", "engine": "ENS", "rank": int(p4["rank"]), "symbol": p4["symbol"],
            "score": float(p4["score"]), "d_pct": 0.99, "c_pct": 0.97, "d": dh, "c": ch, "on_time": True},
           {"session": f"{p5['signal_day']:%Y-%m-%d}", "engine": "D", "rank": int(p5["rank"]), "symbol": p5["symbol"],
            "score": float(p5["score"]), "d_pct": 0.995, "d": dh, "on_time": False}]
    (jb / "why").mkdir(parents=True, exist_ok=True)
    (jb / "why" / "why_ledger.jsonl").write_text(_ledger(led), encoding="utf-8")
    quiet(J.build, ex, False, "J_why.xlsx", lambda m: None, None, str(jb))
    wb = load_workbook(ex / "J_why.xlsx", read_only=True)
    rows_x = list(wb["Trades"].iter_rows(values_only=True))
    hdr = next(r_ for r_ in rows_x if r_ and "Symbol" in r_)
    body = rows_x[rows_x.index(hdr) + 1:]
    ix = {h: hdr.index(h) for h in ("Engine", "Symbol", "Pick day", "Why", "Lead", "Reason share", "Top inputs",
                                    "Why source") if h in hdr}
    got = {}
    for r_ in body if len(ix) == 8 else []:
        if r_ and r_[ix["Why"]]:
            got[(f"{pd.Timestamp(r_[ix['Pick day']]):%Y-%m-%d}", r_[ix["Engine"]], r_[ix["Symbol"]])] = r_
    k = (lambda t: (f"{t['signal_day']:%Y-%m-%d}", t["engine"], t["symbol"]))
    ins = "D_ret_20 = 12.5 (top 1.0%, +0.30); D_atr_pct = 3.25 (bottom 20.0%, +0.20); D_rsi7 = 71 (top 5.0%, +0.10)"
    g1, g2, g4, g5 = got.get(k(p1)), got.get(k(p2)), got.get(k(p4)), got.get(k(p5))
    readme = " ".join(str(c) for r_ in wb["Read me"].iter_rows(values_only=True) for c in r_ if c)
    j_ok = (len(got) == 4 and k(p3) not in got and g1 is not None and g2 is not None and g4 is not None and
            g5 is not None and g1[ix["Why"]] == "trend (CONFIDENT)" and abs(g1[ix["Lead"]] - 1.0) < 1e-12 and
            abs(g1[ix["Reason share"]] - 0.6) < 1e-12 and g1[ix["Top inputs"]] == ins and
            g1[ix["Why source"]] == "part P P_20261113_001 (walk-forward model)" and
            g2[ix["Why"]] == "volatility and jumpiness (MIXED)" and abs(g2[ix["Lead"]] - 0.5) < 1e-12 and
            abs(g2[ix["Reason share"]] - 1.0) < 1e-12 and
            g4[ix["Why"]] == "D trend (CONFIDENT) · C A_reversal (MIXED)" and g4[ix["Lead"]] is None and
            g4[ix["Top inputs"]] == (f"ENS {float(p4['score']):.4f} = 0.5 x 0.9900 (D) + 0.5 x 0.9700 (C) | D lead "
                                     f"+1.50, trend 60%: D_ret_20 = 12.5 (top 1.0%, +0.70); D_rsi7 = 71 (bottom 25.0%, "
                                     f"+0.20) | C lead +0.80, A_reversal 62%: C_resid_1d = -0.05 (bottom 3.0%, +0.40)")
            and g4[ix["Why source"]] == "why ledger, ON TIME" and g5[ix["Why source"]] == "why ledger, LATE" and
            abs(g5[ix["Reason share"]] - 0.6) < 1e-12 and "4 of these" in readme and
            "1 left blank: the export's score differs" in readme)
    check(j_ok, "the journal: a WHY band - part P's picks (lead = the sum of the group pushes, the reason's share, the "
                "top 3 inputs in place order, CONFIDENT / MIXED) and the why ledger's (ENS: its formula and both "
                "halves by their own models; ON TIME / LATE); a pick the export scored differently is left blank and "
                "counted in the Read me", (len(got), sorted(got)[:5], g1, g4, readme[-600:]))
    # guards: a changed part P output, an edited ledger line
    import shutil as _sh
    jb2 = TMP / "why_j_out2"
    _sh.copytree(jb, jb2)
    with open(jb2 / "explain" / "P_20261113_001" / "picks.csv", "a", encoding="utf-8") as f:
        f.write("\n")
    e1_ = None
    try:
        J.build(ex, False, "J_g1.xlsx", lambda m: None, None, str(jb2))
    except J.TLError as e:
        e1_ = str(e)
    jb3 = TMP / "why_j_out3"
    _sh.copytree(jb, jb3)
    ln = (jb3 / "why" / "why_ledger.jsonl").read_text(encoding="utf-8").splitlines()
    ln[0] = ln[0].replace('"on_time": true', '"on_time": false')
    (jb3 / "why" / "why_ledger.jsonl").write_text("\n".join(ln) + "\n", encoding="utf-8")
    e2_ = None
    try:
        J.build(ex, False, "J_g2.xlsx", lambda m: None, None, str(jb3))
    except J.TLError as e:
        e2_ = str(e)
    J.build(ex, False, "J_none.xlsx", lambda m: None, None, str(TMP / "why_j_none"))
    hn = next(r_ for r_ in load_workbook(ex / "J_none.xlsx", read_only=True)["Trades"].iter_rows(values_only=True)
              if r_ and "Symbol" in r_)
    check(e1_ is not None and "does not match its outputs.sha256" in e1_ and e2_ is not None and
          "edited, reordered or cut" in e2_ and "Why" not in hn,
          "the journal's guards: a part P output changed after its run and an edited why-ledger line are refused; "
          "without whylab's outputs there is no WHY band", (e1_, e2_))
