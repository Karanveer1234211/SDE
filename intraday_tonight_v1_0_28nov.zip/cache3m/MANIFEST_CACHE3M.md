# MANIFEST - cache3m v1.0.1 (28 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\cache3m\` (new; beside tradelab). Nothing goes into bigmove_deploy.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `cache3m.py` | `dbce2487ddf84a0d` | 83796 |
| `cache3m_daily.bat` | `2294174a8efd4b4c` | 348 |
| `tests\test_cache3m.py` | `e9840cd11d1da640` | 27423 |
| `tests\c3_world.py` | `5fd9b0ca49bf62d0` | 18761 |
| `README_CACHE3M.md` | `94804c0bd0bb6c1b` | 6743 |
| `MANIFEST_CACHE3M.md` | (this file) | |

## Verified

- `python tests\test_cache3m.py`: VERIFIED (cache3m v1.0.1) - 59 checks, on pandas 2.3.3 / numpy 2.4.1 / pyarrow 26.0.1
  (Karan's set) and pandas 3.0.5 / numpy 2.5.3 / pyarrow 26.0.0; also with a production intraday_cache that raises on
  import placed on PYTHONPATH and CACHE_DAILY_ROOT / INSTRUMENT_CACHE_FILE / CACHE_HISTORY_ANCHOR / KITE_TOKEN_FILE set
  (the test never sees production or the real cache).
- Mutation test: 36 deliberate bugs (tail overlap, re-basing, 100-day limit, vendor gaps, cut-short sessions, basis
  judgement, history start, conventions, volume / adj_factor, the clock, NIFTY look-ahead, index names, unresolved
  memory, merge order, newest-first order, STALE, archives, fingerprints, token errors, thresholds, --symbols,
  unreadable files): all 36 caught. v1.0.1: 3 more (no lock taken, the lock not let go at the end, v1.0's file-age lock that a killed run left blocking): all 3 caught.
- Scale: an 11-year file (386,750 bars) costs 0.25 s of work per evening update on one core (0.16 s with 6 workers);
  Kite's limit is 0.33 s a request, so the evening run is Kite-bound.

## Production contact

- Reads: the daily cache (`*_daily.parquet`, `*_daily.ok.json`, `instrument_cache.json`), read only; production's
  `intraday_cache` (`store`, `path_for`, `BAR_MIN`), imported read only.
- Writes: `<store>\<NAME>_3m.parquet` (the 3-minute store production reads) and `<store>\_cache3m\` only.
- Alters existing bars only (a) when Kite re-based a series (whole file archived first) or (b) to put Kite's
  unadjusted history on the daily cache's basis (rows archived first; adj_factor column), and (c) the last 2 cached
  sessions take Kite's corrections.

## History

- v1.0 (23 Nov 2026): first version.
- v1.0.1 (28 Nov 2026): the run lock is the operating system's lock on `_cache3m\run.lock`, held while the run lasts. In v1.0 a run killed by closing its window or shutting the PC down left the file behind and blocked the next run for 24 hours (the nightly intraday step would have skipped a night). cache3m.py's RunLock and two checks in tests\test_cache3m.py; nothing else changed.
