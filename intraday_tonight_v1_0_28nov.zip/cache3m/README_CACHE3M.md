# cache3m v1.0.1 — the 3-minute bar cache

Kite's 3-minute candles for every NSE stock and index the daily cache holds (futures excluded), from 2015-01-01 (the
history anchor) to the last completed session, kept current every evening. It maintains production's own 3-minute
store — `intraday_cache.store(root)`, i.e. `C:\QuantData\cache_daily\intraday_3m\` — so stage E, tradelab and
triggerlab read the same files they read today: `<SYMBOL>_3m.parquet`, columns `timestamp open high low close
volume`, a bar stamped with its start (09:15 + 3k IST, 125 a normal session).

## Files (copy all into `C:\Users\karanvsi\PyCharmMiscProject\cache3m\`)

| file | what |
|---|---|
| `cache3m.py` | the tool: `inspect`, `update`, `verify` |
| `cache3m_daily.bat` | the evening update (CRLF), for a double-click or Task Scheduler |
| `tests\test_cache3m.py` | 58 checks on a synthetic world — run once after copying |
| `tests\c3_world.py` | the test world (a fake Kite, a synthetic daily cache) |
| `README_CACHE3M.md`, `MANIFEST_CACHE3M.md` | this file, checksums |

Nothing goes into `bigmove_deploy`. Production's `intraday_cache.py` is imported read only (for `store` and
`path_for`) and never changed.

## First run

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\cache3m
python tests\test_cache3m.py
python cache3m.py inspect
python cache3m.py update --check-only
python cache3m.py update --max-hours 9
```

1. The test must end `VERIFIED (cache3m v1.0.1) - 59 checks`.
2. `inspect` (read only) prints what the store holds: files, series behind, sessions missing, and how many requests
   the backlog needs (at 3 a second) — and how many of those bring every series up to date.
3. `update --check-only` prints the plan; nothing is fetched or written.
4. `update` fetches. Newest first: NIFTY, then every series brought up to date (about 2 requests a series, roughly
   25 minutes for ~2,300), then older history a year at a time, newest year first. `--max-hours 9` stops cleanly
   after 9 hours; run the same command again to continue. Ctrl+C or an expired token loses at most the series in
   flight.

## Every evening (after the daily cache)

```
C:\Users\karanvsi\PyCharmMiscProject\cache3m\cache3m_daily.bat
```

About one request a stock: ~13 minutes for ~2,300 series (Kite's 3-a-second limit; the file work keeps up). A second
run the same evening makes no request. If the daily cache has not run yet, cache3m still fetches today: NIFTY looks
past its daily bars on weekdays, and every active series follows NIFTY's sessions.

## What it guarantees

- **Nothing provisional**: today counts only after 15:45 (close + 15 minutes).
- **Gaps measured against the daily cache**: every session the daily cache says a series traded is fetched. A
  session Kite has no 3-minute bars for (a *vendor gap*) is recorded once and not asked again
  (`--recheck-gaps` asks again). A session cut short (fetched during market hours: under half the usual bars and
  ending an hour or more before NIFTY) is fetched once more.
- **Corporate actions**: every fetch re-reads the last 2 cached sessions. If their closes come back on one new
  ratio, Kite re-based the history (split, bonus, extraordinary dividend): the whole series is fetched again and the
  old file archived.
- **The daily cache's basis**: 3 or more consecutive sessions sitting on one ratio *k* to the daily bars are judged
  at the session after them. If the 3-minute bars jump there and the daily bars do not, Kite served that history
  unadjusted (common before 2019): prices × *k*, volume ÷ *k*, and an `adj_factor` column records it (Kite's raw
  price = price / adj_factor); the rows as they were are archived. If the *daily* bars jump instead (the daily cache
  missed a corporate action), Kite's bars are left alone and the report prints a NOTE. Anything else off the daily
  bar is reported, never altered.
- **Each file keeps its own conventions** (tz-aware or naive timestamps, integer or float volume, extra columns).
  New files: tz-aware IST. Indices: new files take Kite's name (`NIFTY 50_3m.parquet`, which tradelab reads); an index
  file already under its cache name (`NIFTYBANK_3m.parquet`) stays there. Index volume: NaN (an index file already
  holding zeros keeps zeros).
- **Same instrument as the daily bars**: tokens come from the daily cache's own `instrument_cache.json` first, then
  Kite's NSE list. A series with neither (delisted) is recorded *unresolved* and not asked again.
- **Kite's 3-minute history starts where NIFTY's does**: when NIFTY has no bars before some date, no stock is asked
  for earlier sessions.
- **Atomic writes**; one update per store at a time: the operating system's lock on `_cache3m\run.lock`, held while the run lasts (v1.0.1) - a run killed by closing its window or shutting the PC down never blocks the next one.

## The store's bookkeeping — `intraday_3m\_cache3m\`

| file | what |
|---|---|
| `coverage_report.json` | the last update: requests, new sessions, stale / missing / failed / unresolved series, notes |
| `catalog.json` | every series → its file, kind, first / last session, sessions, gaps (for other tools) |
| `runs.jsonl` | one line per update |
| `symbols\<NAME>.json` | per series: token, vendor gaps, cut-short sessions checked, adjustments, re-basings |
| `replaced\` | archived files (`<NAME>_<time>_rebased.parquet`) and rows (`..._basis.parquet`) |
| `verify_report.json` | the last `verify` |

## Reading the report

```
  sessions      : expected, present, missing, vendor gaps
  STALE         : active series still missing their latest sessions (rerun; exit code 2)
  FAILED        : series that errored after two second chances (exit code 2)
  unresolved    : no token anywhere (delisted / renamed) - not asked again
  NOTE <NAME>   : a basis block left as Kite prints it, and why
```

Exit codes: 0 done · 2 done but something failed or is behind · 3 refused (nothing written) · 4 Kite token expired
(refresh with Kiteconnect.py, rerun) · 5 stopped by `--max-hours` or Ctrl+C (rerun to continue).

## Options

`--root` (default `%CACHE_DAILY_ROOT%`; no silent default) · `--store` (a folder instead of production's) ·
`--from` (default `CACHE_HISTORY_ANCHOR`, else 2015-01-01) · `--symbols A B ...` / `--symbols-file` (NIFTY50 always
comes along) · `--workers 6` · `--rate 3` · `--max-hours` · `--check-only` · `--recheck-gaps` · `--out` (inspect: also
write `cache3m_inspect.json`).

`verify` reads every bar (read only, ~10 minutes for the full store): the 09:15 + 3k grid, duplicates, OHLC faults,
missing prices, sessions under 80% of 125 bars, sessions on / off their daily bar, basis blocks left.
