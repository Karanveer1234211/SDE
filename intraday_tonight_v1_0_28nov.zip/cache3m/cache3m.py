#!/usr/bin/env python3
"""
cache3m.py - cache3m v1.0: Kite's 3-minute bars for every NSE stock and index in the daily cache.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\cache3m
    python cache3m.py inspect                  read only: what the store holds, what is missing, how long to fill
    python cache3m.py update                   fetch everything missing (the backlog, then one request a stock a day)
    python cache3m.py verify                   read only: every bar checked (layout, OHLC, the daily bar)

WHAT IT KEEPS
=============
Kite's 3-minute candles (open, high, low, close, volume; a bar is stamped with its START, 09:15 + 3k IST, 125 a
normal session) for every equity and index the daily cache holds (futures excluded), from --from (default the
history anchor 2015-01-01) to the last completed session. The files are production's own 3-minute store -
intraday_cache.store(root) and path_for(root, name), which stage E, tradelab and triggerlab read - so nothing about
their layout changes: <NAME>_3m.parquet, one file a series (a stock under its symbol, an index under its Kite name,
e.g. "NIFTY 50_3m.parquet", the name tradelab reads; an index file that already exists under its cache name is kept
under that name). cache3m's own bookkeeping lives in <store>\\_cache3m\\ (a small JSON a series, the catalog, the run
ledger, the reports, archived rows); consumers never see it.

THE PROMISE (the daily cache's)
===============================
What is on disk is what Kite printed, on the daily cache's corporate-action basis, for every session the daily cache
says the series traded - or a recorded reason why not:
  * nothing provisional: the fetch stops at the last COMPLETED session (15:30 + 15 minutes);
  * gaps are measured against the daily cache, each series' own sessions: every missing session in the window is
    fetched, in as few requests as Kite's 100-day limit allows. A session Kite has no 3-minute bars for, although
    the daily cache has a bar, is recorded once (a vendor gap) and not asked again (--recheck-gaps asks again);
  * a session cut short (ending an hour or more before NIFTY's and holding under half the stock's usual bars - a
    fetch made during market hours) is fetched once more;
  * corporate actions: whenever new bars are fetched, the last 2 cached sessions come again in the same request.
    The closes on one consistent new ratio means Kite re-based the history (a split or bonus processed over the
    weekend): the whole series is fetched again, the old file archived;
  * the daily cache is the reference basis. A run of 3 or more consecutive sessions whose high, low (and 09:15 open)
    sit on one ratio k to the daily bar is judged at the session after it: when the 3-minute bars jump there and
    the daily bars run on, Kite served that history unadjusted (much pre-2019 intraday data is): its prices are
    multiplied by k (volume divided by k), the factor kept in an adj_factor column (Kite's raw price = price /
    adj_factor) and the rows as they were archived. When the DAILY bars jump instead (the daily cache missed a
    corporate action), when the run reaches the latest session (the daily cache has not caught up yet), or when
    neither jumps clearly, Kite's bars are left as printed and the report says so. Anything else off the daily bar
    by more than 0.5% is reported, never altered;
  * each file keeps its own timestamp convention (tz-aware or naive IST) and columns; new files take the store's;
  * writes are atomic (a temporary file, then a replace): a stop at any moment (Ctrl+C, an expired token, a power
    cut) loses at most the series in flight, and the next run carries on.

SPEED
=====
Kite allows 3 historical requests a second and 100 days of 3-minute bars a request; cache3m runs at that limit
(6 workers on one shared limiter). A series already current costs nothing: a second run the same evening makes no
request at all, a normal evening one request a stock (about 13 minutes for ~2,300). A backlog is fetched newest
first - every series is brought up to date before any older history - then the history is filled backwards a year
at a time across the whole universe. Kite's 3-minute history starts where NIFTY's does; nothing earlier is asked.
--max-hours stops cleanly after a time budget; the next run continues.

Writes only <store>\\<NAME>_3m.parquet and <store>\\_cache3m\\. Reads the daily cache (read only) and its
instrument_cache.json (the tokens the daily cache used, so the 3-minute bars are the same instrument's).
Exit codes: 0 done; 2 done but some series failed or are behind; 3 refused; 4 Kite token expired; 5 stopped (time
budget or Ctrl+C) - rerun to continue.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import hashlib
import importlib
import json
import os
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

VERSION = "cache3m v1.0.1"
IST = "Asia/Kolkata"
BAR_MIN = 3
SLOTS = 125                                  # bar starts 09:15 .. 15:27
SESSION_START_MIN = 9 * 60 + 15
LAST_BAR_MIN = SESSION_START_MIN + BAR_MIN * (SLOTS - 1)
GRACE_MIN = 15
MAX_DAYS = 99                                # calendar days in one request (Kite allows 100 for 3minute)
KITE_RPS = 3.0
WORKERS = 6
RETRIES = 6
BACKOFF = 0.45
DEFAULT_FROM = "2015-01-01"
TAIL_SESSIONS = 2
BASIS_TOL = 0.005                            # within 0.5% of the daily bar = the same basis (tradelab's PRICE_TOL)
BASIS_MIN_SHIFT = 0.01                       # a ratio at least 1% away from 1 can start a basis block
BASIS_BLOCK_MIN = 3
JUMP_SHARE = 0.5                             # the block's end: the 3-minute jump must exceed the daily one by half k
SHIFT_TOL = 0.003                            # fresh vs cached overlap on one ratio beyond 0.3% = Kite re-based
THIN_SHARE = 0.5                             # a cut-short session: under half the series' median bars ...
THIN_GAP_MIN = 60                            # ... and its last bar an hour or more before NIFTY's that day
HISTORY_GAP_MIN = 20                         # NIFTY empty for >= 20 sessions before its first bar = Kite's start
ACTIVE_DAYS = 10                             # a series whose daily bars end within 10 days of NIFTY's is active
CATCHUP_DAYS = 120                           # era 0: every request ending within 120 days of the newest
FP_LAG = 20                                  # the daily fingerprint covers all but the last 20 sessions
PRICE = ["open", "high", "low", "close"]
COLS = ["timestamp"] + PRICE + ["volume"]
MASTER = "NIFTY50"
META_DIR = "_cache3m"
EMPTY_D = np.array([], dtype="datetime64[D]")
_PRINT = threading.Lock()


class Cache3mError(Exception):
    pass


class AuthExpired(Cache3mError):
    pass


class Unresolved(Cache3mError):
    pass


class StopBudget(Exception):
    pass


def log(msg: str) -> None:
    with _PRINT:
        print("%s  %s" % (dt.datetime.now().strftime("%H:%M:%S"), msg), flush=True)


# ====================================================================================================== time
def now_ist() -> dt.datetime:
    """The clock; CACHE3M_NOW (an ISO time, IST) overrides it - tests only."""
    o = os.environ.get("CACHE3M_NOW", "").strip()
    if o:
        t = pd.Timestamp(o)
        t = t.tz_localize(IST) if t.tzinfo is None else t.tz_convert(IST)
        return t.to_pydatetime()
    return pd.Timestamp.now(tz=IST).to_pydatetime()


def last_complete_day(now: dt.datetime) -> dt.date:
    """Today counts once its session closed (15:30) plus 15 minutes; a weekend or holiday simply has no bars."""
    close = now.replace(hour=15, minute=30, second=0, microsecond=0) + dt.timedelta(minutes=GRACE_MIN)
    return now.date() if now >= close else now.date() - dt.timedelta(days=1)


def D(x) -> np.datetime64:
    return np.datetime64(pd.Timestamp(x).date(), "D")


def day_range(d0, d1) -> np.ndarray:
    return np.arange(np.datetime64(d0, "D"), np.datetime64(d1, "D") + np.timedelta64(1, "D"))


def as_days(x) -> np.ndarray:
    return np.array(sorted(x), dtype="datetime64[D]") if x is not None and len(x) else EMPTY_D


def to_dt(t) -> pd.Series:
    t = t if isinstance(t, pd.Series) else pd.Series(t)
    return t if pd.api.types.is_datetime64_any_dtype(t.dtype) else pd.to_datetime(t)


def ist_naive(t) -> np.ndarray:
    t = to_dt(t)
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert(IST).dt.tz_localize(None)
    return t.to_numpy().astype("datetime64[ns]")


def days_of(df: pd.DataFrame) -> np.ndarray:
    if df is None or not len(df):
        return EMPTY_D
    return np.unique(ist_naive(df["timestamp"]).astype("datetime64[D]"))


# ====================================================================================================== files
def write_json_atomic(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=1, default=str, sort_keys=True), encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path) -> Optional[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    except Exception:
        return None


def write_parquet_atomic(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    df.to_parquet(tmp, index=False, compression="zstd", use_dictionary=False)   # plain encoding: 3x faster here
    last = None
    for i in range(8):                       # Windows: a reader holding the file blocks the replace for a moment
        try:
            os.replace(tmp, path)
            return
        except PermissionError as e:
            last = e
            time.sleep(0.25 * (i + 1))
    try:
        tmp.unlink()
    except OSError:
        pass
    raise Cache3mError("could not replace %s (%s) - is it open in another program?" % (path, last))


class RunLock:
    """One cache3m update per store at a time. v1.0.1: the lock is the operating system's lock on run.lock, held while
    the run lasts. It goes with the process however the run ends - Ctrl+C, its window closed, a crash, the PC shut
    down - so a killed run never blocks the next one. The file stays (it only names the last holder)."""

    def __init__(self, path: Path):
        self.path = path
        self.fh = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(self.path, "a+b")
        try:
            fh.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            fh.close()
            raise Cache3mError("another cache3m update is running on this store (it holds %s); it lets go when it "
                               "ends, however it ends" % self.path)
        self.fh = fh
        try:
            fh.truncate(0)
            fh.write(("%d %s" % (os.getpid(), dt.datetime.now().isoformat())).encode())
            fh.flush()
        except OSError:
            pass
        return self

    def __exit__(self, *a):
        fh, self.fh = self.fh, None
        if fh is None:
            return
        try:
            if os.name == "nt":
                import msvcrt
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        fh.close()


# ====================================================================================================== the daily cache
class Series:
    __slots__ = ("name", "kind", "tsym", "listing", "dates", "o", "h", "l", "c", "first", "last")

    def __init__(self, name, kind, tsym, listing):
        self.name, self.kind, self.tsym, self.listing = name, kind, tsym, listing
        self.dates = self.o = self.h = self.l = self.c = None
        self.first = self.last = None


def load_universe(root: Path, only: Optional[Sequence[str]] = None) -> Dict[str, Series]:
    """Every equity and index in the daily cache (its .ok.json says which); futures are left out. NIFTY50, the
    master calendar, always comes along."""
    out: Dict[str, Series] = {}
    want = ({s.strip().upper() for s in only} | {MASTER}) if only else None
    for okp in sorted(Path(root).glob("*_daily.ok.json")):
        name = okp.name[: -len("_daily.ok.json")]
        if want is not None and name.upper() not in want:
            continue
        m = read_json(okp) or {}
        kind = str(m.get("series_kind") or "equity")
        if kind not in ("equity", "index"):
            continue
        if not (Path(root) / ("%s_daily.parquet" % name)).exists():
            continue
        listing = m.get("listing_start") or m.get("first_timestamp")
        out[name] = Series(name, kind, str(m.get("tradingsymbol") or name), D(listing) if listing else None)
    if want is not None:
        miss = sorted(want - {k.upper() for k in out})
        if miss:
            log("not in the daily cache (skipped): %s" % ", ".join(miss[:20]))
    return out


def load_daily(root: Path, s: Series) -> Series:
    df = pd.read_parquet(Path(root) / ("%s_daily.parquet" % s.name),
                         columns=["timestamp", "open", "high", "low", "close"])
    d = ist_naive(df["timestamp"]).astype("datetime64[D]")
    order = np.argsort(d, kind="mergesort")
    d = d[order]
    keep = np.r_[d[1:] != d[:-1], True] if len(d) else np.zeros(0, bool)   # a two-bar day keeps its last bar
    s.dates = d[keep]
    for k, c in (("o", "open"), ("h", "high"), ("l", "low"), ("c", "close")):
        setattr(s, k, pd.to_numeric(df[c], errors="coerce").to_numpy(float)[order][keep])
    if len(s.dates):
        s.first, s.last = s.dates[0], s.dates[-1]
    return s


def daily_fp(s: Series, to) -> str:
    """A fingerprint of the daily highs and lows up to `to`: it changes when the daily cache re-bases its history."""
    m = s.dates <= np.datetime64(to, "D")
    h = hashlib.sha1(np.ascontiguousarray(s.h[m]).tobytes() + np.ascontiguousarray(s.l[m]).tobytes())
    return "%d:%s" % (int(m.sum()), h.hexdigest()[:16])


def fp_cut(s: Series) -> np.datetime64:
    return s.dates[max(0, len(s.dates) - FP_LAG - 1)]


def read_instrument_cache(root: Path) -> Dict[str, int]:
    """The daily cache's own tokens (SYMBOL -> instrument_token), so both caches read the same instrument."""
    p = Path(os.environ.get("INSTRUMENT_CACHE_FILE") or (Path(root) / "instrument_cache.json"))
    d = read_json(p) or {}
    out = {}
    for k, v in d.items():
        try:
            out[str(k).strip().upper()] = int(v)
        except (TypeError, ValueError):
            continue
    return out


# ====================================================================================================== the store
class FileStats:
    """One 3-minute file's sessions (from its timestamps only): day, bars, the last bar's minute, the convention."""
    __slots__ = ("days", "bars", "last_min", "tz")

    def __init__(self, days=EMPTY_D, bars=None, last_min=None, tz=None):
        self.days = days
        self.bars = bars if bars is not None else np.zeros(0, np.int64)
        self.last_min = last_min if last_min is not None else np.zeros(0, np.int64)
        self.tz = tz


def stats_of(t, tz=None) -> FileStats:
    tn = np.sort(ist_naive(t))
    if not len(tn):
        return FileStats(tz=tz)
    day = tn.astype("datetime64[D]")
    start = np.flatnonzero(np.r_[True, day[1:] != day[:-1]])
    end = np.r_[start[1:], len(day)]
    days = day[start]
    mins = ((tn[end - 1] - days.astype("datetime64[ns]")) // np.timedelta64(1, "m")).astype(np.int64)
    return FileStats(days, (end - start).astype(np.int64), mins, tz)


def file_stats(path: Path) -> FileStats:
    if not path.exists():
        return FileStats()
    try:
        import pyarrow.parquet as pq
        tz = bool(getattr(pq.read_schema(path).field("timestamp").type, "tz", None))
        t = pd.read_parquet(path, columns=["timestamp"])["timestamp"]
    except Exception as e:
        raise Cache3mError("%s is unreadable (%s: %s)" % (path, type(e).__name__, e)) from e
    return stats_of(t, tz)


class Store:
    """Production's 3-minute store (intraday_cache.store(root), path_for(root, name)); --store for a test."""

    def __init__(self, root: Path, store: Optional[str] = None):
        self.root = Path(root)
        self.ic_file = None
        self._path_for = None
        if store:
            self.dir = Path(store)
        else:
            try:
                IC = importlib.import_module("intraday_cache")
            except Exception as e:
                raise Cache3mError("cannot import production's intraday_cache (%s) - run env_tradelab.bat first, or "
                                   "give --store" % e) from e
            if int(getattr(IC, "BAR_MIN", 0)) != BAR_MIN or not hasattr(IC, "store"):
                raise Cache3mError("intraday_cache (%s) is not the 3-minute store (BAR_MIN %s)" % (
                    getattr(IC, "__file__", "?"), getattr(IC, "BAR_MIN", None)))
            self.dir = Path(IC.store(self.root))
            self._path_for = getattr(IC, "path_for", None)
            self.ic_file = str(getattr(IC, "__file__", ""))
        self.meta_dir = self.dir / META_DIR
        self.archive_dir = self.meta_dir / "replaced"
        self._files: Dict[str, Path] = {}

    def path(self, name: str) -> Path:
        if self._path_for is not None:
            return Path(self._path_for(self.root, name))
        return self.dir / ("%s_3m.parquet" % name)

    def file_for(self, s: Series) -> Path:
        """A stock: <SYMBOL>_3m.parquet. An index: its Kite name ("NIFTY 50", what tradelab reads), unless a file
        already exists under its cache name ("NIFTY50") and none under the Kite name."""
        p = self._files.get(s.name)
        if p is None:
            p = self.path(s.name)
            if s.kind == "index" and s.tsym and s.tsym != s.name:
                a = self.path(s.tsym)
                p = a if (a.exists() or not p.exists()) else p
            self._files[s.name] = p
        return p

    def other_name(self, s: Series) -> Optional[Path]:
        """An index's second file, when both names exist (reported, never touched)."""
        if s.kind != "index" or not s.tsym or s.tsym == s.name:
            return None
        a, b = self.path(s.tsym), self.path(s.name)
        return b if (a.exists() and b.exists()) else None

    def meta_path(self, name: str) -> Path:
        return self.meta_dir / "symbols" / ("%s.json" % name)

    def meta(self, name: str) -> dict:
        return read_json(self.meta_path(name)) or {}

    def write_meta(self, name: str, m: dict) -> None:
        write_json_atomic(self.meta_path(name), m)


class Conv:
    """A file's timestamp convention: tz-aware IST or naive IST."""

    def __init__(self, tz_aware: bool = True):
        self.tz_aware = tz_aware

    def ts(self, t) -> pd.Series:
        t = to_dt(t)
        if getattr(t.dt, "tz", None) is None:
            t = t.dt.tz_localize(IST)
        t = t.dt.tz_convert(IST).dt.as_unit("ns")
        return t if self.tz_aware else t.dt.tz_localize(None)


def store_convention(stats: Dict[str, FileStats]) -> Tuple[bool, str]:
    tz = [st.tz for st in stats.values() if st.tz is not None]
    if not tz:
        return True, "new files: tz-aware IST (Kite's own; the store has no files yet)"
    n_tz = int(sum(tz))
    aware = n_tz * 2 >= len(tz)
    return aware, "each file keeps its own; new files: %s (%d of %d existing files are tz-aware)" % (
        "tz-aware IST" if aware else "naive IST", n_tz, len(tz))


# ====================================================================================================== Kite
class Limiter:
    """One token bucket for every worker: rps requests a second, never more."""

    def __init__(self, rps: float):
        self.rps = float(rps)
        self.tokens = 1.0
        self.t = time.perf_counter()
        self.lock = threading.Lock()

    def acquire(self) -> None:
        while True:
            with self.lock:
                now = time.perf_counter()
                self.tokens = min(1.0, self.tokens + (now - self.t) * self.rps)
                self.t = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    return
                wait = (1.0 - self.tokens) / self.rps
            time.sleep(wait)


_TRANSIENT = ("too many", "429", "timed out", "timeout", "temporarily", "connection", "reset by peer",
              "remote end closed", "502", "503", "504", "gateway", "try again")


def error_kind(e: BaseException) -> str:
    n = type(e).__name__
    msg = str(e).lower()
    if n == "TokenException":
        return "auth"
    if n == "InputException" and ("instrument" in msg or "invalid token" in msg):
        return "instrument"
    if n in ("NetworkException", "DataException") or isinstance(e, (TimeoutError, ConnectionError)):
        return "transient"
    if any(w in msg for w in _TRANSIENT):
        return "transient"
    return "other"


class Kite3m:
    """Kite's historical endpoint for 3-minute candles: tokens, the shared limiter, retries."""

    def __init__(self, kite, rps: float = KITE_RPS, inst_cache: Optional[Dict[str, int]] = None):
        self.kite = kite
        self.limiter = Limiter(rps)
        self.inst_cache = inst_cache or {}
        self.calls = 0
        self.retries = 0
        self.lock = threading.Lock()
        self._dump_lock = threading.Lock()
        self._dump: Optional[Dict[Tuple[str, str], int]] = None

    def dump(self) -> Dict[Tuple[str, str], int]:
        with self._dump_lock:
            if self._dump is None:
                rows = self._call(self.kite.instruments, "NSE")
                m: Dict[Tuple[str, str], int] = {}
                for r in rows or []:
                    ts = str(r.get("tradingsymbol", "")).upper()
                    seg = str(r.get("segment", "")).upper()
                    tok = r.get("instrument_token")
                    if not ts or not tok:
                        continue
                    if seg == "INDICES":
                        m[("index", ts)] = int(tok)
                    elif seg == "NSE" and str(r.get("instrument_type", "")).upper() == "EQ":
                        m[("equity", ts)] = int(tok)
                self._dump = m
        return self._dump

    def resolve(self, s: Series) -> Tuple[int, str]:
        """The daily cache's own token first (the same instrument as the daily bars), else Kite's NSE list."""
        key = s.tsym.upper()
        tok = self.inst_cache.get(key)
        if tok:
            return int(tok), "daily cache"
        tok = self.dump().get((s.kind, key))
        if tok is None:
            raise Unresolved("%s (%s) is neither in the daily cache's instrument_cache.json nor in Kite's NSE list "
                             "(delisted or renamed?)" % (s.name, s.tsym))
        return int(tok), "Kite NSE list"

    def _call(self, fn, *a, **k):
        attempt = 0
        while True:
            self.limiter.acquire()
            with self.lock:
                self.calls += 1
            try:
                return fn(*a, **k)
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                kd = error_kind(e)
                if kd == "auth":
                    raise AuthExpired("Kite token expired or invalid (%s) - refresh it with Kiteconnect.py and "
                                      "rerun; nothing is lost" % e) from e
                if kd == "instrument":
                    raise Unresolved("Kite rejects the instrument (%s)" % e) from e
                attempt += 1
                if kd != "transient" or attempt >= RETRIES:
                    raise
                with self.lock:
                    self.retries += 1
                msg = str(e).lower()
                time.sleep(min(15.0, BACKOFF * 2.2 ** attempt) if ("too many" in msg or "429" in msg) else
                           min(8.0, BACKOFF * 1.8 ** attempt + float(np.random.random()) * BACKOFF / 2))

    def bars(self, tok: int, d0: dt.date, d1: dt.date, index: bool) -> pd.DataFrame:
        """3-minute candles for the calendar days d0..d1 (at most MAX_DAYS): tz-aware IST, start-stamped."""
        if (d1 - d0).days + 1 > MAX_DAYS or d1 < d0:
            raise Cache3mError("internal: a request for %s..%s" % (d0, d1))
        rows = self._call(self.kite.historical_data, tok, dt.datetime.combine(d0, dt.time(0, 0)),
                          dt.datetime.combine(d1, dt.time(23, 59)), "3minute", continuous=False, oi=False)
        df = pd.DataFrame(rows or [])
        if df.empty:
            return pd.DataFrame(columns=COLS)
        if "date" in df.columns and "timestamp" not in df.columns:
            df = df.rename(columns={"date": "timestamp"})
        t = pd.to_datetime(df["timestamp"])
        t = t.dt.tz_localize(IST) if getattr(t.dt, "tz", None) is None else t.dt.tz_convert(IST)
        out = pd.DataFrame({"timestamp": t.dt.as_unit("ns")})
        for c in PRICE:
            out[c] = pd.to_numeric(df[c], errors="coerce").astype("float64")
        vol = pd.to_numeric(df["volume"], errors="coerce").astype("float64") if "volume" in df.columns else np.nan
        out["volume"] = np.nan if index else vol        # indices print no volume: NaN, never a phantom 0
        return out


def kite_from_token(path: Optional[str] = None):
    try:
        from kiteconnect import KiteConnect
    except Exception as e:
        raise Cache3mError("kiteconnect is not installed (pip install kiteconnect)") from e
    p = path or os.environ.get("KITE_TOKEN_FILE") or r"C:\Users\karanvsi\PyCharmMiscProject\kite_token.json"
    if not os.path.exists(p):
        raise AuthExpired("token file %s not found - run Kiteconnect.py first" % p)
    d = json.loads(Path(p).read_text(encoding="utf-8"))
    if not d.get("api_key") or not d.get("access_token"):
        raise AuthExpired("api_key / access_token missing in %s" % p)
    k = KiteConnect(api_key=d["api_key"])
    try:
        k.timeout = float(os.environ.get("KITE_HTTP_TIMEOUT", "15"))
    except Exception:
        pass
    k.set_access_token(d["access_token"])
    try:
        k.profile()
    except Exception as e:
        if error_kind(e) == "auth":
            raise AuthExpired("Kite token expired - refresh it with Kiteconnect.py (%s)" % e) from e
        raise
    return k


# ====================================================================================================== planning
def greedy_windows(days) -> List[Tuple[dt.date, dt.date]]:
    """The fewest MAX_DAYS-long windows covering every day (greedy from the earliest is optimal)."""
    ds = sorted({pd.Timestamp(d).date() for d in days})
    out, i = [], 0
    while i < len(ds):
        lim = ds[i] + dt.timedelta(days=MAX_DAYS - 1)
        j = i
        while j + 1 < len(ds) and ds[j + 1] <= lim:
            j += 1
        out.append((ds[i], ds[j]))
        i = j + 1
    return out


class Context:
    """The run's window and what NIFTY's 3-minute file says about the calendar."""

    def __init__(self, from_d, end_d, master_last=None):
        self.from_d, self.end_d = from_d, end_d
        self.master_new = EMPTY_D            # NIFTY 3-minute sessions after the daily cache's last NIFTY date
        self.master_last = master_last       # the latest session known (daily or 3-minute)
        self.history_start = None            # Kite's first 3-minute session (NIFTY's), when it is later than from
        self.m_days = EMPTY_D                # NIFTY's sessions and each one's last bar (minutes after midnight)
        self.m_last = np.zeros(0, np.int64)

    def set_master(self, sm: Series, st: FileStats, meta: dict, recheck: bool) -> None:
        self.m_days, self.m_last = st.days, st.last_min
        have = st.days
        self.master_new = have[have > sm.last] if len(have) and sm.last is not None else EMPTY_D
        self.master_last = max(sm.last, have.max()) if len(have) else sm.last
        self.history_start = None
        if len(have) and have[0] > self.from_d:
            lo = max(self.from_d, sm.listing if sm.listing is not None else self.from_d, sm.first)
            before = sm.dates[(sm.dates >= lo) & (sm.dates < have[0])]
            gaps = as_days(meta.get("vendor_empty", []))
            if len(before) >= HISTORY_GAP_MIN and np.isin(before, gaps).all():
                self.history_start = have[0]


def is_active(s: Series, C: Context) -> bool:
    return s.last is not None and C.master_last is not None and \
        s.last >= C.master_last - np.timedelta64(ACTIVE_DAYS, "D")


def weekday(d: np.ndarray) -> np.ndarray:
    return (d.astype("datetime64[D]").astype(np.int64) + 3) % 7          # Monday 0 .. Sunday 6


def expected_sessions(s: Series, C: Context, report: bool = False) -> np.ndarray:
    """The daily cache's sessions of this series inside the window (and, for an active series, NIFTY's 3-minute
    sessions the daily cache has not reached yet). Sessions before Kite's 3-minute history are not expected (NIFTY
    still looks for them when planning, so a longer history at Kite would be found)."""
    if s.dates is None or not len(s.dates):
        return EMPTY_D
    lo = max(C.from_d, s.listing if s.listing is not None else C.from_d, s.first)
    if C.history_start is not None and (s.name != MASTER or report):
        lo = max(lo, C.history_start)
    exp = s.dates[(s.dates >= lo) & (s.dates <= C.end_d)]
    if is_active(s, C) and len(C.master_new):
        nm = C.master_new
        exp = np.union1d(exp, nm[(nm > s.last) & (nm >= lo) & (nm <= C.end_d)])
    return exp


def thin_sessions(st: FileStats, s: Series, C: Context, checked) -> np.ndarray:
    """Sessions cut short (fetched during market hours): under half the file's median bars AND the last bar an hour
    or more before NIFTY's last bar that day (15:27 when NIFTY has no bars that day)."""
    if len(st.days) < 5:
        return EMPTY_D
    med = float(np.median(st.bars))
    ref = np.full(len(st.days), LAST_BAR_MIN, dtype=np.int64)
    if s.name != MASTER and len(C.m_days):
        pos = np.minimum(np.searchsorted(C.m_days, st.days), len(C.m_days) - 1)
        hit = C.m_days[pos] == st.days
        ref = np.where(hit, C.m_last[pos], LAST_BAR_MIN)
    d = st.days[(st.bars < THIN_SHARE * med) & (st.last_min <= ref - THIN_GAP_MIN)]
    d = d[np.isin(d, s.dates)]
    if len(checked):
        d = d[~np.isin(d, as_days(checked))]
    return d


class Plan:
    __slots__ = ("sym", "expected", "missing", "thin", "tail", "windows", "full", "skip")

    def __init__(self, sym):
        self.sym = sym
        self.expected = self.missing = self.thin = self.tail = EMPTY_D
        self.windows: List[Tuple[dt.date, dt.date]] = []
        self.full = False
        self.skip = ""


def plan_symbol(s: Series, st: FileStats, meta: dict, C: Context, full: bool = False,
                recheck: bool = False) -> Plan:
    """What to fetch for one series: the expected sessions it lacks (recorded vendor gaps excepted), its cut-short
    sessions, and - when anything is fetched - its last 2 cached sessions again, in the fewest requests."""
    P = Plan(s.name)
    if meta.get("unresolved") and not recheck:
        P.skip = "unresolved"
        return P
    P.expected = exp = expected_sessions(s, C)
    if s.name == MASTER and s.last is not None and C.end_d > s.last:
        # NIFTY looks past its daily bars (every weekday up to today), so a session the daily cache has not
        # reached yet is found - and through NIFTY's 3-minute bars every active series gets it too
        cand = np.arange(s.last + np.timedelta64(1, "D"), C.end_d + np.timedelta64(1, "D"))
        P.expected = exp = np.union1d(exp, cand[weekday(cand) < 5])
    if not len(exp):
        P.skip = "no sessions in the window"
        return P
    if full:
        P.full, P.missing = True, exp
        P.windows = greedy_windows(exp)
        return P
    have = st.days
    gaps = EMPTY_D if recheck else as_days(meta.get("vendor_empty", []))
    P.missing = np.setdiff1d(np.setdiff1d(exp, have), gaps)
    P.thin = thin_sessions(st, s, C, [] if recheck else meta.get("thin_checked", []))
    want = np.union1d(P.missing, P.thin)
    if not len(want):
        P.skip = "current"
        return P
    P.tail = np.setdiff1d(have[have < want.max()][-TAIL_SESSIONS:], P.thin)
    P.windows = greedy_windows(np.union1d(want, P.tail))
    return P


def eras(plans: Dict[str, Plan]) -> List[List[Tuple[str, List[Tuple[dt.date, dt.date]]]]]:
    """Newest first across the universe: era 0 = every request ending within 120 days of the newest (it brings
    everything up to date), then one era a calendar year (of a request's end), newest year first."""
    newest = max((w[1] for P in plans.values() for w in P.windows), default=dt.date.today())
    groups: Dict[int, Dict[str, list]] = {}
    for sym, P in plans.items():
        for w in P.windows:
            key = 99999 if (newest - w[1]).days <= CATCHUP_DAYS else w[1].year
            groups.setdefault(key, {}).setdefault(sym, []).append(w)
    return [sorted(groups[k].items()) for k in sorted(groups, reverse=True)]


# ====================================================================================================== basis
def session_table(df: pd.DataFrame, s: Series) -> pd.DataFrame:
    """Per session (as stored): the first bar's open and minute, high, low, the last close, bars, the factor applied,
    and the daily bar's open / high / low / close with the ratios daily / stored."""
    t = ist_naive(df["timestamp"])
    day = t.astype("datetime64[D]")
    mins = ((t - day.astype("datetime64[ns]")) // np.timedelta64(1, "m")).astype(np.int64)
    adj = pd.to_numeric(df["adj_factor"], errors="coerce").fillna(1.0).to_numpy(float) \
        if "adj_factor" in df.columns else np.ones(len(df))
    F = pd.DataFrame({"day": day, "m": mins, "o": pd.to_numeric(df["open"], errors="coerce").to_numpy(float),
                      "h": pd.to_numeric(df["high"], errors="coerce").to_numpy(float),
                      "l": pd.to_numeric(df["low"], errors="coerce").to_numpy(float),
                      "c": pd.to_numeric(df["close"], errors="coerce").to_numpy(float), "adj": adj})
    F = F.sort_values(["day", "m"], kind="mergesort")
    g = F.groupby("day", sort=True)
    T = pd.DataFrame({"o": g["o"].first(), "first_m": g["m"].first(), "h": g["h"].max(), "l": g["l"].min(),
                      "c": g["c"].last(), "bars": g.size(), "adj": g["adj"].median()})
    days = T.index.to_numpy().astype("datetime64[D]")
    if s.dates is not None and len(s.dates):
        pos = np.minimum(np.searchsorted(s.dates, days), len(s.dates) - 1)
        hit = s.dates[pos] == days
        for k, arr in (("do", s.o), ("dh", s.h), ("dl", s.l), ("dc", s.c)):
            T[k] = np.where(hit, arr[pos], np.nan) if arr is not None else np.nan
    else:
        T["do"] = T["dh"] = T["dl"] = T["dc"] = np.nan
    with np.errstate(invalid="ignore", divide="ignore"):
        T["kh"] = T["dh"] / T["h"]
        T["kl"] = T["dl"] / T["l"]
        T["ko"] = np.where(T["first_m"] == SESSION_START_MIN, T["do"] / T["o"], np.nan)
    return T


def basis_k(T: pd.DataFrame) -> np.ndarray:
    """The session's ratio daily / stored when its high and low (and its 09:15 open, when it has one) agree on it
    within 0.5%; NaN when they disagree or there is no daily bar."""
    kh, kl, ko = (T[c].to_numpy(float) for c in ("kh", "kl", "ko"))
    with np.errstate(invalid="ignore", divide="ignore"):
        k = np.sqrt(kh * kl)
        agree = np.isfinite(kh) & np.isfinite(kl) & (kh > 0) & (kl > 0) & (np.abs(kh / kl - 1) <= BASIS_TOL)
        agree &= ~np.isfinite(ko) | (np.abs(ko / k - 1) <= BASIS_TOL)
    return np.where(agree, k, np.nan)


def basis_blocks(T: pd.DataFrame) -> List[Tuple[np.datetime64, np.datetime64, float, int]]:
    """Runs of >= 3 consecutive sessions whose stored bars sit on one consistent ratio k (|k - 1| > 1%) to the
    daily bar: Kite serving them on another corporate-action basis."""
    k = basis_k(T)
    days = T.index.to_numpy().astype("datetime64[D]")
    out, i, n = [], 0, len(k)
    while i < n:
        if not (np.isfinite(k[i]) and abs(k[i] - 1) > BASIS_MIN_SHIFT):
            i += 1
            continue
        j = i
        while j + 1 < n and np.isfinite(k[j + 1]) and abs(k[j + 1] / k[i] - 1) <= BASIS_TOL:
            j += 1
        if j - i + 1 >= BASIS_BLOCK_MIN:
            out.append((days[i], days[j], float(np.median(k[i:j + 1])), j - i + 1))
        i = j + 1
    return out


def judge_blocks(T: pd.DataFrame, B) -> Tuple[list, List[str]]:
    """Which side moved? At the session after a block, the series that is continuous is on the right basis.
    Kite's unadjusted history: the 3-minute bars jump there (from the old price level to today's) while the daily
    bars run on - adjust. A daily cache that missed a corporate action: the daily bars jump, the 3-minute bars run
    on - leave Kite's bars alone. No session after the block, no daily bar there, or no clear winner: leave alone."""
    days = T.index.to_numpy().astype("datetime64[D]")
    pos = {d: i for i, d in enumerate(days.tolist())}
    c3, o3 = T["c"].to_numpy(float), T["o"].to_numpy(float)
    dc, do = T["dc"].to_numpy(float), T["do"].to_numpy(float)
    ok, notes = [], []
    for b in B:
        b0, b1, k, n = b
        i = pos[np.datetime64(b1, "D").item()]
        lead = "sessions %s..%s (%d) sit x%.4g off the daily bars" % (b0, b1, n, k)
        if i + 1 >= len(days):
            notes.append(lead + " up to the latest session: the daily cache has not caught up with a corporate "
                                "action? - left as Kite prints them (run the daily cache, then cache3m)")
            continue
        vals = (c3[i], o3[i + 1], dc[i], do[i + 1])
        if not all(np.isfinite(v) and v > 0 for v in vals):
            notes.append(lead + "; the session after has no daily bar yet - left as Kite prints them")
            continue
        j3 = abs(np.log(vals[1] / vals[0]))
        jd = abs(np.log(vals[3] / vals[2]))
        if j3 - jd > JUMP_SHARE * abs(np.log(k)):
            ok.append(b)
        elif jd - j3 > JUMP_SHARE * abs(np.log(k)):
            notes.append(lead + "; the jump is in the DAILY bars on %s (the daily cache missed a corporate action?) "
                                "- left as Kite prints them" % days[i + 1])
        else:
            notes.append(lead + "; neither series jumps clearly on %s - left as Kite prints them" % days[i + 1])
    return ok, notes


def classify(T: pd.DataFrame) -> Dict[str, int]:
    """Sessions as stored: on the daily bar (high and low within 0.5%), off it, no daily bar; and how many carry an
    adjustment."""
    with np.errstate(invalid="ignore", divide="ignore"):
        on = (np.abs(T["kh"].to_numpy(float) - 1) <= BASIS_TOL) & (np.abs(T["kl"].to_numpy(float) - 1) <= BASIS_TOL)
    nod = ~np.isfinite(T["dh"].to_numpy(float))
    return {"sessions": int(len(T)), "on_daily": int(on.sum()), "off_daily": int((~on & ~nod).sum()),
            "no_daily_bar": int(nod.sum()), "adjusted": int((np.abs(T["adj"].to_numpy(float) - 1) > 1e-12).sum())}


def apply_blocks(df: pd.DataFrame, blocks) -> pd.DataFrame:
    """Prices x k, volume / k, adj_factor x k on each block's sessions."""
    df = df.copy()
    if "adj_factor" not in df.columns:
        df["adj_factor"] = 1.0
    df["adj_factor"] = pd.to_numeric(df["adj_factor"], errors="coerce").fillna(1.0).astype("float64")
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce").astype("float64")
    for c in PRICE:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("float64")
    day = ist_naive(df["timestamp"]).astype("datetime64[D]")
    for d0, d1, k, _ in blocks:
        m = (day >= d0) & (day <= d1)
        for c in PRICE:
            df.loc[m, c] = df.loc[m, c].to_numpy(float) * k
        df.loc[m, "volume"] = df.loc[m, "volume"].to_numpy(float) / k
        df.loc[m, "adj_factor"] = df.loc[m, "adj_factor"].to_numpy(float) * k
    return df


def overlap_check(old: pd.DataFrame, new: pd.DataFrame, old_tn: Optional[np.ndarray] = None) -> Tuple[str, int]:
    """Fresh bars against the cached ones on the same stamps, in Kite's raw terms (cached / adj_factor): a reason
    when the closes sit on one consistent ratio beyond 0.3% (Kite re-based), else the number of corrected values."""
    if old.empty or new.empty:
        return "", 0
    tb = ist_naive(new["timestamp"])
    ta = ist_naive(old["timestamp"]) if old_tn is None else old_tn
    keep = ta >= tb.min()
    a = old[keep].set_index(pd.Index(ta[keep]))
    a = a[~a.index.duplicated(keep="last")]
    b = new.set_index(pd.Index(tb))
    b = b[~b.index.duplicated(keep="last")]
    common = a.index.intersection(b.index)
    if not len(common):
        return "", 0
    a, b = a.loc[common], b.loc[common]
    adj = pd.to_numeric(a["adj_factor"], errors="coerce").fillna(1.0).to_numpy(float) \
        if "adj_factor" in a.columns else np.ones(len(common))
    with np.errstate(invalid="ignore", divide="ignore"):
        r = pd.to_numeric(b["close"], errors="coerce").to_numpy(float) / \
            (pd.to_numeric(a["close"], errors="coerce").to_numpy(float) / adj)
    r = r[np.isfinite(r) & (r > 0)]
    if len(r) >= 5:
        med = float(np.median(r))
        if abs(med - 1) > SHIFT_TOL and float(np.mean(np.abs(r / med - 1) <= SHIFT_TOL)) >= 0.8:
            return "Kite re-based the history (the overlap's closes x%.4f)" % med, 0
    diff = 0
    for c in PRICE + ["volume"]:
        x = pd.to_numeric(a[c], errors="coerce").to_numpy(float)
        x = x / adj if c in PRICE else x * adj
        y = pd.to_numeric(b[c], errors="coerce").to_numpy(float)
        both = np.isfinite(x) & np.isfinite(y)
        diff += int(np.sum(both & (np.abs(x - y) > 1e-6 * np.maximum(1.0, np.abs(y)))))
    return "", diff


# ====================================================================================================== merging
def align(base: pd.DataFrame, new: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """The same columns on both (the cached file's extras kept: adj_factor 1.0 on fresh bars, others blank). Volume
    keeps an integer column when the fresh numbers are whole; an index file holding zeros keeps zeros."""
    base, new = base.copy(), new.copy()
    for c in base.columns:
        if c not in new.columns:
            new[c] = 1.0 if c == "adj_factor" else np.nan
    for c in new.columns:
        if c not in base.columns:
            base[c] = 1.0 if c == "adj_factor" else np.nan
    bv = base["volume"]
    bvn = pd.to_numeric(bv, errors="coerce")
    nv = pd.to_numeric(new["volume"], errors="coerce")
    if len(nv) and nv.isna().all() and len(bvn) and bvn.notna().all() and (bvn == 0).all():
        nv = pd.Series(0.0, index=nv.index)
    if pd.api.types.is_integer_dtype(bv.dtype) and nv.notna().all() and np.all(np.mod(nv.to_numpy(float), 1) == 0):
        new["volume"] = nv.astype(bv.dtype)
    else:
        base["volume"] = bvn.astype("float64")
        new["volume"] = nv.astype("float64")
    return base, new[list(base.columns)]


def merge_bars(base: pd.DataFrame, new: pd.DataFrame) -> pd.DataFrame:
    """Fresh bars replace cached ones on the same stamp; sorted by time."""
    if not len(new):
        return base
    if base.shape[1] == 0:
        m = new.copy()
    else:
        base, new = align(base, new)
        m = pd.concat([base, new], ignore_index=True) if len(base) else new
    m = m.assign(_k=ist_naive(m["timestamp"])).sort_values("_k", kind="mergesort")
    return m.drop_duplicates("_k", keep="last").drop(columns="_k").reset_index(drop=True)


# ====================================================================================================== one series
class Result:
    def __init__(self, sym):
        self.sym = sym
        self.requests = 0
        self.new_sessions = 0
        self.vendor_empty: List[str] = []
        self.thin_refetched = 0
        self.corrections = 0
        self.full = ""
        self.adjusted: List[dict] = []
        self.basis_note: Optional[str] = None
        self.wrote = False

    def add(self, o: "Result") -> "Result":
        self.requests += o.requests
        self.new_sessions += o.new_sessions
        self.vendor_empty += o.vendor_empty
        self.thin_refetched += o.thin_refetched
        self.corrections += o.corrections
        self.full = self.full or o.full
        self.adjusted += o.adjusted
        self.basis_note = o.basis_note if o.basis_note is not None else self.basis_note
        self.wrote = self.wrote or o.wrote
        return self


class Runner:
    def __init__(self, store: Store, kite: Optional[Kite3m], now: dt.datetime, C: Context,
                 stats: Dict[str, FileStats], default_tz: bool, budget_end=None):
        self.store, self.kite, self.now, self.C = store, kite, now, C
        self.stats = stats
        self.default_tz = default_tz
        self.budget_end = budget_end
        self.lock = threading.Lock()
        self.full_done: set = set()
        self.tok_src: Dict[str, str] = {}

    def check_budget(self):
        if self.budget_end is not None and time.time() > self.budget_end:
            raise StopBudget()

    def conv(self, name: str) -> Conv:
        st = self.stats.get(name)
        return Conv(st.tz if (st is not None and st.tz is not None) else self.default_tz)

    def fetch(self, s: Series, tok: int, windows, conv: Conv) -> Tuple[pd.DataFrame, int, np.ndarray]:
        parts, n, asked = [], 0, []
        for d0, d1 in sorted(windows, reverse=True):          # newest first
            self.check_budget()
            b = self.kite.bars(tok, d0, d1, s.kind == "index")
            n += 1
            asked.append(day_range(d0, d1))
            if len(b):
                b = b.copy()
                b["timestamp"] = conv.ts(b["timestamp"])
                parts.append(b)
        asked_days = np.unique(np.concatenate(asked)) if asked else EMPTY_D
        return (pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()), n, asked_days

    def needs_scan(self, meta: dict, s: Series) -> bool:
        """The whole file is checked against the daily cache the first time cache3m touches it, and again whenever
        the daily cache's history changed (it re-based a corporate action)."""
        fp = meta.get("daily_fp") or {}
        if not meta.get("basis_scan") or not fp.get("to") or s.dates is None or not len(s.dates):
            return True
        return fp.get("h") != daily_fp(s, fp["to"])

    def run_symbol(self, s: Series, P: Plan, tok: Optional[int]) -> Result:
        R = Result(s.name)
        if s.name in self.full_done:
            return R
        path = self.store.file_for(s)
        conv = self.conv(s.name)
        meta = self.store.meta(s.name)
        old = pd.read_parquet(path) if path.exists() else pd.DataFrame()
        old_tn = np.zeros(0, "datetime64[ns]")
        if len(old):
            old["timestamp"] = conv.ts(old["timestamp"])
            old_tn = ist_naive(old["timestamp"])
        new, R.requests, asked = (self.fetch(s, tok, P.windows, conv) if P.windows else (pd.DataFrame(), 0, EMPTY_D))
        if len(new) and len(old) and not P.full:
            why, R.corrections = overlap_check(old, new, old_tn)
            if why:                                              # Kite re-based: everything again
                P = plan_symbol(s, FileStats(), {}, self.C, full=True)
                new, n2, asked = self.fetch(s, tok, P.windows, conv)
                R.requests += n2
                R.full = why
        base = old.iloc[0:0] if (P.full and len(old)) else old
        merged = merge_bars(base, new) if len(new) else (base if not P.full else old)
        got = days_of(new)
        miss_asked = np.intersect1d(np.intersect1d(P.missing, asked), s.dates)
        R.vendor_empty = [str(d) for d in np.setdiff1d(miss_asked, got)]
        thin_asked = np.intersect1d(P.thin, asked)
        R.thin_refetched = int(len(thin_asked))
        old_days = np.unique(old_tn.astype("datetime64[D]"))
        R.new_sessions = int(len(got)) if P.full else int(len(np.setdiff1d(got, old_days)))
        scan_all = bool(P.full and len(new)) or self.needs_scan(meta, s)
        tn = ist_naive(merged["timestamp"]) if len(merged) else np.zeros(0, "datetime64[ns]")
        merged, R.adjusted, R.basis_note, scanned, arch = self.basis(s, merged, tn, got, scan_all)
        if ((P.full and len(new)) or len(new) or R.adjusted) and len(merged):
            if P.full and path.exists():
                self.archive_file(path, s.name, "rebased")
            if arch is not None and len(arch):
                self.archive_rows(arch, s.name, "basis", conv)
            out = merged.copy()
            out["timestamp"] = conv.ts(out["timestamp"])
            write_parquet_atomic(path, out)
            R.wrote = True
            st = stats_of(tn, conv.tz_aware)
            with self.lock:
                self.stats[s.name] = st
        if P.full and len(new):
            with self.lock:
                self.full_done.add(s.name)
        self.write_meta(s, tok, meta, path, R, P, got, thin_asked, scanned)
        return R

    def basis(self, s: Series, df: pd.DataFrame, tn: np.ndarray, touched: np.ndarray, scan_all: bool):
        """Put old sessions Kite serves on another corporate-action basis onto the daily cache's. tn: the frame's
        stamps (IST, naive). Returns (frame, adjusted blocks, note or None for unchanged, whether the whole file was
        checked, the rows as they were)."""
        if df.empty or s.dates is None or not len(s.dates):
            return df, [], None, False, None
        day = tn.astype("datetime64[D]")
        if not scan_all:
            if not len(touched):
                return df, [], None, False, None
            sub = df[day >= touched.min() - np.timedelta64(10, "D")]
            if not basis_blocks(session_table(sub, s)):
                return df, [], None, False, None
        T = session_table(df, s)
        B = basis_blocks(T)
        older, notes = judge_blocks(T, B)
        note = "; ".join(notes[-2:])
        if not older:
            return df, [], note, True, None
        m = np.zeros(len(df), bool)
        for d0, d1, _, _ in older:
            m |= (day >= d0) & (day <= d1)
        arch = df[m].copy()
        df = apply_blocks(df, older)
        adj = [{"from": str(b0), "to": str(b1), "factor": round(float(k), 6), "sessions": int(n)}
               for b0, b1, k, n in older]
        return df, adj, note, True, arch

    def archive_file(self, path: Path, name: str, why: str) -> None:
        with self.lock:
            self.store.archive_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, self._archive_name(name, why))

    def archive_rows(self, rows: pd.DataFrame, name: str, why: str, conv: Conv) -> None:
        rows = rows.copy()
        rows["timestamp"] = conv.ts(rows["timestamp"])
        with self.lock:
            self.store.archive_dir.mkdir(parents=True, exist_ok=True)
            write_parquet_atomic(self._archive_name(name, why), rows)

    def _archive_name(self, name: str, why: str) -> Path:
        base = "%s_%s_%s" % (name, self.now.strftime("%Y%m%d_%H%M%S"), why)
        p = self.store.archive_dir / (base + ".parquet")
        k = 1
        while p.exists():
            k += 1
            p = self.store.archive_dir / ("%s_%d.parquet" % (base, k))
        return p

    def write_meta(self, s: Series, tok, meta: dict, path: Path, R: Result, P: Plan, got, thin_asked,
                   scanned: bool) -> None:
        m = dict(meta)
        st = self.stats.get(s.name) or FileStats()
        full = bool(P.full and R.new_sessions)
        ve = set() if full else set(m.get("vendor_empty", []))
        ve = (ve | set(R.vendor_empty)) - {str(d) for d in got}
        tc = set() if full else set(m.get("thin_checked", []))
        tc |= {str(d) for d in thin_asked}
        m.update({"tool": VERSION, "symbol": s.name, "kind": s.kind, "tradingsymbol": s.tsym, "file": path.name,
                  "vendor_empty": sorted(ve), "thin_checked": sorted(tc), "sessions": int(len(st.days)),
                  "first_session": str(st.days[0]) if len(st.days) else None,
                  "last_session": str(st.days[-1]) if len(st.days) else None})
        if tok is not None:
            m["token"] = int(tok)
            m["token_source"] = self.tok_src.get(s.name, m.get("token_source"))
        if P.windows or R.requests:
            m["last_fetch"] = self.now.isoformat()
        m.pop("unresolved", None)
        if R.full:
            m.setdefault("full_refetches", []).append({"at": self.now.isoformat(), "reason": R.full})
        if R.adjusted:
            m.setdefault("adjustments", []).extend(dict(x, at=self.now.isoformat()) for x in R.adjusted)
        if scanned and s.dates is not None and len(s.dates):
            cut = fp_cut(s)
            m["basis_scan"] = self.now.isoformat()
            m["daily_fp"] = {"to": str(cut), "h": daily_fp(s, cut)}
        if R.basis_note is not None:
            if R.basis_note:
                m["basis_note"] = R.basis_note
            else:
                m.pop("basis_note", None)
        m["corrections"] = int(m.get("corrections", 0)) + int(R.corrections)
        self.store.write_meta(s.name, m)


# ====================================================================================================== the update
def read_symbols(a) -> Optional[List[str]]:
    only = list(a.symbols) if a.symbols else None
    if getattr(a, "symbols_file", None):
        extra = [x.strip().split(",")[0] for x in Path(a.symbols_file).read_text(encoding="utf-8").splitlines()]
        extra = [x for x in extra if x and not x.lower().startswith(("symbol", "#"))]
        only = (only or []) + extra
    return only


def window(a) -> Tuple[np.datetime64, np.datetime64, dt.datetime]:
    now = now_ist()
    from_d = D(a.from_date or os.environ.get("CACHE_HISTORY_ANCHOR") or DEFAULT_FROM)
    return from_d, np.datetime64(last_complete_day(now), "D"), now


def open_world(a):
    """The daily cache (universe, sessions, basis), the store and every file's sessions."""
    root = Path(a.root)
    if not root.is_dir():
        raise Cache3mError("--root %s is not a folder" % root)
    store = Store(root, a.store)
    from_d, end_d, now = window(a)
    U = load_universe(root, read_symbols(a))
    if MASTER not in U:
        raise Cache3mError("%s is not in the daily cache (%s) - it is the master calendar; run the daily cache "
                           "first" % (MASTER, root))
    for s in U.values():
        load_daily(root, s)
    stats: Dict[str, FileStats] = {}
    unreadable: Dict[str, str] = {}
    for n, s in U.items():
        try:
            stats[n] = file_stats(store.file_for(s))
        except Cache3mError as e:
            unreadable[n] = str(e)
    return root, store, from_d, end_d, now, U, stats, unreadable


def run_update(a, kite_obj=None) -> int:
    t0 = time.time()
    root, store, from_d, end_d, now, U, stats, unreadable = open_world(a)
    default_tz, conv_txt = store_convention(stats)
    sm = U[MASTER]
    C = Context(from_d, end_d, sm.last)
    C.set_master(sm, stats.get(MASTER, FileStats()), store.meta(MASTER), a.recheck_gaps)
    log("%s | store %s | %s .. %s | %d series from the daily cache (%d indices) | timestamps: %s" % (
        VERSION, store.dir, from_d, end_d, len(U), sum(s.kind == "index" for s in U.values()), conv_txt))
    if a.rate > KITE_RPS:
        log("note: --rate %.1f is above Kite's 3 a second; Kite answers 429 and the retries slow everything" % a.rate)
    if a.check_only:
        plans = {n: plan_symbol(s, stats[n], store.meta(n), C, recheck=a.recheck_gaps)
                 for n, s in U.items() if n in stats}
        todo = {k: P for k, P in plans.items() if P.windows}
        n_req = sum(len(P.windows) for P in todo.values())
        first = sum(len(w) for era in eras(todo)[:1] for _, w in era) if todo else 0
        log("CHECK ONLY: %d series to fetch, %d requests (about %.1f hours at %.0f a second); the first %d (about "
            "%.0f minutes) bring every series up to date; %d series current" % (
                len(todo), n_req, n_req / a.rate / 3600, a.rate, first, first / a.rate / 60, len(U) - len(todo)))
        for k in sorted(todo, key=lambda k: -len(todo[k].missing))[:15]:
            P = todo[k]
            log("  %-18s %5d sessions missing, %3d cut short, %3d requests (%s .. %s)" % (
                k, len(P.missing), len(P.thin), len(P.windows), P.windows[0][0], P.windows[-1][1]))
        if unreadable:
            log("  unreadable files (left alone): %s" % "; ".join(unreadable.values()))
        log("nothing fetched or written")
        return 0
    kite = Kite3m(kite_obj if kite_obj is not None else kite_from_token(), rps=a.rate,
                  inst_cache=read_instrument_cache(root))
    results: Dict[str, Result] = {}
    failed: Dict[str, str] = dict(unreadable)
    unresolved: Dict[str, str] = {}
    stopped, code = "", 0
    with RunLock(store.meta_dir / "run.lock"):
        store.dir.mkdir(parents=True, exist_ok=True)
        Rn = Runner(store, kite, now, C, stats, default_tz,
                    (time.time() + a.max_hours * 3600) if a.max_hours else None)

        def resolve(names) -> Dict[str, int]:
            toks = {}
            for n in names:
                try:
                    toks[n], Rn.tok_src[n] = kite.resolve(U[n])
                except Unresolved as e:
                    unresolved[n] = str(e)
                    m = store.meta(n)
                    m.update({"symbol": n, "tool": VERSION, "unresolved": {"at": now.isoformat(), "why": str(e)}})
                    store.write_meta(n, m)
                except (AuthExpired, StopBudget, KeyboardInterrupt):
                    raise
                except Exception as e:
                    failed[n] = "token: %s: %s" % (type(e).__name__, e)
            return toks

        try:
            # 1. NIFTY first: its 3-minute sessions fix the calendar beyond the daily cache, Kite's first 3-minute
            #    session, and each session's last bar (for the cut-short test)
            if MASTER in stats:
                Pm = plan_symbol(sm, stats[MASTER], store.meta(MASTER), C, recheck=a.recheck_gaps)
                if Pm.windows or (Rn.needs_scan(store.meta(MASTER), sm) and stats[MASTER].days.size):
                    toks = resolve([MASTER]) if Pm.windows else {MASTER: None}
                    if MASTER in toks:
                        try:
                            results[MASTER] = Rn.run_symbol(sm, Pm, toks[MASTER])
                        except (AuthExpired, StopBudget, KeyboardInterrupt):
                            raise
                        except Exception as e:
                            failed[MASTER] = "%s: %s" % (type(e).__name__, e)
                C.set_master(sm, Rn.stats.get(MASTER, FileStats()), store.meta(MASTER), a.recheck_gaps)
                if C.history_start is not None:
                    log("Kite's 3-minute history starts %s (NIFTY's first bar); earlier sessions are not asked" %
                        C.history_start)
            # 2. everything else, newest first
            plans: Dict[str, Plan] = {}
            scan_only: List[str] = []
            n_cur = n_unres = 0
            for n, s in U.items():
                if n == MASTER or n not in stats:
                    continue
                meta = store.meta(n)
                P = plan_symbol(s, stats[n], meta, C, recheck=a.recheck_gaps)
                n_cur += P.skip == "current"
                n_unres += P.skip == "unresolved"
                if P.windows:
                    plans[n] = P
                elif P.skip == "current" and len(stats[n].days) and Rn.needs_scan(meta, s):
                    scan_only.append(n)
            E = eras(plans)
            n_req = sum(len(P.windows) for P in plans.values())
            log("plan: %d series to fetch, %d requests in %d eras (about %.0f minutes); %d current, %d unresolved "
                "earlier (not asked)" % (len(plans), n_req, len(E), n_req / a.rate / 60, n_cur, n_unres))
            for ei, era in enumerate(E):
                toks = resolve([nm for nm, _ in era if nm not in Rn.full_done and nm not in unresolved and
                                nm not in failed])
                era = [(nm, w) for nm, w in era if nm in toks]
                log("era %d of %d: %d series, %d requests" % (ei + 1, len(E), len(era), sum(len(w) for _, w in era)))
                run_era(era, U, plans, Rn, toks, results, failed, a.workers, n_req, t0)
            if scan_only:
                log("basis check of %d files cache3m has not checked yet (no requests)" % len(scan_only))
                for nm in scan_only:
                    plans[nm] = Plan(nm)
                run_era([(nm, []) for nm in scan_only], U, plans, Rn, {nm: None for nm in scan_only}, results,
                        failed, a.workers, 0, t0)
            for rnd in (1, 2):
                retry = [k for k in failed if k in U and k not in unreadable]
                if not retry:
                    break
                log("second chance %d: %d series (%s)" % (rnd, len(retry), ", ".join(retry[:8])))
                time.sleep(2)
                for k in retry:
                    failed.pop(k, None)
                if MASTER in retry:
                    retry.remove(MASTER)
                    Pm = plan_symbol(sm, Rn.stats.get(MASTER, FileStats()), store.meta(MASTER), C,
                                     recheck=a.recheck_gaps)
                    toks = resolve([MASTER]) if Pm.windows else {}
                    if MASTER in toks:
                        try:
                            r = Rn.run_symbol(sm, Pm, toks[MASTER])
                            results[MASTER] = results[MASTER].add(r) if MASTER in results else r
                        except (AuthExpired, StopBudget, KeyboardInterrupt):
                            raise
                        except Exception as e:
                            failed[MASTER] = "%s: %s" % (type(e).__name__, e)
                era = []
                for k in retry:
                    P = plan_symbol(U[k], Rn.stats.get(k, FileStats()), store.meta(k), C, recheck=a.recheck_gaps)
                    if P.windows:
                        plans[k] = P
                        era.append((k, P.windows))
                toks = resolve([k for k, _ in era])
                run_era([(k, w) for k, w in era if k in toks], U, plans, Rn, toks, results, failed,
                        min(3, a.workers), 0, t0)
        except StopBudget:
            stopped, code = "time budget reached (--max-hours %s): rerun to continue" % a.max_hours, 5
        except AuthExpired as e:
            stopped, code = str(e), 4
        except KeyboardInterrupt:
            stopped, code = "interrupted (Ctrl+C): rerun to continue", 5
        if stopped:
            log("STOPPED: %s" % stopped)
        rep = coverage(store, U, C, Rn.stats, results, failed, unresolved, kite, now, stopped, time.time() - t0,
                       conv_txt)
    if code:
        return code
    return 2 if (failed or rep["stale"]) else 0


def run_era(era, U, plans, Rn: Runner, toks, results, failed, workers, n_req, t0):
    if not era:
        return

    def task(name, wins):
        P = plans[name]
        P.windows = wins
        return Rn.run_symbol(U[name], P, toks.get(name))

    last = time.time()
    with cf.ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        futs = {ex.submit(task, nm, w): nm for nm, w in era}
        try:
            for i, f in enumerate(cf.as_completed(futs), 1):
                name = futs[f]
                try:
                    r = f.result()
                    results[name] = results[name].add(r) if name in results else r
                except (AuthExpired, StopBudget, KeyboardInterrupt):
                    raise
                except Exception as e:
                    failed[name] = "%s: %s" % (type(e).__name__, e)
                if time.time() - last >= 60 or i == len(futs):
                    last = time.time()
                    k = Rn.kite.calls if Rn.kite else 0
                    rate = k / max(1e-9, time.time() - t0)
                    eta = (n_req - k) / rate / 60 if (n_req and rate > 0 and n_req > k) else 0
                    log("   %d of %d series in this era | %d requests so far (%.2f a second)%s" % (
                        i, len(futs), k, rate, " | about %.0f minutes left" % eta if eta else ""))
        except BaseException:
            for f in futs:
                f.cancel()
            raise


# ====================================================================================================== reports
def runs_text(days, max_runs=5) -> List[str]:
    ds = sorted(pd.Timestamp(d).date() for d in days)
    if not ds:
        return []
    out, a, b = [], ds[0], ds[0]
    for d in ds[1:]:
        if (d - b).days <= 4:
            b = d
            continue
        out.append((a, b))
        a = b = d
    out.append((a, b))
    txt = [str(x) if x == y else "%s..%s" % (x, y) for x, y in out[:max_runs]]
    if len(out) > max_runs:
        txt.append("+%d more runs" % (len(out) - max_runs))
    return txt


def light_row(store: Store, s: Series, st: FileStats, C: Context) -> dict:
    """A series against the daily cache, from its sessions alone."""
    meta = store.meta(s.name)
    have = st.days
    exp = expected_sessions(s, C, report=True)
    gaps = as_days(meta.get("vendor_empty", []))
    miss = np.setdiff1d(np.setdiff1d(exp, have), gaps)
    behind = miss[miss > have.max()] if len(have) else miss
    return {"symbol": s.name, "kind": s.kind, "tradingsymbol": s.tsym, "file": store.file_for(s).name,
            "exists": bool(len(have)) or store.file_for(s).exists(), "expected": int(len(exp)),
            "present": int(np.isin(exp, have).sum()), "missing": int(len(miss)), "behind": int(len(behind)),
            "missing_runs": runs_text(miss), "vendor_gaps": int(np.isin(gaps, exp).sum()),
            "first_session": str(have[0]) if len(have) else None, "last_session": str(have[-1]) if len(have) else None,
            "sessions": int(len(have)), "active": bool(is_active(s, C)), "unresolved": bool(meta.get("unresolved")),
            "adjustments": len(meta.get("adjustments", [])), "full_refetches": len(meta.get("full_refetches", [])),
            "basis_note": meta.get("basis_note"), "token_source": meta.get("token_source")}


def write_catalog(store: Store, rows: List[dict], C: Context, now) -> None:
    """The store's index for other tools: every series' file, kind and span."""
    keep = ("kind", "tradingsymbol", "file", "first_session", "last_session", "sessions", "missing", "vendor_gaps",
            "adjustments", "basis_note", "unresolved")
    write_json_atomic(store.meta_dir / "catalog.json", {
        "tool": VERSION, "generated": now.isoformat(), "store": str(store.dir), "window_to": str(C.end_d),
        "history_start": str(C.history_start) if C.history_start is not None else None,
        "series": {r["symbol"]: {k: r.get(k) for k in keep} for r in rows if "error" not in r}})


def coverage(store, U, C, stats, results, failed, unresolved, kite, now, stopped, secs, conv_txt) -> dict:
    rows = []
    for n, s in sorted(U.items()):
        if n not in stats:
            rows.append({"symbol": n, "error": failed.get(n, "not read")})
            continue
        rows.append(light_row(store, s, stats[n], C))
    last_m = next((r.get("last_session") for r in rows if r["symbol"] == MASTER), None)
    unresolved = dict(unresolved)
    for r in rows:
        if r.get("unresolved") and r["symbol"] not in unresolved:
            unresolved[r["symbol"]] = str((store.meta(r["symbol"]).get("unresolved") or {}).get("why", "unresolved"))
    stale = [r["symbol"] for r in rows if "error" not in r and r["active"] and r["behind"] and not r["unresolved"]]
    gappy = sorted([r for r in rows if r.get("missing") and not r.get("unresolved")], key=lambda r: -r["missing"])
    live = [r for r in rows if not r.get("unresolved")]
    T = {k: int(sum(int(r.get(k) or 0) for r in live)) for k in ("expected", "present", "missing", "vendor_gaps")}
    T["unresolved_sessions"] = int(sum(int(r.get("expected") or 0) for r in rows if r.get("unresolved")))
    dup = [store.other_name(s).name for s in U.values() if store.other_name(s) is not None]
    rep = {"tool": VERSION, "generated": now.isoformat(), "store": str(store.dir), "intraday_cache": store.ic_file,
           "timestamps": conv_txt, "from": str(C.from_d), "to": str(C.end_d), "last_session": last_m,
           "history_start": str(C.history_start) if C.history_start is not None else None,
           "series": len(U), "files": int(sum(bool(r.get("exists")) for r in rows)), "requests": kite.calls,
           "retries": kite.retries, "minutes": round(secs / 60, 1), "stopped": stopped or None,
           "fetched": {k: {"requests": v.requests, "new_sessions": v.new_sessions,
                           "vendor_gaps": len(v.vendor_empty), "cut_short_refetched": v.thin_refetched,
                           "corrections": v.corrections, "full_refetch": v.full or None, "adjusted": v.adjusted,
                           "basis_note": v.basis_note or None} for k, v in sorted(results.items())},
           "stale": stale, "missing_sessions": [{"symbol": r["symbol"], "missing": r["missing"],
                                                 "runs": r.get("missing_runs")} for r in gappy],
           "failed": failed, "unresolved": unresolved, "index_files_under_two_names": dup, "totals": T,
           "per_symbol": rows}
    write_json_atomic(store.meta_dir / "coverage_report.json", rep)
    write_catalog(store, rows, C, now)
    with open(store.meta_dir / "runs.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({k: rep[k] for k in ("tool", "generated", "from", "to", "last_session", "series",
                                                  "requests", "retries", "minutes", "stopped")}
                           | {"fetched": len(results), "new_sessions": sum(v.new_sessions for v in results.values()),
                              "failed": len(failed), "unresolved": len(unresolved), "stale": len(stale),
                              "missing": T["missing"]}, default=str) + "\n")
    full = [k for k, v in results.items() if v.full]
    adj = [k for k, v in results.items() if v.adjusted]
    notes = [r for r in rows if r.get("basis_note")]
    L = ["", "=" * 76, "3-MINUTE CACHE (%s)" % VERSION, "=" * 76,
         "  store         : %s" % store.dir,
         "  last session  : %s (NIFTY 3-minute)   window %s .. %s%s" % (
             last_m, C.from_d, C.end_d, ("   Kite's 3-minute history starts %s" % C.history_start)
             if C.history_start is not None else ""),
         "  this run      : %d requests (%d retried), %.1f minutes, %d series fetched, %d new sessions" % (
             kite.calls, kite.retries, secs / 60, len(results), sum(v.new_sessions for v in results.values())),
         "  series        : %d | files %d | STALE %d | with missing sessions %d | failed %d | unresolved %d" % (
             len(U), rep["files"], len(stale), len(gappy), len(failed), len(unresolved)),
         "  sessions      : %d expected, %d present, %d missing, %d vendor gaps (a daily bar, no 3-minute bars)" % (
             T["expected"], T["present"], T["missing"], T["vendor_gaps"])]
    if full:
        L.append("  re-based by Kite (fetched whole, old file archived): %s" % ", ".join(sorted(full)[:20]))
    if adj:
        L.append("  put on the daily cache's basis (rows archived): %s" % ", ".join(
            "%s (%s)" % (k, ", ".join("%s..%s x%.4g" % (b["from"], b["to"], b["factor"]) for b in results[k].adjusted))
            for k in sorted(adj)[:8]) + (" ..." if len(adj) > 8 else ""))
    for r in notes[:6]:
        L.append("  NOTE %s: %s" % (r["symbol"], r["basis_note"]))
    if stopped:
        L.append("  STOPPED       : %s" % stopped)
    if stale:
        L.append("  STALE (active, behind): %s%s" % (", ".join(stale[:25]), " ..." if len(stale) > 25 else ""))
    for r in gappy[:10]:
        L.append("    %-18s missing %-5d %s" % (r["symbol"], r["missing"], ", ".join(r.get("missing_runs") or [])))
    if failed:
        L.append("  FAILED: " + "; ".join("%s (%s)" % (k, v[:90]) for k, v in list(failed.items())[:10]))
    if unresolved:
        L.append("  unresolved (no token: not asked again; --recheck-gaps asks): %d series, %d sessions - %s" % (
            len(unresolved), T["unresolved_sessions"], ", ".join(sorted(unresolved)[:12])))
    if dup:
        L.append("  index files under two names (the Kite-name file is the one kept current): %s" % ", ".join(dup))
    L += ["  report: %s" % (store.meta_dir / "coverage_report.json"), "=" * 76]
    print("\n".join(L), flush=True)
    return rep


def run_inspect(a) -> int:
    root, store, from_d, end_d, now, U, stats, unreadable = open_world(a)
    conv_aware, conv_txt = store_convention(stats)
    sm = U[MASTER]
    C = Context(from_d, end_d, sm.last)
    C.set_master(sm, stats.get(MASTER, FileStats()), store.meta(MASTER), False)
    plans, behind = {}, {}
    for n, s in U.items():
        if n not in stats:
            continue
        plans[n] = plan_symbol(s, stats[n], store.meta(n), C)
        have = stats[n].days
        if len(have):
            k = int(np.sum((s.dates > have.max()) & (s.dates <= end_d)))
            if k:
                behind[n] = k
    todo = {k: P for k, P in plans.items() if P.windows}
    n_req = sum(len(P.windows) for P in todo.values())
    first = sum(len(w) for era in eras(todo)[:1] for _, w in era) if todo else 0
    files = sum(1 for n in stats if len(stats[n].days) or store.file_for(U[n]).exists())
    known = {store.file_for(s).name for s in U.values()} | \
        {store.other_name(s).name for s in U.values() if store.other_name(s) is not None}
    others = sorted(p.name for p in store.dir.glob("*_3m.parquet") if p.name not in known) \
        if store.dir.is_dir() else []
    n_thin = sum(len(P.thin) for P in todo.values())
    L = ["", "=" * 76, "3-MINUTE STORE (%s, read only)" % VERSION, "=" * 76,
         "  store        : %s (intraday_cache: %s)" % (store.dir, store.ic_file or "not used, --store"),
         "  timestamps   : %s" % conv_txt,
         "  daily cache  : %d series (%d indices); its NIFTY ends %s" % (
             len(U), sum(s.kind == "index" for s in U.values()), sm.last),
         "  files        : %d of %d series have a 3-minute file; NIFTY's 3-minute file ends %s" % (
             files, len(U), stats[MASTER].days[-1] if MASTER in stats and len(stats[MASTER].days) else "-"),
         "  behind       : %d series lack recent sessions the daily cache has (median %d sessions)" % (
             len(behind), int(np.median(list(behind.values()))) if behind else 0),
         "  missing      : %d sessions in %s .. %s across %d series; %d cut-short sessions to fetch again" % (
             sum(len(P.missing) for P in todo.values()), from_d, end_d, len(todo), n_thin),
         "  to fetch     : %d requests, about %.1f hours at 3 a second; the first %d (about %.0f minutes) bring "
         "every series up to date" % (n_req, n_req / KITE_RPS / 3600, first, first / KITE_RPS / 60)]
    worst = sorted(behind.items(), key=lambda kv: -kv[1])[:10]
    if worst:
        L.append("  most behind  : " + ", ".join("%s %d" % kv for kv in worst))
    if unreadable:
        L.append("  UNREADABLE   : %s" % "; ".join(unreadable.values()))
    if others:
        L.append("  other files  : %d 3-minute files are not in the daily cache's universe (left alone): %s" % (
            len(others), ", ".join(others[:8])))
    L.append("=" * 76)
    print("\n".join(L), flush=True)
    if a.out:
        write_json_atomic(Path(a.out) / "cache3m_inspect.json", {
            "tool": VERSION, "store": str(store.dir), "timestamps": conv_txt, "files": files, "series": len(U),
            "requests_to_fetch": n_req, "requests_to_current": first, "behind": behind, "unreadable": unreadable,
            "other_files": others, "missing": {k: int(len(P.missing)) for k, P in todo.items()}})
    return 0


def deep_row(store: Store, s: Series, st: FileStats, C: Context) -> dict:
    """Every bar: the 09:15 + 3k grid, duplicates, OHLC sanity, bars a session, and the daily bar."""
    rec = light_row(store, s, st, C)
    p = store.file_for(s)
    if not p.exists():
        return rec
    df = pd.read_parquet(p)
    t = ist_naive(df["timestamp"])
    day = t.astype("datetime64[D]")
    mins = ((t - day.astype("datetime64[ns]")) // np.timedelta64(1, "m")).astype(np.int64)
    slot = (mins - SESSION_START_MIN) / BAR_MIN
    on = (slot >= 0) & (slot <= SLOTS - 1) & (np.abs(slot - np.round(slot)) < 1e-9)
    per = pd.Series(on).groupby(day).sum()
    o, h, l, c = (pd.to_numeric(df[k], errors="coerce").to_numpy(float) for k in PRICE)
    with np.errstate(invalid="ignore"):
        bad = (h < l) | (c > h * (1 + 1e-9)) | (c < l * (1 - 1e-9)) | (o > h * (1 + 1e-9)) | (o < l * (1 - 1e-9)) | \
              (l <= 0)
    T = session_table(df, s)
    rec.update({"bars": int(len(df)), "off_grid_bars": int((~on).sum()),
                "duplicates": int(pd.Series(t).duplicated().sum()), "ohlc_violations": int(np.nansum(bad)),
                "missing_prices": int((~np.isfinite(o) | ~np.isfinite(h) | ~np.isfinite(l) | ~np.isfinite(c)).sum()),
                "sessions_full": int((per >= SLOTS).sum()), "sessions_under_80pct": int((per < 0.8 * SLOTS).sum()),
                **classify(T), "basis_blocks": [{"from": str(x), "to": str(y), "factor": round(k, 6), "sessions": int(n)}
                                                for x, y, k, n in basis_blocks(T)]})
    return rec


def run_verify(a) -> int:
    root, store, from_d, end_d, now, U, stats, unreadable = open_world(a)
    sm = U[MASTER]
    C = Context(from_d, end_d, sm.last)
    C.set_master(sm, stats.get(MASTER, FileStats()), store.meta(MASTER), False)
    names = [n for n in sorted(U) if n in stats]
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        rows = list(ex.map(lambda n: deep_row(store, U[n], stats[n], C), names))
    keys = ("expected", "present", "missing", "vendor_gaps", "bars", "off_grid_bars", "duplicates", "ohlc_violations",
            "missing_prices", "sessions_under_80pct", "on_daily", "off_daily", "no_daily_bar", "adjusted")
    T = {k: int(sum(int(r.get(k) or 0) for r in rows if not r.get("unresolved"))) for k in keys}
    unres = [r["symbol"] for r in rows if r.get("unresolved")]
    blocks = {r["symbol"]: r["basis_blocks"] for r in rows if r.get("basis_blocks")}
    write_json_atomic(store.meta_dir / "verify_report.json", {"tool": VERSION, "generated": now.isoformat(),
                                                              "store": str(store.dir), "totals": T,
                                                              "basis_blocks": blocks, "unreadable": unreadable,
                                                              "per_symbol": rows})
    worst = sorted([r for r in rows if r.get("off_daily")], key=lambda r: -r["off_daily"])[:8]
    L = ["", "=" * 76, "3-MINUTE STORE VERIFY (%s, read only)" % VERSION, "=" * 76,
         "  sessions : %d expected, %d present, %d missing, %d vendor gaps" % (
             T["expected"], T["present"], T["missing"], T["vendor_gaps"]),
         "  layout   : %d bars, %d off the 09:15+3k grid, %d duplicate stamps, %d OHLC violations, %d missing prices, "
         "%d sessions under 80%% of 125 bars" % (T["bars"], T["off_grid_bars"], T["duplicates"], T["ohlc_violations"],
                                                 T["missing_prices"], T["sessions_under_80pct"]),
         "  daily    : %d sessions on the daily bar, %d off it (>0.5%%), %d with no daily bar, %d carrying an "
         "adjustment" % (T["on_daily"], T["off_daily"], T["no_daily_bar"], T["adjusted"]),
         "  basis    : %d series hold a block of sessions on another corporate-action basis%s" % (
             len(blocks), (" (" + ", ".join(list(blocks)[:12]) + ")") if blocks else "")]
    if worst:
        L.append("  most off : " + ", ".join("%s %d" % (r["symbol"], r["off_daily"]) for r in worst))
    if unres:
        L.append("  unresolved: %d series without a token (not counted above): %s" % (len(unres), ", ".join(unres[:12])))
    if unreadable:
        L.append("  UNREADABLE: %s" % "; ".join(unreadable.values()))
    L += ["  report   : %s" % (store.meta_dir / "verify_report.json"), "=" * 76]
    print("\n".join(L), flush=True)
    return 0


def main(argv=None, kite_obj=None) -> int:
    ap = argparse.ArgumentParser(prog="cache3m", description=VERSION)
    ap.add_argument("cmd", choices=["inspect", "update", "verify"])
    ap.add_argument("--root", default=os.environ.get("CACHE_DAILY_ROOT"),
                    help="the daily cache (%%CACHE_DAILY_ROOT%%): the universe, its sessions, the reference basis")
    ap.add_argument("--store", help="the 3-minute folder (default: production's intraday_cache.store(root))")
    ap.add_argument("--from", dest="from_date", help="first session to keep (default CACHE_HISTORY_ANCHOR, else "
                                                     "2015-01-01)")
    ap.add_argument("--symbols", nargs="*", help="only these series (NIFTY50 always comes along)")
    ap.add_argument("--symbols-file", dest="symbols_file", help="only the series listed in this file")
    ap.add_argument("--workers", type=int, default=WORKERS)
    ap.add_argument("--rate", type=float, default=KITE_RPS, help="requests a second (Kite allows 3)")
    ap.add_argument("--max-hours", dest="max_hours", type=float, help="update: stop cleanly after this long; the "
                                                                       "next run continues")
    ap.add_argument("--check-only", dest="check_only", action="store_true", help="update: plan, fetch nothing")
    ap.add_argument("--recheck-gaps", dest="recheck_gaps", action="store_true",
                    help="update: ask Kite again for recorded vendor gaps, cut-short sessions and unresolved series")
    ap.add_argument("--out", help="inspect: also write cache3m_inspect.json here")
    a = ap.parse_args(argv)
    print(VERSION, flush=True)
    if not a.root:
        print("REFUSED: give --root or run env_daily.bat (CACHE_DAILY_ROOT is not set) - there is no default",
              flush=True)
        return 3
    if a.rate <= 0 or a.workers < 1:
        print("REFUSED: --rate must be > 0 and --workers >= 1", flush=True)
        return 3
    try:
        if a.cmd == "inspect":
            return run_inspect(a)
        if a.cmd == "verify":
            return run_verify(a)
        return run_update(a, kite_obj)
    except AuthExpired as e:
        print("STOPPED: %s" % e, flush=True)
        return 4
    except Cache3mError as e:
        print("REFUSED: %s" % e, flush=True)
        return 3


if __name__ == "__main__":
    sys.exit(main())
