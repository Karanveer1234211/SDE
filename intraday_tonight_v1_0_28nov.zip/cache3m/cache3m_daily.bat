@echo off
rem cache3m v1.0 - the evening update of the 3-minute store (run it after the daily cache)
rem extra arguments pass through, e.g.  cache3m_daily.bat --max-hours 9
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\cache3m
python cache3m.py update %*
exit /b %ERRORLEVEL%
