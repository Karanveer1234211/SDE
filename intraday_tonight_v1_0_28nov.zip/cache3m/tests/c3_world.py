"""
c3_world.py - cache3m's test world (NOT production code).

A daily cache (<NAME>_daily.parquet + .ok.json + instrument_cache.json), Kite's 3-minute bars behind a fake
KiteConnect, a stand-in for production's intraday_cache (store / path_for / BAR_MIN), and production-like
3-minute files that are behind. Every bar is built from one hidden truth, so a test can say exactly what the store
must hold.

Calendar: weekdays 2023-06-01 .. 2026-11-13 less a few holidays, plus a Saturday session (2025-02-01) and a Sunday
evening Muhurat session (2025-11-02: 20 bars from 18:15). Kite's 3-minute history starts 2024-01-02 for every
instrument (the daily cache starts earlier).

Series (name, kind, what is special):
  NIFTY50    index "NIFTY 50"  production file "NIFTY 50_3m.parquet" (tz-aware, volume 0.0) up to 2026-06-30
  NIFTYBANK  index "NIFTY BANK" production file under its CACHE name "NIFTYBANK_3m.parquet" (volume NaN)
  INDIAVIX   index "INDIA VIX" no file
  AAA        tz-aware production file to 2026-06-30 holding one session cut short at 12:00 (2025-03-12)
  BBB        NAIVE-timestamp production file, int64 volume, to 2026-06-30
  OLDB       Kite serves its sessions up to 2024-06-28 unadjusted (prices x2, volume /2); no file
  OLDP       the same, and a production file already holding those unadjusted bars
  SPLT       1:2 split on 2026-11-02; Kite and the daily cache re-base together (when the world says so)
  SPLD       the same split; the daily cache misses it at first (its old sessions stay on the old basis)
  DIVX       an extraordinary dividend on 2026-11-02: Kite and the daily cache re-base prices by 0.96 (not volume)
  GAPV       Kite has no 3-minute bars on 5 sessions the daily cache has
  ILLQ       thinly traded (about 35% of bars), production file to 2026-03-31
  IPOX       listed 2025-09-15
  DELS       delisted 2025-03-14: in the daily cache, unknown to Kite (no token anywhere)
  RNMD       renamed: the daily cache's tradingsymbol OLDNAME is gone from Kite's list; its token is in
             instrument_cache.json
"""
from __future__ import annotations

import datetime as dt
import json
import shutil
import textwrap
import threading
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd

IST = "Asia/Kolkata"
NB = 125
CAL_START = "2023-06-01"
CAL_END = "2026-11-13"
KITE_START = np.datetime64("2024-01-02", "D")
OLD_BASIS_END = np.datetime64("2024-06-28", "D")
SPLIT_DAY = np.datetime64("2026-11-02", "D")
SATURDAY = np.datetime64("2025-02-01", "D")
MUHURAT = np.datetime64("2025-11-02", "D")
CUT_DAY = np.datetime64("2025-03-12", "D")
PROD_END = np.datetime64("2026-06-30", "D")
HOLIDAYS = ["2023-08-15", "2024-01-26", "2024-03-25", "2024-08-15", "2025-01-01", "2025-08-15", "2026-01-26",
            "2026-10-02"]
GAPS = [np.datetime64(x, "D") for x in ("2024-03-05", "2024-03-06", "2025-05-20", "2026-02-10", "2026-09-15")]

# name: (kind, tradingsymbol, start price, listing, delisting)
SPECS = {
    "NIFTY50": ("index", "NIFTY 50", 21000.0, None, None),
    "NIFTYBANK": ("index", "NIFTY BANK", 46000.0, None, None),
    "INDIAVIX": ("index", "INDIA VIX", 14.0, None, None),
    "AAA": ("equity", "AAA", 1500.0, None, None),
    "BBB": ("equity", "BBB", 320.0, None, None),
    "OLDB": ("equity", "OLDB", 800.0, None, None),
    "OLDP": ("equity", "OLDP", 640.0, None, None),
    "SPLT": ("equity", "SPLT", 1200.0, None, None),
    "SPLD": ("equity", "SPLD", 900.0, None, None),
    "DIVX": ("equity", "DIVX", 400.0, None, None),
    "GAPV": ("equity", "GAPV", 150.0, None, None),
    "ILLQ": ("equity", "ILLQ", 45.0, None, None),
    "IPOX": ("equity", "IPOX", 500.0, "2025-09-15", None),
    "DELS": ("equity", "DELS", 90.0, None, "2025-03-14"),
    "RNMD": ("equity", "OLDNAME", 700.0, None, None),
}
TOKENS = {n: 5000 + 17 * i for i, n in enumerate(SPECS)}
IN_INSTRUMENT_CACHE = ("NIFTY50", "AAA", "BBB", "RNMD", "SPLT")     # the rest resolve through Kite's NSE list


def calendar() -> np.ndarray:
    d = pd.bdate_range(CAL_START, CAL_END).to_numpy().astype("datetime64[D]")
    d = d[~np.isin(d, np.array(HOLIDAYS, dtype="datetime64[D]"))]
    return np.union1d(d, np.array([SATURDAY, MUHURAT]))


def slot_minutes(day: np.datetime64) -> np.ndarray:
    if day == MUHURAT:
        return 18 * 60 + 15 + 3 * np.arange(20)
    return 9 * 60 + 15 + 3 * np.arange(NB)


def tick(x: np.ndarray, t: float = 0.05) -> np.ndarray:
    return np.round(np.round(x / t) * t, 2)


class Truth:
    """One series' adjusted 3-minute bars (the hidden truth) as flat arrays."""

    def __init__(self, name: str, rng: np.random.Generator, cal: np.ndarray):
        kind, tsym, p0, listing, delist = SPECS[name]
        self.name, self.kind, self.tsym = name, kind, tsym
        days = cal.copy()
        if listing:
            days = days[days >= np.datetime64(listing, "D")]
        if delist:
            days = days[days <= np.datetime64(delist, "D")]
        rows_day, rows_min = [], []
        for d in days:
            m = slot_minutes(d)
            if name == "ILLQ":
                keep = rng.random(len(m)) < 0.35
                keep[0] = keep[0] or rng.random() < 0.6
                if not keep.any():
                    keep[0] = True
                m = m[keep]
            rows_day.append(np.full(len(m), d))
            rows_min.append(m)
        day = np.concatenate(rows_day)
        mins = np.concatenate(rows_min).astype(np.int64)
        n = len(day)
        first = np.r_[True, day[1:] != day[:-1]]
        vol_ = 0.0016 if kind == "equity" else 0.0008
        ret = rng.normal(0, vol_, n)
        gap = np.where(first, rng.normal(0, 0.006, n), 0.0)
        lc = np.log(p0) + np.cumsum(ret + gap)
        lo_ = lc - ret
        o, c = np.exp(lo_), np.exp(lc)
        h = np.maximum(o, c) * np.exp(np.abs(rng.normal(0, 0.0006, n)))
        l_ = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, 0.0006, n)))
        o, h, l_, c = tick(o), tick(h), tick(l_), tick(c)
        h = np.maximum.reduce([h, o, c])
        l_ = np.minimum.reduce([l_, o, c])
        self.day = day
        self.ts = (day.astype("datetime64[m]") + mins.astype("timedelta64[m]")).astype("datetime64[ns]")
        self.o, self.h, self.l, self.c = o, h, l_, c
        self.v = (2 * rng.integers(20, 4000, n)).astype(np.int64) if kind == "equity" else np.zeros(n, np.int64)

    def frame(self, d0=None, d1=None) -> pd.DataFrame:
        m = np.ones(len(self.day), bool)
        if d0 is not None:
            m &= self.day >= np.datetime64(d0, "D")
        if d1 is not None:
            m &= self.day <= np.datetime64(d1, "D")
        return pd.DataFrame({"timestamp": pd.DatetimeIndex(self.ts[m]).tz_localize(IST), "open": self.o[m],
                             "high": self.h[m], "low": self.l[m], "close": self.c[m],
                             "volume": self.v[m].astype(float)})


class World:
    def __init__(self, base: Path, seed: int = 11):
        self.base = Path(base)
        if self.base.exists():
            shutil.rmtree(self.base)
        self.root = self.base / "cache_daily"
        self.root.mkdir(parents=True)
        self.store = self.root / "intraday_3m"
        self.mods = self.base / "_mods"
        self.cal = calendar()
        rng = np.random.default_rng(seed)
        self.T: Dict[str, Truth] = {n: Truth(n, rng, self.cal) for n in SPECS}
        self.kite_rebased = {"SPLT": False, "SPLD": False, "DIVX": False}
        self.daily_rebased = {"SPLT": False, "SPLD": False, "DIVX": False}
        self.corrections: Dict[tuple, float] = {}
        self._write_mods()

    # ----- Kite's view -----
    DIV = 1 / 0.96

    def kite_factor(self, name: str, day: np.ndarray):
        """(Kite's raw price / the truth, Kite's raw volume / the truth) per session."""
        f, fv = np.ones(len(day)), np.ones(len(day))
        if name in ("OLDB", "OLDP"):
            f[day <= OLD_BASIS_END] = 2.0
            fv[day <= OLD_BASIS_END] = 0.5
        if name in ("SPLT", "SPLD") and not self.kite_rebased[name]:
            f[day < SPLIT_DAY] = 2.0
            fv[day < SPLIT_DAY] = 0.5
        if name == "DIVX" and not self.kite_rebased[name]:
            f[day < SPLIT_DAY] = self.DIV
        return f, fv

    def daily_factor(self, name: str, day: np.ndarray):
        f, fv = np.ones(len(day)), np.ones(len(day))
        if name in ("SPLT", "SPLD") and not self.daily_rebased[name]:
            f[day < SPLIT_DAY] = 2.0
            fv[day < SPLIT_DAY] = 0.5
        if name == "DIVX" and not self.daily_rebased[name]:
            f[day < SPLIT_DAY] = self.DIV
        return f, fv

    def kite_bars(self, name: str, d0, d1, asof) -> pd.DataFrame:
        T = self.T[name]
        a, b = np.datetime64(d0, "D"), min(np.datetime64(d1, "D"), np.datetime64(asof, "D"))
        i0, i1 = np.searchsorted(T.day, a), np.searchsorted(T.day, b, side="right")
        day = T.day[i0:i1]
        keep = day >= KITE_START
        if name == "GAPV":
            keep &= ~np.isin(day, np.array(GAPS))
        idx = np.arange(i0, i1)[keep]
        day = T.day[idx]
        f, fv = self.kite_factor(name, day)
        df = pd.DataFrame({"ts": T.ts[idx], "open": T.o[idx] * f, "high": T.h[idx] * f, "low": T.l[idx] * f,
                           "close": T.c[idx] * f, "volume": (T.v[idx] * fv).astype(np.int64)})
        for (nm, ts), v in self.corrections.items():
            if nm == name:
                df.loc[df["ts"] == np.datetime64(ts, "ns"), "volume"] = int(v)
        return df

    def expected_store(self, name: str, asof, gaps=True) -> pd.DataFrame:
        """What the store must hold for a series after a complete update: the truth on the daily cache's basis
        (Kite's bars where the daily cache is broken), from Kite's start (or listing) to asof, less vendor gaps."""
        T = self.T[name]
        m = (T.day >= KITE_START) & (T.day <= np.datetime64(asof, "D"))
        if name == "GAPV" and gaps:
            m &= ~np.isin(T.day, np.array(GAPS))
        f, fv = np.ones(m.sum()), np.ones(m.sum())
        if name in ("SPLT", "SPLD", "DIVX") and not self.kite_rebased[name]:
            f, fv = self.kite_factor(name, T.day[m])       # before the event both sides print the old level
        E = pd.DataFrame({"t": T.ts[m], "open": T.o[m] * f, "high": T.h[m] * f, "low": T.l[m] * f,
                          "close": T.c[m] * f, "volume": T.v[m] * fv})
        for (nm, ts), v in self.corrections.items():            # Kite's late corrections are what it prints now
            if nm == name:
                E.loc[E["t"] == np.datetime64(ts, "ns"), "volume"] = float(v)
        return E

    # ----- the daily cache -----
    def write_daily(self, asof, only=None) -> None:
        asof = np.datetime64(asof, "D")
        inst = {}
        for n, T in self.T.items():
            if only is not None and n not in only:
                continue
            kind, tsym = T.kind, T.tsym
            m = T.day <= asof
            day = T.day[m]
            if not len(day):
                continue
            G = pd.DataFrame({"day": day, "o": T.o[m], "h": T.h[m], "l": T.l[m], "c": T.c[m], "v": T.v[m]})
            g = G.groupby("day", sort=True)
            dd = g.size().index.to_numpy().astype("datetime64[D]")
            f, fv = self.daily_factor(n, dd)
            df = pd.DataFrame({"timestamp": pd.DatetimeIndex(dd.astype("datetime64[ns]")).tz_localize(IST),
                               "open": g["o"].first().to_numpy() * f, "high": g["h"].max().to_numpy() * f,
                               "low": g["l"].min().to_numpy() * f, "close": g["c"].last().to_numpy() * f,
                               "volume": (g["v"].sum().to_numpy() * fv) if kind == "equity" else np.nan})
            df.to_parquet(self.root / ("%s_daily.parquet" % n), index=False)
            ok = {"series_kind": kind, "exchange": "NSE", "tradingsymbol": tsym,
                  "first_timestamp": str(df["timestamp"].iloc[0]), "last_timestamp": str(df["timestamp"].iloc[-1]),
                  "listing_start": str(df["timestamp"].iloc[0]), "rows": int(len(df)), "has_volume": kind == "equity"}
            (self.root / ("%s_daily.ok.json" % n)).write_text(json.dumps(ok), encoding="utf-8")
        for n in IN_INSTRUMENT_CACHE:
            inst[SPECS[n][1].upper()] = TOKENS[n]
        (self.root / "instrument_cache.json").write_text(json.dumps(inst, indent=2), encoding="utf-8")
        # a futures series the cache also holds: never a 3-minute series
        fut = pd.DataFrame({"timestamp": pd.DatetimeIndex(self.cal[:5].astype("datetime64[ns]")).tz_localize(IST),
                            "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": 1.0})
        fut.to_parquet(self.root / "USDINR_daily.parquet", index=False)
        (self.root / "USDINR_daily.ok.json").write_text(json.dumps({"series_kind": "futures", "exchange": "CDS",
                                                                     "tradingsymbol": "USDINR"}), encoding="utf-8")

    # ----- production's 3-minute files (behind) -----
    def write_production(self) -> None:
        self.store.mkdir(parents=True, exist_ok=True)
        n = self.T["NIFTY50"].frame(KITE_START, PROD_END)
        n["volume"] = 0.0
        n.to_parquet(self.store / "NIFTY 50_3m.parquet", index=False)
        b = self.T["NIFTYBANK"].frame(KITE_START, PROD_END)
        b["volume"] = np.nan
        b.to_parquet(self.store / "NIFTYBANK_3m.parquet", index=False)
        a = self.T["AAA"].frame(KITE_START, PROD_END)
        t = a["timestamp"].dt.tz_localize(None)
        cut = (t.dt.normalize() == pd.Timestamp(str(CUT_DAY))) & (t.dt.hour * 60 + t.dt.minute > 12 * 60)
        a[~cut.to_numpy()].reset_index(drop=True).to_parquet(self.store / "AAA_3m.parquet", index=False)
        bb = self.T["BBB"].frame(KITE_START, PROD_END)
        bb["timestamp"] = bb["timestamp"].dt.tz_localize(None)
        bb["volume"] = bb["volume"].astype(np.int64)
        bb.to_parquet(self.store / "BBB_3m.parquet", index=False)
        o = self.kite_bars("OLDP", KITE_START, PROD_END, PROD_END)
        pd.DataFrame({"timestamp": pd.DatetimeIndex(o["ts"]).tz_localize(IST), "open": o["open"], "high": o["high"],
                      "low": o["low"], "close": o["close"], "volume": o["volume"].astype(float)}).to_parquet(
            self.store / "OLDP_3m.parquet", index=False)
        self.T["ILLQ"].frame(KITE_START, "2026-03-31").to_parquet(self.store / "ILLQ_3m.parquet", index=False)

    def _write_mods(self) -> None:
        self.mods.mkdir(parents=True, exist_ok=True)
        (self.mods / "intraday_cache.py").write_text(textwrap.dedent('''
            """TEST STAND-IN for production's intraday_cache (store, path_for, BAR_MIN) - NOT the production file."""
            from pathlib import Path
            CODE_VERSION = "intraday_cache TEST STAND-IN"
            BAR_MIN = 3


            def store(root):
                return Path(root) / "intraday_3m"


            def path_for(root, sym):
                return store(root) / f"{sym}_3m.parquet"
            '''), encoding="utf-8")


# ======================================================================================================== fake Kite
class TokenException(Exception):
    pass


class NetworkException(Exception):
    pass


class InputException(Exception):
    pass


class FakeKite:
    """Kite's instruments() and historical_data() over the world (thread-safe), with injectable trouble."""

    def __init__(self, world: World, asof, flaky: float = 0.0, expire_after: Optional[int] = None,
                 interrupt_after: Optional[int] = None, seed: int = 3):
        self.w = world
        self.asof = np.datetime64(asof, "D")
        self.flaky = flaky
        self.expire_after = expire_after
        self.interrupt_after = interrupt_after
        self.rng = np.random.default_rng(seed)
        self.lock = threading.Lock()
        self.n = 0
        self.log = []                   # (kind, token, d0, d1) of every answered call
        self.trouble = 0
        self.by_token = {TOKENS[k]: k for k in SPECS}

    def _tick(self):
        with self.lock:
            self.n += 1
            n = self.n
            bad = self.flaky and self.rng.random() < self.flaky
            pick = self.rng.random()
        if self.expire_after is not None and n > self.expire_after:
            raise TokenException("Incorrect `api_key` or `access_token`.")
        if self.interrupt_after is not None and n == self.interrupt_after:
            raise KeyboardInterrupt()
        if bad:
            with self.lock:
                self.trouble += 1
            if pick < 0.5:
                raise NetworkException("Too many requests")
            raise TimeoutError("Read timed out")

    def instruments(self, exchange="NSE"):
        self._tick()
        rows = []
        for n, (kind, tsym, _, _, delist) in SPECS.items():
            if delist:
                continue
            ts = "NEWNAME" if n == "RNMD" else tsym
            rows.append({"instrument_token": TOKENS[n], "tradingsymbol": ts, "exchange": "NSE",
                         "segment": "INDICES" if kind == "index" else "NSE", "instrument_type": "EQ"})
        rows.append({"instrument_token": 99, "tradingsymbol": "AAA", "exchange": "NSE", "segment": "NFO-FUT",
                     "instrument_type": "FUT"})
        with self.lock:
            self.log.append(("instruments", None, None, None))
        return rows

    def historical_data(self, instrument_token, from_date, to_date, interval, continuous=False, oi=False):
        self._tick()
        if interval != "3minute":
            raise InputException("invalid interval")
        if to_date - from_date > dt.timedelta(days=100):
            raise InputException("interval exceeds max limit: 100 days")
        name = self.by_token.get(int(instrument_token))
        if name is None or SPECS[name][4]:
            raise InputException("invalid token")
        d0, d1 = from_date.date(), to_date.date()
        with self.lock:
            self.log.append(("historical", name, d0, d1))
        B = self.w.kite_bars(name, d0, d1, self.asof)
        idx = pd.DatetimeIndex(B["ts"]).tz_localize(IST).to_pydatetime()
        index = SPECS[name][0] == "index"
        vol = np.zeros(len(B), np.int64) if index else B["volume"].to_numpy(np.int64)
        return [{"date": t, "open": float(o), "high": float(h), "low": float(l), "close": float(c), "volume": int(v)}
                for t, o, h, l, c, v in zip(idx, B["open"].to_numpy(), B["high"].to_numpy(), B["low"].to_numpy(),
                                            B["close"].to_numpy(), vol)]

    def asked(self, name=None):
        return [x for x in self.log if x[0] == "historical" and (name is None or x[1] == name)]
