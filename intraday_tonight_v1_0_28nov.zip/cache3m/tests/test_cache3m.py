"""
test_cache3m.py - cache3m v1.0.1 checks on a synthetic world (tests/c3_world.py). Nothing real is read or written.

    python tests\\test_cache3m.py

Ends with "VERIFIED (cache3m v1.0.1) - N checks" (exit 0) or lists the failures (exit 1).
"""
from __future__ import annotations

import contextlib
import datetime as dt
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
TOOL = HERE.parent
sys.path.insert(0, str(TOOL))
sys.path.insert(0, str(HERE))

import cache3m as C3  # noqa: E402
import c3_world as W  # noqa: E402

C3.BACKOFF = 0.002                     # retries without the real back-off pauses
for _v in ("CACHE_DAILY_ROOT", "INSTRUMENT_CACHE_FILE", "KITE_TOKEN_FILE", "CACHE_HISTORY_ANCHOR", "CACHE3M_NOW"):
    os.environ.pop(_v, None)            # the test never sees the real cache, token or anchor
RESULTS = []
FAILS = []
TMP = Path(tempfile.mkdtemp(prefix="c3test_"))


def check(ok, what):
    RESULTS.append(bool(ok))
    if not ok:
        FAILS.append(what)
        print("FAIL: %s" % what, flush=True)


def use_mods(world):
    """Only the world's stand-in intraday_cache is importable (production's, on PYTHONPATH via env_tradelab.bat,
    is hidden from the test)."""
    sys.modules.pop("intraday_cache", None)
    for p in list(sys.path):
        if p.endswith("_mods") or (p and Path(p, "intraday_cache.py").exists()):
            sys.path.remove(p)
    sys.path.insert(0, str(world.mods))


def run(world, args, kite=None, now=None):
    use_mods(world)
    if now:
        os.environ["CACHE3M_NOW"] = now
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = C3.main(list(args) + ["--root", str(world.root)], kite_obj=kite)
    return rc, buf.getvalue()


def update(world, kite, now, *extra):
    return run(world, ["update", "--from", "2023-06-01", "--rate", "5000", *extra], kite=kite, now=now)


def snapshot(folder: Path):
    out = {}
    if folder.exists():
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                out[str(p.relative_to(folder))] = (p.stat().st_size, p.stat().st_mtime_ns)
    return out


def stored(world, fname):
    return pd.read_parquet(world.store / fname)


def same_as_truth(world, name, fname, asof, vol="truth"):
    """The file holds exactly the expected bars (stamps, prices to 1e-9, volume)."""
    df = stored(world, fname)
    exp = world.expected_store(name, asof)
    t = C3.ist_naive(df["timestamp"])
    if len(t) != len(exp) or not np.array_equal(t, exp["t"].to_numpy()):
        return False, "stamps differ (%d stored vs %d expected)" % (len(t), len(exp))
    for c in ("open", "high", "low", "close"):
        if not np.allclose(df[c].to_numpy(float), exp[c].to_numpy(float), rtol=1e-9, atol=0):
            return False, "%s differs" % c
    v = pd.to_numeric(df["volume"], errors="coerce").to_numpy(float)
    if vol == "truth" and not np.allclose(v, exp["volume"].to_numpy(float), rtol=1e-9, atol=0):
        return False, "volume differs"
    if vol == "zero" and not (np.isfinite(v).all() and (v == 0).all()):
        return False, "volume not all 0"
    if vol == "nan" and not np.isnan(v).all():
        return False, "volume not all NaN"
    return True, ""


def report(world):
    return json.loads((world.store / "_cache3m" / "coverage_report.json").read_text(encoding="utf-8"))


def meta(world, name):
    return json.loads((world.store / "_cache3m" / "symbols" / ("%s.json" % name)).read_text(encoding="utf-8"))


t_start = time.time()
# ================================================================================================== 1. unit rules
rng = np.random.default_rng(5)
ok_cover = ok_span = ok_min = True
for trial in range(60):
    base = np.datetime64("2020-01-01", "D")
    k = int(rng.integers(1, 60))
    days = np.unique(base + rng.integers(0, 900, k).astype("timedelta64[D]"))
    W_ = C3.greedy_windows(days)
    covered = set()
    for a, b in W_:
        ok_span &= (b - a).days + 1 <= C3.MAX_DAYS and b >= a
        covered |= {d for d in days.tolist() if a <= d <= b}
    ok_cover &= covered == set(days.tolist())
    # the minimum number of windows (dynamic programming over the sorted days)
    ds = sorted(days.tolist())
    best = [0] * (len(ds) + 1)
    for i in range(len(ds) - 1, -1, -1):
        j = i
        while j + 1 < len(ds) and (ds[j + 1] - ds[i]).days <= C3.MAX_DAYS - 1:
            j += 1
        best[i] = 1 + min(best[m] for m in range(i + 1, j + 2))
    ok_min &= len(W_) == best[0]
check(ok_cover, "windows cover every requested session")
check(ok_span, "no request spans more than 99 calendar days (Kite allows 100 for 3-minute bars)")
check(ok_min, "the windows are the fewest possible (60 random sets against an exact count)")

mk = lambda s: dt.datetime.fromisoformat(s).replace(tzinfo=dt.timezone(dt.timedelta(hours=5, minutes=30)))
check(C3.last_complete_day(mk("2026-11-11T15:44:00")) == dt.date(2026, 11, 10) and
      C3.last_complete_day(mk("2026-11-11T15:45:00")) == dt.date(2026, 11, 11) and
      C3.last_complete_day(mk("2026-11-11T09:00:00")) == dt.date(2026, 11, 10),
      "today counts only from 15:45 (close 15:30 + 15 minutes)")

check(C3.error_kind(W.TokenException("x")) == "auth" and C3.error_kind(W.InputException("invalid token")) ==
      "instrument" and C3.error_kind(W.NetworkException("x")) == "transient" and
      C3.error_kind(TimeoutError("t")) == "transient" and C3.error_kind(Exception("Too many requests")) ==
      "transient" and C3.error_kind(ValueError("bad")) == "other" and
      C3.error_kind(W.InputException("interval exceeds max limit")) == "other",
      "Kite errors are classified: token -> stop, bad instrument -> unresolved, network/429 -> retry, else fail")


# basis judgement on hand-built session tables
def table(c3, o3, dc, do):
    idx = pd.Index(np.array(["2020-01-01", "2020-01-02", "2020-01-03", "2020-01-06"], dtype="datetime64[D]"))
    return pd.DataFrame({"c": c3, "o": o3, "dc": dc, "do": do}, index=idx)


blk = [(np.datetime64("2020-01-01"), np.datetime64("2020-01-03"), 0.5, 3)]
# Kite unadjusted: 3-minute prices 200 then 100 (a jump), daily 100 throughout
ok_a, _ = C3.judge_blocks(table([200, 200, 200, 101], [200, 200, 200, 100], [100, 100, 100, 101],
                                [100, 100, 100, 100]), blk)
# daily cache missed a split: 3-minute 100 throughout, daily 200 then 100
ok_b, nb = C3.judge_blocks(table([100, 100, 100, 101], [100, 100, 100, 100], [200, 200, 200, 101],
                                 [200, 200, 200, 100]), [(blk[0][0], blk[0][1], 2.0, 3)])
# the block reaches the last session
blk_last = [(np.datetime64("2020-01-02"), np.datetime64("2020-01-06"), 0.5, 3)]
ok_c, nc = C3.judge_blocks(table([200, 200, 200, 200], [200, 200, 200, 200], [100, 100, 100, 100],
                                 [100, 100, 100, 100]), blk_last)
check(len(ok_a) == 1 and not ok_b and "DAILY" in nb[0] and not ok_c and "latest" in nc[0],
      "basis blocks: adjusted only when the 3-minute bars jump at the block's end and the daily bars do not; a daily "
      "cache that missed a split or a block reaching the latest session leaves Kite's bars alone")

o = pd.DataFrame({"timestamp": pd.date_range("2024-01-01 09:15", periods=20, freq="3min", tz=W.IST),
                  "open": 100.0, "high": 101.0, "low": 99.0, "close": 100.0, "volume": 10.0})
n_ = o.copy()
for c in ("open", "high", "low", "close"):
    n_[c] = o[c] * 0.5
why, _ = C3.overlap_check(o, n_)
n2 = o.copy()
n2.loc[3, "volume"] = 11.0
n2.loc[4, "close"] = 100.05
why2, corr = C3.overlap_check(o, n2)
oa = o.copy()
oa["adj_factor"] = 0.5
for c in ("open", "high", "low", "close"):
    oa[c] = o[c] * 0.5
why3, _ = C3.overlap_check(oa, o)
check(why and not why2 and corr == 2 and not why3,
      "overlap check: one ratio on the closes = Kite re-based; two changed values = corrections; a stored "
      "adjustment is undone before comparing (raw = price / adj_factor)")

b_ = pd.DataFrame({"timestamp": pd.date_range("2024-01-01 09:15", periods=3, freq="3min"), "open": 1.0,
                   "high": 1.0, "low": 1.0, "close": 1.0, "volume": np.array([5, 6, 7], dtype=np.int64)})
nn = b_.copy()
nn["volume"] = np.array([8.0, 9.0, 10.0])
m_ = C3.merge_bars(b_, nn)
z_ = b_.assign(volume=0.0)
mz = C3.merge_bars(z_, nn.assign(volume=np.nan))
check(m_["volume"].dtype == np.int64 and list(m_["volume"]) == [8, 9, 10] and (mz["volume"] == 0).all(),
      "merging keeps an integer volume column integer and an index file's zero volumes zero")

st_ = C3.FileStats(np.array(["2024-01-%02d" % d for d in range(1, 11)], dtype="datetime64[D]"),
                   np.array([125, 125, 40, 125, 125, 125, 125, 50, 125, 125]),
                   np.array([927, 927, 700, 927, 927, 927, 927, 920, 927, 927]))
sx = C3.Series("X", "equity", "X", None)
sx.dates = st_.days
Cx = C3.Context(np.datetime64("2020-01-01"), np.datetime64("2024-02-01"))
th = C3.thin_sessions(st_, sx, Cx, [])
th2 = C3.thin_sessions(st_, sx, Cx, ["2024-01-03"])
check(list(th.astype(str)) == ["2024-01-03"] and not len(th2),
      "a session is cut short only with few bars AND an early last bar; once fetched again it is not asked again")

lk = TMP / "lock" / "run.lock"
first = C3.RunLock(lk)                               # kept alive: the lock must be let go at the end, not by luck
with first:
    try:
        with C3.RunLock(lk):
            second = "entered"
    except C3.Cache3mError:
        second = "refused"
with C3.RunLock(lk):
    again = True
lk.write_text("4242 2026-11-01T19:00:00")           # what a killed run leaves behind: the file, no lock on it
with C3.RunLock(lk):
    leftover_taken = True
check(second == "refused" and again and leftover_taken,
      "one update per store: a second is refused while one runs; the lock is let go at the end; a leftover "
      "run.lock (no process holding it) never blocks")
# v1.0.1: a run killed while it holds the lock (its window closed, the PC shut down) - the lock goes with the process
hold = subprocess.Popen([sys.executable, "-c", "import sys, time; sys.path.insert(0, sys.argv[1]); import cache3m as C3; "
                         "from pathlib import Path; l = C3.RunLock(Path(sys.argv[2])); l.__enter__(); "
                         "print('held', flush=True); time.sleep(300)", str(TOOL), str(lk)],
                        stdout=subprocess.PIPE, text=True)
held = hold.stdout.readline().strip()
try:
    with C3.RunLock(lk):
        while_held = "entered"
except C3.Cache3mError as e:
    while_held = "refused" if "another cache3m update is running" in str(e) else str(e)
hold.kill()
hold.wait()
with C3.RunLock(lk):
    after_kill = "entered"
check(held == "held" and while_held == "refused" and after_kill == "entered",
      "another process holding the lock: refused; that process killed mid-run: the next run starts at once")

# ================================================================================================== 2. the world
w = W.World(TMP / "w1")
w.write_daily("2026-10-30")
w.write_production()
NOW_A = "2026-10-30T18:00:00"

# ----- refusals -----
os.environ.pop("CACHE_DAILY_ROOT", None)
use_mods(w)
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    rc0 = C3.main(["inspect"])
check(rc0 == 3 and "REFUSED" in buf.getvalue(), "no --root and no CACHE_DAILY_ROOT: refused (no silent default)")
rc, out = run(w, ["inspect", "--store", str(TMP / "nowhere")], now=NOW_A)
rc_b, out_b = run(w, ["inspect"], now=NOW_A)
sys.modules.pop("intraday_cache", None)
sys.path.remove(str(w.mods))
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    rc_c = C3.main(["inspect", "--root", str(w.root)])
check(rc_b == 0 and rc_c == 3 and "intraday_cache" in buf.getvalue(),
      "production's intraday_cache is required unless --store is given (refused with the reason)")

# ----- inspect and check-only write nothing -----
before = snapshot(w.base)
rc, out = run(w, ["inspect", "--from", "2023-06-01"], now=NOW_A)
rc2, out2 = update(w, None, NOW_A, "--check-only")
after = snapshot(w.base)
check(rc == 0 and rc2 == 0 and before == after, "inspect and update --check-only write nothing")
check("6 of 15 series have a 3-minute file" in out and "most behind" in out and "CHECK ONLY" in out2,
      "inspect counts the files and the series behind; check-only prints the plan")
check("tz-aware" in out and "5 of 6 existing files are tz-aware" in out,
      "inspect reads each file's timestamp convention (one production file here is naive)")

# ----- a Ctrl+C mid-run, then an expired token: nothing corrupt, the report still written -----
k1 = W.FakeKite(w, "2026-10-30", interrupt_after=40)
rc, out = update(w, k1, NOW_A)
bad = [p for p in w.store.rglob("*.tmp")]
readable = True
for p in w.store.glob("*.parquet"):
    try:
        pd.read_parquet(p)
    except Exception:
        readable = False
check(rc == 5 and "interrupted" in out and "3-MINUTE CACHE" in out and not bad and readable,
      "Ctrl+C: exit 5, the coverage report printed, every file readable, no half-written file")
seq = [x for x in k1.asked() if x[1] != "NIFTY50"]
recent = [(dt.date(2026, 10, 30) - x[3]).days <= 120 for x in seq]
first_old = recent.index(False) if False in recent else len(recent)
check(k1.asked()[0][1] == "NIFTY50" and len(seq) > 20 and first_old >= 20 and not any(recent[first_old:]),
      "newest first: NIFTY, then every series brought up to date, and only then older history")
k2 = W.FakeKite(w, "2026-10-30", expire_after=30)
rc, out = update(w, k2, NOW_A)
check(rc == 4 and "Kite token expired" in out and not list(w.store.rglob("*.tmp")),
      "an expired token stops the run (exit 4) and says how to resume; nothing half-written")
rc, out = update(w, W.FakeKite(w, "2026-10-30"), NOW_A, "--max-hours", "0.0000001")
check(rc == 5 and "time budget" in out, "--max-hours stops cleanly (exit 5)")
with C3.RunLock(w.store / "_cache3m" / "run.lock"):
    rc, out = update(w, W.FakeKite(w, "2026-10-30"), NOW_A)
check(rc == 3 and "another cache3m update" in out, "a second update while one runs is refused (exit 3)")

# ----- the backlog, through a flaky Kite (429s and timeouts) -----
k3 = W.FakeKite(w, "2026-10-30", flaky=0.12)
rc, out = update(w, k3, NOW_A, "--workers", "6")
R = report(w)
check(rc == 0, "backlog run completes (exit 0)%s" % ("" if rc == 0 else ": " + out[-1500:]))
check(k3.trouble >= 2 and R["retries"] >= k3.trouble and not R["failed"],
      "Kite's 429s and timeouts are retried (%d injected, %d retried), nothing failed" % (k3.trouble, R["retries"]))
asked_all = k3.asked()
check(all((d1 - d0).days + 1 <= 99 for _, _, d0, d1 in asked_all) and
      all(d1 <= dt.date(2026, 10, 30) for _, _, d0, d1 in asked_all),
      "every request spans at most 99 days and none reaches past the last completed session")
check(R["history_start"] == "2024-01-02" and
      not [x for x in asked_all if x[1] != "NIFTY50" and x[3] < dt.date(2024, 1, 2)],
      "Kite's 3-minute history starts where NIFTY's does (2024-01-02): no stock is asked for earlier sessions")
ok_all, why_all = True, []
for name, fname, vol in (("NIFTY50", "NIFTY 50_3m.parquet", "zero"), ("NIFTYBANK", "NIFTYBANK_3m.parquet", "nan"),
                         ("INDIAVIX", "INDIA VIX_3m.parquet", "nan"), ("AAA", "AAA_3m.parquet", "truth"),
                         ("BBB", "BBB_3m.parquet", "truth"), ("OLDB", "OLDB_3m.parquet", "truth"),
                         ("OLDP", "OLDP_3m.parquet", "truth"), ("SPLT", "SPLT_3m.parquet", "truth"),
                         ("SPLD", "SPLD_3m.parquet", "truth"), ("DIVX", "DIVX_3m.parquet", "truth"),
                         ("GAPV", "GAPV_3m.parquet", "truth"),
                         ("ILLQ", "ILLQ_3m.parquet", "truth"), ("IPOX", "IPOX_3m.parquet", "truth"),
                         ("RNMD", "RNMD_3m.parquet", "truth")):
    good, why = same_as_truth(w, name, fname, "2026-10-30", vol)
    if not good:
        ok_all = False
        why_all.append("%s: %s" % (name, why))
check(ok_all, "every series holds exactly the expected bars - stamps, prices, volumes (14 series)%s" % (
    "" if ok_all else ": " + "; ".join(why_all)))
check(not (w.store / "NIFTY BANK_3m.parquet").exists() and (w.store / "NIFTYBANK_3m.parquet").exists() and
      (w.store / "INDIA VIX_3m.parquet").exists() and not (w.store / "INDIAVIX_3m.parquet").exists(),
      "an index file existing under its cache name stays there; a new index file takes its Kite name")
check(not (w.store / "DELS_3m.parquet").exists() and "DELS" in R["unresolved"] and
      meta(w, "DELS").get("unresolved") and not (w.store / "USDINR_3m.parquet").exists(),
      "a delisted series Kite does not know is recorded unresolved; futures are not 3-minute series")
check(meta(w, "RNMD")["token_source"] == "daily cache" and meta(w, "GAPV")["token_source"] == "Kite NSE list",
      "tokens: the daily cache's own first (a renamed stock still resolves), else Kite's NSE list")
bb = stored(w, "BBB_3m.parquet")
aa = stored(w, "AAA_3m.parquet")
check(getattr(bb["timestamp"].dt, "tz", None) is None and bb["volume"].dtype == np.int64 and
      str(aa["timestamp"].dt.tz) == W.IST,
      "each file keeps its own convention: BBB naive with integer volume, AAA tz-aware IST")
cut = aa[C3.ist_naive(aa["timestamp"]).astype("datetime64[D]") == W.CUT_DAY]
check(len(cut) == 125 and "2025-03-12" in meta(w, "AAA")["thin_checked"],
      "AAA's session cut short at 12:00 was fetched again (125 bars) and recorded")
ob = stored(w, "OLDB_3m.parquet")
odays = C3.ist_naive(ob["timestamp"]).astype("datetime64[D]")
adj = ob["adj_factor"].to_numpy(float)
check(np.allclose(adj[odays <= W.OLD_BASIS_END], 0.5) and np.allclose(adj[odays > W.OLD_BASIS_END], 1.0) and
      meta(w, "OLDB")["adjustments"][0]["factor"] == 0.5,
      "OLDB: Kite's unadjusted 2024 sessions put on the daily cache's basis (adj_factor 0.5; raw = price / 0.5)")
arch = sorted((w.store / "_cache3m" / "replaced").glob("OLDP_*_basis.parquet"))
arow = pd.read_parquet(arch[0]) if arch else pd.DataFrame()
exp_raw = w.kite_bars("OLDP", W.KITE_START, W.OLD_BASIS_END, W.OLD_BASIS_END)
check(len(arch) == 1 and len(arow) == len(exp_raw) and np.allclose(arow["close"].to_numpy(float),
                                                                   exp_raw["close"].to_numpy(float)),
      "OLDP: the production file's unadjusted rows were archived as they were before being adjusted")
mg = meta(w, "GAPV")
check(sorted(mg["vendor_empty"]) == sorted(str(d) for d in W.GAPS) and
      next(r for r in R["per_symbol"] if r["symbol"] == "GAPV")["vendor_gaps"] == 5,
      "GAPV: the 5 sessions Kite has no bars for are recorded as vendor gaps")
ip = stored(w, "IPOX_3m.parquet")
check(str(C3.ist_naive(ip["timestamp"]).astype("datetime64[D]").min()) == "2025-09-15",
      "IPOX starts at its listing")
check(R["totals"]["missing"] == 0 and not R["stale"],
      "nothing is missing or behind after the backlog run (%s missing, stale %s)" % (R["totals"]["missing"],
                                                                                      R["stale"]))
cat = json.loads((w.store / "_cache3m" / "catalog.json").read_text(encoding="utf-8"))
check(cat["series"]["NIFTY50"]["file"] == "NIFTY 50_3m.parquet" and len(cat["series"]) == 15,
      "the catalog maps every series to its file")
check(not list(w.store.rglob("*.tmp")), "no temporary files left")

# ----- verify (read only) -----
before = snapshot(w.store)
rc, out = run(w, ["verify", "--from", "2023-06-01"], now=NOW_A)
V = json.loads((w.store / "_cache3m" / "verify_report.json").read_text(encoding="utf-8"))
after = snapshot(w.store)
changed = {k for k in set(before) | set(after) if before.get(k) != after.get(k)}
check(rc == 0 and changed == {os.path.join("_cache3m", "verify_report.json")},
      "verify writes only its report")
Tv = V["totals"]
muh = sum(int((w.T[n].day == W.MUHURAT).sum()) for n in W.SPECS if n != "DELS")
check(Tv["off_daily"] == 0 and Tv["no_daily_bar"] == 0 and Tv["duplicates"] == 0 and Tv["ohlc_violations"] == 0
      and not V["basis_blocks"] and Tv["off_grid_bars"] == muh and Tv["missing"] == 0,
      "verify: every session on its daily bar, nothing missing, no duplicates or OHLC faults, no basis block left; "
      "the Muhurat session's evening bars are the only off-grid bars (%d)" % muh)

# ----- a second run the same evening asks Kite nothing -----
k4 = W.FakeKite(w, "2026-10-30")
rc, out = update(w, k4, NOW_A)
check(rc == 0 and k4.n == 0, "a second run the same evening makes no request (%d made)" % k4.n)

# ================================================================================================== 3. split weekend
w.kite_rebased.update({"SPLT": True, "SPLD": True, "DIVX": True})
w.daily_rebased.update({"SPLT": True, "DIVX": True})       # SPLD's daily cache misses it
w.write_daily("2026-11-03")
last_bar = np.datetime64("2026-10-30T15:27", "ns")
w.corrections[("AAA", last_bar)] = 123456
NOW_B = "2026-11-03T18:00:00"
k5 = W.FakeKite(w, "2026-11-03")
rc, out = update(w, k5, NOW_B)
R = report(w)
per = {}
for _, nm, d0, d1 in k5.asked():
    per[nm] = per.get(nm, 0) + 1
plain = [n for n in W.SPECS if n not in ("SPLT", "SPLD", "DIVX", "DELS")]
check(rc == 0 and all(per.get(n) == 1 for n in plain) and "DELS" not in per,
      "an ordinary evening: one request per active series; the unresolved series is not asked again")
check(R["fetched"]["SPLT"]["full_refetch"] and R["fetched"]["SPLD"]["full_refetch"] and per["SPLT"] >= 10 and
      len(list((w.store / "_cache3m" / "replaced").glob("SPLT_*_rebased.parquet"))) == 1,
      "Kite re-based SPLT and SPLD after the split: noticed on the overlap, fetched whole, old file archived")
g4, _ = same_as_truth(w, "DIVX", "DIVX_3m.parquet", "2026-11-03")
check(R["fetched"]["DIVX"]["full_refetch"] and g4 and "adjustments" not in meta(w, "DIVX"),
      "a 4% re-basing (an extraordinary dividend, prices only) is caught on the overlap too and fetched whole")
g1, _ = same_as_truth(w, "SPLT", "SPLT_3m.parquet", "2026-11-03")
g2, _ = same_as_truth(w, "SPLD", "SPLD_3m.parquet", "2026-11-03")
nd = meta(w, "SPLD").get("basis_note") or ""
check(g1 and g2 and "DAILY" in nd and "adjustments" not in meta(w, "SPLD"),
      "SPLD's daily cache missed the split: Kite's bars kept as printed and the report says the jump is in the "
      "daily bars (never moved onto a broken daily basis)")
aa = stored(w, "AAA_3m.parquet")
vv = aa.loc[C3.ist_naive(aa["timestamp"]) == last_bar, "volume"]
check(len(vv) == 1 and float(vv.iloc[0]) == 123456.0 and R["fetched"]["AAA"]["corrections"] >= 1,
      "Kite's late correction of the last bar is taken up through the overlap (and counted)")
check("NOTE SPLD" in out, "the coverage report prints the SPLD note")

# ================================================================================================== 4. daily fixed
w.daily_rebased.update({"SPLD": True})
w.write_daily("2026-11-10")
k6 = W.FakeKite(w, "2026-11-10")
rc, out = update(w, k6, "2026-11-10T18:00:00")
check(rc == 0 and not meta(w, "SPLD").get("basis_note") and
      not [r for r in report(w)["per_symbol"] if r.get("basis_note")],
      "once the daily cache re-bases SPLD, its history is checked again and the note clears")
g3, why3 = same_as_truth(w, "SPLD", "SPLD_3m.parquet", "2026-11-10")
check(g3, "SPLD still holds exactly Kite's bars %s" % why3)

# ================================================================================================== 5. the clock
k7 = W.FakeKite(w, "2026-11-11")
rc, out = update(w, k7, "2026-11-11T14:00:00")
check(rc == 0 and k7.n == 0, "at 14:00 today's session is not complete: nothing is asked")
k8 = W.FakeKite(w, "2026-11-11")
rc, out = update(w, k8, "2026-11-11T16:05:00")
aa = stored(w, "AAA_3m.parquet")
has11 = (C3.ist_naive(aa["timestamp"]).astype("datetime64[D]") == np.datetime64("2026-11-11")).sum()
check(rc == 0 and has11 == 125 and not report(w)["stale"],
      "the daily cache has not run yet today: NIFTY's 3-minute bars show the session exists and every active "
      "series gets it anyway (%d AAA bars)" % has11)
w.write_daily("2026-11-11")
k9 = W.FakeKite(w, "2026-11-11")
rc, out = update(w, k9, "2026-11-11T18:00:00")
check(rc == 0 and k9.n == 0, "after the daily cache catches up, nothing more is asked")
okf = True
for name in ("AAA", "OLDB", "SPLT", "GAPV", "IPOX", "RNMD"):
    good, why = same_as_truth(w, name, "%s_3m.parquet" % name, "2026-11-11")
    okf &= good
check(okf, "after five evenings the files still equal the truth")
w.write_daily("2026-11-13")
rc, out = update(w, W.FakeKite(w, "2026-11-13"), "2026-11-13T18:00:00")
k_sat = W.FakeKite(w, "2026-11-14")
rc2, out2 = update(w, k_sat, "2026-11-14T18:00:00")
check(rc == 0 and rc2 == 0 and k_sat.n == 0, "a Saturday evening asks nothing (NIFTY looks ahead on weekdays only)")

# ================================================================================================== 6. odd stores
w2 = W.World(TMP / "w2")
w2.write_daily("2026-10-30")
w2.write_production()
(w2.store / "ILLQ_3m.parquet").write_bytes(b"not a parquet file")
pd.read_parquet(w2.store / "NIFTYBANK_3m.parquet").to_parquet(w2.store / "NIFTY BANK_3m.parquet", index=False)
raw_before = (w2.store / "ILLQ_3m.parquet").read_bytes()
k10 = W.FakeKite(w2, "2026-10-30")
rc, out = update(w2, k10, NOW_A, "--symbols", "AAA", "ILLQ", "NIFTYBANK")
R2 = report(w2)
asked_names = {x[1] for x in k10.asked()}
check(rc == 2 and "unreadable" in R2["failed"].get("ILLQ", "") and
      (w2.store / "ILLQ_3m.parquet").read_bytes() == raw_before and "ILLQ" not in asked_names,
      "an unreadable file is reported as failed (exit 2) and left untouched")
check(asked_names <= {"AAA", "NIFTY50", "NIFTYBANK"} and "AAA" in asked_names,
      "--symbols limits the run to those series (and NIFTY50, the calendar)")
check(R2["index_files_under_two_names"] == ["NIFTYBANK_3m.parquet"] and
      len(pd.read_parquet(w2.store / "NIFTY BANK_3m.parquet")) > len(pd.read_parquet(w2.store /
                                                                                       "NIFTYBANK_3m.parquet")),
      "an index under two names: the Kite-name file is kept current, the other reported and left alone")

w2.write_daily("2026-11-03")
k12 = W.FakeKite(w2, "2026-11-03", expire_after=1)
rc, out = update(w2, k12, "2026-11-03T18:00:00", "--symbols", "AAA", "NIFTYBANK")
check(rc == 4 and "AAA" in report(w2)["stale"] and "STALE" in out,
      "a run stopped before a series was brought up to date names it STALE")

# ----- --recheck-gaps asks Kite again -----
k11 = W.FakeKite(w, "2026-11-11")
rc, out = update(w, k11, "2026-11-11T18:00:00", "--recheck-gaps", "--symbols", "GAPV")
gap_asks = [x for x in k11.asked("GAPV")]
check(rc == 0 and gap_asks and meta(w, "GAPV")["vendor_empty"] == sorted(str(d) for d in W.GAPS),
      "--recheck-gaps asks for the recorded vendor gaps again (still empty, still recorded)")

shutil.rmtree(TMP, ignore_errors=True)
n = len(RESULTS)
print("")
if FAILS:
    print("FAILED (%s) - %d of %d checks failed:" % (C3.VERSION, len(FAILS), n))
    for f in FAILS:
        print("  - " + f)
    sys.exit(1)
print("VERIFIED (%s) - %d checks, %.0f s, pandas %s, numpy %s" % (C3.VERSION, n, time.time() - t_start,
                                                                 pd.__version__, np.__version__))
sys.exit(0)
