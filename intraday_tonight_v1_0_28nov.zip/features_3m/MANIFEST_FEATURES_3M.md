# MANIFEST - features_3m v1.0 (23 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\features_3m\` (new; beside cache3m). Nothing goes into bigmove_deploy.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `features_3m.py` | `e511d1318a919039` | 94859 |
| `features_3m_daily.bat` | `0e3370ffe33526d6` | 348 |
| `tests\test_features_3m.py` | `be2b8552b0bb7fa6` | 25352 |
| `tests\f3_world.py` | `b79442f458c87d55` | 13871 |
| `README_FEATURES_3M.md` | `41004f482d6ffb25` | 7705 |
| `MANIFEST_FEATURES_3M.md` | (this file) | |

## Verified

- `python tests\test_features_3m.py`: VERIFIED (features_3m v1.0) - 38 checks, on pandas 2.3.3 / numpy 2.4.1 (Karan's
  set; also with a production intraday_cache that raises on import on PYTHONPATH and CACHE_DAILY_ROOT set) and
  pandas 3.0.5 / numpy 2.5.3. The 2-worker build runs as `python features_3m.py build --workers 2` in its own
  process with spawned workers - the Windows way.
- The review's acceptance tests: (1) files physically cut at a bar give exactly the stored snapshot, ranks included
  (3 sessions x times, and any bar: 10:00); (2) a spike in the bar stamped 10:15 leaves every 10:15 value unchanged
  and appears at 10:18; (3) a 2x basis fault is flagged, blank, unranked, and feeds no history. Added: (4) changing
  today's daily high/low/close/volume and everything after 13:15 moves no snapshot up to 13:15, no rank and no
  earlier day row - this caught and fixed a real leak (a session's own rvol blanked by its own daily bar).
- Mutation test: 32 deliberate bugs; 29 caught (the clock, event minutes, retest rules, opening ranges, gap fill,
  drawdown order, VWAP, signed volume, efficiency, history windows, fault masking, ranks, peer counts, the home
  index's month boundary, incremental builds, labels, bands). The 3 not caught cannot change any output: the
  first-bar fallback restores the open; a swing's confirmation bar cannot close above its pivot; blanked faulty
  rows have no return to rank.
- Timing: 1.28 s of work per 11-year stock (2,750 sessions); about 20 GB of tables for 2,300 stocks (estimated
  from the test world).

## Production contact

- Reads: the daily cache and the 3-minute store (via production's intraday_cache.store and cache3m's catalog),
  read only. Writes only under --out (default C:\QuantData\features_3m); refuses an --out inside the daily cache
  or bigmove_deploy.

## History

- v1.0 (23 Nov 2026): first version.
