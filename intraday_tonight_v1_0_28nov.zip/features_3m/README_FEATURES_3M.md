# features_3m v1.0 — what was known at every completed 3-minute bar

Reads the 3-minute store that cache3m maintains (and the daily cache), read only, and writes feature tables under
`C:\QuantData\features_3m\`. Nothing goes into `bigmove_deploy` or the daily cache.

## Files (copy all into `C:\Users\karanvsi\PyCharmMiscProject\features_3m\`)

| file | what |
|---|---|
| `features_3m.py` | the tool: `build`, `asof`; and `load()` for reading the tables from your own scripts |
| `features_3m_daily.bat` | the evening build (CRLF): run it after `cache3m_daily.bat` |
| `tests\test_features_3m.py`, `tests\f3_world.py` | 38 checks on a synthetic world |
| `README_FEATURES_3M.md`, `MANIFEST_FEATURES_3M.md` | this file, checksums |

## Run

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\features_3m
python tests\test_features_3m.py
python features_3m.py build
```

The first build computes every session of every series (about 1.3 s of work per 11-year stock; roughly 13 minutes on
4 worker processes for ~2,300 stocks, and about 20 GB of tables — both estimated, not measured on your data). After
that, `build` recomputes only the last 5 sessions and the new ones (minutes). A stock whose past changed (cache3m
re-fetched or adjusted it, or the daily cache re-based it) is recomputed in full automatically; that evening the
cross-stock ranks of every year are refreshed too (several extra minutes). Changing the snapshot times or the history
windows needs `--full`. (Per-stock files are named `<NAME>_f3.parquet`: Windows reserves names like CON and AUX.)

## The clock (no peeking)

- A bar stamped 10:15 runs 10:15–10:18 and is known at 10:18. A value **at 10:15** uses the bars that ended by 10:15
  (the last is the bar stamped 10:12).
- Known at 09:15: the official open (pre-open auction) and every earlier session's daily bar. **Not** known before
  15:30: today's daily high, low, close and volume — they appear only in the day table.
- Event times are minutes after 09:15 at which the event became known (the end of its bar): 33 = the bar stamped
  09:45, known at 09:48.
- The order of two things inside one bar is unknowable: a retest or a failure must come in a later bar than the break;
  a fall from a bar's own high to its own low is not counted as a drawdown.

## Tables (`load(out, table, columns, symbols, start, end, times)` reads any of them)

| table | one row per | known |
|---|---|---|
| `snap\<YEAR>\<NAME>_f3.parquet` | stock, session, snapshot time (09:30 09:45 10:15 11:15 13:15 14:45) | at that time |
| `day\<YEAR>\<NAME>_f3.parquet` | stock, session | at 15:30 → usable from the next open |
| `xs\xs_<YEAR>.parquet` | stock, session, time (1530 = the day) | with its row |
| `market\market_<YEAR>.parquet` | session, time | with its row |
| `home_index.parquet` | stock, month | before the month starts |
| `contract.json` | every column: table, meaning, unit, when known, exact or proxy | |

`python features_3m.py asof --date 2026-11-20 --time 10:00 --symbols RELIANCE TCS` gives every snapshot value at
**any** completed bar, from files cut at that bar (with several stocks, the ranks are among them; `--csv` writes them).

## What is in it (about 130 snapshot and 255 day columns)

- **Path:** return since the open and since yesterday's close, running high/low and minutes since each, which came
  first, range so far (also in ATRs), largest chronological drawdown and run-up, gain given back, loss recovered,
  signed and absolute path efficiency.
- **Opening gap:** gap in % and ATRs, where the open sat in yesterday's range, share filled, minute filled, the
  move in the gap's direction before the fill, reclaim / loss of the open.
- **Levels and event order:** for yesterday's high/low/close, the 5-session high/low, the open, the 15- and 30-minute
  opening ranges, VWAP and confirmed swing highs/lows — distance now; minutes since the first close beyond; whether a
  later bar retested and held, or closed back (failed); crossings; time beyond. The day table keeps the minute of each
  first touch / break / retest / failure and the level at the break.
- **Volatility:** realized volatility (also against ATR), downside share, worst and best bar, largest bar's share;
  day: bipower, jump share, skew, kurtosis, Parkinson, first-hour share.
- **Participation:** VWAP distance, slope, time above, crossings; cumulative volume against the stock's own volume
  curve at that minute; rupees traded; volume in the 3 largest bars; signed (up-bar minus down-bar) volume; streaks;
  day: volume in the first and last 30 minutes, the busiest bar, concentration.
- **Compression and breaks:** range of the last 5 / 10 bars against the stock's normal bar range, inside-bar runs,
  position in the previous 30 minutes' box, minutes since a box break, its volume against normal, whether it failed.
- **Thin trading and stress:** bars missing, longest gap, minutes since the last print, one-price bars, spread
  estimates, price impact, bars at a circuit band.
- **Market and sector:** NIFTY's return, return relative to NIFTY, intraday beta and correlation, stock-specific
  volatility, return on NIFTY's up and down bars; the home index's return and the return relative to it.
- **Same clock, prior sessions:** for return since the open, range in ATRs, realized volatility, VWAP distance and
  coverage — the median, today's percentile and the spread over the prior 60 sessions at the same minute, and how
  many sessions that rests on.
- **Ranks across stocks at the same moment:** percentile of return, return since yesterday, relative volume, range,
  VWAP distance, downside share, return relative to NIFTY, volatility, signed volume; the peer count; the home-index
  group's size, share up and the stock's rank in it. Market table: breadth (share up, above VWAP, broke yesterday's
  high / low) and medians.
- **Day only:** segment returns (open→09:45→11:15→13:15→14:45→close, last 30 minutes), the closing session's move,
  minutes of the day's high and low, 5- and 20-session averages and 20-session z-scores of the main day values.
- **Outcomes, never inputs:** `label_r_to_eod`, `label_r_to_official_close` in the snapshot table — what happened
  after that time, for intraday research.

## Proxies and limits (stated in `contract.json`)

- VWAP is built from bars: Σ(typical price × volume) / Σ volume, typical price (H+L+C)/3. Spread, signed volume and
  price impact are estimates. Circuit bands use stage E's rule (a price within ₹0.011 of the previous close ×
  (1 ± 2/5/10/20%)); the exact band of a stock is not in the data.
- The home index is statistical: the sector index whose NIFTY-adjusted daily returns track the stock's most closely
  over the 250 sessions before the month (correlation ≥ 0.10, ≥ 120 shared sessions), refreshed monthly. There is no
  membership history.
- Ranks before ~2019 are among the stocks Kite still serves (delisted stocks are missing): survivors. Each rank row
  carries its peer count.
- A session whose 3-minute bars disagree with the daily bars on price level (a basis fault: a split cache3m could not
  put right) is flagged (`basis_open_ok`, `basis_ok`), left blank and never ranked; faulty sessions feed no one's
  history.
- Not obtainable from 3-minute bars: the order book, the real spread, trade sizes, the 09:00–09:08 pre-open auction.

## Next (v1.1)

The trade-relative view for the frozen tree: per trade and decision time, the path since the fill (P&L, best and
worst so far, time at each, giveback, recovery, sessions left) with the M5 forecast known then; whole-trade outcomes
only as `label_*`.
