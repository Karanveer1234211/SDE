#!/usr/bin/env python3
"""
features_3m.py - features_3m v1.0: what was known at every completed 3-minute bar, for every stock and index in the
3-minute store (cache3m), each session's full record, and same-time ranks across stocks.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\features_3m
    python tests\\test_features_3m.py
    python features_3m.py build                     first time: every session; afterwards only the new ones
    python features_3m.py asof --date 2026-11-20 --time 10:00 --symbols RELIANCE TCS

THE CLOCK
=========
A bar stamped 10:15 runs 10:15-10:18 and is known at 10:18. A value "at 10:15" uses only bars that ENDED by 10:15 (the
last is the bar stamped 10:12). The official open (the daily cache's, from the pre-open auction) is known at 09:15,
earlier sessions' daily bars are known; today's daily high, low, close and volume are NOT - they appear only in the
day table, which is known at 15:30 and usable from the next open. Event times are stored as the minute after 09:15 at
which the event became known (the END of the bar it happened in).

TABLES (under --out, default <the daily cache's parent>\\features_3m)
  snap\\<YEAR>\\<NAME>_f3.parquet per session and snapshot time (default 09:30 09:45 10:15 11:15 13:15 14:45): what
                                was known then. label_* columns are what happened AFTER (to 15:30): outcomes for
                                research, never inputs.
  day\\<YEAR>\\<NAME>_f3.parquet  per session, known at 15:30: the 15:30 snapshot, the event chronology (minute each
                                level was first touched, broken, retested, failed; crossings), segment returns,
                                volatility, volume profile, liquidity and band proxies, rolling history.
  xs\\xs_<YEAR>.parquet          per stock, session and time: percentile ranks (0..1) among the stocks with data at
                                that moment, the home-index group's breadth and rank, peer counts.
  market\\market_<YEAR>.parquet  per session and time: breadth over all stocks with data then.
  home_index.parquet            each stock's statistical sector by month (a proxy: no membership history exists).
  contract.json                 every column: table, meaning, unit, when known, exact or proxy.
`asof` computes the same values at ANY completed bar from files physically cut at that bar (and today's daily bar
reduced to its open).

PROXIES (3-minute OHLCV cannot give the exact thing): VWAP = sum(typical price x volume) / sum(volume), typical price
(H+L+C)/3 of each bar; spread (Corwin-Schultz, Abdi-Ranaldo) and signed volume (up-bar minus down-bar volume); circuit
bands (stage E's rule: a price within Rs 0.011 of round(previous close x (1 +- 2/5/10/20%), 2)); home index. The order
of two events inside ONE bar is unknowable: a retest or failure must come in a LATER bar than the break, and a fall
inside one bar from its own high to its own low is not counted as a drawdown.

DATA BASIS: the 3-minute store is on the daily cache's corporate-action basis (cache3m). A session whose first bar's open
disagrees with the official open (1.5% when the first bar is 09:15, 15% when the first trade comes later), or whose
high and low sit on one ratio to the daily bar (beyond 0.5%), is a basis fault: its values are left blank (flags kept)
and it is never ranked - a split must not pass for a gap.

Reads the daily cache and the 3-minute store, read only. Writes only under --out.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import hashlib
import importlib
import json
import os
import re
import sys
import time
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

VERSION = "features_3m v1.0"
ENGINE = "f3-engine-1"
IST = "Asia/Kolkata"
NB = 125
BAR = 3
START = 9 * 60 + 15
SNAP_TIMES = ("09:30", "09:45", "10:15", "11:15", "13:15", "14:45")
HIST_W = 60                     # same-clock history: prior sessions
ROLL_W = (5, 20)                # day-table rolling means (sessions, today included)
Z_W = 20                        # day-table z-scores against the prior 20 sessions
PRIOR = 20                      # normal volume curve / bar range / slot volume: prior sessions
MIN_PRIOR = 10
ATR_N = 14
TOL = 0.001                     # a retest comes within 0.1% of the level
BANDS = np.array([0.02, 0.05, 0.10, 0.20])
BAND_TOL = 0.011
OPEN_TOL = 0.015
LATE_TOL = 0.15
BASIS_TOL = 0.005
BOX = 10                        # the box = the previous 10 bars (30 minutes)
BOX_FAIL = 5                    # a box break fails when a close is back inside within 5 bars
SWING = 2                       # a swing high: higher than 2 bars each side; confirmed 2 bars later
GAP_MIN = 0.001
HOME_W = 250
HOME_MIN = 120
HOME_MIN_CORR = 0.10
MASTER = "NIFTY50"
SECTORS = ("NIFTYBANK", "NIFTYAUTO", "NIFTYFMCG", "NIFTYIT", "NIFTYMETAL", "NIFTYPHARMA", "NIFTYREALTY",
           "NIFTYENERGY", "NIFTYPSUBANK", "NIFTYFINSERVICE", "NIFTYMEDIA", "NIFTYCONSUMPTION", "NIFTYINFRA")
UP_LV = ("pdh", "pwh", "or15h", "or30h", "swh")
DN_LV = ("pdl", "pwl", "or15l", "or30l", "swl")
TWO_LV = ("pdc", "op", "vwap")
HIST_FEATS = ("r_op", "range_atr", "rv_rel", "vwap_dist", "cover")
ROLL_FEATS = ("r_last30", "r_seg1", "r_seg5", "rv_rel", "vwap_dist", "jump_share", "signed_vol", "miss_share",
              "r_auction", "gap")
XS_SNAP = ("r_op", "r_pdc", "rvol", "range_atr", "vwap_dist", "dn_share", "rel_nifty", "rv_rel", "signed_vol")
XS_DAY = ("r_oc", "r_pdc", "r_last30", "vwap_dist", "rv_rel", "jump_share", "rvol_day", "signed_vol", "rel_nifty",
          "dn_share")
KEEP_ALWAYS = {"basis_open_ok", "basis_ok", "daily_match", "cover", "bars_missing", "miss_run_max",
               "mins_since_trade", "flat_bars", "home", "miss_share"}
FORWARD = ("_fwd", "fwd_", "future_", "_ahead", "lookahead", "mfe", "mae", "target_", "_next", "ret_1d_close_pct",
           "ret_3d_close_pct", "ret_5d_close_pct")
RAW = {"open", "high", "low", "close", "volume", "vwap", "turnover", "adj_close", "prev_close", "value", "oi",
       "price", "ltp"}
EMPTY_D = np.array([], dtype="datetime64[D]")
SUFFIX = "_f3.parquet"           # per-stock files: <NAME>_f3.parquet (Windows reserves CON, AUX, NUL... as names)


def fname(name: str) -> str:
    return name + SUFFIX


class F3Error(Exception):
    pass


def log(msg: str) -> None:
    print("%s  %s" % (dt.datetime.now().strftime("%H:%M:%S"), msg), flush=True)


# ====================================================================================================== small helpers
def to_dt(t) -> pd.Series:
    t = t if isinstance(t, pd.Series) else pd.Series(t)
    return t if pd.api.types.is_datetime64_any_dtype(t.dtype) else pd.to_datetime(t)


def ist_naive(t) -> np.ndarray:
    t = to_dt(t)
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert(IST).dt.tz_localize(None)
    return t.to_numpy().astype("datetime64[ns]")


def read_json(p: Path) -> Optional[dict]:
    try:
        return json.loads(Path(p).read_text(encoding="utf-8")) if Path(p).exists() else None
    except Exception:
        return None


def write_json(p: Path, obj) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=1, default=str, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


def write_parquet(p: Path, df: pd.DataFrame) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    df.to_parquet(tmp, index=False, compression="zstd", use_dictionary=["symbol"] if "symbol" in df.columns else
                  False)
    for i in range(8):
        try:
            os.replace(tmp, p)
            return
        except PermissionError:
            time.sleep(0.25 * (i + 1))
    raise F3Error("could not replace %s - is it open in another program?" % p)


def t2j(hhmm: str) -> int:
    """The last bar that has ENDED by this clock time (10:15 -> the bar stamped 10:12)."""
    try:
        h, m = (int(x) for x in str(hhmm).strip().split(":"))
    except ValueError:
        raise F3Error("time '%s' is not HH:MM" % hhmm) from None
    k = (h * 60 + m - START) // BAR - 1
    if k < 0 or k > NB - 1:
        raise F3Error("time %s is outside 09:18 .. 15:30 (the first bar ends 09:18)" % hhmm)
    return int(k)


def j2hhmm(j) -> np.ndarray:
    e = START + BAR * (np.asarray(j) + 1)
    return ((e // 60) * 100 + e % 60).astype(np.int16)


def first_true(m: np.ndarray) -> np.ndarray:
    return np.where(m.any(axis=1), m.argmax(axis=1), -1)


def last_true(m: np.ndarray) -> np.ndarray:
    return np.maximum.accumulate(np.where(m, np.arange(m.shape[1])[None, :], -1), axis=1)


def ffill(a: np.ndarray) -> np.ndarray:
    ok = np.isfinite(a)
    idx = np.where(ok, np.arange(a.shape[1])[None, :], 0)
    np.maximum.accumulate(idx, axis=1, out=idx)
    out = a[np.arange(a.shape[0])[:, None], idx]
    out[~np.logical_or.accumulate(ok, axis=1)] = np.nan
    return out


def shift_cols(a: np.ndarray, k: int) -> np.ndarray:
    out = np.full(a.shape, np.nan)
    if k < a.shape[1]:
        out[:, k:] = a[:, : a.shape[1] - k]
    return out


def window_cols(a: np.ndarray, w: int) -> np.ndarray:
    """(S, n, w): bars j-w+1 .. j for every j (NaN before the session start)."""
    pad = np.full((a.shape[0], w - 1), np.nan)
    return sliding_window_view(np.concatenate([pad, a], axis=1), w, axis=1)


def prior_rows(x: np.ndarray, w: int) -> np.ndarray:
    """(S, ..., w): the w PREVIOUS sessions' values for each session (NaN-padded)."""
    pad = np.full((w,) + x.shape[1:], np.nan)
    v = sliding_window_view(np.concatenate([pad, x.astype(float)], axis=0), w, axis=0)
    return v[: x.shape[0]]


def nanq(fn, *a, **k):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        return fn(*a, **k)


def nanmed(a: np.ndarray) -> np.ndarray:
    """Median along the last axis ignoring NaN (sort-based: numpy's nanmedian is slow on short windows)."""
    srt = np.sort(a, axis=-1)                      # NaN sort last
    cnt = np.isfinite(a).sum(axis=-1)
    i0 = np.maximum((cnt - 1) // 2, 0)[..., None]
    i1 = np.maximum(cnt // 2, 0)[..., None]
    v = (np.take_along_axis(srt, i0, -1) + np.take_along_axis(srt, i1, -1))[..., 0] / 2
    return np.where(cnt > 0, v, np.nan)


def fp_hash(*arrays) -> str:
    h = hashlib.sha1()
    for a in arrays:
        h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()[:16]


# ====================================================================================================== inputs
class Series:
    __slots__ = ("name", "kind", "tsym", "file")

    def __init__(self, name, kind, tsym, file=None):
        self.name, self.kind, self.tsym, self.file = name, kind, tsym, file


class Daily:
    __slots__ = ("dates", "o", "h", "l", "c", "v")


class Dense:
    """One series' sessions x 125 bars (bar k starts 09:15 + 3k). NaN where Kite printed no bar."""
    __slots__ = ("days", "O", "H", "L", "C", "V", "P")


def store_dir(root: Path, store: Optional[str]) -> Path:
    if store:
        return Path(store)
    try:
        IC = importlib.import_module("intraday_cache")
    except Exception as e:
        raise F3Error("cannot import production's intraday_cache (%s) - run env_tradelab.bat, or give --store" % e) \
            from e
    if int(getattr(IC, "BAR_MIN", 0)) != BAR:
        raise F3Error("intraday_cache is not the 3-minute store (BAR_MIN %s)" % getattr(IC, "BAR_MIN", None))
    return Path(IC.store(Path(root)))


def load_universe(root: Path, sdir: Path, only: Optional[Sequence[str]] = None) -> Dict[str, Series]:
    """Equities and indices of the daily cache, each with its 3-minute file (cache3m's catalog when present)."""
    cat = (read_json(sdir / "_cache3m" / "catalog.json") or {}).get("series", {})
    want = {s.strip().upper() for s in only} | {MASTER} | set(SECTORS) if only else None
    out: Dict[str, Series] = {}
    for okp in sorted(Path(root).glob("*_daily.ok.json")):
        name = okp.name[: -len("_daily.ok.json")]
        if want is not None and name.upper() not in want:
            continue
        m = read_json(okp) or {}
        kind = str(m.get("series_kind") or "equity")
        if kind not in ("equity", "index") or not (Path(root) / ("%s_daily.parquet" % name)).exists():
            continue
        tsym = str(m.get("tradingsymbol") or name)
        f = (cat.get(name) or {}).get("file")
        if f:
            p = sdir / f
        else:
            p = sdir / ("%s_3m.parquet" % name)
            if kind == "index" and tsym != name and ((sdir / ("%s_3m.parquet" % tsym)).exists() or not p.exists()):
                p = sdir / ("%s_3m.parquet" % tsym)
        out[name] = Series(name, kind, tsym, p)
    return out


def read_daily(root: Path, name: str, before=None, open_on=None) -> Daily:
    """The daily bars; before=date keeps sessions before it, open_on=date then adds that session's OPEN only."""
    df = pd.read_parquet(Path(root) / ("%s_daily.parquet" % name))
    d = ist_naive(df["timestamp"]).astype("datetime64[D]")
    order = np.argsort(d, kind="mergesort")
    d = d[order]
    keep = np.r_[d[1:] != d[:-1], True] if len(d) else np.zeros(0, bool)
    X = Daily()
    X.dates = d[keep]
    for k, c in (("o", "open"), ("h", "high"), ("l", "low"), ("c", "close"), ("v", "volume")):
        v = pd.to_numeric(df[c], errors="coerce").to_numpy(float)[order][keep] if c in df.columns else \
            np.full(keep.sum(), np.nan)
        setattr(X, k, v)
    if before is not None:
        b = np.datetime64(before, "D")
        m = X.dates < b
        add = open_on is not None and np.any(X.dates == b)
        o_b = X.o[X.dates == b][0] if add else np.nan
        for k in ("dates", "o", "h", "l", "c", "v"):
            setattr(X, k, getattr(X, k)[m])
        if add:
            X.dates = np.r_[X.dates, b]
            X.o = np.r_[X.o, o_b]
            for k in ("h", "l", "c", "v"):
                setattr(X, k, np.r_[getattr(X, k), np.nan])
    return X


def read_bars(path: Path, cut=None) -> pd.DataFrame:
    """A 3-minute file; cut=(date, j) keeps only bars that ended by bar j of that date (and nothing later)."""
    if not Path(path).exists():
        return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])
    df = pd.read_parquet(path, columns=None)
    if cut is not None:
        t = ist_naive(df["timestamp"])
        lim = np.datetime64(cut[0], "D").astype("datetime64[ns]") + np.timedelta64(START + BAR * cut[1], "m")
        df = df[t <= lim].reset_index(drop=True)
    return df


def to_dense(df: pd.DataFrame) -> Dense:
    D = Dense()
    if df is None or not len(df):
        D.days = EMPTY_D
        D.O = D.H = D.L = D.C = D.V = np.zeros((0, NB))
        D.P = np.zeros((0, NB), bool)
        return D
    t = ist_naive(df["timestamp"])
    order = np.argsort(t, kind="mergesort")
    t = t[order]
    day = t.astype("datetime64[D]")
    mins = ((t - day.astype("datetime64[ns]")) // np.timedelta64(1, "m")).astype(np.int64) - START
    ok = (mins >= 0) & (mins % BAR == 0) & (mins // BAR < NB)
    k = (mins[ok] // BAR).astype(np.int64)
    d = day[ok]
    D.days = np.unique(d)
    si = np.searchsorted(D.days, d)
    S = len(D.days)
    for nm, col in (("O", "open"), ("H", "high"), ("L", "low"), ("C", "close"), ("V", "volume")):
        a = np.full((S, NB), np.nan)
        src = pd.to_numeric(df[col], errors="coerce").to_numpy(float)[order][ok] if col in df.columns else \
            np.full(ok.sum(), np.nan)
        a[si, k] = src                         # a repeated stamp keeps its last row (sorted, stable)
        setattr(D, nm, a)
    D.P = np.isfinite(D.O) & np.isfinite(D.H) & np.isfinite(D.L) & np.isfinite(D.C)
    for nm in ("O", "H", "L", "C", "V"):
        a = getattr(D, nm)
        a[~D.P] = np.nan
    return D


def slice_dense(D: Dense, lo: int) -> Dense:
    E = Dense()
    for nm in Dense.__slots__:
        setattr(E, nm, getattr(D, nm)[lo:])
    return E


def daily_ctx(X: Daily, days: np.ndarray) -> Dict[str, np.ndarray]:
    """Per session: the official open (known 09:15), the previous sessions' levels and ATR (known), and today's
    daily high / low / close / volume (known only at the close: day table only)."""
    S = len(days)
    out = {k: np.full(S, np.nan) for k in ("op", "pdc", "pdh", "pdl", "pwh", "pwl", "atr", "dvol20", "dH", "dL",
                                           "dC", "dV")}
    out["has_daily"] = np.zeros(S, bool)
    if not len(X.dates) or not S:
        return out
    n = len(X.dates)
    pos = np.minimum(np.searchsorted(X.dates, days), n - 1)
    hit = X.dates[pos] == days
    pc = np.r_[np.nan, X.c[:-1]]
    tr = np.fmax(X.h - X.l, np.fmax(np.abs(X.h - pc), np.abs(X.l - pc)))
    tr[0] = X.h[0] - X.l[0]
    atr_all = np.full(n, np.nan)
    pwh_all, pwl_all, dv_all = np.full(n, np.nan), np.full(n, np.nan), np.full(n, np.nan)
    if n > ATR_N:
        w = prior_rows(tr, ATR_N)
        cnt = np.isfinite(w).sum(axis=1)
        atr_all = np.where(cnt == ATR_N, nanq(np.nanmean, w, axis=1), np.nan)
    if n > 5:
        pwh_all = np.where(np.isfinite(prior_rows(X.h, 5)).sum(axis=1) >= 3, nanq(np.nanmax, prior_rows(X.h, 5),
                                                                                  axis=1), np.nan)
        pwl_all = np.where(np.isfinite(prior_rows(X.l, 5)).sum(axis=1) >= 3, nanq(np.nanmin, prior_rows(X.l, 5),
                                                                                  axis=1), np.nan)
    if n > MIN_PRIOR:
        wv = prior_rows(X.v, PRIOR)
        dv_all = np.where(np.isfinite(wv).sum(axis=1) >= MIN_PRIOR, nanmed(wv), np.nan)
    prev = pos - 1
    okp = hit & (prev >= 0)
    pv = np.maximum(prev, 0)
    out["has_daily"] = hit
    out["op"] = np.where(hit, X.o[pos], np.nan)
    for k, arr in (("pdc", X.c), ("pdh", X.h), ("pdl", X.l)):
        out[k] = np.where(okp, arr[pv], np.nan)
    for k, arr in (("pwh", pwh_all), ("pwl", pwl_all), ("atr", atr_all), ("dvol20", dv_all)):
        out[k] = np.where(hit, arr[pos], np.nan)
    for k, arr in (("dH", X.h), ("dL", X.l), ("dC", X.c), ("dV", X.v)):
        out[k] = np.where(hit, arr[pos], np.nan)
    return out


class MarketSet:
    """NIFTY 50's and the sector indices' 3-minute closes and official opens, by day."""

    def __init__(self):
        self.series: Dict[str, Tuple[np.ndarray, np.ndarray, np.ndarray]] = {}

    def add(self, name: str, D: Dense, X: Daily) -> None:
        op = daily_ctx(X, D.days)["op"]
        first = first_true(D.P)
        fo = np.where(first >= 0, D.O[np.arange(len(D.days)), np.maximum(first, 0)], np.nan)
        op = np.where(np.isfinite(op) & (op > 0), op, fo)
        self.series[name] = (D.days, D.C.astype(np.float64), op)

    def aligned(self, name: str, days: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """(closes S x 125, official opens S) on the given days; NaN where the index has no bars."""
        S = len(days)
        C = np.full((S, NB), np.nan)
        op = np.full(S, np.nan)
        if name not in self.series or not S:
            return C, op
        md, mc, mo = self.series[name]
        if not len(md):
            return C, op
        pos = np.minimum(np.searchsorted(md, days), len(md) - 1)
        hit = md[pos] == days
        C[hit] = mc[pos[hit]]
        op[hit] = mo[pos[hit]]
        return C, op


# ====================================================================================================== the engine
def engine(D: Dense, X: Dict[str, np.ndarray], MK: MarketSet, home: np.ndarray, cols: Sequence[int],
           hist_w: int = HIST_W, roll_w: Sequence[int] = ROLL_W, is_index: bool = False):
    """Every feature of one series. Returns (snap: name -> S x K at the kept bars, day: name -> S at the close).
    Each 2-D quantity is a prefix: its value at bar j uses bars 0..j only (and the prior sessions)."""
    S = len(D.days)
    n = NB
    J = np.arange(n)[None, :]
    R = np.arange(S)
    O, H, L, C, V, P = D.O, D.H, D.L, D.C, D.V, D.P
    cols = np.asarray(cols, dtype=np.int64)
    K = len(cols)
    sn: Dict[str, np.ndarray] = {}
    dy: Dict[str, np.ndarray] = {}
    E = np.errstate(all="ignore")
    E.__enter__()
    try:
        def keep(name, a):
            a = np.asarray(a, dtype=float)
            sn[name] = a[:, cols].astype(np.float32)
            dy[name] = a[:, n - 1].astype(np.float32)

        def keep1(name, a):
            a = np.asarray(a, dtype=float)
            sn[name] = np.repeat(a[:, None], K, axis=1).astype(np.float32)
            dy[name] = a.astype(np.float32)

        def day_(name, a):
            dy[name] = np.asarray(a, dtype=float).astype(np.float32)

        def since(idx):                      # per kept bar: minutes since a first event, NaN if not yet
            out = np.full((S, K), np.nan)
            for k, jc in enumerate(cols):
                hit = (idx >= 0) & (idx <= jc)
                out[:, k] = np.where(hit, BAR * (jc - idx), np.nan)
            return out.astype(np.float32)

        def happened(idx, gate):             # 1 / 0 by each kept bar; NaN while the gate event has not happened
            out = np.full((S, K), np.nan)
            for k, jc in enumerate(cols):
                g = (gate >= 0) & (gate <= jc)
                out[:, k] = np.where(g, ((idx >= 0) & (idx <= jc)).astype(float), np.nan)
            return out.astype(np.float32)

        def known_at(idx):                   # day table: minute after 09:15 when the event became known
            return np.where(idx >= 0, BAR * (idx + 1), np.nan)

        first = first_true(P)
        has = first >= 0
        O_first = np.where(has, O[R, np.maximum(first, 0)], np.nan)
        op_d = X["op"]
        op = np.where(np.isfinite(op_d) & (op_d > 0), op_d, O_first)
        dev = np.abs(O_first / op_d - 1)
        tolb = np.where(first == 0, OPEN_TOL, LATE_TOL)
        bok = np.where(has & np.isfinite(op_d), (dev <= tolb).astype(float), np.where(has, 1.0, np.nan))
        keep("basis_open_ok", np.where(J >= first[:, None], bok[:, None], np.nan) * np.where(has[:, None], 1, np.nan))
        pdc, pdh, pdl, pwh, pwl, atr = (X[k] for k in ("pdc", "pdh", "pdl", "pwh", "pwl", "atr"))
        atrp = atr / pdc
        dmax = nanq(np.nanmax, H, axis=1)
        dmin = nanq(np.nanmin, L, axis=1)
        kh, kl = X["dH"] / dmax, X["dL"] / dmin
        fault = ((kh > 1 + BASIS_TOL) & (kl > 1 + BASIS_TOL)) | ((kh < 1 - BASIS_TOL) & (kl < 1 - BASIS_TOL))
        basis_ok = np.where(np.isfinite(kh) & np.isfinite(kl), (~fault).astype(float), np.nan)
        badrow = (basis_ok == 0) | (bok == 0)          # a faulty session feeds no one's history

        # ---------------------------------------------------------------- coverage
        nobs = np.cumsum(P, axis=1)
        keep("cover", nobs / (J + 1))
        keep("bars_missing", (J + 1) - nobs)
        run = np.zeros(S)
        mx = np.zeros(S)
        MR = np.empty((S, n))
        for j in range(n):
            run = np.where(P[:, j], 0.0, run + 1.0)
            mx = np.maximum(mx, run)
            MR[:, j] = mx
        keep("miss_run_max", MR)
        lo_ = last_true(P)
        keep("mins_since_trade", np.where(lo_ >= 0, BAR * (J - lo_), np.nan))
        keep("flat_bars", np.cumsum(P & (H - L <= 1e-9), axis=1))

        # ---------------------------------------------------------------- the open and returns
        LC = ffill(C)
        prevC = np.empty((S, n))
        prevC[:, 0] = op
        prevC[:, 1:] = LC[:, :-1]
        prevC = np.where(np.isfinite(prevC), prevC, op[:, None])
        r = np.where(P, np.log(C / prevC), np.nan)
        gap = op / pdc - 1
        keep1("gap", gap)
        keep1("gap_atr", (op - pdc) / atr)
        keep1("op_in_prev_range", np.where(pdh > pdl, (op - pdl) / (pdh - pdl), np.nan))
        keep("r_op", LC / op[:, None] - 1)
        keep("r_pdc", LC / pdc[:, None] - 1)
        keep("r_op_atr", (LC - op[:, None]) / atr[:, None])

        # ---------------------------------------------------------------- path and excursions
        RH = np.fmax.accumulate(H, axis=1)
        RL = np.fmin.accumulate(L, axis=1)
        pRH = shift_cols(RH, 1)
        pRL = shift_cols(RL, 1)
        keep("rise_op", RH / op[:, None] - 1)
        keep("fall_op", RL / op[:, None] - 1)
        tH = last_true(P & ~(H <= np.where(np.isfinite(pRH), pRH, -np.inf)))       # the bar that set the high
        tL = last_true(P & ~(L >= np.where(np.isfinite(pRL), pRL, np.inf)))
        keep("mins_since_hi", np.where(tH >= 0, BAR * (J - tH), np.nan))
        keep("mins_since_lo", np.where(tL >= 0, BAR * (J - tL), np.nan))
        keep("hi_first", np.where((tH >= 0) & (tL >= 0), (tH < tL).astype(float), np.nan))
        rng = RH - RL
        keep("pos_range", np.where(rng > 0, (LC - RL) / rng, np.nan))
        keep("range_op", rng / op[:, None])
        keep("range_atr", rng / atr[:, None])
        peak = np.fmax(pRH, op[:, None])
        trough = np.fmin(pRL, op[:, None])
        keep("dd_max", np.maximum(0, np.fmax.accumulate(np.where(P, 1 - L / peak, np.nan), axis=1)))
        keep("ru_max", np.maximum(0, np.fmax.accumulate(np.where(P, H / trough - 1, np.nan), axis=1)))
        up = RH - op[:, None]
        dn = op[:, None] - RL
        keep("giveback", np.where(up > 0.001 * op[:, None], (RH - LC) / up, np.nan))
        keep("recover", np.where(dn > 0.001 * op[:, None], (LC - RL) / dn, np.nan))
        absmove = np.cumsum(np.where(P, np.abs(C - prevC), 0.0), axis=1)
        eff = np.where(absmove > 0, (LC - op[:, None]) / absmove, np.nan)
        keep("eff_signed", eff)
        keep("eff_abs", np.abs(eff))

        # ---------------------------------------------------------------- gap fill
        upg, dng = gap >= GAP_MIN, gap <= -GAP_MIN
        fill = np.where(upg[:, None], (op[:, None] - RL) / (op - pdc)[:, None],
                        np.where(dng[:, None], (RH - op[:, None]) / (pdc - op)[:, None], np.nan))
        fill = np.clip(fill, 0, 1)
        fidx = first_true(fill >= 1)
        keep("gap_fill", fill)
        sn["gap_fill_mins"] = np.full((S, K), np.nan, np.float32)
        ext = np.where(upg[:, None], RH / op[:, None] - 1, np.where(dng[:, None], 1 - RL / op[:, None], np.nan))
        ext_b = np.where(upg[:, None], pRH / op[:, None] - 1, np.where(dng[:, None], 1 - pRL / op[:, None], np.nan))
        gx = np.full((S, K), np.nan)
        for k, jc in enumerate(cols):
            done = (fidx >= 0) & (fidx <= jc)
            sn["gap_fill_mins"][:, k] = np.where(done, BAR * (fidx + 1), np.nan)
            at_f = ext_b[R, np.maximum(fidx, 0)]
            gx[:, k] = np.where(done, np.where(np.isfinite(at_f), np.maximum(at_f, 0), 0.0), ext[:, jc])
        sn["gap_ext"] = gx.astype(np.float32)
        day_("gap_fill_mins", known_at(fidx))
        at_f = ext_b[R, np.maximum(fidx, 0)]
        day_("gap_ext", np.where(fidx >= 0, np.where(np.isfinite(at_f), np.maximum(at_f, 0), 0.0), ext[:, n - 1]))

        # ---------------------------------------------------------------- volatility
        r2 = np.where(P, r * r, 0.0)
        RV = np.cumsum(r2, axis=1)
        rv = np.where(nobs > 0, np.sqrt(RV), np.nan)
        keep("rv", rv)
        keep("rv_rel", rv / atrp[:, None])
        keep("dn_share", np.where(RV > 0, np.cumsum(np.where(P & (r < 0), r * r, 0.0), axis=1) / RV, np.nan))
        keep("worst_bar", np.fmin.accumulate(r, axis=1))
        keep("best_bar", np.fmax.accumulate(r, axis=1))
        keep("big_bar_share", np.where(RV > 0, np.fmax.accumulate(np.where(P, r * r, np.nan), axis=1) / RV, np.nan))

        # ---------------------------------------------------------------- VWAP and participation
        TP = (H + L + C) / 3
        vv = np.where(P & np.isfinite(V), V, 0.0)
        cumV = np.cumsum(vv, axis=1)
        cumTV = np.cumsum(np.where(P, TP, 0.0) * vv, axis=1)
        VW = np.where(cumV > 0, cumTV / cumV, np.nan)
        keep("vwap_dist", LC / VW - 1)
        keep("vwap_slope", VW / shift_cols(VW, 10) - 1)
        okv = P & np.isfinite(VW)
        keep("vwap_above", np.where(np.cumsum(okv, axis=1) > 0,
                                    np.cumsum(okv & (C > VW), axis=1) / np.cumsum(okv, axis=1), np.nan))
        keep("log_rs_traded", np.where(cumTV > 0, np.log10(np.where(cumTV > 0, cumTV, 1.0)), np.nan))
        t1 = np.zeros(S)
        t2 = np.zeros(S)
        t3 = np.zeros(S)
        TOP = np.empty((S, n))
        for j in range(n):
            x = vv[:, j]
            b1 = x > t1
            b2 = ~b1 & (x > t2)
            b3 = ~b1 & ~b2 & (x > t3)
            t3 = np.where(b1 | b2, t2, np.where(b3, x, t3))
            t2 = np.where(b1, t1, np.where(b2, x, t2))
            t1 = np.where(b1, x, t1)
            TOP[:, j] = t1 + t2 + t3
        keep("top3_vol_share", np.where(cumV > 0, TOP / cumV, np.nan))
        upv = np.cumsum(np.where(P & (C > O), vv, 0.0), axis=1)
        dnv = np.cumsum(np.where(P & (C < O), vv, 0.0), axis=1)
        keep("signed_vol", np.where(cumV > 0, (upv - dnv) / cumV, np.nan))
        keep("vol_dn_share", np.where(cumV > 0, np.cumsum(np.where(P & (r < 0), vv, 0.0), axis=1) / cumV, np.nan))
        st = np.zeros(S)
        STR = np.empty((S, n))
        for j in range(n):
            sg = np.sign(np.nan_to_num(r[:, j]))
            obs = P[:, j]
            st = np.where(obs, np.where(sg == 0, 0.0, np.where(np.sign(st) == sg, st + sg, sg)), st)
            STR[:, j] = st
        keep("streak", STR)
        # cumulative volume against the stock's own curve (median of the prior 20 sessions at the same bar)
        kc = np.r_[cols, n - 1]
        cv = cumV[:, kc]
        cv = np.where(np.isfinite(cv) & (cv > 0), cv, np.nan) if not is_index else np.full(cv.shape, np.nan)
        cvh = cv.copy()
        cvh[badrow] = np.nan                           # the mask reaches only other sessions' history
        pw = prior_rows(cvh, PRIOR)
        med = np.where(np.isfinite(pw).sum(axis=-1) >= MIN_PRIOR, nanmed(pw), np.nan)
        rv_ = cv / med
        sn["rvol"] = rv_[:, :K].astype(np.float32)
        dy["rvol"] = rv_[:, K].astype(np.float32)

        # ---------------------------------------------------------------- compression and boxes
        bar_rng = np.where(P, (H - L) / C, np.nan)
        sess_med = nanmed(bar_rng)
        sess_med[badrow] = np.nan
        pw = prior_rows(sess_med, PRIOR)
        nbr = np.where(np.isfinite(pw).sum(axis=1) >= MIN_PRIOR, nanmed(pw), np.nan)
        for w in (5, 10):
            wh = nanq(np.nanmax, window_cols(H, w), axis=2)
            wl = nanq(np.nanmin, window_cols(L, w), axis=2)
            keep("rng%d_rel" % w, ((wh - wl) / LC) / nbr[:, None])
        ins = P & np.r_[np.zeros((1, S), bool), P.T[:-1]].T & (H <= shift_cols(H, 1)) & (L >= shift_cols(L, 1))
        run = np.zeros(S)
        IR = np.empty((S, n))
        for j in range(n):
            run = np.where(ins[:, j], run + 1, np.where(P[:, j], 0.0, run))
            IR[:, j] = run
        keep("inside_run", IR)
        hb = shift_cols(H, 1)
        lb = shift_cols(L, 1)
        cnt = np.isfinite(window_cols(hb, BOX)).sum(axis=2)
        boxH = np.where(cnt >= BOX // 2, nanq(np.nanmax, window_cols(hb, BOX), axis=2), np.nan)
        boxL = np.where(cnt >= BOX // 2, nanq(np.nanmin, window_cols(lb, BOX), axis=2), np.nan)
        keep("box_pos", np.where(boxH > boxL, (LC - boxL) / (boxH - boxL), np.nan))
        keep("box_width_rel", ((boxH - boxL) / LC) / nbr[:, None])
        bu = P & (C > boxH)
        bd = P & (C < boxL)
        bb = bu | bd
        lastb = last_true(bb)
        dirb = ffill(np.where(bu, 1.0, np.where(bd, -1.0, np.nan)))
        keep("mins_since_box_brk", np.where(lastb >= 0, BAR * (J - lastb) * dirb, np.nan))
        # volume of the latest break bar against the normal volume of that bar (prior 20 sessions' mean)
        vslot = np.where(P & np.isfinite(V) & (V > 0), V, np.nan) if not is_index else np.full((S, n), np.nan)
        vsh = vslot.copy()
        vsh[badrow] = np.nan
        pw = prior_rows(vsh, PRIOR)
        slot_norm = np.where(np.isfinite(pw).sum(axis=-1) >= MIN_PRIOR, nanq(np.nanmean, pw, axis=-1), np.nan)
        keep("box_brk_vol", ffill(np.where(bb, vslot / slot_norm, np.nan)) * np.where(lastb >= 0, 1.0, np.nan))
        # did the break hold: a close back inside within 5 bars fails it
        failf = np.zeros((S, n), bool)
        for k in range(1, BOX_FAIL + 1):
            Ck = np.full((S, n), np.nan)
            Ck[:, : n - k] = C[:, k:]
            failf |= (bu & (Ck <= boxH)) | (bd & (Ck >= boxL))
        bf = np.full((S, K), np.nan)
        for k, jc in enumerate(cols):
            b = lastb[:, jc]
            ok_b = b >= 0
            bv = np.maximum(b, 0)
            seen = np.zeros(S, bool)
            for q in range(1, BOX_FAIL + 1):
                jj = bv + q
                inside = (jj <= jc) & (jj < n)
                cq = C[R, np.minimum(jj, n - 1)]
                upb, dnb = bu[R, bv], bd[R, bv]
                seen |= inside & ((upb & (cq <= boxH[R, bv])) | (dnb & (cq >= boxL[R, bv])))
            pending = ~seen & (bv + BOX_FAIL > jc)
            bf[:, k] = np.where(ok_b, np.where(seen, 1.0, np.where(pending, np.nan, 0.0)), np.nan)
        sn["box_brk_failed"] = bf.astype(np.float32)
        day_("box_brk_up_n", bu.sum(axis=1))
        day_("box_brk_dn_n", bd.sum(axis=1))
        day_("box_fail_n", (failf & bb).sum(axis=1))

        # ---------------------------------------------------------------- levels and the order of events
        lvl_cols = {}

        def one_sided(name, lv, j0, upward, dynamic=False, lv_now=None):
            """A resistance (upward) or support level: first touch, first close beyond (the break), then the
            first retest that held and the first close back (the failure), in LATER bars than the break."""
            L2 = lv if dynamic else np.repeat(lv[:, None], n, axis=1)
            ok = P & (J >= j0) & np.isfinite(L2)
            if upward:
                brk = ok & (C > L2)
            else:
                brk = ok & (C < L2)
            fb = first_true(brk)
            lvb = np.where(fb >= 0, L2[R, np.maximum(fb, 0)], np.nan)[:, None]
            aft = (fb[:, None] >= 0) & (J > fb[:, None])
            if upward:
                ret = ok & aft & (L <= lvb * (1 + TOL)) & (C > lvb)
                fail = ok & aft & (C < lvb)
            else:
                ret = ok & aft & (H >= lvb * (1 - TOL)) & (C < lvb)
                fail = ok & aft & (C > lvb)
            fr, ff = first_true(ret), first_true(fail)
            touch = ok & (((L <= L2) & (H >= L2)) | ((prevC < L2) & (C > L2)) | ((prevC > L2) & (C < L2)))
            xing = ok & (((prevC <= L2) & (C > L2)) | ((prevC >= L2) & (C < L2)))
            now = lv_now if lv_now is not None else L2
            keep("lv_%s_dist" % name, LC / now - 1)
            sn["lv_%s_brk_mins" % name] = since(fb)
            sn["lv_%s_retest" % name] = happened(fr, fb)
            sn["lv_%s_fail" % name] = happened(ff, fb)
            day_("ev_%s_touch" % name, known_at(first_true(touch)))
            day_("ev_%s_brk" % name, known_at(fb))
            day_("ev_%s_retest" % name, known_at(fr))
            day_("ev_%s_fail" % name, known_at(ff))
            day_("ev_%s_x" % name, xing.sum(axis=1))
            nok = ok.sum(axis=1)
            day_("ev_%s_beyond" % name, np.where(nok > 0, brk.sum(axis=1) / np.maximum(nok, 1), np.nan))
            if dynamic:
                day_("ev_%s_brk_lvl" % name, lvb[:, 0] / op - 1)
            lvl_cols[name] = (fb, fr, ff)

        def two_sided(name, lv, dynamic=False):
            if dynamic:
                L2 = lv
                Lp = shift_cols(lv, 1)
            else:
                L2 = np.repeat(lv[:, None], n, axis=1)
                Lp = L2
            ok = P & np.isfinite(L2)
            pc = prevC if not dynamic else np.where(np.isfinite(Lp), shift_cols(LC, 1), np.nan)
            ux = ok & np.isfinite(pc) & (pc <= Lp) & (C > L2)
            dx = ok & np.isfinite(pc) & (pc >= Lp) & (C < L2)
            xx = ux | dx
            nx = np.cumsum(xx, axis=1)
            lx = last_true(xx)
            dirx = ffill(np.where(ux, 1.0, np.where(dx, -1.0, np.nan)))
            keep("lv_%s_side" % name, np.sign(LC - L2))
            keep("lv_%s_x" % name, np.where(J >= first[:, None], nx, np.nan))
            keep("lv_%s_lastx_mins" % name, np.where(lx >= 0, BAR * (J - lx) * dirx, np.nan))
            touch = ok & (((L <= L2) & (H >= L2)) | xx)
            fu, fd = first_true(ux), first_true(dx)
            day_("ev_%s_touch" % name, known_at(first_true(touch)))
            day_("ev_%s_xup" % name, known_at(fu))
            day_("ev_%s_xdn" % name, known_at(fd))
            day_("ev_%s_x" % name, xx.sum(axis=1))
            nok = ok.sum(axis=1)
            day_("ev_%s_above" % name, np.where(nok > 0, (ok & (C > L2)).sum(axis=1) / np.maximum(nok, 1), np.nan))
            lxe = lx[:, n - 1]
            day_("ev_%s_lastx" % name, known_at(lxe))
            day_("ev_%s_lastdir" % name, np.where(lxe >= 0, dirx[:, n - 1], np.nan))
            if dynamic:
                day_("ev_%s_xup_lvl" % name, np.where(fu >= 0, L2[R, np.maximum(fu, 0)], np.nan) / op - 1)
                day_("ev_%s_xdn_lvl" % name, np.where(fd >= 0, L2[R, np.maximum(fd, 0)], np.nan) / op - 1)
            return ux, dx

        # opening ranges: the high / low of the first 15 and 30 minutes, events only after they complete
        or15h = nanq(np.nanmax, H[:, :5], axis=1)
        or15l = nanq(np.nanmin, L[:, :5], axis=1)
        or30h = nanq(np.nanmax, H[:, :10], axis=1)
        or30l = nanq(np.nanmin, L[:, :10], axis=1)
        # swing levels: confirmed 2 bars later; a break compares a close with the level known BEFORE that bar
        piv_h = np.zeros((S, n), bool)
        piv_l = np.zeros((S, n), bool)
        for k in range(SWING, n - SWING):
            win = H[:, k - SWING: k + SWING + 1]
            okw = np.isfinite(win).all(axis=1)
            piv_h[:, k] = okw & (H[:, k] > np.max(win[:, :SWING], axis=1)) & (H[:, k] >= np.max(win[:, SWING + 1:],
                                                                                                  axis=1))
            winl = L[:, k - SWING: k + SWING + 1]
            okl = np.isfinite(winl).all(axis=1)
            piv_l[:, k] = okl & (L[:, k] < np.min(winl[:, :SWING], axis=1)) & (L[:, k] <= np.min(winl[:, SWING + 1:],
                                                                                                   axis=1))
        swh_conf = np.full((S, n), np.nan)
        swl_conf = np.full((S, n), np.nan)
        swh_conf[:, 2 * SWING:] = np.where(piv_h[:, SWING: n - SWING], H[:, SWING: n - SWING], np.nan)
        swl_conf[:, 2 * SWING:] = np.where(piv_l[:, SWING: n - SWING], L[:, SWING: n - SWING], np.nan)
        swh_now = ffill(swh_conf)
        swl_now = ffill(swl_conf)
        swh_before = shift_cols(swh_now, 1)
        swl_before = shift_cols(swl_now, 1)

        for name, lv, j0 in (("pdh", pdh, 0), ("pwh", pwh, 0), ("or15h", or15h, 5), ("or30h", or30h, 10)):
            one_sided(name, lv, j0, True)
        one_sided("swh", swh_before, 0, True, dynamic=True, lv_now=swh_now)
        for name, lv, j0 in (("pdl", pdl, 0), ("pwl", pwl, 0), ("or15l", or15l, 5), ("or30l", or30l, 10)):
            one_sided(name, lv, j0, False)
        one_sided("swl", swl_before, 0, False, dynamic=True, lv_now=swl_now)
        # opening ranges are unknown before they complete
        for name, j0 in (("or15h", 5), ("or15l", 5), ("or30h", 10), ("or30l", 10)):
            for nm in ("lv_%s_dist" % name, "lv_%s_brk_mins" % name, "lv_%s_retest" % name, "lv_%s_fail" % name):
                sn[nm][:, cols < j0 - 1] = np.nan
        for name, lv in (("pdh", pdh), ("pdl", pdl), ("pwh", pwh), ("pwl", pwl), ("pdc", pdc)):
            day_("ev_%s_start" % name, np.sign(op - lv))
        two_sided("pdc", pdc)
        ux, dx = two_sided("op", op)
        fdx = first_true(dx)
        fux = first_true(ux)
        day_("ev_op_reclaim", known_at(first_true(ux & (J > fdx[:, None]) & (fdx[:, None] >= 0))))
        day_("ev_op_lose", known_at(first_true(dx & (J > fux[:, None]) & (fux[:, None] >= 0))))
        two_sided("vwap", VW, dynamic=True)

        # ---------------------------------------------------------------- circuit-band proxies (stage E's rule)
        ub = np.round(pdc[:, None] * (1 + BANDS[None, :]), 2)
        lb_ = np.round(pdc[:, None] * (1 - BANDS[None, :]), 2)
        atU = P & (np.abs(H[:, :, None] - ub[:, None, :]) <= BAND_TOL).any(axis=2) & (C >= H - BAND_TOL)
        atD = P & (np.abs(L[:, :, None] - lb_[:, None, :]) <= BAND_TOL).any(axis=2) & (C <= L + BAND_TOL)
        oneD = atD & (H - L <= BAND_TOL)
        keep("band_up_bars", np.cumsum(atU, axis=1))
        keep("band_dn_bars", np.cumsum(atD, axis=1))
        keep("band_dn_onep", np.cumsum(oneD, axis=1))
        day_("band_up_first", known_at(first_true(atU)))
        day_("band_dn_first", known_at(first_true(atD)))
        lastobs = lo_[:, n - 1]
        day_("band_up_last_bar", np.where(lastobs >= 0, atU[R, np.maximum(lastobs, 0)].astype(float), np.nan))
        day_("band_dn_last_bar", np.where(lastobs >= 0, atD[R, np.maximum(lastobs, 0)].astype(float), np.nan))

        # ---------------------------------------------------------------- the market (NIFTY 50) and the home index
        Cn, opn = MK.aligned(MASTER, D.days)
        LCn = ffill(Cn)
        Pn = np.isfinite(Cn)
        prevn = np.empty((S, n))
        prevn[:, 0] = opn
        prevn[:, 1:] = LCn[:, :-1]
        prevn = np.where(np.isfinite(prevn), prevn, opn[:, None])
        rn = np.where(Pn, np.log(Cn / prevn), np.nan)
        nret = LCn / opn[:, None] - 1
        keep("nifty_r_op", nret)
        keep("rel_nifty", (LC / op[:, None] - 1) - nret)
        both = P & Pn & np.isfinite(r) & np.isfinite(rn)
        x = np.where(both, r, 0.0)
        y = np.where(both, rn, 0.0)
        nb_ = np.cumsum(both, axis=1)
        sx, sy = np.cumsum(x, axis=1), np.cumsum(y, axis=1)
        sxx, syy, sxy = np.cumsum(x * x, axis=1), np.cumsum(y * y, axis=1), np.cumsum(x * y, axis=1)
        nn = np.maximum(nb_, 1)
        cxy = sxy / nn - sx * sy / nn ** 2
        vx = sxx / nn - (sx / nn) ** 2
        vy = syy / nn - (sy / nn) ** 2
        okb = (nb_ >= 10) & (vy > 0)
        beta = np.where(okb, cxy / vy, np.nan)
        keep("beta_n", beta)
        keep("corr_n", np.where(okb & (vx > 0), cxy / np.sqrt(vx * vy), np.nan))
        keep("idio_rv", np.where(okb, np.sqrt(np.maximum(0, nb_ * (vx - cxy ** 2 / np.where(vy > 0, vy, 1)))),
                                 np.nan))
        keep("nifty_up_r", np.where(nb_ > 0, np.cumsum(np.where(both & (rn > 0), r, 0.0), axis=1), np.nan))
        keep("nifty_dn_r", np.where(nb_ > 0, np.cumsum(np.where(both & (rn < 0), r, 0.0), axis=1), np.nan))
        keep1("home", home.astype(float))
        Cs = np.full((S, n), np.nan)
        ops = np.full(S, np.nan)
        for code in np.unique(home[home > 0]):
            m = home == code
            c_, o_ = MK.aligned(SECTORS[int(code) - 1], D.days[m])
            Cs[m], ops[m] = c_, o_
        sret = ffill(Cs) / ops[:, None] - 1
        keep("sec_r_op", sret)
        keep("rel_sec", (LC / op[:, None] - 1) - sret)

        # ---------------------------------------------------------------- same-clock history (prior sessions only)
        hn = None
        for nm in HIST_FEATS:
            M = np.concatenate([sn[nm].astype(float), dy[nm].astype(float)[:, None]], axis=1)
            Mh = M.copy()
            Mh[badrow] = np.nan
            pw = prior_rows(Mh, hist_w)                       # S x (K+1) x W
            cntv = np.isfinite(pw).sum(axis=-1)
            okh = cntv >= MIN_PRIOR
            md = np.where(okh, nanmed(pw), np.nan)
            mad = np.where(okh, nanmed(np.abs(pw - md[..., None])), np.nan)
            less = np.nansum(pw < M[..., None], axis=-1) + 0.5 * np.nansum(pw == M[..., None], axis=-1)
            pct = np.where(okh & np.isfinite(M), less / np.maximum(cntv, 1), np.nan)
            for suf, arr in (("med", md), ("pct", pct), ("mad", mad)):
                sn["h_%s_%s" % (nm, suf)] = arr[:, :K].astype(np.float32)
                dy["h_%s_%s" % (nm, suf)] = arr[:, K].astype(np.float32)
            if nm == "r_op":
                hn = cntv
        sn["h_n"] = hn[:, :K].astype(np.float32)
        dy["h_n"] = hn[:, K].astype(np.float32)

        # ---------------------------------------------------------------- what happened AFTER each snapshot
        cend = LC[:, n - 1]
        sn["label_r_to_eod"] = (cend[:, None] / LC[:, cols] - 1).astype(np.float32)
        sn["label_r_to_official_close"] = (X["dC"][:, None] / LC[:, cols] - 1).astype(np.float32)

        # ---------------------------------------------------------------- day only (known at 15:30)
        def cl(j):
            return LC[:, j]

        day_("r_seg1", cl(9) / op - 1)
        day_("r_seg2", cl(39) / cl(9) - 1)
        day_("r_seg3", cl(79) / cl(39) - 1)
        day_("r_seg4", cl(109) / cl(79) - 1)
        day_("r_seg5", cend / cl(109) - 1)
        day_("r_last30", cend / cl(114) - 1)
        day_("r_auction", X["dC"] / cend - 1)
        day_("r_oc", X["dC"] / op - 1)
        day_("hi_min", known_at(first_true(P & (H >= dmax[:, None]))))
        day_("lo_min", known_at(first_true(P & (L <= dmin[:, None]))))
        nr = nobs[:, n - 1]
        RVd = RV[:, n - 1]
        absr = np.abs(np.where(P, r, np.nan))
        pair = absr[:, 1:] * absr[:, :-1]
        BV = (np.pi / 2) * np.nansum(pair, axis=1)
        day_("bv_rel", np.sqrt(BV) / atrp)
        day_("jump_share", np.where(RVd > 0, np.maximum(0, RVd - BV) / RVd, np.nan))
        day_("rskew", np.where((RVd > 0) & (nr >= 10), np.sqrt(nr) * np.nansum(np.where(P, r ** 3, np.nan), axis=1)
                               / RVd ** 1.5, np.nan))
        day_("rkurt", np.where((RVd > 0) & (nr >= 10), nr * np.nansum(np.where(P, r ** 4, np.nan), axis=1)
                               / RVd ** 2, np.nan))
        park = np.sqrt(np.nansum(np.where(P, np.log(H / L) ** 2, np.nan), axis=1) / (4 * np.log(2)))
        day_("park_rel", np.where(nr > 0, park / atrp, np.nan))
        day_("rv_hour1_share", np.where(RVd > 0, RV[:, 19] / RVd, np.nan))
        tv = cumV[:, n - 1]
        day_("rvol_day", np.where(tv > 0, tv / X["dvol20"], np.nan) if not is_index else np.full(S, np.nan))
        day_("vol_first30_share", np.where(tv > 0, cumV[:, 9] / tv, np.nan))
        day_("vol_last30_share", np.where(tv > 0, (tv - cumV[:, 114]) / tv, np.nan))
        day_("vol_peak_min", np.where(tv > 0, BAR * (np.argmax(vv, axis=1) + 1), np.nan))
        day_("vol_hhi", np.where(tv > 0, np.sum((vv / np.maximum(tv, 1e-12)[:, None]) ** 2, axis=1), np.nan))
        # spread proxies from bar highs / lows / closes
        lh = np.log(H / L)
        g2 = np.log(np.fmax(H[:, 1:], H[:, :-1]) / np.fmin(L[:, 1:], L[:, :-1])) ** 2
        b2 = lh[:, 1:] ** 2 + lh[:, :-1] ** 2
        k_ = 3 - 2 * np.sqrt(2)
        alpha = (np.sqrt(2 * b2) - np.sqrt(b2)) / k_ - np.sqrt(g2 / k_)
        scs = np.maximum(0, 2 * (np.exp(alpha) - 1) / (1 + np.exp(alpha)))
        day_("spread_cs", nanq(np.nanmean, scs, axis=1))
        eta = (np.log(H) + np.log(L)) / 2
        lc_ = np.log(C)
        ar = (lc_[:, :-1] - eta[:, :-1]) * (lc_[:, :-1] - eta[:, 1:])
        day_("spread_ar", np.sqrt(np.maximum(0, 4 * nanq(np.nanmean, ar, axis=1))))
        rs_bar = np.where(P, TP * vv, np.nan)
        day_("amihud", nanq(np.nanmean, np.where(rs_bar > 0, np.abs(r) / rs_bar * 1e7, np.nan), axis=1)
             if not is_index else np.full(S, np.nan))
        day_("miss_share", 1 - nr / n)

        # ---------------------------------------------------------------- basis faults: blank, never ranked
        dH, dL, dO = X["dH"], X["dL"], X["op"]
        day_("basis_ok", basis_ok)
        full = (nr >= 0.8 * n) & P[:, 0]
        match = full & (np.abs(O[:, 0] / dO - 1) <= BASIS_TOL) & (np.abs(dmax / dH - 1) <= BASIS_TOL) & \
            (np.abs(dmin / dL - 1) <= BASIS_TOL)
        day_("daily_match", match.astype(float))

        # ---------------------------------------------------------------- rolling history (day table)
        for nm in ROLL_FEATS:
            xv = dy[nm].astype(float)
            xv[badrow] = np.nan
            for w in roll_w:
                pw = np.concatenate([prior_rows(xv, w - 1), xv[:, None]], axis=1) if w > 1 else xv[:, None]
                okw = np.isfinite(pw).sum(axis=1) >= max(2, w // 2)
                dy["avg%d_%s" % (w, nm)] = np.where(okw, nanq(np.nanmean, pw, axis=1), np.nan).astype(np.float32)
            pw = prior_rows(xv, Z_W)
            okz = np.isfinite(pw).sum(axis=1) >= MIN_PRIOR
            mu, sd = nanq(np.nanmean, pw, axis=1), nanq(np.nanstd, pw, axis=1)
            dy["z%d_%s" % (Z_W, nm)] = np.where(okz & (sd > 0), (xv - mu) / sd, np.nan).astype(np.float32)

        # blanking: a faulty session shows no values (its flags stay)
        bad_s = sn["basis_open_ok"] == 0
        for nm in list(sn):
            if nm not in KEEP_ALWAYS:
                sn[nm] = np.where(bad_s, np.nan, sn[nm]).astype(np.float32)
        bad_d = (dy["basis_ok"] == 0) | (dy["basis_open_ok"] == 0)
        for nm in list(dy):
            if nm not in KEEP_ALWAYS:
                dy[nm] = np.where(bad_d, np.nan, dy[nm]).astype(np.float32)
        for nm in KEEP_ALWAYS:
            if nm in sn:
                sn[nm] = sn[nm].astype(np.float32)
    finally:
        E.__exit__(None, None, None)
    return sn, dy


# ====================================================================================================== one series
def frames(name: str, days: np.ndarray, sn: Dict[str, np.ndarray], dy: Dict[str, np.ndarray], cols, keep_rows):
    """The snapshot rows (session x kept bar) and the day rows of the sessions in keep_rows."""
    idx = np.flatnonzero(keep_rows)
    K = len(cols)
    sd = days[idx].astype("datetime64[ns]")
    sdat = {"symbol": np.full(len(idx) * K, name, dtype=object), "date": np.repeat(sd, K),
            "time": np.tile(j2hhmm(cols), len(idx))}
    for c, a in sn.items():
        sdat[c] = a[idx].reshape(-1)
    ddat = {"symbol": np.full(len(idx), name, dtype=object), "date": sd}
    for c, a in dy.items():
        ddat[c] = a[idx]
    return pd.DataFrame(sdat), pd.DataFrame(ddat)


class Cfg:
    def __init__(self, snap_times=SNAP_TIMES, hist_w=HIST_W, roll_w=ROLL_W):
        self.snap_times = tuple(snap_times)
        self.hist_w = int(hist_w)
        self.roll_w = tuple(int(x) for x in roll_w)
        self.cols = sorted({t2j(t) for t in self.snap_times})
        self.need = max(self.hist_w, PRIOR, Z_W, max(self.roll_w), ATR_N) + 2

    def key(self) -> dict:
        return {"engine": ENGINE, "snap_times": list(self.snap_times), "hist_w": self.hist_w,
                "roll_w": list(self.roll_w)}


_W: dict = {}


def _init_worker(root, sdir, out, cfgkey, mkt_names, home_path):
    _W.clear()
    _W.update({"root": Path(root), "sdir": Path(sdir), "out": Path(out), "cfg": Cfg(cfgkey["snap_times"],
                                                                                    cfgkey["hist_w"],
                                                                                    cfgkey["roll_w"])})
    MK = MarketSet()
    for nm, f in mkt_names:
        try:
            MK.add(nm, to_dense(read_bars(Path(f))), read_daily(Path(root), nm))
        except Exception:
            continue
    _W["MK"] = MK
    _W["home"] = pd.read_parquet(home_path) if home_path and Path(home_path).exists() else None


def home_for(H: Optional[pd.DataFrame], name: str, days: np.ndarray) -> np.ndarray:
    out = np.zeros(len(days), np.int64)
    if H is None or not len(days):
        return out
    h = H[H["symbol"] == name]
    if h.empty:
        return out
    ym = pd.DatetimeIndex(days.astype("datetime64[ns]")).year * 100 + pd.DatetimeIndex(days.astype("datetime64[ns]")).month
    mp = dict(zip(h["month"].to_numpy(), h["home"].to_numpy()))
    return np.array([mp.get(int(m), 0) for m in ym], dtype=np.int64)


def run_series(task) -> dict:
    """Read one series, compute, write its new rows. task = (name, kind, file, state dict, full flag)."""
    name, kind, file, state, full = task
    W = _W
    root, out, cfg, MK = W["root"], W["out"], W["cfg"], W["MK"]
    t0 = time.time()
    try:
        bars = read_bars(Path(file))
        D = to_dense(bars)
        Xd = read_daily(root, name)
        if not len(D.days):
            return {"name": name, "status": "no 3-minute bars", "rows": 0}
        hasd = np.isin(D.days, Xd.dates)
        D = slice_dense(D, 0)
        for nm in Dense.__slots__:
            setattr(D, nm, getattr(D, nm)[hasd])
        if not len(D.days):
            return {"name": name, "status": "no session with both daily and 3-minute bars", "rows": 0}
        # what to (re)compute: everything, or the sessions from 5 before the last one built
        S = len(D.days)
        cut_i = 0
        src = fp_hash(D.days, D.C, D.V)
        if not full and state and state.get("cfg") == cfg.key() and state.get("last"):
            last = np.datetime64(state["last"], "D")
            k = int(np.searchsorted(D.days, last, side="right"))
            first_out = max(0, k - 5)
            if first_out > 0:
                pre = D.days[:first_out]
                okpre = fp_hash(pre, D.C[:first_out], D.V[:first_out]) == state.get("src_pre") and \
                    state.get("pre_n") == first_out
                dpre = Xd.dates <= pre[-1]
                okd = fp_hash(Xd.dates[dpre], Xd.o[dpre], Xd.h[dpre], Xd.l[dpre], Xd.c[dpre]) == state.get("daily_pre")
                if okpre and okd:
                    cut_i = first_out
        lo = max(0, cut_i - cfg.need)
        Ds = slice_dense(D, lo)
        X = daily_ctx(Xd, Ds.days)
        hm = home_for(W["home"], name, Ds.days)
        sn, dy = engine(Ds, X, MK, hm, cfg.cols, cfg.hist_w, cfg.roll_w, is_index=(kind == "index"))
        keep_rows = np.arange(len(Ds.days)) >= (cut_i - lo)
        fs, fd = frames(name, Ds.days, sn, dy, cfg.cols, keep_rows)
        first_date = Ds.days[cut_i - lo] if len(Ds.days) > cut_i - lo else None
        years = sorted(set(pd.DatetimeIndex(fd["date"]).year.tolist()))
        for tab, F in (("snap", fs), ("day", fd)):
            for y in years:
                part = F[pd.DatetimeIndex(F["date"]).year == y]
                p = out / tab / str(y) / fname(name)
                if cut_i > 0 and p.exists():
                    old = pd.read_parquet(p)
                    old = old[old["date"] < pd.Timestamp(first_date)]
                    part = pd.concat([old, part], ignore_index=True) if len(old) else part
                write_parquet(p, part.reset_index(drop=True))
        # the prefix fingerprint for the next run: sessions up to 5 before the last one
        k_last = S
        first_next = max(0, k_last - 5)
        pre_last = D.days[first_next - 1] if first_next > 0 else None
        dpre = Xd.dates <= pre_last if pre_last is not None else np.zeros(len(Xd.dates), bool)
        st = {"cfg": cfg.key(), "last": str(D.days[-1]), "pre_n": int(first_next),
              "src_pre": fp_hash(D.days[:first_next], D.C[:first_next], D.V[:first_next]),
              "daily_pre": fp_hash(Xd.dates[dpre], Xd.o[dpre], Xd.h[dpre], Xd.l[dpre], Xd.c[dpre]),
              "src_all": src, "built": dt.datetime.now().isoformat()}
        return {"name": name, "status": "full" if cut_i == 0 else "incremental", "rows": int(len(fd)),
                "years": years, "first": str(first_date) if first_date is not None else None, "state": st,
                "secs": round(time.time() - t0, 2)}
    except Exception as e:
        return {"name": name, "status": "failed: %s: %s" % (type(e).__name__, e), "rows": 0}


# ====================================================================================================== home index
def home_table(root: Path, U: Dict[str, Series], months: Sequence[int], log_=log) -> pd.DataFrame:
    """Each stock's home index for each month: the sector index whose NIFTY-adjusted daily returns correlate most
    with the stock's over the 250 sessions before the month (at least 120 shared, correlation >= 0.10)."""
    secs = [s for s in SECTORS if s in U]
    if MASTER not in U or not secs or not months:
        return pd.DataFrame(columns=["symbol", "month", "home", "corr"])
    cal = read_daily(root, MASTER).dates
    T = len(cal)

    def rets(name):
        X = read_daily(root, name)
        c = np.full(T, np.nan)
        pos = np.searchsorted(cal, X.dates)
        ok = (pos < T) & (cal[np.minimum(pos, T - 1)] == X.dates)
        c[pos[ok]] = X.c[ok]
        return np.log(c[1:] / c[:-1])

    eq = [n for n, s in U.items() if s.kind == "equity"]
    rn = rets(MASTER)
    RS = np.full((T - 1, len(secs)), np.nan)
    for k, s in enumerate(secs):
        RS[:, k] = rets(s)
    RX = np.full((T - 1, len(eq)), np.nan)
    for i, nme in enumerate(eq):
        try:
            RX[:, i] = rets(nme)
        except Exception:
            continue
    days = cal[1:]
    ym = pd.DatetimeIndex(days.astype("datetime64[ns]")).year * 100 + pd.DatetimeIndex(
        days.astype("datetime64[ns]")).month
    rows = []

    def resid_z(M, z):
        ok = np.isfinite(M) & np.isfinite(z)[:, None]
        zz = np.where(ok, z[:, None], np.nan)
        mm = np.where(ok, M, np.nan)
        cov = nanq(np.nanmean, mm * zz, axis=0) - nanq(np.nanmean, mm, axis=0) * nanq(np.nanmean, zz, axis=0)
        var = nanq(np.nanvar, zz, axis=0)
        b = cov / np.where(var > 0, var, np.nan)
        res = mm - b[None, :] * zz
        return (res - nanq(np.nanmean, res, axis=0)) / nanq(np.nanstd, res, axis=0)

    for m in sorted(set(int(x) for x in months)):
        b = int(np.searchsorted(ym, m))
        if b >= len(ym) or ym[b] != m:
            b = int(np.searchsorted(ym, m))
        lo = max(0, b - HOME_W)
        if b - lo < HOME_MIN:
            rows.append(pd.DataFrame({"symbol": eq, "month": m, "home": 0, "corr": np.nan}))
            continue
        zx = resid_z(RX[lo:b], rn[lo:b])
        zs = resid_z(RS[lo:b], rn[lo:b])
        vx, vs = np.isfinite(zx), np.isfinite(zs)
        A, B_ = np.where(vx, zx, 0.0), np.where(vs, zs, 0.0)
        num = A.T @ B_
        cnt = vx.astype(float).T @ vs.astype(float)
        corr = np.where(cnt >= HOME_MIN, num / np.maximum(cnt, 1), np.nan)
        best = np.argmax(np.where(np.isfinite(corr), corr, -np.inf), axis=1)
        bc = corr[np.arange(len(eq)), best]
        code = np.where(np.isfinite(bc) & (bc >= HOME_MIN_CORR), [SECTORS.index(secs[k]) + 1 for k in best], 0)
        rows.append(pd.DataFrame({"symbol": eq, "month": m, "home": code.astype(np.int64), "corr": bc}))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=["symbol", "month", "home", "corr"])


# ====================================================================================================== cross-section
def cross_section(S: pd.DataFrame, feats: Sequence[str], eligible: np.ndarray) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """S: rows of (symbol, date, time, features...). Ranks among the eligible rows of each (date, time)."""
    S = S.copy()
    keys = ["date", "time"]
    out = pd.DataFrame({"symbol": S["symbol"].to_numpy(), "date": S["date"].to_numpy(),
                        "time": S["time"].to_numpy()})
    el = pd.Series(eligible, index=S.index)
    g = S.assign(_el=el.to_numpy())
    for f in feats:
        v = S[f].where(el)
        out["xs_" + f] = v.groupby([S["date"], S["time"]]).rank(pct=True, method="average").astype(np.float32)
    out["xs_n"] = el.astype(float).groupby([S["date"], S["time"]]).transform("sum").astype(np.float32)
    home = S["home"].fillna(0).astype(int) if "home" in S else pd.Series(0, index=S.index)
    hs = el & (home > 0)
    up = (S["r_pdc"] > 0).astype(float).where(hs & S["r_pdc"].notna())
    grp = [S["date"], S["time"], home]
    out["xs_sec_n"] = hs.astype(float).where(hs).groupby(grp).transform("sum").astype(np.float32)
    out["xs_sec_up"] = up.groupby(grp).transform("mean").astype(np.float32)
    out["xs_sec_rank"] = S["r_pdc"].where(hs).groupby(grp).rank(pct=True, method="average").astype(np.float32)
    out.loc[~hs.to_numpy(), ["xs_sec_n", "xs_sec_up", "xs_sec_rank"]] = np.nan
    # the market at each moment
    E = g[g["_el"]]
    def share(col, cond):
        v = cond(E[col]).astype(float).where(E[col].notna())
        return v.groupby([E["date"], E["time"]]).mean()
    M = pd.DataFrame({"n_eq": E.groupby(keys).size()})
    tot = g.groupby(keys).size()
    M["coverage"] = M["n_eq"] / tot.reindex(M.index)
    M["up_pdc"] = share("r_pdc", lambda s: s > 0)
    if "r_op" in E:
        M["up_op"] = share("r_op", lambda s: s > 0)
    M["above_vwap"] = share("vwap_dist", lambda s: s > 0)
    for lv, nm in (("lv_pdh_brk_mins", "broke_pdh"), ("lv_pdl_brk_mins", "broke_pdl")):
        if lv in E:
            M[nm] = E[lv].notna().astype(float).groupby([E["date"], E["time"]]).mean()
    for col, nm in (("r_op", "med_r_op"), ("r_pdc", "med_r_pdc"), ("rvol", "med_rvol")):
        if col in E:
            M[nm] = E[col].groupby([E["date"], E["time"]]).median()
    M = M.reset_index()
    for c in M.columns:
        if c not in keys:
            M[c] = M[c].astype(np.float32)
    return out, M


def read_year(out: Path, tab: str, y: int, cols: Sequence[str], names: Optional[set] = None,
              dates=None, threads: int = 8) -> pd.DataFrame:
    import pyarrow.parquet as pq
    files = sorted((out / tab / str(y)).glob("*" + SUFFIX))
    if names is not None:
        files = [f for f in files if f.name[: -len(SUFFIX)] in names]

    def rd(f):
        try:
            sch = pq.read_schema(f).names
            t = pq.read_table(f, columns=[c for c in cols if c in sch]).to_pandas()
            if dates is not None:
                t = t[t["date"].isin(dates)]
            return t
        except Exception:
            return None

    with cf.ThreadPoolExecutor(threads) as ex:
        parts = [p for p in ex.map(rd, files) if p is not None and len(p)]
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=list(cols))


def build_xs(out: Path, years: Sequence[int], equities: set, dates_by_year: Optional[dict] = None) -> int:
    n = 0
    for y in sorted(set(years)):
        dts = dates_by_year.get(y) if dates_by_year else None
        sc = ["symbol", "date", "time", "basis_open_ok", "home", "lv_pdh_brk_mins", "lv_pdl_brk_mins"] + list(XS_SNAP)
        Ssnap = read_year(out, "snap", y, sc, equities, dts)
        dc = ["symbol", "date", "basis_ok", "basis_open_ok", "home", "lv_pdh_brk_mins", "lv_pdl_brk_mins", "r_op",
              "rvol"] + list(XS_DAY)
        Sday = read_year(out, "day", y, list(dict.fromkeys(dc)), equities, dts)
        parts_x, parts_m = [], []
        if len(Ssnap):
            el = (Ssnap["basis_open_ok"] != 0).to_numpy() & Ssnap["r_op"].notna().to_numpy()
            x, m = cross_section(Ssnap, XS_SNAP, el)
            parts_x.append(x)
            parts_m.append(m)
        if len(Sday):
            Sday = Sday.assign(time=np.int16(1530))
            el = (Sday["basis_ok"] == 1).to_numpy() & (Sday["basis_open_ok"] != 0).to_numpy() & \
                Sday["r_oc"].notna().to_numpy()
            x, m = cross_section(Sday, XS_DAY, el)
            parts_x.append(x)
            parts_m.append(m)
        if not parts_x:
            continue
        X = pd.concat(parts_x, ignore_index=True)
        M = pd.concat(parts_m, ignore_index=True)
        px, pm = out / "xs" / ("xs_%d.parquet" % y), out / "market" / ("market_%d.parquet" % y)
        if dts is not None:
            for p, F in ((px, "X"), (pm, "M")):
                if p.exists():
                    old = pd.read_parquet(p)
                    old = old[~old["date"].isin(dts)]
                    if F == "X":
                        X = pd.concat([old, X], ignore_index=True)
                    else:
                        M = pd.concat([old, M], ignore_index=True)
        X = X.sort_values(["date", "time", "symbol"], kind="mergesort").reset_index(drop=True)
        M = M.sort_values(["date", "time"], kind="mergesort").reset_index(drop=True)
        write_parquet(px, X)
        write_parquet(pm, M)
        n += len(X)
    return n


# ====================================================================================================== the contract
def describe(name: str) -> Tuple[str, str, bool]:
    """(meaning, unit, proxy) for every column."""
    fixed = {
        "basis_open_ok": ("1 if the first bar's open agrees with the official open (1.5% at 09:15, 15% later); 0 = a "
                          "basis fault (values blank)", "flag", False),
        "basis_ok": ("0 if the session's 3-minute high and low sit on one ratio to the daily bar beyond 0.5% (basis "
                     "fault, values blank)", "flag", False),
        "daily_match": ("tradelab's usable-session test: >= 80% of bars, a 09:15 bar, open/high/low within 0.5% of the "
                        "daily bar", "flag", False),
        "cover": ("share of bars printed so far (of bars 09:15 .. now)", "share", False),
        "bars_missing": ("bars with no print so far", "bars", False),
        "miss_run_max": ("longest run of bars without a print so far", "bars", False),
        "mins_since_trade": ("minutes since the last printed bar ended", "minutes", False),
        "flat_bars": ("one-price bars (high = low) so far", "bars", False),
        "gap": ("official open / previous close - 1", "return", False),
        "gap_atr": ("(official open - previous close) / ATR14 (previous sessions)", "ATR", False),
        "op_in_prev_range": ("official open's place in the previous day's range (0 = low, 1 = high)", "share", False),
        "r_op": ("last close / official open - 1", "return", False),
        "r_pdc": ("last close / previous close - 1", "return", False),
        "r_op_atr": ("(last close - official open) / ATR14", "ATR", False),
        "rise_op": ("highest high so far / official open - 1", "return", False),
        "fall_op": ("lowest low so far / official open - 1", "return", False),
        "mins_since_hi": ("minutes since the bar that set the running high", "minutes", False),
        "mins_since_lo": ("minutes since the bar that set the running low", "minutes", False),
        "hi_first": ("1 if the running high was set before the running low", "flag", False),
        "pos_range": ("last close's place in the range so far (0 = low, 1 = high)", "share", False),
        "range_op": ("(high - low so far) / official open", "return", False),
        "range_atr": ("(high - low so far) / ATR14", "ATR", False),
        "dd_max": ("largest fall from a prior peak (incl. the open) to a later bar's low, so far", "return", False),
        "ru_max": ("largest rise from a prior trough (incl. the open) to a later bar's high, so far", "return", False),
        "giveback": ("share of the open-to-high gain given back (high > open + 0.1%)", "share", False),
        "recover": ("share of the open-to-low loss recovered (low < open - 0.1%)", "share", False),
        "eff_signed": ("(last close - open) / total close-to-close movement: +1 straight up, -1 straight down",
                       "share", False),
        "eff_abs": ("absolute path efficiency", "share", False),
        "gap_fill": ("share of the opening gap filled so far (gaps >= 0.1%)", "share", False),
        "gap_fill_mins": ("minute (after 09:15) when the gap was fully filled", "minutes", False),
        "gap_ext": ("largest move in the gap's direction before the fill (or so far)", "return", False),
        "rv": ("realized volatility so far: sqrt(sum of squared 3-minute log returns, the first from the open)",
               "log return", False),
        "rv_rel": ("rv / (ATR14 / previous close)", "ratio", False),
        "dn_share": ("share of realized variance from falling bars", "share", False),
        "worst_bar": ("worst 3-minute log return so far", "log return", False),
        "best_bar": ("best 3-minute log return so far", "log return", False),
        "big_bar_share": ("largest bar's share of realized variance", "share", False),
        "vwap_dist": ("last close / VWAP - 1 (VWAP from bars: typical price x volume)", "return", True),
        "vwap_slope": ("VWAP now / VWAP 30 minutes earlier - 1", "return", True),
        "vwap_above": ("share of printed bars closing above VWAP", "share", True),
        "log_rs_traded": ("log10 of rupees traded so far (typical price x volume)", "log10 Rs", True),
        "top3_vol_share": ("volume share of the 3 largest bars so far", "share", False),
        "signed_vol": ("(volume of up-bars - volume of down-bars) / volume, bar close vs bar open", "share", True),
        "vol_dn_share": ("share of volume on bars that closed below the previous close", "share", True),
        "streak": ("consecutive bars closing the same way (+ up, - down)", "bars", False),
        "rvol": ("cumulative volume / the median of the prior 20 sessions' cumulative volume at the same bar",
                 "ratio", False),
        "rng5_rel": ("range of the last 5 bars / last close / the stock's normal bar range", "ratio", False),
        "rng10_rel": ("range of the last 10 bars / last close / the stock's normal bar range", "ratio", False),
        "inside_run": ("consecutive inside bars", "bars", False),
        "box_pos": ("last close's place in the previous 10 bars' range (>1 above, <0 below)", "share", False),
        "box_width_rel": ("previous 10 bars' range / last close / normal bar range", "ratio", False),
        "mins_since_box_brk": ("minutes since the latest close outside the previous 10 bars' range (+ up, - down)",
                               "minutes", False),
        "box_brk_vol": ("the latest box-break bar's volume / that bar's normal volume (prior 20 sessions)",
                        "ratio", False),
        "box_brk_failed": ("1 if the latest box break closed back inside within 5 bars, 0 if it held, blank while "
                           "pending", "flag", False),
        "band_up_bars": ("bars closing at their high at an upper circuit-band price", "bars", True),
        "band_dn_bars": ("bars closing at their low at a lower circuit-band price", "bars", True),
        "band_dn_onep": ("one-price bars at a lower circuit-band price", "bars", True),
        "nifty_r_op": ("NIFTY 50's last 3-minute close / its open - 1", "return", False),
        "rel_nifty": ("r_op - nifty_r_op", "return", False),
        "beta_n": ("beta of 3-minute returns to NIFTY 50's, session so far (>= 10 shared bars)", "beta", False),
        "corr_n": ("correlation of 3-minute returns with NIFTY 50's, session so far", "corr", False),
        "idio_rv": ("realized volatility not explained by NIFTY 50 (session so far)", "log return", False),
        "nifty_up_r": ("sum of the stock's 3-minute returns on bars NIFTY rose", "log return", False),
        "nifty_dn_r": ("sum of the stock's 3-minute returns on bars NIFTY fell", "log return", False),
        "home": ("home index code (contract 'home_codes'; 0 = none)", "code", True),
        "sec_r_op": ("home index's last 3-minute close / its open - 1", "return", True),
        "rel_sec": ("r_op - sec_r_op", "return", True),
        "h_n": ("prior sessions with a value at this clock time (history depth)", "sessions", False),
        "label_r_to_eod": ("OUTCOME: the 15:27 bar's close / this time's last close - 1 (never an input)", "return",
                           False),
        "label_r_to_official_close": ("OUTCOME: the official close / this time's last close - 1 (never an input)",
                                      "return", False),
        "r_seg1": ("09:45 close / official open - 1", "return", False),
        "r_seg2": ("11:15 close / 09:45 close - 1", "return", False),
        "r_seg3": ("13:15 close / 11:15 close - 1", "return", False),
        "r_seg4": ("14:45 close / 13:15 close - 1", "return", False),
        "r_seg5": ("15:30 (last bar) close / 14:45 close - 1", "return", False),
        "r_last30": ("15:30 close / 15:00 close - 1", "return", False),
        "r_auction": ("official close / last 3-minute close - 1 (the closing session's move)", "return", False),
        "r_oc": ("official close / official open - 1", "return", False),
        "hi_min": ("minute the day's high was first reached", "minutes", False),
        "lo_min": ("minute the day's low was first reached", "minutes", False),
        "bv_rel": ("bipower variation (sqrt) / ATR%", "ratio", False),
        "jump_share": ("max(0, RV - bipower) / RV: the share of variance in jumps", "share", False),
        "rskew": ("realized skewness of 3-minute returns", "skew", False),
        "rkurt": ("realized kurtosis of 3-minute returns", "kurtosis", False),
        "park_rel": ("Parkinson volatility from bar highs/lows / ATR%", "ratio", False),
        "rv_hour1_share": ("share of the day's realized variance in the first hour", "share", False),
        "rvol_day": ("day's 3-minute volume / median daily volume of the prior 20 sessions", "ratio", False),
        "vol_first30_share": ("volume share of the first 30 minutes", "share", False),
        "vol_last30_share": ("volume share of the last 30 minutes", "share", False),
        "vol_peak_min": ("minute the busiest bar ended", "minutes", False),
        "vol_hhi": ("concentration of the day's volume across bars (Herfindahl)", "share", False),
        "spread_cs": ("Corwin-Schultz spread estimate from consecutive bars", "fraction", True),
        "spread_ar": ("Abdi-Ranaldo spread estimate from bar close/high/low", "fraction", True),
        "amihud": ("mean |3-minute return| per crore rupees traded", "return per Rs crore", True),
        "miss_share": ("share of the session's 125 bars without a print", "share", False),
        "band_up_first": ("minute of the first bar at an upper band", "minutes", True),
        "band_dn_first": ("minute of the first bar at a lower band", "minutes", True),
        "band_up_last_bar": ("1 if the last printed bar sat at an upper band", "flag", True),
        "band_dn_last_bar": ("1 if the last printed bar sat at a lower band", "flag", True),
        "box_brk_up_n": ("closes above the previous 10 bars' range", "count", False),
        "box_brk_dn_n": ("closes below the previous 10 bars' range", "count", False),
        "box_fail_n": ("box breaks that closed back inside within 5 bars", "count", False),
        "ev_op_reclaim": ("minute of the first close back above the open after the first close below it",
                          "minutes", False),
        "ev_op_lose": ("minute of the first close back below the open after the first close above it", "minutes",
                       False),
    }
    if name in fixed:
        return fixed[name]
    lvn = {"pdh": "previous day's high", "pwh": "previous 5 sessions' high", "or15h": "15-minute opening-range high",
           "or30h": "30-minute opening-range high", "swh": "latest confirmed swing high",
           "pdl": "previous day's low", "pwl": "previous 5 sessions' low", "or15l": "15-minute opening-range low",
           "or30l": "30-minute opening-range low", "swl": "latest confirmed swing low",
           "pdc": "previous close", "op": "official open", "vwap": "VWAP (bar-based)"}
    m = re.match(r"^lv_([a-z0-9]+)_(dist|brk_mins|retest|fail|side|x|lastx_mins)$", name)
    if m and m.group(1) in lvn:
        L_, what = lvn[m.group(1)], m.group(2)
        up = m.group(1) in UP_LV
        d = {"dist": ("last close / the %s - 1" % L_, "return"),
             "brk_mins": ("minutes since the first close %s the %s (blank if none yet)" % ("above" if up else "below",
                                                                                      L_), "minutes"),
             "retest": ("1 if, after the break, a later bar came back within 0.1%% of the %s and closed beyond it; "
                        "0 if not yet; blank before a break" % L_, "flag"),
             "fail": ("1 if, after the break, a later bar closed back on the other side of the %s; blank before a "
                      "break" % L_, "flag"),
             "side": ("+1 last close above the %s, -1 below" % L_, "sign"),
             "x": ("closes crossing the %s so far" % L_, "count"),
             "lastx_mins": ("minutes since the latest crossing of the %s (+ upward, - downward)" % L_, "minutes")}
        return d[what][0], d[what][1], m.group(1) in ("vwap",)
    m = re.match(r"^ev_([a-z0-9]+)_(touch|brk|retest|fail|x|beyond|start|xup|xdn|above|lastx|lastdir|brk_lvl|xup_lvl|"
                 r"xdn_lvl)$", name)
    if m and m.group(1) in lvn:
        L_, what = lvn[m.group(1)], m.group(2)
        d = {"touch": "minute the %s was first touched", "brk": "minute of the first close beyond the %s",
             "retest": "minute of the first retest that held after the break of the %s",
             "fail": "minute of the first close back after the break of the %s", "x": "closes crossing the %s",
             "beyond": "share of bars closing beyond the %s", "start": "+1 official open above the %s, -1 below",
             "xup": "minute of the first upward crossing of the %s", "xdn": "minute of the first downward crossing "
                                                                         "of the %s",
             "above": "share of bars closing above the %s", "lastx": "minute of the latest crossing of the %s",
             "lastdir": "+1 if the latest crossing of the %s was upward", "brk_lvl": "the %s at its break / open - 1",
             "xup_lvl": "the %s at its first upward crossing / open - 1",
             "xdn_lvl": "the %s at its first downward crossing / open - 1"}
        unit = "minutes" if what in ("touch", "brk", "retest", "fail", "xup", "xdn", "lastx") else \
            ("count" if what == "x" else ("share" if what in ("beyond", "above") else
                                          ("return" if what.endswith("lvl") else "sign")))
        return d[what] % L_, unit, m.group(1) == "vwap"
    m = re.match(r"^h_(.+)_(med|pct|mad)$", name)
    if m:
        w = {"med": "median", "pct": "today's percentile among", "mad": "median absolute deviation"}[m.group(2)]
        return "%s %s at the same clock time over the prior sessions (prior sessions only)" % (w, m.group(1)), \
            "as feature" if m.group(2) != "pct" else "share", False
    m = re.match(r"^avg(\d+)_(.+)$", name)
    if m:
        return "mean of %s over the last %s sessions (today included)" % (m.group(2), m.group(1)), "as feature", False
    m = re.match(r"^z(\d+)_(.+)$", name)
    if m:
        return "today's %s against the prior %s sessions (z-score)" % (m.group(2), m.group(1)), "z", False
    m = re.match(r"^xs_(.+)$", name)
    if m:
        k = m.group(1)
        if k == "n":
            return "stocks ranked at this moment (peer count)", "count", False
        if k == "sec_n":
            return "stocks in the same home index ranked at this moment", "count", True
        if k == "sec_up":
            return "share of the home index's stocks up on the previous close", "share", True
        if k == "sec_rank":
            return "percentile of r_pdc within the home index's stocks", "share", True
        return "percentile (0..1) of %s among the stocks with data at this moment" % k, "share", False
    raise F3Error("no description for column '%s'" % name)


def contract(sample_snap: Sequence[str], sample_day: Sequence[str], xs_cols: Sequence[str],
             mk_cols: Sequence[str], cfg: Cfg) -> dict:
    ident = {"symbol", "date", "time"}
    cols = []
    for tab, names, known in (("snap", sample_snap, "at the snapshot time (bars ended by it)"),
                              ("day", sample_day, "at 15:30; usable from the next session's open"),
                              ("xs", xs_cols, "with its row (snapshot time, or 15:30 for time 1530)")):
        for nm in names:
            if nm in ident:
                continue
            about, unit, proxy = describe(nm)
            kn = known
            if nm.startswith("label_"):
                kn = "AFTER the snapshot (15:30): an outcome, never an input"
            cols.append({"table": tab, "name": nm, "about": about, "unit": unit, "proxy": bool(proxy),
                         "known": kn})
    for nm in mk_cols:
        if nm not in ("date", "time"):
            cols.append({"table": "market", "name": nm, "about": "market breadth among ranked stocks: %s" % nm,
                         "unit": "share" if nm not in ("n_eq",) else "count", "proxy": False,
                         "known": "with its row"})
    return {"tool": VERSION, "engine": ENGINE, "config": cfg.key(),
            "clock": "a value at T uses bars that ended by T; event minutes are minutes after 09:15 when the event "
                     "became known (the end of its bar)",
            "home_codes": {i + 1: s for i, s in enumerate(SECTORS)}, "columns": cols}


def forbidden(name: str) -> bool:
    low = name.lower()
    if low.startswith("label_"):
        return False                     # outcomes are named label_*: the firewall keeps them out of inputs
    return any(p in low for p in FORWARD) or low in RAW or "turnover" in low or \
        low.endswith(("_open", "_close", "_high", "_low"))


# ====================================================================================================== commands
def guard_out(out: Path, root: Path) -> None:
    o = out.resolve()
    for bad in (root.resolve(),):
        if o == bad or bad in o.parents:
            raise F3Error("--out %s is inside the daily cache - refused" % out)
    if "bigmove_deploy" in [p.lower() for p in o.parts]:
        raise F3Error("--out %s is inside bigmove_deploy - refused" % out)


def market_files(U: Dict[str, Series]) -> List[Tuple[str, str]]:
    return [(nm, str(U[nm].file)) for nm in [MASTER] + list(SECTORS) if nm in U]


def run_build(a) -> int:
    t0 = time.time()
    root = Path(a.root)
    sdir = store_dir(root, a.store)
    out = Path(a.out) if a.out else root.parent / "features_3m"
    guard_out(out, root)
    cfg = Cfg(a.snap_times or SNAP_TIMES, a.hist, a.roll or ROLL_W)
    U = load_universe(root, sdir, a.symbols)
    if MASTER not in U:
        raise F3Error("NIFTY50 is not in the daily cache")
    out.mkdir(parents=True, exist_ok=True)
    bj = read_json(out / "_state" / "build.json") or {}
    if bj.get("cfg") and bj["cfg"] != cfg.key() and not a.full:
        raise F3Error("the feature definitions changed (%s -> %s): run with --full to rebuild everything" % (
            bj["cfg"], cfg.key()))
    log("%s | %d series | store %s | out %s | snapshots %s | history %d | rolling %s" % (
        VERSION, len(U), sdir, out, ",".join(cfg.snap_times), cfg.hist_w, list(cfg.roll_w)))
    # home index: months not yet known (all with --full)
    hp = out / "home_index.parquet"
    Hold = pd.read_parquet(hp) if (hp.exists() and not a.full) else pd.DataFrame(
        columns=["symbol", "month", "home", "corr"])
    cal = read_daily(root, MASTER).dates
    months = sorted(set((pd.DatetimeIndex(cal.astype("datetime64[ns]")).year * 100 +
                         pd.DatetimeIndex(cal.astype("datetime64[ns]")).month).tolist()))
    have = set(Hold["month"].astype(int).tolist()) if len(Hold) else set()
    todo_m = [m for m in months if m not in have]
    eq_names = {n for n, s in U.items() if s.kind == "equity"}
    if todo_m:
        Hn = home_table(root, U, todo_m)
        Hold = Hold[~Hold["month"].isin(todo_m)] if len(Hold) else Hold
        Hall = pd.concat([Hold, Hn], ignore_index=True) if len(Hold) else Hn
        write_parquet(hp, Hall.reset_index(drop=True))
        log("home index: %d months computed" % len(todo_m))
    states = {}
    for n_ in U:
        states[n_] = read_json(out / "_state" / "sym" / ("%s.json" % n_)) or {}
    tasks = [(n_, U[n_].kind, str(U[n_].file), states[n_], bool(a.full)) for n_ in sorted(U)]
    init = (str(root), str(sdir), str(out), cfg.key(), market_files(U), str(hp))
    res = []
    if a.workers <= 1:
        _init_worker(*init)
        for i, t in enumerate(tasks, 1):
            res.append(run_series(t))
            if i % 200 == 0:
                log("   %d of %d series" % (i, len(tasks)))
    else:
        import multiprocessing as mp
        with cf.ProcessPoolExecutor(max_workers=a.workers, initializer=_init_worker, initargs=init,
                                    mp_context=mp.get_context("spawn")) as ex:      # Windows' way, everywhere
            for i, r in enumerate(ex.map(run_series, tasks, chunksize=4), 1):
                res.append(r)
                if i % 200 == 0:
                    log("   %d of %d series" % (i, len(tasks)))
    failed = {r["name"]: r["status"] for r in res if str(r["status"]).startswith("failed")}
    years, dates_by_year = set(), {}
    for r in res:
        if r.get("state"):
            write_json(out / "_state" / "sym" / ("%s.json" % r["name"]), r["state"])
        for y in r.get("years", []):
            years.add(y)
    # cross-section: whole years on a full build, else the recomputed dates
    full_years = a.full or not bj
    if not full_years:
        firsts = [np.datetime64(r["first"], "D") for r in res if r.get("first")]
        if firsts:
            d0 = min(firsts)
            alld = cal[cal >= d0]
            for d in alld:
                dates_by_year.setdefault(int(str(d)[:4]), []).append(pd.Timestamp(d))
            years = set(dates_by_year)
    nx = build_xs(out, sorted(years), eq_names, None if full_years else dates_by_year)
    S1 = pd.read_parquet(next((out / "snap").rglob("*.parquet"))) if (out / "snap").exists() and \
        any((out / "snap").rglob("*.parquet")) else pd.DataFrame()
    D1 = pd.read_parquet(next((out / "day").rglob("*.parquet"))) if (out / "day").exists() and \
        any((out / "day").rglob("*.parquet")) else pd.DataFrame()
    xsf = next((out / "xs").glob("*.parquet"), None) if (out / "xs").exists() else None
    mkf = next((out / "market").glob("*.parquet"), None) if (out / "market").exists() else None
    xs_cols = list(pd.read_parquet(xsf).columns) if xsf else []
    mk_cols = list(pd.read_parquet(mkf).columns) if mkf else []
    if len(S1) and len(D1):
        write_json(out / "contract.json", contract(list(S1.columns), list(D1.columns), xs_cols, mk_cols, cfg))
    write_json(out / "_state" / "build.json", {"tool": VERSION, "cfg": cfg.key(), "built": dt.datetime.now().isoformat(),
                                               "series": len(U)})
    nfull = sum(1 for r in res if r["status"] == "full")
    ninc = sum(1 for r in res if r["status"] == "incremental")
    rows = sum(r["rows"] for r in res)
    with open(out / "_state" / "runs.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"tool": VERSION, "at": dt.datetime.now().isoformat(), "series": len(U), "full": nfull,
                            "incremental": ninc, "day_rows": rows, "xs_rows": nx, "failed": len(failed),
                            "minutes": round((time.time() - t0) / 60, 2)}) + "\n")
    skipped = [r for r in res if r["status"] not in ("full", "incremental") and not str(r["status"]).startswith(
        "failed")]
    L = ["", "=" * 74, "3-MINUTE FEATURES (%s)" % VERSION, "=" * 74,
         "  out          : %s" % out,
         "  series       : %d computed in full, %d brought forward, %d without 3-minute bars, %d failed" % (
             nfull, ninc, len(skipped), len(failed)),
         "  rows         : %d stock-days written; %d cross-section rows" % (rows, nx),
         "  time         : %.1f minutes" % ((time.time() - t0) / 60)]
    if failed:
        L.append("  FAILED       : " + "; ".join("%s (%s)" % (k, v[:80]) for k, v in list(failed.items())[:8]))
    L.append("=" * 74)
    print("\n".join(L), flush=True)
    return 2 if failed else 0


def asof_frame(root: Path, sdir: Path, names: Sequence[str], date, hhmm: str, cfg: Optional[Cfg] = None,
               home_path: Optional[Path] = None) -> pd.DataFrame:
    """Every snapshot value at any completed bar, from files physically cut at that bar (and today's daily bar
    reduced to its open). With several stocks the cross-sectional ranks are among them."""
    cfg = cfg or Cfg()
    jT = t2j(hhmm)
    d = np.datetime64(date, "D")
    U = load_universe(root, sdir, list(names))
    MK = MarketSet()
    for nm in [MASTER] + list(SECTORS):
        if nm in U:
            MK.add(nm, to_dense(read_bars(U[nm].file, cut=(d, jT))), read_daily(root, nm, before=d, open_on=d))
    Hh = pd.read_parquet(home_path) if home_path and Path(home_path).exists() else None
    rows = []
    for nm in names:
        if nm not in U:
            continue
        D = to_dense(read_bars(U[nm].file, cut=(d, jT)))
        Xd = read_daily(root, nm, before=d, open_on=d)
        if not len(D.days) or D.days[-1] != d or not np.any(Xd.dates == d):
            continue
        hasd = np.isin(D.days, Xd.dates)
        for k in Dense.__slots__:
            setattr(D, k, getattr(D, k)[hasd])
        lo = max(0, len(D.days) - cfg.need - 1)
        Ds = slice_dense(D, lo)
        sn, _ = engine(Ds, daily_ctx(Xd, Ds.days), MK, home_for(Hh, nm, Ds.days), [jT], cfg.hist_w, cfg.roll_w,
                       is_index=(U[nm].kind == "index"))
        keep = np.zeros(len(Ds.days), bool)
        keep[-1] = True
        fs, _ = frames(nm, Ds.days, sn, {}, [jT], keep)
        rows.append(fs.assign(_eq=U[nm].kind == "equity"))
    if not rows:
        return pd.DataFrame()
    F = pd.concat(rows, ignore_index=True)
    lab = [c for c in F.columns if c.startswith("label_")]
    F = F.drop(columns=lab)                  # outcomes need the future: never in an as-of answer
    eq = F["_eq"].to_numpy()
    if eq.sum() >= 2:
        el = eq & (F["basis_open_ok"] != 0).to_numpy() & F["r_op"].notna().to_numpy()
        x, _ = cross_section(F[F["_eq"]].reset_index(drop=True), XS_SNAP, el[eq])
        F = F.merge(x.drop(columns=["date", "time"]), on="symbol", how="left")
    return F.drop(columns=["_eq"])


def run_asof(a) -> int:
    root = Path(a.root)
    sdir = store_dir(root, a.store)
    out = Path(a.out) if a.out else root.parent / "features_3m"
    names = list(a.symbols or [])
    if not names:
        U = load_universe(root, sdir)
        names = sorted(n for n, s in U.items() if s.kind == "equity")
    cfg = Cfg(a.snap_times or SNAP_TIMES, a.hist, a.roll or ROLL_W)
    F = asof_frame(root, sdir, names, a.date, a.time, cfg, out / "home_index.parquet")
    if F.empty:
        print("no rows: none of the series has bars on %s by %s" % (a.date, a.time))
        return 2
    if a.csv:
        F.to_csv(a.csv, index=False)
        print("wrote %s (%d rows, %d columns)" % (a.csv, len(F), F.shape[1]))
    else:
        show = F.set_index("symbol").T
        with pd.option_context("display.max_rows", 400, "display.width", 160):
            print(show.to_string())
    return 0


def load(out, table: str, columns=None, symbols=None, start=None, end=None, times=None) -> pd.DataFrame:
    """Read a table back: table in snap / day / xs / market; filters by symbols, date range and snapshot times."""
    out = Path(out)
    if table in ("snap", "day"):
        years = sorted(int(p.name) for p in (out / table).iterdir() if p.is_dir() and p.name.isdigit())
        files = []
        for y in years:
            if (start and y < pd.Timestamp(start).year) or (end and y > pd.Timestamp(end).year):
                continue
            for f in sorted((out / table / str(y)).glob("*" + SUFFIX)):
                if symbols is None or f.name[: -len(SUFFIX)] in set(symbols):
                    files.append(f)
    else:
        files = sorted((out / table).glob("*.parquet"))
    parts = []
    for f in files:
        t = pd.read_parquet(f, columns=None if columns is None else
                            list(dict.fromkeys(["symbol", "date", "time"][: 3 if table != "day" else 2] +
                                               list(columns))))
        if symbols is not None and "symbol" in t:
            t = t[t["symbol"].isin(list(symbols))]
        if start is not None:
            t = t[t["date"] >= pd.Timestamp(start)]
        if end is not None:
            t = t[t["date"] <= pd.Timestamp(end)]
        if times is not None and "time" in t:
            t = t[t["time"].isin([int(str(x).replace(":", "")) for x in times])]
        if len(t):
            parts.append(t)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="features_3m", description=VERSION)
    ap.add_argument("cmd", choices=["build", "asof"])
    ap.add_argument("--root", default=os.environ.get("CACHE_DAILY_ROOT"), help="the daily cache")
    ap.add_argument("--store", help="the 3-minute folder (default: production's intraday_cache.store(root))")
    ap.add_argument("--out", help="output folder (default: <daily cache's parent>\\features_3m)")
    ap.add_argument("--symbols", nargs="*", help="only these series (build: NIFTY50 and the sector indices always "
                                                 "come along)")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--full", action="store_true", help="build: recompute everything")
    ap.add_argument("--snap-times", dest="snap_times", nargs="*", help="snapshot times (HH:MM, bar ends)")
    ap.add_argument("--hist", type=int, default=HIST_W, help="same-clock history: prior sessions")
    ap.add_argument("--roll", type=int, nargs="*", help="rolling windows of the day table (sessions)")
    ap.add_argument("--date", help="asof: the session")
    ap.add_argument("--time", help="asof: HH:MM (a value at T uses bars that ended by T)")
    ap.add_argument("--csv", help="asof: write the rows here")
    a = ap.parse_args(argv)
    print(VERSION, flush=True)
    if not a.root:
        print("REFUSED: give --root or run env_daily.bat (CACHE_DAILY_ROOT is not set)", flush=True)
        return 3
    try:
        if a.cmd == "asof":
            if not a.date or not a.time:
                raise F3Error("asof needs --date and --time")
            return run_asof(a)
        return run_build(a)
    except F3Error as e:
        print("REFUSED: %s" % e, flush=True)
        return 3


if __name__ == "__main__":
    sys.exit(main())
