@echo off
rem features_3m v1.0 - the evening feature build (run it after cache3m_daily.bat)
rem extra arguments pass through, e.g.  features_3m_daily.bat --workers 6
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\features_3m
python features_3m.py build %*
exit /b %ERRORLEVEL%
