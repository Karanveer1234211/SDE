"""
f3_world.py - features_3m's test world (NOT production code).

A daily cache and a 3-minute store (with cache3m's catalog) for 12 stocks and 3 indices over ~320 sessions, built from
one market factor, two sector factors and stock noise, with planted days whose features are known exactly:

  EVNT  session E1: opens below the previous high, first close above it in bar 10, retest that holds in bar 20,
        closes back below in bar 50                -> ev_pdh_brk 33, ev_pdh_retest 63, ev_pdh_fail 153
  GAPF  session E2: opens 2% above the previous close, fills in bar 30 (its high before that: bar 5)
  LOCK  session E5: from bar 60 one-price bars at the 5% lower band to the close
  ILLQ  thinly traded (about 40% of bars); session E4: bars only in even slots
  VOLX  the last session: first-hour volume x3 and a 4% rise by 10:15
  BADB  before E3 its 3-minute bars sit at 2x the daily bars (a basis fault)
  BETA  3-minute returns = 1.5 x NIFTY's (+ small noise)
  ITA ITB ITC2 (IT), BKA BKB (banks): sector members, for the home index
"""
from __future__ import annotations

import json
import shutil
import textwrap
from pathlib import Path
from typing import Dict

import numpy as np
import pandas as pd

IST = "Asia/Kolkata"
NB = 125
SPECS = {
    # name: (kind, tradingsymbol, start price, sector, market beta)
    "NIFTY50": ("index", "NIFTY 50", 22000.0, None, 1.0),
    "NIFTYIT": ("index", "NIFTY IT", 35000.0, "IT", 1.0),
    "NIFTYBANK": ("index", "NIFTY BANK", 48000.0, "BANK", 1.0),
    "ITA": ("equity", "ITA", 1500.0, "IT", 1.0),
    "ITB": ("equity", "ITB", 800.0, "IT", 0.9),
    "ITC2": ("equity", "ITC2", 400.0, "IT", 1.1),
    "BKA": ("equity", "BKA", 1200.0, "BANK", 1.2),
    "BKB": ("equity", "BKB", 600.0, "BANK", 1.0),
    "EVNT": ("equity", "EVNT", 1500.0, None, 1.0),
    "GAPF": ("equity", "GAPF", 900.0, None, 1.0),
    "BADB": ("equity", "BADB", 700.0, None, 1.0),
    "ILLQ": ("equity", "ILLQ", 120.0, None, 0.8),
    "LOCK": ("equity", "LOCK", 500.0, None, 1.0),
    "BETA": ("equity", "BETA", 1000.0, None, 1.5),
    "VOLX": ("equity", "VOLX", 650.0, None, 1.0),
}
HOLIDAYS = ["2025-01-26", "2025-03-14", "2025-08-15", "2025-10-02", "2026-01-26"]


def calendar(n=None):
    d = pd.bdate_range("2025-01-01", "2026-04-10").to_numpy().astype("datetime64[D]")
    d = d[~np.isin(d, np.array(HOLIDAYS, dtype="datetime64[D]"))]
    return d if n is None else d[:n]


def tick(x):
    return np.round(np.round(x / 0.05) * 0.05, 2)


class World:
    def __init__(self, base: Path, seed: int = 7, n_sessions: int = 320):
        self.base = Path(base)
        if self.base.exists():
            shutil.rmtree(self.base)
        self.root = self.base / "cache_daily"
        self.store = self.root / "intraday_3m"
        self.mods = self.base / "_mods"
        self.store.mkdir(parents=True)
        self.mods.mkdir(parents=True)
        self.cal = calendar(n_sessions)
        S = len(self.cal)
        self.S = S
        self.E1, self.E2, self.E3, self.E4, self.E5 = S - 20, S - 15, S - 40, S - 12, S - 10
        rng = np.random.default_rng(seed)
        m = rng.normal(0, 0.0008, (S, NB))
        gm = rng.normal(0, 0.004, S)
        sf = {"IT": (rng.normal(0, 0.0006, (S, NB)), rng.normal(0, 0.003, S)),
              "BANK": (rng.normal(0, 0.0006, (S, NB)), rng.normal(0, 0.003, S))}
        self.bars: Dict[str, dict] = {}
        for name, (kind, tsym, p0, sec, beta) in SPECS.items():
            if kind == "index":
                r = m.copy() if sec is None else m + sf[sec][0]
                g = gm.copy() if sec is None else gm + sf[sec][1]
            else:
                idio = rng.normal(0, 0.0012 if name != "BETA" else 0.0003, (S, NB))
                r = beta * m + idio + (sf[sec][0] if sec else 0)
                g = beta * gm + rng.normal(0, 0.004, S) + (sf[sec][1] if sec else 0)
            first = np.zeros((S, NB))
            first[:, 0] = g
            lc = np.log(p0) + np.cumsum((r + first).reshape(-1)).reshape(S, NB)
            lo_ = lc - r
            O, C = np.exp(lo_), np.exp(lc)
            H = np.maximum(O, C) * np.exp(np.abs(rng.normal(0, 0.0004, (S, NB))))
            L = np.minimum(O, C) * np.exp(-np.abs(rng.normal(0, 0.0004, (S, NB))))
            O, H, L, C = tick(O), tick(H), tick(L), tick(C)
            H = np.maximum.reduce([H, O, C])
            L = np.minimum.reduce([L, O, C])
            curve = 1.6 - np.sin(np.linspace(0, np.pi, NB))
            V = np.round(curve[None, :] * np.exp(rng.normal(np.log(2000), 0.35, (S, NB)))) if kind == "equity" \
                else np.zeros((S, NB))
            P = np.ones((S, NB), bool)
            if name == "ILLQ":
                P = rng.random((S, NB)) < 0.4
                P[:, 0] |= rng.random(S) < 0.3
            self.bars[name] = {"O": O, "H": H, "L": L, "C": C, "V": V.astype(float), "P": P}
        self.dclose_noise = {n: rng.normal(0, 0.0003, S) for n in SPECS}
        self._plant()

    # ------------------------------------------------------------------ planted days
    def daily_of(self, name, s):
        b = self.bars[name]
        P = b["P"][s]
        o = b["O"][s][P][0]
        c = b["C"][s][P][-1]
        dc = float(np.round(c * (1 + self.dclose_noise[name][s]), 2))
        return {"o": o, "h": b["H"][s][P].max(), "l": b["L"][s][P].min(), "c": dc, "v": b["V"][s][P].sum()}

    def set_day(self, name, s, O, H, L, C, V=None):
        b = self.bars[name]
        b["O"][s], b["H"][s], b["L"][s], b["C"][s] = O, H, L, C
        if V is not None:
            b["V"][s] = V
        b["P"][s] = True

    def _plant(self):
        j = np.arange(NB)
        # EVNT: break, retest, fail around the previous day's high
        Pp = self.daily_of("EVNT", self.E1 - 1)["h"]
        C = np.empty(NB)
        C[:10] = np.linspace(0.995, 0.998, 10)
        C[10] = 1.003
        C[11:20] = np.linspace(1.004, 1.010, 9)
        C[20] = 1.004
        C[21:50] = 1.004 + 0.008 * (0.5 + 0.5 * np.sin(np.arange(29) / 3))
        C[50] = 0.997
        C[51:] = np.linspace(0.996, 0.999, NB - 51)
        O = np.r_[0.994, C[:-1]]
        H = np.maximum(O, C) + 0.0005
        L = np.minimum(O, C) - 0.0005
        H[:10] = np.minimum(H[:10], 0.9985)
        L[10] = 0.9975
        H[10] = 1.004
        L[11:20] = np.maximum(L[11:20], 1.0025)
        L[20], H[20] = 1.0005, 1.0105
        L[21:50] = np.maximum(L[21:50], 1.0025)
        H[50], L[50] = 1.0045, 0.996
        H[51:] = np.minimum(H[51:], 0.9995)
        self.set_day("EVNT", self.E1, tick(O * Pp), tick(H * Pp), tick(L * Pp), tick(C * Pp))
        # GAPF: a 2% gap up, filled in bar 30
        Q = self.daily_of("GAPF", self.E2 - 1)["c"]
        C = np.empty(NB)
        C[:30] = np.linspace(1.019, 1.004, 30)
        C[30] = 1.001
        C[31:] = 1.001 + 0.006 * np.abs(np.sin(np.arange(NB - 31) / 7))
        O = np.r_[1.02, C[:-1]]
        H = np.maximum(O, C) + 0.0008
        L = np.minimum(O, C) - 0.0008
        H[5] = 1.026
        L[:30] = np.maximum(L[:30], 1.0025)
        L[25] = 1.001                         # 95% filled, not yet filled
        L[30] = 0.999
        L[31:] = np.maximum(L[31:], 1.0003)
        self.set_day("GAPF", self.E2, tick(O * Q), tick(H * Q), tick(L * Q), tick(C * Q))
        # LOCK: one-price bars at the 5% lower band from bar 60
        Q = self.daily_of("LOCK", self.E5 - 1)["c"]
        lb = float(np.round(Q * 0.95, 2))
        C = np.empty(NB)
        C[:60] = np.linspace(0.995, 0.958, 60) * Q
        O = np.r_[0.996 * Q, C[:-1]]
        C, O = tick(C), tick(O)
        H = np.maximum(O, C) + 0.10
        L = np.minimum(O, C) - 0.10
        C[60:], O[60:], H[60:], L[60:] = lb, lb, lb, lb
        d2 = float(np.round(Q * 0.98, 2))     # a decoy: a low exactly at the 2% band that closes well above it
        L[15], C[15], O[15], H[15] = d2, d2 + 0.30, d2 + 0.20, d2 + 0.40
        V = self.bars["LOCK"]["V"][self.E5].copy()
        V[60:] = 50
        self.set_day("LOCK", self.E5, O, H, L, C, V)
        self.lock_band = lb
        # ILLQ: bars only in even slots on E4
        b = self.bars["ILLQ"]
        b["P"][self.E4] = (j % 2) == 0
        # VOLX: the last session: first-hour volume x3 and a 4% rise by 10:15
        s = self.S - 1
        b = self.bars["VOLX"]
        op = self.daily_of("VOLX", s - 1)["c"] * 1.001
        C = np.empty(NB)
        C[:20] = op * np.linspace(1.002, 1.04, 20)
        C[20:] = op * (1.04 + 0.003 * np.sin(np.arange(NB - 20) / 5))
        O = np.r_[op, C[:-1]]
        H = np.maximum(O, C) * 1.0005
        L = np.minimum(O, C) * 0.9995
        V = b["V"][s].copy()
        V[:20] *= 3
        self.set_day("VOLX", s, tick(O), tick(H), tick(L), tick(C), V)
        # BADB: before E3 the 3-minute file will be written at 2x (see write)

    # ------------------------------------------------------------------ files
    def daily_frame(self, name, upto=None):
        b = self.bars[name]
        kind = SPECS[name][0]
        rows = []
        n = self.S if upto is None else upto
        for s in range(n):
            if not b["P"][s].any():
                continue
            d = self.daily_of(name, s)
            rows.append((self.cal[s], d["o"], d["h"], d["l"], d["c"], d["v"] if kind == "equity" else np.nan))
        df = pd.DataFrame(rows, columns=["day", "open", "high", "low", "close", "volume"])
        df.insert(0, "timestamp", pd.DatetimeIndex(df.pop("day").to_numpy().astype("datetime64[ns]")).tz_localize(IST))
        return df

    def bar_frame(self, name, upto=None):
        b = self.bars[name]
        n = self.S if upto is None else upto
        P = b["P"][:n]
        si, sj = np.nonzero(P)
        ts = (self.cal[:n][si].astype("datetime64[m]") + (555 + 3 * sj).astype("timedelta64[m]")).astype(
            "datetime64[ns]")
        f = np.ones(len(si))
        if name == "BADB":
            f = np.where(si < self.E3, 2.0, 1.0)
        return pd.DataFrame({"timestamp": pd.DatetimeIndex(ts).tz_localize(IST), "open": b["O"][:n][P] * f,
                             "high": b["H"][:n][P] * f, "low": b["L"][:n][P] * f, "close": b["C"][:n][P] * f,
                             "volume": b["V"][:n][P] / f if SPECS[name][0] == "equity" else 0.0})

    def file_name(self, name):
        kind, tsym = SPECS[name][0], SPECS[name][1]
        return ("%s_3m.parquet" % tsym) if kind == "index" else ("%s_3m.parquet" % name)

    def write(self, upto=None):
        cat = {}
        for name, (kind, tsym, *_r) in SPECS.items():
            df = self.daily_frame(name, upto)
            df.to_parquet(self.root / ("%s_daily.parquet" % name), index=False)
            ok = {"series_kind": kind, "tradingsymbol": tsym, "exchange": "NSE",
                  "first_timestamp": str(df["timestamp"].iloc[0]), "listing_start": str(df["timestamp"].iloc[0])}
            (self.root / ("%s_daily.ok.json" % name)).write_text(json.dumps(ok), encoding="utf-8")
            self.bar_frame(name, upto).to_parquet(self.store / self.file_name(name), index=False)
            cat[name] = {"file": self.file_name(name), "kind": kind, "tradingsymbol": tsym}
        (self.store / "_cache3m").mkdir(exist_ok=True)
        (self.store / "_cache3m" / "catalog.json").write_text(json.dumps({"series": cat}), encoding="utf-8")
        (self.mods / "intraday_cache.py").write_text(textwrap.dedent('''
            """TEST STAND-IN for production's intraday_cache - NOT the production file."""
            from pathlib import Path
            BAR_MIN = 3


            def store(root):
                return Path(root) / "intraday_3m"


            def path_for(root, sym):
                return store(root) / f"{sym}_3m.parquet"
            '''), encoding="utf-8")
        return self

    def cut_copy(self, dst: Path, s: int, jT: int, change_after: bool = False) -> Path:
        """A copy of the files cut at bar jT of session s: later bars and sessions removed (or, change_after,
        replaced with different numbers), and session s's daily bar reduced to its open (or its high / low / close /
        volume changed)."""
        dst = Path(dst)
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(self.base, dst)
        root = dst / "cache_daily"
        lim = np.datetime64(self.cal[s], "D").astype("datetime64[ns]") + np.timedelta64(555 + 3 * jT, "m")
        for name in SPECS:
            f = root / "intraday_3m" / self.file_name(name)
            df = pd.read_parquet(f)
            t = df["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).to_numpy()
            late = t > lim
            if change_after:
                for c in ("open", "high", "low", "close"):
                    df.loc[late, c] = df.loc[late, c] * 1.13
                df.loc[late, "high"] = df.loc[late, ["open", "high", "low", "close"]].max(axis=1)
                df.loc[late, "low"] = df.loc[late, ["open", "high", "low", "close"]].min(axis=1)
                df.loc[late, "volume"] = df.loc[late, "volume"] * 7
            else:
                df = df[~late]
            df.to_parquet(f, index=False)
            dp = root / ("%s_daily.parquet" % name)
            dd = pd.read_parquet(dp)
            day = dd["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).dt.normalize().to_numpy().astype(
                "datetime64[D]")
            today = day == self.cal[s]
            after = day > self.cal[s]
            if change_after:
                for c in ("high", "low", "close"):
                    dd.loc[today | after, c] = dd.loc[today | after, c] * 1.21
                dd.loc[today | after, "volume"] = dd.loc[today | after, "volume"] * 3
                dd.loc[after, "open"] = dd.loc[after, "open"] * 1.21
            else:
                for c in ("high", "low", "close", "volume"):
                    dd.loc[today, c] = np.nan
                dd = dd[~after]
            dd.to_parquet(dp, index=False)
        return root
