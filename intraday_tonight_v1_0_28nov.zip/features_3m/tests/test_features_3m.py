"""
test_features_3m.py - features_3m v1.0 checks on a synthetic world (tests/f3_world.py). Nothing real is read or
written.

    python tests\\test_features_3m.py

Ends with "VERIFIED (features_3m v1.0) - N checks" (exit 0) or lists the failures (exit 1).
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
TOOL = HERE.parent
sys.path.insert(0, str(TOOL))
sys.path.insert(0, str(HERE))
for _v in ("CACHE_DAILY_ROOT", "CACHE_HISTORY_ANCHOR"):
    os.environ.pop(_v, None)

import features_3m as F  # noqa: E402
import f3_world as W  # noqa: E402

RESULTS, FAILS = [], []
TMP = Path(tempfile.mkdtemp(prefix="f3test_"))
t_start = time.time()


def check(ok, what):
    RESULTS.append(bool(ok))
    if not ok:
        FAILS.append(what)
        print("FAIL: %s" % what, flush=True)


def use_mods(world):
    sys.modules.pop("intraday_cache", None)
    for p in list(sys.path):
        if p.endswith("_mods") or (p and Path(p, "intraday_cache.py").exists()):
            sys.path.remove(p)
    sys.path.insert(0, str(world.mods))


def run(args):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = F.main(list(args))
    return rc, buf.getvalue()


def build(world, out, *extra, root=None):
    use_mods(world)
    return run(["build", "--root", str(root or world.root), "--out", str(out), "--workers", "1", *extra])


def snap(out, name, day=None):
    t = F.load(out, "snap", symbols=[name])
    return t if day is None else t[t["date"] == pd.Timestamp(str(day))].set_index("time")


def dayrow(out, name, day):
    t = F.load(out, "day", symbols=[name])
    r = t[t["date"] == pd.Timestamp(str(day))]
    return r.iloc[0] if len(r) else None


def frames_equal(a, b, keys, skip=()):
    if len(a) != len(b):
        return False, "rows %d vs %d" % (len(a), len(b))
    a = a.sort_values(keys).reset_index(drop=True)
    b = b.sort_values(keys).reset_index(drop=True)
    for c in a.columns:
        if c in skip or c in keys:
            continue
        if c not in b.columns:
            return False, "column %s missing" % c
        x, y = a[c].to_numpy(), b[c].to_numpy()
        if x.dtype.kind in "fi" or y.dtype.kind in "fi":
            x, y = x.astype(float), y.astype(float)
            if not np.allclose(x, y, rtol=2e-6, atol=1e-7, equal_nan=True):
                bad = ~np.isclose(x, y, rtol=2e-6, atol=1e-7, equal_nan=True)
                i = int(np.argmax(bad))
                return False, "%s differs (%d rows; e.g. %s vs %s at %s)" % (c, bad.sum(), x[i], y[i],
                                                                         a.loc[i, keys].to_dict())
        elif not (a[c].astype(str).to_numpy() == b[c].astype(str).to_numpy()).all():
            return False, "%s differs" % c
    return True, ""


# ================================================================================================== 1. units
check(F.t2j("10:15") == 19 and F.t2j("09:18") == 0 and F.t2j("15:30") == 124 and F.t2j("10:16") == 19 and
      int(F.j2hhmm(19)) == 1015 and int(F.j2hhmm(124)) == 1530,
      "the clock: a value at 10:15 uses bars that ended by 10:15 (the bar stamped 10:12 is the last)")
try:
    F.t2j("09:16")
    early = False
except F.F3Error:
    early = True
check(early, "no value exists before the first bar ends (09:18)")
rng = np.random.default_rng(3)
a = rng.normal(size=(300, 5, 40))
a[rng.random(a.shape) < 0.35] = np.nan
a[0, 0] = np.nan
import warnings  # noqa: E402
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    ref = np.nanmedian(a, axis=-1)
check(np.allclose(F.nanmed(a), ref, equal_nan=True), "the fast median equals numpy's nanmedian")


def one_session(Cl, Hh, Ll, Oo=None, Vv=None, op=100.0, pdc=99.0, pdh=101.0, pdl=98.0, cols=(4, 9, 19, 20, 21, 22,
                                                                                                    124)):
    D = F.Dense()
    D.days = np.array(["2026-01-05"], dtype="datetime64[D]")
    Cl = np.asarray(Cl, float)[None, :]
    D.C = Cl
    D.O = (np.r_[op, Cl[0, :-1]] if Oo is None else np.asarray(Oo, float))[None, :]
    D.H, D.L = np.asarray(Hh, float)[None, :], np.asarray(Ll, float)[None, :]
    D.V = (np.full((1, F.NB), 1000.0) if Vv is None else np.asarray(Vv, float)[None, :])
    D.P = np.isfinite(D.C)
    X = {k: np.array([v]) for k, v in (("op", op), ("pdc", pdc), ("pdh", pdh), ("pdl", pdl), ("pwh", pdh + 1),
                                        ("pwl", pdl - 1), ("atr", 2.0), ("dvol20", 1e5), ("dH", np.nanmax(Hh)),
                                        ("dL", np.nanmin(Ll)), ("dC", Cl[0, -1]), ("dV", 1e5))}
    X["has_daily"] = np.array([True])
    sn, dy = F.engine(D, X, F.MarketSet(), np.zeros(1, np.int64), list(cols))
    return sn, dy, list(cols)


# session A: steady rise (no pivots), a spike high at bar 12 (a swing high, confirmed at bar 14), broken in bar 18
C_ = np.r_[100.0 + 0.1 * np.arange(12), 101.2, 101.1, 101.0, 101.1, 101.2, 101.3, 101.7, np.full(F.NB - 19, 101.7)]
O_ = np.r_[100.0, C_[:-1]]
H_ = np.maximum(O_, C_) + 0.05
H_[12] = 101.5
L_ = np.minimum(O_, C_) - 0.05
sn, dy, cl = one_session(C_, H_, L_, O_)
k945, k1015 = cl.index(9), cl.index(19)
check(dy["ev_or15h_brk"][0] == 18 and dy["ev_or15h_touch"][0] >= 18 and np.isnan(sn["lv_or15h_brk_mins"][0, 0]) and
      sn["lv_or15h_brk_mins"][0, k945] == 12 and dy["ev_or30h_brk"][0] == 33 and np.isnan(sn["lv_or30h_dist"][0, 0]),
      "opening ranges: complete at 09:30 / 09:45, broken in bars 5 / 10 (minutes 18 / 33); the 30-minute range is "
      "unknown at 09:30")
check(dy["ev_swh_brk"][0] == 57 and abs(dy["ev_swh_brk_lvl"][0] - 0.015) < 1e-6,
      "a swing high is confirmed 2 bars after its peak and its break is the first close above it (bar 18, minute 57, "
      "level +1.5%)")
k19 = cl.index(19)
dC_ = np.abs(np.diff(np.r_[100.0, C_[:20]]))
tp = (H_[:20] + L_[:20] + C_[:20]) / 3
upb = (C_[:20] > O_[:20]).sum() - (C_[:20] < O_[:20]).sum()
rv19 = np.sqrt(np.sum(np.log(C_[:20] / np.r_[100.0, C_[:19]]) ** 2))
check(abs(sn["eff_signed"][0, k19] - (C_[19] - 100) / dC_.sum()) < 1e-6 and
      abs(sn["signed_vol"][0, k19] - upb / 20) < 1e-6 and abs(sn["rv"][0, k19] - rv19) < 1e-6 and
      abs(sn["vwap_dist"][0, k19] - (C_[19] / tp.mean() - 1)) < 1e-6 and
      abs(sn["range_atr"][0, k19] - (H_[:20].max() - L_[:20].min()) / 2.0) < 1e-6,
      "path efficiency, signed volume, realized volatility, VWAP distance and range in ATRs equal hand calculations")
check(dy["ev_vwap_xup"][0] == 6 and dy["ev_op_reclaim"][0] != dy["ev_op_reclaim"][0],
      "VWAP: the first close above it after a bar on it is a crossing (bar 1, minute 6); no open reclaim when the "
      "price never closed below the open")
# session B: a box break up in bar 20 that closes back inside in bar 22
C_ = np.full(F.NB, 100.0)
C_[20], C_[21], C_[22] = 100.5, 100.4, 100.05
O_ = np.r_[100.0, C_[:-1]]
H_ = np.maximum(O_, C_) + 0.1
L_ = np.minimum(O_, C_) - 0.1
sn, dy, cl = one_session(C_, H_, L_, O_)
bf = sn["box_brk_failed"][0]
check(np.isnan(bf[cl.index(20)]) and np.isnan(bf[cl.index(21)]) and bf[cl.index(22)] == 1 and
      sn["mins_since_box_brk"][0, cl.index(22)] == 6 and dy["box_fail_n"][0] >= 1,
      "a box break is pending for 5 bars, failed once a close is back inside (bar 22), dated +6 minutes")
# session D: drawdown and run-up are chronological - a fall inside one bar from its own high is not counted
C_ = np.r_[np.linspace(100.5, 102.8, 3), np.linspace(102.0, 98.2, 7), np.linspace(98.6, 101.0, 10), 100.0,
           np.full(F.NB - 21, 100.0)]
O_ = np.r_[100.0, C_[:-1]]
H_ = np.maximum(O_, C_) + 0.05
L_ = np.minimum(O_, C_) - 0.05
H_[2], L_[9] = 103.0, 98.0
H_[20], L_[20] = 104.0, 97.0
sn, dy, cl = one_session(C_, H_, L_, O_)
pk, tr, ddr, rur = 100.0, 100.0, 0.0, 0.0
for jj in range(21):
    ddr = max(ddr, 1 - L_[jj] / pk)
    rur = max(rur, H_[jj] / tr - 1)
    pk, tr = max(pk, H_[jj]), min(tr, L_[jj])
check(abs(sn["dd_max"][0, cl.index(20)] - ddr) < 1e-6 and abs(sn["ru_max"][0, cl.index(20)] - rur) < 1e-6 and
      abs(ddr - (1 - 97 / 103)) < 1e-9,
      "drawdown / run-up: from the peak / trough BEFORE each bar (%.4f / %.4f), not a bar's own high-to-low" % (ddr,
                                                                                                             rur))
# session C: a retest inside the breaking bar itself is not a retest
C_ = np.full(F.NB, 100.6)
C_[:5] = 100.5
O_ = np.r_[100.4, C_[:-1]]
H_ = np.maximum(O_, C_) + 0.05
L_ = np.minimum(O_, C_) - 0.05
C_[5], H_[5], L_[5] = 101.3, 101.4, 100.9        # breaks pdh 101 and dips to it inside the same bar
L_[6:] = 101.2                                   # above the 0.1% retest band (101.101)
C_[6:], H_[6:] = 101.3, 101.4
sn, dy, cl = one_session(C_, H_, L_, O_)
check(dy["ev_pdh_brk"][0] == 18 and np.isnan(dy["ev_pdh_retest"][0]),
      "the order inside one bar is unknowable: a dip back to the level within the breaking bar is not a retest")

# ================================================================================================== 2. the world
w = W.World(TMP / "w1").write()
use_mods(w)
OUT = TMP / "out1"
rc, out = build(w, OUT)
check(rc == 0 and "15 computed in full" in out, "a first build computes every series (exit 0)%s" % (
    "" if rc == 0 else ": " + out[-800:]))
cal = w.cal
d1 = cal[w.E1]

# ----- the planted event chronology (EVNT)
r = dayrow(OUT, "EVNT", d1)
s1 = snap(OUT, "EVNT", d1)
check(r["ev_pdh_touch"] == 33 and r["ev_pdh_brk"] == 33 and r["ev_pdh_retest"] == 63 and r["ev_pdh_fail"] == 153
      and r["ev_pdh_start"] == -1,
      "EVNT: the previous high touched and broken in bar 10 (minute 33), retested and held in bar 20 (63), closed back "
      "below in bar 50 (153)")
check(np.isnan(s1.loc[945, "lv_pdh_brk_mins"]) and s1.loc[1015, "lv_pdh_brk_mins"] == 27 and
      s1.loc[1015, "lv_pdh_retest"] == 0 and s1.loc[1115, "lv_pdh_retest"] == 1 and s1.loc[1115, "lv_pdh_fail"] == 0
      and s1.loc[1315, "lv_pdh_fail"] == 1,
      "EVNT snapshots know only what had happened: at 10:15 broken 27 minutes ago, no retest yet; at 11:15 retested; "
      "at 13:15 failed")

# ----- gap fill (GAPF)
r = dayrow(OUT, "GAPF", cal[w.E2])
b = w.bars["GAPF"]
op_g = b["O"][w.E2][0]
pdc_g = w.daily_of("GAPF", w.E2 - 1)["c"]
ext = b["H"][w.E2][:30].max() / op_g - 1
s2 = snap(OUT, "GAPF", cal[w.E2])
check(abs(r["gap"] - (op_g / pdc_g - 1)) < 1e-6 and r["gap_fill_mins"] == 93 and abs(r["gap_ext"] - ext) < 1e-6 and
      s2.loc[1015, "gap_fill"] < 1 and np.isnan(s2.loc[1015, "gap_fill_mins"]) and s2.loc[1115, "gap_fill_mins"] == 93,
      "GAPF: a %.2f%% gap filled in bar 30 (minute 93); the extension before the fill (%.3f%%) and the partial fill at "
      "10:15 are right" % (100 * (op_g / pdc_g - 1), 100 * ext))

# ----- lower circuit band (LOCK)
r = dayrow(OUT, "LOCK", cal[w.E5])
check(r["band_dn_bars"] == 65 and r["band_dn_onep"] == 65 and r["band_dn_first"] == 183 and
      r["band_dn_last_bar"] == 1 and r["band_up_bars"] == 0,
      "LOCK: 65 one-price bars at the 5% lower band from bar 60 (minute 183), closed there")

# ----- coverage (ILLQ)
r = dayrow(OUT, "ILLQ", cal[w.E4])
s4 = snap(OUT, "ILLQ", cal[w.E4])
check(r["miss_share"] == np.float32(62 / 125) and r["miss_run_max"] == 1 and s4.loc[1015, "cover"] == 0.5 and
      s4.loc[1015, "mins_since_trade"] == 3 and s4.loc[1015, "bars_missing"] == 10,
      "ILLQ: bars only in even slots - 62 of 125 missing, longest gap 1 bar; at 10:15 the last print ended 3 minutes "
      "earlier")

# ----- the last session: volume burst, extreme rise, ranks and history (VOLX)
last = cal[-1]
s5 = snap(OUT, "VOLX", last)
X5 = F.load(OUT, "xs")
x5 = X5[(X5["symbol"] == "VOLX") & (X5["date"] == pd.Timestamp(str(last)))].set_index("time")
Sl = F.load(OUT, "snap", start=str(last), end=str(last), times=["10:15"])
Sl = Sl[Sl["symbol"].isin([n_ for n_, v_ in W.SPECS.items() if v_[0] == "equity"])]
n_el = int(((Sl["basis_open_ok"] != 0) & Sl["r_op"].notna()).sum())
check(2.5 < s5.loc[1015, "rvol"] < 3.6 and s5.loc[1015, "h_r_op_pct"] == 1.0 and x5.loc[1015, "xs_r_op"] == 1.0 and
      x5.loc[1015, "xs_n"] == n_el and n_el >= 11,
      "VOLX: 3x the usual first-hour volume (rvol %.2f), the highest 10:15 rise of its own 60-session history and the "
      "top rank among the %d stocks ranked (h_pct %s, xs %s, n %s)" % (
          s5.loc[1015, "rvol"], n_el, s5.loc[1015, "h_r_op_pct"], x5.loc[1015, "xs_r_op"], x5.loc[1015, "xs_n"]))

# ----- the basis fault (BADB)
sb = F.load(OUT, "snap", symbols=["BADB"])
db = F.load(OUT, "day", symbols=["BADB"])
before = sb["date"] < pd.Timestamp(str(cal[w.E3]))
d_before = db["date"] < pd.Timestamp(str(cal[w.E3]))
xb = X5[X5["symbol"] == "BADB"]
xb_before = xb["date"] < pd.Timestamp(str(cal[w.E3]))
check((sb.loc[before, "basis_open_ok"] == 0).all() and sb.loc[before, "r_op"].isna().all() and
      sb.loc[before, "gap"].isna().all() and (db.loc[d_before, "basis_ok"] == 0).all() and
      db.loc[d_before, "r_oc"].isna().all() and xb.loc[xb_before, "xs_r_op"].isna().all() and
      sb.loc[~before, "r_op"].notna().mean() > 0.95,
      "BADB: sessions whose 3-minute bars sit at 2x the daily bars are flagged, left blank and never ranked; the "
      "fixed sessions are normal")
first_good = db[~d_before].iloc[0]
check(first_good["h_n"] == 0, "faulty sessions feed no one's history (BADB's first good session has no history)")
dbad = pd.Timestamp(str(cal[w.E3 - 3]))
Sb3 = F.load(OUT, "snap", start=str(cal[w.E3 - 3]), end=str(cal[w.E3 - 3]), times=["10:15"])
Sb3 = Sb3[Sb3["symbol"].isin([n_ for n_, v_ in W.SPECS.items() if v_[0] == "equity"])]
xb3 = X5[(X5["date"] == dbad) & (X5["time"] == 1015)]
n_ok = int(((Sb3["basis_open_ok"] != 0) & Sb3["r_op"].notna()).sum())
check(len(xb3) == len(Sb3) and (xb3["xs_n"] == n_ok).all() and n_ok == len(Sb3) - 1,
      "the peer count counts only the stocks ranked at that moment (%d of %d on a BADB fault day)" % (n_ok, len(Sb3)))

# ----- market beta and the home index
bt = F.load(OUT, "day", symbols=["BETA"])
check(abs(float(np.nanmedian(bt["beta_n"])) - 1.5) < 0.1 and float(np.nanmedian(bt["corr_n"])) > 0.9,
      "BETA: intraday beta to NIFTY %.2f (planted 1.5)" % float(np.nanmedian(bt["beta_n"])))
Hx = pd.read_parquet(OUT / "home_index.parquet")
late_m = Hx["month"] >= 202602
it, bk = F.SECTORS.index("NIFTYIT") + 1, F.SECTORS.index("NIFTYBANK") + 1
okh = all((Hx[late_m & (Hx["symbol"] == s)]["home"] == it).all() for s in ("ITA", "ITB", "ITC2")) and \
    all((Hx[late_m & (Hx["symbol"] == s)]["home"] == bk).all() for s in ("BKA", "BKB")) and \
    (Hx[Hx["month"] == 202501]["home"] == 0).all()
check(okh, "home index: IT and bank stocks find their sector index from past daily returns; none in the first month")
Ux = F.load_universe(w.root, w.store)
H1 = F.home_table(w.root, Ux, [202603])
hc = TMP / "homecopy"
shutil.copytree(w.root, hc, ignore=shutil.ignore_patterns("intraday_3m"))
rng_h = np.random.default_rng(9)
for nm_ in Ux:
    pth = hc / ("%s_daily.parquet" % nm_)
    dfh = pd.read_parquet(pth)
    late_ = dfh["timestamp"].dt.tz_convert(W.IST).dt.tz_localize(None) >= pd.Timestamp("2026-03-01")
    dfh.loc[late_, "close"] = dfh.loc[late_, "close"] * rng_h.uniform(0.7, 1.3, int(late_.sum()))
    dfh.to_parquet(pth, index=False)
H2 = F.home_table(hc, Ux, [202603])
check(H1.sort_values("symbol")[["symbol", "home"]].reset_index(drop=True).equals(
    H2.sort_values("symbol")[["symbol", "home"]].reset_index(drop=True)) and (H1["home"] > 0).sum() >= 5,
      "a month's home index uses only sessions before the month (scrambling March's closes changes nothing)")
ds_ = F.load(OUT, "snap", symbols=["ITA"])
check(ds_[ds_["date"] >= pd.Timestamp("2026-02-01")]["sec_r_op"].notna().mean() > 0.9,
      "the home index's intraday return is attached to its stocks")

# ----- indices and labels
nf = F.load(OUT, "snap", symbols=["NIFTY50"])
check(nf["vwap_dist"].isna().all() and nf["rvol"].isna().all() and nf["r_op"].notna().mean() > 0.95,
      "indices: no volume features (no volume), price features computed")
ev = F.load(OUT, "snap", symbols=["EVNT"])
e1 = ev[ev["date"] == pd.Timestamp(str(d1))].set_index("time")
Cv = w.bars["EVNT"]["C"][w.E1]
check(abs(e1.loc[1015, "label_r_to_eod"] - (Cv[-1] / Cv[19] - 1)) < 1e-6,
      "label_r_to_eod is what happened after the snapshot (the 15:27 bar's close / the 10:12 bar's close - 1)")

# ----- the contract and the label firewall
ct = json.loads((OUT / "contract.json").read_text(encoding="utf-8"))
inC = {(c["table"], c["name"]) for c in ct["columns"]}
S0 = F.load(OUT, "snap", symbols=["ITA"])
D0 = F.load(OUT, "day", symbols=["ITA"])
X0 = X5
M0 = F.load(OUT, "market")
cover = all(("snap", c) in inC for c in S0.columns if c not in ("symbol", "date", "time")) and \
    all(("day", c) in inC for c in D0.columns if c not in ("symbol", "date")) and \
    all(("xs", c) in inC for c in X0.columns if c not in ("symbol", "date", "time")) and \
    all(("market", c) in inC for c in M0.columns if c not in ("date", "time"))
names = [c for c in list(S0.columns) + list(D0.columns) + list(X0.columns) + list(M0.columns)
         if c not in ("symbol", "date", "time")]
bad = [c for c in names if F.forbidden(c)]
lab = [c for c in names if c.startswith("label_")]
check(cover and not bad and lab and all(c in S0.columns for c in lab) and not [c for c in D0.columns
                                                                               if c.startswith("label_")],
      "every column is in the contract; no raw price level or forward-looking name; outcomes only as label_* in the "
      "snapshot table %s" % (bad[:5] if bad else ""))

# ================================================================================================== 3. no peeking
# (a) the review's acceptance test: files physically cut at a bar give the same snapshot
for s_i, hhmm in ((w.E1, "10:15"), (w.S - 1, "13:15"), (w.E2, "09:45")):
    jT = F.t2j(hhmm)
    root_c = w.cut_copy(TMP / "cut", s_i, jT)
    use_mods(w)
    sdir = root_c / "intraday_3m"
    names_all = [n for n, v in W.SPECS.items() if v[0] == "equity"]
    A = F.asof_frame(root_c, sdir, names_all, str(cal[s_i]), hhmm, home_path=OUT / "home_index.parquet")
    Sall = F.load(OUT, "snap", start=str(cal[s_i]), end=str(cal[s_i]), times=[hhmm])
    Sall = Sall[Sall["symbol"].isin(A["symbol"])]
    Xa = X5[(X5["date"] == pd.Timestamp(str(cal[s_i]))) & (X5["time"] == int(hhmm.replace(":", "")))]
    Sx = Sall.merge(Xa.drop(columns=["date", "time"]), on="symbol", how="left")
    use = [c for c in A.columns if c in Sx.columns and not c.startswith("label_")]
    same, why = frames_equal(A[use], Sx[use], ["symbol"])
    same = same and len(A) >= 11 and not [c for c in A.columns if c not in Sx.columns]
    check(same, "files physically cut at %s on %s give exactly the stored snapshot, ranks included %s" % (
        hhmm, cal[s_i], why))
# (b) any completed bar, not only the six: the cut files at 10:00 equal the full-data engine at bar 14
root_c = w.cut_copy(TMP / "cut", w.E1, F.t2j("10:00"))
A = F.asof_frame(root_c, root_c / "intraday_3m", ["EVNT", "GAPF"], str(cal[w.E1]), "10:00",
                 home_path=OUT / "home_index.parquet")
B = F.asof_frame(w.root, w.store, ["EVNT", "GAPF"], str(cal[w.E1]), "10:00", home_path=OUT / "home_index.parquet")
same, why = frames_equal(A, B, ["symbol"])
check(same and A["lv_pdh_brk_mins"].notna().any() is not None, "asof at a non-snapshot time (10:00): cut files and "
                                                               "full files agree %s" % why)
# (c) the bar stamped 10:15 is not part of the 10:15 value
w2 = W.World(TMP / "w2").write()
b2 = w2.bars["VOLX"]
s_last = w2.S - 1
b2["H"][s_last][20] *= 1.08
b2["C"][s_last][20] *= 1.05
b2["V"][s_last][20] *= 40
w2.write()
OUT2 = TMP / "out2"
build(w2, OUT2)
v1 = snap(OUT, "VOLX", last)
v2 = snap(OUT2, "VOLX", last)
cols_ = [c for c in v1.columns if not c.startswith("label_") and c not in ("symbol", "date")]
same_1015 = np.allclose(v1.loc[1015, cols_].astype(float), v2.loc[1015, cols_].astype(float), equal_nan=True)
a18 = F.asof_frame(w.root, w.store, ["VOLX"], str(last), "10:18", home_path=OUT / "home_index.parquet")
b18 = F.asof_frame(w2.root, w2.store, ["VOLX"], str(last), "10:18", home_path=OUT2 / "home_index.parquet")
check(same_1015 and abs(float(b18["rise_op"].iloc[0]) - float(a18["rise_op"].iloc[0])) > 0.01,
      "a spike in the bar stamped 10:15 leaves every 10:15 value unchanged and appears at 10:18")
# (d) change today's daily high / low / close / volume, every later bar and every later session: no value known at
#     13:15 moves, and no earlier day row moves
s_c = w.S - 3
jT = F.t2j("13:15")
w.cut_copy(TMP / "chg", s_c, jT, change_after=True)
OUT3 = TMP / "out3"
use_mods(w)
rc3, o3 = run(["build", "--root", str(TMP / "chg" / "cache_daily"), "--out", str(OUT3), "--workers", "1"])
Sa = F.load(OUT, "snap", start=str(cal[s_c]), end=str(cal[s_c]))
Sb = F.load(OUT3, "snap", start=str(cal[s_c]), end=str(cal[s_c]))
keep_t = [930, 945, 1015, 1115, 1315]
Sa, Sb = Sa[Sa["time"].isin(keep_t)], Sb[Sb["time"].isin(keep_t)]
skip = [c for c in Sa.columns if c.startswith("label_")]
same1, why1 = frames_equal(Sa.drop(columns=skip), Sb.drop(columns=skip), ["symbol", "date", "time"])
Da = F.load(OUT, "day", end=str(cal[s_c - 1]))
Db = F.load(OUT3, "day", end=str(cal[s_c - 1]))
same2, why2 = frames_equal(Da, Db, ["symbol", "date"])
Xa_ = X5[(X5["date"] <= pd.Timestamp(str(cal[s_c]))) & ((X5["date"] < pd.Timestamp(str(cal[s_c]))) |
                                                         (X5["time"].isin(keep_t)))]
X3 = F.load(OUT3, "xs")
Xb_ = X3[(X3["date"] <= pd.Timestamp(str(cal[s_c]))) & ((X3["date"] < pd.Timestamp(str(cal[s_c]))) |
                                                        (X3["time"].isin(keep_t)))]
same3, why3 = frames_equal(Xa_, Xb_, ["symbol", "date", "time"])
check(rc3 == 0 and same1 and same2 and same3,
      "changing today's daily high/low/close/volume and everything after 13:15 moves no snapshot up to 13:15, no "
      "rank, and no earlier day row %s %s %s" % (why1, why2, why3))

# ================================================================================================== 4. builds
# incremental = full
wi = W.World(TMP / "wi")
wi.write(upto=wi.S - 8)
OUTI = TMP / "outi"
rc_a, oa = build(wi, OUTI)
wi.write()
rc_b, ob = build(wi, OUTI)
okall = rc_a == 0 and rc_b == 0 and "15 brought forward" in ob
for tab, keys in (("snap", ["symbol", "date", "time"]), ("day", ["symbol", "date"]), ("xs", ["symbol", "date", "time"]),
                  ("market", ["date", "time"])):
    same, why = frames_equal(F.load(OUTI, tab), F.load(OUT, tab), keys)
    if not same:
        okall = False
        print("   incremental vs full, %s: %s" % (tab, why))
check(okall, "adding 8 sessions brings every series forward and every table equals a full build")
# a changed history (the 3-minute file of one stock altered in the past) is rebuilt in full
f_ = wi.store / "BKA_3m.parquet"
dfb = pd.read_parquet(f_)
dfb.loc[100, "volume"] = dfb.loc[100, "volume"] + 1
dfb.to_parquet(f_, index=False)
rc_c, oc = build(wi, OUTI)
check(rc_c == 0 and "1 computed in full, 14 brought forward" in oc, "a series whose past changed is recomputed in full")
# workers: as Karan runs it - "python features_3m.py build --workers 2" in its own process (Windows starts every
# worker by importing the main script, so this is the path that must work)
OUTW = TMP / "outw"
env = dict(os.environ)
env["PYTHONPATH"] = str(w.mods) + os.pathsep + env.get("PYTHONPATH", "")
pw_ = subprocess.run([sys.executable, str(TOOL / "features_3m.py"), "build", "--root", str(w.root), "--out", str(OUTW),
                      "--workers", "2"], env=env, capture_output=True, text=True, timeout=900)
rc_w = pw_.returncode
okw = rc_w == 0
for tab, keys in (("snap", ["symbol", "date", "time"]), ("day", ["symbol", "date"]), ("xs", ["symbol", "date", "time"])):
    same, why = frames_equal(F.load(OUTW, tab), F.load(OUT, tab), keys)
    okw &= same
check(okw, "2 worker processes (started the Windows way) give the same tables as one%s" % (
    "" if rc_w == 0 else ": " + (pw_.stdout + pw_.stderr)[-600:]))
# refusals
rc1, o1 = build(w, w.root / "feat")
rc2, o2 = build(w, OUT, "--hist", "40")
rc4, o4 = run(["build", "--out", str(OUT)])
check(rc1 == 3 and "inside the daily cache" in o1 and rc2 == 3 and "--full" in o2 and rc4 == 3,
      "refused: output inside the daily cache, changed definitions without --full, no --root")
rc5, o5 = run(["asof", "--root", str(w.root), "--out", str(OUT), "--date", str(last), "--time", "10:15",
               "--symbols", "VOLX", "EVNT"])
check(rc5 == 0 and "xs_r_op" in o5 and "lv_pdh_brk_mins" in o5, "the asof command prints every value at any bar")

shutil.rmtree(TMP, ignore_errors=True)
n = len(RESULTS)
print("")
if FAILS:
    print("FAILED (%s) - %d of %d checks failed:" % (F.VERSION, len(FAILS), n))
    for f in FAILS:
        print("  - " + f)
    sys.exit(1)
print("VERIFIED (%s) - %d checks, %.0f s, pandas %s, numpy %s" % (F.VERSION, n, time.time() - t_start,
                                                                 pd.__version__, np.__version__))
sys.exit(0)
