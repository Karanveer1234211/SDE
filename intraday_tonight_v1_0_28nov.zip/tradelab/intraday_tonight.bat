@echo off
rem intraday_tonight.bat - tradelab intraday add-on v1.0: the 3-minute cache, then its features, in one window.
rem run_tonight.bat starts it in a window of its own as soon as Run Now has finished - the daily cache is then
rem current and nothing else is asking Kite for bars - and steps 2-5 carry on beside it; their RESULT never
rem depends on it. It can also be double-clicked on its own, any evening after the daily cache has run.
rem   1  cache3m update: 3-minute bars for every stock and index of the daily cache, up to the last completed
rem      session, into production's 3-minute store (intraday_3m). It stops cleanly after IT_MAX_HOURS and the
rem      next run carries on - that happens only on the first evenings, while the backlog is fetched
rem   2  features_3m build: the 3-minute features of the new sessions
rem The features wait when cache3m refuses (code 3: another update is running on the store, or a setting is wrong).
rem cache3m codes: 0 done, 2 done but a series failed or is behind, 3 refused, 4 Kite token expired, 5 stopped
rem early (time budget or Ctrl+C - the next run carries on). features_3m codes: 0 done, 2 a series failed,
rem 3 refused. 9: a file or a setting not found.
rem Every run adds one line to TRADELAB_OUT\intraday_log.txt: when it ended, and each step's exit code.
rem Argument  auto  - no pause at the end (run_tonight.bat auto passes it on).
setlocal
set "IT_CACHE3M_DIR=C:\Users\karanvsi\PyCharmMiscProject\cache3m"
set "IT_FEAT_DIR=C:\Users\karanvsi\PyCharmMiscProject\features_3m"
set "IT_MAX_HOURS=8"
set "IT_AUTO="
if /i "%~1"=="auto" set "IT_AUTO=1"
set "IT_RC1=skipped"
set "IT_RC2=skipped"
set "IT_FAILED="
set "IT_START=%DATE% %TIME%"
title intraday - 3-minute cache, then its features

call "%~dp0env_tradelab.bat"
set "IT_OUT=%TRADELAB_OUT%"
if "%IT_OUT%"=="" set "IT_OUT=C:\QuantData\tradelab"
if not exist "%IT_OUT%" mkdir "%IT_OUT%"
if "%CACHE_DAILY_ROOT%"=="" goto :no_env

echo.
echo   ==== INTRADAY 1 of 2: cache3m - the 3-minute bars - started %IT_START% ====
if not exist "%IT_CACHE3M_DIR%\cache3m.py" goto :no_c3
pushd "%IT_CACHE3M_DIR%"
python cache3m.py update --root "%CACHE_DAILY_ROOT%" --max-hours %IT_MAX_HOURS%
set "IT_RC1=%ERRORLEVEL%"
popd
goto :c3_done
:no_c3
echo   NOT FOUND: %IT_CACHE3M_DIR%\cache3m.py - edit IT_CACHE3M_DIR at the top of intraday_tonight.bat
set "IT_RC1=9"
:c3_done
if "%IT_RC1%"=="0" goto :feat
if "%IT_RC1%"=="5" goto :feat
set "IT_FAILED=%IT_FAILED% [cache3m: code %IT_RC1%]"
if "%IT_RC1%"=="3" goto :feat_wait

:feat
echo.
echo   ==== INTRADAY 2 of 2: features_3m - the 3-minute features - %TIME% ====
if not exist "%IT_FEAT_DIR%\features_3m.py" goto :no_f3
pushd "%IT_FEAT_DIR%"
python features_3m.py build --root "%CACHE_DAILY_ROOT%"
set "IT_RC2=%ERRORLEVEL%"
popd
goto :f3_done
:no_f3
echo   NOT FOUND: %IT_FEAT_DIR%\features_3m.py - edit IT_FEAT_DIR at the top of intraday_tonight.bat
set "IT_RC2=9"
:f3_done
if not "%IT_RC2%"=="0" set "IT_FAILED=%IT_FAILED% [features_3m: code %IT_RC2%]"
goto :result
:feat_wait
echo.
echo   ==== INTRADAY 2 of 2: features_3m waits - cache3m refused, its line above says why ====
set "IT_RC2=waits"
goto :result
:no_env
echo   CACHE_DAILY_ROOT is empty after env_tradelab.bat - its line above says why; nothing was run
set "IT_RC1=9"
set "IT_FAILED= [env_tradelab.bat: no CACHE_DAILY_ROOT]"

:result
echo.
if defined IT_FAILED goto :res_failed
if "%IT_RC1%"=="5" goto :res_more
echo   INTRADAY RESULT: OK - the 3-minute bars are current and their features are built
set "IT_RC=0"
goto :res_log
:res_more
echo   INTRADAY RESULT: OK SO FAR - cache3m stopped early, at its %IT_MAX_HOURS%-hour budget or Ctrl+C, and the
echo   next run carries on; the features were built on what is there. Expected only while the backlog is fetched.
set "IT_RC=0"
goto :res_log
:res_failed
echo   INTRADAY RESULT: FAILED at%IT_FAILED%
echo   Read that step's own lines above. cache3m's last report: intraday_3m\_cache3m\coverage_report.json
set "IT_RC=1"
:res_log
>>"%IT_OUT%\intraday_log.txt" echo %DATE% %TIME%  cache3m=%IT_RC1%  features_3m=%IT_RC2%%IT_FAILED%
if not defined IT_AUTO pause
endlocal & exit /b %IT_RC%
