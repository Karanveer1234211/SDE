@echo off
rem run_tonight.bat - tradelab v1.3.1 + setups add-on v1.0 + why add-on v1.0 + intraday add-on v1.0: the whole evening in
rem ONE double-click. It replaces
rem pressing Run Now, then run_pick_meta.bat, then run_watch.bat:
rem   1  Run Now exactly as you double-click it: bigmove_deploy\run_now.bat, unchanged, started from its own folder
rem      in a child cmd - nothing inside it can end this script
rem   2  pick_meta: publish the cards (every recorded day still without one) and score the tracker - the commands of
rem      open_close\run_pick_meta.bat, in the same environment
rem   3  setuplab: the frozen setups' scan of the last five days' picks (what to buy at the next open), for tonight
rem      and every evening since the freeze still without one; its own on-time ledger (SETUPLAB_DIR / SETUPLAB_OUT
rem      come from env_tradelab.bat)
rem   4  whylab: why each of tonight's recorded picks (D and ENS, ranks 1-10) was picked, recorded in its own
rem      hash-chained ledger before the next open (ON TIME), and every recorded session still without one (LATE);
rem      the open picks' reasons at tonight's close; the monitor (WHYLAB_DIR / WHYLAB_OUT from env_tradelab.bat,
rem      whylab's environment from env_whylab.bat). Information only - nothing traded changes
rem   5  tradelab: the watch page for tonight and for every recorded day still without one (with the setups at the
rem      next open and the why); opens tonight's page
rem   +  intraday add-on v1.0: as soon as Run Now has finished, intraday_tonight.bat (beside this file) starts in a
rem      window of its own - the 3-minute cache (cache3m), then its features (features_3m) - while steps 2-5 carry
rem      on here. Its result goes to TRADELAB_OUT\intraday_log.txt and never changes this RESULT; no file, no start.
rem Every step runs even when an earlier one failed: each works only on what production has already recorded, so a
rem failed or partial Run Now gives at worst nothing new - never a wrong card or page. RESULT names each failed step.
rem Start it when you would press Run Now, never while another run is going. If Run Now asks for a key at its end,
rem press it once and the rest carries on.
rem Nothing in bigmove_deploy is changed; tradelab writes only under TRADELAB_OUT, setuplab only under SETUPLAB_OUT.
rem Task Scheduler (no clicks): program run_tonight.bat, argument  auto  - no pause, no browser, and Run Now gets no
rem keyboard, so a prompt inside it fails at once instead of waiting all night.
rem Every run adds one line to TRADELAB_OUT\tonight_log.txt: when, each step's exit code, and intraday= started or
rem not found.
setlocal
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TN_RUN_NOW=%BIGMOVE_DIR%\run_now.bat"
set "TN_TL_DIR=%~dp0"
set "TN_3M_BAT=%TN_TL_DIR%intraday_tonight.bat"
set "TN_3M=skipped"
set "TN_AUTO="
if /i "%~1"=="auto" set "TN_AUTO=1"
set "TN_FAILED="
set "TN_RC1=skipped"
set "TN_RC2=skipped"
set "TN_RC3=skipped"
set "TN_RC4=skipped"
set "TN_RC5=skipped"
title tonight - Run Now, pick_meta, setups, why, tradelab + intraday

rem where tradelab writes - read from env_tradelab.bat in a scope of its own, so Run Now starts in a clean environment
setlocal
call "%TN_TL_DIR%env_tradelab.bat" >nul
endlocal & set "TN_OUT=%TRADELAB_OUT%"
if "%TN_OUT%"=="" set "TN_OUT=C:\QuantData\tradelab"
if not exist "%TN_OUT%" mkdir "%TN_OUT%"

echo.
echo   ==== STEP 1 of 5: Run Now - started %DATE% %TIME% ====
if exist "%TN_RUN_NOW%" goto :run_now
echo   NOT FOUND: %TN_RUN_NOW%
echo   Edit TN_RUN_NOW at the top of run_tonight.bat: the file you double-click as Run Now.
set "TN_RC1=9"
goto :step2
:run_now
for %%I in ("%TN_RUN_NOW%") do set "TN_RUN_NOW_DIR=%%~dpI"
pushd "%TN_RUN_NOW_DIR%"
if defined TN_AUTO goto :run_now_auto
cmd /c ""%TN_RUN_NOW%""
set "TN_RC1=%ERRORLEVEL%"
popd
goto :step2
:run_now_auto
cmd /c ""%TN_RUN_NOW%"" <nul
set "TN_RC1=%ERRORLEVEL%"
popd

:step2
if not "%TN_RC1%"=="0" set "TN_FAILED=%TN_FAILED% [step 1 Run Now: code %TN_RC1%]"
call :start_3m
echo.
echo   ==== STEP 2 of 5: pick_meta - publish the cards, score the tracker - %TIME% ====
setlocal
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :pm_noenv
pushd "%BIGMOVE_DIR%\open_close"
set "PYTHONPATH=%BIGMOVE_DIR%"
python pick_meta.py publish --root "%CACHE_DAILY_ROOT%" --all-missing
set "TN_R=%ERRORLEVEL%"
python pick_meta.py score --root "%CACHE_DAILY_ROOT%"
if "%TN_R%"=="0" set "TN_R=%ERRORLEVEL%"
popd
goto :pm_done
:pm_noenv
echo   CACHE_DAILY_ROOT is empty after env_daily.bat - pick_meta skipped
set "TN_R=9"
:pm_done
endlocal & set "TN_RC2=%TN_R%"
if not "%TN_RC2%"=="0" set "TN_FAILED=%TN_FAILED% [step 2 pick_meta: code %TN_RC2%]"

echo.
echo   ==== STEP 3 of 5: setuplab - the frozen setups' scan of the last five days' picks - %TIME% ====
setlocal
call "%TN_TL_DIR%env_tradelab.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :su_noenv
if not exist "%SETUPLAB_DIR%\setuplab.py" goto :su_nofile
pushd "%SETUPLAB_DIR%"
python setuplab.py scan --root "%CACHE_DAILY_ROOT%" --out "%SETUPLAB_OUT%" --all-missing
set "TN_R=%ERRORLEVEL%"
popd
goto :su_done
:su_noenv
echo   CACHE_DAILY_ROOT is empty after env_tradelab.bat - the setup scan skipped
set "TN_R=9"
goto :su_done
:su_nofile
echo   NOT FOUND: %SETUPLAB_DIR%\setuplab.py - edit SETUPLAB_DIR at the top of env_tradelab.bat
set "TN_R=9"
:su_done
endlocal & set "TN_RC3=%TN_R%"
if not "%TN_RC3%"=="0" set "TN_FAILED=%TN_FAILED% [step 3 setup scan: code %TN_RC3%]"

echo.
echo   ==== STEP 4 of 5: whylab - why each pick was picked, recorded before the next open - %TIME% ====
setlocal
call "%TN_TL_DIR%env_tradelab.bat" >nul
set "TN_WY=%WHYLAB_DIR%"
set "CACHE_DAILY_ROOT="
if "%TN_WY%"=="" goto :wy_nodir
if not exist "%TN_WY%\whylab.py" goto :wy_nofile
if not exist "%TN_WY%\env_whylab.bat" goto :wy_nofile
call "%TN_WY%\env_whylab.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :wy_noenv
pushd "%TN_WY%"
python whylab.py why --root "%CACHE_DAILY_ROOT%" --out "%WHYLAB_OUT%" --catch-up
set "TN_R=%ERRORLEVEL%"
popd
goto :wy_done
:wy_nodir
echo   WHYLAB_DIR is empty - add WHYLAB_DIR and WHYLAB_OUT to env_tradelab.bat (why add-on v1.0)
set "TN_R=9"
goto :wy_done
:wy_nofile
echo   NOT FOUND: %TN_WY%\whylab.py or env_whylab.bat - edit WHYLAB_DIR at the top of env_tradelab.bat
set "TN_R=9"
goto :wy_done
:wy_noenv
echo   env_whylab.bat stopped (its own line above says why) - whylab skipped
set "TN_R=9"
:wy_done
endlocal & set "TN_RC4=%TN_R%"
if not "%TN_RC4%"=="0" set "TN_FAILED=%TN_FAILED% [step 4 whylab why: code %TN_RC4%]"

echo.
echo   ==== STEP 5 of 5: tradelab - the watch page - %TIME% ====
setlocal
call "%TN_TL_DIR%env_tradelab.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :tl_noenv
pushd "%TN_TL_DIR%"
python tl_watch.py --root "%CACHE_DAILY_ROOT%" --all-missing
set "TN_R=%ERRORLEVEL%"
popd
goto :tl_done
:tl_noenv
echo   CACHE_DAILY_ROOT is empty after env_tradelab.bat - the watch page skipped
set "TN_R=9"
:tl_done
endlocal & set "TN_RC5=%TN_R%"
if not "%TN_RC5%"=="0" set "TN_FAILED=%TN_FAILED% [step 5 tl_watch: code %TN_RC5%]"
if not defined TN_AUTO if "%TN_RC5%"=="0" call :open_latest

echo.
if defined TN_FAILED goto :result_failed
echo   RESULT: OK - Run Now, pick_meta's cards, the setup scan, the why record and the watch page are done
echo   Pages: %TN_OUT%\watch
set "TN_RC=0"
goto :result_log
:result_failed
echo   RESULT: FAILED at%TN_FAILED%
echo   Read that step's own lines above. The steps after it still ran on what production had already recorded.
set "TN_RC=1"
:result_log
if "%TN_3M%"=="started" echo   Intraday: started in its own window after Run Now - its result goes to %TN_OUT%\intraday_log.txt
if "%TN_3M%"=="not found" echo   Intraday: NOT STARTED - intraday_tonight.bat is not beside run_tonight.bat
>>"%TN_OUT%\tonight_log.txt" echo %DATE% %TIME%  run_now=%TN_RC1%  pick_meta=%TN_RC2%  setup_scan=%TN_RC3%  why=%TN_RC4%  tl_watch=%TN_RC5%  intraday=%TN_3M%%TN_FAILED%
if not defined TN_AUTO pause
endlocal & exit /b %TN_RC%

:open_latest
for /f "delims=" %%F in ('dir /b /o-n "%TN_OUT%\watch\WATCH_*.html" 2^>nul') do (
    start "" "%TN_OUT%\watch\%%F"
    goto :eof
)
goto :eof

:start_3m
rem intraday add-on v1.0: the 3-minute cache and its features in a window of their own - see intraday_tonight.bat
echo.
if not exist "%TN_3M_BAT%" goto :start_3m_none
echo   ==== INTRADAY - started in a window of its own: the 3-minute cache, then its features - %TIME% ====
set "TN_3M=started"
if defined TN_AUTO goto :start_3m_auto
start "intraday 3m" cmd /c ""%TN_3M_BAT%""
goto :eof
:start_3m_auto
start "intraday 3m" /min cmd /c ""%TN_3M_BAT%" auto"
goto :eof
:start_3m_none
echo   ==== INTRADAY - not started: %TN_3M_BAT% not found ====
set "TN_3M=not found"
goto :eof
