# MANIFEST - jumplab v1.0

12 Nov 2026: a meta model for BigMove's JUMPY picks (ranks 1-10) built on volatility and direction, and swing targets from pick_meta's forecasts - study JL1, declared before any run (JUMPLAB_DECLARATION.json). Lives beside tradelab (PyCharmMiscProject\jumplab), reads production read only through tradelab's tl_data (pick_meta's research run hash-checked, the daily cache, the 3-minute bars, stage E's rules), writes only under C:\QuantData\jumplab. Needs tradelab v1.3.1 + setups add-on v1.6 and scikit-learn.

| file | version | sha256 (16) | role |
|---|---|---|---|
| jumplab.py | jumplab v1.0 | eb2601176c36fa3a | COMMAND: check (the declaration and tradelab's strategies\jumplab.py) / run (Stage 1: lane, features, walk-forward meta model, skill -> REPORT.md, jm_scores.parquet, run_stage2.bat) / holm (Stage 2: Holm per engine, the drawdown goal) |
| JUMPLAB_DECLARATION.json | frozen 2026-11-12 | ac9b731c8df75078 | study JL1: picks and lane (the tree's cut-offs), 37 features, the model and its walk-forward, skill measures, the 16 Stage 2 strategies, the pass rule, Holm, the goal check; jumplab.py refuses any other sha256 |
| env_jumplab.bat | jumplab v1.0 | 6b21983b820f2e55 | session setup (CRLF): CACHE_DAILY_ROOT via env_daily.bat, JUMPLAB_OUT=C:\QuantData\jumplab, PYTHONPATH jumplab;tradelab;open_close;bigmove_deploy |
| README_JUMPLAB.md | jumplab v1.0 | 8d4f1c9c58c7ce2e | the question, the two stages, the 16 strategies, how to run, the outputs, the tests |
| tests/test_jumplab.py | jumplab v1.0 | 1bfd69ed4e1454e2 | 8 checks on tradelab's test worlds (planted / absent labels) and by hand; must end VERIFIED (jumplab v1.0) |

Declaration sha256 (full): ac9b731c8df750785c9168ac870a951bfd73a48821c9fc9f2cbc33b4fe567a05
tradelab strategies\jumplab.py sha256 (declared): 03ab53624a8dccf97a0e6188031d6c9563d29bb204c9750d46ac0b02bd218a55

Verified here: 8 checks, 0 failures on pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1 and pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2; 16 planted bugs each caught (the lane at the cut-off, no-ATR picks, the embargo, the percentile reference, calm picks scored, the close location, the ATR rank window, intraday sampling, the last hour, the dip label, Holm, the goal check, ENS commands, the volume median, jm_rand, a re-export column). tradelab section 21: 9 more planted bugs, each caught.
