# jumplab v1.0 — a meta model for BigMove's JUMPY picks, and swing targets (study JL1)

**Question.** The frozen tree never buys a JUMPY pick at the open. It waits for a frozen setup or skips the pick. Can a meta model built from volatility and direction pick out the jumpy picks worth buying at the D1 open, across all ranks 1–10? And since swing size is predictable but direction is not, do targets set from the forecast swing beat the tree's 5th-close exit?

Everything was declared before any run, in **`JUMPLAB_DECLARATION.json`** (12 Nov 2026). `jumplab.py` refuses any other sha256.

**Prior evidence (why expectations are low).**
- pick_meta's P(profit) had AUC 0.529, and its pick test said KEEP D: −21.3 [−49.7, +7.7].
- VD1 found no volatility × direction rule that worked across the universe.
- What *is* predictable is swing size (P(+5%) AUC 0.695) and dip risk (P(−8%) AUC 0.699).

## Stage 1 — `jumplab.py run` (walk-forward meta model)

- **Rows.** All D and ENS picks, ranks 1–10, from pick_meta's research run (hash-checked). The labels are pick_meta's honest trades: D1 open → 5th close, after 35 bp.
- **Lane.** The frozen tree's rule: s_atr14 above the year's cut-off is JUMPY, and a pick with no ATR is also JUMPY. ETFs are never jumpy. The cut-offs are copied into the declaration.
- **Inputs (37), all known at the signal close.**
  - Direction: SDE 3/5/10/20, returns over 1/5/20/60 sessions, share of up days, close location, distance from the 20-session high and low, the gap.
  - Volatility: ATR%, its rank against the stock's own year, true-range ratio, up and down semideviation, RSJ, largest-day share, shock.
  - Volume: turnover ratio, the day's volume against its median, turnover level.
  - Recent lower-circuit locks.
  - **Intraday** (3-minute bars): RSJ and realised variance over 5 sessions, the last hour's return, coverage.
  - The model's standing: rank, score, score z, gap to the next rank, engine, the other engine's rank, repeat.
  - Market-wide inputs are left out, because pick_meta showed the model memorises regimes from them.
- **Models.** Two HistGradientBoosting models, with pick_meta's shallow settings:
  - expected net;
  - P(dip to −8% or worse).
- **Walk-forward by year from 2021.** Each year's model trains only on jumpy picks that exited at least 5 sessions before that year started.
- **Scores.** Every jumpy pick of the test year gets:
  - `jm_net` and `jm_dip`;
  - their percentiles among the model's own training predictions (`jm_net_q`, `jm_dip_q`);
  - a fixed random number for the random control (`jm_rand`).
  - pick_meta's frozen forecasts are copied in under fixed names (`jm_up5`, `jm_deep`, `jm_mfe20/50/80`, `jm_mae20/50`).
- **Skill (descriptive).** On out-of-sample jumpy picks from 2021:
  - the daily rank correlation of `jm_net` with the real net;
  - the top 30% against the rest on the same day;
  - the dip AUC, shown beside pick_meta's own.

## Stage 2 — tradelab add-on v1.6 (`strategies\jumplab.py`, 16 strategies × D and ENS, each against the frozen tree)

| | strategy |
|-|-|
| T1 / T2 | sell at +5% / +3% when P(+5% touch) ≥ 0.5 (ranks 1–3, from 2022) |
| T3 / T4 | sell at + the forecast median swing / + the forecast 20% swing (the likely one) |
| T5 / T6 | sell at +5% / +3% always (controls) |
| T7 | T3 + a stop at the forecast 20% dip |
| T8 | a 3% trailing stop once the gain reaches the forecast median swing |
| J0 | buy every jumpy pick, ranks 1–10, at the D1 open (control) |
| J1 | jumpy, ranks 1–10, meta expected net in its top 30% → D1 open |
| J2 | jumpy, meta expected net above 0 → D1 open |
| J3 | J1, and meta dip risk at or below its median |
| J4 | J1, plus no tree buy at all for a jumpy pick in the meta's bottom 30% (three-way: open / tree / skip) |
| J5 | J1 + T3's target |
| J6 | a random 30% of the jumpy picks (control) |
| J7 | J1 on ranks 1–3 only |

**PASS rule.** For each strategy:
- the daily-return difference against the frozen tree has a 95% interval above 0;
- the CAGR is higher;
- the worst drawdown is no deeper.

Then Holm corrects across each engine's 16 strategies (0.025, one-sided). `jumplab.py holm` also prints your 18 Oct goal for each run: a worst drawdown of −25% or better while keeping at least 70% of the tree's CAGR (descriptive). A PASS is a forward candidate only.

## Install and run

1. Copy the `jumplab` folder to `C:\Users\karanvsi\PyCharmMiscProject\jumplab`, beside tradelab.
2. Install tradelab add-on v1.6, which is the other zip.
3. jumplab needs scikit-learn (pick_meta already uses it).

```
call C:\Users\karanvsi\PyCharmMiscProject\jumplab\env_jumplab.bat
python tests\test_jumplab.py
python jumplab.py check
python jumplab.py run --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
```

Then double-click `C:\QuantData\jumplab\runs\JL_<date>_<nnn>\run_stage2.bat`. It runs all 32 backtests from the tradelab folder, then Holm. Its commands are also in `stage2_commands.txt`.

**Outputs** (`C:\QuantData\jumplab\runs\JL_<date>_<nnn>\`):
- REPORT.md: the verdict first, the Stage 2 commands, the model year by year, deciles, what the model leans on;
- jm_scores.parquet: tradelab's `--jumplab` reads it, hash-checked;
- skill.csv, deciles.csv, years.csv, importance.csv;
- stage2_commands.txt, run_stage2.bat;
- run.json, DECLARATION.json, outputs.sha256;
- one line per run in `jumplab_ledger.jsonl`.

## Tests (`tests\test_jumplab.py`, 8 checks)

- **The declaration and the strategies file.** Both are checked against their frozen sha256.
- **By hand:**
  - the lane;
  - the daily features at 25 picks;
  - the intraday features from the 3-minute file;
  - the walk-forward model, refitted by hand to the same scores and percentiles;
  - the embargo, `jm_rand`, the re-exports.
- **Planted world.** Jumpy orderly falls are planted to gain +4%, and jumpy 5-day runners to dip −10%. The run must find NET SKILL and DIP SKILL, the top 30% must beat the rest, and an SDE must lead the importance.
- **Absent world:** no net skill.
- **Outputs:** hashed, with 32 commands and a CRLF .bat.
- **Holm** and the goal check by hand, plus guards.

16 planted bugs, each caught. tradelab's section 21 covers the Stage 2 mechanics (9 more planted bugs).
