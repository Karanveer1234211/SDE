@echo off
rem env_jumplab.bat - jumplab v1.0 (a meta model for BigMove's jumpy picks, and swing targets): start a session.
rem   call C:\Users\karanvsi\PyCharmMiscProject\jumplab\env_jumplab.bat
rem Reads production (pick_meta's research run, the daily cache, the 3-minute bars, stage E's rules) READ ONLY,
rem through tradelab's tl_data. Writes only under JUMPLAB_OUT. Edit the paths below if your folders differ.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "JUMPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\jumplab"
set "JUMPLAB_OUT=C:\QuantData\jumplab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_data.py" goto :no_tradelab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%JUMPLAB_DIR%;%TRADELAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%JUMPLAB_OUT%" mkdir "%JUMPLAB_OUT%"
cd /d "%JUMPLAB_DIR%"
echo jumplab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   JUMPLAB_OUT=%JUMPLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_jumplab.bat
exit /b 1
:no_tradelab
echo ERROR: %TRADELAB_DIR%\tl_data.py not found - jumplab reads the cache through tradelab (edit TRADELAB_DIR)
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
