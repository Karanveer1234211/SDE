"""
jumplab.py - jumplab v1.0: a volatility and direction meta model for BigMove's JUMPY picks, and swing targets (JL1).

    python jumplab.py check                                       the declaration and tradelab's strategies\\jumplab.py
                                                                  are the frozen ones (sha256)
    python jumplab.py run --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 [--out <folder>] [--stage-e-any]
                                                                  Stage 1 -> JUMPLAB_OUT\\runs\\JL_<date>_<nnn>
    python jumplab.py holm <TLB folder> [...] | --scan <tradelab backtest folder>
                                                                  Stage 2: Holm across each engine's 16 strategies

JUMPLAB_DECLARATION.json (beside this file, frozen 12 Nov 2026 before any run) holds the study: the picks and their lane,
the features, the walk-forward meta model, the skill measures and the 16 Stage 2 strategies (tradelab add-on v1.6).

READS (read only): pick_meta's research run (predictions.parquet, hash-checked by tradelab's tl_data.load_picks), the
daily cache and the 3-minute bars through tradelab's tl_data (production's loader and lower-circuit rule), NSE's ETF
list when present. WRITES only under --out / JUMPLAB_OUT: JL_<date>_<nnn>\\ REPORT.md, jm_scores.parquet (tradelab's
--jumplab reads it), skill.csv, deciles.csv, years.csv, importance.csv, stage2_commands.txt, run_stage2.bat, run.json,
DECLARATION.json, outputs.sha256; one line per run in jumplab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import tl_common as TC
import tl_data as TD
import tl_setups as SU

VERSION = "jumplab v1.0"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "JUMPLAB_DECLARATION.json"
DECL_SHA = "ac9b731c8df750785c9168ac870a951bfd73a48821c9fc9f2cbc33b4fe567a05"
STRAT_FILE = HERE.parent / "tradelab" / "strategies" / "jumplab.py"
LEDGER = "jumplab_ledger.jsonl"
VARIANTS = ("T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "J0", "J1", "J2", "J3", "J4", "J5", "J6", "J7")
ETF_RE = re.compile(r"(BEES|IETF|ETF)$")
DIP = -0.08
FEATS = ["sde3", "sde5", "sde10", "sde20", "ret1", "ret5", "ret20", "ret60", "up_share10", "clv5", "dist_hi20",
         "dist_lo20", "gap1", "atrp", "atr_rank252", "tr_ratio", "semivol20", "upvol20", "semi_share", "rsj10", "lds10",
         "shock", "turn_rel", "vol_ratio1", "log_turn20", "lock3", "rsj_i5", "rv_i5", "last_hour", "i_cov", "rank",
         "score", "score_z", "score_gap", "engine_D", "other_rank", "repeat"]


class JLError(Exception):
    pass


def say(msg: str) -> None:
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def sha256(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


# ---------------------------------------------------------------------------------------------------- declaration
def load_decl(path: Path = DECL_FILE, check: bool = True) -> Tuple[dict, str]:
    if not Path(path).is_file():
        raise JLError(f"{path} is missing - it ships beside jumplab.py")
    sha = sha256(path)
    if check and sha != DECL_SHA:
        raise JLError(f"{path} has sha256 {sha[:16]}, not the frozen declaration's {DECL_SHA[:16]}. The declaration is "
                      f"fixed before any run; a changed study is a new declaration (ask Claude).")
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    if tuple(d["stage2_book"]["variants"]) != VARIANTS:
        raise JLError(f"{path}: the Stage 2 variants differ from the ones this code knows")
    return d, sha


def out_base(arg: Optional[str], root: Optional[Path]) -> Path:
    v = arg or os.environ.get("JUMPLAB_OUT")
    if not v:
        raise JLError("no output folder: pass --out or start with env_jumplab.bat (sets JUMPLAB_OUT)")
    b = Path(v).resolve()
    guards = ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                          ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise JLError(f"output folder {b} is inside {g}; jumplab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


# ---------------------------------------------------------------------------------------------------- lane
def etf_names(root: Path, decl: dict) -> Tuple[set, str]:
    names = {s.upper() for s in decl["picks"]["lane"]["etf_names"]}
    p = Path(root) / "sectors" / "eq_etfseclist.csv"
    if p.is_file():
        E = pd.read_csv(p, dtype=str)
        col = next((c for c in E.columns if str(c).strip().lower() == "symbol"), None)
        if col is None:
            raise JLError(f"{p} has no Symbol column - is it NSE's ETF list?")
        names |= {str(s).strip().upper() for s in E[col].dropna() if str(s).strip()}
        return names, f"NSE's list ({p.name}) + the tree's names + the name rule"
    return names, "the tree's names + the name rule (NSE's list not found)"


def lanes(T: pd.DataFrame, atr: np.ndarray, decl: dict, etfs: set) -> np.ndarray:
    """1 = JUMPY (s_atr14 above the year's cut-off, or no ATR), 0 = CALM or an ETF."""
    cuts = {int(k): float(v) for k, v in decl["picks"]["lane"]["cutoffs"].items()}
    first = min(cuts)
    yrs = pd.DatetimeIndex(T["signal_day"]).year.to_numpy()
    cut = np.array([cuts.get(int(y), cuts[first] if y < first else np.nan) for y in yrs])
    with np.errstate(invalid="ignore"):
        jumpy = ~np.isfinite(atr) | (atr > cut)
    jumpy &= np.isfinite(cut)
    names = set(etfs) | {x.upper() for x in decl["picks"]["lane"]["etf_names"]}
    etf = np.array([bool(ETF_RE.search(s.upper())) or s.upper() in names for s in T["symbol"].astype(str)])
    return (jumpy & ~etf).astype(float)


# ---------------------------------------------------------------------------------------------------- features
def daily_features(ds) -> Dict[str, np.ndarray]:
    """Every value at bar t is known at t's close (see the declaration's features)."""
    o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
    v = np.asarray(ds.v, float) if ds.v is not None else np.full(len(c), np.nan)
    n = len(c)
    A = SU.vol_arrays(o, h, l, c, v)
    r = A["r"]
    fin = np.isfinite(r).astype(float)
    F = {k: A[k] for k in ("rsj10", "turn_rel", "lds10", "shock", "ret20", "atrp", "semivol20", "sde10")}
    for k in (3, 5, 20):
        F[f"sde{k}"] = SU.sde_series(c, k)
    pc = np.r_[np.nan, c[:-1]]
    with np.errstate(divide="ignore", invalid="ignore"):
        F["ret1"] = c / pc - 1
        for k in (5, 60):
            x = np.full(n, np.nan)
            if n > k:
                x[k:] = c[k:] / c[:-k] - 1
            x[~(SU._roll(fin, k, "sum") >= k)] = np.nan
            F[f"ret{k}"] = x
        F["ret1"][~np.isfinite(r)] = np.nan
        up = np.where(np.isfinite(r), (r > 0).astype(float), np.nan)
        F["up_share10"] = np.where(SU._roll(fin, 10, "sum") >= 10, SU._roll(np.nan_to_num(up), 10, "mean"), np.nan)
        rng = h - l
        clv = np.where(rng > 0, ((c - l) - (h - c)) / rng, 0.0)
        F["clv5"] = SU._roll(clv, 5, "mean")
        atr = F["atrp"] * c
        F["dist_hi20"] = (c - SU._roll(h, 20, "max")) / atr
        F["dist_lo20"] = (c - SU._roll(l, 20, "min")) / atr
        F["gap1"] = o / pc - 1
        F["gap1"][np.abs(F["gap1"]) > SU.SDE_JUMP] = np.nan
        ap = pd.Series(F["atrp"])
        F["atr_rank252"] = ap.rolling(253, min_periods=253).apply(lambda w: float(np.mean(w[:-1] <= w[-1])),
                                                                  raw=True).to_numpy(float)
        tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
        F["tr_ratio"] = tr / atr
        r2 = np.where(np.isfinite(r), r * r, 0.0)
        upv = np.sqrt(2.0 * SU._roll(np.where(r > 0, r2, 0.0), 20, "mean"))
        upv[~(SU._roll(fin, 20, "sum") >= 20)] = np.nan
        F["upvol20"] = upv
        F["semi_share"] = F["semivol20"] / (F["semivol20"] + upv)
        F["vol_ratio1"] = v / SU._roll(v, 50, "median", shift=1)
        F["log_turn20"] = np.log10(np.clip(SU._roll(c * v, 20, "median"), 1, None))
    F["lock3"] = SU.lock3_of(SU.lower_locks(ds)).astype(float)
    return F


def intraday_features(S: Dict, ds, i: int) -> Dict[str, float]:
    """The 5 sessions to bar i from the 3-minute bars (S = the symbol's sessions by day), as 15-minute log returns."""
    out = {"rsj_i5": np.nan, "rv_i5": np.nan, "last_hour": np.nan, "i_cov": 0.0}
    if S is None or i < 4:
        return out
    days = [np.datetime64(ds.dates[j], "D") for j in range(i - 4, i + 1)]
    up = dn = 0.0
    var, used = [], 0
    for d in days:
        s = S.get(d)
        if s is None or not getattr(s, "usable", False):
            continue
        cl = np.asarray(s.c, float)
        p = np.r_[float(s.o[0]), cl[4::5]]
        p = p[np.isfinite(p) & (p > 0)]
        if len(p) < 10:
            continue
        rr = np.diff(np.log(p))
        up += float((rr[rr > 0] ** 2).sum())
        dn += float((rr[rr < 0] ** 2).sum())
        var.append(float((rr ** 2).sum()))
        used += 1
        if d == days[-1] and len(cl) >= 21 and np.isfinite(cl[-1]) and np.isfinite(cl[-21]) and cl[-21] > 0:
            out["last_hour"] = float(cl[-1] / cl[-21] - 1)
    out["i_cov"] = used / 5.0
    if used and up + dn > 0:
        out["rsj_i5"] = (up - dn) / (up + dn)
        out["rv_i5"] = float(np.mean(var))
    return out


def standing(T: pd.DataFrame) -> pd.DataFrame:
    X = pd.DataFrame(index=T.index)
    g = T.groupby(["engine", "signal_day"])["score"]
    sd = g.transform("std").replace(0, np.nan)
    X["score_z"] = (T["score"] - g.transform("mean")) / sd
    nxt = T.sort_values(["engine", "signal_day", "rank"]).groupby(["engine", "signal_day"])["score"].shift(-1)
    X["score_gap"] = T["score"] - nxt.reindex(T.index)
    return X


def build(root: Path, pm_run: str, decl: dict, stage_e_any: bool, log=say) -> dict:
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    T, pinfo = TD.load_picks(root, pm_run, ["D", "ENS"], list(range(1, 11)))
    log(f"picks: {len(T):,} (D and ENS, ranks 1-10) from {pinfo['first_day']} to {pinfo['last_day']}; file sha256 "
        f"{pinfo['sha256'][:16]}")
    etfs, etf_txt = etf_names(root, decl)
    try:
        store = market.intraday
        intraday_note = f"3-minute bars from {store.dir}"
    except Exception as e:                                         # no 3-minute folder: features blank, said loudly
        store, intraday_note = None, f"NO 3-minute bars ({type(e).__name__}: {e}) - the intraday features are blank"
    log(f"intraday: {intraday_note}")
    n = len(T)
    cols = {k: np.full(n, np.nan) for k in FEATS}
    atr_bars = np.full(n, np.nan)
    days = pd.DatetimeIndex(T["signal_day"]).to_numpy().astype("datetime64[D]")
    t0 = time.time()
    groups = list(pd.Series(np.arange(n)).groupby(T["symbol"].astype(str).to_numpy()))
    for k, (sym, idxs) in enumerate(groups):
        ds = market.series(sym)
        if ds is None or not len(ds):
            continue
        F = daily_features(ds)
        ii = idxs.to_numpy()
        pos = np.array([ds.idx(days[j]) for j in ii], dtype=np.int64)
        ok = pos >= 0
        for name, arr in F.items():
            if name in cols:
                cols[name][ii[ok]] = arr[pos[ok]]
        atr_bars[ii[ok]] = F["atrp"][pos[ok]]
        Si = None
        if store is not None and ok.any():                  # one read of the symbol's 3-minute file
            want = sorted({np.datetime64(ds.dates[q], "D") for p_ in pos[ok] for q in range(max(p_ - 4, 0), p_ + 1)})
            try:
                Si = store.sessions(sym, want, ds)
            except Exception:
                Si = None
        for j, p_ in zip(ii[ok], pos[ok]):
            vals = intraday_features(Si, ds, int(p_))
            a = F["atrp"][p_]
            if np.isfinite(vals["rv_i5"]):
                vals["rv_i5"] = vals["rv_i5"] / (a * a) if np.isfinite(a) and a > 0 else np.nan
            for kk, vv in vals.items():
                cols[kk][j] = vv
        market.daily.pop(sym, None)
        if k and k % 200 == 0:
            log(f"   {k:,} of {len(groups):,} symbols ({time.time() - t0:.0f}s)")
    X = pd.DataFrame(cols, index=T.index)
    X["rank"] = T["rank"].astype(float)
    X["score"] = pd.to_numeric(T["score"], errors="coerce")
    X[["score_z", "score_gap"]] = standing(T)
    X["engine_D"] = (T["engine"] == "D").astype(float)
    X["other_rank"] = pd.to_numeric(T.get("other_rank"), errors="coerce")
    X["repeat"] = T["repeat"].astype(float) if "repeat" in T.columns else np.nan
    atr = pd.to_numeric(T["s_atr14"], errors="coerce").to_numpy(float) if "s_atr14" in T.columns else np.full(n, np.nan)
    atr = np.where(np.isfinite(atr), atr, atr_bars)
    jumpy = lanes(T, atr, decl, etfs)
    return {"T": T, "X": X[FEATS], "jumpy": jumpy, "pinfo": pinfo, "etf": etf_txt, "intraday": intraday_note,
            "cal": np.asarray(market.cal).astype("datetime64[D]"), "prod": prod.describe(),
            "i_sessions": None if store is None else {"asked": store.asked, "usable": store.usable,
                                                      "reasons": dict(store.reasons)}}


# ---------------------------------------------------------------------------------------------------- the model
def labels(T: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    st = T["status_recorded"].astype(str).to_numpy() if "status_recorded" in T.columns else np.full(len(T), "")
    net = pd.to_numeric(T["net_recorded"], errors="coerce").to_numpy(float)
    mae = pd.to_numeric(T["mae_recorded"], errors="coerce").to_numpy(float)
    ok = (st == "ok") & np.isfinite(net)
    return ok, net, (mae <= DIP).astype(float)


def _models(decl: dict):
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
    s = dict(decl["model"]["settings"])
    return HistGradientBoostingRegressor(loss="squared_error", **s), HistGradientBoostingClassifier(**s)


def walk_forward(D: dict, decl: dict, log=say) -> dict:
    T, X, jumpy, cal = D["T"], D["X"], D["jumpy"], D["cal"]
    ok, net, dip = labels(T)
    sd = pd.DatetimeIndex(T["signal_day"]).to_numpy().astype("datetime64[D]")
    ex = pd.to_datetime(T.get("exit_day_recorded"), errors="coerce").to_numpy().astype("datetime64[D]")
    years = sorted({int(y) for y in pd.DatetimeIndex(T["signal_day"]).year if y >= 2021})
    out = {k: np.full(len(T), np.nan) for k in ("jm_net", "jm_net_q", "jm_dip", "jm_dip_q")}
    fits = []
    Xv = X.to_numpy(float)
    for y in years:
        first = np.datetime64(f"{y}-01-01", "D")
        k0 = int(np.searchsorted(cal, first))
        gate = cal[max(k0 - 5, 0)]
        tr = (jumpy == 1) & ok & (ex < gate)
        te = (jumpy == 1) & (sd >= first) & (sd < np.datetime64(f"{y + 1}-01-01", "D"))
        if tr.sum() < 200 or not te.any():
            fits.append({"year": y, "train_rows": int(tr.sum()), "test_rows": int(te.sum()), "fitted": False})
            continue
        lo, hi = np.percentile(net[tr], [1, 99])
        use = np.isfinite(Xv[tr]).any(axis=0)              # a feature blank in every training row sits this year out
        Xtr, Xte = Xv[tr][:, use], Xv[te][:, use]
        mr, mc = _models(decl)
        mr.fit(Xtr, np.clip(net[tr], lo, hi))
        if 0 < dip[tr].mean() < 1:
            mc.fit(Xtr, dip[tr])
            fd = np.sort(mc.predict_proba(Xtr)[:, 1])
            pd_ = mc.predict_proba(Xte)[:, 1]
            out["jm_dip"][te] = pd_
            out["jm_dip_q"][te] = np.searchsorted(fd, pd_, side="right") / len(fd)
        fn = np.sort(mr.predict(Xtr))
        pn = mr.predict(Xte)
        out["jm_net"][te] = pn
        out["jm_net_q"][te] = np.searchsorted(fn, pn, side="right") / len(fn)
        fits.append({"year": y, "train_rows": int(tr.sum()), "test_rows": int(te.sum()), "fitted": True,
                     "train_first": str(sd[tr].min()), "train_last_exit": str(ex[tr].max()), "dip_rate": float(dip[tr].mean()),
                     "features_out": [f for f, u in zip(FEATS, use) if not u]})
        last = (mr, tr, use)
        log(f"   {y}: trained on {tr.sum():,} jumpy picks (exits to {ex[tr].max()}), scored {te.sum():,}")
    imp = importance(last[0], Xv[last[1]][:, last[2]], np.clip(net[last[1]], *np.percentile(net[last[1]], [1, 99])),
                     [f for f, u in zip(FEATS, last[2]) if u]) if any(f["fitted"] for f in fits) else pd.DataFrame()
    return {"scores": out, "fits": fits, "importance": imp}


def importance(model, Xv, y, names) -> pd.DataFrame:
    """Permutation importance of the last year's net model on its own training rows (descriptive)."""
    from sklearn.inspection import permutation_importance
    rng = np.random.default_rng(7)
    k = rng.choice(len(Xv), size=min(len(Xv), 6000), replace=False)
    r = permutation_importance(model, Xv[k], y[k], n_repeats=3, random_state=7, scoring="r2")
    return pd.DataFrame({"feature": names, "importance": r.importances_mean}).sort_values("importance", ascending=False)


def jm_rand(tids) -> np.ndarray:
    return np.array([int(hashlib.sha256(str(t).encode()).hexdigest()[:12], 16) / 16 ** 12 for t in tids])


def scores_frame(D: dict, W: dict, decl: dict) -> Tuple[pd.DataFrame, List[str]]:
    T = D["T"]
    J = pd.DataFrame({"trade_id": T["trade_id"].astype(str).to_numpy(), "engine": T["engine"].to_numpy(),
                      "signal_day": T["signal_day"].to_numpy(), "rank": T["rank"].to_numpy(),
                      "symbol": T["symbol"].to_numpy(), "jm_jumpy": D["jumpy"]})
    for k, v in W["scores"].items():
        J[k] = v
    J["jm_rand"] = jm_rand(J["trade_id"])
    missing = []
    for k, src in decl["model"]["pick_meta_reexport"].items():
        if src in T.columns:
            J[k] = pd.to_numeric(T[src], errors="coerce").to_numpy(float)
        else:
            J[k] = np.nan
            missing.append(src)
    return J, missing


# ---------------------------------------------------------------------------------------------------- skill
def _spearman(a, b) -> float:
    if len(a) < 3:
        return np.nan
    ra, rb = pd.Series(a).rank().to_numpy(), pd.Series(b).rank().to_numpy()
    if ra.std() == 0 or rb.std() == 0:
        return np.nan
    return float(np.corrcoef(ra, rb)[0, 1])


def _auc(y, p) -> float:
    y, p = np.asarray(y, float), np.asarray(p, float)
    m = np.isfinite(p)
    y, p = y[m], p[m]
    n1, n0 = (y == 1).sum(), (y == 0).sum()
    if not n1 or not n0:
        return np.nan
    r = pd.Series(p).rank().to_numpy()
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def _auc_boot(days, y, p, B=2000, seed=7):
    u, inv = np.unique(days, return_inverse=True)
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(B):
        w = np.bincount(rng.integers(0, len(u), len(u)), minlength=len(u))[inv]
        k = np.repeat(np.arange(len(y)), w)
        vals.append(_auc(y[k], p[k]))
    vals = np.array(vals, float)
    vals = vals[np.isfinite(vals)]
    return (_auc(y, p), *(np.percentile(vals, [2.5, 97.5]) if len(vals) else (np.nan, np.nan)))


def skill(D: dict, J: pd.DataFrame) -> dict:
    T = D["T"]
    ok, net, dip = labels(T)
    m = ok & (J["jm_jumpy"].to_numpy() == 1) & np.isfinite(J["jm_net"].to_numpy(float))
    S = pd.DataFrame({"day": pd.DatetimeIndex(T["signal_day"])[m], "year": pd.DatetimeIndex(T["signal_day"]).year[m],
                      "net": net[m], "dip": dip[m], "jm_net": J["jm_net"].to_numpy(float)[m],
                      "jm_net_q": J["jm_net_q"].to_numpy(float)[m], "jm_dip": J["jm_dip"].to_numpy(float)[m],
                      "deep": J["jm_deep"].to_numpy(float)[m]})
    out = {"rows": int(len(S)), "days": int(S["day"].nunique()) if len(S) else 0}
    if not len(S):
        return dict(out, net_skill=None, dip_skill=None, top=None, deciles=pd.DataFrame(), years=pd.DataFrame())
    rho = S.groupby("day").apply(lambda g: _spearman(g["jm_net"], g["net"]) if len(g) >= 3 else np.nan).dropna()
    m_, lo, hi = TC.bootstrap_daily(rho.to_numpy(float))
    out["net_skill"] = {"mean": m_, "lo": lo, "hi": hi, "days": int(len(rho)), "pooled": _spearman(S["jm_net"], S["net"]),
                        "verdict": "NET SKILL" if lo > 0 else "no net skill"}
    S["top"] = S["jm_net_q"] >= 0.7
    dd = S.groupby("day").apply(lambda g: g.loc[g["top"], "net"].mean() - g.loc[~g["top"], "net"].mean()
                                if g["top"].any() and (~g["top"]).any() else np.nan).dropna()
    m2, lo2, hi2 = TC.bootstrap_daily(dd.to_numpy(float))
    out["top"] = {"mean": m2, "lo": lo2, "hi": hi2, "days": int(len(dd)), "share_top": float(S["top"].mean()),
                  "net_top": float(S.loc[S["top"], "net"].mean()) if S["top"].any() else np.nan,
                  "net_rest": float(S.loc[~S["top"], "net"].mean()) if (~S["top"]).any() else np.nan}
    a, alo, ahi = _auc_boot(S["day"].to_numpy(), S["dip"].to_numpy(float), S["jm_dip"].to_numpy(float))
    k = np.isfinite(S["deep"].to_numpy(float))
    pm = _auc_boot(S["day"].to_numpy()[k], S["dip"].to_numpy(float)[k], S["deep"].to_numpy(float)[k]) if k.sum() > 50 \
        else (np.nan, np.nan, np.nan)
    jm_same = _auc(S["dip"].to_numpy(float)[k], S["jm_dip"].to_numpy(float)[k]) if k.sum() > 50 else np.nan
    out["dip_skill"] = {"auc": a, "lo": alo, "hi": ahi, "verdict": "DIP SKILL" if alo > 0.5 else "no dip skill",
                        "pick_meta_auc_same_rows": list(pm), "jm_auc_same_rows": jm_same, "rate": float(S["dip"].mean())}
    S["dec"] = pd.qcut(S["jm_net"].rank(method="first"), 10, labels=False) + 1
    out["deciles"] = S.groupby("dec").agg(picks=("net", "size"), mean_net_bp=("net", lambda x: x.mean() * 1e4),
                                          win=("net", lambda x: (x > 0).mean()), dip_rate=("dip", "mean")).reset_index()
    out["years"] = S.groupby("year").apply(lambda g: pd.Series({
        "picks": len(g), "spearman": _spearman(g["jm_net"], g["net"]),
        "top_bp": g.loc[g["top"], "net"].mean() * 1e4 if g["top"].any() else np.nan,
        "rest_bp": g.loc[~g["top"], "net"].mean() * 1e4 if (~g["top"]).any() else np.nan,
        "dip_auc": _auc(g["dip"], g["jm_dip"])})).reset_index()
    return out


# ---------------------------------------------------------------------------------------------------- report
def fmt(m, lo=np.nan, hi=np.nan, k=1e4, nd=1) -> str:
    if m is None or not np.isfinite(m):
        return "-"
    s = f"{m * k:+.{nd}f}"
    return s + (f" [{lo * k:+.{nd}f}, {hi * k:+.{nd}f}]" if np.isfinite(lo) and np.isfinite(hi) else "")


def stage2_commands(run: Path, pm_run: str) -> List[str]:
    return [f'python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run {pm_run} --strategy strategies\\jumplab.py#{v} '
            f'--compare strategies\\tree.py --engines {e} --jumplab "{run}" --declare "jumplab JL1 {v} {e}"'
            for e in ("D", "ENS") for v in VARIANTS]


def stage2_bat(cmds: List[str], base: Path) -> str:
    tl = HERE.parent / "tradelab"
    L = ["@echo off", "rem run_stage2.bat - jumplab JL1 Stage 2: the 32 declared backtests, then Holm (written by "
         f"{VERSION})", f'call "{tl / "env_tradelab.bat"}"', "if errorlevel 1 goto :fail", f'set "JUMPLAB_OUT={base}"',
         f'cd /d "{tl}"']
    for c in cmds:
        L += [c, "if errorlevel 1 goto :fail"]
    L += [f'cd /d "{HERE}"', 'python jumplab.py holm --scan "%TRADELAB_OUT%\\backtest"', "echo RESULT: Stage 2 done",
          "pause", "goto :eof", ":fail", "echo RESULT: FAILED - send Claude the lines above", "pause", "exit /b 1"]
    return "\r\n".join(L) + "\r\n"


def report(D, W, J, SK, decl, sha, secs, run, cmds, missing) -> str:
    T = D["T"]
    jm = J["jm_jumpy"].to_numpy() == 1
    ns, ds_ = SK.get("net_skill") or {}, SK.get("dip_skill") or {}
    tp = SK.get("top") or {}
    L = [f"# jumplab - {decl['name']} ({VERSION})", "",
         f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). pick_meta run "
         f"{D['pinfo']['file']} (sha256 {D['pinfo']['sha256'][:16]}): {len(T):,} picks (D and ENS, ranks 1-10), "
         f"{int(jm.sum()):,} JUMPY ({jm.mean():.1%}). ETFs: {D['etf']}. Intraday: {D['intraday']}. {secs:.0f} s.", "",
         "## Verdict first (Stage 1, descriptive - Stage 2 decides)", ""]
    if ns:
        L.append(f"- **{ns['verdict'].upper()}**: the meta's expected net ranks the day's jumpy picks with a mean daily "
                 f"rank correlation of {ns['mean']:+.4f} [{ns['lo']:+.4f}, {ns['hi']:+.4f}] ({ns['days']:,} days; pooled "
                 f"{ns['pooled']:+.4f}).")
        L.append(f"- Top 30% by the meta minus the rest, same day: {fmt(tp.get('mean'), tp.get('lo'), tp.get('hi'))} bp "
                 f"(top {fmt(tp.get('net_top'))} bp, rest {fmt(tp.get('net_rest'))} bp; {tp.get('share_top', 0):.1%} of "
                 f"the jumpy picks scored top).")
        L.append(f"- **{ds_['verdict'].upper()}**: AUC {ds_['auc']:.3f} [{ds_['lo']:.3f}, {ds_['hi']:.3f}] for a dip to "
                 f"-8% (rate {ds_['rate']:.1%}); pick_meta's prob_deep on the same rows from 2022: "
                 + (f"{ds_['pick_meta_auc_same_rows'][0]:.3f} [{ds_['pick_meta_auc_same_rows'][1]:.3f}, "
                    f"{ds_['pick_meta_auc_same_rows'][2]:.3f}] (the meta {ds_['jm_auc_same_rows']:.3f})"
                    if np.isfinite(ds_['pick_meta_auc_same_rows'][0]) else "not available") + ".")
    else:
        L.append("- No out-of-sample jumpy pick with a settled trade: nothing to score.")
    if missing:
        L.append(f"- pick_meta columns missing from the file (their jm_* stay blank; the T strategies that read them "
                 f"never fire): {missing}.")
    L += ["", f"## Stage 2 - run all {len(cmds)} backtests", "",
          f"Double-click `{run / 'run_stage2.bat'}` (it calls env_tradelab.bat, runs these from the tradelab folder, then "
          "Holm). Or paste them from stage2_commands.txt:", "", "```", *cmds,
          f'cd /d "{HERE}"', 'python jumplab.py holm --scan "%TRADELAB_OUT%\\backtest"', "```", "",
          "## The meta model, year by year (walk-forward)", "",
          "| test year | trained on (jumpy picks) | scored | Spearman (pooled) | top 30% bp | rest bp | dip AUC |",
          "|---|---|---|---|---|---|---|"]
    yrs = SK.get("years")
    yy = yrs.set_index("year") if isinstance(yrs, pd.DataFrame) and len(yrs) else pd.DataFrame()
    for f in W["fits"]:
        r = yy.loc[f["year"]] if f["year"] in yy.index else None
        L.append(f"| {f['year']} | {f['train_rows']:,} | {f['test_rows']:,} | "
                 + (f"{r['spearman']:+.3f} | {r['top_bp']:+.1f} | {r['rest_bp']:+.1f} | {r['dip_auc']:.3f} |" if r is not None
                    else "- | - | - | - |"))
    dec = SK.get("deciles")
    if isinstance(dec, pd.DataFrame) and len(dec):
        L += ["", "### Jumpy picks by the meta's expected net (deciles, out of sample, after 35 bp)", "",
              "| decile | picks | mean net bp | win | dip to -8% |", "|---|---|---|---|---|"]
        for r in dec.itertuples(index=False):
            L.append(f"| {r.dec} | {r.picks:,} | {r.mean_net_bp:+.1f} | {r.win:.1%} | {r.dip_rate:.1%} |")
    imp = W.get("importance")
    if isinstance(imp, pd.DataFrame) and len(imp):
        L += ["", "### What the last year's model leans on (permutation importance, descriptive)", "",
              "| feature | importance (R2 drop) |", "|---|---|"]
        for r in imp.head(12).itertuples(index=False):
            L.append(f"| {r.feature} | {r.importance:+.5f} |")
    L += ["", "## How to read it", "",
          f"- Lane: {decl['picks']['lane']['rule']}; cut-offs {decl['picks']['lane']['cutoffs']}.",
          f"- Model: {decl['model']['walk_forward']}. Scores: {decl['model']['scores']}.",
          f"- Stage 2: {decl['stage2_book']['pass_per_strategy']}. {decl['stage2_book']['family']}. "
          f"{decl['stage2_book']['meaning']}.",
          f"- Prior evidence: {decl['prior_evidence']['expectation']}.", ""]
    return "\n".join(L)


# ---------------------------------------------------------------------------------------------------- commands
def cmd_run(a) -> int:
    t0 = time.time()
    decl, sha = load_decl()
    if not a.root:
        raise JLError("--root is required (--root %CACHE_DAILY_ROOT% after call env_jumplab.bat)")
    root = Path(a.root)
    if not root.is_dir():
        raise JLError(f"--root {root} is not a folder")
    if not a.pm_run:
        raise JLError("--pm-run is required (pick_meta's research run, e.g. PM_20261017_001)")
    base = out_base(a.out, root)
    say(f"{VERSION} | declaration {sha[:16]} | root {root} | pm-run {a.pm_run}")
    D = build(root, a.pm_run, decl, a.stage_e_any)
    say("walk-forward meta model ...")
    W = walk_forward(D, decl)
    J, missing = scores_frame(D, W, decl)
    SK = skill(D, J)
    run = TC.new_run_dir(base, "runs", "JL")
    J.to_parquet(run / SU.JM_FILE, index=False)
    sk_rows = []
    if SK.get("net_skill"):
        sk_rows.append(dict(measure="net_rank_correlation", **{k: SK["net_skill"][k] for k in ("mean", "lo", "hi")}))
        sk_rows.append(dict(measure="top30_minus_rest_net", **{k: SK["top"][k] for k in ("mean", "lo", "hi")}))
        sk_rows.append({"measure": "dip_auc", "mean": SK["dip_skill"]["auc"], "lo": SK["dip_skill"]["lo"],
                        "hi": SK["dip_skill"]["hi"]})
    pd.DataFrame(sk_rows).to_csv(run / "skill.csv", index=False, float_format="%.8g")
    (SK.get("deciles") if isinstance(SK.get("deciles"), pd.DataFrame) else pd.DataFrame()).to_csv(
        run / "deciles.csv", index=False, float_format="%.8g")
    (SK.get("years") if isinstance(SK.get("years"), pd.DataFrame) else pd.DataFrame()).to_csv(
        run / "years.csv", index=False, float_format="%.8g")
    W["importance"].to_csv(run / "importance.csv", index=False, float_format="%.8g")
    cmds = stage2_commands(run, a.pm_run)
    (run / "stage2_commands.txt").write_text("\r\n".join(cmds) + "\r\n", encoding="utf-8")
    (run / "run_stage2.bat").write_bytes(stage2_bat(cmds, base).encode("utf-8"))
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    secs = time.time() - t0
    (run / "REPORT.md").write_text(report(D, W, J, SK, decl, sha, secs, run, cmds, missing), encoding="utf-8")
    meta = {"tool": VERSION, "declaration_sha256": sha, "root": str(root), "pm_run": a.pm_run,
            "predictions_sha256": D["pinfo"]["sha256"], "picks": int(len(J)), "jumpy": int((J["jm_jumpy"] == 1).sum()),
            "scored": int(np.isfinite(J["jm_net"]).sum()), "fits": W["fits"], "missing_pick_meta": missing,
            "intraday": D["intraday"], "intraday_sessions": D["i_sessions"], "etf": D["etf"], "production": D["prod"],
            "net_skill": SK.get("net_skill"), "dip_skill": SK.get("dip_skill"), "top30": SK.get("top"),
            "seconds": round(secs, 1)}
    (run / "run.json").write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    TC.write_outputs_sha(run)
    with open(base / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "run": run.name,
                            "declaration_sha256": sha, "net_skill": (SK.get("net_skill") or {}).get("verdict"),
                            "dip_skill": (SK.get("dip_skill") or {}).get("verdict")}, default=str) + "\n")
    say(f"net: {(SK.get('net_skill') or {}).get('verdict')} | dip: {(SK.get('dip_skill') or {}).get('verdict')}")
    say(f"Stage 2: double-click {run / 'run_stage2.bat'}")
    say(f"DONE {run}  ({secs:.0f} s)")
    return 0


def holm(rows: List[dict], alpha: float = 0.025) -> List[dict]:
    out = []
    for eng in sorted({r["engine"] for r in rows}):
        g = sorted([r for r in rows if r["engine"] == eng], key=lambda r: (np.inf if not np.isfinite(r["p"]) else r["p"]))
        m, going = len(g), True
        for i, r in enumerate(g):
            lim = alpha / (m - i)
            keep = going and np.isfinite(r["p"]) and r["p"] <= lim
            going = keep
            out.append(dict(r, family=m, holm_limit=lim, holm_kept=bool(keep),
                            final="PASS" if keep and r["rule_verdict"] == "PASS" else "FAIL"))
    return out


def read_backtest(folder: Path, want_sha: str) -> dict:
    sj = folder / "summary.json"
    if not sj.is_file():
        raise JLError(f"{folder}: no summary.json")
    s = json.loads(sj.read_text(encoding="utf-8"))
    st, dec = s.get("strategy") or {}, s.get("decision") or {}
    copies = sorted(folder.glob("strategy_*.py"))
    if not st.get("variant") or not copies:
        raise JLError(f"{folder}: not a run of strategies\\jumplab.py#NAME")
    if want_sha and sha256(copies[0]) != want_sha:
        raise JLError(f"{folder}: its strategy file is not the declared strategies\\jumplab.py (sha256 "
                      f"{sha256(copies[0])[:16]} vs {want_sha[:16]})")
    eng = (st.get("picks") or {}).get("engines") or []
    if len(eng) != 1:
        raise JLError(f"{folder}: one engine per run (this one {eng})")
    if (s.get("compare") or {}).get("name") != "tree":
        raise JLError(f"{folder}: compared with {(s.get('compare') or {}).get('name')}, not the frozen tree")
    cg, dd = dec.get("cagr") or [np.nan, np.nan], dec.get("max_drawdown") or [np.nan, np.nan]
    return {"folder": folder.name, "engine": eng[0], "variant": st["variant"], "rule_verdict": dec.get("verdict"),
            "p": float(dec["p_one_sided"]) if dec.get("p_one_sided") is not None else np.nan,
            "cagr": cg[0], "cagr_tree": cg[1], "dd": dd[0], "dd_tree": dd[1]}


def cmd_holm(a) -> int:
    decl, sha = load_decl()
    want = decl["stage2_book"]["strategies_sha256"]
    folders = [Path(x) for x in a.folders]
    if a.scan:
        for f in sorted(Path(a.scan).glob("TLB_*")):
            sj = f / "summary.json"
            if sj.is_file():
                st = json.loads(sj.read_text(encoding="utf-8")).get("strategy") or {}
                if st.get("variant") and str(st.get("name", "")).startswith("jumplab_"):
                    folders.append(f)
    if not folders:
        raise JLError("no tl_backtest runs given (folders, or --scan <TRADELAB_OUT>\\backtest)")
    rows = [read_backtest(f, want) for f in folders]
    seen = {}
    for r in rows:
        k = (r["engine"], r["variant"])
        if k in seen:
            raise JLError(f"{r['variant']} on {r['engine']} appears twice ({seen[k]}, {r['folder']}): a declared test "
                          f"is run once - give the folders to use")
        seen[k] = r["folder"]
    H = holm(rows, decl["stage2_book"].get("holm_alpha", 0.025))
    want_n = len(VARIANTS)
    say(f"{VERSION} holm | declaration {sha[:16]} | {len(H)} runs")
    for eng in sorted({r["engine"] for r in H}):
        n_ = sum(1 for r in H if r["engine"] == eng)
        if n_ != want_n:
            say(f"NOTE: {eng} has {n_} of the {want_n} declared runs - the family is incomplete, verdicts provisional")
    say("engine | variant | rule | p (one-sided) | Holm limit | kept | FINAL | CAGR (tree) | worst DD (tree) | goal | run")
    for r in H:
        goal = (np.isfinite(r["dd"]) and r["dd"] >= -0.25 and np.isfinite(r["cagr"]) and np.isfinite(r["cagr_tree"])
                and r["cagr"] >= 0.7 * r["cagr_tree"])
        say(f"{r['engine']} | {r['variant']} | {r['rule_verdict']} | {r['p']:.4f} | {r['holm_limit']:.4f} | "
            f"{'yes' if r['holm_kept'] else 'no'} | {r['final']} | {r['cagr']:+.2%} ({r['cagr_tree']:+.2%}) | "
            f"{r['dd']:.2%} ({r['dd_tree']:.2%}) | {'MET' if goal else 'no'} | {r['folder']}")
    out = a.out or os.environ.get("JUMPLAB_OUT")
    if out:
        base = Path(out)
        base.mkdir(parents=True, exist_ok=True)
        with open(base / LEDGER, "a", encoding="utf-8") as f:
            f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "event": "holm",
                                "declaration_sha256": sha, "rows": H}, default=str) + "\n")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="jumplab: a meta model for the jumpy picks, and swing targets (JL1)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="the declaration and tradelab's strategies\\jumplab.py are the frozen ones")
    r = sub.add_parser("run", help="Stage 1: the walk-forward meta model and its skill")
    r.add_argument("--root")
    r.add_argument("--pm-run")
    r.add_argument("--out", default=None)
    r.add_argument("--stage-e-any", action="store_true")
    h = sub.add_parser("holm", help="Stage 2: Holm across each engine's tl_backtest runs of strategies\\jumplab.py")
    h.add_argument("folders", nargs="*")
    h.add_argument("--scan", default=None)
    h.add_argument("--out", default=None)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            want = d["stage2_book"]["strategies_sha256"]
            if not STRAT_FILE.is_file():
                raise JLError(f"{STRAT_FILE} not found (tradelab add-on v1.6 beside jumplab)")
            have = sha256(STRAT_FILE)
            if have != want:
                raise JLError(f"{STRAT_FILE} has sha256 {have[:16]}, not the declared {want[:16]} - refusing")
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['name']}, declared {d['declared']}): {len(VARIANTS)} Stage 2 "
                f"strategies per engine; strategies\\jumplab.py sha256 {have[:16]} as declared")
            return 0
        if a.cmd == "holm":
            return cmd_holm(a)
        return cmd_run(a)
    except (JLError, TC.TLError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
