"""
tests/test_jumplab.py - jumplab v1.0 (study JL1). Synthetic worlds only (tradelab's test world: daily and 3-minute bars,
pick_meta-style predictions for D and ENS ranks 1-10); ends with VERIFIED (jumplab v1.0).

  1 declaration  the frozen file loads with the 16 Stage 2 strategies; a changed copy is refused; check confirms
                 strategies\\jumplab.py and refuses a changed one
  2 lane         JUMPY by hand from s_atr14 and the year's cut-off (2020 uses 2021's; no ATR = jumpy; ETFs never)
  3 features     the daily features at a pick by hand from the bars; the intraday features by hand from the 3-minute file
  4 model        a year's model trains only on jumpy picks that exited 5 sessions before the year; refitted by hand it
                 gives the same scores and percentiles; jm_rand and the pick_meta re-exports by hand
  5 planted      labels with a planted effect (jumpy orderly falls end +4% higher, jumpy 5-day runners dip to -10%):
                 NET SKILL and DIP SKILL, the top 30% beats the rest, and sde5 / ret5 lead the importance
  6 absent       the same world with its own labels: no net skill
  7 outputs      hashed outputs; jm_scores has every pick once; stage2_commands / run_stage2.bat hold the 32 declared
                 backtests (CRLF) and Holm; the report leads with the verdict
  8 holm         Holm step-down and the drawdown goal by hand; a run listed twice, a foreign strategy file and a missing
                 --pm-run are refused

    python tests\\test_jumplab.py          (from the jumplab folder, after call env_jumplab.bat)
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

LAB = Path(__file__).resolve().parents[1]
TRADELAB = LAB.parent / "tradelab"
sys.path.insert(0, str(LAB))
sys.path.insert(0, str(TRADELAB))
sys.path.insert(0, str(TRADELAB / "tests"))
for _v in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "JUMPLAB_OUT", "TRADELAB_OUT"):
    os.environ.pop(_v, None)
import tl_world as W                                                 # noqa: E402

RESULTS = []


def check(cond, msg, detail=None):
    ok = bool(cond)
    RESULTS.append(ok)
    print(("  ok    " if ok else "  FAIL  ") + msg + ("" if ok or detail is None else f"   <- {str(detail)[:900]}"))


def quiet(fn, *a):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        rc = fn(*a)
    return rc, buf.getvalue()


def world(root: Path, seed: int):
    w = W.make_world(root, "absent", seed=seed, n_syms=20, n_days=500, with_special=False)
    P = pd.read_parquet(w["root"] / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    rng = np.random.default_rng(seed)
    P["s_atr14"] = rng.uniform(0.03, 0.08, len(P))           # about half the picks above the 2023 / 2024 cut-offs
    P.loc[rng.random(len(P)) < 0.03, "s_atr14"] = np.nan     # no ATR = jumpy
    P["prob_deep"] = rng.uniform(0, 0.5, len(P))
    P["pred_mae_q20"] = -rng.uniform(0.02, 0.1, len(P))
    W.rewrite_predictions(w["root"], P)
    W.use_mods(w["root"])
    return w, P


def run(JL, root, out):
    rc, log = quiet(JL.main, ["run", "--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any"])
    runs = sorted((Path(out) / "runs").glob("JL_*")) if (Path(out) / "runs").exists() else []
    return rc, log, (runs[-1] if runs else None)


def main() -> int:
    t0 = time.time()
    TMP = Path(tempfile.mkdtemp(prefix="jumplab_"))
    import jumplab as JL
    import tl_setups as SU
    import tl_data as TD
    # 1 declaration
    print("1. the declaration")
    d, sha = JL.load_decl()
    bad = TMP / "decl.json"
    bad.write_text(JL.DECL_FILE.read_text(encoding="utf-8").replace('"min_samples_leaf": 100', '"min_samples_leaf": 20'),
                   encoding="utf-8")
    try:
        JL.load_decl(bad)
        refused = False
    except JL.JLError as e:
        refused = "not the frozen declaration" in str(e)
    g1 = quiet(JL.main, ["check"])
    real = JL.STRAT_FILE
    alt = TMP / "strat.py"
    alt.write_text(real.read_text(encoding="utf-8") + "\n# changed\n", encoding="utf-8")
    JL.STRAT_FILE = alt
    g2 = quiet(JL.main, ["check"])
    JL.STRAT_FILE = real
    check(sha == JL.DECL_SHA and tuple(d["stage2_book"]["variants"]) == JL.VARIANTS and len(JL.VARIANTS) == 16 and
          refused and g1[0] == 0 and "as declared" in g1[1] and g2[0] == 2 and "not the declared" in g2[1],
          "the frozen declaration loads (16 Stage 2 strategies); a changed copy is refused; check confirms "
          "strategies\\jumplab.py and refuses a changed one", (g1[1][-300:], g2[1][-300:]))
    # 2 lane
    print("2. the lane")
    T = pd.DataFrame({"signal_day": pd.to_datetime(["2020-05-04", "2021-03-01", "2021-03-01", "2023-06-01", "2023-06-01",
                                                    "2024-02-01", "2027-01-05"]),
                      "symbol": ["AAA", "BBB", "GOLDBEES", "CCC", "LIQUID", "DDD", "EEE"]})
    cuts = d["picks"]["lane"]["cutoffs"]
    atr = np.array([cuts["2021"] + 0.001, cuts["2021"] - 0.001, 0.2, np.nan, 0.2, cuts["2024"], 0.2])
    ln = JL.lanes(T, atr, d, set())
    check(ln.tolist() == [1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
          "JUMPY by hand: above the year's cut-off (2020 uses 2021's), no ATR = jumpy, at the cut-off = calm, ETFs "
          "(name rule, the tree's names) never, a year without a cut-off never", ln.tolist())
    # 3-6 worlds
    print("3. features by hand (planted world)")
    w, P = world(TMP / "planted", 5)
    root = w["root"]
    prod = TD.Production(stage_e_any=True)
    mk = TD.Market(root, prod)
    Tp, _ = TD.load_picks(root, "PM_TEST_001", ["D", "ENS"], list(range(1, 11)))
    D = JL.build(root, "PM_TEST_001", d, True, log=lambda m_: None)
    X = D["X"]
    rows = Tp.sample(25, random_state=3).index
    bad_f = []
    for i in rows:
        sym = Tp.at[i, "symbol"]
        f_ = pd.read_parquet(root / f"{sym}_daily.parquet")
        dd_ = pd.to_datetime(f_["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
        j = int(np.flatnonzero(dd_.to_numpy() == np.datetime64(Tp.at[i, "signal_day"]))[0])
        o, h, l, c, v = (f_[k].to_numpy(float) for k in ("open", "high", "low", "close", "volume"))
        mv = np.diff(c[j - 5:j + 1])
        sde5 = (c[j] - c[j - 5]) / np.abs(mv).sum()
        clv = np.where(h - l > 0, ((c - l) - (h - c)) / (h - l), 0)[j - 4:j + 1].mean()
        pc = np.r_[np.nan, c[:-1]]
        tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
        atr14 = tr[j - 13:j + 1].mean()
        dhi = (c[j] - h[j - 19:j + 1].max()) / atr14
        r20 = np.log(c[j - 19:j + 1] / c[j - 20:j])
        upv = np.sqrt(2 * np.mean(np.where(r20 > 0, r20 ** 2, 0)))
        vr = v[j] / np.median(v[j - 50:j]) if j >= 50 else np.nan
        want = {"sde5": sde5, "ret5": c[j] / c[j - 5] - 1, "clv5": clv, "dist_hi20": dhi, "upvol20": upv,
                "vol_ratio1": vr, "gap1": o[j] / c[j - 1] - 1, "tr_ratio": tr[j] / atr14, "atrp": atr14 / c[j]}
        if j >= 253:
            want["atr_rank252"] = np.mean(np.array([tr[q - 13:q + 1].mean() / c[q] for q in range(j - 252, j)]) <= atr14 / c[j])
        for k, vv in want.items():
            if not (abs(X.at[i, k] - vv) <= 1e-9 * max(1, abs(vv)) or (np.isnan(X.at[i, k]) and np.isnan(vv))):
                bad_f.append((sym, k, X.at[i, k], vv))
    # intraday by hand for one pick with bars
    i3 = next(i for i in rows if X.at[i, "i_cov"] == 1.0)
    sym = Tp.at[i3, "symbol"]
    B3 = pd.read_parquet(root / "intraday_3m" / f"{sym}_3m.parquet")
    B3["day"] = pd.to_datetime(B3["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
    ds = mk.series(sym)
    jj = ds.idx(np.datetime64(Tp.at[i3, "signal_day"], "D"))
    up = dn = 0.0
    var = []
    for q in range(jj - 4, jj + 1):
        g = B3[B3["day"] == pd.Timestamp(ds.dates[q])].sort_values("timestamp")
        cl = g["close"].to_numpy(float)
        p = np.r_[g["open"].iloc[0], cl[4::5]]
        rr = np.diff(np.log(p))
        up += (rr[rr > 0] ** 2).sum()
        dn += (rr[rr < 0] ** 2).sum()
        var.append((rr ** 2).sum())
        if q == jj:
            lh = cl[-1] / cl[-21] - 1
    a14 = X.at[i3, "atrp"]
    check(not bad_f and abs(X.at[i3, "rsj_i5"] - (up - dn) / (up + dn)) < 1e-9 and
          abs(X.at[i3, "rv_i5"] - np.mean(var) / a14 ** 2) < 1e-9 * max(1, np.mean(var) / a14 ** 2) and
          abs(X.at[i3, "last_hour"] - lh) < 1e-12,
          "features by hand at 25 picks (sde5, ret5, clv5, dist_hi20, upvol20, vol_ratio1, gap1, tr_ratio, atrp, "
          "atr_rank252); the intraday features (rsj_i5, rv_i5 / atrp^2, last_hour) by hand from the 3-minute file",
          (bad_f[:4], X.loc[i3, ["rsj_i5", "rv_i5", "last_hour"]].tolist()))
    # plant labels: jumpy orderly falls (sde5 < -0.5) end +4% higher; jumpy 5-day runners (ret5 > +4%) dip to -10%
    print("4. the walk-forward model by hand")
    jm = D["jumpy"] == 1
    sde5 = X["sde5"].to_numpy(float)
    ret5 = X["ret5"].to_numpy(float)
    PP = P.copy()
    key = Tp.set_index("trade_id")
    PP["trade_id"] = [f"{e}-{pd.Timestamp(s_):%Y%m%d}-{r}" for e, s_, r in zip(PP["engine"], PP["signal_day"], PP["rank"])]
    plant_up = set(Tp.loc[jm & (sde5 < -0.5), "trade_id"])
    plant_dn = set(Tp.loc[jm & (ret5 > 0.04), "trade_id"])
    PP.loc[PP["trade_id"].isin(plant_up) & (PP["status"] == "ok"), "net"] += 0.04
    PP.loc[PP["trade_id"].isin(plant_dn), "mae"] = -0.10
    W.rewrite_predictions(root, PP.drop(columns=["trade_id"]))
    out = TMP / "outP"
    rc, log, rdir = run(JL, root, out)
    if rc != 0 or rdir is None:
        check(False, "planted run", log[-2500:])
        return finish(t0, TMP)
    J = pd.read_parquet(rdir / "jm_scores.parquet")
    meta = json.loads((rdir / "run.json").read_text())
    Tq, _ = TD.load_picks(root, "PM_TEST_001", ["D", "ENS"], list(range(1, 11)))
    D2 = JL.build(root, "PM_TEST_001", d, True, log=lambda m_: None)
    ok_, net_, dip_ = JL.labels(Tq)
    cal = D2["cal"]
    sd = pd.DatetimeIndex(Tq["signal_day"]).to_numpy().astype("datetime64[D]")
    ex = pd.to_datetime(Tq["exit_day_recorded"]).to_numpy().astype("datetime64[D]")
    gate = cal[int(np.searchsorted(cal, np.datetime64("2024-01-01", "D"))) - 5]
    tr = (D2["jumpy"] == 1) & ok_ & (ex < gate)
    te = (D2["jumpy"] == 1) & (sd >= np.datetime64("2024-01-01", "D"))
    Xv = D2["X"].to_numpy(float)
    use = np.isfinite(Xv[tr]).any(axis=0)
    mr, mc = JL._models(d)
    lo, hi = np.percentile(net_[tr], [1, 99])
    mr.fit(Xv[tr][:, use], np.clip(net_[tr], lo, hi))
    pn = mr.predict(Xv[te][:, use])
    fn = np.sort(mr.predict(Xv[tr][:, use]))
    Jt = J.set_index("trade_id").loc[Tq["trade_id"].to_numpy()]
    hand_rand = int(hashlib.sha256(str(Tq["trade_id"].iloc[7]).encode()).hexdigest()[:12], 16) / 16 ** 12
    lab = JL.labels(pd.DataFrame({"status_recorded": ["ok", "ok", "ok", "stuck"], "net_recorded": [0.01, -0.02, np.nan, 0.0],
                                  "mae_recorded": [-0.0799, -0.08, -0.2, -0.3]}))
    lab_ok = lab[0].tolist() == [True, True, False, False] and lab[2].tolist() == [0.0, 1.0, 1.0, 1.0]
    fit24 = next(f for f in meta["fits"] if f["year"] == 2024)
    check(fit24["train_rows"] == int(tr.sum()) and np.allclose(Jt["jm_net"].to_numpy()[te], pn) and
          np.allclose(Jt["jm_net_q"].to_numpy()[te], np.searchsorted(fn, pn, side="right") / len(fn)) and
          np.isnan(Jt["jm_net"].to_numpy()[~te]).all() and abs(Jt["jm_rand"].iloc[7] - hand_rand) < 1e-15 and
          np.allclose(Jt["jm_deep"].to_numpy(float), Tq["prob_deep"].to_numpy(float), equal_nan=True) and
          np.allclose(Jt["jm_up5"].to_numpy(float), Tq["prob_big"].to_numpy(float), equal_nan=True) and
          np.isnan(Jt["jm_mfe20"].to_numpy(float)).all() and "pred_mfe_q20" in meta["missing_pick_meta"] and
          ex[tr].max() < gate and lab_ok,
          "2024's model trains only on jumpy settled picks that exited 5 sessions before 2024; refitted by hand it gives "
          "the same scores and training percentiles; 2023 (no earlier year) and calm picks stay unscored; jm_rand by hand; "
          "pick_meta's forecasts re-exported as they are (a missing column blank and listed); labels by hand (only "
          "settled 'ok' trades train; a dip = MAE at or below -8%)",
          (fit24, int(tr.sum()), meta["missing_pick_meta"]))
    print("5. planted skill")
    ns, dsk, tp = meta["net_skill"], meta["dip_skill"], meta["top30"]
    imp = pd.read_csv(rdir / "importance.csv")
    check(ns["verdict"] == "NET SKILL" and ns["lo"] > 0 and dsk["verdict"] == "DIP SKILL" and tp["lo"] > 0 and
          set(imp["feature"].head(3)) & {"sde5", "sde3", "sde10"},
          f"planted: NET SKILL {ns['mean']:+.3f} [{ns['lo']:+.3f}, {ns['hi']:+.3f}], DIP SKILL AUC {dsk['auc']:.3f} "
          f"[{dsk['lo']:.3f}, {dsk['hi']:.3f}], the top 30% beats the rest by {tp['mean'] * 1e4:+.0f} bp "
          f"[{tp['lo'] * 1e4:+.0f}, {tp['hi'] * 1e4:+.0f}]; an SDE leads the importance", (ns, dsk, tp, imp.head(5)))
    print("6. absent")
    wA, PA = world(TMP / "absent", 9)
    rcA, logA, rA = run(JL, wA["root"], TMP / "outA")
    mA = json.loads((rA / "run.json").read_text()) if rA else {}
    check(rcA == 0 and mA.get("net_skill", {}).get("verdict") == "no net skill",
          "absent (the world's own labels): no net skill", (mA.get("net_skill"), logA[-500:]))
    print("7. outputs")
    names = {p.name for p in rdir.iterdir()}
    hashed = [ln.split("  ", 1)[1].strip() for ln in (rdir / "outputs.sha256").read_text().splitlines() if ln.strip()]
    bat = (rdir / "run_stage2.bat").read_bytes()
    cmds = (rdir / "stage2_commands.txt").read_text(encoding="utf-8").splitlines()
    rep = (rdir / "REPORT.md").read_text(encoding="utf-8")
    check(set(hashed) == names - {"outputs.sha256"} and J["trade_id"].is_unique and len(J) == len(Tq) and
          len(cmds) == 32 and all(f"#{v} " in " ".join(cmds) for v in JL.VARIANTS) and
          sum("--engines ENS" in c_ for c_ in cmds) == 16 and b"\r\n" in bat and b"\n" not in bat.replace(b"\r\n", b"") and
          bat.count(b"tl_backtest.py") == 32 and b"jumplab.py holm --scan" in bat and b"JUMPLAB_OUT=" in bat and
          rep.index("Verdict first") < rep.index("Stage 2") and (TMP / "outP" / JL.LEDGER).is_file(),
          "every output hashed; jm_scores holds every pick once; stage2_commands and run_stage2.bat (CRLF) hold the 32 "
          "declared backtests (16 x D, ENS) and Holm; the report leads with the verdict; ledger written",
          (sorted(names), len(cmds)))
    print("8. holm")
    H = JL.holm([{"engine": "D", "variant": v, "p": p, "rule_verdict": rv} for v, p, rv in
                 (("T1", 0.001, "PASS"), ("T2", 0.002, "PASS"), ("J1", 0.3, "PASS"), ("J2", 0.0015, "FAIL"))])
    hh = {r["variant"]: r for r in H}
    fk = TMP / "tlb"
    for nm, var, cg in (("TLB_1", "J1", 0.80), ("TLB_2", "J1", 0.80), ("TLB_3", "T1", 0.80), ("TLB_4", "J2", 0.60)):
        f_ = fk / nm
        f_.mkdir(parents=True)
        shutil.copy2(real, f_ / "strategy_jumplab.py")
        (f_ / "summary.json").write_text(json.dumps(
            {"strategy": {"name": f"jumplab_{var}", "variant": var, "picks": {"engines": ["D"]}}, "compare": {"name": "tree"},
             "decision": {"verdict": "PASS", "p_one_sided": 0.001, "cagr": [cg, 1.0], "max_drawdown": [-0.20, -0.29]}}))
    h1 = quiet(JL.main, ["holm", "--scan", str(fk)])
    shutil.rmtree(fk / "TLB_2")
    h2 = quiet(JL.main, ["holm", "--scan", str(fk)])
    (fk / "TLB_3" / "strategy_jumplab.py").write_text("STRATEGIES = {}\n")
    h3 = quiet(JL.main, ["holm", "--scan", str(fk)])
    g3 = quiet(JL.main, ["run", "--root", str(root), "--out", str(TMP / "x"), "--stage-e-any"])
    # D family of 4 sorted: T1 0.001 <= 0.025/4; J2 0.0015 <= 0.025/3 kept but its rule FAILs; T2 0.002 <= 0.0125; J1 0.3 no
    check(hh["T1"]["final"] == "PASS" and hh["T2"]["final"] == "PASS" and hh["J2"]["holm_kept"] and
          hh["J2"]["final"] == "FAIL" and hh["J1"]["final"] == "FAIL" and abs(hh["J1"]["holm_limit"] - 0.025) < 1e-12 and
          h1[0] == 2 and "appears twice" in h1[1] and h2[0] == 0 and
          any("| T1 |" in ln and "| MET |" in ln for ln in h2[1].splitlines()) and
          any("| J2 |" in ln and "| no |" in ln for ln in h2[1].splitlines()) and
          "has 3 of the 16 declared runs" in h2[1] and h3[0] == 2 and "not the declared" in h3[1] and
          g3[0] == 2 and "--pm-run is required" in g3[1],
          "Holm by hand (a kept test whose own rule fails still FAILS); the drawdown goal by hand (-20% with 80% of the "
          "tree's CAGR: MET; -20% with 60%: no); an incomplete family flagged; a run listed twice, a foreign strategy file and a "
          "missing --pm-run refused", [x[1][-300:] for x in (h1, h2, h3, g3)])
    return finish(t0, TMP)


def finish(t0, TMP) -> int:
    shutil.rmtree(TMP, ignore_errors=True)
    nf = RESULTS.count(False)
    print(f"{len(RESULTS)} checks, {nf} failures, {time.time() - t0:.0f} s, pandas {pd.__version__} / numpy {np.__version__}")
    if nf == 0:
        print("VERIFIED (jumplab v1.0)")
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
