# MANIFEST - vollab v1.0 (22 Nov 2026; m5tree and m5fair added 23 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\vollab` (a research folder beside `tradelab`, `setuplab`, `treelab` and `triggerlab`). Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\vollab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `vollab.py` | 59fbb6467f5e7a06 | 67751 |
| `VOLLAB_DECLARATION.json` | b96fa6a2439576bf | 13127 |
| `README_VOLLAB.md` | 4b96cab7917f9e23 | 6007 |
| `tests\test_vollab.py` | 41b8bdcc51447ef5 | 33098 |
| `tests\vl_world.py` | 0606e264d95840d5 | 12891 |
| `touchcheck.py` | a24ffb0bfbd738f5 | 10820 |
| `tests\test_touchcheck.py` | 9bd308df14553bcb | 7174 |
| `m5tree.py` | b975b167123f456c | 47162 |
| `M5TREE_DECLARATION.json` | 1d23294746b2504d | 8919 |
| `README_M5TREE.md` | f8b4c18523af6b95 | 8360 |
| `tests\test_m5tree.py` | 24d3458808d1e9f7 | 27187 |
| `tests\m5_world.py` | 855e2695e5bc2062 | 8933 |
| `m5fair.py` | 6dd4271d3038ab0b | 22239 |
| `M5FAIR_DECLARATION.json` | ba9020dde3014a34 | 4609 |
| `tests\test_m5fair.py` | 21b8f9ff433e1b94 | 18123 |
| `MANIFEST_VOLLAB.md` | this file | - |

Needs, read only, as sibling folders (versions checked at every start):
- triggerlab v1.0 (triggerlab.py sha16 a0342ef93421a11b: Universe, load_paths, frozen_trades, book_sim, the gate);
- treelab v1.0 (treelab.py sha16 64ac932f584fade1);
- setuplab v1.1 (setuplab.py sha16 9979d418aecec6de, with FROZEN_SETUPS.json and TREE.json);
- tradelab v1.3.1 (tl_data.py sha16 46ceff88fdadda7f, tl_common.py sha16 ad7e75715da7556a);
- through tradelab's env (env_tradelab.bat): stage_e_execution (the shipped v1.2), intraday_cache and stage_b_screen (ELIG_COL) from bigmove_deploy\open_close.

Declaration: `VOLLAB_DECLARATION.json`, internal sha256 `386a894ca68ca283...`. Declared at 2026-11-22 20:40 IST; amended 2026-11-22 22:05 IST. It is checked at every start against this code's settings, and an edited file is refused.

m5tree's declaration: `M5TREE_DECLARATION.json`, internal sha256 `433ef5a4e19f574c...`, declared at 2026-11-23 00:45 IST. Checked at every start against m5tree's settings; an edited file is refused.

m5fair's declaration: `M5FAIR_DECLARATION.json`, internal sha256 `71084f7dd1942aa1...`, declared at 2026-11-23 01:50 IST, after seeing m5tree's real result. Checked at every start (with m5tree's own declaration `433ef5a4e19f574c`); an edited file is refused.

Inputs:
- `%CACHE_DAILY_ROOT%\panel_oc\panel.parquet` (eligibility, the frozen setups' inputs);
- setuplab's watchlist folder (`C:\QuantData\setuplab\WL_R1_10`);
- the daily cache through stage E's loader; the 3-minute bars (`intraday_cache.store`).

## History
- v1.0 (22 Nov 2026): first build - the research report's Part 1 (stage A forecast race, stage B mappings S, T, R).
- touchcheck v1.0 (22 Nov 2026, 23:55): an add-on, run after vollab. It checks how accurate the +5% and +10% touch chances implied by M5 and by ATR14 are, on the tree's picks. Its measures are fixed in its header: Brier, skill, AUC, tenths, by year. `tests\test_touchcheck.py`: VERIFIED, 6 checks, both library versions.

- m5tree v1.0 (23 Nov 2026, 01:30): an add-on, run after vollab (reads its pick_forecasts.csv; no 3-minute pass). Part 1: the frozen tree with M5 in place of ATR14 (lanes and S1's dip), PASS = a daily gain with an interval above 0 and a worst fall no deeper; lane-only, S1-only and mix-matched lanes shown. Part 2: V1 every dip in M5 units, V2 + a normal-volume gate, V3 + halved dips after a stressed NIFTY close (Holm); V4 (skip the calmest fifth, snooped) and ALL shown.

- m5fair v1.0 (23 Nov 2026, 02:05): the like-for-like follow-up to m5tree's FAIL. F1 = M5 in ATR units against the frozen yearly cut-off (and as S1's ATR) is the one decision; ATRROLL (ATR14 on m5tree's 250-session rule), LANE and M5TREE shown; every tree averaged over 5 start days; path-free disagreement tables.

## Verified (synthetic data only)
`tests\test_vollab.py` ends `VERIFIED (vollab v1.0) - 37 checks` on Python 3.13 with pandas 3.0.5 + numpy 2.5.3 (about 155 s) and with pandas 2.3.3 + numpy 2.4.1 (about 190 s).
- the 3-minute measures by a bar-by-bar loop (sessions with bars missing too); the usability rule = tradelab's IntradayStore._judge;
- the target, ATR14, close-to-close, Yang-Zhang and the HAR averages by loops; GARCH's filter, forecast and fit (recovers a simulated (0.08, 0.90));
- the firewall: prices changed after a day leave every earlier forecast of all 9 models unchanged; the 5-session embargo on every refit;
- QLIKE and its interval by an explicit loop; decision A both ways;
- the book = triggerlab's book_sim, and a hand loop with multipliers and caps; the yearly restart;
- S's multipliers (mean exactly 1), T's exits on hand-built paths, R's flags by loop, the matched variance ratio and the touch table by hand;
- PLANTED world: REPLACE (a HAR model), S ADOPTED; PLANTED_T: T ADOPTED; PLANTED_R: R ADOPTED; ABSENT: S, T, R NOT ADOPTED;
- refusals: edited declaration, --out inside the cache, no eligibility column, too little 3-minute history, bars stamped at their end; --check-only writes nothing; outputs hash-checked.

`tests\test_m5tree.py` ends `VERIFIED (m5tree v1.0) - 18 checks` with pandas 3.0.5 + numpy 2.5.3 (about 55 s) and with pandas 2.3.3 + numpy 2.4.1 (about 60 s), on five synthetic worlds (daily bars):
- the window, the M5 cut-off, both lane rules, ATR14's yearly cut, S1's M5-ATR, V1's scale and V4's skip by a loop over every pick (two worlds, one with picks under the 100-pick minimum);
- S1's fill day (ATR14 and M5-ATR), V1's and V3's S3 and C1 fills, V2's volume ratios and gated C1 fills by loops over the watch days (setuplab's rule) from the worlds' own bars and panel;
- NIFTY's z and stress flag by a loop; the M5 tree's routing (open only when calm, ENS every calm pick, D the first calm up-open, every setup entry the earliest of the seven); V4 never trades the skipped picks;
- the gains and intervals by a loop over the 2,000 resamples, the one-sided p's, Holm, a year and worst fall by hand; the decision rules on hand-made rows;
- the identity (no forecasts = the frozen trades and books exactly); the frozen tree's returns = triggerlab's frozen trades through vollab's books;
- LANE world: M5TREE PASS; RULER: V1 PASS; VOLUME: V2 PASS, V1 FAIL; STRESS: V3 PASS and above V1; ABSENT: all four FAIL (also FAIL on three more seeds);
- refusals (no pick_forecasts.csv, no M5 column, --out inside the cache, an edited declaration); --check-only writes nothing; outputs hash-checked.

`tests\test_m5fair.py` ends `VERIFIED (m5fair v1.0) - 11 checks` with pandas 3.0.5 + numpy 2.5.3 (about 35 s) and with pandas 2.3.3 + numpy 2.4.1:
- every pick's lane under the four rules and the 250-session ATR14 cut-off by a loop; the 5-start account and each start's a year and worst fall by hand; the first start's accounts = m5tree v1.0's own;
- the five comparisons by a loop over the resamples; F1's verdict and the rule on hand-made rows; F1's and ATRROLL's routing (opens only when calm, ENS all calm, D the first calm up-open, setups the earliest fill);
- the path-free tables and jumpy shares by hand; the identity (no forecasts = the frozen 5-start account exactly);
- LANE world: F1 PASS; ABSENT world: F1 FAIL; refusals, --check-only, hashes, ledger, the report's sections.

**Mutation test:** 27 deliberate bugs, each in its own copy of vollab.py; every one makes the tests fail. The first run caught 17 of 26: 9 slipped past (a missing 3-minute bar not carried, the daily models left unscaled, and seven in stage B's decision: R's cap from the entry day's own close, R's percentile including today, the raw variance ratio, no Holm, no 3 bp margin, no worst-fall condition). Checks were added for each (sessions with missing bars, kappa per refit, R's cap and percentiles by loop, decision B by hand, the reported ratios and Holm p's rebuilt from the daily returns), and those 9 plus one more (the HAR flag's percentile including today) are now caught. The 17: the 15-minute grid, the subsampled grids' ends, bipower's pi/2, the target's overnight and length, the embargo, training on the test month, GARCH's missing-return rule, Yang-Zhang's k, the usability count and its open check, REPLACE on the point estimate, S's clip, T's gap fill and window, the book's slot release, the yearly restart, stage B's start.

**m5tree mutation test:** 25 deliberate bugs, each in its own copy of m5tree.py. The first run caught 23. Two slipped past: the 100-pick minimum dropped, and Part 2 judged at 0.05 instead of 0.025. Checks were added for each (the window on a world whose first weeks have under 100 forecast picks; the decision rules on hand-made rows), and both are now caught. The 23: the window including the signal day or 300 sessions long, the lane cut at the median, the mix quantile, the skip at the lane cut, the M5-ATR ratio upside down, S1's D1 not zero, the % dips unscaled, the gate at 2.0, the volume baseline or span shifted a day, the stress read from the watch day's own close, the stress doubling the dips, the stress median including today, V2/V3 sharing V1's fills, V4 skipping nothing, ENS on D's calm rule, closed instead of marked book values, the period a week late, plain instead of log returns, no Holm, M5TREE ignoring the worst fall, the trade lanes upside down.

**m5fair mutation test:** 15 deliberate bugs, each in its own copy of m5fair.py; all 15 caught on the first run (one start day, the 5-start mean misaligned, F1's lanes left frozen, ATRROLL keeping the yearly cut, the ATR window including the signal day or at its median, F1 without S1, the verdict ignoring the worst fall or judged on the estimate, a year = the best start, a comparison upside down, the routing table's open and setup swapped, LANE's cut at the mix quantile, the shares counting calm picks, the bootstrap over the wrong days).
