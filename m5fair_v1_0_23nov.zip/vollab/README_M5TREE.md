# m5tree v1.0 - the frozen tree with M5 in place of ATR14, plus new setups on M5

Your asks (22-23 Nov 2026): *"I want to know its impact on tree if we replace atr with m5. Detailed impact
analysis."* - then *"Go. And also look for new logical setups including m5."* - then *"Build"*.

It runs after vollab and reads that run's `pick_forecasts.csv`, so there is no new 3-minute pass. Every tree below
uses the same picks, the same prices and the same books (Rs 5 L each, 3 positions, 1/3 a slot, 0.35 a round trip,
D/ENS 50:50 restarted each January). Only the rules named change. The period runs from the first session of 2023 to
the end of the frozen trades.

## The window (point in time)

For a pick signalled on day t, the window is the tree's picks (D and ENS ranks 1-3) that have an M5 forecast and
were signalled in the 250 sessions before t. It needs at least 100 such picks; with fewer, the pick keeps ATR14
everywhere (as does a pick with no forecast).

## Part 1 - your question (one decision)

ATR14 enters the frozen tree in two places. M5TREE replaces both:
- **Lanes:** a pick is jumpy when its M5 sigma5 is above the window's 2/3 quantile.
- **S1's 1-ATR dip:** the ATR becomes M5 x (the window's median ATR14 / its median M5). The typical pick keeps its
  dip; a pick M5 sees as twice as jumpy needs twice the dip.

**PASS** needs both:
- the M5 tree's daily gain over the frozen tree has a 95% interval above 0 (day-block bootstrap);
- its worst fall is no deeper.

Otherwise FAIL, and the frozen tree stays.

**Example:** the window's median M5 is 6% and its 2/3 quantile 7.5%. A pick with M5 = 9% is jumpy. Its S1 needs a
dip of 1.5 typical ATRs, and V1 below makes its 3% dips need 4.5%.

**Shown with intervals, not judged:**
- LANE: the lanes only.
- S1M5: S1 only.
- LANEMIX: M5's ranking with the ATR rule's own jumpy share. This tells you whether a gain comes from M5 ranking the
  picks better or from simply having a different number of jumpy picks.

**The detail:**
- the lane confusion table: for each engine, ATR14's lane against M5's, with the picks' D1-open-to-D5-close net and
  the frozen setups' fill rate and net (so you see how the picks that switch lane actually did);
- lane switches by year;
- S1's fills gained, lost and moved;
- the trades actually taken: same entry, re-timed, added, dropped;
- each lane's trades, win %, average, average win and loss, payoff;
- per-year returns of every tree.

## Part 2 - new setups on M5 (from the research report; Holm over V1-V3)

Each is tested against the frozen tree.

- **V1 - every dip in M5 units.** S1 as above; S3, C1, C2 and N1's % dips are multiplied by M5 / the window's median
  M5. Reason: a 3% dip is a big shock for a quiet stock and noise for a wild one.
- **V2 - V1, only on normal volume.** A dip setup fills only if the dip days (D1 up to the day before the entry)
  traded at most 1.5 x the stock's median volume of its 20 sessions up to the signal day. Reason: on NSE, large
  moves on low volume reverse and on high volume continue (Parthasarathy 2019).
- **V3 - V1, wider when the market is stressed.** After a close where NIFTY's 5-session variance forecast is at least
  1.25 x its median over the previous 250 sessions, the five dip thresholds are halved. Reason: dip buyers are paid
  most when market volatility jumps (Nagel 2012).

**PASS** needs both:
- a Holm-adjusted one-sided p <= 0.025;
- a worst fall no deeper.

**Shown, not judged:**
- V4: skip picks whose M5 is in the window's bottom fifth. This was chosen after seeing vollab's stage B quintiles, so
  it is snooped.
- ALL: M5TREE + V1.
- V2 and V3 measured against V1 (what each gate adds).
- The research report's check: the frozen tree's trades by M5 quintile, including net per unit of sigma. If that is
  flat, M5 sizes the move but not the edge.

**Not tested here:**
- the bad-volatility (RSJ) filter, the overnight-share gap rule and the sector-residual reversal need a new 3-minute
  pass or a sector map;
- sigma stops are left out: they cost mean-reversion entries (Kaminski & Lo);
- the squeeze breakout is left out: its evidence is blog-grade.

## Run

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\vollab
python tests\test_m5tree.py
python m5tree.py --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --run C:\QuantData\vollab\VOLLAB_20261122_001 --out C:\QuantData\vollab --check-only
python m5tree.py --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --run C:\QuantData\vollab\VOLLAB_20261122_001 --out C:\QuantData\vollab
```

## What it writes (`C:\QuantData\vollab\M5TREE_<date>_<nnn>\`)

- `M5TREE.md`: the verdicts first, then every table.
- `m5tree_variants.csv`: every tree's a year, worst fall, CVaR, gain, interval, p's, verdict, trades and years.
- `m5tree_daily.csv`: each tree's daily returns, NIFTY's stress flag and z.
- `m5tree_trades.csv`: every tree's planned trades with lane, how, net and whether the book took it.
- `m5tree_picks.csv`: every pick in the period with both lanes, M5, the window's numbers, S1's fill days and the open
  and setup outcomes.
- `m5tree_tables.csv`: the report's tables.
- `M5TREE_RESULT.json`, `DECLARATION.json`, `RUN.json` and `outputs.sha256`; a line per run in `vollab_ledger.jsonl`.

## Safety gates (it refuses rather than guess)

- the declaration must be the shipped file;
- vollab, setuplab, treelab, triggerlab and tradelab must be the expected versions;
- the frozen setups' dips must be the declared five;
- the frozen tree must reproduce (triggerlab's gate);
- the picks' prices must match the cache;
- with no forecast at all, the M5 machinery must give the frozen trades exactly (the identity check);
- `--out` may not be inside the cache or a tool folder.

## Limits

- M5 was chosen in vollab on accuracy over these same months. That is a small head start for Part 1.
- The period is about 3 years 9 months, and the lockbox is spent. A PASS is a candidate for a forward paper book with
  its own freeze date, judged at its own month 6 and 12.
- Fills read daily bars, so queue position on an intraday limit is not modelled.

---

# m5fair v1.0 - the like-for-like follow-up (23 Nov 2026)

Your question on m5tree's FAIL: *"Is it even apple to apple?"* It wasn't, fully. m5tree's M5 lanes changed two
things at once:
- the volatility measure (M5 instead of ATR14);
- the cut-off rule (the last 250 sessions' top-3 picks instead of ATR14's yearly cut-off from every past pick).

The 250-session rule lagged: it called only about 20% of the 2025 picks jumpy, against ATR's 43-50%, and 2025 is
where the M5 tree lost. m5fair separates the two changes. Every tree is averaged over the first 5 sessions of 2023 as
start days, as TREE.json does.

| tree | what changes |
|---|---|
| F1 | M5 in ATR units (M5 x the window's median ATR14 / its median M5) against the frozen yearly cut-off, and as S1's ATR: the pure swap of measure |
| ATRROLL | ATR14 on m5tree's 250-session rule: the rule's own effect |
| LANE, M5TREE | m5tree's two trees again, now with 5 start days |

**The decision is F1 alone:**
- PASS needs its 5-start daily gain over the frozen tree to have a 95% interval above 0;
- and its mean worst fall over the 5 starts must be no deeper.

**Shown with intervals:**
- ATRROLL vs FROZEN: the rule, with ATR14 on both sides;
- LANE vs ATRROLL: the measure, with the 250-session rule on both sides;
- LANE and M5TREE vs FROZEN.

**Path-free (each pick's own outcomes, no books):**
- where each pair of rules disagrees;
- each rule's jumpy share by year.

**Designed after seeing m5tree's result.** A PASS earns a forward paper book only.

## Run

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\vollab
python tests\test_m5fair.py
python m5fair.py --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --run C:\QuantData\vollab\VOLLAB_20261122_001 --out C:\QuantData\vollab
```

It writes `C:\QuantData\vollab\M5FAIR_<date>_<nnn>\`:
- `M5FAIR.md`: the verdict first;
- `m5fair_trees.csv`, `m5fair_daily.csv` (each start's account and the 5-start mean), `m5fair_starts.csv`,
  `m5fair_picks.csv` (every pick's lane under each rule), `m5fair_tables.csv`;
- `M5FAIR_RESULT.json`, `DECLARATION.json`, `RUN.json`, `outputs.sha256`.
