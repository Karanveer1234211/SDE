"""
m5fair.py - m5fair v1.0 (beside m5tree v1.0): the like-for-like version of m5tree's Part 1. Does M5 make a better
ruler than ATR14 for the frozen tree when nothing else changes?

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\vollab
    python tests\\test_m5fair.py
    python m5fair.py --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --run C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn> --out C:\\QuantData\\vollab

Karan, 23 Nov 2026 01:30, on m5tree's FAIL: "Is it even apple to apple?" 01:40, on this plan: "Go".

m5tree v1.0 changed two things at once: the ruler (M5 for ATR14) and the cut-off rule (the last 250 sessions' top-3
picks for ATR14's yearly cut from every past pick). This test separates them, with every tree averaged over the first
5 sessions of 2023 as start days (TREE.json's way), all on m5tree's window, picks, prices and books.

  F1       M5 in ATR units everywhere: M5-ATR = sigma5 x (the window's median s_atr14 / its median sigma5), against
           the frozen yearly ATR14 cut-off (lanes) and as S1's ATR. THE DECISION: PASS when its 5-start daily gain
           over the frozen tree has a 95% interval above 0 AND its 5-start mean worst fall is no deeper.
  ATRROLL  ATR14 against the window's 2/3 quantile of s_atr14 (m5tree's 250-session rule, the same picks): shown
  LANE     m5tree's LANE (M5 against the window's 2/3 quantile of sigma5): shown
  M5TREE   m5tree's M5TREE (LANE + S1 in M5-ATR units): shown
  Shown with intervals: ATRROLL vs FROZEN (the 250-session rule, ATR14 on both), LANE vs ATRROLL (M5 for ATR14 on the
  250-session rule), LANE and M5TREE vs FROZEN (m5tree's results with 5 starts). Path-free: each pair's lane
  disagreements with the picks' own open and setup outcomes; the jumpy share of each rule by year.
Designed after seeing m5tree v1.0's result: a PASS earns a forward paper book only, not a production change.

Writes only M5FAIR_<date>_<nnn>\\ under --out and a line in vollab_ledger.jsonl. Research only.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import m5tree as M  # noqa: E402

VL, SU, TL, TG, TD, TC = M.VL, M.SU, M.TL, M.TG, M.TD, M.TC
VERSION = "m5fair v1.0"
NEEDS = {"m5tree": "m5tree v1.0"}
DECL_FILE = "M5FAIR_DECLARATION.json"
STARTS = 5
TREES = {"FROZEN": {"lane": "atr", "s1": False}, "F1": {"lane": "m5atr", "s1": True},
         "ATRROLL": {"lane": "atrroll", "s1": False}, "LANE": {"lane": "m5", "s1": False},
         "M5TREE": {"lane": "m5", "s1": True}}
WORDS = {"FROZEN": "the frozen tree (ATR14 against its yearly cut-off)",
         "F1": "M5 in ATR units against the frozen yearly cut-off, and as S1's ATR",
         "ATRROLL": "ATR14 against the 250-session rule",
         "LANE": "M5 against the 250-session rule (m5tree's LANE)",
         "M5TREE": "m5tree's M5TREE (LANE + S1 in M5-ATR units)"}
PAIRS = (("F1", "FROZEN", "the decision: M5 for ATR14, the frozen rule kept"),
         ("ATRROLL", "FROZEN", "the 250-session rule for the yearly cut, ATR14 on both"),
         ("LANE", "ATRROLL", "M5 for ATR14, the 250-session rule on both"),
         ("LANE", "FROZEN", "m5tree's LANE with 5 starts"),
         ("M5TREE", "FROZEN", "m5tree's M5TREE with 5 starts"))
LANE_RULES = ("atr", "m5atr", "atrroll", "m5")
LOG = M.LOG


class FairError(Exception):
    pass


def constants():
    return {"starts": STARTS, "trees": TREES, "pairs": [list(p[:2]) for p in PAIRS], "decided": "F1",
            "boot": [M.BOOT_B, M.BOOT_BLOCK, M.BOOT_SEED], "start": M.START, "q_lane": M.Q_LANE,
            "m5tree_declaration": "433ef5a4e19f574c"}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise FairError("no declaration at %s (it ships beside m5fair.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise FairError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file"
                        % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise FairError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def window_q_atr(d0, sig, atr):
    """Per pick: the 2/3 quantile of s_atr14 over m5tree's window population (picks with a forecast and an ATR whose
    signal day is one of the 250 sessions before), NaN under 100 picks."""
    n = len(d0)
    q = np.full(n, np.nan)
    with np.errstate(invalid="ignore"):
        pop = np.flatnonzero(np.isfinite(sig) & (sig > 0) & np.isfinite(atr) & (atr > 0))
    o = pop[np.argsort(d0[pop], kind="mergesort")]
    pd0 = d0[o]
    for d in np.unique(d0):
        a = np.searchsorted(pd0, d - M.WIN, side="left")
        b = np.searchsorted(pd0, d - 1, side="right")
        idx = o[a:b]
        if len(idx) >= M.WIN_MIN:
            q[d0 == d] = np.quantile(atr[idx], M.Q_LANE)
    return q


def lanes(I, kind, qatr):
    """(the value each Book row is compared with, its cut-off) under a lane rule; picks without M5 or a full window keep
    ATR14 against its yearly cut-off under every rule."""
    a, c = I.atr.copy(), I.cut_year.copy()
    ok, br = I.ok, I.br
    if kind == "m5":
        a[br[ok]] = I.sig[ok]
        c[br[ok]] = I.W["q23"][ok]
    elif kind == "m5atr":
        a = I.atr_s1.copy()
    elif kind == "atrroll":
        c[br[ok]] = qatr[ok]
    elif kind != "atr":
        raise FairError("lane rule %r" % kind)
    return a, c


def run_tree(G, name, qatr, cache):
    TS, U, PA, I, p0, t1 = G["TS"], G["U"], G["PA"], G["I"], G["p0"], G["t1"]
    spec = TREES[name]
    fills = M.variant_fills(TS, I, M.VARIANTS["M5TREE" if spec["s1"] else "FROZEN"], cache)
    a, c = lanes(I, spec["lane"], qatr)
    Ts = {}
    for e, calm in M.ENGINES:
        E = (TS["ED"] if e == "D" else TS["EE"]) if name == "FROZEN" else M.make_eng(TS, e, fills, a, c)
        Ts[e], _ = TG.frozen_trades(U, PA, TS["bk"], E, calm, TS["primary"])
    runs = []
    for s in range(p0, p0 + STARTS):
        B = {e: VL.book_sim2(Ts[e], PA.C, s, t1) for e, _ in M.ENGINES}
        r = VL.account_returns(B["D"][1], B["ENS"][1], TS["bk"].cal, s, t1)
        taken = sum(int(B[e][2][(Ts[e]["ent"] >= s) & (Ts[e]["ent"] <= t1)].sum()) for e, _ in M.ENGINES)
        runs.append({"start": s, "r": r, "taken": taken,
                     "exposure": float(np.mean(0.5 * B["D"][4] + 0.5 * B["ENS"][4]))})
    c0 = p0 + STARTS - 1
    rbar = np.mean([R["r"][c0 - R["start"]:] for R in runs], axis=0)
    return {"name": name, "fills": fills, "lane": M.lane_code(a, c), "Ts": Ts, "runs": runs, "rbar": rbar}


def summarise(V, cal, t1):
    per = []
    for R in V["runs"]:
        pn = VL.path_numbers(R["r"], cal[R["start"]:t1 + 1])
        per.append({"start": str(pd.Timestamp(cal[R["start"]]).date()), "a_year": pn["a_year"], "fall": pn["fall"],
                    "trades": R["taken"], "exposure": R["exposure"]})
    row = {"a_year": float(np.mean([p["a_year"] for p in per])), "fall": float(np.mean([p["fall"] for p in per])),
           "a_year_min": float(min(p["a_year"] for p in per)), "a_year_max": float(max(p["a_year"] for p in per)),
           "fall_min": float(min(p["fall"] for p in per)), "fall_max": float(max(p["fall"] for p in per)),
           "trades": float(np.mean([p["trades"] for p in per])),
           "exposure": float(np.mean([p["exposure"] for p in per]))}
    return row, per


def decide(row_f1, fz):
    ok = bool(np.isfinite(row_f1["diff_lo"]) and row_f1["diff_lo"] > 0 and row_f1["fall"] <= fz["fall"])
    return "PASS" if ok else "FAIL"


def routing(PF, la, lb, na, nb):
    """Path-free: picks by (rule a's lane, rule b's lane), with their D1-open-to-D5-close net and the earliest frozen
    setup's fill rate and net (m5tree's pick table)."""
    rows = []
    for e in ("D", "ENS", "both"):
        m = np.ones(len(PF), bool) if e == "both" else (PF["engine"] == e).to_numpy()
        for x in (0, 1):
            for y in (0, 1):
                g = m & (la == x) & (lb == y)
                on = M.net_stats(PF.loc[g, "open_net"])
                st = M.net_stats(PF.loc[g, "setup7_net"])
                rows.append({"pair": "%s vs %s" % (na, nb), "engine": e, na: "jumpy" if x else "calm",
                             nb: "jumpy" if y else "calm", "picks": int(g.sum()), "open_net_avg": on["avg"],
                             "open_win_pct": on["win_pct"],
                             "setup_fill_pct": float(100 * (PF.loc[g, "setup7_day"] > 0).mean()) if g.any() else np.nan,
                             "setup_net_avg": st["avg"], "setup_win_pct": st["win_pct"]})
    return pd.DataFrame(rows)


def write_report(d, info, R):
    rows, fz = R["rows"], R["rows"]["FROZEN"]
    f1 = rows["F1"]
    years = sorted(R["years"]["FROZEN"])
    L = ["# %s - M5 against ATR14 like for like" % VERSION, "",
         "%s .. %s (%d sessions: every tree averaged over %d start days, %s .. %s); vollab run %s; declaration %s. "
         "m5tree's window, picks, prices and books." % (info["from"], info["to"], info["days"], STARTS,
                                                       info["starts"][0], info["starts"][-1], info["vollab_run"],
                                                       info["declaration_sha256"][:16]), "",
         "## Verdict", "",
         "**F1 - M5 in ATR units for ATR14, the frozen rule kept: %s.** Its daily gain over the frozen tree is %s bp a "
         "day %s; a year %s%% vs %s%% (mean of 5 starts); worst fall %s%% vs %s%%." % (
             f1["verdict"], M._p(f1["diff"]), M._ci(f1["diff_lo"], f1["diff_hi"]), M._p(f1["a_year"]),
             M._p(fz["a_year"]), M._p(f1["fall"], 2, False), M._p(fz["fall"], 2, False)),
         "PASS needs the interval above 0 and a mean worst fall no deeper. Designed after seeing m5tree v1.0: a PASS "
         "is a candidate for a forward paper book only.", "", "## What each change does (5 starts, paired days)", "",
         "| comparison | what it isolates | gain, bp a day | one-sided p |", "|---|---|---|---|"]
    for a, b, w in PAIRS:
        c = R["pairs"]["%s vs %s" % (a, b)]
        L.append("| %s vs %s | %s | %s %s | %s |" % (a, b, w, M._p(c["diff"]), M._ci(c["diff_lo"], c["diff_hi"]),
                                                    M._p(c["p_one"], 4, False)))
    L += ["", "## Every tree", "",
          "| tree | what | a year (mean of 5 starts) | range | worst fall (mean) | range | trades | exposure |",
          "|---|---|---|---|---|---|---|---|"]
    for v in TREES:
        r = rows[v]
        L.append("| %s | %s | %s%% | %s .. %s | %.2f%% | %.2f .. %.2f | %.0f | %.2f |" % (
            v, WORDS[v], M._p(r["a_year"]), M._p(r["a_year_min"]), M._p(r["a_year_max"]), r["fall"], r["fall_min"],
            r["fall_max"], r["trades"], r["exposure"]))
    L += ["", "Per year, the 5-start account (%):", "", "| tree | " + " | ".join(str(y) for y in years) + " |",
          "|---|" + "---|" * len(years)]
    for v in TREES:
        L.append("| %s | " % v + " | ".join(M._p(R["years"][v][y]) for y in years) + " |")
    L += ["", "## Jumpy share of each lane rule (engine picks entering in the period)", ""]
    L += M._md(R["shares"], ["year", "engine", "picks", "atr", "m5atr", "atrroll", "m5"],
               {k: M._f(1, pct=True) for k in ("atr", "m5atr", "atrroll", "m5")})
    L += ["", "atr = ATR14 against its yearly cut-off (frozen); m5atr = F1's; atrroll = ATR14 against the 250-session "
          "rule; m5 = M5 against the 250-session rule.", "", "## Where the lanes disagree (path-free)", "",
          "Each pick's own outcomes, whatever the books did: open net = bought at the D1 open, sold at the D5 close; "
          "setup = the earliest of the 7 frozen setups (its primary exit).", ""]
    for nm, T in R["routing"].items():
        L += ["### %s" % nm, ""]
        cols = [c for c in T.columns if c not in ("pair",)]
        L += M._md(T, cols, {"open_net_avg": M._f(2, True), "open_win_pct": M._f(1), "setup_fill_pct": M._f(1),
                             "setup_net_avg": M._f(2, True), "setup_win_pct": M._f(1)})
        L.append("")
    L += ["## Each start day", ""]
    L += M._md(R["per_start"], ["tree", "start", "a_year", "fall", "trades", "exposure"],
               {"a_year": M._f(2, True, True), "fall": M._f(2, False, True), "exposure": M._f(2)})
    L += ["", "## Read this", "",
          "- m5fair was designed after m5tree v1.0's FAIL showed its lane rule changing the cut-off method as well as "
          "the ruler. A PASS here earns a forward paper book, not a production change.",
          "- M5 was chosen in vollab on forecast accuracy over these same months; the frozen tree's ATR14 lanes and "
          "setups were drawn on 2020-26 data (in sample here).", "", "## Checks", ""] + [
        "- %s: %s" % kv for kv in info["checks"].items()]
    (d / "M5FAIR.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def run(a, log=LOG):
    t0 = time.time()
    dp, ddoc = load_declaration()
    if M.VERSION != NEEDS["m5tree"]:
        raise FairError("needs %s beside this file (found %s)" % (NEEDS["m5tree"], M.VERSION))
    G = M.prepare(a, log)
    if G["ddoc"]["sha256"][:16] != constants()["m5tree_declaration"]:
        raise FairError("m5tree's declaration is not the one this test was declared on (%s)" % G["ddoc"]["sha256"][:16])
    TS, U, PA, I, p0, t1 = G["TS"], G["U"], G["PA"], G["I"], G["p0"], G["t1"]
    bk = TS["bk"]
    checks = dict(G["checks"])
    for k_, v_ in checks.items():
        log(" %s: %s" % (k_, v_))
    if getattr(a, "check_only", False):
        log("CHECK OK - the frozen tree reproduced, %d picks matched, %d with M5; nothing computed or written." % (
            U.n, G["finfo"]["picks_matched"]))
        return None
    if p0 + STARTS - 1 >= t1:
        raise FairError("too few sessions after %s" % M.START)
    qatr = window_q_atr(I.d0, I.sig, I.atr[U.br])
    # identity: without forecasts every rule is the frozen one
    Iid = M.Inputs(TS, U, np.full(U.nu, np.nan), G["rv_u"], G["stress_bk"])
    Gid = dict(G, I=Iid)
    qid = window_q_atr(Iid.d0, Iid.sig, Iid.atr[U.br])
    cache = {}
    Vs = {"FROZEN": run_tree(G, "FROZEN", qatr, cache)}
    for nm in ("F1", "ATRROLL"):
        Vi = run_tree(Gid, nm, qid, {})
        if not np.array_equal(Vi["rbar"], Vs["FROZEN"]["rbar"]):
            raise FairError("%s without forecasts does not reproduce the frozen tree - send Claude this line" % nm)
    checks["identity"] = "without forecasts F1 and ATRROLL reproduce the frozen tree's 5-start account exactly"
    for nm in ("F1", "ATRROLL", "LANE", "M5TREE"):
        Vs[nm] = run_tree(G, nm, qatr, cache)
    c0 = p0 + STARTS - 1
    days = bk.cal[c0:t1 + 1]
    B_ = SU.Boot(days, B=M.BOOT_B, block=M.BOOT_BLOCK, seed=M.BOOT_SEED)
    rows, per_rows, years = {}, [], {}
    yr = pd.DatetimeIndex(days).year.to_numpy()
    for nm, V in Vs.items():
        rows[nm], per = summarise(V, bk.cal, t1)
        for p in per:
            per_rows.append(dict(tree=nm, **p))
        years[nm] = {int(y): float((np.prod(1 + V["rbar"][yr == y]) - 1) * 100) for y in sorted(set(yr))}
    pairs = {}
    for x, y, _ in PAIRS:
        est, lo, hi, sd, p = M.compare(B_, Vs[x]["rbar"], Vs[y]["rbar"])
        pairs["%s vs %s" % (x, y)] = {"diff": est, "diff_lo": lo, "diff_hi": hi, "p_one": p}
    rows["F1"].update(pairs["F1 vs FROZEN"])
    rows["F1"]["verdict"] = decide(rows["F1"], rows["FROZEN"])
    for nm in rows:
        if nm != "F1":
            rows[nm]["verdict"] = "-" if nm == "FROZEN" else "shown only"
    # ---- path-free tables
    Vt = M.run_variant(TS, U, PA, I, "M5TREE", cache, p0, t1)
    PF = M.pick_frame(TS, U, PA, I, {"M5TREE": Vt}, p0, t1)
    pm = (U.i1 >= p0) & (U.i1 <= t1)
    br = U.br[pm]
    L = {}
    for k in LANE_RULES:
        lc = M.lane_code(*lanes(I, k, qatr))[br]
        L[k] = lc
        PF["lane_" + k] = lc
    PF["atr_cut_roll"] = qatr[pm]
    sh = []
    yrs = pd.DatetimeIndex(PF["signal_day"]).year.to_numpy()
    for y in sorted(set(yrs)):
        for e in ("D", "ENS"):
            g = (yrs == y) & (PF["engine"] == e).to_numpy()
            sh.append(dict(year=int(y), engine=e, picks=int(g.sum()),
                           **{k: float(100 * (L[k][g] == 1).mean()) if g.any() else np.nan for k in LANE_RULES}))
    routes = {"F1 vs FROZEN": routing(PF, L["m5atr"], L["atr"], "F1", "FROZEN"),
              "ATRROLL vs FROZEN": routing(PF, L["atrroll"], L["atr"], "ATRROLL", "FROZEN"),
              "LANE vs ATRROLL": routing(PF, L["m5"], L["atrroll"], "LANE", "ATRROLL")}
    R = {"rows": rows, "pairs": pairs, "years": years, "shares": pd.DataFrame(sh), "routing": routes,
         "per_start": pd.DataFrame(per_rows)}
    info = {"from": str(pd.Timestamp(days[0]).date()), "to": str(pd.Timestamp(days[-1]).date()), "days": len(days),
            "starts": [str(pd.Timestamp(bk.cal[s]).date()) for s in range(p0, p0 + STARTS)],
            "vollab_run": G["rd"].name, "declaration_sha256": ddoc["sha256"]}
    checks["period"] = "%s .. %s, %d sessions, each tree the mean of %d accounts started on %s" % (
        info["from"], info["to"], len(days), STARTS, ", ".join(info["starts"]))
    checks["window"] = "M5 (and the 250-session rule) used on %d of %d engine picks entering from %s" % (
        int(I.ok[pm].sum()), int(pm.sum()), str(pd.Timestamp(bk.cal[p0]).date()))
    # ---- outputs
    out, rd = G["out"], G["rd"]
    d = SU.new_run_dir(out, "M5FAIR")
    VL.ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                    "tool": VERSION, "declaration_sha256": ddoc["sha256"], "vollab_run": rd.name})
    files = ["m5fair_trees.csv", "m5fair_daily.csv", "m5fair_picks.csv", "m5fair_tables.csv", "m5fair_starts.csv"]
    pd.DataFrame([dict(tree=k, what=WORDS[k], **v) for k, v in rows.items()]).to_csv(d / files[0], index=False)
    alld = bk.cal[p0:t1 + 1]
    daily = {"date": pd.DatetimeIndex(alld).date}
    for nm, V in Vs.items():
        daily["r_" + nm] = np.r_[np.full(c0 - p0, np.nan), V["rbar"]]       # the 5-start account, from the 5th start
        for R_ in V["runs"]:
            daily["r_%s_s%d" % (nm, R_["start"] - p0 + 1)] = np.r_[np.full(R_["start"] - p0, np.nan), R_["r"]]
    pd.DataFrame(daily).to_csv(d / files[1], index=False, float_format="%.12g")
    PF.to_csv(d / files[2], index=False, float_format="%.12g")
    tabs = [R["shares"].assign(table="shares")] + [t.assign(table="routing") for t in routes.values()] + [
        pd.DataFrame([dict(pair=k, **v) for k, v in pairs.items()]).assign(table="pairs")]
    pd.concat(tabs, ignore_index=True).to_csv(d / files[3], index=False, float_format="%.12g")
    R["per_start"].to_csv(d / files[4], index=False, float_format="%.12g")
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info["checks"] = checks
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": ddoc["sha256"], "vollab_run": rd.name, "period": [info["from"], info["to"]],
              "starts": info["starts"], "trees": rows, "pairs": pairs, "decision": {"F1": rows["F1"]["verdict"]}}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "M5FAIR_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    write_report(d, info, R)
    (d / "RUN.json").write_text(json.dumps({"version": VERSION, "root": str(G["root"]), "panel": str(G["panel"]),
                                            "data": str(a.data), "run": str(rd), "checks": checks}, indent=1,
                                           default=str), encoding="utf-8")
    files += ["M5FAIR_RESULT.json", "DECLARATION.json", "M5FAIR.md", "RUN.json"]
    SU.write_hashes(d, files)
    VL.ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                    "decision": result["decision"], "minutes": round((time.time() - t0) / 60, 1)})
    log("M5FAIR WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    f1 = rows["F1"]
    log(" F1 (M5 for ATR14, the frozen rule kept): %s (%s bp a day %s; a year %s%% vs %s%%; worst fall %.2f%% vs "
        "%.2f%%; 5 starts)" % (f1["verdict"], M._p(f1["diff"]), M._ci(f1["diff_lo"], f1["diff_hi"]),
                               M._p(f1["a_year"]), M._p(rows["FROZEN"]["a_year"]), f1["fall"], rows["FROZEN"]["fall"]))
    for x, y, w in PAIRS[1:]:
        c = pairs["%s vs %s" % (x, y)]
        log(" %s vs %s (%s): %s bp a day %s" % (x, y, w, M._p(c["diff"]), M._ci(c["diff_lo"], c["diff_hi"])))
    return d


def main(argv=None):
    ap = argparse.ArgumentParser(prog="m5fair", description=VERSION)
    ap.add_argument("--root", required=True, help="the cache root (%%CACHE_DAILY_ROOT%%)")
    ap.add_argument("--data", required=True, help="setuplab's watchlist folder (C:\\QuantData\\setuplab\\WL_R1_10)")
    ap.add_argument("--run", required=True, help="the vollab run folder (C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn>)")
    ap.add_argument("--out", required=True, help="the output folder (C:\\QuantData\\vollab)")
    ap.add_argument("--panel", help="panel_oc's panel.parquet (default: <root>\\panel_oc\\panel.parquet)")
    ap.add_argument("--check-only", dest="check_only", action="store_true", help="check the inputs, write nothing")
    ap.add_argument("--stage-e-any", dest="stage_e_any", action="store_true",
                    help="accept a stage_e_execution.py that is not the shipped v1.2")
    a = ap.parse_args(argv)
    try:
        run(a)
    except (FairError, M.M5Error, VL.VLError, TG.TGError, TL.TLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
