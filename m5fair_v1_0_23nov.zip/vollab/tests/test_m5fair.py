"""
tests for m5fair v1.0 - synthetic worlds (tests/m5_world.py) run through m5fair (and m5tree for the cross-check); the
rules rebuilt by hand. Ends with  VERIFIED (m5fair v1.0)  or  FAILED.
  t1  every pick's lane under the four rules (ATR14 yearly, F1's M5-ATR, ATR14 on the 250-session rule, M5 on it) and
      the 250-session ATR14 cut-off, by a loop over the picks and their windows
  t2  the 5-start account: the mean of the 5 accounts' daily returns; each start's a year and worst fall by hand; the
      trees' means and ranges
  t3  each start-1 account = m5tree v1.0's own account for FROZEN, LANE and M5TREE on the same world
  t4  the five comparisons and their intervals by a loop over the 2,000 resamples; F1's verdict; the rule on
      hand-made rows
  t5  F1's routing: opens only when F1 calls the pick calm, ENS every calm pick, D the first calm up-open, every
      setup entry the earliest of the seven fills with S1 on the M5-ATR; ATRROLL's on the frozen fills
  t6  the path-free tables (F1 vs FROZEN, LANE vs ATRROLL) and the jumpy shares by hand from the pick table
  t7  the identity: without forecasts F1 and ATRROLL give the frozen 5-start account exactly
  t8  LANE world: F1 PASS; ABSENT world: F1 FAIL
  t9  refusals (no pick_forecasts.csv, --out inside the cache, an edited declaration), --check-only writes nothing,
      the outputs' hashes, the ledger, the report's sections
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import m5fair as F  # noqa: E402
import m5_world as MW  # noqa: E402
import test_m5tree as TT  # noqa: E402

M, VL, SU = F.M, F.VL, F.SU
FAILS, N_OK = [], [0]
SEED = 31


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)


same = TT.same


def world(tmp, kind, with_tree=False):
    root, data, run, W = MW.make_world(tmp / kind, SEED, kind, SU=SU,
                                       sig_from="2022-12-15" if kind == "lane" else "2022-10-01")
    out = tmp / kind / "out"
    with redirect_stdout(io.StringIO()) as buf:
        rc = F.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(out), "--stage-e-any"])
        if with_tree:
            M.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(tmp / kind / "tree"),
                    "--stage-e-any"])
    d = sorted(out.glob("M5FAIR_*"))
    t = sorted((tmp / kind / "tree").glob("M5TREE_*")) if with_tree else []
    return {"root": root, "data": data, "run": run, "W": W, "out": out, "rc": rc, "d": d[-1] if d else None,
            "tree": t[-1] if t else None, "log": buf.getvalue()}


def main():
    print("%s self-test (pandas %s, numpy %s)" % (F.VERSION, pd.__version__, np.__version__))
    tmp = Path(tempfile.mkdtemp(prefix="m5fair_test_"))
    try:
        Wd = {"lane": world(tmp, "lane", True), "absent": world(tmp, "absent")}
        bad = [k for k, w in Wd.items() if w["rc"] != 0 or w["d"] is None]
        if bad or Wd["lane"]["tree"] is None:
            for k in Wd:
                print(Wd[k]["log"][-2500:])
            check(False, "m5fair (and m5tree) run on the worlds (failed: %s)" % bad)
            return 1
        w = Wd["lane"]
        d = w["d"]
        P = pd.read_csv(d / "m5fair_picks.csv", parse_dates=["signal_day"])
        D = pd.read_csv(d / "m5fair_daily.csv", parse_dates=["date"])
        Tr = pd.read_csv(d / "m5fair_trees.csv").set_index("tree")
        St = pd.read_csv(d / "m5fair_starts.csv")
        Tb = pd.read_csv(d / "m5fair_tables.csv")
        cal = pd.DatetimeIndex(w["W"]["cal"])
        # ------------------------------------------------------------------ t1 the four lane rules
        wl = pd.read_parquet(w["data"] / "watchlist.parquet")
        wl["signal_day"] = pd.to_datetime(wl["signal_day"])
        Fc = pd.read_csv(w["run"] / "pick_forecasts.csv", parse_dates=["signal_day"])
        fc = {(s, x): v for s, x, v in zip(Fc["symbol"], Fc["signal_day"], Fc["sigma5_M5_pct"])}
        cuts = TT.hand_cuts(wl)
        HW = TT.hand_window(wl, fc, cal, cuts)
        cpos = {x: i for i, x in enumerate(cal)}
        E = wl[wl["engine"].isin(["D", "ENS"]) & (wl["rank"] <= 3) & (wl["symbol"] != "LIQUIDBEES") &
               (wl["signal_day"] >= pd.Timestamp("2021-01-01"))].copy()
        E["d0"] = E["signal_day"].map(cpos)
        E["sig"] = [fc.get((s, x), np.nan) for s, x in zip(E["symbol"], E["signal_day"])]
        pop = E[np.isfinite(E["sig"]) & (E["sig"] > 0) & (E["s_atr14"] > 0)]
        nb = 0
        hand = {}
        for r in P.itertuples():
            n, q23, q20, ms, ma, sh, qm, sg, at, cut = HW[r.trade_id]
            d0 = cpos[r.signal_day]
            wv = pop[(pop["d0"] >= d0 - 250) & (pop["d0"] <= d0 - 1)]
            qa = np.quantile(wv["s_atr14"], 2 / 3) if len(wv) >= 100 else np.nan
            used = bool(np.isfinite(sg) and n >= 100)
            la = int(at > cut)
            lf = int(sg * ma / ms > cut) if used else la
            lr = int(at > qa) if used else la
            lm = int(sg > q23) if used else la
            hand[r.trade_id] = (la, lf, lr, lm)
            nb += not (r.lane_atr == la and r.lane_m5atr == lf and r.lane_atrroll == lr and r.lane_m5 == lm and
                       same(r.atr_cut_roll, qa))
        diff = {k: int((P["lane_" + k] != P["lane_atr"]).sum()) for k in ("m5atr", "atrroll", "m5")}
        check(nb == 0 and len(P) > 3000 and min(diff.values()) > 20,
              "t1 every pick's lane under the four rules and the 250-session ATR14 cut-off by a loop over %d picks "
              "(%d off; picks off the frozen lane: F1 %d, ATRROLL %d, LANE %d)" % (len(P), nb, diff["m5atr"],
                                                                                  diff["atrroll"], diff["m5"]))
        # ------------------------------------------------------------------ t2 the 5-start account
        c0i = 4
        ok2 = True
        for t in F.TREES:
            S = np.column_stack([D["r_%s_s%d" % (t, k)].to_numpy() for k in range(1, 6)])
            ok2 &= same(D["r_" + t].to_numpy()[c0i:], S[c0i:].mean(1), 1e-10)
            ok2 &= bool(np.isnan(D["r_" + t].to_numpy()[:c0i]).all())
            ay, fl = [], []
            for k in range(5):
                rr = S[k:, k]
                v = np.r_[1.0, np.cumprod(1 + rr)]
                yrs = (D["date"].iloc[-1] - D["date"].iloc[k]).days / 365.25
                ay.append((v[-1] ** (1 / yrs) - 1) * 100)
                fl.append(100 * np.max(1 - v / np.maximum.accumulate(v)))
                ok2 &= bool(np.isnan(S[:k, k]).all())
            s_ = St[St["tree"] == t]
            ok2 &= same(s_["a_year"], ay, 1e-9) and same(s_["fall"], fl, 1e-9)
            ok2 &= same([Tr.at[t, "a_year"], Tr.at[t, "fall"], Tr.at[t, "a_year_min"], Tr.at[t, "fall_max"]],
                        [np.mean(ay), np.mean(fl), min(ay), max(fl)], 1e-9)
        check(ok2, "t2 each tree's account = the mean of its 5 start-day accounts from the 5th start; each start's a "
                   "year and worst fall by hand; the trees' means and ranges")
        # ------------------------------------------------------------------ t3 start 1 = m5tree's own accounts
        Dt = pd.read_csv(w["tree"] / "m5tree_daily.csv", parse_dates=["date"])
        ok3 = bool((Dt["date"].to_numpy() == D["date"].to_numpy()).all())
        for t in ("FROZEN", "LANE", "M5TREE"):
            ok3 &= same(D["r_%s_s1" % t], Dt["r_" + t], 1e-10)
        check(ok3, "t3 the first start day's FROZEN, LANE and M5TREE accounts = m5tree v1.0's own on the same world")
        # ------------------------------------------------------------------ t4 the comparisons by hand
        DD = D.iloc[c0i:]
        days = DD["date"].to_numpy().astype("datetime64[ns]")
        B_ = SU.Boot(days, B=2000, block=10, seed=7)
        pairs = Tb[Tb["table"] == "pairs"].set_index("pair")
        ok4 = True
        for x, y, _ in F.PAIRS:
            v = (np.log1p(DD["r_" + x].to_numpy()) - np.log1p(DD["r_" + y].to_numpy())) * 1e4
            ms = np.array([v[ix].mean() for ix in B_.ix])
            lo, hi = np.percentile(ms, [2.5, 97.5])
            p = 1 - 0.5 * (1 + math.erf(v.mean() / ms.std(ddof=1) / math.sqrt(2)))
            k = "%s vs %s" % (x, y)
            ok4 &= same(pairs.loc[k, ["diff", "diff_lo", "diff_hi", "p_one"]].to_numpy(float), [v.mean(), lo, hi, p],
                        1e-9)
        f1 = Tr.loc["F1"]
        ok4 &= f1["verdict"] == ("PASS" if (f1["diff_lo"] > 0 and f1["fall"] <= Tr.at["FROZEN", "fall"]) else "FAIL")
        ok4 &= all(Tr.at[t, "verdict"] == "shown only" for t in ("ATRROLL", "LANE", "M5TREE"))
        rules = [F.decide({"diff_lo": 0.1, "fall": 20.0}, {"fall": 20.0}),
                 F.decide({"diff_lo": 0.1, "fall": 20.01}, {"fall": 20.0}),
                 F.decide({"diff_lo": -0.01, "fall": 10.0}, {"fall": 20.0}),
                 F.decide({"diff_lo": np.nan, "fall": 10.0}, {"fall": 20.0})]
        check(ok4 and rules == ["PASS", "FAIL", "FAIL", "FAIL"],
              "t4 the five comparisons, their intervals (a loop over the 2,000 resamples) and one-sided p's by hand; "
              "F1's verdict; the rule on hand-made rows")
        # ------------------------------------------------------------------ t5 F1's and ATRROLL's routing
        G = M.prepare(TT.args(w["root"], w["data"], w["run"], tmp / "prep"), log=lambda *x: None)
        I = G["I"]
        qatr = F.window_q_atr(I.d0, I.sig, I.atr[G["U"].br])
        bk = G["TS"]["bk"]
        rowof = {t_: i for i, t_ in enumerate(bk.ids)}
        Pm = P.set_index("trade_id")
        wlx = wl.set_index("trade_id")
        ok5, n5 = True, 0
        for nm, col, s1 in (("F1", "lane_m5atr", True), ("ATRROLL", "lane_atrroll", False)):
            V = F.run_tree(G, nm, qatr, {})
            f7 = {sid: G["TS"]["fills"][sid][0] for sid in M.TG.SETUPS}
            if s1:
                f7["S1"] = M.variant_fills(G["TS"], I, M.VARIANTS["M5TREE"], {})["S1"][0]
            for e, T in V["Ts"].items():
                m = (T["ent"] >= G["p0"]) & (T["ent"] <= G["t1"]) & np.isin(T["tid"], P["trade_id"].to_numpy())
                how = np.array([str(g).split(":", 1)[-1] for g in T["g"][m]])
                tids = T["tid"][m]
                ents = T["ent"][m]
                lane = np.array([Pm.at[t_, col] for t_ in tids])
                ok5 &= bool((lane[how == "open"] == 0).all())
                opens = set(tids[how == "open"])
                if e == "ENS":
                    ok5 &= opens == set(P.loc[(P["engine"] == "ENS") & (P[col] == 0), "trade_id"])
                else:
                    want = set()
                    dP = P[(P["engine"] == "D") & (P[col] == 0)].copy()
                    dP["up"] = [wlx.at[t_, "entry"] >= wlx.at[t_, "signal_close"] for t_ in dP["trade_id"]]
                    for _, g in dP[dP["up"]].groupby("signal_day"):
                        want.add(g.sort_values("rank").iloc[0]["trade_id"])
                    ok5 &= opens == want
                for t_, h, en in zip(tids, how, ents):
                    if h == "open":
                        continue
                    br = rowof[t_]
                    k, _, sid = min((f7[s][br], j, s) for j, s in enumerate(M.TG.SETUPS) if f7[s][br] > 0)
                    ok5 &= sid == h and en == bk.i1[br] + k - 1
                    n5 += 1
        check(ok5 and n5 > 400, "t5 F1's and ATRROLL's routing: opens only when calm under their own rule, ENS every "
                                "calm pick, D the first calm up-open; %d setup entries = the earliest of the seven "
                                "fills (F1's S1 on the M5-ATR)" % n5)
        # ------------------------------------------------------------------ t6 the path-free tables
        R = Tb[Tb["table"] == "routing"]
        ok6 = True
        for pair, ca, cb, na, nb_ in (("F1 vs FROZEN", "lane_m5atr", "lane_atr", "F1", "FROZEN"),
                                      ("LANE vs ATRROLL", "lane_m5", "lane_atrroll", "LANE", "ATRROLL")):
            Rp = R[R["pair"] == pair]
            for e in ("D", "ENS", "both"):
                for x in (0, 1):
                    for y in (0, 1):
                        g = P if e == "both" else P[P["engine"] == e]
                        g = g[(g[ca] == x) & (g[cb] == y)]
                        r = Rp[(Rp["engine"] == e) & (Rp[na] == ("jumpy" if x else "calm")) &
                               (Rp[nb_] == ("jumpy" if y else "calm"))].iloc[0]
                        on = g["open_net"].dropna()
                        st = g["setup7_net"].dropna()
                        ok6 &= r["picks"] == len(g) and same([r["open_net_avg"], r["setup_net_avg"]],
                                                             [on.mean() if len(on) else np.nan,
                                                              st.mean() if len(st) else np.nan], 1e-9)
                        ok6 &= same(r["setup_fill_pct"], 100 * (g["setup7_day"] > 0).mean() if len(g) else np.nan,
                                    1e-9)
        Sh = Tb[Tb["table"] == "shares"]
        yrs = P["signal_day"].dt.year
        for r in Sh.itertuples():
            g = P[(yrs == r.year) & (P["engine"] == r.engine)]
            ok6 &= same([r.atr, r.m5atr, r.atrroll, r.m5], [100 * (g["lane_" + k] == 1).mean() for k in
                                                           ("atr", "m5atr", "atrroll", "m5")], 1e-9)
        check(ok6, "t6 the path-free tables (F1 vs FROZEN, LANE vs ATRROLL: picks, open and setup outcomes) and each "
                   "rule's jumpy share by year, by hand from the pick table")
        # ------------------------------------------------------------------ t7 identity
        wa = Wd["absent"]
        Ga = M.prepare(TT.args(wa["root"], wa["data"], wa["run"], tmp / "prep"), log=lambda *x: None)
        Iid = M.Inputs(Ga["TS"], Ga["U"], np.full(Ga["U"].nu, np.nan), Ga["rv_u"], Ga["stress_bk"])
        Gid = dict(Ga, I=Iid)
        qid = F.window_q_atr(Iid.d0, Iid.sig, Iid.atr[Ga["U"].br])
        fz = F.run_tree(Ga, "FROZEN", F.window_q_atr(Ga["I"].d0, Ga["I"].sig, Ga["I"].atr[Ga["U"].br]), {})
        ok7 = all(np.array_equal(F.run_tree(Gid, t, qid, {})["rbar"], fz["rbar"]) for t in ("F1", "ATRROLL", "LANE",
                                                                                           "M5TREE"))
        rc_ = json.loads((wa["d"] / "RUN.json").read_text(encoding="utf-8"))["checks"]
        check(ok7 and "reproduce the frozen tree" in rc_["identity"],
              "t7 without forecasts F1, ATRROLL, LANE and M5TREE give the frozen 5-start account exactly")
        # ------------------------------------------------------------------ t8 planted and absent
        tl = Tr.loc["F1"]
        ta = pd.read_csv(wa["d"] / "m5fair_trees.csv").set_index("tree").loc["F1"]
        check(tl["verdict"] == "PASS", "t8 LANE world: F1 PASS (%+.2f bp a day [%+.2f, %+.2f])" % (
            tl["diff"], tl["diff_lo"], tl["diff_hi"]))
        check(ta["verdict"] == "FAIL", "t8 ABSENT world: F1 FAIL (%+.2f bp a day [%+.2f, %+.2f])" % (
            ta["diff"], ta["diff_lo"], ta["diff_hi"]))
        # ------------------------------------------------------------------ t9 refusals and outputs
        root, data, run = wa["root"], wa["data"], wa["run"]
        empty = tmp / "emptyrun"
        empty.mkdir()
        o9 = tmp / "o9"
        with redirect_stdout(io.StringIO()) as b9:
            r1 = F.main(["--root", str(root), "--data", str(data), "--run", str(empty), "--out", str(o9),
                         "--stage-e-any"])
            r2 = F.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(root / "x"),
                         "--stage-e-any"])
            r3 = F.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(o9),
                         "--stage-e-any", "--check-only"])
        txt = b9.getvalue()
        dd = json.loads((HERE.parent / F.DECL_FILE).read_text(encoding="utf-8"))
        dd["decision"] = dd["decision"].replace("95%", "90%")
        ed = tmp / "edited.json"
        ed.write_text(json.dumps(dd), encoding="utf-8")
        try:
            F.load_declaration(ed)
            refused = False
        except F.FairError:
            refused = True
        check(r1 == 3 and r2 == 3 and r3 == 0 and refused and "CHECK OK" in txt and txt.count("REFUSED") == 2 and
              not list(o9.glob("M5FAIR_*")) and not (root / "x").exists(),
              "t9 refused: no pick_forecasts.csv, --out inside the cache, an edited declaration; --check-only writes "
              "nothing")
        dz = wa["d"]
        hs = [ln for ln in (dz / "outputs.sha256").read_text(encoding="utf-8").split("\n") if ln.strip()]
        okh = all(hashlib.sha256((dz / ln.split("  ")[1]).read_bytes()).hexdigest() == ln.split("  ")[0] for ln in hs)
        led = [json.loads(x) for x in (wa["out"] / "vollab_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        md = (dz / "M5FAIR.md").read_text(encoding="utf-8")
        secs = all(x in md for x in ("## Verdict", "## What each change does", "## Every tree", "## Jumpy share",
                                     "## Where the lanes disagree", "## Each start day", "## Checks"))
        check(okh and len(hs) == 9 and [x["event"] for x in led] == ["start", "end"] and secs,
              "t9 every output's sha256 matches outputs.sha256; the ledger's start and end; the report's sections")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print("FAILED: %d of %d checks" % (len(FAILS), len(FAILS) + N_OK[0]))
        return 1
    print("VERIFIED (%s) - %d checks" % (F.VERSION, N_OK[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
