"""
m5tree.py - m5tree v1.0 (beside vollab v1.0): the frozen tree with M5 in place of ATR14, and new setups built on M5.
Same picks, same prices, same books: only the rules named below change.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\vollab
    python tests\\test_m5tree.py
    python m5tree.py --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --run C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn> --out C:\\QuantData\\vollab

Karan, 22 Nov 2026 23:58: "I want to know its impact on tree if we replace atr with m5. Detailed impact analysis."
23 Nov 00:09: "Go. And also look for new logical setups including m5." 00:28: "Build".

ATR14 enters the frozen tree in two places: the calm / jumpy lanes and S1's 1-ATR dip. M5 = vollab's HARQ forecast of
the next 5 sessions' move (sigma5, %), read from the vollab run's pick_forecasts.csv (no 3-minute pass here).

THE WINDOW (point in time): for a pick with signal day t, the tree's picks (D and ENS ranks 1-3) with an M5 forecast
whose signal day is one of the 250 sessions before t; at least 100 of them, else the pick keeps ATR14 everywhere.

PART 1 - Karan's question (one test)
  M5TREE  jumpy = sigma5 above the window's 2/3 quantile; S1's ATR = sigma5 x (window median s_atr14 / window median
          sigma5). PASS = its daily gain over the frozen tree has a 95% interval above 0 AND its worst fall is no deeper.
  shown: LANE (lanes only), S1M5 (S1 only), LANEMIX (M5 ranks, the ATR rule's jumpy share in the window).
PART 2 - new setups on M5 (the research report's ranked list; Holm over V1-V3, each against the frozen tree)
  V1  every dip in M5 units: S1 as above; S3, C1, C2, N1's % dips x sigma5 / the window's median sigma5
  V2  V1 on normal volume: a dip setup fills only if D1..D(k-1)'s mean volume <= 1.5 x the median of the stock's 20
      sessions up to the signal day
  V3  V1, wider in market stress: on a watch day after a close where NIFTY's 5-session variance forecast (vollab's R
      forecast) >= 1.25 x its median over the 250 sessions before, the five dip thresholds are halved
  PASS = Holm-adjusted one-sided p <= 0.025 AND a worst fall no deeper. shown: V4 (skip picks whose sigma5 is in the
  window's bottom fifth: chosen after vollab's stage B quintiles, so snooped), ALL (M5TREE + V1).
Example: a pick with sigma5 9% when the window's median is 6% and its 2/3 quantile 7.5% is jumpy; its S1 dip becomes
1.5 x the typical ATR and its 3% dips need 4.5%.

Reads vollab's pick_forecasts.csv, the panel, the watchlist and the daily cache (stage E's loader), read only. Writes
only M5TREE_<date>_<nnn>\\ under --out and a line in vollab_ledger.jsonl. Research only: nothing in production, the
paper test or the frozen tree changes.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import vollab as VL  # noqa: E402

SU, TL, TG, TD, TC = VL.SU, VL.TL, VL.TG, VL.TD, VL.TC
VERSION = "m5tree v1.0"
NEEDS = {"vollab": "vollab v1.0", "setuplab": "setuplab v1.1", "treelab": "treelab v1.0",
         "triggerlab": "triggerlab v1.0", "tradelab": "tradelab v1.3.1"}
DECL_FILE = "M5TREE_DECLARATION.json"
COL = "sigma5_M5_pct"
START = "2023-01-01"
WIN, WIN_MIN = 250, 100            # sessions before the signal day; picks with a forecast needed
Q_LANE, Q_SKIP = 2 / 3, 0.2
VOL_N, VOL_MIN, RVOL_MAX = 20, 15, 1.5
STRESS_Z, STRESS_N, STRESS_MIN, STRESS_CUT = 1.25, 250, 120, 0.5
DIPS = {"S1": ("pc_vs_d1_atr", -1.0), "S3": ("pc_vs_d1", -3.0), "C1": ("pc_vs_d1", -2.0),
        "C2": ("pc_vs_d1", -3.0), "N1": ("pc_vs_d1", -2.0)}
RV_FIELD = "m5_rvol"
WATCH = SU.WATCH
COST = SU.COST
ALPHA1 = 0.025
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
ENGINES = (("D", "first_up"), ("ENS", "all"))
VARIANTS = {
    "FROZEN": {"lane": "atr", "dips": None, "gate": False, "stress": False, "skip": False},
    "LANE": {"lane": "m5", "dips": None, "gate": False, "stress": False, "skip": False},
    "S1M5": {"lane": "atr", "dips": "s1", "gate": False, "stress": False, "skip": False},
    "LANEMIX": {"lane": "mix", "dips": None, "gate": False, "stress": False, "skip": False},
    "M5TREE": {"lane": "m5", "dips": "s1", "gate": False, "stress": False, "skip": False},
    "V1": {"lane": "atr", "dips": "all", "gate": False, "stress": False, "skip": False},
    "V2": {"lane": "atr", "dips": "all", "gate": True, "stress": False, "skip": False},
    "V3": {"lane": "atr", "dips": "all", "gate": False, "stress": True, "skip": False},
    "V4": {"lane": "atr", "dips": None, "gate": False, "stress": False, "skip": True},
    "ALL": {"lane": "m5", "dips": "all", "gate": False, "stress": False, "skip": False},
}
WORDS = {"FROZEN": "the frozen tree (ATR14 lanes, the frozen setups)",
         "LANE": "M5 lanes only (S1 on ATR14)",
         "S1M5": "S1's dip in M5 units only (ATR14 lanes)",
         "LANEMIX": "M5 lanes with the ATR rule's jumpy share",
         "M5TREE": "M5 in both places: lanes and S1's dip",
         "V1": "every dip in M5 units (S1, S3, C1, C2, N1)",
         "V2": "V1, dips only on normal volume",
         "V3": "V1, dips halved after a stressed NIFTY close",
         "V4": "skip picks in the window's bottom fifth of sigma5 (snooped)",
         "ALL": "M5 lanes + every dip in M5 units"}
PART1, PART2, SHOWN2 = ("LANE", "S1M5", "LANEMIX", "M5TREE"), ("V1", "V2", "V3"), ("V4", "ALL")
LOG = VL.LOG


class M5Error(Exception):
    pass


def constants():
    return {"col": COL, "start": START, "win": WIN, "win_min": WIN_MIN, "q_lane": Q_LANE, "q_skip": Q_SKIP,
            "vol": [VOL_N, VOL_MIN, RVOL_MAX], "stress": [STRESS_Z, STRESS_N, STRESS_MIN, STRESS_CUT],
            "dips": {k: list(v) for k, v in DIPS.items()}, "alpha1": ALPHA1, "cost": COST,
            "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "variants": VARIANTS, "decided": ["M5TREE"] + list(PART2)}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise M5Error("no declaration at %s (it ships beside m5tree.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise M5Error("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise M5Error("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def check_dips(fdoc):
    """The five dip setups as declared: their dip condition is DIPS' (field, '<', value), the only one on a price."""
    have = {}
    for s in fdoc["setups"]:
        d = [c for c in s["conds"] if c[0] in ("pc_vs_d1", "pc_vs_d1_atr")]
        if d:
            have[s["id"]] = d
    want = {k: [[f, "<", v]] for k, (f, v) in DIPS.items()}
    norm = {k: [[str(c[0]), str(c[1]), float(c[2])] for c in v] for k, v in have.items()}
    if norm != want:
        raise M5Error("the frozen setups' dips are not the declared ones (found %s)" % norm)


# ====================================================================================================== the forecasts
def read_forecasts(pf, U):
    """sigma5 (M5, %) of each distinct pick from vollab's pick_forecasts.csv; NaN when missing or not positive."""
    F = pd.read_csv(pf)
    need = {"symbol", "signal_day", COL}
    if not need <= set(F.columns):
        raise M5Error("%s lacks %s" % (Path(pf).name, ", ".join(sorted(need - set(F.columns)))))
    sym = F["symbol"].astype(str).str.strip().str.upper().to_numpy()
    day = pd.to_datetime(F["signal_day"]).to_numpy().astype("datetime64[D]").astype(str)
    sig = pd.to_numeric(F[COL], errors="coerce").to_numpy(float)
    s = pd.Series(sig, index=pd.MultiIndex.from_arrays([sym, day]))
    s = s[~s.index.duplicated(keep="last")]
    ku = pd.MultiIndex.from_arrays([np.asarray(U.usym).astype(str),
                                    np.asarray(U.usday).astype("datetime64[D]").astype(str)])
    su = s.reindex(ku).to_numpy(float)
    with np.errstate(invalid="ignore"):
        su = np.where(np.isfinite(su) & (su > 0), su, np.nan)
    return su, {"file_rows": int(len(F)), "file_with_m5": int(np.isfinite(sig).sum()),
                "picks_matched": int(np.isfinite(su).sum()), "picks": int(U.nu)}


def window_stats(d0, sig, atr, jumpy):
    """Per pick (calendar index d0 of its signal day): over the picks with a forecast and an ATR whose signal day is in
    d0 - WIN .. d0 - 1: count, sigma5's 2/3 and 1/5 quantiles and median, s_atr14's median, the ATR lanes' jumpy share
    and sigma5's quantile at 1 - that share."""
    n = len(d0)
    W = {k: np.full(n, np.nan) for k in ("q23", "q20", "med_sig", "med_atr", "share", "qmix")}
    cnt = np.zeros(n, np.int64)
    with np.errstate(invalid="ignore"):
        pop = np.flatnonzero(np.isfinite(sig) & (sig > 0) & np.isfinite(atr) & (atr > 0))
    o = pop[np.argsort(d0[pop], kind="mergesort")]
    pd0 = d0[o]
    for d in np.unique(d0):
        a = np.searchsorted(pd0, d - WIN, side="left")
        b = np.searchsorted(pd0, d - 1, side="right")
        idx = o[a:b]
        m = d0 == d
        cnt[m] = len(idx)
        if len(idx) < WIN_MIN:
            continue
        s, at, jj = sig[idx], atr[idx], jumpy[idx].astype(float)
        sh = float(jj.mean())
        W["q23"][m] = np.quantile(s, Q_LANE)
        W["q20"][m] = np.quantile(s, Q_SKIP)
        W["med_sig"][m] = np.median(s)
        W["med_atr"][m] = np.median(at)
        W["share"][m] = sh
        W["qmix"][m] = np.quantile(s, 1.0 - sh)
    return cnt, W


# ====================================================================================================== volume, stress
def volumes(U, mk):
    """Per distinct pick and watch day k: the mean volume of D1..D(k-1) / the median volume of the stock's last 20 bars
    up to the signal day (at least 15 with volume > 0), its own bars in order (as load_paths); k = 1: 0 (no dip)."""
    rv = np.full((U.nu, WATCH + 1), np.nan)
    rv[:, 1] = 0.0
    nobase = 0
    order = np.argsort(U.usym, kind="mergesort")
    syms, starts = np.unique(U.usym[order], return_index=True)
    bounds = list(starts) + [len(order)]
    for si, sym in enumerate(syms):
        ds = mk.series(str(sym))
        us = order[bounds[si]:bounds[si + 1]]
        if ds is None:
            nobase += len(us)
            continue
        v = np.asarray(ds.v, float)
        for u in us:
            i0 = ds.idx(U.usday[u])
            if i0 < 0:
                nobase += 1
                continue
            base = v[max(0, i0 - VOL_N + 1): i0 + 1]
            with np.errstate(invalid="ignore"):
                base = base[np.isfinite(base) & (base > 0)]
            if len(base) < VOL_MIN:
                nobase += 1
                continue
            med = float(np.median(base))
            for k in range(2, WATCH + 1):
                if i0 + k - 1 >= len(v):
                    break
                span = v[i0 + 1: i0 + k]
                if np.all(np.isfinite(span)) and np.all(span > 0):
                    rv[u, k] = float(np.mean(span)) / med
    return rv, nobase


def stress_state(mk, bkcal):
    """At each watchlist session's close: NIFTY's 5-session variance forecast (vollab's nifty_state, the R forecast)
    >= STRESS_Z x its median over the STRESS_N sessions before (at least STRESS_MIN). -> (flag on bkcal, z on bkcal)."""
    cal = np.asarray(mk.cal).astype("datetime64[D]")
    _, _, _, Fh, _, _ = VL.nifty_state(mk.series("NIFTY50"), cal)
    n = len(cal)
    z = np.full(n, np.nan)
    for t in range(n):
        if not np.isfinite(Fh[t]):
            continue
        w = Fh[max(0, t - STRESS_N): t]
        w = w[np.isfinite(w)]
        if len(w) >= STRESS_MIN:
            z[t] = Fh[t] / np.median(w)
    bd = np.asarray(bkcal).astype("datetime64[D]")
    pos = np.searchsorted(cal, bd)
    ok = pos < n
    ok[ok] = cal[pos[ok]] == bd[ok]
    zb = np.where(ok, z[np.minimum(pos, n - 1)], np.nan)
    with np.errstate(invalid="ignore"):
        return zb >= STRESS_Z, zb


# ====================================================================================================== the replays
class _Swap:
    """setuplab's Book as SU.trigger reads it (n, ok, O, field), with some fields replaced."""

    def __init__(self, bk, over):
        self.bk, self.over = bk, over
        self.n, self.ok, self.O = bk.n, bk.ok, bk.O

    def field(self, name):
        return self.over[name] if name in self.over else self.bk.field(name)


def dip_fills(TS, sids, atr_s1, scale, fk=None, gate_rv=None):
    """The setups `sids` replayed on the Book with S1's ATR = atr_s1, the % dips divided by `scale`, every dip divided
    by fk (per row and watch day: 1, or 1/2 = the threshold halved) and, with gate_rv, the normal-volume condition."""
    bk = TS["bk"]
    fconds = SU.frozen_conds(TS["fdoc"])
    out = {}
    for sid in sids:
        fld = DIPS[sid][0]
        if fld == "pc_vs_d1_atr":
            A = np.full((bk.n, WATCH + 1), np.nan)
            with np.errstate(invalid="ignore", divide="ignore"):
                A[:, 2:] = (bk.C[:, 1:WATCH] / bk.O[:, [1]] - 1) / atr_s1[:, None]
            A[:, 1] = 0.0
        else:
            with np.errstate(invalid="ignore", divide="ignore"):
                A = bk.field("pc_vs_d1") / scale[:, None]
        if fk is not None:
            A = A / fk
        over = {fld: A}
        cc = list(fconds[sid])
        if gate_rv is not None:
            over[RV_FIELD] = gate_rv
            cc = cc + [(RV_FIELD, "<=", RVOL_MAX)]
        day, st = SU.trigger(_Swap(bk, over), cc)
        r = SU.exits_arr(bk, day, st, TS["primary"][sid])
        out[sid] = (np.where(st == "Filled", day, 0).astype(np.int64), r["ret"])
    return out


def make_eng(TS, e, fills, atr_eff, cut_eff):
    """treelab's Eng for engine e with the given fills and lanes (calm = atr_eff <= cut_eff; no cut = left out)."""
    bk = TS["bk"]
    E = TL.Eng(bk, e, TS["s_"], TS["cuts"], TS["cuts"]["2/3"], fills, list(TG.SETUPS), TS["primary"], TS["tdoc"],
               np.full(bk.n, np.nan))
    E.atr = np.asarray(atr_eff, float)[E.rows]
    E.cut["2/3"] = np.asarray(cut_eff, float)[E.rows]
    E._plans = {}
    return E


def lane_code(atr_eff, cut_eff):
    """1 jumpy, 0 calm, -1 left out (no cut-off): Eng.plan's rule."""
    with np.errstate(invalid="ignore"):
        return np.where(~np.isfinite(cut_eff), -1, np.where(atr_eff <= cut_eff, 0, 1)).astype(np.int64)


class Inputs:
    """Everything the variants share: per Book row, the frozen and the M5 versions of each rule's input."""

    def __init__(self, TS, U, sig_u, rv_u, stress_bk):
        bk = TS["bk"]
        self.nb = nb = bk.n
        cuts = TS["cuts"]["2/3"]
        yrs = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
        self.cut_year = np.array([cuts.get(int(y), np.nan) for y in yrs])
        self.atr = np.asarray(bk.atr, float)
        self.br = U.br
        self.sig = sig_u[U.u]                                   # per engine pick
        self.d0 = (U.i1 - 1).astype(np.int64)
        self.cnt, self.W = window_stats(self.d0, self.sig, self.atr[U.br], U.lane)
        self.ok = np.isfinite(self.sig) & (self.cnt >= WIN_MIN)
        ok = self.ok
        W = self.W
        with np.errstate(invalid="ignore", divide="ignore"):
            self.lane_m5 = np.where(ok, (self.sig > W["q23"]).astype(np.int64), U.lane)
            self.lane_mix = np.where(ok, (self.sig > W["qmix"]).astype(np.int64), U.lane)
            self.skip = ok & (self.sig < W["q20"])
            s1 = np.where(ok, self.sig * W["med_atr"] / W["med_sig"], self.atr[U.br])
            sc = np.where(ok, self.sig / W["med_sig"], 1.0)
        self.atr_s1 = self.atr.copy()
        self.atr_s1[U.br] = s1
        self.scale = np.ones(nb)
        self.scale[U.br] = sc
        self.sig_bk = np.full(nb, np.nan)
        self.sig_bk[U.br] = self.sig
        self.rv = np.full((nb, WATCH + 1), np.nan)
        self.rv[U.br] = rv_u[U.u]
        self.fk = np.ones((nb, WATCH + 1))
        n_cal = len(stress_bk)
        for k in range(1, WATCH + 1):
            j = bk.i1 + k - 2                                   # the close before watch day k (k = 1: the signal day)
            inside = (j >= 0) & (j < n_cal)
            st = np.zeros(nb, bool)
            st[inside] = stress_bk[j[inside]]
            self.fk[st, k] = STRESS_CUT                         # pc / 0.5 < -3  <=>  pc < -1.5
        self.stress_bk = stress_bk

    def lanes(self, kind, skip=False):
        a, c = self.atr.copy(), self.cut_year.copy()
        if kind in ("m5", "mix"):
            q = self.W["q23"] if kind == "m5" else self.W["qmix"]
            a[self.br[self.ok]] = self.sig[self.ok]
            c[self.br[self.ok]] = q[self.ok]
        if skip:
            c[self.br[self.skip]] = np.nan
        return a, c


def variant_fills(TS, I, spec, cache):
    key = (spec["dips"], spec["gate"], spec["stress"])
    if key == (None, False, False):
        return dict(TS["fills"])
    if key not in cache:
        sids = ["S1"] if spec["dips"] == "s1" else list(DIPS)
        atr_s1 = I.atr_s1 if spec["dips"] in ("s1", "all") else I.atr
        scale = I.scale if spec["dips"] == "all" else np.ones(I.nb)
        cache[key] = dip_fills(TS, sids, atr_s1, scale, I.fk if spec["stress"] else None,
                               I.rv if spec["gate"] else None)
    f = dict(TS["fills"])
    f.update(cache[key])
    return f


def run_variant(TS, U, PA, I, name, cache, p0, t1):
    spec = VARIANTS[name]
    fills = variant_fills(TS, I, spec, cache)
    a, c = I.lanes(spec["lane"], spec["skip"])
    Ts = {}
    dropped = 0
    for e, calm in ENGINES:
        E = (TS["ED"] if e == "D" else TS["EE"]) if name == "FROZEN" else make_eng(TS, e, fills, a, c)
        T, dr = TG.frozen_trades(U, PA, TS["bk"], E, calm, TS["primary"])
        Ts[e] = T
        dropped += dr
    B = {e: VL.book_sim2(Ts[e], PA.C, p0, t1) for e, _ in ENGINES}
    r = VL.account_returns(B["D"][1], B["ENS"][1], TS["bk"].cal, p0, t1)
    return {"name": name, "fills": fills, "lane": lane_code(a, c), "Ts": Ts, "B": B, "r": r, "dropped": dropped}


# ====================================================================================================== statistics
def compare(B_, r, rb):
    """Mean of ln(1 + r) - ln(1 + rb) in bp a day, its 95% interval (Boot over the days) and the one-sided p."""
    x = (np.log1p(r) - np.log1p(rb)) * 1e4
    est, lo, hi, sd = VL.boot_mean(B_, np.arange(len(x)), x)
    p = (1.0 - VL.phi(est / sd)) if (np.isfinite(sd) and sd > 0) else np.nan
    return est, lo, hi, sd, p


def summarise(V, days, p0, t1):
    row = VL.path_numbers(V["r"], days)
    row["exposure"] = float(np.mean(0.5 * V["B"]["D"][4] + 0.5 * V["B"]["ENS"][4]))
    tk = 0
    for e, _ in ENGINES:
        T = V["Ts"][e]
        tk += int(V["B"][e][2][(T["ent"] >= p0) & (T["ent"] <= t1)].sum())
    row["trades"] = tk
    yrs = pd.DatetimeIndex(days).year.to_numpy()
    for y in sorted(set(yrs)):
        row["year_%d" % y] = float((np.prod(1 + V["r"][yrs == y]) - 1) * 100)
    return row


def decide(rows, fz):
    """M5TREE: PASS when diff_lo > 0 and its fall <= the frozen tree's. V1-V3: Holm over the one-sided p's, PASS when
    the adjusted p <= ALPHA1 and the fall is no deeper. The rest: shown only."""
    m = rows["M5TREE"]
    m["p_holm"] = np.nan
    m["verdict"] = "PASS" if (np.isfinite(m["diff_lo"]) and m["diff_lo"] > 0 and m["fall"] <= fz["fall"]) else "FAIL"
    adj = VL.holm(np.array([rows[v]["p_one"] for v in PART2], float))
    for v, pa in zip(PART2, adj):
        rows[v]["p_holm"] = float(pa)
        ok = bool(np.isfinite(pa) and pa <= ALPHA1 and rows[v]["fall"] <= fz["fall"])
        rows[v]["verdict"] = "PASS" if ok else "FAIL"
    for v in rows:
        if v not in ("M5TREE",) + PART2:
            rows[v]["p_holm"] = np.nan
            rows[v]["verdict"] = "-" if v == "FROZEN" else "shown only"
    return rows


# ====================================================================================================== the tables
def trades_frame(V, U, bk, I, p0, t1):
    out = []
    for e, _ in ENGINES:
        T = V["Ts"][e]
        m = (T["ent"] >= p0) & (T["ent"] <= t1)
        br = U.br[T["r"][m]]
        ex = T["ex"][m]
        out.append(pd.DataFrame({
            "variant": V["name"], "engine": e, "trade_id": T["tid"][m], "symbol": T["sym"][m],
            "signal_day": pd.DatetimeIndex(T["sday"][m]).date, "rank": T["rank"][m],
            "entry_day": pd.DatetimeIndex(bk.cal[T["ent"][m]]).date,
            "exit_day": [str(pd.Timestamp(bk.cal[x]).date()) if x < len(bk.cal) else "pending" for x in ex],
            "how": [str(g).split(":", 1)[-1] for g in T["g"][m]], "lane": np.where(V["lane"][br] == 1, "jumpy", "calm"),
            "sigma5_pct": I.sig_bk[br], "net": T["net"][m], "taken": V["B"][e][2][m]}))
    return pd.concat(out, ignore_index=True)


def net_stats(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if not len(x):
        return {"n": 0, "win_pct": np.nan, "avg": np.nan, "avg_win": np.nan, "avg_loss": np.nan, "payoff": np.nan,
                "sum": 0.0}
    w, l_ = x[x > 0], x[x <= 0]
    aw = float(w.mean()) if len(w) else np.nan
    al = float(l_.mean()) if len(l_) else np.nan
    return {"n": int(len(x)), "win_pct": float(100 * (x > 0).mean()), "avg": float(x.mean()), "avg_win": aw,
            "avg_loss": al, "payoff": (aw / abs(al)) if (np.isfinite(aw) and np.isfinite(al) and al != 0) else np.nan,
            "sum": float(x.sum())}


def lane_table(TF):
    rows = []
    for v in ("FROZEN", "M5TREE"):
        for e in ("D", "ENS", "both"):
            for ln in ("calm", "jumpy"):
                m = (TF["variant"] == v) & TF["taken"] & (TF["lane"] == ln)
                if e != "both":
                    m &= TF["engine"] == e
                rows.append(dict(tree=v, engine=e, lane=ln, **net_stats(TF.loc[m, "net"])))
    return pd.DataFrame(rows)


def trade_changes(TF, a="FROZEN", b="M5TREE"):
    """Taken trades of tree a vs tree b by engine pick: same entry, re-timed, added (b only), dropped (a only)."""
    rows = []
    for e in ("D", "ENS"):
        A = TF[(TF["variant"] == a) & TF["taken"] & (TF["engine"] == e)].set_index("trade_id")
        Bf = TF[(TF["variant"] == b) & TF["taken"] & (TF["engine"] == e)].set_index("trade_id")
        both = A.index.intersection(Bf.index)
        same = [t for t in both if A.at[t, "entry_day"] == Bf.at[t, "entry_day"] and A.at[t, "how"] == Bf.at[t, "how"]]
        ret = [t for t in both if t not in set(same)]
        add = Bf.index.difference(A.index)
        drop = A.index.difference(Bf.index)
        for nm, net in (("same entry", A.loc[same, "net"]), ("re-timed (%s)" % a, A.loc[ret, "net"]),
                        ("re-timed (%s)" % b, Bf.loc[ret, "net"]), ("added (%s only)" % b, Bf.loc[add, "net"]),
                        ("dropped (%s only)" % a, A.loc[drop, "net"])):
            rows.append(dict(engine=e, group=nm, **net_stats(net)))
    return pd.DataFrame(rows)


def pick_frame(TS, U, PA, I, Vs, p0, t1):
    """Every engine pick entering in the period: its lanes, forecast, window and potential outcomes."""
    bk = TS["bk"]
    m = (U.i1 >= p0) & (U.i1 <= t1)
    j = np.flatnonzero(m)
    br = U.br[j]
    u = U.u[j]
    fz = TS["fills"]
    su = {s: (fz[s][0] > 0, np.where(fz[s][0] > 0, fz[s][0], np.nan), fz[s][1]) for s in TG.SETUPS}
    sid, sk, _, _, snet = TL.first_fill(su, list(TG.SETUPS), TS["primary"], bk.i1)
    with np.errstate(invalid="ignore", divide="ignore"):
        onet = (PA.C[u, 5] / PA.O[u, 1] - 1) * 100 - COST
    f_m5 = Vs["M5TREE"]["fills"]["S1"]
    return pd.DataFrame({
        "engine": U.eng[j], "trade_id": U.tid[j], "symbol": U.sym[j], "signal_day": pd.DatetimeIndex(U.sday[j]).date,
        "rank": U.rank[j], "s_atr14": I.atr[br], "atr_cut": I.cut_year[br], "lane_atr": U.lane[j],
        "sigma5_M5_pct": I.sig[j], "window_picks": I.cnt[j], "m5_cut": I.W["q23"][j], "m5_used": I.ok[j],
        "lane_m5": I.lane_m5[j], "lane_mix": I.lane_mix[j], "atr_for_s1": I.atr_s1[br], "v1_scale": I.scale[br],
        "v4_skip": I.skip[j], "open_net": onet, "setup7": sid[br], "setup7_day": sk[br],
        "setup7_net": np.where(sk[br] > 0, snet[br], np.nan), "s1_day_atr": fz["S1"][0][br],
        "s1_day_m5": f_m5[0][br], "s1_net_atr": np.where(fz["S1"][0][br] > 0, fz["S1"][1][br], np.nan),
        "s1_net_m5": np.where(f_m5[0][br] > 0, f_m5[1][br], np.nan)})


def confusion(PF):
    rows = []
    for e in ("D", "ENS", "both"):
        P = PF if e == "both" else PF[PF["engine"] == e]
        for la in (0, 1):
            for lm in (0, 1):
                g = P[(P["lane_atr"] == la) & (P["lane_m5"] == lm)]
                on = net_stats(g["open_net"])
                st = net_stats(g["setup7_net"])
                rows.append({"engine": e, "atr_lane": "jumpy" if la else "calm", "m5_lane": "jumpy" if lm else "calm",
                             "picks": int(len(g)), "open_net_avg": on["avg"], "open_win_pct": on["win_pct"],
                             "setup_fill_pct": float(100 * (g["setup7_day"] > 0).mean()) if len(g) else np.nan,
                             "setup_net_avg": st["avg"], "setup_win_pct": st["win_pct"]})
    return pd.DataFrame(rows)


def switch_years(PF):
    rows = []
    yrs = pd.DatetimeIndex(PF["signal_day"]).year.to_numpy()
    for y in sorted(set(yrs)):
        for e in ("D", "ENS"):
            g = PF[(yrs == y) & (PF["engine"] == e).to_numpy()]
            rows.append({"year": int(y), "engine": e, "picks": int(len(g)), "with_m5": int(g["m5_used"].sum()),
                         "atr_jumpy_pct": float(100 * g["lane_atr"].mean()) if len(g) else np.nan,
                         "m5_jumpy_pct": float(100 * g["lane_m5"].mean()) if len(g) else np.nan,
                         "calm_to_jumpy": int(((g["lane_atr"] == 0) & (g["lane_m5"] == 1)).sum()),
                         "jumpy_to_calm": int(((g["lane_atr"] == 1) & (g["lane_m5"] == 0)).sum())})
    return pd.DataFrame(rows)


def s1_table(PF):
    a, m = PF["s1_day_atr"].to_numpy(), PF["s1_day_m5"].to_numpy()
    groups = {"filled both, same day": (a > 0) & (a == m), "filled both, another day": (a > 0) & (m > 0) & (a != m),
              "gained (M5 only)": (a == 0) & (m > 0), "lost (ATR14 only)": (a > 0) & (m == 0),
              "neither": (a == 0) & (m == 0)}
    rows = []
    for nm, g in groups.items():
        rows.append({"group": nm, "picks": int(g.sum()), "net_atr_avg": net_stats(PF.loc[g, "s1_net_atr"])["avg"],
                     "net_m5_avg": net_stats(PF.loc[g, "s1_net_m5"])["avg"],
                     "win_m5_pct": net_stats(PF.loc[g, "s1_net_m5"])["win_pct"],
                     "win_atr_pct": net_stats(PF.loc[g, "s1_net_atr"])["win_pct"]})
    return pd.DataFrame(rows)


def fill_changes(Vs, U, p0, t1, names):
    m = (U.i1 >= p0) & (U.i1 <= t1)
    br = np.unique(U.br[m])
    f0 = Vs["FROZEN"]["fills"]
    rows = []
    for v in names:
        for s in DIPS:
            a, b = f0[s][0][br], Vs[v]["fills"][s][0][br]
            rows.append({"variant": v, "setup": s, "frozen_fills": int((a > 0).sum()), "fills": int((b > 0).sum()),
                         "gained": int(((a == 0) & (b > 0)).sum()), "lost": int(((a > 0) & (b == 0)).sum()),
                         "moved": int(((a > 0) & (b > 0) & (a != b)).sum()),
                         "net_gained_avg": net_stats(Vs[v]["fills"][s][1][br][(a == 0) & (b > 0)])["avg"],
                         "net_lost_avg": net_stats(f0[s][1][br][(a > 0) & (b == 0)])["avg"]})
    return pd.DataFrame(rows)


def quintiles(TF):
    g = TF[(TF["variant"] == "FROZEN") & TF["taken"] & np.isfinite(TF["sigma5_pct"])]
    if len(g) < 25:
        return pd.DataFrame()
    s = g["sigma5_pct"].to_numpy(float)
    q = np.searchsorted(np.quantile(s, [0.2, 0.4, 0.6, 0.8]), s, side="right")
    rows = []
    for k in range(5):
        h = g[q == k]
        st = net_stats(h["net"])
        rows.append({"quintile": k + 1, "trades": st["n"], "sigma5_avg": float(h["sigma5_pct"].mean()),
                     "net_avg": st["avg"], "win_pct": st["win_pct"],
                     "net_per_sigma": float((h["net"] / h["sigma5_pct"]).mean())})
    return pd.DataFrame(rows)


# ====================================================================================================== the report
def _p(x, nd=2, sign=True):
    return VL._p(x, nd, sign)


def _ci(lo, hi, nd=2):
    return VL._ci(lo, hi, nd)


def _md(df, cols, fmt):
    L = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for r in df.to_dict("records"):
        L.append("| " + " | ".join(fmt.get(c, lambda v: str(v))(r[c]) for c in cols) + " |")
    return L


def _f(nd, sign=False, pct=False):
    def g(v):
        try:
            if not np.isfinite(float(v)):
                return "-"
        except (TypeError, ValueError):
            return str(v)
        s = ("%+." if sign else "%.") + str(nd) + "f"
        return (s % float(v)) + ("%" if pct else "")
    return g


def write_report(d, info, R):
    rows, fz = R["rows"], R["rows"]["FROZEN"]
    years = sorted(int(k[5:]) for k in fz if k.startswith("year_"))
    m = rows["M5TREE"]
    L = ["# %s - the tree with M5 in place of ATR14, and new setups on M5" % VERSION, "",
         "%s .. %s (%d sessions); vollab run %s; declaration %s. Same picks, same prices, same books (Rs 5 L each, 3 "
         "positions, 1/3 each, 0.35 a round trip, D/ENS 50:50 restarted each January)." % (
             info["from"], info["to"], info["days"], info["vollab_run"], info["declaration_sha256"][:16]), "",
         "## Verdict", "",
         "**Part 1 - replace ATR14 with M5 (lanes and S1): %s.** The daily gain over the frozen tree is %s bp a day "
         "%s; a year %s%% vs %s%%; worst fall %s%% vs %s%%." % (
             m["verdict"], _p(m["diff"]), _ci(m["diff_lo"], m["diff_hi"]), _p(m["a_year"]), _p(fz["a_year"]),
             _p(m["fall"], 2, False), _p(fz["fall"], 2, False)),
         "PASS needs the interval above 0 and a worst fall no deeper. A PASS is a candidate for a forward paper book "
         "beside the frozen tree (its own freeze date); nothing in the frozen tree changes.", ""]
    L += ["**Part 2 - new setups on M5 (Holm over V1-V3):** " + "; ".join(
        "%s %s (%s bp a day %s, Holm p %s)" % (v, rows[v]["verdict"], _p(rows[v]["diff"]),
                                               _ci(rows[v]["diff_lo"], rows[v]["diff_hi"]),
                                               _p(rows[v]["p_holm"], 4, False)) for v in PART2) + ".", ""]
    L += ["## Every tree", "",
          "| tree | what | a year | worst fall | 5% CVaR a day | gain vs frozen, bp a day | one-sided p | Holm p | "
          "verdict | trades | exposure |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    for v in ("FROZEN",) + PART1 + PART2 + SHOWN2:
        r = rows[v]
        L.append("| %s | %s | %s%% | %s%% | %s%% | %s | %s | %s | %s | %d | %.2f |" % (
            v, WORDS[v], _p(r["a_year"]), _p(r["fall"], 2, False), _p(r["cvar5"]),
            "-" if v == "FROZEN" else "%s %s" % (_p(r["diff"]), _ci(r["diff_lo"], r["diff_hi"])),
            "-" if v == "FROZEN" else _p(r["p_one"], 4, False), _p(r.get("p_holm", np.nan), 4, False),
            r.get("verdict", "-"), r["trades"], r["exposure"]))
    L += ["", "Per year (%):", "", "| tree | " + " | ".join(str(y) for y in years) + " |",
          "|---|" + "---|" * len(years)]
    for v in ("FROZEN",) + PART1 + PART2 + SHOWN2:
        L.append("| %s | " % v + " | ".join(_p(rows[v].get("year_%d" % y, np.nan)) for y in years) + " |")
    L += ["", "V2 and V3 against V1 (what the gate adds, shown only): " + "; ".join(
        "%s %s bp a day %s" % (v, _p(R["vs_v1"][v]["diff"]), _ci(R["vs_v1"][v]["diff_lo"], R["vs_v1"][v]["diff_hi"]))
        for v in ("V2", "V3")) + ".", ""]
    # ---- part 1 detail
    L += ["## Part 1 in detail", "", "### The lanes: ATR14 vs M5, each engine pick entering in the period", "",
          "M5 used on %d of %d engine picks (the rest keep ATR14: no forecast, or fewer than %d forecast picks in the "
          "window)." % (info["m5_used"], info["period_picks"], WIN_MIN), "",
          "open net = bought at the D1 open, sold at the D5 close; setup = the earliest of the 7 frozen setups (its "
          "primary exit). Both on every pick, whatever its lane did.", ""]
    L += _md(R["confusion"], ["engine", "atr_lane", "m5_lane", "picks", "open_net_avg", "open_win_pct",
                              "setup_fill_pct", "setup_net_avg", "setup_win_pct"],
             {"open_net_avg": _f(2, True), "open_win_pct": _f(1), "setup_fill_pct": _f(1),
              "setup_net_avg": _f(2, True), "setup_win_pct": _f(1)})
    L += ["", "By year:", ""]
    L += _md(R["switch_years"], ["year", "engine", "picks", "with_m5", "atr_jumpy_pct", "m5_jumpy_pct",
                                 "calm_to_jumpy", "jumpy_to_calm"], {"atr_jumpy_pct": _f(1), "m5_jumpy_pct": _f(1)})
    L += ["", "### S1's dip: 1 ATR14 vs 1 M5-ATR (every engine pick in the period, whatever its lane)", ""]
    L += _md(R["s1"], ["group", "picks", "net_atr_avg", "win_atr_pct", "net_m5_avg", "win_m5_pct"],
             {"net_atr_avg": _f(2, True), "net_m5_avg": _f(2, True), "win_atr_pct": _f(1), "win_m5_pct": _f(1)})
    L += ["", "### Trades actually taken: frozen tree vs M5 tree", ""]
    L += _md(R["changes"], ["engine", "group", "n", "win_pct", "avg", "payoff", "sum"],
             {"win_pct": _f(1), "avg": _f(2, True), "payoff": _f(2), "sum": _f(1, True)})
    L += ["", "### Each lane of each tree (taken trades)", ""]
    L += _md(R["lanes"], ["tree", "engine", "lane", "n", "win_pct", "avg", "avg_win", "avg_loss", "payoff", "sum"],
             {"win_pct": _f(1), "avg": _f(2, True), "avg_win": _f(2, True), "avg_loss": _f(2, True),
              "payoff": _f(2), "sum": _f(1, True)})
    # ---- part 2 detail
    L += ["", "## Part 2 in detail", "", "Fills of the five dip setups against the frozen setups' (engine picks in the "
          "period):", ""]
    L += _md(R["fills"], ["variant", "setup", "frozen_fills", "fills", "gained", "lost", "moved", "net_gained_avg",
                          "net_lost_avg"], {"net_gained_avg": _f(2, True), "net_lost_avg": _f(2, True)})
    L += ["", "V2: %s. V3: NIFTY stressed on %.1f%% of the period's closes." % (info["volume"], info["stress_pct"]),
          ""]
    if len(R["quintiles"]):
        L += ["## Diagnostic: the frozen tree's taken trades by M5 quintile", "",
              "net per sigma = net / sigma5. Flat across the quintiles = M5 sizes the move, not the edge (the "
              "research report's check).", ""]
        L += _md(R["quintiles"], ["quintile", "trades", "sigma5_avg", "net_avg", "win_pct", "net_per_sigma"],
                 {"sigma5_avg": _f(2), "net_avg": _f(2, True), "win_pct": _f(1), "net_per_sigma": _f(3, True)})
    L += ["", "## Read this", "",
          "- M5 was chosen in vollab as the most accurate forecast over these same months (on accuracy, not money): "
          "a small head start for Part 1.",
          "- V1-V3 come from the research report (literature), fixed before this run. V4 was chosen after seeing "
          "vollab's stage B quintiles: snooped, shown only.",
          "- The lockbox is spent; a PASS here is a candidate for a forward paper book, judged at its own month 6 "
          "and 12.", "", "## Checks", ""] + ["- %s: %s" % (k, v) for k, v in info["checks"].items()]
    (d / "M5TREE.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ====================================================================================================== the run
def prepare(a, log=LOG):
    """Everything the variants need: the declaration and versions, the inputs, the frozen tree (its gate), the picks
    and their daily bars, M5, the volumes and NIFTY's stress."""
    dp, ddoc = load_declaration()
    found = {"vollab": VL.VERSION, "setuplab": SU.VERSION, "treelab": TL.VERSION, "triggerlab": TG.VERSION,
             "tradelab": TC.VERSION}
    bad = ["%s (found %s)" % (v, found[k]) for k, v in NEEDS.items() if found[k] != v]
    if bad:
        raise M5Error("needs %s beside this folder" % ", ".join(bad))
    root, panel = VL.resolve_inputs(a)
    out = VL.guard_out(a.out, root)
    rd = Path(a.run)
    pf = rd / "pick_forecasts.csv"
    if not pf.is_file():
        raise M5Error("%s not found (give --run a VOLLAB_<date>_<nnn> folder)" % pf)
    TS = VL.tree_setup(a, root, panel, log)
    check_dips(TS["fdoc"])
    bk = TS["bk"]
    checks = dict(TS["checks"])
    mk = TD.Market(root, TD.Production(stage_e_any=bool(getattr(a, "stage_e_any", False))))
    U = TG.Universe(bk, TS["cuts"]["2/3"], TS["tdoc"], TS["s_"])
    PA, why = TG.load_paths(U, bk, VL._DailyOnly(mk), log)
    off = int((~PA.ok).sum())
    if U.nu == 0 or off > TG.MISMATCH_MAX * U.nu:
        raise M5Error("%d of %d picks could not be matched to the cache's bars (%s)" % (off, U.nu, why))
    n_before = U.n
    U.keep(PA.ok)
    checks["picks"] = "%d engine picks of D and ENS ranks 1-3 (%d distinct); %d dropped (prices not matched: %s)" % (
        U.n, int(PA.ok.sum()), n_before - U.n, why or "none")
    sig_u, finfo = read_forecasts(pf, U)
    checks["forecasts"] = "%s: %d rows, %d with M5; %d of %d distinct picks matched" % (
        pf.name, finfo["file_rows"], finfo["file_with_m5"], finfo["picks_matched"], finfo["picks"])
    p0 = int(np.searchsorted(bk.cal, np.datetime64(START)))
    t1 = int(TS["t1"])
    if p0 >= t1:
        raise M5Error("the frozen trades end before %s" % START)
    inper = (U.i1 >= p0) & (U.i1 <= t1)
    if not np.isfinite(sig_u[U.u[inper]]).any():
        raise M5Error("no pick entering from %s has an M5 forecast (is --run the right vollab run?)" % START)
    rv_u, nobase = volumes(U, mk)
    stress_bk, zb = stress_state(mk, bk.cal)
    I = Inputs(TS, U, sig_u, rv_u, stress_bk)
    return {"dp": dp, "ddoc": ddoc, "root": root, "panel": panel, "out": out, "rd": rd, "TS": TS, "mk": mk, "U": U,
            "PA": PA, "sig_u": sig_u, "finfo": finfo, "p0": p0, "t1": t1, "rv_u": rv_u, "nobase": nobase,
            "stress_bk": stress_bk, "zb": zb, "I": I, "checks": checks}


def run(a, log=LOG):
    t0 = time.time()
    G = prepare(a, log)
    dp, ddoc, root, panel, out, rd = G["dp"], G["ddoc"], G["root"], G["panel"], G["out"], G["rd"]
    TS, U, PA, I, p0, t1 = G["TS"], G["U"], G["PA"], G["I"], G["p0"], G["t1"]
    rv_u, nobase, stress_bk, zb, finfo, checks = G["rv_u"], G["nobase"], G["stress_bk"], G["zb"], G["finfo"], \
        G["checks"]
    bk = TS["bk"]
    for k_, v_ in checks.items():
        log(" %s: %s" % (k_, v_))
    if getattr(a, "check_only", False):
        log("CHECK OK - the frozen tree reproduced, %d picks matched, %d with M5; nothing computed or written." % (
            U.n, finfo["picks_matched"]))
        return None
    # ---- identity: the M5 machinery with no forecast reproduces the frozen trades
    cache = {}
    Iid = Inputs(TS, U, np.full(U.nu, np.nan), rv_u, stress_bk)
    Vid = run_variant(TS, U, PA, Iid, "M5TREE", {}, p0, t1)
    Vs = {"FROZEN": run_variant(TS, U, PA, I, "FROZEN", cache, p0, t1)}
    same = all(np.array_equal(Vid["Ts"][e][k], Vs["FROZEN"]["Ts"][e][k]) for e, _ in ENGINES
               for k in ("ent", "ex", "u", "tid")) and np.array_equal(Vid["r"], Vs["FROZEN"]["r"])
    if not same:
        raise M5Error("the M5 machinery without forecasts does not reproduce the frozen trades - send Claude this line")
    checks["identity"] = "the M5 machinery without forecasts reproduces the frozen trades and books exactly"
    for v in [x for x in VARIANTS if x != "FROZEN"]:
        Vs[v] = run_variant(TS, U, PA, I, v, cache, p0, t1)
    days = bk.cal[p0:t1 + 1]
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    rows = {"FROZEN": summarise(Vs["FROZEN"], days, p0, t1)}
    for v in [x for x in VARIANTS if x != "FROZEN"]:
        rows[v] = summarise(Vs[v], days, p0, t1)
        est, lo, hi, sd, p = compare(B_, Vs[v]["r"], Vs["FROZEN"]["r"])
        rows[v].update({"diff": est, "diff_lo": lo, "diff_hi": hi, "p_one": p})
    rows["FROZEN"].update({"diff": np.nan, "diff_lo": np.nan, "diff_hi": np.nan, "p_one": np.nan})
    decide(rows, rows["FROZEN"])
    vs_v1 = {}
    for v in ("V2", "V3"):
        est, lo, hi, _, p = compare(B_, Vs[v]["r"], Vs["V1"]["r"])
        vs_v1[v] = {"diff": est, "diff_lo": lo, "diff_hi": hi, "p_one": p}
    # ---- tables
    TF = pd.concat([trades_frame(Vs[v], U, bk, I, p0, t1) for v in VARIANTS], ignore_index=True)
    PF = pick_frame(TS, U, PA, I, Vs, p0, t1)
    R = {"rows": rows, "vs_v1": vs_v1, "confusion": confusion(PF), "switch_years": switch_years(PF),
         "s1": s1_table(PF), "changes": trade_changes(TF), "lanes": lane_table(TF),
         "fills": fill_changes(Vs, U, p0, t1, ("M5TREE",) + PART2), "quintiles": quintiles(TF)}
    pm = (U.i1 >= p0) & (U.i1 <= t1)
    brp = np.unique(U.br[pm])
    v1f = np.zeros(len(brp), bool)
    v2f = np.zeros(len(brp), bool)
    for s in DIPS:
        v1f |= Vs["V1"]["fills"][s][0][brp] > 0
        v2f |= Vs["V2"]["fills"][s][0][brp] > 0
    novol = int((~np.isfinite(I.rv[brp, 2])).sum())
    info = {"from": str(pd.Timestamp(days[0]).date()), "to": str(pd.Timestamp(days[-1]).date()), "days": len(days),
            "vollab_run": rd.name, "declaration_sha256": ddoc["sha256"], "period_picks": int(pm.sum()),
            "m5_used": int(I.ok[pm].sum()),
            "volume": "%d of %d picks with a V1 dip fill keep none under the volume gate; %d picks have no volume "
                      "baseline (no fill under V2)" % (int((v1f & ~v2f).sum()), int(v1f.sum()), novol),
            "stress_pct": float(100 * np.mean(stress_bk[p0:t1 + 1]))}
    checks["period"] = "%s .. %s, %d sessions; the books start empty at %s" % (info["from"], info["to"], len(days),
                                                                                 info["from"])
    checks["window"] = "M5 used on %d of %d engine picks entering in the period" % (info["m5_used"],
                                                                                    info["period_picks"])
    checks["volume"] = "%d distinct picks without a 20-bar volume baseline (V2 cannot fill them)" % nobase
    checks["dropped"] = "; ".join("%s %d" % (v, Vs[v]["dropped"]) for v in VARIANTS if Vs[v]["dropped"]) or \
        "no planned trade lacked prices"
    # ---- outputs
    d = SU.new_run_dir(out, "M5TREE")
    VL.ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                    "tool": VERSION, "declaration_sha256": ddoc["sha256"], "vollab_run": rd.name})
    vr = []
    for v in VARIANTS:
        r = {"variant": v, "what": WORDS[v]}
        r.update(rows[v])
        vr.append(r)
    files = ["m5tree_variants.csv", "m5tree_daily.csv", "m5tree_trades.csv", "m5tree_picks.csv",
             "m5tree_tables.csv"]
    pd.DataFrame(vr).to_csv(d / files[0], index=False)
    pd.DataFrame({"date": pd.DatetimeIndex(days).date, "nifty_stress": stress_bk[p0:t1 + 1],
                  "nifty_z": zb[p0:t1 + 1], **{"r_" + v: Vs[v]["r"] for v in VARIANTS}}).to_csv(
        d / files[1], index=False, float_format="%.12g")
    TF.to_csv(d / files[2], index=False, float_format="%.12g")
    PF.to_csv(d / files[3], index=False, float_format="%.12g")
    tabs = []
    for nm in ("confusion", "switch_years", "s1", "changes", "lanes", "fills", "quintiles"):
        t = R[nm].copy()
        t.insert(0, "table", nm)
        tabs.append(t)
    pd.concat(tabs, ignore_index=True).to_csv(d / files[4], index=False, float_format="%.12g")
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info["checks"] = checks
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": ddoc["sha256"], "vollab_run": rd.name, "period": [info["from"], info["to"]],
              "variants": rows, "vs_v1": vs_v1,
              "decisions": {v: rows[v]["verdict"] for v in ("M5TREE",) + PART2}}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "M5TREE_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    write_report(d, info, R)
    (d / "RUN.json").write_text(json.dumps({"version": VERSION, "root": str(root), "panel": str(panel),
                                            "data": str(a.data), "run": str(rd), "checks": checks,
                                            "missing_columns": TS["missing_cols"]}, indent=1, default=str),
                                encoding="utf-8")
    files += ["M5TREE_RESULT.json", "DECLARATION.json", "M5TREE.md", "RUN.json"]
    SU.write_hashes(d, files)
    VL.ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                    "decisions": result["decisions"], "minutes": round((time.time() - t0) / 60, 1)})
    log("M5TREE WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    m = rows["M5TREE"]
    log(" PART 1 M5TREE: %s (%s bp a day %s; a year %s%% vs %s%%; worst fall %.2f%% vs %.2f%%)" % (
        m["verdict"], _p(m["diff"]), _ci(m["diff_lo"], m["diff_hi"]), _p(m["a_year"]), _p(rows["FROZEN"]["a_year"]),
        m["fall"], rows["FROZEN"]["fall"]))
    for v in PART2:
        r = rows[v]
        log(" PART 2 %s: %s (%s bp a day %s, Holm p %s)" % (v, r["verdict"], _p(r["diff"]),
                                                           _ci(r["diff_lo"], r["diff_hi"]), _p(r["p_holm"], 4, False)))
    return d


def main(argv=None):
    ap = argparse.ArgumentParser(prog="m5tree", description=VERSION)
    ap.add_argument("--root", required=True, help="the cache root (%%CACHE_DAILY_ROOT%%)")
    ap.add_argument("--data", required=True, help="setuplab's watchlist folder (C:\\QuantData\\setuplab\\WL_R1_10)")
    ap.add_argument("--run", required=True, help="the vollab run folder (C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn>)")
    ap.add_argument("--out", required=True, help="the output folder (C:\\QuantData\\vollab)")
    ap.add_argument("--panel", help="panel_oc's panel.parquet (default: <root>\\panel_oc\\panel.parquet)")
    ap.add_argument("--check-only", dest="check_only", action="store_true", help="check the inputs, write nothing")
    ap.add_argument("--stage-e-any", dest="stage_e_any", action="store_true",
                    help="accept a stage_e_execution.py that is not the shipped v1.2")
    a = ap.parse_args(argv)
    try:
        run(a)
    except (M5Error, VL.VLError, TG.TGError, TL.TLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
