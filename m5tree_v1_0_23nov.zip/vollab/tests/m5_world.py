"""
tests/m5_world.py - synthetic worlds for m5tree's tests (daily bars only; nothing here ships to production).

make_world(base, seed, kind) writes the cache root (<SYM>_daily.parquet with volume, NIFTY50_daily.parquet,
panel_oc\\panel.parquet, vl_world's stand-in production modules), setuplab's watchlist folder (D and ENS ranks 1-5 a
day from 2020) and a vollab run folder holding pick_forecasts.csv (sigma5_M5_pct for the D and ENS ranks 1-3 picks from
sig_from; 3% of them left blank).
  absent: 2% a day for every stock; sigma5 = 2% x sqrt(5) x noise (no information); plain volume; NIFTY plain.
  lane:   as absent, but sigma5 knows the pick: 6% when the pick's D1-open-to-D5-close return is negative, else 3%
          (x noise) - M5's lanes send the losers to the setups and buy the winners at the open; ATR14 cannot tell.
  ruler:  as absent, but sigma5 knows the dip: 3 x when the pick's D3-open-to-D5-close return is negative, else
          0.5 x (x noise) - dips in M5 units wait for the losers' deep dips and buy the winners' shallow ones.
  volume: as absent, but a day falling 1.5% or more followed by a fall of 1% or more from the next open to 3 sessions
          later trades 6x the volume - the volume gate drops the dips that keep falling.
  stress: as absent (140 stocks; a stock picked waits 12 sessions to be picked again), but NIFTY has two
          100-session stretches at 2.5% a day (mean 0; the stocks follow it, so most picks turn jumpy there); inside
          them every top-3 pick dips 1.6% from its D1 open to its D1 close and then rises 1.5% a day to D5 - only
          the halved dips (-1%, -1.5%) buy it at the D2 open; the frozen ones (-2%, -3%, -1 ATR) never fill it.
Every world: d_mdi14_diff5 and d_bb_bw_20 only fall, so S2 and C3 never fill and the jumpy lane enters through the
five dip setups (the ones the variants change).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import vl_world as VW  # noqa: E402

IST = "Asia/Kolkata"
FZ = VW.FZ
ELIG = VW.ELIG
KINDS = ("absent", "lane", "ruler", "volume", "stress")
STRESS_WINDOWS = (("2023-03-01", 100), ("2024-09-02", 100))


def make_world(base: Path, seed: int, kind: str, n_sym=30, per_day=5, start="2019-05-01", end="2025-12-31",
               sig_from="2022-10-01", SU=None):
    assert kind in KINDS
    rng = np.random.default_rng(seed)
    root, data, run = base / "root", base / "data", base / "vollab_run" / "VOLLAB_20261122_001"
    for p in (root / "panel_oc", data, run):
        p.mkdir(parents=True, exist_ok=True)
    VW.use_mods(root)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]
    # the market
    mu_m, sd_m = np.full(T, 0.0004), np.full(T, 0.008)
    stress = np.zeros(T, bool)
    if kind == "stress":
        for d0, n in STRESS_WINDOWS:
            k = int(np.searchsorted(cal, pd.Timestamp(d0)))
            stress[k:k + n] = True
        mu_m[stress], sd_m[stress] = 0.0, 0.025
    m = rng.normal(mu_m, sd_m)
    beta = rng.uniform(0.8, 1.2, n_sym)
    sig_s = np.full(n_sym, 0.02)
    eps = rng.normal(0, 1, (n_sym, T))
    R = np.zeros((n_sym, T))
    drift = np.zeros((n_sym, T + 6))
    for t in range(T):
        R[:, t] = beta * m[t] + sig_s * eps[:, t] + drift[:, t]
    on = rng.uniform(0.2, 0.4, (n_sym, T))                    # the overnight share of each day's move
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    chosen = None
    if kind == "stress":                                       # picks first: a stock waits 12 sessions to come back
        if n_sym < 140:
            raise ValueError("the stress world needs n_sym >= 140")
        rp = np.random.default_rng(seed + 2000)
        last = np.full(n_sym, -99)
        chosen = {}
        for t in range(t0, T - 12):
            for eng in ("D", "ENS"):
                free = np.flatnonzero(last < t - 12)
                ch = rp.choice(free, per_day, replace=False)
                chosen[(t, eng)] = ch
                last[ch] = t
            if stress[t]:                                      # each top-3 stock: a shallow D1 dip, then a rebound
                for s_ in set(chosen[(t, "D")][:3]) | set(chosen[(t, "ENS")][:3]):
                    R[s_, t + 1], on[s_, t + 1] = -0.016, 0.0
                    R[s_, t + 2:t + 6] = 0.015
    C = 100.0 * np.exp(rng.normal(0, 0.4, n_sym))[:, None] * np.exp(np.cumsum(R, axis=1))
    Cp = np.c_[C[:, :1] / np.exp(R[:, :1]), C[:, :-1]]
    O = Cp * np.exp(on * R)
    wob = np.abs(rng.normal(0, 0.3, (n_sym, T))) * sig_s[:, None]
    H = np.maximum(O, C) * np.exp(wob)
    L = np.minimum(O, C) * np.exp(-np.abs(rng.normal(0, 0.3, (n_sym, T))) * sig_s[:, None])
    V = rng.lognormal(13, 0.15, (n_sym, T))
    if kind == "volume":
        fwd = np.full((n_sym, T), np.nan)
        fwd[:, :T - 4] = C[:, 4:] / O[:, 1:T - 3] - 1          # from the next open to 3 sessions after it
        V[(R <= -0.015) & (fwd <= -0.01)] *= 6.0
    for s in range(n_sym):
        pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": O[s], "high": H[s], "low": L[s],
                      "close": C[s], "volume": V[s]}).to_parquet(root / ("%s_daily.parquet" % syms[s]), index=False)
    nc = 18000 * np.exp(np.cumsum(m))
    no = np.r_[18000, nc[:-1]] * np.exp(0.3 * m)
    nh = np.maximum(no, nc) * np.exp(np.abs(rng.normal(0, 0.3 * sd_m)))
    nl = np.minimum(no, nc) * np.exp(-np.abs(rng.normal(0, 0.3 * sd_m)))
    pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": no, "high": nh, "low": nl,
                  "close": nc, "volume": np.nan}).to_parquet(root / "NIFTY50_daily.parquet", index=False)
    # the panel: the frozen setups' inputs (changing every day, so the setups fill often) and the eligibility column
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)), axis=1) for f in FZ}
    for f in ("d_mdi14_diff5", "d_bb_bw_20"):                  # only falling: S2 and C3 never fill
        X[f] = -np.cumsum(np.abs(rng.normal(0, 1, (n_sym, T))) + 0.01, axis=1)
    X["d_bb_pctb_20"] = rng.normal(0.3, 0.5, (n_sym, T))
    X["w_ret_13w"] = np.cumsum(rng.normal(0, 3, (n_sym, T)), axis=1)
    X[ELIG] = (rng.random((n_sym, T)) > 0.03).astype(float)
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(pd.DatetimeIndex(cal).tz_localize(IST), n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the watchlist
    atr = np.vstack([SU.atr_simple(H[s], L[s], C[s]) for s in range(n_sym)])
    rows, fc = [], {}
    sig_t = int(np.searchsorted(cal, pd.Timestamp(sig_from)))
    for t in range(t0, T - 12):
        for eng in ("D", "ENS"):
            ch = chosen[(t, eng)] if chosen is not None else rng.choice(n_sym, per_day, replace=False)
            for rk, s in enumerate(ch, 1):
                e1 = O[s, t + 1]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": C[s, t], "entry": e1, "status": "ok",
                       "net_bp": (C[s, t + 5] / e1 - 1) * 1e4 - 35, "s_atr14": atr[s, t], "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[s, t + k] / e1 - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[s, t + k] / C[s, t + k - 1] - 1
                rows.append(row)
                if rk <= 3 and t >= sig_t and (syms[s], t) not in fc:
                    if kind == "lane":
                        v = (6.0 if C[s, t + 5] / O[s, t + 1] < 1 else 3.0) * np.exp(rng.normal(0, 0.1))
                    elif kind == "ruler":
                        v = 100 * 0.02 * np.sqrt(5) * (3.0 if C[s, t + 5] / O[s, t + 3] < 1 else 0.5) * \
                            np.exp(rng.normal(0, 0.05))
                    else:
                        v = 100 * 0.02 * np.sqrt(5) * np.exp(rng.normal(0, 0.25))
                    fc[(syms[s], t)] = v if rng.random() > 0.03 else np.nan
    pd.DataFrame(rows).to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    pd.DataFrame({"symbol": [k[0] for k in fc], "signal_day": [str(cal[k[1]].date()) for k in fc],
                  "row_found": True, "sigma5_M5_pct": list(fc.values())}).to_csv(run / "pick_forecasts.csv",
                                                                                 index=False, float_format="%.5g")
    return root, data, run, {"cal": cal, "syms": syms, "O": O, "H": H, "L": L, "C": C, "V": V, "R": R,
                             "sig_s": sig_s, "stress": stress, "nifty": nc}
