"""
tests for m5tree v1.0 - five synthetic worlds (tests/m5_world.py: daily bars only), each run through m5tree; the rules
rebuilt by hand from the worlds' own bars, panel and forecasts. Ends with  VERIFIED (m5tree v1.0)  or  FAILED.
  t1  the window (250 sessions before, >= 100 forecast picks) and everything read from it, by a loop over the picks:
      the M5 cut-off, the lanes (M5, mix, ATR14's yearly cut), S1's M5-ATR, V1's scale, V4's skip
  t2  S1's fill day with ATR14 and with the M5-ATR, by a loop over watch days (setuplab's rule) for every pick
  t3  V1's and V3's S3 and C1 fills by the same loop (the scale, the halving on stressed closes)
  t4  NIFTY's stress: z and the flag by a loop over the sessions (the median of the 250 forecasts before)
  t5  V2: each pick's volume ratio from the world's volumes, and C1's fills with the gate, by loops
  t6  the M5 tree's routing: open only when calm; ENS every calm pick; D the first calm pick opening at or above the
      signal close; every setup entry the earliest of the seven fills (S1 the M5 one)
  t7  the gains, intervals, one-sided p's, Holm, the verdicts, a year and worst fall, by hand from the daily returns
  t8  the identity: the M5 machinery without forecasts gives the frozen trades and books
  t9  planted worlds pass their own rule (lane: M5TREE; ruler: V1; volume: V2, not V1; stress: V3, above V1); the
      absent world passes none
  t10 refusals (no pick_forecasts.csv, no M5 column, --out inside the cache, an edited declaration), --check-only
      writes nothing, the outputs' hashes, the ledger, the report's sections
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import m5tree as M  # noqa: E402
import m5_world as MW  # noqa: E402

VL, SU = M.VL, M.SU
FAILS, N_OK = [], [0]
SEED = 31


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)


def same(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


def args(root, data, run, out, **kw):
    a = argparse.Namespace(root=str(root), data=str(data), run=str(run), out=str(out), panel=None, stage_e_any=True,
                           check_only=False)
    for k, v in kw.items():
        setattr(a, k, v)
    return a


def world(tmp, kind):
    root, data, run, W = MW.make_world(tmp / kind, SEED, kind, SU=SU, n_sym=140 if kind == "stress" else 30,
                                       sig_from="2022-12-15" if kind == "lane" else "2022-10-01")
    out = tmp / kind / "out"
    with redirect_stdout(io.StringIO()) as buf:
        rc = M.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(out), "--stage-e-any"])
    d = sorted(out.glob("M5TREE_*"))
    return {"root": root, "data": data, "run": run, "W": W, "out": out, "rc": rc, "d": d[-1] if d else None,
            "log": buf.getvalue()}


def outputs(d):
    return {"V": pd.read_csv(d / "m5tree_variants.csv").set_index("variant"),
            "D": pd.read_csv(d / "m5tree_daily.csv", parse_dates=["date"]),
            "T": pd.read_csv(d / "m5tree_trades.csv", parse_dates=["signal_day", "entry_day"]),
            "P": pd.read_csv(d / "m5tree_picks.csv", parse_dates=["signal_day"])}


def panel(root, syms, cal):
    P = pd.read_parquet(root / "panel_oc" / "panel.parquet")
    P["timestamp"] = pd.to_datetime(P["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
    out = {}
    for f in [c for c in P.columns if c not in ("symbol", "timestamp")]:
        out[f] = P.pivot(index="symbol", columns="timestamp", values=f).reindex(index=syms, columns=cal).to_numpy()
    return out


def hand_fill(conds, X, C, O, s, t, dip_field, dip_den):
    """setuplab's rule by a loop: the first watch day k = 1..5 whose conditions all hold (rounded to 9 decimals,
    0 passes neither > 0 nor < 0). dip_den(k): the dip field's divisor that day (the pick's ATR for pc_vs_d1_atr, x the
    scale and the halving)."""
    for k in range(1, 6):
        ok = True
        for f, op, v in conds:
            if f in ("pc_vs_d1", "pc_vs_d1_atr"):
                if k == 1:
                    x = 0.0
                else:
                    raw = C[s, t + k - 1] / O[s, t + 1] - 1
                    x = (raw * 100 if f == "pc_vs_d1" else raw) / dip_den(k)
            elif f == "m5_rvol":
                x = dip_field(k)
            elif f.endswith("_change"):
                b = f[:-7]
                x = X[b][s, t + k - 1] - X[b][s, t + k - 2]
            else:
                x = X[f][s, t + k - 1]
            x = round(float(x), 9)
            hold = {">": x > v, "<": x < v, ">=": x >= v, "<=": x <= v}[op]
            if not hold:
                ok = False
                break
        if ok:
            return k
    return 0


def hand_window(wl, fc, cal, cuts):
    """The window's numbers for every engine pick of D / ENS ranks 1-3 (not the ETF, from 2021), by a loop."""
    cpos = {d: i for i, d in enumerate(cal)}
    E = wl[wl["engine"].isin(["D", "ENS"]) & (wl["rank"] <= 3) & (wl["symbol"] != "LIQUIDBEES") &
           (wl["signal_day"] >= pd.Timestamp("2021-01-01"))].copy()
    E["d0"] = E["signal_day"].map(cpos)
    E["sig"] = [fc.get((s, d), np.nan) for s, d in zip(E["symbol"], E["signal_day"])]
    E["cut"] = [cuts.get(d.year, np.nan) for d in E["signal_day"]]
    E["jumpy"] = (E["s_atr14"] > E["cut"]).astype(int)
    pop = E[np.isfinite(E["sig"]) & (E["sig"] > 0) & (E["s_atr14"] > 0)]
    res = {}
    for r in E.itertuples():
        w = pop[(pop["d0"] >= r.d0 - 250) & (pop["d0"] <= r.d0 - 1)]
        n = len(w)
        if n >= 100:
            s_ = w["sig"].to_numpy()
            sh = w["jumpy"].mean()
            res[r.trade_id] = (n, np.quantile(s_, 2 / 3), np.quantile(s_, 0.2), np.median(s_),
                               np.median(w["s_atr14"]), sh, np.quantile(s_, 1 - sh), r.sig, r.s_atr14, r.cut)
        else:
            res[r.trade_id] = (n,) + (np.nan,) * 6 + (r.sig, r.s_atr14, r.cut)
    return res


def hand_cuts(wl):
    comp = wl[np.isfinite(wl["s_atr14"])]
    out = {}
    for y in range(2020, 2027):
        v = comp.loc[comp["signal_day"] < pd.Timestamp("%d-01-01" % y), "s_atr14"].to_numpy()
        if len(v) >= 100:
            out[y] = float(np.quantile(v, 2 / 3))
    return out


def main():
    print("%s self-test (pandas %s, numpy %s)" % (M.VERSION, pd.__version__, np.__version__))
    tmp = Path(tempfile.mkdtemp(prefix="m5tree_test_"))
    try:
        Wd = {k: world(tmp, k) for k in MW.KINDS}
        bad = [k for k, w in Wd.items() if w["rc"] != 0 or w["d"] is None]
        if bad:
            for k in bad:
                print(Wd[k]["log"][-2500:])
            check(False, "m5tree runs on every world (failed: %s)" % bad)
            return 1
        # ------------------------------------------------------------------ t1 the window (stress and lane worlds)
        for kind in ("lane", "stress"):
            w = Wd[kind]
            O_ = outputs(w["d"])
            W = w["W"]
            cal = pd.DatetimeIndex(W["cal"])
            syms = W["syms"]
            spos = {s: i for i, s in enumerate(syms)}
            wl = pd.read_parquet(w["data"] / "watchlist.parquet")
            wl["signal_day"] = pd.to_datetime(wl["signal_day"])
            F = pd.read_csv(w["run"] / "pick_forecasts.csv", parse_dates=["signal_day"])
            fc = {(s, d): v for s, d, v in zip(F["symbol"], F["signal_day"], F["sigma5_M5_pct"])}
            HW = hand_window(wl, fc, cal, hand_cuts(wl))
            P = O_["P"]
            nb = 0
            hand = {}
            for r in P.itertuples():
                n, q23, q20, ms, ma, sh, qm, sg, at, cut = HW[r.trade_id]
                used = bool(np.isfinite(sg) and n >= 100)
                lane_atr = int(at > cut)
                lm = int(sg > q23) if used else lane_atr
                lx = int(sg > qm) if used else lane_atr
                a1 = sg * ma / ms if used else at
                sc = sg / ms if used else 1.0
                sk = bool(used and sg < q20)
                hand[r.trade_id] = (at, a1, sc)
                good = (r.window_picks == n and bool(r.m5_used) == used and r.lane_atr == lane_atr and
                        r.lane_m5 == lm and r.lane_mix == lx and same(r.atr_cut, cut) and same(r.atr_for_s1, a1) and
                        same(r.v1_scale, sc) and bool(r.v4_skip) == sk and same(r.m5_cut, q23))
                nb += not good
            used_share = P["m5_used"].mean()
            small = int(((P["window_picks"] < 100) & np.isfinite(P["sigma5_M5_pct"])).sum())
            check(nb == 0 and len(P) > 3000 and 0.5 < used_share < 1.0 and (small > 20 if kind == "lane" else True),
                  "t1 %s world, the window by a loop over %d picks: counts, the M5 cut-off and lanes, the mix lanes, "
                  "ATR14's yearly cut, S1's M5-ATR, V1's scale, V4's skip (M5 used on %.0f%%; %d with a forecast keep "
                  "ATR14 under 100 window picks; %d mismatches)" % (kind, len(P), 100 * used_share, small, nb))
        G = M.prepare(args(w["root"], w["data"], w["run"], tmp / "prep"), log=lambda *x: None)
        I, TS = G["I"], G["TS"]
        mk = G["mk"]
        ncal = np.asarray(mk.cal).astype("datetime64[D]")
        Fh = VL.nifty_state(mk.series("NIFTY50"), ncal)[3]
        zt = {}
        for t in range(len(ncal)):
            prev = [x for x in Fh[max(0, t - 250):t] if np.isfinite(x)]
            if np.isfinite(Fh[t]) and len(prev) >= 120:
                zt[pd.Timestamp(ncal[t])] = Fh[t] / np.median(prev)
        stressed = {d: bool(z >= 1.25) for d, z in zt.items()}
        # ------------------------------------------------------------------ t2 S1 by hand
        X = panel(w["root"], syms, cal)
        fdoc = json.loads((Path(SU.__file__).resolve().parent / "FROZEN_SETUPS.json").read_text(encoding="utf-8"))
        cond = {s["id"]: [(c[0], c[1], float(c[2])) for c in s["conds"]] for s in fdoc["setups"]}
        Cw, Ow = W["C"], W["O"]
        b1 = b2 = 0
        for r in P.itertuples():
            s, t = spos[r.symbol], cal.get_loc(r.signal_day)
            k_atr = hand_fill(cond["S1"], X, Cw, Ow, s, t, None, lambda k, a=hand[r.trade_id][0]: a)
            k_m5 = hand_fill(cond["S1"], X, Cw, Ow, s, t, None, lambda k, a=hand[r.trade_id][1]: a)
            b1 += k_atr != r.s1_day_atr
            b2 += k_m5 != r.s1_day_m5
        moved = int((P["s1_day_atr"] != P["s1_day_m5"]).sum())
        check(b1 == 0 and b2 == 0 and moved > 20 and (P["s1_day_m5"] > 0).sum() > 100,
              "t2 S1's fill day by a loop over the watch days: with ATR14 (%d off) and with the M5-ATR (%d off); %d "
              "picks change" % (b1, b2, moved))
        # ------------------------------------------------------------------ t3 V1 / V3 by hand
        bk = TS["bk"]
        rowof = {t_: i for i, t_ in enumerate(bk.ids)}
        Dd = O_["D"]
        fv1 = M.dip_fills(TS, ["S3", "C1"], I.atr_s1, I.scale)
        fv3 = M.dip_fills(TS, ["S3", "C1"], I.atr_s1, I.scale, I.fk)
        b3 = 0
        halved = 0
        for r in P.itertuples():
            s, t = spos[r.symbol], cal.get_loc(r.signal_day)
            br = rowof[r.trade_id]
            for sid in ("S3", "C1"):
                k1 = hand_fill(cond[sid], X, Cw, Ow, s, t, None, lambda k, c=hand[r.trade_id][2]: c)

                def den3(k, c=hand[r.trade_id][2], t=t):
                    return c * (0.5 if stressed.get(cal[t + k - 1], False) else 1.0)
                k3 = hand_fill(cond[sid], X, Cw, Ow, s, t, None, den3)
                b3 += (k1 != fv1[sid][0][br]) + (k3 != fv3[sid][0][br])
                halved += k1 != k3
        check(b3 == 0 and halved > 50,
              "t3 V1's and V3's S3 and C1 fill days by the loop (the M5 scale; halved after a stressed close): %d off; "
              "the halving moves %d" % (b3, halved))
        # ------------------------------------------------------------------ t4 NIFTY's stress
        zh = np.array([zt.get(d, np.nan) for d in Dd["date"]])
        inwin = np.zeros(len(Dd), bool)
        for d0, n in MW.STRESS_WINDOWS:
            k = int(np.searchsorted(cal, pd.Timestamp(d0)))
            inwin |= (Dd["date"] >= cal[k]).to_numpy() & (Dd["date"] <= cal[k + n - 1]).to_numpy()
        flag = Dd["nifty_stress"].to_numpy(bool)
        check(same(Dd["nifty_z"], zh, 1e-8) and np.array_equal(flag, np.nan_to_num(zh, nan=0) >= 1.25) and
              flag[inwin].mean() > 0.6 and flag[~inwin].mean() < 0.25,
              "t4 NIFTY's z and stress flag by a loop (stressed on %.0f%% of the stress stretches, %.0f%% elsewhere)" % (
                  100 * flag[inwin].mean(), 100 * flag[~inwin].mean()))
        # ------------------------------------------------------------------ t5 V2 (volume world)
        wv = Wd["volume"]
        Gv = M.prepare(args(wv["root"], wv["data"], wv["run"], tmp / "prep"), log=lambda *x: None)
        Pv = outputs(wv["d"])["P"]
        Vw, Cv, Ov = wv["W"]["V"], wv["W"]["C"], wv["W"]["O"]
        Xv = panel(wv["root"], wv["W"]["syms"], cal)
        rowv = {t_: i for i, t_ in enumerate(Gv["TS"]["bk"].ids)}
        fv2 = M.dip_fills(Gv["TS"], ["C1"], Gv["I"].atr_s1, Gv["I"].scale, None, Gv["I"].rv)
        b5 = b6 = blocked = 0
        for r in Pv.itertuples():
            s, t = spos[r.symbol], cal.get_loc(r.signal_day)
            br = rowv[r.trade_id]
            med = np.median(Vw[s, max(0, t - 19):t + 1])
            rv = {k: Vw[s, t + 1:t + k].mean() / med for k in range(2, 6)}
            rv[1] = 0.0
            b5 += not same([Gv["I"].rv[br, k] for k in range(1, 6)], [rv[k] for k in range(1, 6)], 1e-12)
            kg = hand_fill(cond["C1"] + [("m5_rvol", "<=", 1.5)], Xv, Cv, Ov, s, t, lambda k, rv=rv: rv[k],
                           lambda k, c=r.v1_scale: c)
            k1 = hand_fill(cond["C1"], Xv, Cv, Ov, s, t, None, lambda k, c=r.v1_scale: c)
            b6 += kg != fv2["C1"][0][br]
            blocked += (k1 > 0) and (kg != k1)
        check(b5 == 0 and b6 == 0 and blocked > 50,
              "t5 V2: every pick's volume ratios from the world's volumes (%d off) and C1's fills with the gate by the "
              "loop (%d off); the gate changes %d" % (b5, b6, blocked))
        # ------------------------------------------------------------------ t6 the M5 tree's routing (stress world)
        T = O_["T"]
        Tm = T[T["variant"] == "M5TREE"]
        lane = dict(zip(P["trade_id"], P["lane_m5"]))
        opens = Tm[Tm["how"] == "open"]
        ok6 = bool((opens["trade_id"].map(lane) == 0).all())
        ens_calm = set(P.loc[(P["engine"] == "ENS") & (P["lane_m5"] == 0), "trade_id"])
        ok6 &= set(opens.loc[opens["engine"] == "ENS", "trade_id"]) == ens_calm
        wlx = wl.set_index("trade_id")
        dP = P[P["engine"] == "D"].copy()
        dP["up"] = [wlx.at[t_, "entry"] >= wlx.at[t_, "signal_close"] for t_ in dP["trade_id"]]
        want_d = set()
        for _, g in dP[(dP["lane_m5"] == 0) & dP["up"]].groupby("signal_day"):
            want_d.add(g.sort_values("rank").iloc[0]["trade_id"])
        ok6 &= set(opens.loc[opens["engine"] == "D", "trade_id"]) == want_d
        f7 = {sid: TS["fills"][sid][0] for sid in M.TG.SETUPS}
        f7["S1"] = M.variant_fills(TS, I, M.VARIANTS["M5TREE"], {})["S1"][0]
        bad6 = 0
        setups = Tm[Tm["how"] != "open"]
        for r in setups.itertuples():
            br = rowof[r.trade_id]
            ks = [(f7[sid][br], j, sid) for j, sid in enumerate(M.TG.SETUPS) if f7[sid][br] > 0]
            k, _, sid = min(ks)
            t = cal.get_loc(r.signal_day)
            bad6 += not (sid == r.how and cal[t + k] == r.entry_day)
        jump_open = int(((Tm["how"] == "open") & (Tm["trade_id"].map(lane) == 1)).sum())
        ok6 &= bool((Tm["lane"] == np.where(Tm["trade_id"].map(lane) == 1, "jumpy", "calm")).all())
        check(ok6 and bad6 == 0 and jump_open == 0 and len(setups) > 200,
              "t6 the M5 tree's routing: open only when calm (%d jumpy opens), ENS every calm pick, D the first calm "
              "pick opening at or above the signal close; %d setup entries = the earliest of the seven fills (%d off)"
              % (jump_open, len(setups), bad6))
        skip = set(P.loc[P["v4_skip"].astype(bool), "trade_id"])
        T4, Tf = T[T["variant"] == "V4"], T[T["variant"] == "FROZEN"]
        kf = {(r.trade_id, r.entry_day, r.how) for r in Tf.itertuples() if r.engine == "ENS" and r.trade_id not in skip}
        k4 = {(r.trade_id, r.entry_day, r.how) for r in T4.itertuples() if r.engine == "ENS"}
        check(len(skip) > 300 and not (set(T4["trade_id"]) & skip) and kf == k4,
              "t6 V4: none of the %d picks in the window's bottom fifth is traded; ENS's other frozen trades all stay"
              % len(skip))
        # ------------------------------------------------------------------ t7 statistics by hand
        Vt = O_["V"]
        days = Dd["date"].to_numpy().astype("datetime64[ns]")
        B_ = SU.Boot(days, B=2000, block=10, seed=7)
        rf = Dd["r_FROZEN"].to_numpy()
        ok7 = True
        p1 = {}
        for v in ("M5TREE", "V1", "V2", "V3"):
            x = (np.log1p(Dd["r_" + v].to_numpy()) - np.log1p(rf)) * 1e4
            ms = np.array([x[ix].mean() for ix in B_.ix])
            lo, hi = np.percentile(ms, [2.5, 97.5])
            p = 1 - 0.5 * (1 + math.erf(x.mean() / ms.std(ddof=1) / math.sqrt(2)))
            p1[v] = p
            ok7 &= same([Vt.at[v, "diff"], Vt.at[v, "diff_lo"], Vt.at[v, "diff_hi"], Vt.at[v, "p_one"]],
                        [x.mean(), lo, hi, p], 1e-9)
        ps = sorted(("V1", "V2", "V3"), key=lambda v: p1[v])
        adj, run_ = {}, 0.0
        for i, v in enumerate(ps):
            run_ = max(run_, min(1.0, (3 - i) * p1[v]))
            adj[v] = run_
        for v in ("V1", "V2", "V3"):
            ok7 &= same(Vt.at[v, "p_holm"], adj[v], 1e-9)
            ok7 &= Vt.at[v, "verdict"] == ("PASS" if (adj[v] <= 0.025 and Vt.at[v, "fall"] <= Vt.at["FROZEN", "fall"])
                                           else "FAIL")

        def path(r):
            vv = np.r_[1.0, np.cumprod(1 + r)]
            yrs = (Dd["date"].iloc[-1] - Dd["date"].iloc[0]).days / 365.25
            return (vv[-1] ** (1 / yrs) - 1) * 100, 100 * np.max(1 - vv / np.maximum.accumulate(vv))
        for v in ("FROZEN", "M5TREE", "V3"):
            ok7 &= same([Vt.at[v, "a_year"], Vt.at[v, "fall"]], list(path(Dd["r_" + v].to_numpy())), 1e-9)
        m5 = Vt.loc["M5TREE"]
        ok7 &= m5["verdict"] == ("PASS" if (m5["diff_lo"] > 0 and m5["fall"] <= Vt.at["FROZEN", "fall"]) else "FAIL")
        ok7 &= all(Vt.at[v, "verdict"] == "shown only" for v in ("LANE", "S1M5", "LANEMIX", "V4", "ALL"))
        ok7 &= Dd["date"].iloc[0] == cal[cal >= pd.Timestamp(M.START)][0]
        check(ok7, "t7 the period from the first session of 2023; the gains, their intervals (a loop over the 2,000 resamples), one-sided p's, Holm, the verdicts, "
                   "a year and worst fall by hand")
        def row(p, fall, lo=1.0):
            return {"p_one": p, "fall": fall, "diff_lo": lo}
        rr = {"FROZEN": {"fall": 20.0}, "M5TREE": row(0.01, 20.0, 0.1), "V1": row(0.008, 19.0), "V2": row(0.016, 21.0),
              "V3": row(0.021, 20.0), "LANE": row(0.0, 1.0), "S1M5": row(0.0, 1.0), "LANEMIX": row(0.0, 1.0),
              "V4": row(0.0, 1.0), "ALL": row(0.0, 1.0)}
        M.decide(rr, rr["FROZEN"])
        # Holm: 0.008 x 3 = 0.024 PASS; 0.016 x 2 = 0.032 FAIL (and its fall is deeper); 0.021 -> max(0.032, 0.021) FAIL
        ok_d = ([rr[v]["verdict"] for v in ("M5TREE", "V1", "V2", "V3")] == ["PASS", "PASS", "FAIL", "FAIL"] and
                same([rr[v]["p_holm"] for v in ("V1", "V2", "V3")], [0.024, 0.032, 0.032], 1e-12))
        rr2 = {k: dict(v) for k, v in rr.items()}
        rr2["M5TREE"].update(fall=20.5)
        rr2["V2"].update(p_one=0.004, fall=20.0)
        M.decide(rr2, rr2["FROZEN"])
        ok_d &= [rr2[v]["verdict"] for v in ("M5TREE", "V1", "V2")] == ["FAIL", "PASS", "PASS"]
        rr3 = {k: dict(v) for k, v in rr.items()}
        rr3["M5TREE"].update(diff_lo=-0.01)
        rr3["V1"].update(p_one=0.0125)                             # x 3 = 0.0375: inside 0.05, outside 0.025
        M.decide(rr3, rr3["FROZEN"])
        ok_d &= rr3["M5TREE"]["verdict"] == "FAIL" and rr3["V1"]["verdict"] == "FAIL"
        check(ok_d, "t7 the decision rules on hand-made rows: Holm x3 / x2, the 0.025 line, the worst-fall condition, "
                    "the interval's lower end")
        # ------------------------------------------------------------------ t8 identity
        wa = Wd["absent"]
        Ga = M.prepare(args(wa["root"], wa["data"], wa["run"], tmp / "prep"), log=lambda *x: None)
        Iid = M.Inputs(Ga["TS"], Ga["U"], np.full(Ga["U"].nu, np.nan), Ga["rv_u"], Ga["stress_bk"])
        a_ = M.run_variant(Ga["TS"], Ga["U"], Ga["PA"], Iid, "ALL", {}, Ga["p0"], Ga["t1"])
        f_ = M.run_variant(Ga["TS"], Ga["U"], Ga["PA"], Ga["I"], "FROZEN", {}, Ga["p0"], Ga["t1"])
        same8 = all(np.array_equal(a_["Ts"][e][k], f_["Ts"][e][k]) for e in ("D", "ENS") for k in ("ent", "ex", "tid"))
        run_checks = json.loads((wa["d"] / "RUN.json").read_text(encoding="utf-8"))["checks"]
        Bk = {}
        for e, Eg, calm in (("D", Ga["TS"]["ED"], "first_up"), ("ENS", Ga["TS"]["EE"], "all")):
            Tz, _ = M.TG.frozen_trades(Ga["U"], Ga["PA"], Ga["TS"]["bk"], Eg, calm, Ga["TS"]["primary"])
            Bk[e] = VL.book_sim2(Tz, Ga["PA"].C, Ga["p0"], Ga["t1"])[1]
        r_fz = VL.account_returns(Bk["D"], Bk["ENS"], Ga["TS"]["bk"].cal, Ga["p0"], Ga["t1"])
        Da = outputs(wa["d"])["D"]
        same8 = same8 and same(Da["r_FROZEN"], r_fz, 1e-9)
        check(same8 and np.array_equal(a_["r"], f_["r"]) and "reproduces the frozen trades" in run_checks["identity"],
              "t8 without forecasts the M5 lanes and every M5 dip give the frozen trades and books exactly; the frozen "
              "tree's daily returns = triggerlab's frozen trades through vollab's books")
        # ------------------------------------------------------------------ t9 planted and absent
        v = {k: outputs(Wd[k]["d"])["V"] for k in MW.KINDS}
        res = json.loads((Wd["stress"]["d"] / "M5TREE_RESULT.json").read_text(encoding="utf-8"))
        v3v1 = res["vs_v1"]["V3"]
        check(v["lane"].at["M5TREE", "verdict"] == "PASS",
              "t9 LANE world: M5TREE PASS (%+.2f bp a day [%+.2f, %+.2f])" % tuple(
                  v["lane"].loc["M5TREE", ["diff", "diff_lo", "diff_hi"]]))
        check(v["ruler"].at["V1", "verdict"] == "PASS",
              "t9 RULER world: V1 PASS (%+.2f bp a day [%+.2f, %+.2f])" % tuple(
                  v["ruler"].loc["V1", ["diff", "diff_lo", "diff_hi"]]))
        check(v["volume"].at["V2", "verdict"] == "PASS" and v["volume"].at["V1", "verdict"] == "FAIL",
              "t9 VOLUME world: V2 PASS (%+.2f bp a day), V1 FAIL (%+.2f)" % (v["volume"].at["V2", "diff"],
                                                                         v["volume"].at["V1", "diff"]))
        check(v["stress"].at["V3", "verdict"] == "PASS" and v3v1["diff_lo"] > 0,
              "t9 STRESS world: V3 PASS (%+.2f bp a day), above V1 by %+.2f [%+.2f, %+.2f]" % (
                  v["stress"].at["V3", "diff"], v3v1["diff"], v3v1["diff_lo"], v3v1["diff_hi"]))
        ab = v["absent"]
        check(all(ab.at[x, "verdict"] == "FAIL" for x in ("M5TREE", "V1", "V2", "V3")),
              "t9 ABSENT world: M5TREE, V1, V2 and V3 all FAIL")
        # ------------------------------------------------------------------ t10 refusals and outputs
        root, data, run = wa["root"], wa["data"], wa["run"]
        empty = tmp / "emptyrun"
        empty.mkdir()
        nocol = tmp / "nocol"
        nocol.mkdir()
        pd.read_csv(run / "pick_forecasts.csv").drop(columns=["sigma5_M5_pct"]).to_csv(nocol / "pick_forecasts.csv",
                                                                                      index=False)
        o10 = tmp / "o10"
        with redirect_stdout(io.StringIO()) as b10:
            r1 = M.main(["--root", str(root), "--data", str(data), "--run", str(empty), "--out", str(o10),
                         "--stage-e-any"])
            r2 = M.main(["--root", str(root), "--data", str(data), "--run", str(nocol), "--out", str(o10),
                         "--stage-e-any"])
            r3 = M.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(root / "x"),
                         "--stage-e-any"])
            r4 = M.main(["--root", str(root), "--data", str(data), "--run", str(run), "--out", str(o10),
                         "--stage-e-any", "--check-only"])
        txt = b10.getvalue()
        nothing = not list(o10.glob("M5TREE_*")) and not (root / "x").exists()
        dd = json.loads((HERE.parent / M.DECL_FILE).read_text(encoding="utf-8"))
        dd["part_2"]["V2"] = dd["part_2"]["V2"].replace("1.5 x", "2 x")
        ed = tmp / "edited.json"
        ed.write_text(json.dumps(dd), encoding="utf-8")
        try:
            M.load_declaration(ed)
            refused_decl = False
        except M.M5Error:
            refused_decl = True
        check(r1 == 3 and r2 == 3 and r3 == 3 and r4 == 0 and nothing and refused_decl and "CHECK OK" in txt and
              txt.count("REFUSED") == 3,
              "t10 refused: no pick_forecasts.csv, no M5 column, --out inside the cache, an edited declaration; "
              "--check-only writes nothing")
        d = wa["d"]
        hs = (d / "outputs.sha256").read_text(encoding="utf-8").split("\n")
        okh = all(hashlib.sha256((d / ln.split("  ")[1]).read_bytes()).hexdigest() == ln.split("  ")[0]
                  for ln in hs if ln.strip())
        led = [json.loads(x) for x in (wa["out"] / "vollab_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        md = (d / "M5TREE.md").read_text(encoding="utf-8")
        secs = all(x in md for x in ("## Verdict", "## Every tree", "### The lanes", "### S1's dip",
                                     "### Trades actually taken", "### Each lane", "## Part 2 in detail",
                                     "## Diagnostic", "## Checks"))
        check(okh and len(hs) >= 9 and [x["event"] for x in led] == ["start", "end"] and secs,
              "t10 every output's sha256 matches outputs.sha256; the ledger's start and end; the report's sections")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print("FAILED: %d of %d checks" % (len(FAILS), len(FAILS) + N_OK[0]))
        return 1
    print("VERIFIED (%s) - %d checks" % (M.VERSION, N_OK[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
