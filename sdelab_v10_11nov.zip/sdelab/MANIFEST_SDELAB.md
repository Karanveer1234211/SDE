# MANIFEST - sdelab v1.0

11 Nov 2026: a separate experiment from BigMove - SDE (signed directional efficiency) on the whole NSE universe, declared before any run (SDE_DECLARATION.json, sha256 below). Lives beside tradelab (PyCharmMiscProject\sdelab), reads the cache through tradelab's tl_data / production's stage E read only, writes only under C:\QuantData\sdelab. Needs tradelab v1.3.1 + setups add-on v1.4 (tl_setups.sde_series).

| file | version | sha256 (16) | role |
|---|---|---|---|
| sdelab.py | sdelab v1.0 | 5f16109db33a1960 | COMMAND: check (the frozen declaration) / run (the declared study on the whole universe): features, honest exits, 120 tests, books, REPORT.md |
| SDE_DECLARATION.json | frozen 2026-11-11 | a3017eb71c798be4 | the study: theory, universe, 5 environments + control, 10 entries, 2 exits, 2 periods, statistics, decision rules; sdelab.py refuses any other sha256 |
| env_sdelab.bat | sdelab v1.0 | 43b5fcebcab959a1 | session setup (CRLF): CACHE_DAILY_ROOT via env_daily.bat, SDELAB_OUT=C:\QuantData\sdelab, PYTHONPATH sdelab;tradelab;open_close;bigmove_deploy |
| README_SDELAB.md | sdelab v1.0 | 38cea5f57254c699 | the theory, the environments, the decision, how to run, the outputs |
| tests/test_sdelab.py | sdelab v1.0 | 48397a870e53bc27 | 12 checks on synthetic worlds (planted / absent); must end VERIFIED (sdelab v1.0) |

Declaration sha256 (full): a3017eb71c798be4903afea67d24ee86196a802be35dbaeb5f606b9e4f46ecb7

Verified here: 12 checks, 0 failures (pandas 3.0.5 / numpy 2.5.3 and pandas 2.3.3 / numpy 2.4.1); 12 planted bugs each caught (look-ahead SDE, entry at the signal open, locks ignored, target before stop, cooldown, Bonferroni off, market mean for median, excess against the wrong baseline, the book's priority, the years rule, the ETF filter, stuck exits); a 300-stock neutral universe (814k stock-days) gives no survivor.
