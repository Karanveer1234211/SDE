# sdelab v1.0 — SDE on the whole NSE universe (separate from BigMove)

**Question.** Is signed directional efficiency (SDE) an entry signal across the whole universe, not just among BigMove's picks? Which of five theory-chosen environments, which SDE entries and which SDE-specific setups beat buying every eligible stock on the same dates? Does that hold out of sample (2016–2020, never used by the SDE research) and in replication (2021 on)? And does the best of them make money in a 3-position book?

Everything the run does is in **`SDE_DECLARATION.json`**, frozen on 11 Nov 2026 before any run (sha256 `a3017eb71c798be4…`). `sdelab.py` refuses any other declaration file. A changed study is a new declaration.

## The theory

SDE_N = (close(t) − close(t−N)) / the sum of the N absolute close-to-close moves to t. It is the share of the path that was net progress: −1 means every move was down (one-sided selling), +1 means every move was up. It measures how one-sided trading was, not how big the move was.

There are two competing theories:
- **Price pressure, then a bounce.** A seller who is not trading on information pushes the price below value until they are done. Whoever supplies liquidity earns the rebound (Grossman–Miller 1988; Jegadeesh 1990; Lehmann 1990; Nagel 2012).
- **Informed selling, then continuation.** News priced in gradually keeps going (Da–Gurun–Warachka 2014, "frog in the pan").

An environment's job is to tilt the odds toward non-informational selling, using only what is known at the signal close.

| env | name | rule | why |
|-|-|-|-|
| E0 | control | every eligible stock-day | |
| E1 | lone seller, calm market | the day's median SDE10 > −0.2, and no single-day fall ≥ 2 ATR in the window | news arrives as gaps; small steps while the market is fine look like one seller working an order |
| E2 | dip in an intact uptrend | close > SMA200, SMA50 ≥ 1.02 × SMA200, SMA200 rising over 20 sessions | the long-run picture is positive; trend holders absorb the selling |
| E3 | stock volatility expansion | ATR% ≥ the 67th percentile of its own previous 252 sessions | a bigger dislocation should pay a bigger liquidity premium |
| E4 | market-wide stress | at least half of the eligible stocks are in their own top-third ATR% | when volatility is everywhere, liquidity providers withdraw and reversal profits rise (Nagel 2012) |
| E5 | heavy-volume selling | 10-session mean volume ≥ 1.5 × the 50 sessions before | moves on liquidity-driven volume reverse (Campbell–Grossman–Wang 1993) |

**Entries** (signal at the close, buy at the next open):
- SDE variants: N1 SDE10 < −0.5 · N2 SDE5 < −0.5 · N3 SDE20 < −0.5 · N4 SDE10 < −0.7 · N5 bottom 10% of SDE10 that day · N6 turn (SDE10 < −0.5 in the last 3 sessions and SDE3 ≥ 0 now).
- SDE setups: U1 reversal bar (up day, close in the top 30% of its range) · U2 thrust (close above yesterday's high after SDE10 < −0.5) · U3 climax (volume ≥ 2× the 50-session median).
- Opposite-theory check: P1 orderly rise (SDE10 > +0.5).

**Exits.** X1 sells at the 5th close. X2 uses a 2-ATR target and a 3-ATR stop within 5 sessions: if both are inside one bar, the stop counts; a later open beyond a level fills at that open; otherwise it sells at the 5th close. Exits are honest: a close locked at the lower circuit (production's stage E rule) sells at the first unlocked open within 20 sessions. Costs are 35 bp a round trip. After an event, a stock cannot fire again for 5 sessions.

**Universe.** The panel's symbols, without ETFs and indices (production's ETF rule). A stock-day is eligible with at least 260 bars of history, a close of at least Rs 20, a 20-day median turnover of at least Rs 2 crore, and a tradable next open.

## The decision (declared)

- **Excess** = the event's net − the same-date mean net of every eligible stock-day (same exit).
- **Incremental** = the event's net − the same date's mean in its own environment.

A combination is a **SURVIVOR** only if all of these hold:
- (A) Its excess has a Bonferroni lower bound above 0 in 2016–2020 (z = 3.53 for 120 tests).
- (B) Its excess has a 95% lower bound above 0 from 2021 on.
- (C) It beats its own environment: 95% lower bound above 0 in A, and a positive mean in B.
- (D) Its mean excess is positive in at least 8 of the 11 years.
- It has at least 300 events on 100 days in each period.

A survivor is **TRADEABLE** if, in both periods, its Rs 5 L 3-position book has:
- a positive CAGR;
- a CAGR above the mean of 10 random books drawn from the same environment;
- a worst drawdown no deeper than theirs.

Anything else is descriptive.

**Known bias.** The cache holds the stocks it holds today. Stocks delisted after a fall are probably missing, which flatters every buy-the-fall rule, most of all in 2016–2020.

## Install and run

Copy the `sdelab` folder to `C:\Users\karanvsi\PyCharmMiscProject\sdelab` (beside tradelab; it reads the cache through tradelab's `tl_data`). It writes only under `C:\QuantData\sdelab`.

```
call C:\Users\karanvsi\PyCharmMiscProject\sdelab\env_sdelab.bat
python tests\test_sdelab.py
python sdelab.py check
python sdelab.py run --root %CACHE_DAILY_ROOT%
```

The test must end with `VERIFIED (sdelab v1.0)` (about a minute). `check` prints the declaration's sha256. The run takes about 5–15 minutes. The estimate is from a 300-stock synthetic universe: 814k stock-days in 152 s, using about 350 MB.

Output goes to `C:\QuantData\sdelab\runs\SDE_<date>_<nnn>\`:

|file|what|
|-|-|
|REPORT.md|verdict first; the environments ranked; the survivors with their books; every test|
|verdicts.csv|the four conditions and the verdict for each of the 120 tests|
|results.csv|every test × period: events, days, net, excess (95% and Bonferroni), incremental, win rate|
|years.csv|mean excess by year|
|books.csv|each combination's book (CAGR, worst drawdown, trades) beside the random books|
|environments.csv|how often each environment occurs and what it pays as a whole|
|survivor_events.parquet|every event of the survivors|
|run.json, DECLARATION.json, outputs.sha256|provenance|

A line is appended to `C:\QuantData\sdelab\sdelab_ledger.jsonl` for every run.

## Tests (`tests/test_sdelab.py`, 12 checks)

- Hand calculations: features, honest and bracket exits, cooldown, the bootstrap and Bonferroni intervals, the verdict rules, a book.
- The run's rows are checked against the stock files: SDE at the signal close, entry at the next open, the 5th close.
- One combination is recomputed by hand from the rows.
- Planted world (random walks plus a bounce after orderly falls): the core entry survives and is tradeable; the opposite-theory check does not.
- Absent world (pure random walks): nothing survives. At 300 stocks (814k stock-days), the Bonferroni gate still let nothing through.
- 12 planted bugs, each caught. Passes on pandas 3.0.5 and 2.3.3.
