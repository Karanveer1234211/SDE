@echo off
rem env_sdelab.bat - sdelab v1.0 (SDE on the whole NSE universe, separate from BigMove): start a session in cmd.
rem   call C:\Users\karanvsi\PyCharmMiscProject\sdelab\env_sdelab.bat
rem Reads production (the daily cache, the panel's symbol list, stage E's loader and lower-circuit rule) READ ONLY,
rem through tradelab's tl_data. Writes only under SDELAB_OUT. Edit the paths below if your folders differ.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "SDELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\sdelab"
set "SDELAB_OUT=C:\QuantData\sdelab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_data.py" goto :no_tradelab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%SDELAB_DIR%;%TRADELAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%SDELAB_OUT%" mkdir "%SDELAB_OUT%"
cd /d "%SDELAB_DIR%"
echo sdelab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   SDELAB_OUT=%SDELAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_sdelab.bat
exit /b 1
:no_tradelab
echo ERROR: %TRADELAB_DIR%\tl_data.py not found - sdelab reads the cache through tradelab (edit TRADELAB_DIR)
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
