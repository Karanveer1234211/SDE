"""
sdelab.py - sdelab v1.0: signed directional efficiency (SDE) on the whole NSE universe, separate from BigMove.

    python sdelab.py check                                   the declaration file is the frozen one (sha256)
    python sdelab.py run --root %CACHE_DAILY_ROOT%           the declared study -> SDELAB_OUT\\SDE_<date>_<nnn>
                         [--panel <panel.parquet>] [--out <folder>] [--stage-e-any]

SDE_DECLARATION.json (beside this file, frozen 11 Nov 2026 before any run) holds everything the run does: the theory,
the universe, five environments chosen from SDE's theory (+ a control), ten entries (six SDE variants, three SDE
setups, one opposite-theory check), two exits, two periods (2016-2020 = out of sample for the SDE research; 2021 on =
its replication), the statistics and the decision rules. The tool refuses a declaration whose sha256 differs.

READS (read only): the daily cache through production's own loader and lower-circuit rule (stage_e_execution via
tradelab's tl_data), the panel's symbol list. WRITES only under --out / SDELAB_OUT (refused inside the cache or the
production code): SDE_<date>_<nnn>\\ REPORT.md, results.csv, years.csv, books.csv, environments.csv,
survivor_events.parquet, run.json, DECLARATION.json, outputs.sha256; and one line per run in sdelab_ledger.jsonl.

Every number: signal at the close of t, buy at the next session's open, honest exits (a close locked at the lower
circuit sells at the first open that is not, within 20 sessions), 35 bp a round trip. Statistics: circular block
bootstrap over signal days (blocks of 10, 2,000 draws, seed 7); Bonferroni across the declared 120 tests.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import statistics
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
try:
    import tl_common as TC
    import tl_data as TD
    import tl_setups as SU
except ImportError:                                       # beside tradelab: PyCharmMiscProject\sdelab, \tradelab
    sys.path.insert(0, str(HERE.parent / "tradelab"))
    import tl_common as TC
    import tl_data as TD
    import tl_setups as SU

VERSION = "sdelab v1.0"
DECL_FILE = HERE / "SDE_DECLARATION.json"
DECL_SHA = "a3017eb71c798be4903afea67d24ee86196a802be35dbaeb5f606b9e4f46ecb7"
LEDGER = "sdelab_ledger.jsonl"
ENVS = ("E0", "E1", "E2", "E3", "E4", "E5")
ENTRIES = ("N1", "N2", "N3", "N4", "N5", "N6", "U1", "U2", "U3", "P1")
EXITS = ("X1", "X2")
BIT = {k: 1 << i for i, k in enumerate(ENVS[1:] + ENTRIES)}      # E0 = every row
ETF_SUFFIX = ("BEES", "ETF", "IETF")
STATUS = ("ok", "stuck", "pending")
WHY = ("target", "stop", "time", "stuck", "pending")
INDEX_PREFIX = ("NIFTY", "INDIA", "SENSEX")


class SDEError(RuntimeError):
    pass


def say(msg: str) -> None:
    print(msg, flush=True)


# ---------------------------------------------------------------------------------------------------- declaration
def sha256(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_decl(path: Path = DECL_FILE, check: bool = True) -> Tuple[dict, str]:
    if not Path(path).is_file():
        raise SDEError(f"{path} is missing - it ships beside sdelab.py")
    sha = sha256(path)
    if check and sha != DECL_SHA:
        raise SDEError(f"{path} has sha256 {sha[:16]}, not the frozen declaration's {DECL_SHA[:16]}. The declaration "
                       f"is fixed before any run; a changed study is a new declaration (ask Claude).")
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    for k in ("environments", "entries", "exits", "periods", "stats", "decision", "book", "universe"):
        if k not in d:
            raise SDEError(f"{path}: '{k}' missing")
    if tuple(d["environments"]) != ENVS or tuple(d["entries"]) != ENTRIES or tuple(d["exits"]) != EXITS:
        raise SDEError(f"{path}: environments / entries / exits differ from the ones this code implements")
    if abs(float(d["sde"]["jump_guard"]) - SU.SDE_JUMP) > 1e-12 or tuple(d["sde"]["horizons"]) != SU.SDE_HORIZONS:
        raise SDEError("the declaration's SDE definition differs from tl_setups' sde_series")
    return d, sha


# ---------------------------------------------------------------------------------------------------- helpers
def roll(x: np.ndarray, n: int, how: str, shift: int = 0) -> np.ndarray:
    """Trailing window statistics (pandas, full windows only); shift=1 = the window ending at t-1."""
    s = pd.Series(np.asarray(x, float))
    if shift:
        s = s.shift(shift)
    r = s.rolling(n, min_periods=n)
    return {"mean": r.mean, "median": r.median, "max": r.max, "min": r.min}[how]().to_numpy(float) if how != "q67" \
        else r.quantile(0.67).to_numpy(float)


def lag(x: np.ndarray, k: int = 1) -> np.ndarray:
    out = np.full(len(x), np.nan)
    if k < len(x):
        out[k:] = np.asarray(x, float)[:-k]
    return out


def is_etf(sym: str, prod_rule=None) -> bool:
    if prod_rule is not None:
        try:
            return bool(prod_rule(sym))
        except Exception:
            pass
    s = sym.upper()
    return s.endswith(ETF_SUFFIX) or "ETF" in s or s.startswith(INDEX_PREFIX)


def etf_rule(root: Path):
    """production's research_common.is_etf_symbol (with its exclude file) when importable, else None (name rule)."""
    try:
        import research_common as RC
    except ImportError:
        return None, "the name rule (research_common not importable)"
    try:
        extra = RC.load_symbol_list(Path(root) / RC.UNIVERSE_EXCLUDE_FILE)
    except Exception:
        extra = set()
    return (lambda s: RC.is_etf_symbol(s, extra)), "production's research_common.is_etf_symbol"


# ---------------------------------------------------------------------------------------------------- one stock
def stock_features(o, h, l, c, v) -> Dict[str, np.ndarray]:
    """Every value known at the close of bar t (index t) - the declaration's features, entries' parts and the SDEs."""
    o, h, l, c, v = (np.asarray(x, float) for x in (o, h, l, c, v))
    n = len(c)
    F = {f"sde{k}": SU.sde_series(c, k) for k in SU.SDE_HORIZONS}
    pc = lag(c)
    tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
    tr[0] = h[0] - l[0] if n else np.nan
    atr = roll(tr, 14, "mean")
    with np.errstate(divide="ignore", invalid="ignore"):
        atrp = atr / c
    F["atr"], F["atrp"] = atr, atrp
    q67 = roll(atrp, 252, "q67", shift=1)
    F["v3_known"] = np.isfinite(q67) & np.isfinite(atrp)
    F["v3"] = F["v3_known"] & (atrp >= q67)
    sma50, sma200 = roll(c, 50, "mean"), roll(c, 200, "mean")
    F["uptrend"] = (c > sma200) & (sma50 >= 1.02 * sma200) & (sma200 > lag(sma200, 20))
    with np.errstate(invalid="ignore", divide="ignore"):
        drop = pc - c                                           # a fall is positive
        F["shock"] = roll(drop, 10, "max") / atr >= 2.0
        F["vol_ratio"] = roll(v, 10, "mean") / roll(v, 50, "mean", shift=10)
        F["climax"] = v >= 2.0 * roll(v, 50, "median", shift=1)
        F["reversal_bar"] = (c > o) & (h > l) & ((c - l) >= 0.7 * (h - l))
        F["thrust"] = c > lag(h)
        F["turnover"] = roll(c * v, 20, "median")
    F["sde10_prev"] = lag(F["sde10"])
    F["sde10_min3"] = roll(F["sde10"], 3, "min", shift=1)
    return F


def lock_arrays(ds) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Lower-circuit locks by production's rule, asked only where a lock is possible (the price at the day's low)."""
    n = len(ds.c)
    lc, lo = np.zeros(n, bool), np.zeros(n, bool)
    for i in np.flatnonzero(ds.c <= ds.l * (1 + 1e-9)):
        lc[i] = ds.locked(int(i), "close")
    for i in np.flatnonzero(ds.o <= ds.l * (1 + 1e-9)):
        lo[i] = ds.locked(int(i), "open")
    frozen = (ds.o == ds.h) & (ds.h == ds.l) & (ds.l == ds.c) & lc
    return lc, lo, frozen


def time_exit(x: np.ndarray, c, o, lc, lo, n: int, search: int = 20):
    """Sell at the close of bar x; locked -> the first unlocked open within `search` sessions; none -> the close of
    x + search ('stuck'); the data ending first -> 'pending'. Returns (bar, price, status)."""
    x = np.asarray(x, np.int64)
    bar = np.full(len(x), -1, np.int64)
    px = np.full(len(x), np.nan)
    st = np.full(len(x), "pending", dtype=object)
    inside = x < n
    xi = np.minimum(x, n - 1)
    plain = inside & ~lc[xi]
    bar[plain], px[plain], st[plain] = x[plain], c[xi[plain]], "ok"
    lk = inside & lc[xi]
    if lk.any():
        ul = np.flatnonzero(~lo)
        p = np.searchsorted(ul, x[lk] + 1)
        k = np.where(p < len(ul), ul[np.minimum(p, max(len(ul) - 1, 0))] if len(ul) else n, n)
        ok = k <= np.minimum(x[lk] + search, n - 1)
        stuck = ~ok & (x[lk] + search <= n - 1)
        idx = np.flatnonzero(lk)
        bar[idx[ok]], px[idx[ok]], st[idx[ok]] = k[ok], o[k[ok]], "ok"
        j = x[lk][stuck] + search
        bar[idx[stuck]], px[idx[stuck]], st[idx[stuck]] = j, c[j], "stuck"
    return bar, px, st


def bracket_exit(e: np.ndarray, atr: np.ndarray, o, h, l, c, lc, lo, frozen, n: int, hold: int, tgt_atr: float,
                 stop_atr: float, search: int = 20):
    """X2: target / stop from the entry open, checked bar by bar over the hold (a later open beyond a level fills at
    that open; both inside one bar = the stop; a frozen bar sells nothing); untouched = the time exit."""
    e = np.asarray(e, np.int64)
    m = len(e)
    entry = o[np.minimum(e, n - 1)]
    tgt, stp = entry + tgt_atr * atr, entry - stop_atr * atr
    bar = np.full(m, -1, np.int64)
    px = np.full(m, np.nan)
    st = np.full(m, "", dtype=object)
    done = np.zeros(m, bool)
    for k in range(hold):
        j = e + k
        jj = np.minimum(j, n - 1)
        act = (j < n) & ~done & ~frozen[jj]
        if k > 0:
            g = act & (o[jj] <= stp)
            bar[g], px[g], st[g], done[g] = j[g], o[jj[g]], "stop", True
            g = act & ~done & (o[jj] >= tgt)
            bar[g], px[g], st[g], done[g] = j[g], o[jj[g]], "target", True
        g = act & ~done & (l[jj] <= stp)
        bar[g], px[g], st[g], done[g] = j[g], stp[g], "stop", True
        g = act & ~done & (h[jj] >= tgt)
        bar[g], px[g], st[g], done[g] = j[g], tgt[g], "target", True
    rest = ~done
    if rest.any():
        b2, p2, s2 = time_exit(e[rest] + hold - 1, c, o, lc, lo, n, search)
        bar[rest], px[rest], st[rest] = b2, p2, np.where(s2 == "ok", "time", s2)
    status = np.where(np.isin(st, ["pending"]), "pending", np.where(st == "stuck", "stuck", "ok"))
    return bar, px, status, st


def stock_rows(sym: str, sid: int, ds, cal: np.ndarray, decl: dict) -> Tuple[Optional[pd.DataFrame], np.ndarray]:
    """The stock's eligible signal days with every flag and both exits; and its closes on the market calendar."""
    U, X = decl["universe"], decl["exits"]
    cost = decl["cost_bp"] / 1e4
    o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
    v = np.asarray(ds.v, float) if ds.v is not None else np.full(len(c), np.nan)
    n = len(c)
    ci = np.searchsorted(cal, ds.dates)
    on_cal = (ci < len(cal)) & (cal[np.minimum(ci, len(cal) - 1)] == ds.dates)
    closes = np.full(len(cal), np.nan, np.float32)
    closes[ci[on_cal]] = c[on_cal]
    closes = pd.Series(closes).ffill().to_numpy(np.float32)
    if n < U["min_history_bars"] + 2:
        return None, closes
    F = stock_features(o, h, l, c, v)
    t = np.arange(n)
    nxt_ok = np.zeros(n, bool)
    nxt_ok[:-1] = on_cal[:-1] & on_cal[1:] & (ci[1:] == ci[:-1] + 1) & \
        ~((o[1:] == h[1:]) & (h[1:] == l[1:]) & (l[1:] == c[1:]))
    with np.errstate(invalid="ignore"):
        elig = (t >= U["min_history_bars"] - 1) & nxt_ok & (c >= U["min_close_rs"]) & (h >= l) & (l > 0) & \
            (F["turnover"] >= U["min_median_turnover_rs"])
    idx = np.flatnonzero(elig)
    if not len(idx):
        return None, closes
    lc, lo, frozen = lock_arrays(ds)
    e = idx + 1
    b1, p1, s1 = time_exit(e + X["X1"]["hold"] - 1, c, o, lc, lo, n)
    b2, p2, s2, why2 = bracket_exit(e, F["atr"][idx], o, h, l, c, lc, lo, frozen, n, X["X2"]["hold"],
                                    X["X2"]["target_atr"], X["X2"]["stop_atr"])
    entry = o[e]
    s10 = F["sde10"][idx]
    flags = np.zeros(len(idx), np.int64)
    with np.errstate(invalid="ignore"):
        parts = {
            "E2": F["uptrend"][idx], "E3": F["v3"][idx], "E5": F["vol_ratio"][idx] >= 1.5,
            "N1": s10 < -0.5, "N2": F["sde5"][idx] < -0.5, "N3": F["sde20"][idx] < -0.5, "N4": s10 < -0.7,
            "N6": (F["sde10_min3"][idx] < -0.5) & (F["sde3"][idx] >= 0),
            "U1": (s10 < -0.5) & F["reversal_bar"][idx], "U2": (F["sde10_prev"][idx] < -0.5) & F["thrust"][idx],
            "U3": (s10 < -0.5) & F["climax"][idx], "P1": s10 > 0.5}
    for k, m in parts.items():
        flags |= np.where(np.asarray(m, bool), BIT[k], 0)
    def cal_of(b):
        return np.where(b >= 0, ci[np.clip(b, 0, n - 1)], -1)
    R = pd.DataFrame({
        "sym": np.full(len(idx), sid, np.int32), "t": ci[idx].astype(np.int32), "e": ci[e].astype(np.int32),
        "entry": entry, "sde10": s10.astype(np.float32), "turnover": F["turnover"][idx].astype(np.float32),
        "v3": F["v3"][idx], "v3_known": F["v3_known"][idx], "shock": F["shock"][idx], "flags": flags,
        "x1_cal": cal_of(b1).astype(np.int32), "x1_net": (p1 / entry - 1 - cost).astype(np.float64),
        "x1_status": pd.Categorical(s1, categories=STATUS),
        "x2_cal": cal_of(b2).astype(np.int32), "x2_net": (p2 / entry - 1 - cost).astype(np.float64),
        "x2_status": pd.Categorical(s2, categories=STATUS), "x2_why": pd.Categorical(why2, categories=WHY)})
    return R, closes


# ---------------------------------------------------------------------------------------------------- the universe
def universe_symbols(panel: Path, rule) -> Tuple[List[str], int]:
    if not Path(panel).is_file():
        raise SDEError(f"panel {panel} not found (--panel, default %CACHE_DAILY_ROOT%\\panel\\panel.parquet)")
    s = pd.read_parquet(panel, columns=["symbol"])["symbol"].astype(str).str.strip().unique()
    keep = sorted(x for x in s if x and not is_etf(x, rule))
    return keep, int(len(s) - len(keep))


def build(root: Path, panel: Path, decl: dict, stage_e_any: bool, log=say) -> dict:
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    cal = np.asarray(market.cal).astype("datetime64[D]")
    rule, rule_txt = etf_rule(root)
    syms, dropped = universe_symbols(panel, rule)
    log(f"universe: {len(syms):,} symbols from {Path(panel).name} ({dropped:,} ETFs / indices left out by {rule_txt}); "
        f"calendar {len(cal):,} sessions {cal[0]}..{cal[-1]}")
    frames, closes, missing = [], [], []
    t0 = time.time()
    for k, s in enumerate(syms):
        ds = market.series(s)
        if ds is None or len(ds.c) == 0:
            missing.append(s)
            closes.append(np.full(len(cal), np.nan, np.float32))
            continue
        R, cl = stock_rows(s, k, ds, cal, decl)
        closes.append(cl)
        if R is not None:
            frames.append(R)
        market.daily.pop(s, None)                         # memory stays flat
        if k and k % 200 == 0:
            log(f"   {k:,} of {len(syms):,} stocks ({time.time() - t0:.0f}s)")
    if not frames:
        raise SDEError("no eligible stock-days in the universe")
    A = pd.concat(frames, ignore_index=True)
    # the market on each day (eligible stocks only)
    g = A.groupby("t")
    med = g["sde10"].median()
    p10 = g["sde10"].quantile(0.10)
    v3s = A[A["v3_known"]].groupby("t")["v3"].mean()
    A["mkt_sde10"] = A["t"].map(med).astype(np.float32)
    A["mkt_v3_share"] = A["t"].map(v3s).astype(np.float32)
    A["sde10_p10"] = A["t"].map(p10).astype(np.float32)
    with np.errstate(invalid="ignore"):
        A["flags"] |= np.where((A["mkt_sde10"] > -0.2) & ~A["shock"].astype(bool), BIT["E1"], 0)
        A["flags"] |= np.where(A["mkt_v3_share"] >= 0.5, BIT["E4"], 0)
        A["flags"] |= np.where(A["sde10"] <= A["sde10_p10"], BIT["N5"], 0)
    A["year"] = pd.DatetimeIndex(cal[A["t"].to_numpy()]).year.astype(np.int16)
    return {"rows": A, "closes": np.vstack(closes), "syms": syms, "cal": cal, "missing": missing,
            "etf_rule": rule_txt, "dropped": dropped, "prod": prod.describe()}


# ---------------------------------------------------------------------------------------------------- statistics
def env_mask(A: pd.DataFrame, env: str) -> np.ndarray:
    return np.ones(len(A), bool) if env == "E0" else (A["flags"].to_numpy() & BIT[env]) > 0


def cooldown(sym: np.ndarray, t: np.ndarray, gap: int) -> np.ndarray:
    """Rows (sorted by symbol then day) kept when a stock fires again only `gap` sessions after its last kept fire."""
    keep = np.zeros(len(t), bool)
    last_s, last_t = -1, -10 ** 9
    for i in range(len(t)):
        if sym[i] != last_s or t[i] >= last_t + gap:
            keep[i] = True
            last_s, last_t = sym[i], t[i]
    return keep


def period_mask(cal: np.ndarray, t: np.ndarray, per: List[Optional[str]]) -> np.ndarray:
    d = cal[t]
    m = d >= np.datetime64(per[0])
    if per[1]:
        m &= d <= np.datetime64(per[1])
    return m


def boot(days: np.ndarray, vals: np.ndarray, st: dict, z: float) -> dict:
    """Mean per event; circular block bootstrap over signal days: 95% percentile interval and mean +- z x sd."""
    ok = np.isfinite(vals)
    v, d = vals[ok], days[ok]
    out = {"n": int(len(v)), "days": 0, "mean": np.nan, "lo": np.nan, "hi": np.nan, "bonf_lo": np.nan,
           "bonf_hi": np.nan}
    if not len(v):
        return out
    u, inv = np.unique(d, return_inverse=True)
    S = np.bincount(inv, weights=v, minlength=len(u))
    N = np.bincount(inv, minlength=len(u)).astype(float)
    out.update({"days": int(len(u)), "mean": float(S.sum() / N.sum())})
    if len(u) < 20:
        return out
    b = st["bootstrap"]
    I = TC.circular_block_index(len(u), b["B"], b["block"], b["seed"])
    s = S[I].sum(1) / N[I].sum(1)
    sd = float(np.std(s, ddof=1))
    out.update({"lo": float(np.percentile(s, 2.5)), "hi": float(np.percentile(s, 97.5)),
                "bonf_lo": out["mean"] - z * sd, "bonf_hi": out["mean"] + z * sd})
    return out


def evaluate(D: dict, decl: dict, log=say) -> dict:
    A, cal = D["rows"], D["cal"]
    st = decl["stats"]
    z = statistics.NormalDist().inv_cdf(1 - st["alpha"] / (2 * st["tests"]))
    gap = int(decl["cooldown_sessions"])
    per = decl["periods"]
    A = A.sort_values(["sym", "t"], kind="mergesort").reset_index(drop=True)
    usable = {x: A[f"{x.lower()}_status"].isin(["ok", "stuck"]).to_numpy() for x in EXITS}
    base = {}
    for x in EXITS:
        net = A[f"{x.lower()}_net"].where(usable[x])
        base[("U", x)] = net.groupby(A["t"]).mean()
        for env in ENVS:
            m = env_mask(A, env)
            base[(env, x)] = net[m].groupby(A["t"][m]).mean()
    # how often each environment occurs and what it pays as a whole
    envrows = []
    for env in ENVS:
        m = env_mask(A, env)
        for pk, pv in per.items():
            pm = period_mask(cal, A["t"].to_numpy(), pv)
            r = {"env": env, "name": decl["environments"][env]["name"], "period": pk,
                 "share_of_stock_days": float((m & pm).sum() / max(pm.sum(), 1)), "stock_days": int((m & pm).sum())}
            for x in EXITS:
                ex = (A[f"{x.lower()}_net"] - A["t"].map(base[("U", x)])).to_numpy(float)
                ok = m & pm & usable[x]
                r[f"{x}_net_mean"] = float(np.nanmean(A[f"{x.lower()}_net"].to_numpy(float)[ok])) if ok.any() else np.nan
                r[f"{x}_excess_mean"] = float(np.nanmean(ex[ok])) if ok.any() else np.nan
            envrows.append(r)
    rows, years, events = [], [], {}
    T, SY = A["t"].to_numpy(), A["sym"].to_numpy()
    fl = A["flags"].to_numpy()
    for env in ENVS:
        em = env_mask(A, env)
        for en in ENTRIES:
            m = em & ((fl & BIT[en]) > 0)
            idx = np.flatnonzero(m)
            keep = idx[cooldown(SY[idx], T[idx], gap)]
            events[(env, en)] = keep
            for x in EXITS:
                kk = keep[usable[x][keep]]
                net = A[f"{x.lower()}_net"].to_numpy(float)[kk]
                ex = net - A["t"].iloc[kk].map(base[("U", x)]).to_numpy(float)
                inc = net - A["t"].iloc[kk].map(base[(env, x)]).to_numpy(float)
                for pk, pv in per.items():
                    pm = period_mask(cal, T[kk], pv)
                    r = {"env": env, "entry": en, "exit": x, "period": pk}
                    bx = boot(T[kk][pm], ex[pm], st, z)
                    bi = boot(T[kk][pm], inc[pm], st, z)
                    r.update({"events": bx["n"], "days": bx["days"],
                              "net_mean": float(np.mean(net[pm])) if pm.any() else np.nan,
                              "win_rate": float(np.mean(net[pm] > 0)) if pm.any() else np.nan,
                              "excess_mean": bx["mean"], "excess_lo": bx["lo"], "excess_hi": bx["hi"],
                              "excess_bonf_lo": bx["bonf_lo"], "excess_bonf_hi": bx["bonf_hi"],
                              "incr_mean": bi["mean"], "incr_lo": bi["lo"], "incr_hi": bi["hi"]})
                    rows.append(r)
                yr = A["year"].to_numpy()[kk]
                for y in range(2016, 2027):
                    ym = yr == y
                    years.append({"env": env, "entry": en, "exit": x, "year": y, "events": int(ym.sum()),
                                  "excess_mean": float(np.mean(ex[ym])) if ym.any() else np.nan})
        log(f"   {env}: {len(ENTRIES)} entries x {len(EXITS)} exits tested")
    R, Y = pd.DataFrame(rows), pd.DataFrame(years)
    V = verdicts(R, Y, decl)
    return {"results": R, "years": Y, "verdicts": V, "env": pd.DataFrame(envrows), "events": events, "z": z,
            "rows": A, "base": base, "usable": usable}


def verdicts(R: pd.DataFrame, Y: pd.DataFrame, decl: dict) -> pd.DataFrame:
    st = decl["stats"]
    out = []
    for (env, en, x), g in R.groupby(["env", "entry", "exit"], sort=False):
        a, b = g[g["period"] == "A"].iloc[0], g[g["period"] == "B"].iloc[0]
        y = Y[(Y["env"] == env) & (Y["entry"] == en) & (Y["exit"] == x)]
        ypos = int(((y["events"] >= st["year_min_events"]) & (y["excess_mean"] > 0)).sum())
        enough = all(p["events"] >= st["min_events"] and p["days"] >= st["min_days"] for p in (a, b))
        cA = bool(enough and a["excess_bonf_lo"] > 0)          # a test with too few events passes nothing
        cB = bool(enough and b["excess_lo"] > 0)
        cC = bool(enough and a["incr_lo"] > 0 and b["incr_mean"] > 0)
        cD = ypos >= 8
        surv = enough and cA and cB and cC and cD
        why = "SURVIVOR" if surv else ("TOO FEW EVENTS" if not enough else
                                       "fails " + ", ".join(k for k, ok in (("A", cA), ("B", cB), ("C", cC), ("D", cD))
                                                            if not ok))
        out.append({"env": env, "entry": en, "exit": x, "A_out_of_sample": cA, "B_replication": cB,
                     "C_beats_env": cC, "D_years_positive": ypos, "enough": enough, "survivor": surv, "verdict": why})
    return pd.DataFrame(out)


# ---------------------------------------------------------------------------------------------------- books
def book(c: dict, closes: np.ndarray, cal: np.ndarray, per: List[Optional[str]], capital: float,
         slots: int) -> dict:
    """A slots-position book: candidates (arrays e, x, sym, entry, net, in priority order within each entry day) bought
    at the open with 1/slots of the closed value (never more than the cash), one position per stock, realised on the
    exit day, marked at each close."""
    d0 = int(np.searchsorted(cal, np.datetime64(per[0])))
    d1 = int(np.searchsorted(cal, np.datetime64(per[1]), side="right") - 1) if per[1] else len(cal) - 1
    if d1 <= d0:
        return {"cagr": np.nan, "max_dd": np.nan, "trades": 0}
    order = np.argsort(c["e"], kind="mergesort")             # stable: the priority within a day is kept
    e, x, sy, en, nt = (c[k][order] for k in ("e", "x", "sym", "entry", "net"))
    p = 0
    cash = closed = float(capital)
    held: List[list] = []
    vals = np.empty(d1 - d0 + 1)
    trades = 0
    for di, d in enumerate(range(d0, d1 + 1)):
        end = int(np.searchsorted(e, d, side="right"))
        p = max(p, int(np.searchsorted(e, d)))
        while p < end and len(held) < slots:              # full book: today's candidates are skipped at once
            if not any(h_[0] == sy[p] for h_ in held):
                a = min(closed / slots, cash)
                if a > 0:
                    cash -= a
                    held.append([sy[p], a, en[p], x[p], nt[p]])
                    trades += 1
            p += 1
        p = end
        mv, keep = 0.0, []
        for h_ in held:
            if h_[3] == d:
                cash += h_[1] * (1 + h_[4])
                closed += h_[1] * h_[4]
            else:
                cl = closes[h_[0], d]
                mv += h_[1] * (cl / h_[2] if np.isfinite(cl) and h_[2] > 0 else 1.0)
                keep.append(h_)
        held = keep
        vals[di] = cash + mv
    yrs = (cal[d1] - cal[d0]).astype("timedelta64[D]").astype(float) / 365.25
    cagr = (vals[-1] / capital) ** (1 / yrs) - 1 if yrs > 0 and vals[-1] > 0 else np.nan
    dd = float((vals / np.maximum.accumulate(vals) - 1).min())
    return {"cagr": float(cagr), "max_dd": dd, "trades": trades, "final": float(vals[-1])}


def candidates(A: pd.DataFrame, idx: np.ndarray, x: str, order: np.ndarray) -> dict:
    k = idx[order]
    return {"e": A["e"].to_numpy()[k], "x": A[f"{x.lower()}_cal"].to_numpy()[k], "sym": A["sym"].to_numpy()[k],
            "entry": A["entry"].to_numpy()[k], "net": A[f"{x.lower()}_net"].to_numpy(float)[k]}


def rank_order(A: pd.DataFrame, ev: np.ndarray, entry: str) -> np.ndarray:
    """The book's priority among one entry day's candidates: SDE10 ascending (P1: descending), then 20-day turnover
    descending, then symbol."""
    s10 = A["sde10"].to_numpy(float)[ev]
    key = -s10 if entry == "P1" else s10
    return np.lexsort((A["sym"].to_numpy()[ev], -A["turnover"].to_numpy(float)[ev], key, A["e"].to_numpy()[ev]))


def books(D: dict, E: dict, decl: dict, log=say) -> pd.DataFrame:
    A, cal, cl = E["rows"], D["cal"], D["closes"]
    B = decl["book"]
    cap, slots = float(B["capital_rs"]), int(B["positions"])
    out = []
    base_cache = {}
    for x in EXITS:
        use = E["usable"][x]
        for env in ENVS:
            pool = np.flatnonzero(env_mask(A, env) & use)
            for pk, pv in decl["periods"].items():
                res = []
                for seed in range(1, 11):
                    rk = np.random.default_rng(seed).random(len(pool))
                    o = np.lexsort((rk, A["e"].to_numpy()[pool]))
                    res.append(book(candidates(A, pool, x, o), cl, cal, pv, cap, slots))
                base_cache[(env, x, pk)] = (float(np.nanmean([r["cagr"] for r in res])),
                                            float(np.nanmean([r["max_dd"] for r in res])),
                                            float(np.nanmin([r["cagr"] for r in res])),
                                            float(np.nanmax([r["cagr"] for r in res])))
        for (env, en), ev in E["events"].items():
            ev = ev[E["usable"][x][ev]]
            o = rank_order(A, ev, en)
            for pk, pv in decl["periods"].items():
                r = book(candidates(A, ev, x, o), cl, cal, pv, cap, slots)
                bm, bd, blo, bhi = base_cache[(env, x, pk)]
                out.append({"env": env, "entry": en, "exit": x, "period": pk, "cagr": r["cagr"], "max_dd": r["max_dd"],
                            "trades": r["trades"], "random_cagr_mean": bm, "random_max_dd_mean": bd,
                            "random_cagr_min": blo, "random_cagr_max": bhi})
        log(f"   books for {x} done")
    return pd.DataFrame(out)


def tradeable(V: pd.DataFrame, BK: pd.DataFrame) -> pd.DataFrame:
    V = V.copy()
    ok = []
    for r in V.itertuples(index=False):
        g = BK[(BK["env"] == r.env) & (BK["entry"] == r.entry) & (BK["exit"] == r.exit)]
        good = len(g) == 2 and all(
            (b.cagr > 0) and (b.cagr > b.random_cagr_mean) and (b.max_dd >= b.random_max_dd_mean)
            for b in g.itertuples(index=False))
        ok.append(bool(r.survivor and good))
    V["tradeable"] = ok
    return V


# ---------------------------------------------------------------------------------------------------- report
def pct(x, nd=2) -> str:
    return "-" if x is None or not np.isfinite(x) else f"{x * 100:+.{nd}f}%"


def bp(m, lo=np.nan, hi=np.nan) -> str:
    if not np.isfinite(m):
        return "-"
    s = f"{m * 1e4:+.1f}"
    return s + (f" [{lo * 1e4:+.1f}, {hi * 1e4:+.1f}]" if np.isfinite(lo) and np.isfinite(hi) else "")


def report(D: dict, E: dict, V: pd.DataFrame, BK: pd.DataFrame, decl: dict, sha: str, secs: float) -> str:
    R, cal = E["results"], D["cal"]
    surv = V[V["survivor"]]
    trd = V[V["tradeable"]]
    L = [f"# SDE universe study - {decl['name']} ({VERSION})", "",
         f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). Universe {len(D['syms']):,} "
         f"stocks ({D['dropped']:,} ETFs / indices out by {D['etf_rule']}; {len(D['missing']):,} without bars), "
         f"{len(E['rows']):,} eligible stock-days, calendar {cal[0]}..{cal[-1]}. {secs:.0f} s.", "",
         "## Verdict first", ""]
    if len(trd):
        L.append(f"**{len(trd)} combination(s) TRADEABLE** (survived every event test and the 3-position book beat "
                 f"random picks from its environment in both periods): " +
                 "; ".join(f"{r.env} x {r.entry} x {r.exit}" for r in trd.itertuples(index=False)) + ".")
    elif len(surv):
        L.append(f"**{len(surv)} survivor(s) at the event level, none tradeable in the book.**")
    else:
        L.append("**No combination survived.** Nothing here beats buying every eligible stock on the same dates, "
                 "out of sample and in replication, after the correction for 120 tests.")
    L += ["", f"Of {len(V)} declared tests: {int(V['A_out_of_sample'].sum())} pass the out-of-sample test (A, "
              f"2016-2020, Bonferroni), {int(V['B_replication'].sum())} the replication (B), "
              f"{int(V['C_beats_env'].sum())} beat their own environment (C), "
              f"{int((V['D_years_positive'] >= 8).sum())} are positive in 8+ years (D); "
              f"{int(V['survivor'].sum())} pass all four; {int(V['tradeable'].sum())} tradeable.", ""]
    L += ["### The environments ranked (by their best entry's out-of-sample excess, X1)", "",
          "| rank | env | name | survivors (of 20) | tradeable | best entry | its excess A bp [Bonferroni] | "
          "its excess B bp [95%] |", "|---|---|---|---|---|---|---|---|"]
    rk = []
    for env in ENVS:
        g = R[(R.env == env) & (R.exit == "X1") & (R.period == "A")].sort_values("excess_mean", ascending=False)
        best = g.iloc[0] if len(g) else None
        b2 = R[(R.env == env) & (R.exit == "X1") & (R.period == "B") & (R.entry == best.entry)].iloc[0] \
            if best is not None else None
        rk.append((best.excess_mean if best is not None else -np.inf, env, best, b2))
    for i, (_, env, best, b2) in enumerate(sorted(rk, key=lambda z_: -z_[0] if np.isfinite(z_[0]) else np.inf), 1):
        vv = V[V.env == env]
        L.append(f"| {i} | {env} | {decl['environments'][env]['name']} | {int(vv['survivor'].sum())} | "
                 f"{int(vv['tradeable'].sum())} | {best.entry if best is not None else '-'} | "
                 f"{bp(best.excess_mean, best.excess_bonf_lo, best.excess_bonf_hi) if best is not None else '-'} | "
                 f"{bp(b2.excess_mean, b2.excess_lo, b2.excess_hi) if b2 is not None else '-'} |")
    L.append("")
    if len(surv):
        L += ["### The survivors", "", "| env | entry | exit | A: excess bp, Bonferroni interval | B: excess bp [95%] | vs env A / B bp | years + | "
              "book CAGR A / B | random A / B | book worst DD A / B | verdict |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
        for r in surv.itertuples(index=False):
            a = R[(R.env == r.env) & (R.entry == r.entry) & (R.exit == r.exit) & (R.period == "A")].iloc[0]
            b = R[(R.env == r.env) & (R.entry == r.entry) & (R.exit == r.exit) & (R.period == "B")].iloc[0]
            g = BK[(BK.env == r.env) & (BK.entry == r.entry) & (BK.exit == r.exit)].set_index("period")
            L.append(f"| {r.env} | {r.entry} | {r.exit} | {bp(a.excess_mean, a.excess_bonf_lo, a.excess_bonf_hi)} | "
                     f"{bp(b.excess_mean, b.excess_lo, b.excess_hi)} | {bp(a.incr_mean)} / {bp(b.incr_mean)} | "
                     f"{r.D_years_positive} | {pct(g.at['A', 'cagr'], 1)} / {pct(g.at['B', 'cagr'], 1)} | "
                     f"{pct(g.at['A', 'random_cagr_mean'], 1)} / {pct(g.at['B', 'random_cagr_mean'], 1)} | "
                     f"{pct(g.at['A', 'max_dd'], 1)} / {pct(g.at['B', 'max_dd'], 1)} | "
                     f"{'TRADEABLE' if r.tradeable else 'event survivor only'} |")
        L.append("")
    L += ["## The theory and the five environments", "", decl["theory"]["what_sde_is"], "",
          f"- Reversal: {decl['theory']['reversal']}", f"- Continuation: {decl['theory']['continuation']}",
          f"- An environment's job: {decl['theory']['job_of_an_environment']}.", "",
          "| env | name | rule | why | share of stock-days A / B | env excess X1 bp A / B |", "|---|---|---|---|---|---|"]
    EV = E["env"].set_index(["env", "period"])
    for k, v in decl["environments"].items():
        L.append(f"| {k} | {v['name']} | {v['rule']} | {v.get('why', '-')} | "
                 f"{EV.at[(k, 'A'), 'share_of_stock_days']:.1%} / {EV.at[(k, 'B'), 'share_of_stock_days']:.1%} | "
                 f"{bp(EV.at[(k, 'A'), 'X1_excess_mean'])} / {bp(EV.at[(k, 'B'), 'X1_excess_mean'])} |")
    L += ["", "## Every test (excess = net minus the same-date mean of every eligible stock, same exit; bp)", "",
          "A = 2016-2020, out of sample for the SDE research; B = 2021 on, its replication. Bonferroni interval: the "
          f"mean +- {E['z']:.2f} bootstrap standard deviations (120 tests).", "",
          "| env | entry | exit | events A | excess A [Bonferroni] | vs env A [95%] | events B | excess B [95%] | "
          "vs env B | years + | verdict |", "|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in V.itertuples(index=False):
        a = R[(R.env == r.env) & (R.entry == r.entry) & (R.exit == r.exit) & (R.period == "A")].iloc[0]
        b = R[(R.env == r.env) & (R.entry == r.entry) & (R.exit == r.exit) & (R.period == "B")].iloc[0]
        L.append(f"| {r.env} | {r.entry} | {r.exit} | {a.events:,} | {bp(a.excess_mean, a.excess_bonf_lo, a.excess_bonf_hi)} | "
                 f"{bp(a.incr_mean, a.incr_lo, a.incr_hi)} | {b.events:,} | {bp(b.excess_mean, b.excess_lo, b.excess_hi)} | "
                 f"{bp(b.incr_mean)} | {r.D_years_positive} | {r.verdict}{' / TRADEABLE' if r.tradeable else ''} |")
    L += ["", "## How to read it", "",
          "- Entries: " + "; ".join(f"{k} {v['name']}" for k, v in decl["entries"].items()) + ".",
          "- Exits: " + "; ".join(f"{k} {v['name']}" for k, v in decl["exits"].items()) + f". {decl['honest_exits']}.",
          f"- One event per stock until {decl['cooldown_sessions']} sessions have passed; {decl['cost_bp']} bp a round "
          "trip; signal at the close, buy at the next open.",
          f"- Decision: {decl['decision']['survivor']}. Tradeable: {decl['decision']['tradeable']}.",
          f"- Book: {decl['book']['sizing']}; {decl['book']['rank']}; baseline: {decl['book']['baseline']}.",
          f"- Known bias: {decl['known_bias']}.",
          "- Files: results.csv (every test x period), years.csv, books.csv, environments.csv, "
          "survivor_events.parquet (the survivors' events), run.json, DECLARATION.json.", ""]
    return "\n".join(L)


# ---------------------------------------------------------------------------------------------------- command line
def out_base(arg: Optional[str], root: Path) -> Path:
    v = arg or os.environ.get("SDELAB_OUT")
    if not v:
        raise SDEError("no output folder: pass --out or start with env_sdelab.bat (sets SDELAB_OUT)")
    b = Path(v).resolve()
    guards = [Path(root).resolve()] + [Path(os.environ[e]).resolve() for e in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR")
                                       if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise SDEError(f"output folder {b} is inside {g}; sdelab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


def cmd_run(a) -> int:
    t0 = time.time()
    decl, sha = load_decl()
    if not a.root:
        raise SDEError("--root is required (--root %CACHE_DAILY_ROOT% after call env_sdelab.bat)")
    root = Path(a.root)
    if not root.is_dir():
        raise SDEError(f"--root {root} is not a folder")
    panel = Path(a.panel) if a.panel else root / "panel" / "panel.parquet"
    base = out_base(a.out, root)
    say(f"{VERSION} | declaration {sha[:16]} | root {root} | panel {panel}")
    D = build(root, panel, decl, a.stage_e_any)
    say(f"eligible stock-days: {len(D['rows']):,}; testing {len(ENVS)} x {len(ENTRIES)} x {len(EXITS)} = "
        f"{len(ENVS) * len(ENTRIES) * len(EXITS)} combinations ...")
    E = evaluate(D, decl)
    say("books: each combination and 10 random books per environment ...")
    BK = books(D, E, decl)
    V = tradeable(E["verdicts"], BK)
    run = TC.new_run_dir(base, "runs", "SDE")
    E["results"].to_csv(run / "results.csv", index=False, float_format="%.8g")
    E["years"].to_csv(run / "years.csv", index=False, float_format="%.8g")
    BK.to_csv(run / "books.csv", index=False, float_format="%.8g")
    E["env"].to_csv(run / "environments.csv", index=False, float_format="%.8g")
    V.to_csv(run / "verdicts.csv", index=False)
    A = E["rows"]
    keep = []
    for r in V[V["survivor"]].itertuples(index=False):
        ev = E["events"][(r.env, r.entry)]
        X = A.iloc[ev].copy()
        X.insert(0, "symbol", [D["syms"][i] for i in X["sym"]])
        X["signal_day"] = D["cal"][X["t"].to_numpy()]
        X["env"], X["entry_rule"] = r.env, r.entry
        keep.append(X.drop(columns=["sym"]))
    (pd.concat(keep, ignore_index=True) if keep else pd.DataFrame()).to_parquet(run / "survivor_events.parquet",
                                                                                index=False)
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    secs = time.time() - t0
    (run / "REPORT.md").write_text(report(D, E, V, BK, decl, sha, secs), encoding="utf-8")
    meta = {"tool": VERSION, "declaration_sha256": sha, "root": str(root), "panel": str(panel),
            "universe": len(D["syms"]), "missing": D["missing"], "etf_rule": D["etf_rule"],
            "stock_days": int(len(A)), "z_bonferroni": E["z"], "production": D["prod"], "seconds": round(secs, 1),
            "survivors": int(V["survivor"].sum()), "tradeable": int(V["tradeable"].sum())}
    (run / "run.json").write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    TC.write_outputs_sha(run)
    with open(base / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION,
                            "run": run.name, "declaration_sha256": sha, "survivors": meta["survivors"],
                            "tradeable": meta["tradeable"]}) + "\n")
    say(f"survivors {meta['survivors']} | tradeable {meta['tradeable']}")
    say(f"DONE {run}  ({secs:.0f} s)")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="sdelab: SDE on the whole NSE universe (declared study)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="the declaration file is the frozen one")
    r = sub.add_parser("run", help="the declared study")
    r.add_argument("--root")
    r.add_argument("--panel", default=None)
    r.add_argument("--out", default=None)
    r.add_argument("--stage-e-any", action="store_true")
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['name']}, declared {d['declared']}): {len(ENVS)} environments, "
                f"{len(ENTRIES)} entries, {len(EXITS)} exits")
            return 0
        return cmd_run(a)
    except (SDEError, TC.TLError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
