"""
tests/test_sdelab.py - sdelab v1.0. Synthetic worlds only; ends with VERIFIED (sdelab v1.0).

  1 declaration  the frozen file loads; a changed copy is refused
  2 hand         SDE, ATR, the uptrend, volume ratio, shock, the SDE setups' parts by hand on a small path
  3 exits        honest time exit (a close locked at the lower band sells at the first unlocked open; stuck; pending)
                 and the bracket (target, stop, both in one bar = stop, gap through at a later open, frozen bars)
  4 stats        cooldown, the block bootstrap and the Bonferroni interval, the verdict rules
  5 book         a 3-position book by hand (sizing on the closed value, one position per stock, full days skipped)
  6 planted      random walks where an orderly fall (SDE10 < -0.5) is followed by a rise: E0 x N1 survives and is
                 tradeable; the opposite-theory check P1 does not survive; ETFs never enter; the report says so
  7 absent       the same random walks without the rise (no edge anywhere): nothing survives
  8 guards       no --root, an output folder inside the cache, a symbol without bars

    python tests\\test_sdelab.py          (from the sdelab folder, after call env_sdelab.bat)
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

LAB = Path(__file__).resolve().parents[1]
TRADELAB = LAB.parent / "tradelab"
sys.path.insert(0, str(LAB))
sys.path.insert(0, str(TRADELAB))
sys.path.insert(0, str(TRADELAB / "tests"))
for _v in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "SDELAB_OUT"):
    os.environ.pop(_v, None)
import tl_world as W                                                 # noqa: E402  (stand-in production modules)

RESULTS = []


def check(cond, msg, detail=None):
    ok = bool(cond)
    RESULTS.append(ok)
    print(("  ok    " if ok else "  FAIL  ") + msg + ("" if ok or detail is None else f"   <- {str(detail)[:700]}"))


def quiet(fn, *a):
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        rc = fn(*a)
    return rc, buf.getvalue()


# ---------------------------------------------------------------------------------------------------- worlds
def make_universe(root: Path, planted: bool, n_syms: int = 36, seed: int = 3):
    """Business days 2015-01-01 .. 2026-06-30; every stock an independent random walk (no edge of any kind: returns
    do not depend on the past). planted: when a stock's SDE10 at a close is below -0.5, its next 5 sessions rise
    +1.2% a day inside the day (open to close) - the bounce SDE's reversal theory predicts. Two ETF names never
    enter; one panel symbol has no bars."""
    root.mkdir(parents=True, exist_ok=True)
    W.write_mods(root)
    W.use_mods(root)
    days = pd.bdate_range("2015-01-01", "2026-06-30")
    ts = pd.DatetimeIndex(days).tz_localize("Asia/Kolkata") + pd.Timedelta(hours=9, minutes=15)
    rng = np.random.default_rng(seed)
    n = len(days)

    def write(sym, o, h, l, c, v):
        pd.DataFrame({"timestamp": ts, "open": o, "high": h, "low": l, "close": c, "volume": v}).to_parquet(
            root / f"{sym}_daily.parquet", index=False)
    nc = 1000 * np.cumprod(1 + rng.normal(0.0, 0.01, n))
    write("NIFTY50", nc, nc * 1.005, nc * 0.995, nc, np.full(n, 1e6))
    names = [f"S{i:02d}" for i in range(n_syms)] + ["GOLDBEES", "NIFTYIETF"]
    for sym in names:
        c = np.empty(n)
        o = np.empty(n)
        c[0] = o[0] = rng.uniform(400, 1500)
        on = rng.normal(0, 0.003, n)
        intra = rng.normal(0, 0.018, n)
        boost = 0
        for t in range(1, n):
            o[t] = c[t - 1] * (1 + on[t])
            c[t] = o[t] * (1 + intra[t] + (0.012 if boost > 0 else 0.0))
            boost = max(boost - 1, 0)
            if planted and boost == 0 and t >= 10:
                w = c[t - 10:t + 1]
                if (w[-1] - w[0]) / np.abs(np.diff(w)).sum() < -0.5:
                    boost = 5
        h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.004, n)))
        l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.004, n)))
        write(sym, o, h, l, c, rng.lognormal(12.5, 0.4, n))
    (root / "panel").mkdir(exist_ok=True)
    pd.DataFrame({"symbol": names + ["NOBARS"], "timestamp": days[-1]}).to_parquet(root / "panel" / "panel.parquet",
                                                                                   index=False)
    return days


class FakeDS:
    """A stock with stand-in lower-band locks (2 / 5 / 10 / 20% of the previous close, at the day's low)."""

    def __init__(self, o, h, l, c, v, dates):
        self.o, self.h, self.l, self.c, self.v = (np.asarray(x, float) for x in (o, h, l, c, v))
        self.dates = np.asarray(dates).astype("datetime64[D]")

    def locked(self, i, side):
        if i <= 0:
            return False
        prev = self.c[i - 1]
        p = self.c[i] if side == "close" else self.o[i]
        band = any(abs(p - round(prev * (1 - b), 2)) <= 0.011 for b in (0.02, 0.05, 0.10, 0.20))
        return bool(band and p <= self.l[i] * (1 + 1e-9))


# ---------------------------------------------------------------------------------------------------- the tests
def main() -> int:
    t0 = time.time()
    TMP = Path(tempfile.mkdtemp(prefix="sdelab_"))
    import sdelab as S
    # 1 declaration
    print("1. the declaration")
    d, sha = S.load_decl()
    bad = TMP / "decl.json"
    bad.write_text(S.DECL_FILE.read_text(encoding="utf-8").replace('"cost_bp": 35', '"cost_bp": 30'), encoding="utf-8")
    try:
        S.load_decl(bad)
        refused = False
    except S.SDEError as e:
        refused = "not the frozen declaration" in str(e)
    check(sha == S.DECL_SHA and d["stats"]["tests"] == len(S.ENVS) * len(S.ENTRIES) * len(S.EXITS) == 120 and refused,
          "the frozen declaration loads (120 declared tests = 6 environments x 10 entries x 2 exits); a changed copy "
          "is refused")
    # 2 features by hand
    print("2. features by hand")
    rng = np.random.default_rng(1)
    m = 320
    c = 100 * np.cumprod(1 + rng.normal(0.001, 0.02, m))
    o = c * (1 + rng.normal(0, 0.003, m))
    h = np.maximum(o, c) * 1.01
    l = np.minimum(o, c) * 0.99
    v = rng.lognormal(10, 0.4, m)
    F = S.stock_features(o, h, l, c, v)
    t = m - 1
    pc = np.r_[np.nan, c[:-1]]
    tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
    atr = tr[t - 13:t + 1].mean()
    s10 = (c[t] - c[t - 10]) / np.abs(np.diff(c[t - 10:t + 1])).sum()
    sma50, sma200, sma200_20 = c[t - 49:t + 1].mean(), c[t - 199:t + 1].mean(), c[t - 219:t - 19].mean()
    up = (c[t] > sma200) and (sma50 >= 1.02 * sma200) and (sma200 > sma200_20)
    vr = v[t - 9:t + 1].mean() / v[t - 59:t - 9].mean()
    shock = (np.max(pc[t - 9:t + 1] - c[t - 9:t + 1]) / atr) >= 2
    clim = v[t] >= 2 * np.median(v[t - 50:t])
    atrp = np.array([tr[k - 13:k + 1].mean() / c[k] if k >= 13 else np.nan for k in range(m)])
    v3 = atrp[t] >= np.quantile(atrp[t - 252:t], 0.67)
    rev = (c[t] > o[t]) and ((c[t] - l[t]) >= 0.7 * (h[t] - l[t]))
    check(abs(F["atr"][t] - atr) < 1e-9 and abs(F["sde10"][t] - s10) < 1e-12 and bool(F["uptrend"][t]) == up and
          abs(F["vol_ratio"][t] - vr) < 1e-9 and bool(F["shock"][t]) == shock and bool(F["climax"][t]) == clim and
          bool(F["v3"][t]) == bool(v3) and bool(F["reversal_bar"][t]) == rev and bool(F["thrust"][t]) == (c[t] > h[t - 1])
          and abs(F["sde10_min3"][t] - np.nanmin(F["sde10"][t - 3:t])) < 1e-12 and
          abs(F["turnover"][t] - np.median((c * v)[t - 19:t + 1])) < 1e-6,
          "every feature at the last bar by hand: ATR14 (simple), SDE10, the uptrend (SMA50 >= 1.02 x SMA200, SMA200 "
          "rising over 20), volume ratio (10 vs the 50 before), shock (2 ATR), climax (2 x the median of the 50 before), "
          "V3 (67th percentile of the 252 before), reversal bar, thrust, the 3-session SDE10 minimum, turnover")
    # 3 exits
    print("3. honest exits")
    days = pd.bdate_range("2024-01-01", periods=40)
    cc = np.full(40, 100.0)
    oo = np.full(40, 100.0)
    hh = np.full(40, 101.0)
    ll = np.full(40, 99.0)
    cc[10] = round(cc[9] * 0.95, 2)
    ll[10] = cc[10]                                 # bar 10 closes locked at the 5% band
    oo[11] = round(cc[10] * 0.95, 2)
    cc[11] = oo[11]
    hh[11] = ll[11] = oo[11]                        # bar 11 frozen at the band
    oo[12], cc[12], hh[12], ll[12] = 92.0, 93.0, 94.0, 91.0
    ds = FakeDS(oo, hh, ll, cc, np.ones(40), days)
    lc, lo, frozen = S.lock_arrays(ds)
    b, p, st = S.time_exit(np.array([10, 5, 41]), ds.c, ds.o, lc, lo, 40, search=20)
    lc2 = lc.copy()
    lc2[30] = True
    lo2 = lo.copy()
    lo2[31:] = True
    ul_none = S.time_exit(np.array([30]), ds.c, ds.o, lc2, lo2, 40, search=5)
    check(lc[10] and frozen[11] and not lc[12] and b[0] == 12 and p[0] == 92.0 and st[0] == "ok" and b[1] == 5 and
          st[2] == "pending" and ul_none[2][0] == "stuck" and ul_none[0][0] == 35,
          "time exit: a close locked at the lower band sells at the first open that is not (two sessions later, after a "
          "frozen bar); 'stuck' sells at the close 20 (here 5) sessions on; the data ending first = 'pending'",
          (lc[10], frozen[11], b, p, st, ul_none))
    # bracket: entry open 100, ATR 2 -> target 104, stop 94
    n = 12
    O = np.full(n, 100.0)
    H = np.full(n, 101.0)
    L = np.full(n, 99.0)
    C = np.full(n, 100.0)
    z = np.zeros(n, bool)
    H[3] = 104.5                                    # target on bar 3 (entry 1)
    r1 = S.bracket_exit(np.array([1]), np.array([2.0]), O, H, L, C, z, z, z, n, 5, 2.0, 3.0)
    H0 = np.full(n, 101.0)                          # no target from here on
    L2 = L.copy()
    L2[2], H2 = 93.5, H0.copy()
    H2[2] = 105.0                                   # both in one bar -> the stop
    r2 = S.bracket_exit(np.array([1]), np.array([2.0]), O, H2, L2, C, z, z, z, n, 5, 2.0, 3.0)
    O3 = O.copy()
    O3[4] = 92.0
    L3 = L.copy()
    L3[4] = 91.0                                    # gap through the stop at a later open
    r3 = S.bracket_exit(np.array([1]), np.array([2.0]), O3, H0, L3, C, z, z, z, n, 5, 2.0, 3.0)
    r4 = S.bracket_exit(np.array([1]), np.array([2.0]), O, H0, L, C, z, z, z, n, 5, 2.0, 3.0)
    fz = z.copy()
    fz[2] = True
    L5 = L.copy()
    L5[2] = 90.0                                    # a frozen bar sells nothing
    r5 = S.bracket_exit(np.array([1]), np.array([2.0]), O, H0, L5, C, z, z, fz, n, 5, 2.0, 3.0)
    check(r1[0][0] == 3 and r1[1][0] == 104.0 and r1[3][0] == "target" and r2[1][0] == 94.0 and r2[3][0] == "stop" and
          r3[0][0] == 4 and r3[1][0] == 92.0 and r4[0][0] == 5 and r4[3][0] == "time" and r5[3][0] == "time",
          "bracket: the 2-ATR target, the 3-ATR stop, both in one bar = the stop, a gap through at a later open fills at "
          "that open, untouched = the 5th close, a frozen bar sells nothing", (r1, r2, r3, r4, r5))
    # 4 stats
    print("4. statistics and verdicts")
    sym = np.array([0, 0, 0, 0, 1, 1, 1, 1])
    tt = np.array([1, 3, 6, 7, 2, 6, 7, 8])
    kept = S.cooldown(sym, tt, 5)
    dd = np.repeat(np.arange(200), 3)
    vals = np.random.default_rng(5).normal(0.01, 0.02, len(dd))
    bt = S.boot(dd, vals, d["stats"], 3.0)
    z = __import__("statistics").NormalDist().inv_cdf(1 - 0.05 / 240)
    check(list(kept) == [True, False, True, False, True, False, True, False] and abs(bt["mean"] - vals.mean()) < 1e-12 and
          bt["bonf_lo"] < bt["lo"] < bt["mean"] < bt["hi"] < bt["bonf_hi"] and bt["days"] == 200 and abs(z - 3.5293) < 1e-3,
          "cooldown keeps a stock's next fire only 5 sessions on; the bootstrap mean = the plain mean, its Bonferroni "
          "interval (z = 3.53 for 120 tests) is wider than the 95% one", (list(kept), bt))
    R = pd.DataFrame([{"env": "E0", "entry": "N1", "exit": "X1", "period": pk, "events": 400, "days": 150,
                       "excess_bonf_lo": 0.001, "excess_lo": 0.002, "incr_lo": 0.001, "incr_mean": 0.002}
                      for pk in ("A", "B")])
    Y = pd.DataFrame([{"env": "E0", "entry": "N1", "exit": "X1", "year": y, "events": 40,
                       "excess_mean": 0.01 if y < 2024 else -0.01} for y in range(2016, 2027)])
    v_ok = S.verdicts(R, Y, d).iloc[0]
    v_few = S.verdicts(R.assign(events=200), Y, d).iloc[0]
    v_d = S.verdicts(R, Y.assign(excess_mean=np.where(Y["year"] < 2023, 0.01, -0.01)), d).iloc[0]
    v_a = S.verdicts(R.assign(excess_bonf_lo=np.where(R["period"] == "A", -0.001, 0.001)), Y, d).iloc[0]
    check(v_ok["survivor"] and v_ok["D_years_positive"] == 8 and v_few["verdict"] == "TOO FEW EVENTS" and
          not v_d["survivor"] and "D" in v_d["verdict"] and not v_a["survivor"] and "A" in v_a["verdict"],
          "verdicts: all four conditions -> SURVIVOR; 8 positive years pass, 7 fail; fewer than 300 events = TOO FEW; "
          "a failed out-of-sample test fails", (v_ok.to_dict(), v_d.to_dict(), v_a.to_dict()))
    # 5 book by hand
    print("5. the book by hand")
    cal = np.array(pd.bdate_range("2020-01-01", periods=12)).astype("datetime64[D]")
    closes = np.full((3, 12), 100.0, np.float32)
    cand = {"e": np.array([1, 1, 1, 1, 6]), "x": np.array([5, 5, 5, 3, 9]), "sym": np.array([0, 0, 1, 2, 0]),
            "entry": np.full(5, 100.0), "net": np.array([0.10, 0.5, -0.05, 0.02, 0.10])}
    bk = S.book(cand, closes, cal, [str(cal[0]), str(cal[11])], 300000.0, 2)
    # day 1: buy sym0 (100k = 300k/2? closed 300k / 2 slots = 150k), sym0 again refused, sym1 150k; full -> sym2 skipped
    # day 5: both sold: +15k, -7.5k -> 307.5k; day 6: sym0 153.75k, day 9 sold +15.375k -> 322.875k
    check(bk["trades"] == 3 and abs(bk["final"] - 322875.0) < 1e-6,
          "book: 1/slots of the closed value, a stock held once, a full book skips the day's other candidates, sales "
          "realise on their day (322,875 by hand)", bk)
    # 6 planted
    print("6. planted world: random walks where an orderly fall is followed by a rise")
    rootP = TMP / "planted"
    make_universe(rootP, planted=True)
    outP = TMP / "outP"
    rc, log = quiet(S.main, ["run", "--root", str(rootP), "--out", str(outP), "--stage-e-any"])
    runs = sorted((outP / "runs").glob("SDE_*")) if (outP / "runs").exists() else []
    if rc != 0 or not runs:
        check(False, "planted run", log[-1500:])
        return finish(t0, TMP)
    run = runs[-1]
    V = pd.read_csv(run / "verdicts.csv")
    Rr = pd.read_csv(run / "results.csv")
    BK = pd.read_csv(run / "books.csv")
    rep = (run / "REPORT.md").read_text(encoding="utf-8")
    meta = json.loads((run / "run.json").read_text())
    v1 = V[(V.env == "E0") & (V.entry == "N1") & (V.exit == "X1")].iloc[0]
    vp = V[(V.entry == "P1")]
    a1 = Rr[(Rr.env == "E0") & (Rr.entry == "N1") & (Rr.exit == "X1") & (Rr.period == "A")].iloc[0]
    sha_ok = all(ln.split("  ", 1)[1].strip() in {p.name for p in run.iterdir()}
                 for ln in (run / "outputs.sha256").read_text().splitlines() if ln.strip())
    ev = pd.read_parquet(run / "survivor_events.parquet")
    check(v1["survivor"] and v1["tradeable"] and a1["excess_mean"] > 0.005 and not vp["survivor"].any() and
          meta["universe"] == 37 and meta["missing"] == ["NOBARS"] and "GOLDBEES" not in set(ev.get("symbol", [])) and
          "TRADEABLE" in rep.split("## The theory")[0] and sha_ok and (outP / "sdelab_ledger.jsonl").is_file(),
          "planted: E0 x N1 x X1 (SDE10 < -0.5, the 5th close) survives every test and is tradeable; the opposite-theory "
          "check P1 never survives; 37 symbols (2 ETFs out; the one without bars noted as missing); outputs hashed, ledger written",
          (v1.to_dict(), a1.to_dict(), meta.get("universe"), meta.get("missing"), log[-600:]))
    # environments and market variables by hand on the planted rows
    import sdelab as S2
    D = S2.build(rootP, rootP / "panel" / "panel.parquet", d, True, log=lambda m_: None)
    A = D["rows"]
    t_some = int(A.loc[A["v3_known"], "t"].value_counts().index[0])      # a day with known ATR percentiles
    g = A[A["t"] == t_some]
    e1 = ((g["flags"] & S2.BIT["E1"]) > 0) == ((g["sde10"].median() > -0.2) & ~g["shock"].astype(bool))
    e4 = ((g["flags"] & S2.BIT["E4"]) > 0) == (g.loc[g["v3_known"], "v3"].mean() >= 0.5)
    n5 = ((g["flags"] & S2.BIT["N5"]) > 0) == (g["sde10"] <= g["sde10"].quantile(0.10))
    nets = A["x1_net"].to_numpy(float)
    mk_ok = abs(float(g["mkt_sde10"].iloc[0]) - float(g["sde10"].median())) < 1e-6 and \
        abs(float(g["mkt_v3_share"].iloc[0]) - float(g.loc[g["v3_known"], "v3"].mean())) < 1e-6
    check(bool(e1.all() and e4.all() and n5.all()) and mk_ok and len(A) > 1000 and np.nanmax(np.abs(nets)) < 1.0,
          "market variables by hand on one day: E1 (the day's median SDE10 > -0.2 and no shock), E4 (half the stocks "
          "in their own top-third ATR%), N5 (the day's bottom 10% of SDE10)")
    # rows against the stock files: SDE10 at the signal close, the entry = the NEXT open, the 5th close, 35 bp
    cal = D["cal"]
    samp = A.sample(25, random_state=4)
    r_ok, bad = True, []
    for r in samp.itertuples(index=False):
        f = pd.read_parquet(rootP / f"{D['syms'][r.sym]}_daily.parquet")
        dd_ = pd.to_datetime(f["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
        i = int(np.flatnonzero(dd_.to_numpy().astype("datetime64[D]") == cal[r.t])[0])
        cl = f["close"].to_numpy(float)
        s10 = (cl[i] - cl[i - 10]) / np.abs(np.diff(cl[i - 10:i + 1])).sum()
        e_ok = abs(r.entry - f["open"].iloc[i + 1]) < 1e-9 and cal[r.e] == dd_.iloc[i + 1].to_datetime64().astype(
            "datetime64[D]")
        x_ok = r.x1_status != "ok" or abs(r.x1_net - (cl[i + 5] / r.entry - 1 - 0.0035)) < 1e-9 or cal[r.x1_cal] != \
            dd_.iloc[i + 5].to_datetime64().astype("datetime64[D]")
        g_ = abs(r.sde10 - s10) < 1e-5 and e_ok and x_ok
        r_ok &= bool(g_)
        if not g_:
            bad.append((D["syms"][r.sym], str(cal[r.t]), r.sde10, s10, r.entry, f["open"].iloc[i + 1]))
    # one combination by hand from the rows: E2 x N1 x X1 in period A (cooldown, both baselines)
    Aa = A.sort_values(["sym", "t"], kind="mergesort").reset_index(drop=True)
    use = Aa["x1_status"].isin(["ok", "stuck"])
    netv = Aa["x1_net"].where(use)
    ub = netv.groupby(Aa["t"]).mean()
    e2 = (Aa["flags"] & S2.BIT["E2"]) > 0
    eb = netv[e2].groupby(Aa["t"][e2]).mean()
    m = e2 & ((Aa["flags"] & S2.BIT["N1"]) > 0)
    idx = np.flatnonzero(m)
    k2 = idx[S2.cooldown(Aa["sym"].to_numpy()[idx], Aa["t"].to_numpy()[idx], 5)]
    k2 = k2[use.to_numpy()[k2]]
    ya = pd.DatetimeIndex(cal[Aa["t"].to_numpy()[k2]]).year
    k2 = k2[(ya >= 2016) & (ya <= 2020)]
    exm = float((Aa["x1_net"].iloc[k2] - Aa["t"].iloc[k2].map(ub)).mean())
    inm = float((Aa["x1_net"].iloc[k2] - Aa["t"].iloc[k2].map(eb)).mean())
    rr = Rr[(Rr.env == "E2") & (Rr.entry == "N1") & (Rr.exit == "X1") & (Rr.period == "A")].iloc[0]
    yy = pd.read_csv(run / "years.csv")
    ysum = int(yy[(yy.env == "E0") & (yy.entry == "N1") & (yy.exit == "X1") & (yy.year <= 2020)]["events"].sum())
    # the book's priority: SDE10 ascending, then turnover descending, then symbol (P1: SDE10 descending)
    TT = pd.DataFrame({"sde10": [-0.6, -0.9, -0.6, -0.6, 0.8], "turnover": [5e7, 1e7, 9e7, 9e7, 1e7],
                       "sym": [3, 1, 2, 0, 4], "e": [7, 7, 7, 7, 7]})
    o1 = list(S2.rank_order(TT, np.arange(5), "N1"))
    o2 = list(S2.rank_order(TT.iloc[:2], np.arange(2), "P1"))
    check(r_ok and abs(exm - rr["excess_mean"]) < 1e-9 and abs(inm - rr["incr_mean"]) < 1e-9 and
          rr["events"] == len(k2) and ysum == int(a1["events"]) and abs(meta["z_bonferroni"] - 3.5293) < 1e-3 and
          o1 == [1, 3, 2, 0, 4] and o2 == [0, 1],
          "by hand from the stock files: SDE10 at the signal close, entry at the NEXT open, the 5th close net of 35 bp; "
          "E2 x N1 x X1 in 2016-2020 recomputed (cooldown, the universe and the environment baselines); years add up to "
          "period A; z = 3.53; the book's priority (SDE10, then turnover, then symbol; P1 reversed)",
          (r_ok, bad[:3], exm, rr["excess_mean"], inm, rr["incr_mean"], rr["events"], len(k2), ysum, o1, o2))
    # 7 absent
    print("7. absent world: the same random walks, no rise after the falls")
    rootA = TMP / "absent"
    make_universe(rootA, planted=False)
    outA = TMP / "outA"
    rc, log = quiet(S.main, ["run", "--root", str(rootA), "--out", str(outA), "--stage-e-any"])
    runA = sorted((outA / "runs").glob("SDE_*"))[-1] if rc == 0 else None
    VA = pd.read_csv(runA / "verdicts.csv") if runA else pd.DataFrame({"survivor": [True]})
    repA = (runA / "REPORT.md").read_text(encoding="utf-8") if runA else ""
    check(rc == 0 and not VA["survivor"].any() and "No combination survived" in repA,
          "absent: nothing survives and the report says so first", log[-600:])
    # 8 guards
    print("8. guards")
    g1 = quiet(S.main, ["run", "--out", str(outA), "--stage-e-any"])
    os.environ["CACHE_DAILY_ROOT"] = str(rootA)
    g2 = quiet(S.main, ["run", "--root", str(rootA), "--out", str(rootA / "inside"), "--stage-e-any"])
    os.environ.pop("CACHE_DAILY_ROOT", None)
    g3 = quiet(S.main, ["check"])
    check(g1[0] == 2 and "--root is required" in g1[1] and g2[0] == 2 and "sdelab never writes there" in g2[1] and
          g3[0] == 0 and "OK SDE_DECLARATION.json" in g3[1],
          "guards: no --root is refused; an output folder inside the cache is refused; check confirms the frozen file",
          (g1, g2, g3))
    return finish(t0, TMP)


def finish(t0, TMP) -> int:
    shutil.rmtree(TMP, ignore_errors=True)
    nf = RESULTS.count(False)
    print(f"{len(RESULTS)} checks, {nf} failures, {time.time() - t0:.0f} s, pandas {pd.__version__} / numpy {np.__version__}")
    if nf == 0:
        print("VERIFIED (sdelab v1.0)")
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
