# MANIFEST - sdelab v1.0 + voldir v1.0

11 Nov 2026: a separate experiment from BigMove - SDE (signed directional efficiency) on the whole NSE universe, declared before any run (SDE_DECLARATION.json, sha256 below). Lives beside tradelab (PyCharmMiscProject\sdelab), reads the cache through tradelab's tl_data / production's stage E read only, writes only under C:\QuantData\sdelab. Needs tradelab v1.3.1 + setups add-on v1.4 (tl_setups.sde_series).

12 Nov 2026: voldir v1.0 - volatility x direction (study VD1, VOLDIR_DECLARATION.json frozen before any run): Stage 0 forecast race, Stage 1 fourteen universe tests (R1's universe, exits, costs and statistics through sdelab.py's own code), Stage 2 in tradelab (strategies\voldir.py, sha checked) with a Holm step. sdelab.py and SDE_DECLARATION.json are unchanged. Needs tradelab v1.3.1 + setups add-on v1.5 (tl_setups.vol_arrays) and scipy.

| file | version | sha256 (16) | role |
|---|---|---|---|
| sdelab.py | sdelab v1.0 | 5f16109db33a1960 | COMMAND: check (the frozen declaration) / run (the declared study on the whole universe): features, honest exits, 120 tests, books, REPORT.md |
| SDE_DECLARATION.json | frozen 2026-11-11 | a3017eb71c798be4 | the study: theory, universe, 5 environments + control, 10 entries, 2 exits, 2 periods, statistics, decision rules; sdelab.py refuses any other sha256 |
| voldir.py | voldir v1.0 | 6bcd22d693d6b9f0 | COMMAND: check (the declaration and tradelab's strategies\voldir.py) / run (Stage 0 race + Stage 1 tests -> REPORT.md, daily_cuts.parquet, stage2_commands.txt) / holm (Stage 2: Holm per engine over tl_backtest runs) |
| VOLDIR_DECLARATION.json | frozen 2026-11-12 | 0cb7f61653894fe7 | study VD1: features, 12 rules / 14 tests with parents, buy and veto decisions, the forecast race, Stage 2 (B1, B2, translations, Holm); voldir.py refuses any other sha256 |
| env_sdelab.bat | sdelab v1.0 | 43b5fcebcab959a1 | session setup (CRLF): CACHE_DAILY_ROOT via env_daily.bat, SDELAB_OUT=C:\QuantData\sdelab, PYTHONPATH sdelab;tradelab;open_close;bigmove_deploy |
| README_SDELAB.md | sdelab v1.0 | 38cea5f57254c699 | the theory, the environments, the decision, how to run, the outputs |
| README_VOLDIR.md | voldir v1.0 | 0b76cf9b4058aa78 | the three stages, the 14 tests and their sources, the decisions, how to run Stage 1 and Stage 2, the outputs |
| tests/test_sdelab.py | sdelab v1.0 | 48397a870e53bc27 | 12 checks on synthetic worlds (planted / absent); must end VERIFIED (sdelab v1.0) |
| tests/test_voldir.py | voldir v1.0 | fdda8a1d615b64cb | 9 checks on GARCH worlds (planted / absent) and by hand; must end VERIFIED (voldir v1.0) |

Declaration sha256 (full): SDE a3017eb71c798be4903afea67d24ee86196a802be35dbaeb5f606b9e4f46ecb7; VOLDIR 0cb7f61653894fe77335357333c9bfd1e975d7f0f3a0057a73a002c3db2319c3

Verified here (sdelab): 12 checks, 0 failures (pandas 3.0.5 / numpy 2.5.3 and pandas 2.3.3 / numpy 2.4.1); 12 planted bugs each caught; a 300-stock neutral universe (814k stock-days) gives no survivor.
Verified here (voldir): 9 checks, 0 failures (pandas 3.0.5 / numpy 2.5.3 and pandas 2.3.3 / numpy 2.4.1, scipy 1.18); 17 planted bugs each caught (the turnover third, the parent baseline, the cooldown, the veto's bound, the turnover window, the RSJ sign, a look-ahead GARCH fit, the race's scale, the X0 hold, the turnover cut, lock3's window, Holm, Stage 2's list, Yang-Zhang's k, the year rule, the regime's window, next-day cuts); a 300-stock GARCH world with no edge (811,205 stock-days) gives nothing.
