# voldir v1.0 — volatility × direction on the whole NSE universe (study VD1)

**Question.** Does volatility tell which falls bounce and which keep going? That covers its level, its direction (variance from up days vs down days), the market's volatility regime and the price bands. And is there a better volatility number than ATR14? Every rule comes from published research (see the table). Each was declared before any run, in **`VOLDIR_DECLARATION.json`** (frozen 12 Nov 2026; `voldir.py` refuses any other sha256).

It runs in three stages:

| stage | where | what | decides |
|-|-|-|-|
| 0 — forecast race | `voldir.py run` | ATR14² vs EWMA, Yang–Zhang, HAR and GJR-GARCH as forecasts of the next 5 sessions' variance (QLIKE; the day's rank correlation across stocks) | whether a lane rebuilt on a better forecast is worth building (a new tree, forward). Nothing else changes |
| 1 — universe tests | `voldir.py run` | 14 tests: 12 rules, two of them on two exits, each against the universe and against its parent | which rules become Stage 2 strategies |
| 2 — the frozen tree | tradelab add-on v1.5, `strategies\voldir.py` | B1 (downside-volatility sizing) and B2 (no buy after a lower-circuit close) always; the survivors' and vetoes' translations | `voldir.py holm`: a Holm-corrected PASS per engine = a forward candidate only |

## The tests (signal at the close, buy at the next open; R1's universe, honest exits, 35 bp, 5-session cooldown)

| test | rule | parent | kind | source |
|-|-|-|-|-|
| V1L / V1H | RSJ10 in the day's lowest / highest tenth (variance made of falls / of rises) | all stocks | buy | Bollerslev, Li & Zhao 2020 (US: falls-variance outperforms); the sign flipped in Pakistan, so both are tested |
| V2L / V2H | orderly fall (SDE10 < −0.5) on thin / heavy turnover (the day's bottom / top third of the turnover ratio) | N1 | buy / veto | Medhat & Schmeling 2022; Chui et al. 2023 (India) |
| V3D / V3C | orderly fall as a drift (largest day < 35% of the path, no 2-ATR fall) / with a panic candle | N1 | buy / veto | Atilgan et al. 2020 (left-tail momentum); Da, Gurun & Warachka 2014 |
| V4F / V4R | orderly fall while NIFTY's GJR-GARCH volatility is high (top 20% of its past year) and falling / rising | N1 | buy / veto | Wang & Xu 2015; Nagel 2012 |
| V5K / V5D | a lower-circuit close in the last 3 sessions (any stock / an orderly fall) | all / N1 | veto | Das 2026 (preprint, NSE); Nath 2003, 2005 |
| V6H / V6L | jumpy (top third of ATR%) 20-day winner (top tenth) on heavy / thin turnover; X0 = the 2nd close and X1 = the 5th | J | buy / veto | Arena, Haggard & Yan 2008; Chen, Li & Worthington 2022 |

**Buy survivor** must pass all of these:
- (A) its excess over the universe has a Bonferroni lower bound above 0 in 2016–2020 (z = 2.91 for 14 tests);
- (B) its excess has a 95% lower bound above 0 from 2021 on;
- (C) it beats its parent (95% in A, mean in B);
- (D) it is positive in at least 8 of 11 years;
- it has at least 300 events on 100 days per period.

**Veto confirmed:**
- its gap to its parent has a Bonferroni upper bound below 0 in A and a 95% upper bound below 0 in B;
- it is negative in at least 8 of 11 years;
- it meets the same event floor.

Every feature is in `tradelab\tl_setups.py`'s `vol_arrays`. That is the same code tradelab reads at every pick, so Stage 1 and Stage 2 cannot disagree. NIFTY's GJR-GARCH is refitted each January on the past only.

**Known bias:** the cache holds today's stocks. Stocks delisted after a fall are missing, which flatters buy-the-fall rules, most in 2016–2020. Period A has seen one SDE study (R1), so it is lightly used, not untouched.

## Install and run

1. Copy `voldir.py`, `VOLDIR_DECLARATION.json`, `README_VOLDIR.md`, `MANIFEST_SDELAB.md` and `tests\test_voldir.py` into `C:\Users\karanvsi\PyCharmMiscProject\sdelab`. The sdelab R1 files stay as they are.
2. Install tradelab add-on v1.5, which is the other zip.
3. voldir needs scipy for the GARCH fits. If it is missing, install it with `pip install scipy`.

```
call C:\Users\karanvsi\PyCharmMiscProject\sdelab\env_sdelab.bat
python tests\test_voldir.py
python voldir.py check
python voldir.py run --root %CACHE_DAILY_ROOT%
```

The test must end with `VERIFIED (voldir v1.0)` (about 30 s). `check` prints the declaration's sha256 and confirms tradelab's `strategies\voldir.py` is the declared one. The run writes `C:\QuantData\sdelab\runs\VD_<date>_<nnn>\`:

| file | what |
|-|-|
| REPORT.md | the verdict first, then the exact Stage 2 commands, every test, the race and NIFTY's GARCH parameters by year |
| verdicts.csv, results.csv, years.csv | each test × exit: the four conditions; the numbers per period; the yearly means |
| race.csv | each forecast × period: QLIKE, the mean daily rank correlation, the gain over ATR [95%], the scale |
| daily_cuts.parquet | each session's cross-section cuts and the market regime (tradelab's `--voldir` reads it, hash-checked) |
| market_vol.csv, gjr_params.csv | NIFTY's volatility forecast and flags by day; the parameters by year |
| stage2_commands.txt | the Stage 2 backtests to run, for D and ENS |
| run.json, DECLARATION.json, outputs.sha256 | provenance; one line in `voldir_ledger.jsonl` |

Then run Stage 2 from the tradelab folder with `call env_tradelab.bat` and every line of `stage2_commands.txt`. After that, from the sdelab folder:

```
python voldir.py holm --scan C:\QuantData\tradelab\backtest
```

It reads every tl_backtest run of `strategies\voldir.py#...`. It checks the strategy file's sha, one engine per run, the comparison with the frozen tree, and that each variant and engine was run only once. It then prints each engine's Holm-corrected verdicts.

## Tests (`tests/test_voldir.py`, 9 checks)

- Hand calculations:
  - the features, including the split guard and lock3;
  - the GJR fit recovering simulated parameters, and the filter recursion;
  - the market regime using only the past, which is checked by cutting the data;
  - EWMA, Yang–Zhang and RV5;
  - the buy and veto verdicts and Holm.
- **Planted GARCH world.** This has leverage, fat tails, price bands that lock at the band, and a market factor. In it, V2L survives, V5K is a confirmed veto and V6H × X0 survives. Nothing that runs against the plants passes. GJR beats ATR in the race. Stage 2's commands follow the verdicts.
- **By hand from the stock files:**
  - the values at the signal close, the next-open entry and X0;
  - one day's cuts and flags;
  - V2L recomputed from the rows;
  - the race's scale.
- **Absent GARCH world.** Nothing passes. A 300-stock version (811,205 stock-days) also gave nothing.
- Guards.

17 planted bugs, each caught. Passes on pandas 3.0.5 and 2.3.3.
