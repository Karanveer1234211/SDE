"""
tests/test_voldir.py - voldir v1.0 (study VD1). Synthetic worlds only; ends with VERIFIED (voldir v1.0).

  1 declaration  the frozen file loads (14 tests, z for 14); a changed copy is refused
  2 features     rsj10, turn_rel, lds10, shock, ret20, atrp, semivol20, lock3 and the jump guard by hand
  3 GJR          the fit recovers a simulated GJR-t's parameters; the filter = the recursion by hand; the market regime
                 uses only the past (cutting the data later changes nothing before) and its flags by hand
  4 forecasts    EWMA, Yang-Zhang, RV5 by hand; HAR / QLIKE scale on a toy race
  5 verdicts     buy and veto rules by hand (each condition flipped); Holm by hand
  6 planted      a GARCH world (leverage, fat tails, price bands, a market factor) with three planted effects: thin-
                 turnover orderly falls bounce (V2L survives), lower-circuit closes keep falling (V5K veto confirmed),
                 jumpy 20-day winners on heavy turnover rise for two sessions (V6H x X0 survives); nothing that runs
                 against the plants passes (rules that overlap them, e.g. V1H mid-bounce, may: the effect is real in
                 that world); the race ranks GJR above ATR; Stage 2 commands follow the verdicts
  7 by hand      rows against the stock files; one day's cuts and flags; one test recomputed from the rows
  8 absent       the same GARCH world without the plants (no edge anywhere): nothing passes
  9 guards       no --root, a changed strategies file, a Stage 2 run listed twice

    python tests\\test_voldir.py          (from the sdelab folder, after call env_sdelab.bat)
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

LAB = Path(__file__).resolve().parents[1]
TRADELAB = LAB.parent / "tradelab"
sys.path.insert(0, str(LAB))
sys.path.insert(0, str(TRADELAB))
sys.path.insert(0, str(TRADELAB / "tests"))
for _v in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "SDELAB_OUT"):
    os.environ.pop(_v, None)
import tl_world as W                                                 # noqa: E402  (stand-in production modules)

RESULTS = []


def check(cond, msg, detail=None):
    ok = bool(cond)
    RESULTS.append(ok)
    print(("  ok    " if ok else "  FAIL  ") + msg + ("" if ok or detail is None else f"   <- {str(detail)[:900]}"))


def quiet(fn, *a):
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        rc = fn(*a)
    return rc, buf.getvalue()


# ---------------------------------------------------------------------------------------------------- the world
def make_world(root: Path, planted: bool, n_syms: int = 50, seed: int = 5):
    """Business days 2015-01-01 .. 2026-06-30. NIFTY50 and every stock follow GJR-GARCH with Student-t shocks and a
    leverage effect; a stock's day = an overnight move and an intraday move (the market's intraday move x 0.8 + its
    own), each mean-zero in simple terms, so no rule can earn anything; the close is held inside the stock's band
    (5% or 10%) - a fall beyond it closes LOCKED at the band (the stand-in stage E rule sees it) with nothing carried
    over. planted adds, decided each day on the real path and the day's cross-section:
      V2L  SDE10 < -0.5 and turnover ratio <= the day's 33rd percentile -> +1.2% a day inside the next 5 sessions
      V5   a close locked at the lower band -> -1.5% a day inside the next 3 sessions
      V6H  ATR% >= the day's 67th percentile, 20-day return >= its 90th, turnover ratio >= its 67th -> +1.5% a day
           inside the next 2 sessions"""
    root.mkdir(parents=True, exist_ok=True)
    W.write_mods(root)
    W.use_mods(root)
    days = pd.bdate_range("2015-01-01", "2026-06-30")
    ts = pd.DatetimeIndex(days).tz_localize("Asia/Kolkata") + pd.Timedelta(hours=9, minutes=15)
    rng = np.random.default_rng(seed)
    n, m = len(days), n_syms
    nu = 5.0
    tz = lambda size: rng.standard_t(nu, size) / np.sqrt(nu / (nu - 2))          # noqa: E731
    # the market
    om, a_, g_, b_ = 1.2e-5, 0.03, 0.10, 0.90
    s2 = om / (1 - a_ - g_ / 2 - b_)
    rm = np.empty(n)
    for t in range(n):
        e = np.sqrt(s2) * float(np.clip(tz(1)[0], -6, 6))
        rm[t] = e
        s2 = om + (a_ + g_ * (e < 0)) * e * e + b_ * s2
    nc = 10000 * np.cumprod(1 + rm)
    nifty = pd.DataFrame({"timestamp": ts, "open": np.r_[10000, nc[:-1]], "high": nc * 1.004, "low": nc * 0.996,
                          "close": nc, "volume": np.full(n, 1e6)})
    nifty["high"] = np.maximum(nifty[["open", "close"]].max(axis=1), nifty["high"])
    nifty["low"] = np.minimum(nifty[["open", "close"]].min(axis=1), nifty["low"])
    nifty.to_parquet(root / "NIFTY50_daily.parquet", index=False)
    # the stocks, day by day (the plants read the path so far and the day's cross-section)
    lvl = rng.uniform(0.016, 0.026, m) ** 2
    om_s, a_s, g_s, b_s = lvl * (1 - 0.04 - 0.05 - 0.88), 0.04, 0.10, 0.88
    band = rng.choice([0.05, 0.05, 0.10], m)
    O, H, L, C, V = (np.zeros((n, m)) for _ in range(5))
    C[0] = O[0] = rng.uniform(800, 2000, m)
    H[0], L[0] = C[0] * 1.01, C[0] * 0.99
    V[:] = rng.lognormal(12.5, 0.45, (n, m))
    s2s = lvl.copy()
    boost = np.zeros((n + 6, m))
    TR = np.zeros((n, m))
    TR[0] = H[0] - L[0]
    for t in range(1, n):
        prev = C[t - 1]
        sd = np.sqrt(s2s)
        on = np.clip(sd * 0.35 * tz(m), -0.6 * band, 0.6 * band)
        intra = 0.8 * rm[t] + sd * 0.9 * np.clip(tz(m), -6, 6) + boost[t]
        o = prev * (1 + on)
        c = o * (1 + intra)
        lo_b, hi_b = np.round(prev * (1 - band), 2), np.round(prev * (1 + band), 2)
        lock = c <= lo_b
        c = np.where(lock, lo_b, np.minimum(c, hi_b))
        h = np.minimum(np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.004, m))), hi_b)
        l = np.maximum(np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.004, m))), lo_b)
        l = np.where(lock, c, l)
        h = np.maximum(h, np.maximum(o, c))
        O[t], H[t], L[t], C[t] = o, h, l, c
        e = c / prev - 1
        s2s = om_s + (a_s + g_s * (e < 0)) * e * e + b_s * s2s
        TR[t] = np.fmax(h - l, np.fmax(np.abs(h - prev), np.abs(l - prev)))
        if planted and t >= 140:
            w = C[t - 10:t + 1]
            sde = (w[-1] - w[0]) / np.abs(np.diff(w, axis=0)).sum(0)
            tv = C[:t + 1] * V[:t + 1]
            trel = tv[t - 9:t + 1].mean(0) / np.median(tv[t - 129:t - 9], axis=0)
            atrp = TR[t - 13:t + 1].mean(0) / C[t]
            r20 = C[t] / C[t - 20] - 1
            p33, p67 = np.quantile(trel, [0.33, 0.67])
            v2 = (sde < -0.5) & (trel <= p33)
            v6 = (atrp >= np.quantile(atrp, 0.67)) & (r20 >= np.quantile(r20, 0.90)) & (trel >= p67)
            for k in range(1, 6):
                boost[t + k] += np.where(v2, 0.012, 0.0)
            for k in range(1, 4):
                boost[t + k] += np.where(lock, -0.015, 0.0)
            for k in range(1, 3):
                boost[t + k] += np.where(v6, 0.015, 0.0)
    names = [f"S{i:02d}" for i in range(m)]
    for j, s in enumerate(names):
        pd.DataFrame({"timestamp": ts, "open": O[:, j], "high": H[:, j], "low": L[:, j], "close": C[:, j],
                      "volume": V[:, j]}).to_parquet(root / f"{s}_daily.parquet", index=False)
    pd.DataFrame({"timestamp": ts, "open": O[:, 0], "high": H[:, 0], "low": L[:, 0], "close": C[:, 0],
                  "volume": V[:, 0]}).to_parquet(root / "GOLDBEES_daily.parquet", index=False)
    (root / "panel").mkdir(exist_ok=True)
    pd.DataFrame({"symbol": names + ["GOLDBEES", "NOBARS"], "timestamp": days[-1]}).to_parquet(
        root / "panel" / "panel.parquet", index=False)
    return {"days": days, "names": names, "band": band, "C": C, "O": O, "H": H, "L": L, "V": V}


class FakeDS:
    def __init__(self, o, h, l, c, v, dates, sym="X"):
        self.o, self.h, self.l, self.c, self.v = (np.asarray(x, float) for x in (o, h, l, c, v))
        self.dates = np.asarray(dates).astype("datetime64[D]")
        self.sym = sym

    def __len__(self):
        return len(self.c)

    def locked(self, i, side):
        if i <= 0:
            return False
        prev = self.c[i - 1]
        p = self.c[i] if side == "close" else self.o[i]
        return bool(any(abs(p - round(prev * (1 - b), 2)) <= 0.011 for b in (0.02, 0.05, 0.10, 0.20))
                    and p <= self.l[i] * (1 + 1e-9))


# ---------------------------------------------------------------------------------------------------- the tests
def main() -> int:
    t0 = time.time()
    TMP = Path(tempfile.mkdtemp(prefix="voldir_"))
    import voldir as VD
    import tl_setups as SU
    # 1 declaration
    print("1. the declaration")
    d, sha = VD.load_decl()
    bad = TMP / "decl.json"
    bad.write_text(VD.DECL_FILE.read_text(encoding="utf-8").replace('"cost_bp": 35', '"cost_bp": 30'), encoding="utf-8")
    try:
        VD.load_decl(bad)
        refused = False
    except VD.SDEError as e:
        refused = "not the frozen declaration" in str(e)
    z = __import__("statistics").NormalDist().inv_cdf(1 - 0.05 / 28)
    check(sha == VD.DECL_SHA and d["test_count"] == 14 == sum(len(v[2]) for v in VD.TESTS.values()) and refused and
          abs(z - 2.9137) < 1e-3,
          "the frozen declaration loads (12 rules, 14 tests with V6H / V6L on two exits; z = 2.91 for 14); a changed copy "
          "is refused")
    # 2 features by hand
    print("2. features by hand")
    rng = np.random.default_rng(2)
    nn = 200
    c = 100 * np.cumprod(1 + rng.normal(0, 0.02, nn))
    o = c * (1 + rng.normal(0, 0.003, nn))
    h, l = np.maximum(o, c) * 1.01, np.minimum(o, c) * 0.99
    v = rng.lognormal(10, 0.5, nn)
    F = SU.vol_arrays(o, h, l, c, v)
    t = nn - 1
    r = np.log(c[1:] / c[:-1])
    r10, r20 = r[-10:], r[-20:]
    rsj = ((r10[r10 > 0] ** 2).sum() - (r10[r10 < 0] ** 2).sum()) / (r10 ** 2).sum()
    tv = c * v
    trel = tv[t - 9:t + 1].mean() / np.median(tv[t - 129:t - 9])
    mv = np.abs(np.diff(c[t - 10:t + 1]))
    pc = np.r_[np.nan, c[:-1]]
    tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
    atr = tr[t - 13:t + 1].mean()
    shock = (np.max(pc[t - 9:t + 1] - c[t - 9:t + 1]) / atr) >= 2
    semi = np.sqrt(2 * np.mean(np.where(r20 < 0, r20 ** 2, 0)))
    jump = c.copy()
    jump[150:] = jump[150:] / 2                                     # an unadjusted 1:2 split
    Fj = SU.vol_arrays(o, h, l, jump, v)
    lc = np.zeros(12, bool)
    lc[[3, 9]] = True
    l3 = SU.lock3_of(lc)
    check(abs(F["rsj10"][t] - rsj) < 1e-12 and abs(F["turn_rel"][t] - trel) < 1e-9 and
          abs(F["lds10"][t] - mv.max() / mv.sum()) < 1e-12 and float(F["shock"][t]) == float(shock) and
          abs(F["ret20"][t] - (c[t] / c[t - 20] - 1)) < 1e-12 and abs(F["atrp"][t] - atr / c[t]) < 1e-12 and
          abs(F["semivol20"][t] - semi) < 1e-12 and abs(F["sde10"][t] - (c[t] - c[t - 10]) / mv.sum()) < 1e-12 and
          np.isnan(Fj["rsj10"][150:160]).all() and np.isnan(Fj["ret20"][150:170]).all() and
          np.isfinite(Fj["rsj10"][161]) and np.isnan(F["turn_rel"][:129]).all() and np.isfinite(F["turn_rel"][129]) and
          list(np.flatnonzero(l3)) == [3, 4, 5, 9, 10, 11],
          "rsj10, turn_rel (10 vs the median of the 120 before), lds10, shock, ret20, atrp, semivol20, sde10 at the last "
          "bar by hand; an unadjusted split blanks every window that holds it; turn_rel needs 130 bars; lock3 = a "
          "locked close on t-2..t")
    # 3 GJR
    print("3. GJR-GARCH")
    rg = np.random.default_rng(9)

    def sim(nobs, mu=0.03, om=0.03, a=0.04, g=0.10, b=0.88, nu=6):
        zz = rg.standard_t(nu, nobs) / np.sqrt(nu / (nu - 2))
        s2_ = om / (1 - a - g / 2 - b)
        out = np.empty(nobs)
        for k in range(nobs):
            e_ = np.sqrt(s2_) * zz[k]
            out[k] = mu + e_
            s2_ = om + (a + g * (e_ < 0)) * e_ * e_ + b * s2_
        return out
    rs = sim(6000)
    f = VD.gjr_fit(rs)
    eps = rs - f["mu"]
    hand = np.empty(len(rs))
    s_ = f["s0"]
    for k in range(len(rs)):
        s_ = f["omega"] + (f["alpha"] + f["gamma"] * (eps[k] < 0)) * eps[k] ** 2 + f["beta"] * s_
        hand[k] = s_
    fc = VD.gjr_forecast(rs, f)
    dts = pd.bdate_range("2014-01-01", periods=3200).to_numpy().astype("datetime64[D]")
    nifty = 10000 * np.exp(np.cumsum(sim(3200, mu=0.02, om=0.02) / 100))
    M, P = VD.market_vol(dts, nifty, log=None)
    cut = 2400
    M2, _ = VD.market_vol(dts[:cut], nifty[:cut], log=None)
    yr_cut = pd.Timestamp(dts[cut]).year
    same = M["date"].dt.year < yr_cut
    k = int(np.flatnonzero(np.isfinite(M["mvol_high"].to_numpy()) & (M["date"].dt.year >= 2016))[100])
    mv = M["mvol"].to_numpy()
    hi_hand = float(mv[k] >= np.quantile(mv[k - 252:k], 0.80))
    fa_hand = float(mv[k] < mv[k - 5])
    check(abs(f["alpha"] - 0.04) < 0.03 and abs(f["gamma"] - 0.10) < 0.06 and abs(f["beta"] - 0.88) < 0.05 and
          f["ok"] and np.allclose(fc, hand, rtol=1e-10) and
          np.allclose(M.loc[same, "mvol"].to_numpy(), M2.loc[same.to_numpy()[:cut], "mvol"].to_numpy(), equal_nan=True)
          and M.loc[same, "mvol"].notna().sum() > 1000 and int(P["year"].min()) == 2015 and
          M["mvol_high"].iloc[k] == hi_hand and M["mvol_falling"].iloc[k] == fa_hand and
          all(abs(M["mvol_p80"].iloc[j] - np.quantile(mv[j - 252:j], 0.80)) < 1e-12 for j in (k, k + 7, k + 50)),
          "GJR-t fit recovers alpha 0.04 / gamma 0.10 / beta 0.88 from 6,000 simulated days; the filter = the recursion "
          "by hand; the market regime uses only the past (removing every session from 2023 on changes no earlier "
          "value; 2014's warm-up is history only); mvol_high (>= 80th percentile of the 252 before) and mvol_falling by "
          "hand", (f, P.head(3).to_dict("records")))
    # 4 forecasts
    print("4. forecasts")
    E_ = VD.ewma(np.log(c[1:] / c[:-1]))
    rr = np.log(c[1:] / c[:-1])
    s_ = np.mean(rr[:20] ** 2)
    eh = []
    for x in rr:
        s_ = 0.94 * s_ + 0.06 * x * x
        eh.append(s_)
    YZ = VD.yang_zhang(o, h, l, c)
    nY = 20
    on_ = np.log(o[t - 19:t + 1] / c[t - 20:t])
    oc_ = np.log(c[t - 19:t + 1] / o[t - 19:t + 1])
    rs_ = (np.log(h / c) * np.log(h / o) + np.log(l / c) * np.log(l / o))[t - 19:t + 1]
    kk = 0.34 / (1.34 + 21 / 19)
    yz_h = on_.var(ddof=1) + kk * oc_.var(ddof=1) + (1 - kk) * rs_.mean()
    Z = VD.race_cols(o, h, l, c, pd.bdate_range("2019-01-01", periods=nn))
    rv_h = np.mean(np.log(c[101:106] / c[100:105]) ** 2)
    check(np.allclose(E_, eh, rtol=1e-12) and abs(YZ[t] - yz_h) < 1e-12 and abs(Z["rv5"][100] - rv_h) < 1e-12 and
          np.isnan(Z["rv5"][-5:]).all() and abs(Z["har_w"][t] - np.mean(r[-5:] ** 2)) < 1e-15,
          "EWMA (0.94, started at the first 20 squared returns), Yang-Zhang over 20 (k = 0.34 / (1.34 + 21/19)), RV5 = "
          "the mean squared return of the 5 sessions after, HAR's weekly input - by hand")
    # 5 verdicts and Holm
    print("5. verdicts and Holm")
    R = pd.DataFrame([{"test": "V2L", "exit": "X1", "parent": "N1", "kind": "buy", "period": pk, "events": 400,
                       "days": 150, "excess_bonf_lo": 0.001, "excess_lo": 0.002, "incr_lo": 0.001, "incr_mean": 0.002,
                       "incr_bonf_hi": 0.01, "incr_hi": 0.01} for pk in ("A", "B")])
    Y = pd.DataFrame([{"test": "V2L", "exit": "X1", "year": y, "events": 40, "excess_mean": 0.01 if y < 2024 else -0.01,
                       "incr_mean": -0.01 if y < 2024 else 0.01} for y in range(2016, 2027)])
    vb = VD.verdicts(R, Y, d).iloc[0]
    vb_c = VD.verdicts(R.assign(incr_lo=np.where(R.period == "A", -0.001, 0.001)), Y, d).iloc[0]
    vb_y = VD.verdicts(R, Y.assign(excess_mean=np.where(Y.year < 2023, 0.01, -0.01)), d).iloc[0]
    Rv = R.assign(test="V5K", parent="E0", kind="veto", incr_bonf_hi=-0.001, incr_hi=-0.002)
    vv = VD.verdicts(Rv, Y.assign(test="V5K"), d).iloc[0]
    vv_a = VD.verdicts(Rv.assign(incr_bonf_hi=np.where(Rv.period == "A", 0.001, -0.001)), Y.assign(test="V5K"), d).iloc[0]
    vv_few = VD.verdicts(Rv.assign(days=90), Y.assign(test="V5K"), d).iloc[0]
    H = VD.holm([{"engine": "D", "variant": "B1", "p": 0.004, "rule_verdict": "PASS"},
                 {"engine": "D", "variant": "B2", "p": 0.011, "rule_verdict": "PASS"},
                 {"engine": "D", "variant": "J_V2L", "p": 0.020, "rule_verdict": "PASS"},
                 {"engine": "ENS", "variant": "B1", "p": 0.020, "rule_verdict": "FAIL"},
                 {"engine": "ENS", "variant": "B2", "p": 0.03, "rule_verdict": "PASS"}])
    hh = {(r_["engine"], r_["variant"]): r_ for r_ in H}
    # D: 0.004 <= 0.025/3 kept; 0.011 <= 0.0125 kept; 0.020 <= 0.025 kept. ENS: 0.020 <= 0.0125? no -> stop
    check(vb["passed"] and vb["verdict"] == "SURVIVOR" and not vb_c["passed"] and "C" in vb_c["verdict"] and
          not vb_y["passed"] and "D" in vb_y["verdict"] and vv["passed"] and vv["verdict"] == "VETO CONFIRMED" and
          not vv_a["passed"] and vv_few["verdict"] == "TOO FEW EVENTS" and
          [hh[("D", x)]["final"] for x in ("B1", "B2", "J_V2L")] == ["PASS"] * 3 and
          hh[("ENS", "B1")]["final"] == "FAIL" and not hh[("ENS", "B1")]["holm_kept"] and
          not hh[("ENS", "B2")]["holm_kept"],
          "verdicts: a buy needs A, B, C (beats its parent) and 8 positive years; a veto needs its vs-parent upper "
          "bounds below 0 and 8 negative years; too few days = TOO FEW; Holm step-down by hand (D keeps all three at "
          "0.025/3, 0.025/2, 0.025; ENS stops at the first p above 0.0125)", (vb.to_dict(), vv.to_dict(), H))
    # 6 planted
    print("6. planted GARCH world")
    rootP = TMP / "planted"
    WP = make_world(rootP, planted=True)
    outP = TMP / "outP"
    rc, log = quiet(VD.main, ["run", "--root", str(rootP), "--out", str(outP), "--stage-e-any"])
    runs = sorted((outP / "runs").glob("VD_*")) if (outP / "runs").exists() else []
    if rc != 0 or not runs:
        check(False, "planted run", log[-2500:])
        return finish(t0, TMP)
    run = runs[-1]
    V = pd.read_csv(run / "verdicts.csv")
    Rr = pd.read_csv(run / "results.csv")
    RA = pd.read_csv(run / "race.csv")
    rep = (run / "REPORT.md").read_text(encoding="utf-8")
    meta = json.loads((run / "run.json").read_text())
    cmds = (run / "stage2_commands.txt").read_text(encoding="utf-8")
    cuts = pd.read_parquet(run / "daily_cuts.parquet")

    def vd(tid, x="X1"):
        return V[(V.test == tid) & (V.exit == x)].iloc[0]
    sha_ok = all(ln.split("  ", 1)[1].strip() in {p.name for p in run.iterdir()}
                 for ln in (run / "outputs.sha256").read_text().splitlines() if ln.strip())
    wrong_way = V[V.passed & V.test.isin(["V1L", "V3C", "V6L"])]     # opposite to every plant
    rb = RA[RA.period == "B"].set_index("method")
    check(vd("V2L")["verdict"] == "SURVIVOR" and vd("V5K")["verdict"] == "VETO CONFIRMED" and
          vd("V5D")["verdict"] in ("VETO CONFIRMED", "TOO FEW EVENTS") and vd("V6H", "X0")["verdict"] == "SURVIVOR" and
          not len(wrong_way) and meta["universe"] == 51 and meta["missing"] == ["NOBARS"] and sha_ok and
          rb.at["GJR", "qlike"] < rb.at["ATR", "qlike"] and rb.at["GJR", "spearman_vs_atr_lo"] > 0 and
          "J_V2L" in cmds and "J_V6H_X0" in cmds and "#B1 " in cmds and "#B2 " in cmds and "X_V5" not in cmds and
          cmds.count("--engines ENS") == cmds.count("--engines D ") and "--voldir" in cmds and
          (outP / "voldir_ledger.jsonl").is_file() and rep.index("Buy survivors") < rep.index("## Every test") and
          set(SU.CUT_COLS) <= set(cuts.columns) and len(cuts) == len(WP["days"]),
          "planted: V2L (thin-turnover orderly falls) survives; V5K (after a lower-band close) is a confirmed veto; V6H x "
          "X0 (jumpy winners on heavy turnover, 2nd close) survives; nothing that runs against the plants passes (V1L "
          "variance from falls, V3C, V6L thin-turnover winners); GJR beats ATR "
          "in the race (QLIKE and the daily rank correlation); Stage 2 lists B1, B2, J_V2L, J_V6H_X0 for D and ENS and "
          "nothing for V5; outputs hashed; daily_cuts has every session",
          (V[["test", "exit", "verdict"]].values.tolist(), rb[["qlike", "spearman_vs_atr_lo"]].to_dict(), log[-500:]))
    # 7 by hand from the stock files
    print("7. by hand from the stock files")
    r1, _ = VD.S.load_decl()
    D = VD.build(rootP, rootP / "panel" / "panel.parquet", d, r1, True, log=lambda m_: None)
    A = D["rows"]
    cal = D["cal"]
    samp = A.sample(30, random_state=4)
    ok_rows, bad_rows = True, []
    for r_ in samp.itertuples(index=False):
        sym = D["syms"][r_.sym]
        f_ = pd.read_parquet(rootP / f"{sym}_daily.parquet")
        dd_ = pd.to_datetime(f_["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
        i = int(np.flatnonzero(dd_.to_numpy().astype("datetime64[D]") == cal[r_.t])[0])
        cl = f_["close"].to_numpy(float)
        vo = f_["volume"].to_numpy(float)
        rr_ = np.log(cl[i - 9:i + 1] / cl[i - 10:i])
        rsj_h = ((rr_[rr_ > 0] ** 2).sum() - (rr_[rr_ < 0] ** 2).sum()) / (rr_ ** 2).sum()
        tv_ = cl * vo
        tr_h = tv_[i - 9:i + 1].mean() / np.median(tv_[i - 129:i - 9])
        x0_ok = r_.x0_status != "ok" or abs(r_.x0_net - (cl[i + 2] / f_["open"].iloc[i + 1] - 1 - 0.0035)) < 1e-9 or \
            cal[r_.x0_cal] != dd_.iloc[i + 2].to_datetime64().astype("datetime64[D]")
        g_ = (abs(r_.rsj10 - rsj_h) < 1e-5 and abs(r_.turn_rel - tr_h) < 1e-4 * max(1, tr_h) and
              abs(r_.entry - f_["open"].iloc[i + 1]) < 1e-9 and abs(r_.ret20 - (cl[i] / cl[i - 20] - 1)) < 1e-5 and x0_ok)
        ok_rows &= bool(g_)
        if not g_:
            bad_rows.append((sym, str(cal[r_.t]), r_.rsj10, rsj_h, r_.turn_rel, tr_h))
    day = int(A["t"].value_counts().index[0])
    g = A[A["t"] == day]
    cr = cuts.iloc[day]
    cut_ok = (abs(cr["rsj10_p10"] - g["rsj10"].quantile(0.10)) < 1e-7 and
              abs(cr["turn_rel_p67"] - g["turn_rel"].quantile(0.67)) < 1e-6 and
              abs(cr["atrp_p67"] - g["atrp"].quantile(0.67)) < 1e-8 and
              ((g["rsj_lo"] == 1) == (g["rsj10"] <= cr["rsj10_p10"])).all() and
              ((g["turn_hi"] == 1) == (g["turn_rel"] >= cr["turn_rel_p67"])).all() and
              (g["mvol_high"].fillna(-1) == (cr["mvol_high"] if np.isfinite(cr["mvol_high"]) else -1)).all())
    # V2L x X1 in period A from the rows (cooldown, the universe and N1 baselines)
    Aa = A.sort_values(["sym", "t"], kind="mergesort").reset_index(drop=True)
    use = Aa["x1_status"].isin(["ok", "stuck"])
    net = Aa["x1_net"].where(use)
    ub = net.groupby(Aa["t"]).mean()
    n1 = Aa["sde10"] < -0.5
    pb = net[n1].groupby(Aa["t"][n1]).mean()
    mm = n1 & (Aa["turn_lo"] == 1)
    idx = np.flatnonzero(mm)
    k2 = idx[VD.S.cooldown(Aa["sym"].to_numpy()[idx], Aa["t"].to_numpy()[idx], 5)]
    k2 = k2[use.to_numpy()[k2]]
    ya = pd.DatetimeIndex(cal[Aa["t"].to_numpy()[k2]]).year
    k2 = k2[(ya >= 2016) & (ya <= 2020)]
    exm = float((Aa["x1_net"].iloc[k2] - Aa["t"].iloc[k2].map(ub)).mean())
    inm = float((Aa["x1_net"].iloc[k2] - Aa["t"].iloc[k2].map(pb)).mean())
    rr2 = Rr[(Rr.test == "V2L") & (Rr.exit == "X1") & (Rr.period == "A")].iloc[0]
    # the race's ATR scale: the 2016-2020 mean of RV5 / ATR%^2 on the rows where every forecast exists
    RC = VD.race(A, cal, d, log=None)
    pa = (pd.DatetimeIndex(cal[A["t"].to_numpy()]).year <= 2020) & (pd.DatetimeIndex(cal[A["t"].to_numpy()]).year >= 2016)
    fa, yv = A["f_atr"].to_numpy(float), A["rv5"].to_numpy(float)
    com = np.isfinite(yv) & (yv > 0)
    for col in ("f_atr", "f_ewma", "f_yz", "f_gjr"):
        com &= np.isfinite(A[col].to_numpy(float)) & (A[col].to_numpy(float) > 0)
    Xh = np.c_[np.ones(len(A)), A["har_d"], A["har_w"], A["har_m"]].astype(float)
    com &= np.isfinite(Xh @ np.asarray(RC["har_beta"]))
    sc_h = float(np.mean(yv[com & pa] / fa[com & pa]))
    sc_ok = abs(RC["table"].set_index(["method", "period"]).at[("ATR", "A"), "scale"] - sc_h) < 1e-9 * max(1, sc_h)
    check(ok_rows and cut_ok and abs(exm - rr2["excess_mean"]) < 1e-9 and abs(inm - rr2["incr_mean"]) < 1e-9 and
          rr2["events"] == len(k2) and sc_ok,
          "by hand from the stock files: rsj10, turn_rel and ret20 at the signal close, entry at the NEXT open, X0 = the "
          "2nd close net of 35 bp; one day's cuts (quantiles of the eligible stocks) and flags; V2L x X1 in 2016-2020 "
          "recomputed (cooldown, the universe and the N1 baselines); the race's ATR scale = the 2016-2020 mean of "
          "RV5 / ATR%^2 on the common rows",
          (bad_rows[:3], cut_ok, sc_ok, exm, rr2["excess_mean"], inm, rr2["incr_mean"], rr2["events"], len(k2)))
    # 8 absent
    print("8. absent GARCH world: no plants")
    rootA = TMP / "absent"
    make_world(rootA, planted=False, n_syms=60, seed=8)
    outA = TMP / "outA"
    rc, log = quiet(VD.main, ["run", "--root", str(rootA), "--out", str(outA), "--stage-e-any"])
    runA = sorted((outA / "runs").glob("VD_*"))[-1] if rc == 0 else None
    VA = pd.read_csv(runA / "verdicts.csv") if runA else pd.DataFrame({"passed": [True]})
    repA = (runA / "REPORT.md").read_text(encoding="utf-8") if runA else ""
    cmA = (runA / "stage2_commands.txt").read_text(encoding="utf-8") if runA else ""
    check(rc == 0 and not VA["passed"].any() and "Buy survivors: 0" in repA and "Vetoes confirmed: 0" in repA and
          cmA.count("tl_backtest.py") == 4,
          "absent (GARCH with leverage, fat tails and price bands, nothing planted): no buy survives, no veto is "
          "confirmed, and Stage 2 lists only B1 and B2 for each engine", (VA[["test", "exit", "verdict"]].values.tolist()
                                                                          if runA else log[-800:]))
    # 9 guards
    print("9. guards")
    g1 = quiet(VD.main, ["run", "--out", str(outA), "--stage-e-any"])
    g2 = quiet(VD.main, ["check"])
    real = VD.STRAT_FILE
    alt = TMP / "voldir_strat.py"
    alt.write_text(real.read_text(encoding="utf-8") + "\n# changed\n", encoding="utf-8")
    VD.STRAT_FILE = alt
    g3 = quiet(VD.main, ["check"])
    VD.STRAT_FILE = real
    fk = TMP / "tlb"
    for nm in ("TLB_1", "TLB_2"):
        f_ = fk / nm
        f_.mkdir(parents=True)
        shutil.copy2(real, f_ / "strategy_voldir.py")
        (f_ / "summary.json").write_text(json.dumps({"strategy": {"name": "voldir_B1", "variant": "B1",
                                                                  "picks": {"engines": ["D"]}},
                                                     "compare": {"name": "tree"},
                                                     "decision": {"verdict": "PASS", "p_one_sided": 0.001}}))
    g4 = quiet(VD.main, ["holm", "--scan", str(fk)])
    shutil.rmtree(fk / "TLB_2")
    g5 = quiet(VD.main, ["holm", "--scan", str(fk)])
    check(g1[0] == 2 and "--root is required" in g1[1] and g2[0] == 0 and "as declared" in g2[1] and g3[0] == 2 and
          "not the declared" in g3[1] and g4[0] == 2 and "appears twice" in g4[1] and g5[0] == 0 and
          "D | B1 | PASS | 0.0010 | 0.0250 | yes | PASS" in g5[1],
          "guards: no --root is refused; check confirms the declaration and strategies\\voldir.py, and refuses a changed "
          "strategies file; holm refuses a test run twice and Holm-corrects a single run by hand",
          [x[1][-300:] for x in (g1, g2, g3, g4, g5)])
    return finish(t0, TMP)


def finish(t0, TMP) -> int:
    shutil.rmtree(TMP, ignore_errors=True)
    nf = RESULTS.count(False)
    print(f"{len(RESULTS)} checks, {nf} failures, {time.time() - t0:.0f} s, pandas {pd.__version__} / numpy {np.__version__}")
    if nf == 0:
        print("VERIFIED (voldir v1.0)")
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
