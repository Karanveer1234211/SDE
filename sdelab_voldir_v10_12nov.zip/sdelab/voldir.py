"""
voldir.py - voldir v1.0: volatility x direction on the whole NSE universe (study VD1), beside sdelab.

    python voldir.py check                                   the declaration (and tradelab's strategies\\voldir.py) are
                                                             the frozen ones (sha256)
    python voldir.py run --root %CACHE_DAILY_ROOT%           Stage 0 (forecast race) + Stage 1 (14 tests) ->
                         [--panel <panel.parquet>] [--out <folder>] [--stage-e-any] [--pm-run PM_...]
                                                             SDELAB_OUT\\runs\\VD_<date>_<nnn>
    python voldir.py holm <TLB folder> [<TLB folder> ...]    Stage 2: Holm across each engine's family of
                         | --scan <tradelab backtest folder>  tl_backtest runs of strategies\\voldir.py

VOLDIR_DECLARATION.json (beside this file, frozen 12 Nov 2026 before any run) holds everything: the features, the 14
tests (12 rules, two of them with two exits), their parents, the buy and veto decisions, the forecast race and Stage 2.
The universe, the honest exits, the costs, the cooldown, the periods and the bootstrap are R1's (sdelab.py's own code).

READS (read only): the daily cache through production's loader and lower-circuit rule (stage_e_execution via tradelab's
tl_data), the panel's symbol list; tradelab's tl_setups.vol_arrays is the one definition of the stock features (tradelab
add-on v1.5 reads the same at every pick). WRITES only under --out / SDELAB_OUT: VD_<date>_<nnn>\\ REPORT.md,
verdicts.csv, results.csv, years.csv, race.csv, market_vol.csv, gjr_params.csv, daily_cuts.parquet (tradelab's
--voldir reads it), stage2_commands.txt, run.json, DECLARATION.json, outputs.sha256; one line per run in
voldir_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import statistics
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
try:
    from scipy.optimize import minimize
    from scipy.signal import lfilter
    from scipy.special import gammaln
except ImportError:                                       # pragma: no cover
    sys.exit("voldir needs scipy (the GJR-GARCH fits): pip install scipy")

import sdelab as S
from sdelab import SDEError, say, sha256

TC, TD, SU = S.TC, S.TD, S.SU

VERSION = "voldir v1.0"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "VOLDIR_DECLARATION.json"
DECL_SHA = "0cb7f61653894fe77335357333c9bfd1e975d7f0f3a0057a73a002c3db2319c3"
STRAT_FILE = HERE.parent / "tradelab" / "strategies" / "voldir.py"
LEDGER = "voldir_ledger.jsonl"
TESTS = {"V1L": ("E0", "buy", ("X1",)), "V1H": ("E0", "buy", ("X1",)), "V2L": ("N1", "buy", ("X1",)),
         "V2H": ("N1", "veto", ("X1",)), "V3D": ("N1", "buy", ("X1",)), "V3C": ("N1", "veto", ("X1",)),
         "V4F": ("N1", "buy", ("X1",)), "V4R": ("N1", "veto", ("X1",)), "V5K": ("E0", "veto", ("X1",)),
         "V5D": ("N1", "veto", ("X1",)), "V6H": ("J", "buy", ("X0", "X1")), "V6L": ("J", "veto", ("X0", "X1"))}
EXITS = {"X0": 2, "X1": 5}
PARENTS = ("E0", "N1", "J")
METHODS = ("ATR", "EWMA", "YZ", "HAR", "GJR")
STAGE2 = {"V1L": ["J_V1L"], "V1H": ["J_V1H"], "V2L": ["J_V2L"], "V3D": ["J_V3D"], "V4F": ["J_V4F"],
          ("V6H", "X0"): ["J_V6H_X0"], ("V6H", "X1"): ["J_V6H_X1"], "V2H": ["X_V2H"], "V3C": ["X_V3C"],
          "V4R": ["X_V4R"], "V6L": ["X_V6L"]}
EWMA_LAMBDA = 0.94
GJR_MIN_FIT, MKT_MIN_FIT = 500, 200
RACE_END = "2020-12-31"
MVOL_PCT, MVOL_WIN, MVOL_LAG = 0.80, 252, 5


# ---------------------------------------------------------------------------------------------------- declaration
def load_decl(path: Path = DECL_FILE, check: bool = True) -> Tuple[dict, str]:
    if not Path(path).is_file():
        raise SDEError(f"{path} is missing - it ships beside voldir.py")
    sha = sha256(path)
    if check and sha != DECL_SHA:
        raise SDEError(f"{path} has sha256 {sha[:16]}, not the frozen declaration's {DECL_SHA[:16]}. The declaration "
                       f"is fixed before any run; a changed study is a new declaration (ask Claude).")
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    t = d.get("tests") or {}
    if set(t) != set(TESTS) or any((t[k]["parent"], t[k]["kind"], tuple(t[k]["exits"])) != v for k, v in TESTS.items()):
        raise SDEError(f"{path}: the tests differ from the ones this code implements")
    if d["test_count"] != sum(len(v[2]) for v in TESTS.values()) or d["stats"]["tests"] != d["test_count"]:
        raise SDEError(f"{path}: the test count differs from the tests listed")
    if {k: v["hold"] for k, v in d["exits"].items()} != EXITS:
        raise SDEError(f"{path}: the exits differ from the ones this code implements")
    return d, sha


def strategies_sha(decl: dict) -> Tuple[Optional[str], str]:
    """(sha256 of tradelab's strategies\\voldir.py or None, the declared one)."""
    want = decl["stage2_book"].get("strategies_sha256", "")
    return (sha256(STRAT_FILE) if STRAT_FILE.is_file() else None), want


# ---------------------------------------------------------------------------------------------------- GJR-GARCH
def gjr_path(eps: np.ndarray, omega: float, alpha: float, gamma: float, beta: float, s0: float):
    """sig2[t] = variance of eps[t] given t-1; fc[t] = the forecast made at t's close for t+1 (a blank eps = 0)."""
    e = np.nan_to_num(np.asarray(eps, float))
    x = omega + (alpha + gamma * (e < 0)) * e * e
    fc = lfilter([1.0], [1.0, -beta], x, zi=[beta * s0])[0]
    return np.r_[s0, fc[:-1]], fc


def gjr_nll(p: np.ndarray, r: np.ndarray, ok: np.ndarray, s0: float) -> float:
    mu, omega, alpha, gamma, beta, nu = p
    if alpha + gamma / 2 + beta >= 0.999 or omega <= 0 or nu <= 2.05:
        return 1e12
    eps = np.where(ok, r - mu, 0.0)
    sig2, _ = gjr_path(eps, omega, alpha, gamma, beta, s0)
    sig2 = np.maximum(sig2, 1e-12)
    e2 = eps[ok] ** 2
    s2 = sig2[ok]
    ll = (gammaln((nu + 1) / 2) - gammaln(nu / 2) - 0.5 * math.log(math.pi * (nu - 2)) - 0.5 * np.log(s2)
          - (nu + 1) / 2 * np.log1p(e2 / ((nu - 2) * s2)))
    v = -float(ll.sum())
    return v if np.isfinite(v) else 1e12


def gjr_fit(r: np.ndarray) -> dict:
    """GJR-GARCH(1,1), Student-t errors, constant mean, by maximum likelihood (returns in percent; blank = no news)."""
    r = np.asarray(r, float)
    ok = np.isfinite(r)
    n = int(ok.sum())
    out = {"n": n, "ok": False}
    if n < 50:
        return out
    m, v = float(np.mean(r[ok])), float(np.var(r[ok]))
    if not v > 0:
        return out
    x0 = np.array([m, 0.05 * v, 0.03, 0.08, 0.88, 8.0])
    bnd = [(m - 2 * math.sqrt(v), m + 2 * math.sqrt(v)), (1e-6 * v, 5 * v), (0.0, 0.5), (0.0, 0.5), (0.0, 0.998),
           (2.1, 60.0)]
    rz = np.where(ok, r, 0.0)
    res = minimize(gjr_nll, x0, args=(rz, ok, v), method="L-BFGS-B", bounds=bnd, options={"maxiter": 300})
    p = res.x
    out.update({"mu": float(p[0]), "omega": float(p[1]), "alpha": float(p[2]), "gamma": float(p[3]),
                "beta": float(p[4]), "nu": float(p[5]), "s0": v, "nll": float(res.fun),
                "ok": bool(np.isfinite(res.fun) and res.fun < 1e11)})
    return out


def gjr_forecast(r: np.ndarray, fit: dict) -> np.ndarray:
    """The one-session-ahead variance forecast at every close (percent^2), filtered with fixed parameters."""
    eps = np.where(np.isfinite(r), np.asarray(r, float) - fit["mu"], np.nan)
    return gjr_path(eps, fit["omega"], fit["alpha"], fit["gamma"], fit["beta"], fit["s0"])[1]


def market_vol(dates: np.ndarray, close: np.ndarray, log=say) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """NIFTY50: parameters for calendar year Y fitted on every return before 1 Jan Y (at least MKT_MIN_FIT); the first
    fitted year's parameters also give the warm-up year(s) (history only). mvol = sqrt(forecast for the next session),
    percent; mvol_high = mvol >= the 80th percentile of the 252 sessions before; mvol_falling = mvol < mvol 5 before."""
    d = np.asarray(dates).astype("datetime64[D]")
    r = SU.log_returns(close) * 100
    yrs = pd.DatetimeIndex(d).year.to_numpy()
    mvol = np.full(len(d), np.nan)
    rows = []
    first = None
    for y in sorted(set(yrs)):
        est = (d < np.datetime64(f"{y}-01-01")) & np.isfinite(r)
        if est.sum() < MKT_MIN_FIT:
            continue
        f = gjr_fit(np.where(d < np.datetime64(f"{y}-01-01"), r, np.nan)[: int(np.flatnonzero(est)[-1]) + 1])
        if not f["ok"]:
            continue
        fc = gjr_forecast(r, f)
        m = yrs == y
        mvol[m] = np.sqrt(np.maximum(fc[m], 0))
        rows.append({"year": int(y), "fitted_on_returns": f["n"], **{k: f[k] for k in ("mu", "omega", "alpha", "gamma",
                                                                                     "beta", "nu")}})
        if first is None:
            first = (y, fc)
    if first is not None:
        warm = yrs < first[0]
        mvol[warm] = np.sqrt(np.maximum(first[1][warm], 0))
    s = pd.Series(mvol)
    p80 = s.shift(1).rolling(MVOL_WIN, min_periods=MVOL_WIN).quantile(MVOL_PCT).to_numpy(float)
    lag5 = s.shift(MVOL_LAG).to_numpy(float)
    with np.errstate(invalid="ignore"):
        high = np.where(np.isfinite(mvol) & np.isfinite(p80), (mvol >= p80).astype(float), np.nan)
        fall = np.where(np.isfinite(mvol) & np.isfinite(lag5), (mvol < lag5).astype(float), np.nan)
    M = pd.DataFrame({"date": pd.DatetimeIndex(d), "mvol": mvol, "mvol_p80": p80, "mvol_lag5": lag5,
                      "mvol_high": high, "mvol_falling": fall})
    if log:
        log(f"market volatility: NIFTY50 GJR-GARCH refitted for {len(rows)} years; high-volatility sessions "
            f"{np.nanmean(high):.1%} of those known")
    return M, pd.DataFrame(rows)


# ---------------------------------------------------------------------------------------------------- forecasts
def ewma(r: np.ndarray, lam: float = EWMA_LAMBDA) -> np.ndarray:
    r2 = np.nan_to_num(np.asarray(r, float) ** 2)
    first = r2[np.isfinite(np.asarray(r, float))][:20]
    seed = float(np.mean(first)) if len(first) else 0.0
    return lfilter([1 - lam], [1.0, -lam], r2, zi=[lam * seed])[0]


def yang_zhang(o, h, l, c, n: int = 20) -> np.ndarray:
    o, h, l, c = (np.asarray(x, float) for x in (o, h, l, c))
    pc = np.r_[np.nan, c[:-1]]
    with np.errstate(divide="ignore", invalid="ignore"):
        on = np.log(o / pc)
        on[np.abs(o / pc - 1) > SU.SDE_JUMP] = np.nan
        oc = np.log(c / o)
        rs = np.log(h / c) * np.log(h / o) + np.log(l / c) * np.log(l / o)
    k = 0.34 / (1.34 + (n + 1) / (n - 1))
    vo = pd.Series(on).rolling(n, min_periods=n).var(ddof=1).to_numpy(float)
    vc = pd.Series(oc).rolling(n, min_periods=n).var(ddof=1).to_numpy(float)
    vr = pd.Series(rs).rolling(n, min_periods=n).mean().to_numpy(float)
    return vo + k * vc + (1 - k) * vr


def race_cols(o, h, l, c, dates) -> Dict[str, np.ndarray]:
    """Per bar: the target RV5 (the mean r^2 of the 5 sessions after t) and the forecasts' inputs at t."""
    r = SU.log_returns(c)
    n = len(r)
    r2 = r * r
    fin = np.isfinite(r).astype(float)
    nxt = pd.Series(np.nan_to_num(r2)).rolling(5, min_periods=5).sum().shift(-5).to_numpy(float)
    cnt = pd.Series(fin).rolling(5, min_periods=5).sum().shift(-5).to_numpy(float)
    rv5 = np.where(cnt >= 5, nxt / 5, np.nan)
    out = {"rv5": rv5, "f_ewma": ewma(r), "f_yz": yang_zhang(o, h, l, c),
           "har_d": r2, "har_w": SU._roll(r2, 5, "mean"), "har_m": SU._roll(r2, 22, "mean"), "f_gjr": np.full(n, np.nan)}
    d = np.asarray(dates).astype("datetime64[D]")
    est = d <= np.datetime64(RACE_END)
    if np.isfinite(r[est]).sum() >= GJR_MIN_FIT:
        f = gjr_fit(np.where(est, r * 100, np.nan)[: int(np.flatnonzero(est)[-1]) + 1])
        if f["ok"]:
            out["f_gjr"] = gjr_forecast(r * 100, f) / 1e4
    return out


# ---------------------------------------------------------------------------------------------------- the universe
def stock_rows(sym: str, sid: int, ds, cal: np.ndarray, r1: dict) -> Optional[pd.DataFrame]:
    """R1's eligible rows (sdelab.stock_rows: the universe, the entry, X1) + X0, the volatility features and the race."""
    R, _ = S.stock_rows(sym, sid, ds, cal, r1)
    if R is None:
        return None
    o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
    v = np.asarray(ds.v, float) if ds.v is not None else np.full(len(c), np.nan)
    n = len(c)
    ci = np.searchsorted(cal, ds.dates)
    idx = np.searchsorted(ci, R["t"].to_numpy())
    if not np.array_equal(ci[idx], R["t"].to_numpy()):
        raise SDEError(f"{sym}: rows and bars disagree")
    lc, lo, _ = S.lock_arrays(ds)
    F = SU.vol_arrays(o, h, l, c, v)
    e = idx + 1
    b0, p0, s0 = S.time_exit(e + EXITS["X0"] - 1, c, o, lc, lo, n)
    cost = r1["cost_bp"] / 1e4
    entry = o[e]
    Z = race_cols(o, h, l, c, ds.dates)
    f32 = np.float32
    add = {"x0_cal": np.where(b0 >= 0, ci[np.clip(b0, 0, n - 1)], -1).astype(np.int32),
           "x0_net": (p0 / entry - 1 - cost).astype(np.float64), "x0_status": pd.Categorical(s0, categories=S.STATUS),
           "atrp": F["atrp"][idx].astype(f32), "rsj10": F["rsj10"][idx].astype(f32),
           "turn_rel": F["turn_rel"][idx].astype(f32), "lds10": F["lds10"][idx].astype(f32),
           "shock_v": F["shock"][idx].astype(f32), "ret20": F["ret20"][idx].astype(f32),
           "semivol20": F["semivol20"][idx].astype(f32), "lock3": SU.lock3_of(lc)[idx],
           "f_atr": (F["atrp"][idx] ** 2).astype(f32)}
    for k, x in Z.items():
        add[k] = x[idx].astype(f32)
    return pd.concat([R.drop(columns=["x2_cal", "x2_net", "x2_status", "x2_why", "flags"]),
                      pd.DataFrame(add, index=R.index)], axis=1)


def build(root: Path, panel: Path, decl: dict, r1: dict, stage_e_any: bool, log=say) -> dict:
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    cal = np.asarray(market.cal).astype("datetime64[D]")
    rule, rule_txt = S.etf_rule(root)
    syms, dropped = S.universe_symbols(panel, rule)
    log(f"universe: {len(syms):,} symbols from {Path(panel).name} ({dropped:,} ETFs / indices left out by {rule_txt}); "
        f"calendar {len(cal):,} sessions {cal[0]}..{cal[-1]}")
    nds = market.series("NIFTY50")
    if nds is None or not len(nds):
        raise SDEError("NIFTY50 has no daily bars - the market volatility needs it")
    M, P = market_vol(nds.dates, nds.c, log)
    M = M.set_index(M["date"].to_numpy().astype("datetime64[D]")).reindex(cal)
    frames, missing = [], []
    t0 = time.time()
    for k, s in enumerate(syms):
        ds = market.series(s)
        if ds is None or len(ds.c) == 0:
            missing.append(s)
            continue
        R = stock_rows(s, k, ds, cal, r1)
        if R is not None:
            frames.append(R)
        market.daily.pop(s, None)
        if k and k % 200 == 0:
            log(f"   {k:,} of {len(syms):,} stocks ({time.time() - t0:.0f}s)")
    if not frames:
        raise SDEError("no eligible stock-days in the universe")
    A = pd.concat(frames, ignore_index=True)
    A["year"] = pd.DatetimeIndex(cal[A["t"].to_numpy()]).year.astype(np.int16)
    # the day's cross-section (eligible stocks) and the market regime -> daily_cuts and the flags (tl_setups.cut_flags)
    g = A.groupby("t")
    Cq = pd.DataFrame({"rsj10_p10": g["rsj10"].quantile(0.10), "rsj10_p90": g["rsj10"].quantile(0.90),
                       "turn_rel_p33": g["turn_rel"].quantile(0.33), "turn_rel_p67": g["turn_rel"].quantile(0.67),
                       "atrp_p67": g["atrp"].quantile(0.67), "ret20_p90": g["ret20"].quantile(0.90),
                       "n_eligible": g.size()})
    cuts = pd.DataFrame(index=np.arange(len(cal)))
    cuts["date"] = pd.DatetimeIndex(cal)
    for k in Cq.columns:
        cuts[k] = Cq[k].reindex(cuts.index).to_numpy(float)
    for k in ("mvol", "mvol_p80", "mvol_high", "mvol_falling"):
        cuts[k] = M[k].to_numpy(float)
    Ct = cuts.iloc[A["t"].to_numpy()].reset_index(drop=True)
    fl = SU.cut_flags(A["rsj10"].to_numpy(float), A["turn_rel"].to_numpy(float), A["atrp"].to_numpy(float),
                      A["ret20"].to_numpy(float), Ct)
    for k, x in fl.items():
        A[k[4:]] = x.astype(np.float32)
    return {"rows": A, "syms": syms, "cal": cal, "missing": missing, "etf_rule": rule_txt, "dropped": dropped,
            "prod": prod.describe(), "cuts": cuts, "mvol": M.reset_index(drop=True).assign(date=pd.DatetimeIndex(cal)),
            "gjr": P}


# ---------------------------------------------------------------------------------------------------- the tests
def masks(A: pd.DataFrame) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    one = lambda c: (A[c].to_numpy(float) == 1)                                   # noqa: E731 (blank = no)
    zero = lambda c: (A[c].to_numpy(float) == 0)                                  # noqa: E731
    with np.errstate(invalid="ignore"):
        n1 = A["sde10"].to_numpy(float) < -0.5
        lds = A["lds10"].to_numpy(float)
    lock = A["lock3"].to_numpy(bool)
    P = {"E0": np.ones(len(A), bool), "N1": n1, "J": one("atr_hi")}
    with np.errstate(invalid="ignore"):
        T = {"V1L": one("rsj_lo"), "V1H": one("rsj_hi"), "V2L": n1 & one("turn_lo"), "V2H": n1 & one("turn_hi"),
             "V3D": n1 & (lds < 0.35) & zero("shock_v"), "V3C": n1 & ((lds >= 0.35) | one("shock_v")),
             "V4F": n1 & one("mvol_high") & one("mvol_falling"), "V4R": n1 & one("mvol_high") & zero("mvol_falling"),
             "V5K": lock, "V5D": n1 & lock,
             "V6H": one("atr_hi") & one("ret20_top") & one("turn_hi"),
             "V6L": one("atr_hi") & one("ret20_top") & one("turn_lo")}
    return T, P


def evaluate(D: dict, decl: dict, log=say) -> dict:
    A, cal = D["rows"].sort_values(["sym", "t"], kind="mergesort").reset_index(drop=True), D["cal"]
    st = decl["stats"]
    z = statistics.NormalDist().inv_cdf(1 - st["alpha"] / (2 * st["tests"]))
    gap = int(decl["cooldown_sessions"])
    per = decl["periods"]
    TM, PM = masks(A)
    T, SY = A["t"].to_numpy(), A["sym"].to_numpy()
    usable = {x: A[f"{x.lower()}_status"].isin(["ok", "stuck"]).to_numpy() for x in EXITS}
    base = {}
    for x in EXITS:
        net = A[f"{x.lower()}_net"].where(usable[x])
        for p, m in PM.items():
            base[(p, x)] = net[m].groupby(A["t"][m]).mean()
    rows, years, events = [], [], {}
    for tid, (parent, kind, exits) in TESTS.items():
        idx = np.flatnonzero(TM[tid])
        keep = idx[S.cooldown(SY[idx], T[idx], gap)]
        events[tid] = keep
        for x in exits:
            kk = keep[usable[x][keep]]
            net = A[f"{x.lower()}_net"].to_numpy(float)[kk]
            tt = pd.Series(T[kk])
            ex = net - tt.map(base[("E0", x)]).to_numpy(float)
            inc = net - tt.map(base[(parent, x)]).to_numpy(float)
            for pk, pv in per.items():
                pm = S.period_mask(cal, T[kk], pv)
                bx, bi = S.boot(T[kk][pm], ex[pm], st, z), S.boot(T[kk][pm], inc[pm], st, z)
                rows.append({"test": tid, "exit": x, "parent": parent, "kind": kind, "period": pk, "events": bx["n"],
                             "days": bx["days"], "net_mean": float(np.mean(net[pm])) if pm.any() else np.nan,
                             "win_rate": float(np.mean(net[pm] > 0)) if pm.any() else np.nan,
                             "excess_mean": bx["mean"], "excess_lo": bx["lo"], "excess_hi": bx["hi"],
                             "excess_bonf_lo": bx["bonf_lo"], "excess_bonf_hi": bx["bonf_hi"],
                             "incr_mean": bi["mean"], "incr_lo": bi["lo"], "incr_hi": bi["hi"],
                             "incr_bonf_lo": bi["bonf_lo"], "incr_bonf_hi": bi["bonf_hi"]})
            yr = A["year"].to_numpy()[kk]
            for y in range(2016, 2027):
                ym = yr == y
                years.append({"test": tid, "exit": x, "year": y, "events": int(ym.sum()),
                              "excess_mean": float(np.mean(ex[ym])) if ym.any() else np.nan,
                              "incr_mean": float(np.mean(inc[ym])) if ym.any() else np.nan})
    R, Y = pd.DataFrame(rows), pd.DataFrame(years)
    log(f"   {len(R) // 2} tests evaluated (z = {z:.3f})")
    return {"results": R, "years": Y, "verdicts": verdicts(R, Y, decl), "events": events, "z": z, "rows": A}


def verdicts(R: pd.DataFrame, Y: pd.DataFrame, decl: dict) -> pd.DataFrame:
    st = decl["stats"]
    out = []
    for (tid, x), g in R.groupby(["test", "exit"], sort=False):
        a, b = g[g["period"] == "A"].iloc[0], g[g["period"] == "B"].iloc[0]
        y = Y[(Y["test"] == tid) & (Y["exit"] == x)]
        enough = all(p["events"] >= st["min_events"] and p["days"] >= st["min_days"] for p in (a, b))
        kind = a["kind"]
        big = y["events"] >= st["year_min_events"]
        if kind == "buy":
            cA, cB = bool(enough and a["excess_bonf_lo"] > 0), bool(enough and b["excess_lo"] > 0)
            cC = bool(enough and a["incr_lo"] > 0 and b["incr_mean"] > 0)
            yrs = int((big & (y["excess_mean"] > 0)).sum())
            ok = enough and cA and cB and cC and yrs >= 8
            word = "SURVIVOR"
        else:
            cA, cB = bool(enough and a["incr_bonf_hi"] < 0), bool(enough and b["incr_hi"] < 0)
            cC = True
            yrs = int((big & (y["incr_mean"] < 0)).sum())
            ok = enough and cA and cB and yrs >= 8
            word = "VETO CONFIRMED"
        why = word if ok else ("TOO FEW EVENTS" if not enough else "fails " + ", ".join(
            k for k, c_ in (("A", cA), ("B", cB), ("C", cC), ("D", yrs >= 8)) if not c_))
        out.append({"test": tid, "exit": x, "parent": a["parent"], "kind": kind, "A": cA, "B": cB,
                    "C": cC if kind == "buy" else None, "D_years": yrs, "enough": enough, "passed": bool(ok),
                    "verdict": why})
    return pd.DataFrame(out)


# ---------------------------------------------------------------------------------------------------- the race
def race(A: pd.DataFrame, cal: np.ndarray, decl: dict, log=say) -> dict:
    per = decl["periods"]
    pa = S.period_mask(cal, A["t"].to_numpy(), per["A"])
    X = np.c_[np.ones(len(A)), A["har_d"].to_numpy(float), A["har_w"].to_numpy(float), A["har_m"].to_numpy(float)]
    y = A["rv5"].to_numpy(float)
    okh = pa & np.isfinite(X).all(1) & np.isfinite(y)
    beta = np.linalg.lstsq(X[okh], y[okh], rcond=None)[0] if okh.sum() > 10 else np.full(4, np.nan)
    F = {"ATR": A["f_atr"].to_numpy(float), "EWMA": A["f_ewma"].to_numpy(float), "YZ": A["f_yz"].to_numpy(float),
         "HAR": np.maximum(X @ beta, 1e-10), "GJR": A["f_gjr"].to_numpy(float)}
    com = np.isfinite(y) & (y > 0)
    for f in F.values():
        com &= np.isfinite(f) & (f > 0)
    t = A["t"].to_numpy()
    out_rows, days = [], {}
    scale = {k: float(np.mean(y[com & pa] / F[k][com & pa])) if (com & pa).any() else np.nan for k in METHODS}
    G = pd.DataFrame({"t": t[com], "y": y[com], **{k: F[k][com] for k in METHODS}})
    rk = G.groupby("t")[["y"] + list(METHODS)].rank()
    rk["t"] = G["t"].to_numpy()
    cnt = rk.groupby("t")["y"].transform("size").to_numpy()
    rk = rk[cnt >= 10]
    rho = {}
    for k in METHODS:
        gg = rk[["t", "y", k]].copy()
        gg["yy"], gg["kk"], gg["yk"] = gg["y"] ** 2, gg[k] ** 2, gg["y"] * gg[k]
        s = gg.groupby("t").agg(n=("y", "size"), sy=("y", "sum"), sk=(k, "sum"), syy=("yy", "sum"), skk=("kk", "sum"),
                                syk=("yk", "sum"))
        cov = s["syk"] - s["sy"] * s["sk"] / s["n"]
        vy, vk = s["syy"] - s["sy"] ** 2 / s["n"], s["skk"] - s["sk"] ** 2 / s["n"]
        rho[k] = (cov / np.sqrt(vy * vk)).astype(float)
    for pk, pv in per.items():
        pm = S.period_mask(cal, t, pv) & com
        for k in METHODS:
            q = y[pm] / (scale[k] * F[k][pm])
            ql = float(np.mean(q - np.log(q) - 1)) if pm.any() else np.nan
            rd = rho[k][S.period_mask(cal, rho[k].index.to_numpy(), pv)]
            ra = rho["ATR"][rd.index]
            m, lo, hi = TC.bootstrap_daily((rd - ra).to_numpy(float))
            out_rows.append({"method": k, "period": pk, "rows": int(pm.sum()), "days": int(len(rd)), "scale": scale[k],
                             "qlike": ql, "spearman_mean": float(rd.mean()) if len(rd) else np.nan,
                             "spearman_vs_atr": m, "spearman_vs_atr_lo": lo, "spearman_vs_atr_hi": hi})
    Rr = pd.DataFrame(out_rows)
    rb = Rr[Rr["period"] == "B"].set_index("method")
    atr_q = rb.at["ATR", "qlike"] if "ATR" in rb.index else np.nan
    beats = [k for k in METHODS if k != "ATR" and k in rb.index and rb.at[k, "qlike"] < atr_q and
             rb.at[k, "spearman_vs_atr_lo"] > 0]
    Rr["beats_atr"] = [(r.method in beats) if r.period == "B" else None for r in Rr.itertuples(index=False)]
    if log:
        log(f"   race: {int(com.sum()):,} common rows; beats ATR in B: {beats or 'none'}")
    return {"table": Rr, "beats": beats, "har_beta": [float(b) for b in beta], "common_rows": int(com.sum())}


# ---------------------------------------------------------------------------------------------------- report
def bp(m, lo=np.nan, hi=np.nan) -> str:
    return S.bp(m, lo, hi)


def stage2_list(V: pd.DataFrame) -> List[str]:
    out = ["B1", "B2"]
    for r in V[V["passed"]].itertuples(index=False):
        for key in ((r.test, r.exit), r.test):
            if key in STAGE2:
                for v in STAGE2[key]:
                    if v not in out:
                        out.append(v)
                break
    return out


def stage2_commands(names: List[str], run: Path, pm_run: str) -> List[str]:
    L = []
    for eng in ("D", "ENS"):
        for v in names:
            L.append(f'python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run {pm_run} --strategy strategies\\voldir.py#{v} '
                     f'--compare strategies\\tree.py --engines {eng} --voldir "{run}" --declare "voldir VD1 Stage 2 {v} {eng}"')
    return L


def report(D: dict, E: dict, RC: dict, decl: dict, sha: str, secs: float, run: Path, cmds: List[str]) -> str:
    R, V = E["results"], E["verdicts"]
    buys, vetoes = V[(V.kind == "buy") & V.passed], V[(V.kind == "veto") & V.passed]
    L = [f"# Volatility x direction - {decl['name']} ({VERSION})", "",
         f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). Universe {len(D['syms']):,} "
         f"stocks ({D['dropped']:,} ETFs / indices out by {D['etf_rule']}; {len(D['missing']):,} without bars), "
         f"{len(E['rows']):,} eligible stock-days, calendar {D['cal'][0]}..{D['cal'][-1]}. {secs:.0f} s.", "",
         "## Verdict first", ""]
    L.append(f"- **Buy survivors: {len(buys)}**" + (" - " + "; ".join(f"{r.test} x {r.exit}" for r in buys.itertuples(index=False))
                                                   if len(buys) else " - no buy rule beats the universe and its parent "
                                                   "out of sample and in replication.") + "")
    L.append(f"- **Vetoes confirmed: {len(vetoes)}**" + (" - " + "; ".join(f"{r.test} x {r.exit}" for r in vetoes.itertuples(index=False))
                                                        if len(vetoes) else " - no subset is reliably worse than its parent."))
    L.append(f"- **Forecast race (Stage 0): " + (f"{', '.join(RC['beats'])} beat ATR14 in 2021 on**" if RC["beats"]
                                                 else "nothing beats ATR14 in 2021 on**") +
             " (lower QLIKE and a daily rank-correlation gain whose 95% interval is above 0).")
    L += ["", f"Stage 2 (the frozen tree, tradelab add-on v1.5): run these {len(cmds)} backtests from the tradelab folder "
              "(stage2_commands.txt), then `python voldir.py holm --scan %TRADELAB_OUT%\\backtest` from the sdelab folder:",
          "", "```", *cmds, "```", ""]
    L += ["## Every test", "",
          f"Excess = net minus the same-date mean of every eligible stock (same exit); vs parent = net minus the same-date "
          f"mean of the parent's stock-days. A = 2016-2020 with the Bonferroni interval (mean +- {E['z']:.2f} bootstrap "
          f"SDs, {decl['stats']['tests']} tests); B = 2021 on, 95%. bp.", "",
          "| test | exit | kind | parent | events A | excess A [Bonf.] | vs parent A [Bonf.] | events B | excess B [95%] | "
          "vs parent B [95%] | years | verdict |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in V.itertuples(index=False):
        a = R[(R.test == r.test) & (R.exit == r.exit) & (R.period == "A")].iloc[0]
        b = R[(R.test == r.test) & (R.exit == r.exit) & (R.period == "B")].iloc[0]
        L.append(f"| {r.test} | {r.exit} | {r.kind} | {r.parent} | {a.events:,} | "
                 f"{bp(a.excess_mean, a.excess_bonf_lo, a.excess_bonf_hi)} | {bp(a.incr_mean, a.incr_bonf_lo, a.incr_bonf_hi)} | "
                 f"{b.events:,} | {bp(b.excess_mean, b.excess_lo, b.excess_hi)} | {bp(b.incr_mean, b.incr_lo, b.incr_hi)} | "
                 f"{r.D_years} | {r.verdict} |")
    L += ["", "Years = years (of 11) whose mean excess (buy) is above 0 / whose mean vs parent (veto) is below 0, each "
              "with at least 30 events; 8 needed.", "", "### The rules", ""]
    for k, v in decl["tests"].items():
        L.append(f"- **{k}** ({v['kind']}, parent {v['parent']}): {v['rule']} - {v['why']}.")
    T = RC["table"]
    L += ["", "## Stage 0 - the volatility forecast race", "",
          f"Target: the mean squared log return of the 5 sessions after the signal close. {RC['common_rows']:,} rows where "
          "all five forecasts exist. Each forecast is scaled by one constant from 2016-2020 (QLIKE's best level). "
          "Spearman = the day's rank correlation of the forecast with the outcome across stocks (what a lane cut-off "
          "uses); vs ATR = its daily difference, 95% block bootstrap. Period A is in sample for HAR, GJR and the scales.",
          "", "| method | period | QLIKE | Spearman | vs ATR [95%] | scale | beats ATR |", "|---|---|---|---|---|---|---|"]
    for r in T.itertuples(index=False):
        L.append(f"| {r.method} | {r.period} | {r.qlike:.4f} | {r.spearman_mean:.4f} | "
                 f"{r.spearman_vs_atr:+.4f} [{r.spearman_vs_atr_lo:+.4f}, {r.spearman_vs_atr_hi:+.4f}] | {r.scale:.3f} | "
                 f"{'' if r.beats_atr is None else ('YES' if r.beats_atr else 'no')} |")
    L += ["", f"HAR (pooled, 2016-2020): RV5 = {RC['har_beta'][0]:.3g} + {RC['har_beta'][1]:.3f} r^2 + "
              f"{RC['har_beta'][2]:.3f} mean5 + {RC['har_beta'][3]:.3f} mean22.", "",
          "## Market volatility (NIFTY50 GJR-GARCH, refitted each January on the past only)", "",
          "| year | returns fitted | alpha | gamma (leverage) | beta | nu |", "|---|---|---|---|---|---|"]
    for r in D["gjr"].itertuples(index=False):
        L.append(f"| {r.year} | {r.fitted_on_returns:,} | {r.alpha:.3f} | {r.gamma:.3f} | {r.beta:.3f} | {r.nu:.1f} |")
    L += ["", "## How to read it", "",
          f"- {decl['entry_timing']}; exits: " + "; ".join(f"{k} {v['name']}" for k, v in decl["exits"].items()) +
          f"; {decl['honest_exits']}; {decl['cost_bp']} bp; one event per stock until {decl['cooldown_sessions']} "
          "sessions have passed.",
          f"- Buy survivor: {decl['decision']['buy_survivor']}.", f"- Veto confirmed: {decl['decision']['veto_confirmed']}.",
          f"- Period roles: A {decl['period_roles']['A']}; B {decl['period_roles']['B']}.",
          f"- Stage 2: {decl['stage2_book']['pass_per_strategy']} {decl['stage2_book']['family']}. "
          f"{decl['stage2_book']['meaning']}.",
          f"- Known bias: {decl['known_bias']}.",
          f"- Files: verdicts.csv, results.csv, years.csv, race.csv, market_vol.csv, gjr_params.csv, daily_cuts.parquet "
          f"(tradelab's --voldir {run}), stage2_commands.txt.", ""]
    return "\n".join(L)


# ---------------------------------------------------------------------------------------------------- commands
def cmd_run(a) -> int:
    t0 = time.time()
    decl, sha = load_decl()
    r1, _ = S.load_decl()
    if not a.root:
        raise SDEError("--root is required (--root %CACHE_DAILY_ROOT% after call env_sdelab.bat)")
    root = Path(a.root)
    if not root.is_dir():
        raise SDEError(f"--root {root} is not a folder")
    panel = Path(a.panel) if a.panel else root / "panel" / "panel.parquet"
    base = S.out_base(a.out, root)
    say(f"{VERSION} | declaration {sha[:16]} | root {root} | panel {panel}")
    D = build(root, panel, decl, r1, a.stage_e_any)
    say(f"eligible stock-days: {len(D['rows']):,}; {decl['test_count']} tests ...")
    E = evaluate(D, decl)
    say("Stage 0: the forecast race ...")
    RC = race(E["rows"], D["cal"], decl)
    run = TC.new_run_dir(base, "runs", "VD")
    V = E["verdicts"]
    E["results"].to_csv(run / "results.csv", index=False, float_format="%.8g")
    E["years"].to_csv(run / "years.csv", index=False, float_format="%.8g")
    V.to_csv(run / "verdicts.csv", index=False)
    RC["table"].to_csv(run / "race.csv", index=False, float_format="%.8g")
    D["mvol"].to_csv(run / "market_vol.csv", index=False, float_format="%.8g")
    D["gjr"].to_csv(run / "gjr_params.csv", index=False, float_format="%.8g")
    D["cuts"].to_parquet(run / SU.CUTS_FILE, index=False)
    names = stage2_list(V)
    cmds = stage2_commands(names, run, a.pm_run)
    (run / "stage2_commands.txt").write_text("\r\n".join(cmds) + "\r\n", encoding="utf-8")
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    secs = time.time() - t0
    (run / "REPORT.md").write_text(report(D, E, RC, decl, sha, secs, run, cmds), encoding="utf-8")
    meta = {"tool": VERSION, "declaration_sha256": sha, "root": str(root), "panel": str(panel),
            "universe": len(D["syms"]), "missing": D["missing"], "etf_rule": D["etf_rule"],
            "stock_days": int(len(E["rows"])), "z_bonferroni": E["z"], "production": D["prod"], "seconds": round(secs, 1),
            "buy_survivors": V[(V.kind == "buy") & V.passed][["test", "exit"]].values.tolist(),
            "vetoes_confirmed": V[(V.kind == "veto") & V.passed][["test", "exit"]].values.tolist(),
            "race_beats_atr": RC["beats"], "stage2": names, "pm_run_in_commands": a.pm_run}
    (run / "run.json").write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    TC.write_outputs_sha(run)
    with open(base / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "run": run.name,
                            "declaration_sha256": sha, "buy_survivors": meta["buy_survivors"],
                            "vetoes_confirmed": meta["vetoes_confirmed"], "race_beats_atr": RC["beats"]}) + "\n")
    say(f"buy survivors {meta['buy_survivors']} | vetoes {meta['vetoes_confirmed']} | race {RC['beats'] or 'none'}")
    say(f"Stage 2: {len(cmds)} backtests listed in {run / 'stage2_commands.txt'}")
    say(f"DONE {run}  ({secs:.0f} s)")
    return 0


def holm(rows: List[dict], alpha: float = 0.025) -> List[dict]:
    """Holm step-down within each engine: sorted by p, the i-th (0-based) is kept while p <= alpha / (m - i)."""
    out = []
    for eng in sorted({r["engine"] for r in rows}):
        g = sorted([r for r in rows if r["engine"] == eng], key=lambda r: (np.inf if not np.isfinite(r["p"]) else r["p"]))
        m, going = len(g), True
        for i, r in enumerate(g):
            lim = alpha / (m - i)
            keep = going and np.isfinite(r["p"]) and r["p"] <= lim
            going = keep
            out.append(dict(r, family=m, holm_limit=lim, holm_kept=bool(keep),
                            final="PASS" if keep and r["rule_verdict"] == "PASS" else "FAIL"))
    return out


def read_backtest(folder: Path, want_sha: str) -> dict:
    sj = folder / "summary.json"
    if not sj.is_file():
        raise SDEError(f"{folder}: no summary.json")
    s = json.loads(sj.read_text(encoding="utf-8"))
    st, dec = s.get("strategy") or {}, s.get("decision") or {}
    var = st.get("variant")
    copies = sorted(folder.glob("strategy_*.py"))
    if not var or not copies:
        raise SDEError(f"{folder}: not a run of strategies\\voldir.py#NAME")
    if want_sha and sha256(copies[0]) != want_sha:
        raise SDEError(f"{folder}: its strategy file is not the declared strategies\\voldir.py (sha256 "
                       f"{sha256(copies[0])[:16]} vs {want_sha[:16]})")
    eng = (st.get("picks") or {}).get("engines") or []
    if len(eng) != 1:
        raise SDEError(f"{folder}: one engine per run (this one {eng})")
    if (s.get("compare") or {}).get("name") != "tree":
        raise SDEError(f"{folder}: compared with {(s.get('compare') or {}).get('name')}, not the frozen tree")
    return {"folder": folder.name, "engine": eng[0], "variant": var, "rule_verdict": dec.get("verdict"),
            "p": float(dec.get("p_one_sided", np.nan)) if dec.get("p_one_sided") is not None else np.nan,
            "value": dec.get("metric_value")}


def cmd_holm(a) -> int:
    decl, sha = load_decl()
    _, want = strategies_sha(decl)
    folders = [Path(x) for x in a.folders]
    if a.scan:
        for f in sorted(Path(a.scan).glob("TLB_*")):
            sj = f / "summary.json"
            if sj.is_file():
                st = (json.loads(sj.read_text(encoding="utf-8")).get("strategy") or {})
                if st.get("variant") and str(st.get("name", "")).startswith("voldir_"):
                    folders.append(f)
    if not folders:
        raise SDEError("no tl_backtest runs given (folders, or --scan <TRADELAB_OUT>\\backtest)")
    rows = [read_backtest(f, want) for f in folders]
    seen = {}
    for r in rows:
        k = (r["engine"], r["variant"])
        if k in seen:
            raise SDEError(f"{r['variant']} on {r['engine']} appears twice ({seen[k]}, {r['folder']}): a declared test "
                           f"is run once - give the folders to use")
        seen[k] = r["folder"]
    H = holm(rows, decl["stage2_book"].get("holm_alpha", 0.025))
    say(f"{VERSION} holm | declaration {sha[:16]} | {len(H)} runs")
    say("engine | variant | rule | p (one-sided) | Holm limit | kept | FINAL | run")
    for r in H:
        say(f"{r['engine']} | {r['variant']} | {r['rule_verdict']} | {r['p']:.4f} | {r['holm_limit']:.4f} | "
            f"{'yes' if r['holm_kept'] else 'no'} | {r['final']} | {r['folder']}")
    out = a.out or os.environ.get("SDELAB_OUT")
    if out:
        base = Path(out)
        base.mkdir(parents=True, exist_ok=True)
        with open(base / LEDGER, "a", encoding="utf-8") as f:
            f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "event": "holm",
                                "declaration_sha256": sha, "rows": H}, default=str) + "\n")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="voldir: volatility x direction on the whole NSE universe (study VD1)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="the declaration and tradelab's strategies\\voldir.py are the frozen ones")
    r = sub.add_parser("run", help="Stage 0 + Stage 1")
    r.add_argument("--root")
    r.add_argument("--panel", default=None)
    r.add_argument("--out", default=None)
    r.add_argument("--stage-e-any", action="store_true")
    r.add_argument("--pm-run", default="PM_20261017_001", help="only written into the Stage 2 commands")
    h = sub.add_parser("holm", help="Stage 2: Holm across each engine's tl_backtest runs of strategies\\voldir.py")
    h.add_argument("folders", nargs="*")
    h.add_argument("--scan", default=None)
    h.add_argument("--out", default=None)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            have, want = strategies_sha(d)
            if have is None:
                raise SDEError(f"{STRAT_FILE} not found (tradelab add-on v1.5 beside sdelab)")
            if have != want:
                raise SDEError(f"{STRAT_FILE} has sha256 {have[:16]}, not the declared {want[:16]} - refusing")
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['name']}, declared {d['declared']}): {d['test_count']} tests; "
                f"strategies\\voldir.py sha256 {have[:16]} as declared")
            return 0
        if a.cmd == "holm":
            return cmd_holm(a)
        return cmd_run(a)
    except (SDEError, TC.TLError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
