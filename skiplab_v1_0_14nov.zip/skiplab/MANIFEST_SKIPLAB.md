# MANIFEST - skiplab v1.0 (study SK1)

Built 14 Nov 2026. Folder: C:\Users\karanvsi\PyCharmMiscProject\skiplab (new; beside tradelab, setuplab, jumplab and clashlab, never inside bigmove_deploy). Outputs: C:\QuantData\skiplab. Reads production, setuplab's runs and the panel READ ONLY.

Uses, unchanged and version-checked: tradelab (tl_data, tl_setups v1.7), setuplab v1.1 (zones, ATR, the bootstrap, run folders), jumplab v1.0 / v1.0.1 (daily features), clashlab cl2 v1.0 (the search, judge and Holm). Nothing in those folders changes.

Declaration sha256: 0fe32bffb8fb9a083ce5fc1536b7587bf49f902698369f3fa33422b4db08a84b

| file | version | sha256 (first 16) | role |
|---|---|---|---|
| skiplab.py | skiplab v1.0 | 7026c2cdf56ba4a9 | COMMAND: check / run (every measure of T-1 and T0, the CL2 search on Oct 2021-2023, the judge on 2024 onward, the tradability check, the atlas, the report) |
| SKIPLAB_DECLARATION.json | SK1, declared 14 Nov 2026 | 0fe32bffb8fb9a08 | the study, fixed before any run (skiplab.py refuses another sha256) |
| env_skiplab.bat | skiplab v1.0 | 841d26df31828cb3 | start a session: env_daily.bat, PYTHONPATH (skiplab, tradelab, setuplab, jumplab, clashlab, open_close, bigmove_deploy), SETUPLAB_OUT, SKIPLAB_OUT (CRLF) |
| README_SKIPLAB.md | skiplab v1.0 | d9313628e28d5ebe | the question, the measures, the two parts, install and run, outputs, tests |
| tests/test_skiplab.py | skiplab v1.0 | 6b718a0b49e0f4b1 | the self-test (26 checks; must end VERIFIED (skiplab v1.0)); verified on pandas 3.0.5 / numpy 2.5.3 and on pandas 2.3.3 / numpy 2.4.1; 25 planted bugs caught |
