@echo off
rem env_skiplab.bat - skiplab v1.0 (study SK1: the jumpy picks no frozen setup catches): start a session.
rem   call C:\Users\karanvsi\PyCharmMiscProject\skiplab\env_skiplab.bat
rem Reads production (the daily cache, the 3-minute bars, stage E's loaders), setuplab's runs and the panel READ ONLY,
rem through tradelab, setuplab, jumplab and clashlab (their code used unchanged). Writes only under SKIPLAB_OUT.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "SETUPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\setuplab"
set "JUMPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\jumplab"
set "CLASHLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\clashlab"
set "SETUPLAB_OUT=C:\QuantData\setuplab"
set "SKIPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\skiplab"
set "SKIPLAB_OUT=C:\QuantData\skiplab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_data.py" goto :no_tradelab
if not exist "%SETUPLAB_DIR%\setuplab.py" goto :no_setuplab
if not exist "%JUMPLAB_DIR%\jumplab.py" goto :no_jumplab
if not exist "%CLASHLAB_DIR%\cl2.py" goto :no_clashlab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%SKIPLAB_DIR%;%TRADELAB_DIR%;%SETUPLAB_DIR%;%JUMPLAB_DIR%;%CLASHLAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%SKIPLAB_OUT%" mkdir "%SKIPLAB_OUT%"
cd /d "%SKIPLAB_DIR%"
echo skiplab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   SETUPLAB_OUT=%SETUPLAB_OUT%   SKIPLAB_OUT=%SKIPLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_skiplab.bat
exit /b 1
:no_tradelab
echo ERROR: %TRADELAB_DIR%\tl_data.py not found - skiplab reads the bars through tradelab's tl_data (edit TRADELAB_DIR)
exit /b 1
:no_setuplab
echo ERROR: %SETUPLAB_DIR%\setuplab.py not found - skiplab uses setuplab's zones and ATR (edit SETUPLAB_DIR)
exit /b 1
:no_jumplab
echo ERROR: %JUMPLAB_DIR%\jumplab.py not found - skiplab uses jumplab's daily features (edit JUMPLAB_DIR)
exit /b 1
:no_clashlab
echo ERROR: %CLASHLAB_DIR%\cl2.py not found - skiplab uses clashlab CL2's search (edit CLASHLAB_DIR)
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
