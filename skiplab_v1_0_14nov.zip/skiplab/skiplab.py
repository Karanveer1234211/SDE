"""
skiplab.py - skiplab v1.0 (study SK1): the jumpy picks no frozen setup catches. What their signal day (T0) and the
day before (T-1) looked like inside the session, with the panel's features, SDE and the market around them, and
which of those looks repeat. SKIPLAB_DECLARATION.json (pinned below) holds the rules, fixed before any run.

    python skiplab.py check                                      the declaration is the pinned one; the libraries
    python skiplab.py run --root %CACHE_DAILY_ROOT% [--setups %SETUPLAB_OUT%] [--out <folder>] [--features <panel>]
                          [--stage-e-any] [--rerun-reason "<a verified bug>"]
                                                                 -> SKIPLAB_OUT\\runs\\SK_<date>_<nnn>

READS (read only): setuplab's newest TREE run (every pick's lane, first setup, setup net, D1 net) and TAGS run (the
watchlist and panel it used), both hash-checked through tradelab's tl_setups; features_final.txt beside setuplab.py;
the daily and 3-minute bars through tradelab's tl_data (production's loaders). Uses setuplab's zone and ATR code,
jumplab's daily features and clashlab's CL2 search and judge unchanged (their versions are checked). WRITES only under
--out / SKIPLAB_OUT: SK_<date>_<nnn>\\ REPORT.md, picks.parquet, groups.csv, measures.csv, daytypes.csv,
transitions.csv, filters.csv, top25.csv, tradability.csv, run.json, DECLARATION.json, outputs.sha256; one line per run
in skiplab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import tl_common as TC
import tl_data as TD
import tl_setups as SU

VERSION = "skiplab v1.0"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "SKIPLAB_DECLARATION.json"
DECL_SHA = "0fe32bffb8fb9a083ce5fc1536b7587bf49f902698369f3fa33422b4db08a84b"
LEDGER = "skiplab_ledger.jsonl"
COST = 0.35
INTRADAY_FIRST = np.datetime64("2021-10-01", "D")
SPLIT = np.datetime64("2024-01-01", "D")
INDEX = "NIFTYSMLCAP250"
CL2_VERSION = "cl2 v1.0"
JL_VERSIONS = ("jumplab v1.0", "jumplab v1.0.1")
SL_NEEDS = ("Boot", "ZONE_DIMS", "ZDIM", "ZONE_INDEX", "zone_values", "zone_buckets", "market_dims", "atr_simple",
            "new_run_dir", "write_hashes")
NB = 125                                     # 3-minute bars a session: 09:15 + 3k, k = 0..124
SLOT_0945, SLOT_1015, SLOT_1430 = 9, 19, 104  # the bar whose close is the price at 09:45 / 10:15 / 14:30
AM_LAST, PM_FIRST = 19, 105                   # first hour = bars 0..19, last hour = bars 105..124
DAILY = ("sde3", "sde5", "sde10", "sde20", "ret1", "ret5", "ret60", "up_share10", "clv5", "dist_hi20", "dist_lo20",
         "atr_rank252", "tr_ratio", "semivol20", "upvol20", "semi_share", "rsj10", "lds10", "shock", "turn_rel",
         "log_turn20")
BAR = ("gap", "oc", "range", "clv", "uwick", "lwick", "rvol")
PATH = ("eff", "vwap", "vwap_share", "t_hi", "t_lo", "drive30", "or30", "mid", "last_hour", "vol_am", "vol_pm", "rv",
        "jump", "dd", "ru")
CROSS = ("x_hi", "x_lo", "x_close_hi", "x_range", "x_vol", "x_eff2")
DAYS = ("Tm1", "T0")                          # T-1 and the signal day
TYPES = ("QUIET", "GAP_UP_GO", "GAP_UP_FADE", "GAP_DN_RECOVER", "GAP_DN_GO", "TREND_UP", "TREND_DN", "REVERSAL_UP",
         "REVERSAL_DN", "RANGE")
GROUPS = ("N", "C", "K")
YEARS = (2021, 2022, 2023, 2024, 2025, 2026)
GNAME = {"N": "jumpy, never caught", "C": "jumpy, caught", "K": "calm"}
DAY_TEXT = {"Tm1": "T-1", "T0": "T0"}


class SKError(Exception):
    pass


def say(msg: str) -> None:
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def sha256(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_decl(path: Path = DECL_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != DECL_SHA:
        raise SKError(f"{path.name} has sha256 {sha[:16]}, not the pinned {DECL_SHA[:16]} - the declaration is fixed "
                      f"before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def libs():
    """setuplab, jumplab and clashlab's cl2 - skiplab uses their code unchanged, so their versions are checked."""
    try:
        import setuplab as SL
    except ImportError as e:
        raise SKError(f"cannot import setuplab ({e}) - start with env_skiplab.bat (it puts setuplab on PYTHONPATH)")
    miss = [n for n in SL_NEEDS if not hasattr(SL, n)]
    if miss:
        raise SKError(f"setuplab ({getattr(SL, 'VERSION', '?')}) lacks {miss} - skiplab needs setuplab v1.1")
    try:
        import jumplab as JL
    except ImportError as e:
        raise SKError(f"cannot import jumplab ({e}) - env_skiplab.bat puts the jumplab folder on PYTHONPATH")
    if getattr(JL, "VERSION", "") not in JL_VERSIONS:
        raise SKError(f"jumplab is {getattr(JL, 'VERSION', '?')}, skiplab uses the daily features of {JL_VERSIONS}")
    try:
        import cl2 as CL
    except ImportError as e:
        raise SKError(f"cannot import clashlab's cl2 ({e}) - env_skiplab.bat puts the clashlab folder on PYTHONPATH")
    if getattr(CL, "VERSION", "") != CL2_VERSION:
        raise SKError(f"clashlab's cl2 is {getattr(CL, 'VERSION', '?')}, skiplab uses the search of {CL2_VERSION}")
    return SL, JL, CL


def out_base(arg: Optional[str], root: Optional[Path]) -> Path:
    v = arg or os.environ.get("SKIPLAB_OUT")
    if not v:
        raise SKError("no output folder: pass --out or start with env_skiplab.bat (sets SKIPLAB_OUT)")
    b = Path(v).resolve()
    guards = ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                          ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise SKError(f"output folder {b} is inside {g}; skiplab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


def ist_dates(s) -> pd.Series:
    t = pd.to_datetime(s)
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t.dt.normalize()


def features_final(SL) -> Tuple[List[str], Path]:
    ff = Path(SL.__file__).resolve().with_name("features_final.txt")
    if not ff.is_file():
        raise SKError(f"{ff} not found (it ships with setuplab)")
    feats = [x.strip() for x in ff.read_text(encoding="utf-8").splitlines() if x.strip() and not x.startswith("#")]
    if any(f.lower().startswith("label_") for f in feats):
        raise SKError("features_final.txt lists a label_ column - refusing (the label firewall)")
    return feats, ff


# ---------------------------------------------------------------------------------------------------- the picks
def resolve(base: Path, features: Optional[str]):
    """setuplab's newest TREE and TAGS runs (hash-checked) and the panel the TAGS run used (or the one given)."""
    tree, trinfo = SU.load_tree(base, need=True)
    tags, tinfo = SU.load_tags(base, need=True)
    if trinfo.get("frozen_sha256") and tinfo.get("frozen_sha256") and trinfo["frozen_sha256"] != tinfo["frozen_sha256"]:
        raise SKError(f"tree run {trinfo['run']} and TAGS run {tinfo['run']} come from different freezes - refusing")
    need = {"trade_id", "engine", "rank", "symbol", "signal_day", "lane", "etf", "first_setup", "setup_net", "d1_net",
            "complete"}
    miss = sorted(need - set(tree.columns))
    if miss:
        raise SKError(f"the tree run {trinfo['run']} lacks {miss} - it needs setuplab v1.1's tree command")
    meta = json.loads((Path(tinfo["folder"]) / "TAGS.json").read_text(encoding="utf-8"))
    panel = Path(features) if features else Path(meta.get("panel", ""))
    if not panel.is_file():
        raise SKError(f"the panel the TAGS run used is not at {panel} - pass --features <panel.parquet>")
    return tree, trinfo, tinfo, panel


def stock_days(tree: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    """U: one row per stock-day (group N / C / K, best rank, engines, outcome); P: the per-engine rows of jumpy ranks
    1-3 picks (the tree's own) with the tree's result, for the tradability check."""
    T = tree.copy()
    T["symbol"] = T["symbol"].astype(str).str.strip().str.upper()
    T["sday"] = ist_dates(T["signal_day"]).astype("datetime64[ns]")
    T["rank"] = pd.to_numeric(T["rank"], errors="coerce")
    T["d1_net"] = pd.to_numeric(T["d1_net"], errors="coerce").astype(float)
    T["setup_net"] = pd.to_numeric(T["setup_net"], errors="coerce").astype(float)
    lane = T["lane"].astype(str).to_numpy()
    etf = T["etf"].astype("boolean").fillna(False).to_numpy(bool)
    comp = T["complete"].astype("boolean").fillna(False).to_numpy(bool)
    net = T["d1_net"].to_numpy(float)
    jumpy = np.isin(lane, ["JUMPY", "NO ATR"])
    calm = lane == "CALM"
    caught = T["first_setup"].fillna("").astype(str).str.len().to_numpy() > 0
    T["group"] = np.where(jumpy & ~caught, "N", np.where(jumpy & caught, "C", np.where(calm, "K", "")))
    ok = ~etf & (jumpy | calm) & comp & np.isfinite(net) & (T["sday"].to_numpy() >= np.datetime64(INTRADAY_FIRST))
    info = {"tree_rows": int(len(T)), "kept_rows": int(ok.sum()), "etf": int(etf.sum()),
            "no_cutoff": int((lane == "NO CUT-OFF").sum()), "not_complete": int((~comp).sum())}
    T = T[ok].sort_values(["symbol", "sday", "rank", "engine"]).reset_index(drop=True)
    g = T.groupby(["symbol", "sday"], sort=True)
    U = g.agg(rank=("rank", "min"), engines=("engine", lambda s: ",".join(sorted(set(map(str, s))))),
              rows=("trade_id", "size"), group=("group", "first"), n_groups=("group", "nunique"),
              d1_net=("d1_net", "first"), net_spread=("d1_net", lambda s: float(np.nanmax(s) - np.nanmin(s))),
              setup_net=("setup_net", "first"), first_setup=("first_setup", "first"),
              ids=("trade_id", lambda s: " ".join(map(str, s)))).reset_index()
    U["d1_net"] = pd.to_numeric(U["d1_net"], errors="coerce").astype(float)
    U["setup_net"] = pd.to_numeric(U["setup_net"], errors="coerce").astype(float)
    U["in_both"] = U["engines"].str.contains("D,ENS", regex=False)
    info.update({"stock_days": int(len(U)), "group_mismatch": int((U["n_groups"] > 1).sum()),
                 "net_mismatch": int((U["net_spread"] > 1e-6).sum())})
    key = pd.MultiIndex.from_frame(U[["symbol", "sday"]])
    P = T[(T["rank"] <= 3) & np.isin(T["group"], ["N", "C"])].copy()
    P["uid"] = key.get_indexer(pd.MultiIndex.from_frame(P[["symbol", "sday"]]))
    P["tree_res"] = np.where(P["group"] == "N", 0.0, pd.to_numeric(P["setup_net"], errors="coerce"))
    P = P[np.isfinite(P["tree_res"].to_numpy(float)) & (P["uid"] >= 0)].reset_index(drop=True)
    return U, P[["trade_id", "engine", "rank", "symbol", "sday", "group", "d1_net", "tree_res", "uid"]], info


# ---------------------------------------------------------------------------------------------------- the measures
def bar_measures(o, h, l, c, v, vmed, j: int, atr: float) -> Dict[str, float]:
    """One session's daily-bar measures (index j of the stock's own bars), ATR in rupees."""
    out = dict.fromkeys(BAR, np.nan)
    if j < 1 or not (atr > 0) or not all(np.isfinite([o[j], h[j], l[j], c[j], c[j - 1]])):
        return out
    rng = h[j] - l[j]
    out["gap"], out["oc"], out["range"] = (o[j] - c[j - 1]) / atr, (c[j] - o[j]) / atr, rng / atr
    if rng > 0:
        out["clv"] = (c[j] - l[j]) / rng
        out["uwick"] = (h[j] - max(o[j], c[j])) / rng
        out["lwick"] = (min(o[j], c[j]) - l[j]) / rng
    if np.isfinite(vmed[j]) and vmed[j] > 0 and np.isfinite(v[j]):
        out["rvol"] = v[j] / vmed[j]
    return out


def day_type(m: Dict[str, float]) -> str:
    """The declared day type of one session from its daily-bar measures (first match); '' when unknown."""
    g, oc, r, clv = m["gap"], m["oc"], m["range"], m["clv"]
    if not np.isfinite(r):
        return ""
    if r < 0.6:
        return "QUIET"
    if not (np.isfinite(g) and np.isfinite(oc) and np.isfinite(clv)):
        return ""
    up_w, lo_w = m["uwick"] * r, m["lwick"] * r                 # wicks in ATR
    if g >= 0.5:
        return "GAP_UP_GO" if oc >= 0 else "GAP_UP_FADE"
    if g <= -0.5:
        return "GAP_DN_RECOVER" if oc > 0 else "GAP_DN_GO"
    if oc >= 0.5 and clv >= 0.7:
        return "TREND_UP"
    if oc <= -0.5 and clv <= 0.3:
        return "TREND_DN"
    if lo_w >= 0.5 and clv >= 0.6:
        return "REVERSAL_UP"
    if up_w >= 0.5 and clv <= 0.4:
        return "REVERSAL_DN"
    return "RANGE"


def session_grid(s):
    """125-slot arrays of one usable session: the bars' own high / low / close / volume (nan / 0 where a bar is
    missing) and the close carried forward (a missing bar takes the last close before it)."""
    H, L, C = (np.full(NB, np.nan) for _ in range(3))
    V = np.zeros(NB)
    k = np.asarray(s.slot, dtype=np.int64)
    H[k], L[k], C[k] = s.h, s.l, s.c
    V[k] = np.nan_to_num(np.asarray(s.v, float))
    i = np.maximum.accumulate(np.where(np.isfinite(C), np.arange(NB), -1))
    Cf = np.where(i >= 0, C[np.clip(i, 0, None)], np.nan)
    return float(s.o[0]), H, L, C, V, Cf


def path_measures(s, atr: float, atrp: float) -> Tuple[Dict[str, float], Optional[np.ndarray]]:
    """One session's 3-minute measures (declared) and its path (first open, then every bar's close)."""
    out = dict.fromkeys(PATH, np.nan)
    if s is None or not getattr(s, "usable", False) or not (atr > 0):
        return out, None
    O, H, L, C, V, Cf = session_grid(s)
    p = np.r_[O, Cf]
    if not np.isfinite(p).all() or (p <= 0).any():
        return out, None
    last = p[-1]
    tot = float(np.abs(np.diff(p)).sum())
    out["eff"] = (last - O) / tot if tot > 0 else 0.0
    have = np.isfinite(C)
    tp = np.where(have, (H + L + C) / 3.0, 0.0)
    vv = np.where(have, V, 0.0)
    cpv, cvv = np.cumsum(tp * vv), np.cumsum(vv)
    if cvv[-1] > 0:
        out["vwap"] = (last - cpv[-1] / cvv[-1]) / atr
        run = np.where(cvv > 0, cpv / np.where(cvv > 0, cvv, 1.0), np.nan)
        okv = have & np.isfinite(run)
        out["vwap_share"] = float(np.mean(C[okv] >= run[okv])) if okv.any() else np.nan
        out["vol_am"] = float(V[:AM_LAST + 1].sum() / V.sum())
        out["vol_pm"] = float(V[PM_FIRST:].sum() / V.sum())
    out["t_hi"] = float(np.nanargmax(H)) / (NB - 1)
    out["t_lo"] = float(np.nanargmin(L)) / (NB - 1)
    out["drive30"] = (Cf[SLOT_0945] - O) / atr
    orh = max(O, float(np.nanmax(H[:SLOT_0945 + 1])))
    orl = min(O, float(np.nanmin(L[:SLOT_0945 + 1])))
    out["or30"] = (last - orh) / atr if last > orh else (last - orl) / atr if last < orl else 0.0
    out["mid"] = (Cf[SLOT_1430] - Cf[SLOT_1015]) / atr
    out["last_hour"] = (last - Cf[SLOT_1430]) / atr
    r = np.diff(np.log(p))
    rv = float(np.sqrt(np.sum(r * r)))
    if atrp > 0:
        out["rv"] = rv / atrp
    out["jump"] = float(np.max(np.abs(r)) / rv) if rv > 0 else np.nan
    hh = np.where(np.isfinite(H), H, -np.inf)
    ll = np.where(np.isfinite(L), L, np.inf)
    rmax = np.maximum.accumulate(np.r_[O, hh])[1:]
    rmin = np.minimum.accumulate(np.r_[O, ll])[1:]
    okb = np.isfinite(H) & np.isfinite(L)
    out["dd"] = float(np.max(rmax[okb] - L[okb])) / atr
    out["ru"] = float(np.max(H[okb] - rmin[okb])) / atr
    return out, p


def cross_measures(o, h, l, c, v, j: int, atr: float, p1, p0) -> Dict[str, float]:
    """T0 (index j) against T-1 (j - 1): the daily bars, and the two-session path."""
    out = dict.fromkeys(CROSS, np.nan)
    if j < 1 or not (atr > 0):
        return out
    out["x_hi"], out["x_lo"], out["x_close_hi"] = (h[j] - h[j - 1]) / atr, (l[j] - l[j - 1]) / atr, \
        (c[j] - h[j - 1]) / atr
    r1 = h[j - 1] - l[j - 1]
    if r1 > 0:
        out["x_range"] = (h[j] - l[j]) / r1
    if np.isfinite(v[j - 1]) and v[j - 1] > 0 and np.isfinite(v[j]):
        out["x_vol"] = v[j] / v[j - 1]
    if p1 is not None and p0 is not None:
        p = np.r_[p1, p0]
        tot = float(np.abs(np.diff(p)).sum())
        out["x_eff2"] = (p0[-1] - p1[0]) / tot if tot > 0 else 0.0
    return out


def med20_before(v) -> np.ndarray:
    """The median volume of the 20 sessions before each bar (blank with fewer than 20)."""
    return pd.Series(np.asarray(v, float)).shift(1).rolling(20, min_periods=20).median().to_numpy()


def build(SL, JL, market, U: pd.DataFrame, log=say) -> Tuple[pd.DataFrame, dict]:
    """Every stock-day's measures from its own daily and 3-minute bars (all known at the T0 close), the outcome's
    descriptive extras (D1-D5) and the excess over Smallcap 250."""
    n = len(U)
    num = {k: np.full(n, np.nan) for k in list(DAILY) + [f"{d}_{m}" for d in DAYS for m in BAR + PATH] + list(CROSS)
           + [f"z_{d}" for d in SL.ZDIM] + ["atr14", "mfe", "mae", "open6", "chk_net", "idx_gross"]}
    zb = {d: np.full(n, -1, np.int8) for d in SL.ZDIM}
    typ = {d: np.full(n, "", dtype=object) for d in DAYS}
    dates = {k: np.full(n, np.datetime64("NaT"), dtype="datetime64[D]") for k in ("tm1", "d1", "d5")}
    usable = {d: np.zeros(n, bool) for d in DAYS}
    idx = {}
    for k, sym in SL.ZONE_INDEX:
        ds = market.series(sym)
        if ds is None or not len(ds.dates):
            raise SKError(f"{sym} bars are missing from the cache (setuplab's zones read them)")
        idx[k] = (ds.dates, ds.c)
    M = SL.market_dims(idx)
    sc = market.series(INDEX)
    if sc is None:
        raise SKError(f"{INDEX} bars are missing from the cache (the excess is measured against Smallcap 250)")
    try:
        store = market.intraday
    except Exception as e:
        raise SKError(f"the 3-minute bars are not reachable ({type(e).__name__}: {e}) - SK1 studies them")
    sday = U["sday"].to_numpy().astype("datetime64[D]")
    groups = U.groupby("symbol", sort=True).indices
    t0, fb, no_bars = time.time(), 0, 0
    for g_i, (sym, rows) in enumerate(groups.items()):
        ds = market.series(sym)
        if ds is None or not len(ds.dates):
            no_bars += len(rows)
            continue
        o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
        v = np.asarray(ds.v, float)
        pos = np.array([ds.idx(d) for d in sday[rows]], dtype=np.int64)
        ok = (pos >= 1) & (pos + 5 < len(c))
        if not ok.any():
            no_bars += len(rows)
            continue
        F = JL.daily_features(ds)
        a14 = SL.atr_simple(h, l, c)
        zv = SL.zone_values(ds.dates, o, h, l, c, v, M)
        zk = SL.zone_buckets(zv)
        vmed = med20_before(v)
        want = sorted({np.datetime64(ds.dates[q], "D") for p_ in pos[ok] for q in (p_ - 1, p_)})
        try:
            S = store.sessions(sym, want, ds)
        except Exception:
            S = {}
        for r, p_ in zip(rows[ok], pos[ok]):
            atrp = float(a14[p_])
            atr = atrp * c[p_] if np.isfinite(atrp) else np.nan
            num["atr14"][r] = atrp
            for name in DAILY:
                num[name][r] = F[name][p_]
            for d in SL.ZDIM:
                num[f"z_{d}"][r] = zv[d][p_]
                zb[d][r] = zk[d][p_]
            paths = {}
            for d, j in (("Tm1", p_ - 1), ("T0", p_)):
                bm = bar_measures(o, h, l, c, v, vmed, j, atr)
                for k_, x in bm.items():
                    num[f"{d}_{k_}"][r] = x
                typ[d][r] = day_type(bm)
                s = S.get(np.datetime64(ds.dates[j], "D"))
                pm, pth = path_measures(s, atr, atrp)
                usable[d][r] = pth is not None
                paths[d] = pth
                for k_, x in pm.items():
                    num[f"{d}_{k_}"][r] = x
            for k_, x in cross_measures(o, h, l, c, v, p_, atr, paths["Tm1"], paths["T0"]).items():
                num[k_][r] = x
            o1 = o[p_ + 1]
            dates["tm1"][r], dates["d1"][r], dates["d5"][r] = ds.dates[p_ - 1], ds.dates[p_ + 1], ds.dates[p_ + 5]
            if np.isfinite(o1) and o1 > 0:
                num["mfe"][r] = np.nanmax(h[p_ + 1:p_ + 6]) / o1 - 1
                num["mae"][r] = np.nanmin(l[p_ + 1:p_ + 6]) / o1 - 1
                num["chk_net"][r] = (c[p_ + 5] / o1 - 1) * 100 - COST
                if p_ + 6 < len(o) and np.isfinite(o[p_ + 6]):
                    num["open6"][r] = (o[p_ + 6] / o1 - 1) * 100 - COST
            j1 = sc.idx(ds.dates[p_ + 1])
            j5 = int(np.searchsorted(sc.dates, np.datetime64(ds.dates[p_ + 5], "D"), side="right")) - 1
            j0 = int(np.searchsorted(sc.dates, np.datetime64(ds.dates[p_ + 1], "D"), side="left")) - 1
            base = sc.o[j1] if j1 >= 0 else np.nan
            if not (np.isfinite(base) and base > 0):            # no index open on D1: its last close before D1
                base = sc.c[j0] if j0 >= 0 else np.nan
                fb += 1
            if j5 >= 0 and np.isfinite(base) and base > 0 and np.isfinite(sc.c[j5]):
                num["idx_gross"][r] = (sc.c[j5] / base - 1) * 100
        no_bars += int((~ok).sum())
        market.daily.pop(sym, None)
        if g_i and g_i % 200 == 0:
            log(f"   {g_i:,} of {len(groups):,} stocks ({time.time() - t0:.0f}s)")
    store.layout_check()                     # tradelab's stop: under half the sessions with bars usable = wrong stamps
    X = pd.DataFrame(num)
    for d in SL.ZDIM:
        X[d] = zb[d]
    for d in DAYS:
        X[f"{d}_type"] = typ[d]
        X[f"{d}_usable"] = usable[d]
    for k_, a in dates.items():
        X[k_] = pd.to_datetime(a).astype("datetime64[ns]")
    info = {"no_bars": int(no_bars), "index_open_fallback": int(fb),
            "sessions": {"asked": store.asked, "with_bars": store.with_bars, "usable": store.usable,
                         "reasons": dict(store.reasons)}}
    return X, info


def read_panel(panel: Path, feats: List[str], keys: pd.DataFrame, log=say) -> Tuple[np.ndarray, float]:
    """The panel row of each (symbol, T0): the features' values, blank where there is no row (clashlab CL2's reader)."""
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(panel)
    low = {c.lower(): c for c in pf.schema_arrow.names}
    tk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or tk is None:
        raise SKError(f"{panel} needs symbol and timestamp (or date) columns")
    miss = [f for f in feats if f.lower() not in low]
    if miss:
        raise SKError(f"{panel} lacks {', '.join(miss)} (features_final.txt)")
    need = keys[["symbol", "sday"]].drop_duplicates()
    syms = set(need["symbol"])
    parts = []
    for b in pf.iter_batches(batch_size=300_000, columns=[low["symbol"], tk] + [low[f.lower()] for f in feats]):
        f = b.to_pandas()
        f.columns = ["symbol", "sday"] + list(feats)
        f["symbol"] = f["symbol"].astype(str).str.strip().str.upper()
        f = f[f["symbol"].isin(syms)]
        if not len(f):
            continue
        f["sday"] = ist_dates(f["sday"]).astype("datetime64[ns]")
        f = f.merge(need, on=["symbol", "sday"], how="inner")
        for c_ in feats:
            f[c_] = pd.to_numeric(f[c_], errors="coerce").astype(float)
        parts.append(f.assign(found=1))
    Fp = pd.concat(parts, ignore_index=True).drop_duplicates(["symbol", "sday"]) if parts else \
        pd.DataFrame(columns=["symbol", "sday", "found"] + list(feats))
    out = keys[["symbol", "sday"]].merge(Fp, on=["symbol", "sday"], how="left")
    found = float(out["found"].fillna(0).astype(float).mean()) if len(out) else 0.0
    return out[list(feats)].to_numpy(float), found


# ---------------------------------------------------------------------------------------------------- buckets
def make_dims(SL, X: pd.DataFrame, cont: List[str], train: np.ndarray):
    """The declared buckets: quarters of each number at the quartiles of the discovery N picks (40+ values), the
    zones' own buckets, day types and in_both yes / no. Same dictionaries as clashlab CL2 (its ztext reads them)."""
    dims, B = [], {}
    for name, what, edges, labels in SL.ZONE_DIMS:
        dims.append({"name": name, "kind": "zone", "what": what, "nb": len(labels), "labels": list(labels),
                     "edges": None if edges is None else list(edges)})
        B[name] = X[name].to_numpy().astype(np.int8)
    for f in cont:
        v = X[f].to_numpy(float)
        t = v[train & np.isfinite(v)]
        b = np.full(len(v), -1, np.int8)
        if len(t) >= 40:
            e = [float(x) for x in np.quantile(t, [0.25, 0.5, 0.75])]
            ok = np.isfinite(v)
            b[ok] = np.searchsorted(np.asarray(e), v[ok], side="right").astype(np.int8)
            dims.append({"name": f, "kind": "feature", "what": f, "nb": 4, "labels": ["Q1", "Q2", "Q3", "Q4"],
                         "edges": e})
        B[f] = b
    for d in DAYS:
        known = X[f"{d}_type"].astype(str).to_numpy() != ""
        for t_ in TYPES:
            nm = f"{d}_is_{t_}"
            B[nm] = np.where(known, (X[f"{d}_type"].astype(str).to_numpy() == t_).astype(np.int8), -1).astype(np.int8)
            dims.append({"name": nm, "kind": "zone", "what": f"{DAY_TEXT[d]} day type {t_}", "nb": 2,
                         "labels": ["no", "yes"], "edges": None})
    B["in_both"] = X["in_both"].astype(bool).to_numpy().astype(np.int8)
    dims.append({"name": "in_both", "kind": "zone", "what": "picked by D and ENS", "nb": 2, "labels": ["no", "yes"],
                 "edges": None})
    return dims, B


# ---------------------------------------------------------------------------------------------------- statistics
def ci_from(R: np.ndarray) -> Tuple[float, float]:
    if not np.isfinite(R).any():
        return np.nan, np.nan
    return float(np.nanpercentile(R, 2.5)), float(np.nanpercentile(R, 97.5))


def boot_means(boot, di: np.ndarray, vals: np.ndarray, masks: List[np.ndarray]) -> np.ndarray:
    """Resampled means of vals inside each mask (columns), the same day draws for all: (resamples, masks)."""
    nd = len(boot.days)
    cols = []
    for m in masks:
        cols += [np.bincount(di[m], weights=vals[m], minlength=nd), np.bincount(di[m], minlength=nd).astype(float)]
    R = boot.M @ np.column_stack(cols) if cols else np.zeros((boot.M.shape[0], 0))
    with np.errstate(invalid="ignore", divide="ignore"):
        return R[:, 0::2] / np.where(R[:, 1::2] > 0, R[:, 1::2], np.nan)


def auc(a: np.ndarray, b: np.ndarray) -> float:
    """The chance a value of a is above a value of b (ties count half); blank with fewer than 20 on a side."""
    a, b = a[np.isfinite(a)], b[np.isfinite(b)]
    if len(a) < 20 or len(b) < 20:
        return np.nan
    r = pd.Series(np.r_[a, b]).rank().to_numpy()
    return float((r[:len(a)].sum() - len(a) * (len(a) + 1) / 2) / (len(a) * len(b)))


# ---------------------------------------------------------------------------------------------------- the study
def study(SL, CL, X: pd.DataFrame, P: pd.DataFrame, cont: List[str], log=say) -> dict:
    sd = X["sday"].to_numpy().astype("datetime64[D]")
    tm1 = X["tm1"].to_numpy().astype("datetime64[D]")
    d5 = X["d5"].to_numpy().astype("datetime64[D]")
    have = ~np.isnat(tm1) & ~np.isnat(d5)
    disc = have & (tm1 >= INTRADAY_FIRST) & (d5 < SPLIT)
    test = have & (sd >= SPLIT)
    grp = X["group"].astype(str).to_numpy()
    net = X["d1_net"].to_numpy(float)
    ex = net + COST - X["idx_gross"].to_numpy(float)
    X["excess"] = ex
    N = grp == "N"
    dims, B = make_dims(SL, X, cont, disc & N)
    res = {"periods": {"discovery": int((disc & N).sum()), "test": int((test & N).sum())},
           "dims": len(dims), "dims_list": [d["name"] for d in dims]}
    # ---- the repeatable test (clashlab CL2's search, eligibility, ranking, judge and Holm)
    tr = np.flatnonzero(disc & N)
    te = np.flatnonzero(test & N)
    Btr = {k: v[tr] for k, v in B.items()}
    log(f" searching {len(dims)} measures over {len(tr):,} discovery N picks")
    Sc = CL.screen(sd[tr], pd.DatetimeIndex(sd[tr]).year.to_numpy(), net[tr], Btr, dims)
    chosen, order, n_elig, skipped = CL.choose(Sc, Btr)
    log(f" {len(Sc['keys']):,} candidates, {n_elig:,} eligible; chosen {len(chosen)}")
    Bte = {k: v[te] for k, v in B.items()}
    Xte = pd.DataFrame({"day": pd.to_datetime(sd[te]), "net3": net[te], "ex3": ex[te]})
    rows = []
    for rnk, i in enumerate(chosen, 1):
        z = Sc["keys"][i]
        m = CL.zmask(z, Bte)
        e = CL.judge(SL, Xte, m) if len(te) else {"rule": "NOT HELD", "p": 1.0}
        e.update(rank=rnk, z=z, key=CL.zkey(z), text=CL.ztext(z, dims), train_n=int(Sc["n"][i]),
                 train_mean=float(Sc["mean"][i]), train_ses=int(Sc["ses"][i]),
                 train_years={int(y): [int(a), float(b)] for y, a, b in zip(Sc["years"], Sc["yn"][:, i],
                                                                           Sc["ymean"][:, i])},
                 test_years=years_of(sd[te], net[te], m))
        mtr = CL.zmask(z, Btr)
        e["train_rest"] = float(net[tr][~mtr].mean()) if (~mtr).any() else np.nan
        e["train_excess"] = float(np.nanmean(ex[tr][mtr])) if mtr.any() else np.nan
        tm = te[m][np.argsort(sd[te[m]], kind="stable")]           # in date order, every 10th-ish across the years
        pick = tm[np.unique(np.linspace(0, len(tm) - 1, min(10, len(tm))).round().astype(int))] if len(tm) else tm
        e["examples"] = [{"symbol": X.at[q, "symbol"], "signal_day": str(pd.Timestamp(X.at[q, "sday"]).date()),
                          "rank": int(X.at[q, "rank"]), "engines": X.at[q, "engines"], "net": float(net[q])}
                         for q in pick]
        rows.append(e)
    rows = CL.holm(rows) if rows else rows
    for r in rows:
        r["final"] = "REPEATABLE" if r.get("final") == "HOLDS" else "NOT REPEATABLE"
    res["filters"] = rows
    res["candidates"], res["eligible"], res["overlap_skipped"] = len(Sc["keys"]), n_elig, skipped
    top = order[:25]
    res["top25"] = pd.DataFrame([{"place": k + 1, "filter": CL.ztext(Sc["keys"][i], dims), "picks": int(Sc["n"][i]),
                                  "sessions": int(Sc["ses"][i]), "mean_net": float(Sc["mean"][i]),
                                  **{f"n_{y}": int(Sc["yn"][j, i]) for j, y in enumerate(Sc["years"])},
                                  **{f"net_{y}": float(Sc["ymean"][j, i]) for j, y in enumerate(Sc["years"])},
                                  "chosen": int(i) in set(chosen)} for k, i in enumerate(top)])
    # ---- the tradability check (descriptive)
    res["tradability"] = tradability(SL, CL, X, P, B, rows, Sc, chosen, test)
    # ---- the atlas
    res["groups"] = groups_table(SL, X, disc, test)
    res["measures"] = measures_table(SL, X, B, dims, cont, disc, test)
    res["daytypes"], res["transitions"] = daytype_tables(X, disc, test)
    res["B"], res["disc"], res["test"] = B, disc, test
    return res


def years_of(days: np.ndarray, net: np.ndarray, m: np.ndarray) -> Dict[int, list]:
    yr = pd.DatetimeIndex(days).year.to_numpy()
    out = {}
    for y in sorted(set(yr)):
        k = (yr == y)
        out[int(y)] = [int((k & m).sum()), float(net[k & m].mean()) if (k & m).any() else np.nan,
                       float(net[k & ~m].mean()) if (k & ~m).any() else np.nan]
    return out


def tradability(SL, CL, X, P, B, rows, Sc, chosen, test) -> pd.DataFrame:
    """Each chosen filter read at the T0 close on every jumpy pick of ranks 1-3 in the test years, per engine: buy at
    the D1 open (D5 close) against the tree's own result on the same picks (its setup trade, 0 when skipped)."""
    out = []
    if not len(P):
        return pd.DataFrame(out)
    uid = P["uid"].to_numpy(np.int64)
    pt = test[uid]
    for r, i in zip(rows, chosen):
        z = Sc["keys"][i]
        mm = CL.zmask(z, {k: v[uid] for k, v in B.items()})
        for eng in ("D", "ENS"):
            m = pt & mm & (P["engine"].to_numpy() == eng)
            row = {"filter": r["rank"], "engine": eng, "picks": int(m.sum()),
                   "never_caught": int((m & (P["group"].to_numpy() == "N")).sum())}
            if m.sum() >= 2:
                days = P["sday"].to_numpy().astype("datetime64[D]")[m]
                d = P["d1_net"].to_numpy(float)[m] - P["tree_res"].to_numpy(float)[m]
                boot = SL.Boot(days)
                di = np.searchsorted(boot.days, days)
                lo, hi = boot.ci_idx(di, d)
                row.update(open_net=float(P["d1_net"].to_numpy(float)[m].mean()),
                           tree_net=float(P["tree_res"].to_numpy(float)[m].mean()), diff=float(d.mean()), diff_lo=lo,
                           diff_hi=hi)
            out.append(row)
    return pd.DataFrame(out)


def groups_table(SL, X, disc, test) -> pd.DataFrame:
    rows = []
    grp = X["group"].astype(str).to_numpy()
    net, ex = X["d1_net"].to_numpy(float), X["excess"].to_numpy(float)
    mfe, mae, o6 = (X[k].to_numpy(float) for k in ("mfe", "mae", "open6"))
    rk = X["rank"].to_numpy(float)
    setup = X["setup_net"].to_numpy(float)
    sd = X["sday"].to_numpy().astype("datetime64[D]")
    for pname, per in (("discovery", disc), ("test", test)):
        if not per.any():
            continue
        boot = SL.Boot(sd[per])
        di = np.full(len(X), -1, np.int64)
        di[per] = np.searchsorted(boot.days, sd[per])
        for band, bm in (("1-10", np.ones(len(X), bool)), ("1-3", rk <= 3), ("4-10", rk > 3)):
            masks = [per & bm & (grp == g) for g in GROUPS]
            Rn = boot_means(boot, di, np.nan_to_num(net), masks)
            okx = np.isfinite(ex)
            Re = boot_means(boot, di, np.nan_to_num(ex), [m & okx for m in masks])
            for j, g in enumerate(GROUPS):
                m = masks[j]
                if not m.any():
                    continue
                lo, hi = ci_from(Rn[:, j])
                elo, ehi = ci_from(Re[:, j])
                rows.append({"period": pname, "ranks": band, "group": g, "what": GNAME[g], "picks": int(m.sum()),
                             "net": float(net[m].mean()), "net_lo": lo, "net_hi": hi,
                             "excess": float(np.nanmean(ex[m])) if (m & okx).any() else np.nan, "excess_lo": elo,
                             "excess_hi": ehi, "win": float((net[m] > 0).mean()),
                             "mfe": float(np.nanmean(mfe[m])) * 100, "mae": float(np.nanmean(mae[m])) * 100,
                             "up5": float(np.nanmean(mfe[m] >= 0.05)), "up10": float(np.nanmean(mfe[m] >= 0.10)),
                             "dn8": float(np.nanmean(mae[m] <= -0.08)),
                             "open6": float(np.nanmean(o6[m])) if np.isfinite(o6[m]).any() else np.nan,
                             "setup_trade": float(np.nanmean(setup[m])) if g == "C" and np.isfinite(setup[m]).any()
                             else np.nan})
    return pd.DataFrame(rows)


def measures_table(SL, X, B, dims, cont, disc, test) -> pd.DataFrame:
    """Every measure: medians in N / C / K, AUC of N against C and K per period, and within N the top-minus-bottom
    bucket spread of the net with its 95% interval per period and year by year (descriptive)."""
    grp = X["group"].astype(str).to_numpy()
    N = grp == "N"
    net = X["d1_net"].to_numpy(float)
    sd = X["sday"].to_numpy().astype("datetime64[D]")
    yr = pd.DatetimeIndex(sd).year.to_numpy()
    inper = disc | test
    kind = {d["name"]: d for d in dims}
    names = list(cont) + [f"z_{d}" for d in SL.ZDIM] + [d["name"] for d in dims if d["kind"] == "zone" and
                                                         d["name"] not in SL.ZDIM]
    zone_of = {f"z_{d}": d for d in SL.ZDIM}
    pers = {}
    for pname, per in (("disc", disc), ("test", test)):
        m = per & N
        if m.any():
            boot = SL.Boot(sd[m])
            di = np.full(len(X), -1, np.int64)
            di[m] = np.searchsorted(boot.days, sd[m])
            pers[pname] = (m, boot, di)
    rows, specs = [], []
    for nm in names:
        bk = B.get(zone_of.get(nm, nm))
        r = {"measure": nm, "family": family(nm)}
        vals = X[nm].to_numpy(float) if nm in X.columns else np.where(bk >= 0, bk, np.nan).astype(float)
        for g in GROUPS:
            x = vals[grp == g]
            r[f"median_{g}"] = float(np.nanmedian(x)) if np.isfinite(x).any() else np.nan
        for pname, per in (("disc", disc), ("test", test)):
            r[f"auc_NC_{pname}"] = auc(vals[per & N], vals[per & (grp == "C")])
            r[f"auc_NK_{pname}"] = auc(vals[per & N], vals[per & (grp == "K")])
        lo_b, hi_b = None, None
        if bk is not None and (bk >= 0).any():
            present = sorted(int(b) for b in np.unique(bk[(bk >= 0) & disc & N]) if ((bk == b) & disc & N).sum() >= 20)
            if len(present) >= 2:
                lo_b, hi_b = present[0], present[-1]
        r["low_bucket"], r["high_bucket"] = lo_b, hi_b
        if bk is not None and nm in kind and kind[nm]["kind"] == "feature":
            for pname, per in (("disc", disc), ("test", test)):
                for q in range(4):
                    mq = per & N & (bk == q)
                    r[f"q{q + 1}_{pname}"] = float(net[mq].mean()) if mq.any() else np.nan
        if lo_b is not None:
            for y in YEARS:
                a, b = inper & N & (yr == y) & (bk == hi_b), inper & N & (yr == y) & (bk == lo_b)
                r[f"spread_{y}"] = float(net[a].mean() - net[b].mean()) if a.any() and b.any() else np.nan
        rows.append(r)
        specs.append((bk, lo_b, hi_b))
    T = pd.DataFrame(rows)
    for pname, (m, boot, di) in pers.items():
        masks, idx = [], []
        for j, (bk, lo_b, hi_b) in enumerate(specs):
            if lo_b is None:
                continue
            masks += [m & (bk == hi_b), m & (bk == lo_b)]
            idx.append(j)
        R = boot_means(boot, di, np.nan_to_num(net), masks) if masks else np.zeros((1, 0))
        sp, lo, hi = np.full(len(T), np.nan), np.full(len(T), np.nan), np.full(len(T), np.nan)
        for k, j in enumerate(idx):
            a, b = masks[2 * k], masks[2 * k + 1]
            if a.any() and b.any():
                sp[j] = float(net[a].mean() - net[b].mean())
                lo[j], hi[j] = ci_from(R[:, 2 * k] - R[:, 2 * k + 1])
        T[f"spread_{pname}"], T[f"spread_{pname}_lo"], T[f"spread_{pname}_hi"] = sp, lo, hi
    for c in ("spread_disc", "spread_disc_lo", "spread_disc_hi", "spread_test", "spread_test_lo", "spread_test_hi"):
        if c not in T.columns:
            T[c] = np.nan
    up = (T["spread_disc_lo"] > 0) & (T["spread_test_lo"] > 0)
    dn = (T["spread_disc_hi"] < 0) & (T["spread_test_hi"] < 0)
    T["repeatable_association"] = np.where(up, "higher is better", np.where(dn, "lower is better", ""))
    ys = [c for c in T.columns if c.startswith("spread_20")]
    T["years_same_sign"] = [int(sum(1 for c in ys if np.isfinite(r[c]) and np.isfinite(r["spread_disc"]) and
                                    np.sign(r[c]) == np.sign(r["spread_disc"]) and r[c] != 0)) for _, r in T.iterrows()]
    return T


def family(nm: str) -> str:
    if nm.startswith("Tm1_"):
        return "T-1 session"
    if nm.startswith("T0_"):
        return "T0 session"
    if nm.startswith("x_"):
        return "T0 against T-1"
    if nm.startswith("z_"):
        return "zone"
    if nm.startswith("sde"):
        return "SDE"
    if nm in DAILY:
        return "daily"
    if nm in ("rank", "in_both"):
        return "pick"
    return "panel"


def daytype_tables(X, disc, test) -> Tuple[pd.DataFrame, pd.DataFrame]:
    grp = X["group"].astype(str).to_numpy()
    net = X["d1_net"].to_numpy(float)
    rows, trans = [], []
    for pname, per in (("discovery", disc), ("test", test)):
        for d in DAYS:
            t = X[f"{d}_type"].astype(str).to_numpy()
            for g in GROUPS:
                m = per & (grp == g) & (t != "")
                for t_ in TYPES:
                    k = m & (t == t_)
                    rows.append({"period": pname, "day": DAY_TEXT[d], "group": g, "type": t_, "picks": int(k.sum()),
                                 "share": float(k.sum() / m.sum()) if m.sum() else np.nan,
                                 "net": float(net[k].mean()) if k.any() else np.nan})
        a, b = X["Tm1_type"].astype(str).to_numpy(), X["T0_type"].astype(str).to_numpy()
        m = per & (grp == "N") & (a != "") & (b != "")
        for t1 in TYPES:
            for t0 in TYPES:
                k = m & (a == t1) & (b == t0)
                if k.any():
                    trans.append({"period": pname, "T-1": t1, "T0": t0, "picks": int(k.sum()),
                                  "share": float(k.sum() / m.sum()), "net": float(net[k].mean()),
                                  "win": float((net[k] > 0).mean())})
    return pd.DataFrame(rows), pd.DataFrame(trans)


# ---------------------------------------------------------------------------------------------------- the report
def _f(x, nd=2, sign=True) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


def _ci(lo, hi, nd=2) -> str:
    return f"[{_f(lo, nd)}, {_f(hi, nd)}]"


def report(res: dict, decl: dict, sha: str, info: dict, secs: float) -> str:
    F = res["filters"]
    rep = [f for f in F if f["final"] == "REPEATABLE"]
    L = [f"# skiplab - {decl['name'].split(' - ')[0]} ({VERSION})", "",
         f"Declaration sha256 `{sha[:16]}` (declared {decl['declared']}, before any run). Tree run {info['tree_run']}, "
         f"TAGS run {info['tags_run']}; panel `{info['panel']}`. {secs:.0f} s.", "",
         "## Verdict first", "",
         f"- **{len(rep)} of {len(F)} filters REPEATABLE**" + (": " + "; ".join(f"#{f['rank']} {f['text']}" for f in rep)
                                                              if rep else " - nothing found on Oct 2021-2023 held "
                                                              "on 2024 onward under the declared rule.") + "",
         f"- Searched {res['candidates']:,} filters ({res['dims']} measures) on {res['periods']['discovery']:,} "
         f"never-caught jumpy picks of Oct 2021-2023; {res['eligible']:,} eligible; judged on "
         f"{res['periods']['test']:,} picks from 2024 (never used to choose).", "",
         "| # | filter | discovery picks | discovery net % | test picks | test net % inside | rest | inside - rest "
         "[95%] | excess over Smallcap 250 [95%] | p | Holm limit | verdict |",
         "|---|---|---:|---:|---:|---:|---:|---|---|---:|---:|---|"]
    for f in F:
        L.append(f"| {f['rank']} | {f['text']} | {f['train_n']:,} | {_f(f['train_mean'])} | {f.get('n', 0):,} | "
                 f"{_f(f.get('net'))} | {_f(f.get('net_out'))} | {_f(f.get('diff'))} "
                 f"{_ci(f.get('diff_lo'), f.get('diff_hi'))} | {_f(f.get('chk'))} {_ci(f.get('chk_lo'), f.get('chk_hi'))} "
                 f"| {f.get('p', float('nan')):.4f} | {f.get('holm_limit', float('nan')):.4f} | **{f['final']}** |")
    L += ["", "REPEATABLE = inside beat the rest of the never-caught picks AND beat Smallcap 250, both with 95% "
              "intervals above 0, kept by Holm across the 5 (0.025). Year by year (picks inside, net inside, net of "
              "the rest):", ""]
    for f in F:
        L.append(f"- #{f['rank']}: discovery " + ", ".join(f"{y} {a} at {_f(b)}" for y, (a, b) in
                                                           f["train_years"].items()) +
                 "; test " + ", ".join(f"{y} {a} at {_f(b)} vs {_f(c)}" for y, (a, b, c) in f["test_years"].items()))
    T = res["tradability"]
    L += ["", "## Tradability check (descriptive)", "",
          "Never caught is known only after D5, so each filter was also read at the T0 close on EVERY jumpy pick of "
          "ranks 1-3 in the test years (caught or not): buying them at the D1 open against what the frozen tree did "
          "with the same picks (its setup trade, 0 when it skipped). Capacity ignored.", "",
          "| # | engine | picks | of them never caught | D1 open -> D5 close % | tree % | difference [95%] |",
          "|---|---|---:|---:|---:|---:|---|"]
    for r in T.to_dict("records") if len(T) else []:
        L.append(f"| {r['filter']} | {r['engine']} | {r['picks']:,} | {r['never_caught']:,} | {_f(r.get('open_net'))} | "
                 f"{_f(r.get('tree_net'))} | {_f(r.get('diff'))} {_ci(r.get('diff_lo'), r.get('diff_hi'))} |")
    G = res["groups"]
    L += ["", "## Who they are: never-caught jumpy picks against caught jumpy and calm picks", "",
          "Buy at the D1 open, sell at the D5 close, net % after 0.35 pp; excess = over Smallcap 250 on the same dates; "
          "MFE / MAE from the D1 open over D1-D5; up5 / up10 = touched +5% / +10%; dn8 = touched -8%. 95% intervals "
          "over signal days.", "",
          "| period | ranks | group | picks | net % [95%] | excess % [95%] | win | MFE % | MAE % | up5 | up10 | dn8 | "
          "OPEN6 % | setup trade % |", "|---|---|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in G.to_dict("records") if len(G) else []:
        L.append(f"| {r['period']} | {r['ranks']} | {r['group']} {r['what']} | {r['picks']:,} | {_f(r['net'])} "
                 f"{_ci(r['net_lo'], r['net_hi'])} | {_f(r['excess'])} {_ci(r['excess_lo'], r['excess_hi'])} | "
                 f"{r['win']:.1%} | {_f(r['mfe'])} | {_f(r['mae'])} | {r['up5']:.1%} | {r['up10']:.1%} | "
                 f"{r['dn8']:.1%} | {_f(r['open6'])} | {_f(r['setup_trade'])} |")
    M = res["measures"]
    if len(M):
        M = M.copy()
        M["gap_disc"] = (M["auc_NC_disc"] - 0.5).abs()
        top = M[np.isfinite(M["auc_NC_disc"])].sort_values("gap_disc", ascending=False).head(15)
        L += ["", "## What sets the never-caught picks apart (N against caught jumpy picks C)", "",
              "AUC = the chance a never-caught pick has the higher value than a caught one (0.5 = no difference). "
              "Kept when the test years point the same way.", "",
              "| measure | family | median N | median C | median K | AUC N vs C discovery | test | same side |",
              "|---|---|---:|---:|---:|---:|---:|---|"]
        for r in top.to_dict("records"):
            same = np.isfinite(r["auc_NC_test"]) and np.sign(r["auc_NC_test"] - 0.5) == np.sign(r["auc_NC_disc"] - 0.5)
            L.append(f"| {r['measure']} | {r['family']} | {_f(r['median_N'], 3, False)} | {_f(r['median_C'], 3, False)} |"
                     f" {_f(r['median_K'], 3, False)} | {_f(r['auc_NC_disc'], 3, False)} | "
                     f"{_f(r['auc_NC_test'], 3, False)} | {'yes' if same else 'no'} |")
        ra = M[M["repeatable_association"] != ""]
        L += ["", "## What lines up with how they did (within the never-caught picks)", "",
              "Spread = mean net % of the top bucket minus the bottom bucket (quarters at the discovery quartiles; "
              "zones and day types their own). Listed when the spread is above (or below) 0 with 95% in BOTH periods "
              "- descriptive, the repeatable test above decides.", ""]
        if len(ra):
            L += ["| measure | family | direction | spread discovery [95%] | spread test [95%] | years same sign |",
                  "|---|---|---|---|---|---:|"]
            for r in ra.to_dict("records"):
                L.append(f"| {r['measure']} | {r['family']} | {r['repeatable_association']} | {_f(r['spread_disc'])} "
                         f"{_ci(r['spread_disc_lo'], r['spread_disc_hi'])} | {_f(r['spread_test'])} "
                         f"{_ci(r['spread_test_lo'], r['spread_test_hi'])} | {r['years_same_sign']} of 6 |")
        else:
            L.append("- None: no measure's spread held with 95% in both periods.")
        M["abs_disc"] = M["spread_disc"].abs()
        L += ["", "The 15 largest discovery spreads, with the test years beside them:", "",
              "| measure | family | spread discovery [95%] | spread test [95%] | years same sign |", "|---|---|---|---|---:|"]
        for r in M[np.isfinite(M["abs_disc"])].sort_values("abs_disc", ascending=False).head(15).to_dict("records"):
            L.append(f"| {r['measure']} | {r['family']} | {_f(r['spread_disc'])} "
                     f"{_ci(r['spread_disc_lo'], r['spread_disc_hi'])} | {_f(r['spread_test'])} "
                     f"{_ci(r['spread_test_lo'], r['spread_test_hi'])} | {r['years_same_sign']} of 6 |")
    D, Tr = res["daytypes"], res["transitions"]
    if len(D):
        L += ["", "## Day types (the daily bar, declared rules)", "", "Share of each type, never caught / caught / calm, "
              "and the never-caught picks' mean net % in that type:", "",
              "| period | day | type | N share | C share | K share | N net % |", "|---|---|---|---:|---:|---:|---:|"]
        for (pn, dy, t_), g in D.groupby(["period", "day", "type"], sort=False):
            s = {r["group"]: r for r in g.to_dict("records")}
            L.append(f"| {pn} | {dy} | {t_} | {s.get('N', {}).get('share', np.nan):.1%} | "
                     f"{s.get('C', {}).get('share', np.nan):.1%} | {s.get('K', {}).get('share', np.nan):.1%} | "
                     f"{_f(s.get('N', {}).get('net', np.nan))} |")
    if len(Tr):
        L += ["", "T-1 then T0 among the never-caught picks (the 12 most common pairs of the discovery years, with the "
                  "test years beside them):", "",
              "| T-1 | T0 | discovery picks | share | net % | test picks | share | net % |",
              "|---|---|---:|---:|---:|---:|---:|---:|"]
        a = Tr[Tr["period"] == "discovery"].sort_values("picks", ascending=False).head(12)
        b = Tr[Tr["period"] == "test"].set_index(["T-1", "T0"])
        for r in a.to_dict("records"):
            t = b.loc[(r["T-1"], r["T0"])] if (r["T-1"], r["T0"]) in b.index else None
            L.append(f"| {r['T-1']} | {r['T0']} | {r['picks']:,} | {r['share']:.1%} | {_f(r['net'])} | "
                     f"{int(t['picks']) if t is not None else 0:,} | "
                     f"{(t['share'] if t is not None else np.nan):.1%} | {_f(t['net'] if t is not None else np.nan)} |")
    L += ["", "## Examples to look at on a chart (test years, inside each filter)", ""]
    for f in F:
        L.append(f"- #{f['rank']}: " + (", ".join(f"{x['symbol']} {x['signal_day']} (rank {x['rank']}, {x['engines']}, "
                                                  f"{_f(x['net'])}%)" for x in f["examples"]) or "none"))
    d = info["data"]
    L += ["", "## Data and checks", "",
          f"- Tree rows {d['tree_rows']:,}; kept {d['kept_rows']:,} (from {INTRADAY_FIRST}, not ETF, a lane, complete); "
          f"stock-days {d['stock_days']:,}; a stock-day whose rows disagree on the group: {d['group_mismatch']}, on "
          f"the D1 net: {d['net_mismatch']}.",
          f"- Bars: {d['no_bars']:,} stock-days without T-1, T0 and D1-D5 bars (left out). The tree's D1 net against "
          f"the bars: {d['chk_same']:,} of {d['chk_n']:,} within 0.01 pp (largest difference {d['chk_max']:.4g}).",
          f"- 3-minute sessions: {d['sessions']['usable']:,} usable of {d['sessions']['asked']:,} asked "
          f"({d['sessions']['with_bars']:,} with bars); T-1 usable on {d['usable_Tm1']:.1%} and T0 on "
          f"{d['usable_T0']:.1%} of the study's picks; reasons {d['sessions']['reasons']}.",
          f"- Panel row of T0 found for {d['panel_found']:.1%}; Smallcap 250's open missing (T0 close used) "
          f"{d['index_open_fallback']:,} times.", "",
          "## What this is not", ""] + [f"- {x}" for x in decl["what_this_is_not"]]
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------------------------------- the run
def ledger_runs(bout: Path, sha: str) -> List[dict]:
    p = bout / LEDGER
    if not p.is_file():
        return []
    out = []
    for ln in p.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(ln)
        except ValueError:
            continue
        if r.get("event") == "run" and r.get("declaration_sha256") == sha:
            out.append(r)
    return out


def execute(SL, JL, CL, decl, sha, tree, trinfo, tinfo, panel, market, bout: Path, rerun_reason=None, log=say):
    t0 = time.time()
    done = ledger_runs(bout, sha)
    if done and not rerun_reason:
        raise SKError(f"SK1 already ran ({done[-1].get('run')}); a second run needs --rerun-reason \"<a verified "
                      f"bug>\" - never to try other settings")
    feats, ff = features_final(SL)
    U, P, dinfo = stock_days(tree)
    log(f" {dinfo['stock_days']:,} stock-days (D and ENS, ranks 1-10, from {INTRADAY_FIRST}); building the measures")
    Xm, binfo = build(SL, JL, market, U, log)
    X = pd.concat([U.reset_index(drop=True), Xm], axis=1)
    log(" reading the panel's 60 features at T0")
    pv, found = read_panel(panel, feats, X, log)
    for j, f in enumerate(feats):
        X[f] = pv[:, j]
    keep = ~X["tm1"].isna() & ~X["d5"].isna()
    chk = keep & np.isfinite(X["chk_net"].to_numpy(float))
    cd = np.abs(X["chk_net"].to_numpy(float) - X["d1_net"].to_numpy(float))[chk.to_numpy()]
    dinfo.update(binfo)
    dinfo.update({"panel_found": found, "chk_n": int(chk.sum()), "chk_same": int((cd <= 0.01).sum()),
                  "chk_max": float(cd.max()) if len(cd) else 0.0,
                  "usable_Tm1": float(X.loc[keep & (X["group"] == "N"), "Tm1_usable"].mean()) if keep.any() else 0.0,
                  "usable_T0": float(X.loc[keep & (X["group"] == "N"), "T0_usable"].mean()) if keep.any() else 0.0})
    cont = list(DAILY) + [f"{d}_{m}" for d in DAYS for m in BAR + PATH] + list(CROSS) + list(feats) + ["rank"]
    res = study(SL, CL, X, P, cont, log)
    run = SL.new_run_dir(bout / "runs", "SK")
    info = {"tree_run": trinfo["run"], "tags_run": tinfo["run"], "panel": str(panel), "data": dinfo}
    secs = time.time() - t0
    (run / "REPORT.md").write_text(report(res, decl, sha, info, secs), encoding="utf-8")
    Xo = X.copy()
    Xo["period"] = np.where(res["disc"], "discovery", np.where(res["test"], "test", ""))
    for f in res["filters"]:
        Xo[f"in_filter_{f['rank']}"] = CL.zmask(f["z"], res["B"])
    Xo.to_parquet(run / "picks.parquet", index=False)
    res["groups"].to_csv(run / "groups.csv", index=False, float_format="%.6g")
    res["measures"].to_csv(run / "measures.csv", index=False, float_format="%.6g")
    res["daytypes"].to_csv(run / "daytypes.csv", index=False, float_format="%.6g")
    res["transitions"].to_csv(run / "transitions.csv", index=False, float_format="%.6g")
    pd.DataFrame([{k: (json.dumps(v) if isinstance(v, (dict, list)) else v) for k, v in f.items() if k != "z"}
                  for f in res["filters"]]).to_csv(run / "filters.csv", index=False, float_format="%.6g")
    res["top25"].to_csv(run / "top25.csv", index=False, float_format="%.6g")
    res["tradability"].to_csv(run / "tradability.csv", index=False, float_format="%.6g")
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    rj = {"tool": VERSION, "made": dt.datetime.now().isoformat(timespec="seconds"), "declaration_sha256": sha,
          "tree_run": trinfo["run"], "tree_sha256": trinfo.get("sha256"), "tags_run": tinfo["run"],
          "panel": str(panel), "features_file": str(ff), "features_sha256": sha256(ff), "measures": res["dims"],
          "candidates": res["candidates"], "eligible": res["eligible"], "periods": res["periods"],
          "filters": [{k: f.get(k) for k in ("rank", "key", "text", "train_n", "train_mean", "n", "net", "net_out",
                                             "diff", "diff_lo", "diff_hi", "chk", "chk_lo", "chk_hi", "p", "holm_limit",
                                             "final")} for f in res["filters"]],
          "data": dinfo, "libraries": {"setuplab": getattr(SL, "VERSION", "?"), "jumplab": JL.VERSION,
                                       "cl2": CL.VERSION, "tl_setups": getattr(SU, "SETUPS_VERSION", "?"),
                                       "tradelab": getattr(TC, "VERSION", "?")},
          "rerun_reason": rerun_reason, "seconds": round(secs, 1)}
    (run / "run.json").write_text(json.dumps(rj, indent=1, default=str), encoding="utf-8")
    names = ["REPORT.md", "picks.parquet", "groups.csv", "measures.csv", "daytypes.csv", "transitions.csv",
             "filters.csv", "top25.csv", "tradability.csv", "DECLARATION.json", "run.json"]
    SL.write_hashes(run, names)
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": dt.datetime.now().isoformat(timespec="seconds"), "tool": VERSION, "event": "run",
                            "run": run.name, "declaration_sha256": sha, "tree_run": trinfo["run"],
                            "tags_run": tinfo["run"], "repeatable": [x["rank"] for x in res["filters"]
                                                                     if x["final"] == "REPEATABLE"],
                            "rerun_reason": rerun_reason}) + "\n")
    return run, res


def cmd_run(a) -> int:
    decl, sha = load_decl()
    SL, JL, CL = libs()
    root = Path(a.root) if a.root else None
    if root is None or not root.is_dir():
        raise SKError("--root must be the daily cache (%CACHE_DAILY_ROOT%)")
    base = SU.base_dir(a.setups)
    if base is None:
        raise SKError("setuplab's output folder: pass --setups or start with env_skiplab.bat (sets SETUPLAB_OUT)")
    tree, trinfo, tinfo, panel = resolve(base, a.features)
    bout = out_base(a.out, root)
    say(f"{VERSION} run | declaration {sha[:16]} | tree {trinfo['run']} | tags {tinfo['run']} | out {bout}")
    market = TD.Market(root, TD.Production(stage_e_any=a.stage_e_any))
    run, res = execute(SL, JL, CL, decl, sha, tree, trinfo, tinfo, panel, market, bout, a.rerun_reason)
    say(f"wrote {run}")
    for f in res["filters"]:
        say(f"#{f['rank']} {f['text']}: discovery {f['train_mean']:+.2f}% ({f['train_n']}) -> test "
            f"{f.get('net', float('nan')):+.2f}% vs rest {f.get('net_out', float('nan')):+.2f}% -> {f['final']}")
    say("RESULT: " + (", ".join(f"#{f['rank']} REPEATABLE" for f in res["filters"] if f["final"] == "REPEATABLE")
                      or "no filter repeatable") + " (send Claude REPORT.md)")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="skiplab: the jumpy picks no frozen setup catches (SK1)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="the declaration is the pinned one; setuplab, jumplab and cl2 are the versions used")
    r = sub.add_parser("run", help="build every measure, search on Oct 2021-2023, judge on 2024 onward, the atlas")
    r.add_argument("--root")
    r.add_argument("--setups", default=None)
    r.add_argument("--features", default=None)
    r.add_argument("--out", default=None)
    r.add_argument("--stage-e-any", action="store_true")
    r.add_argument("--rerun-reason", default=None)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if a.cmd == "check":
            d, sha = load_decl()
            SL, JL, CL = libs()
            say(f"OK {DECL_FILE.name} sha256 {sha} ({d['name'].split(' - ')[0]}, declared {d['declared']}); "
                f"{getattr(SL, 'VERSION', 'setuplab ?')}, {JL.VERSION}, {CL.VERSION}, {getattr(SU, 'SETUPS_VERSION', '?')}")
            return 0
        return cmd_run(a)
    except (SKError, TC.TLError, ValueError) as e:
        say(f"ERROR: {e}")
        return 2
    except TC.StopRun as e:
        say(f"STOPPED: {e}")
        return 3


if __name__ == "__main__":
    sys.exit(main())
