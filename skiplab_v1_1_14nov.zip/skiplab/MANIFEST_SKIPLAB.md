# MANIFEST - skiplab v1.1 (study SK1, backtest SK2)

Built 14 Nov 2026. Folder: C:\Users\karanvsi\PyCharmMiscProject\skiplab (beside tradelab, setuplab, jumplab and clashlab, never inside bigmove_deploy). Outputs: C:\QuantData\skiplab. Reads production, setuplab's runs, the research watchlist and the panel READ ONLY.

Uses, unchanged and version-checked: tradelab (tl_data, tl_setups v1.7), setuplab v1.1 (zones, ATR, the bootstrap, run folders; SK2: the tree's own loader, picks, books and book simulator), jumplab v1.0 / v1.0.1 (daily features), clashlab cl2 v1.0 (the search, judge and Holm). Nothing in those folders changes.

Declarations: SK1 0fe32bffb8fb9a083ce5fc1536b7587bf49f902698369f3fa33422b4db08a84b (unchanged); SK2 2444726dbe5b33106ad74e4fcb01b626ffcffe5c305b52e03717615d497a34a5 (new).

| file | version | sha256 (first 16) | in the v1.1 zip | role |
|---|---|---|---|---|
| skiplab.py | skiplab v1.1 | feba117a2b25123e | yes (replaces v1.0) | COMMAND: check / run (SK1: every measure of T-1 and T0, the CL2 search on Oct 2021-2023, the judge on 2024 onward, the tradability check, the atlas) / book (SK2: the filters as a separate pocket and inside the tree's places, the reconcile, the rule, Holm, the interference counts) |
| SK2_DECLARATION.json | SK2, declared 14 Nov 2026 | 2444726dbe5b3310 | yes (new) | the backtest, fixed before any run on real data (skiplab.py refuses another sha256) |
| SKIPLAB_DECLARATION.json | SK1, declared 14 Nov 2026 | 0fe32bffb8fb9a08 | no (unchanged) | the study, fixed before any run |
| env_skiplab.bat | skiplab v1.0 | 841d26df31828cb3 | no (unchanged) | start a session: env_daily.bat, PYTHONPATH (skiplab, tradelab, setuplab, jumplab, clashlab, open_close, bigmove_deploy), SETUPLAB_OUT, SKIPLAB_OUT (CRLF) |
| README_SKIPLAB.md | skiplab v1.1 | 53633d6f1c2f53f7 | yes | the question, the measures, SK1's two parts, SK2's two parts, install and run, outputs, tests |
| tests/test_skiplab.py | skiplab v1.1 | cd3863eac85f06bb | yes | the self-test (46 checks; must end VERIFIED (skiplab v1.1)); verified on pandas 3.0.5 / numpy 2.5.3 and on pandas 2.3.3 / numpy 2.4.1 |

Planted bugs: SK1 (v1.0) 25 of 25 caught. SK2 31 planted, 29 caught; the 2 not caught change nothing in the history and so cannot be seen: leaving NO ATR picks out (setuplab's complete picks always have an ATR) and taking the a-year return from the marked value (every book holds nothing on the window's last day, so marked = closed).
