"""
tests/test_skiplab.py - skiplab v1.1 self-test (SK1 study and SK2 book).

    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\skiplab
    python tests\\test_skiplab.py

SK1 by hand: the day types and daily-bar measures, the 3-minute measures against an independent loop, T0 against T-1,
the stock-days (groups, one row per stock-day, the tree's result), the panel reader, the buckets, the bootstrap and AUC.
Then synthetic worlds with real file layouts (daily and 3-minute bars, setuplab TREE / TAGS runs, a panel; tradelab's
production stand-ins): a PLANTED world (a strong T0 last hour is followed by +4% over D2-D5) where the filter must be
found on 2021-2023 and hold on 2024 onward, and an ABSENT world where nothing may hold; no look-ahead; outputs, ledger,
the rerun guard.
SK2: a world run through setuplab's own tag and tree commands; the rebuilt tree must match the tree run pick for pick
and trade for trade; every book (the tree, the everything pocket, each filter's pocket and branch) against an
independent simulator on the watchlist's paths; the rule, the interference counts and Holm by hand; a PLANTED filter
passes, a random one and a calm-only one do not; the guards (changed SK1 files, another tree run, a changed watchlist,
the daily cache as output, the rerun guard). Ends 'VERIFIED (skiplab v1.1)' when every check passes; exit code 1
otherwise.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
for _v in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "SKIPLAB_OUT", "SETUPLAB_OUT"):
    os.environ.pop(_v, None)
import tl_data as TD  # noqa: E402
sys.path.insert(0, str(Path(TD.__file__).resolve().parent / "tests"))
import tl_world as W  # noqa: E402
import tl_setups as SU  # noqa: E402
import skiplab as SK  # noqa: E402

SL, JL, CL = SK.libs()
RESULTS = []
N3 = SK.NB
IST = "Asia/Kolkata"


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(("  ok   " if ok else "  FAIL ") + name + ("" if ok else f"   <- {str(detail)[:1500]}"), flush=True)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        out = fn(*a, **k)
    return out, buf.getvalue()


def close(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol)))


# ---------------------------------------------------------------------------------------------------- 1 declaration
def t1_declaration():
    d, sha = SK.load_decl()
    check("t1a the declaration loads with its pinned sha256", sha == SK.DECL_SHA and d["declared"] == "2026-11-14")
    with tempfile.TemporaryDirectory() as t:
        p = Path(t) / "d.json"
        p.write_text(SK.DECL_FILE.read_text(encoding="utf-8").replace("at least 90", "at least 60"), encoding="utf-8")
        try:
            SK.load_decl(p)
            refused = False
        except SK.SKError as e:
            refused = "pinned" in str(e)
    rc, out = quiet(SK.main, ["check"])
    check("t1b a changed declaration is refused; 'check' says OK with the library versions", refused and rc == 0 and
          "OK" in out and SK.CL2_VERSION in out, out[-300:])
    real = CL.VERSION
    CL.VERSION = "cl2 v9"
    try:
        SK.libs()
        bad = False
    except SK.SKError as e:
        bad = "cl2 v9" in str(e)
    CL.VERSION = real
    check("t1c another cl2 version is refused (skiplab uses its search unchanged)", bad)


# ---------------------------------------------------------------------------------------------------- 2 daily bar
def t2_bar():
    cases = {  # (open, high, low, close) after a close of 100, ATR 1
        "QUIET": (100.0, 100.3, 99.9, 100.1), "GAP_UP_GO": (100.6, 101.5, 100.5, 101.2),
        "GAP_UP_FADE": (100.6, 100.9, 99.8, 100.0), "GAP_DN_RECOVER": (99.4, 100.2, 99.2, 99.9),
        "GAP_DN_GO": (99.4, 99.6, 98.5, 98.7), "TREND_UP": (100.1, 101.0, 100.0, 100.9),
        "TREND_DN": (99.9, 100.0, 99.0, 99.1), "REVERSAL_UP": (100.0, 100.5, 99.2, 100.3),
        "REVERSAL_DN": (100.0, 100.8, 99.6, 99.8), "RANGE": (100.0, 100.5, 99.7, 100.2)}
    extra = {"GAP_UP_GO#trend too": (100.6, 101.6, 100.5, 101.5), "QUIET#gap too": (100.6, 100.8, 100.5, 100.7)}
    bad = []
    for name, (o, h, l, c) in {**cases, **extra}.items():
        a = lambda x0, x1: np.array([x0, x1], float)
        m = SK.bar_measures(a(100, o), a(100.2, h), a(99.8, l), a(100, c), a(1, 1), a(np.nan, np.nan), 1, 1.0)
        got = SK.day_type(m)
        if got != name.split("#")[0]:
            bad.append((name, got, m))
    m = SK.bar_measures(np.array([100, 100.6]), np.array([100.2, 101.5]), np.array([99.8, 100.5]),
                        np.array([100, 101.2]), np.array([1, 3.0]), np.array([np.nan, 2.0]), 1, 2.0)
    want = {"gap": 0.3, "oc": 0.3, "range": 0.5, "clv": 0.7, "uwick": 0.3, "lwick": 0.1, "rvol": 1.5}
    nok = SK.bar_measures(np.array([np.nan, 100.6]), np.array([100.2, 101.5]), np.array([99.8, 100.5]),
                          np.array([np.nan, 101.2]), np.ones(2), np.ones(2), 1, 2.0)
    v = np.arange(1, 26, dtype=float)
    md = SK.med20_before(v)
    check("t2a day types by hand: each of the 10 once, the order of precedence (a gap beats a trend, QUIET beats a "
          "gap), unknown without the previous close", not bad and SK.day_type(nok) == "", bad)
    check("t2b daily-bar measures by hand (ATR 2: gap, open-to-close, range, close location, wicks, volume / the "
          "median of the 20 sessions before)", all(abs(m[k] - want[k]) < 1e-9 for k in want) and
          np.isnan(md[19]) and md[20] == 10.5 and md[24] == 14.5, (m, md[18:]))


# ---------------------------------------------------------------------------------------------------- 3 the session
def session(o0, closes, highs=None, lows=None, vols=None, drop=(), usable=True):
    k = np.arange(N3)
    c = np.asarray(closes, float)
    o = np.r_[o0, c[:-1]]
    h = np.maximum(o, c) + 0.05 if highs is None else np.asarray(highs, float)
    lo = np.minimum(o, c) - 0.05 if lows is None else np.asarray(lows, float)
    v = np.ones(N3) if vols is None else np.asarray(vols, float)
    keep = ~np.isin(k, list(drop))
    return TD.Session(np.datetime64("2023-05-02"), k[keep], o[keep], h[keep], lo[keep], c[keep], v[keep], usable, "")


def oracle_path(s, atr, atrp):
    """An independent loop over the bars (the declaration's words, written separately)."""
    present = {int(k): j for j, k in enumerate(s.slot)}
    last, path, closes = s.o[0], [s.o[0]], []
    for k in range(N3):
        if k in present:
            last = s.c[present[k]]
        closes.append(last)
        path.append(last)
    eff = (path[-1] - path[0]) / sum(abs(path[i + 1] - path[i]) for i in range(len(path) - 1))
    pv = vv = 0.0
    above = cnt = 0
    for k in range(N3):
        if k in present:
            j = present[k]
            pv += (s.h[j] + s.l[j] + s.c[j]) / 3 * s.v[j]
            vv += s.v[j]
            cnt += 1
            above += s.c[j] >= pv / vv
    hi = max(s.h)
    lo_ = min(s.l)
    t_hi = [int(k) for k, j in present.items() if s.h[j] == hi][0] / 124
    t_lo = [int(k) for k, j in present.items() if s.l[j] == lo_][0] / 124
    orh = max([s.o[0]] + [s.h[present[k]] for k in range(10) if k in present])
    orl = min([s.o[0]] + [s.l[present[k]] for k in range(10) if k in present])
    fin = path[-1]
    or30 = (fin - orh) / atr if fin > orh else (fin - orl) / atr if fin < orl else 0.0
    r = [np.log(path[i + 1] / path[i]) for i in range(len(path) - 1)]
    rv = np.sqrt(sum(x * x for x in r))
    run_h, run_l, dd, ru = s.o[0], s.o[0], 0.0, 0.0
    for k in range(N3):
        if k in present:
            j = present[k]
            run_h, run_l = max(run_h, s.h[j]), min(run_l, s.l[j])
            dd, ru = max(dd, run_h - s.l[j]), max(ru, s.h[j] - run_l)
    vam = sum(s.v[present[k]] for k in range(20) if k in present) / sum(s.v)
    vpm = sum(s.v[present[k]] for k in range(105, N3) if k in present) / sum(s.v)
    return {"eff": eff, "vwap": (fin - pv / vv) / atr, "vwap_share": above / cnt, "t_hi": t_hi, "t_lo": t_lo,
            "drive30": (closes[9] - s.o[0]) / atr, "or30": or30, "mid": (closes[104] - closes[19]) / atr,
            "last_hour": (fin - closes[104]) / atr, "vol_am": vam, "vol_pm": vpm, "rv": rv / atrp,
            "jump": max(abs(x) for x in r) / rv, "dd": dd / atr, "ru": ru / atr}


def t3_session():
    rng = np.random.default_rng(3)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.003, N3)))
    c[:10] = np.linspace(100.2, 101.0, 10)                    # an opening drive
    vol = rng.integers(1, 9, N3).astype(float)
    bad = {}
    ob = np.r_[100.0, c[:-1]]
    hs, ls = np.maximum(ob, c) + 0.05, np.minimum(ob, c) - 0.05
    hs[30], ls[70] = hs[30] + 3.0, ls[70] - 3.0                 # wicks: the high / low bar is not the extreme close's
    for nm, s in (("full", session(100.0, c, vols=vol)), ("missing bars", session(100.0, c, vols=vol, drop=(3, 50, 51, 124))),
                  ("wicks", session(100.0, c, highs=hs, lows=ls, vols=vol)),
                  ("random highs", session(100.0, c, highs=np.maximum(np.r_[100, c[:-1]], c) + rng.uniform(0, .4, N3),
                                           lows=np.minimum(np.r_[100, c[:-1]], c) - rng.uniform(0, .4, N3), vols=vol))):
        got, p = SK.path_measures(s, 2.0, 0.02)
        want = oracle_path(s, 2.0, 0.02)
        diff = {k: (got[k], want[k]) for k in want if not abs(got[k] - want[k]) < 1e-9}
        if diff or p is None:
            bad[nm] = diff
    un, pu = SK.path_measures(session(100.0, c, usable=False), 2.0, 0.02)
    check("t3a the 3-minute measures equal an independent loop (eff, VWAP and time above it, high / low times, drive, "
          "opening-range break, midday, last hour, volume shares, realised volatility, jump, fall / rise) - also with "
          "missing bars (the last close carried), real highs / lows and long wicks", not bad, bad)
    check("t3b an unusable session leaves every 3-minute measure blank", pu is None and all(np.isnan(v) for v in un.values()))
    s1, s0 = session(100.0, c, vols=vol), session(c[-1] * 1.01, c * 1.01 + 0.3, vols=vol)
    _, p1 = SK.path_measures(s1, 2.0, 0.02)
    _, p0 = SK.path_measures(s0, 2.0, 0.02)
    o, h, lo_, cl, v = (np.array(x, float) for x in ([100, 101], [102, 104], [99, 100], [101, 103.5], [10, 25]))
    x = SK.cross_measures(o, h, lo_, cl, v, 1, 2.0, p1, p0)
    pp = np.r_[p1, p0]
    want = {"x_hi": 1.0, "x_lo": 0.5, "x_close_hi": 0.75, "x_range": 4 / 3, "x_vol": 2.5,
            "x_eff2": (pp[-1] - pp[0]) / np.abs(np.diff(pp)).sum()}
    check("t3c T0 against T-1 by hand (highs, lows, close vs the T-1 high, range and volume ratios, the two-session "
          "SDE with the overnight move)", all(abs(x[k] - want[k]) < 1e-9 for k in want), (x, want))


# ---------------------------------------------------------------------------------------------------- 4 stock-days
def t4_stock_days():
    rows = [("D-20220103-1", "D", 1, "AAA", "2022-01-03", "JUMPY", False, "", np.nan, 1.0, True),
            ("ENS-20220103-2", "ENS", 2, "aaa ", "2022-01-03", "JUMPY", False, "", np.nan, 1.0, True),
            ("D-20220103-2", "D", 2, "BBB", "2022-01-03", "JUMPY", False, "S2@D3", 2.5, -1.0, True),
            ("D-20220103-3", "D", 3, "CCC", "2022-01-03", "CALM", False, "", np.nan, 0.5, True),
            ("D-20220104-1", "D", 1, "GOLDBEES", "2022-01-04", "JUMPY", True, "", np.nan, 0.1, True),
            ("D-20220104-2", "D", 2, "DDD", "2022-01-04", "NO CUT-OFF", False, "", np.nan, 0.1, True),
            ("D-20220104-3", "D", 3, "EEE", "2022-01-04", "NO ATR", False, "", np.nan, -2.0, True),
            ("D-20220104-4", "D", 4, "FFF", "2022-01-04", "JUMPY", False, "", np.nan, 0.3, False),
            ("D-20210901-1", "D", 1, "GGG", "2021-09-01", "JUMPY", False, "", np.nan, 0.3, True),
            ("ENS-20220104-5", "ENS", 5, "HHH", "2022-01-04", "JUMPY", False, "", np.nan, 3.0, True),
            ("D-20220105-1", "D", 1, "III", "2022-01-05", "JUMPY", False, "C1@D2", np.nan, 0.2, True)]
    T = pd.DataFrame(rows, columns=["trade_id", "engine", "rank", "symbol", "signal_day", "lane", "etf", "first_setup",
                                    "setup_net", "d1_net", "complete"])
    U, P, info = SK.stock_days(T)
    got = {r.symbol: (r.group, int(r.rank), r.engines, bool(r.in_both)) for r in U.itertuples()}
    want = {"AAA": ("N", 1, "D,ENS", True), "BBB": ("C", 2, "D", False), "CCC": ("K", 3, "D", False),
            "EEE": ("N", 3, "D", False), "HHH": ("N", 5, "ENS", False), "III": ("C", 1, "D", False)}
    pr = sorted((r.trade_id, r.group, float(r.tree_res)) for r in P.itertuples())
    check("t4a stock-days by hand: one row per stock-day (best rank, both engines), N / C / K, ETFs, NO CUT-OFF, "
          "incomplete and pre-Oct 2021 picks out, NO ATR = jumpy", got == want and info["stock_days"] == 6 and
          info["group_mismatch"] == 0, (got, info))
    check("t4b the tree's result per jumpy ranks 1-3 row: 0 when skipped, its setup net when caught, an unsettled "
          "setup trade left out, rank 5 not in the tree's own picks",
          pr == [("D-20220103-1", "N", 0.0), ("D-20220103-2", "C", 2.5), ("D-20220104-3", "N", 0.0),
                 ("ENS-20220103-2", "N", 0.0)], pr)


# ---------------------------------------------------------------------------------------------------- 5 panel, buckets
def t5_panel_buckets():
    with tempfile.TemporaryDirectory() as t:
        ts = pd.to_datetime(["2023-01-02 00:00", "2023-01-03 00:00", "2023-01-02 00:00", "2023-01-04 00:00"])
        P = pd.DataFrame({"Symbol": [" aaa", "AAA", "BBB", "BBB"],
                          "Timestamp": ts.tz_localize(IST).tz_convert("UTC"),
                          "D_Feat_One": [1.0, 2.0, 3.0, 4.0], "w_two": np.array([5, 6, 7, 8], np.float32)})
        P.to_parquet(Path(t) / "p.parquet", index=False)
        K = pd.DataFrame({"symbol": ["AAA", "BBB", "AAA"],
                          "sday": pd.to_datetime(["2023-01-03", "2023-01-02", "2023-01-05"])})
        v, found = SK.read_panel(Path(t) / "p.parquet", ["d_feat_one", "W_TWO"], K)
    check("t5a panel reader: the row of T0 (zoned stamps -> IST dates, names and symbols in any case), blank where "
          "there is no row", close(v, [[2.0, 6.0], [3.0, 7.0], [np.nan, np.nan]]) and abs(found - 2 / 3) < 1e-12,
          (v, found))
    rng = np.random.default_rng(1)
    n = 300
    X = pd.DataFrame({d: rng.integers(-1, 3, n).astype(np.int8) for d in SL.ZDIM})
    X["a"] = rng.normal(size=n)
    X["b"] = np.where(np.arange(n) < 30, 1.0, np.nan)
    X["Tm1_type"] = rng.choice(list(SK.TYPES) + [""], n)
    X["T0_type"] = rng.choice(list(SK.TYPES), n)
    X["in_both"] = rng.random(n) < 0.5
    train = np.arange(n) < 200
    dims, B = SK.make_dims(SL, X, ["a", "b"], train)
    X2 = X.copy()
    X2.loc[~train, "a"] = X2.loc[~train, "a"] * 50
    dims2, _ = SK.make_dims(SL, X2, ["a", "b"], train)
    e = np.quantile(X.loc[train, "a"], [0.25, 0.5, 0.75])
    da = [d for d in dims if d["name"] == "a"][0]
    ty = B["Tm1_is_RANGE"]
    tyw = np.where(X["Tm1_type"] == "", -1, (X["Tm1_type"] == "RANGE").astype(int))
    check("t5b buckets: quarters at the discovery quartiles only (later values change nothing), a measure with under 40 "
          "values is no measure, zones keep their own buckets, day types yes / no with unknown blank",
          close(da["edges"], e) and [d["edges"] for d in dims2 if d["name"] == "a"][0] == da["edges"] and
          not any(d["name"] == "b" for d in dims) and (B["b"] == -1).all() and np.array_equal(B["ATRP"], X["ATRP"]) and
          np.array_equal(ty, tyw) and len(dims) == 12 + 1 + 20 + 1, [d["name"] for d in dims][:5])
    days = np.array(pd.bdate_range("2023-01-02", periods=60), dtype="datetime64[D]")
    boot = SL.Boot(days)
    di = np.arange(60)
    vals = rng.normal(size=60)
    m1, m2 = vals > 0, vals <= 0
    R = SK.boot_means(boot, di, vals, [m1, m2])
    b0 = boot.ix[7]
    w1 = np.mean(np.concatenate([vals[[d]] for d in b0 if m1[d]]))
    check("t5c bootstrap means: resample 7 by hand equals the matrix route; AUC by hand with ties",
          abs(R[7, 0] - w1) < 1e-12 and abs(SK.auc(np.r_[np.arange(20.0), [5.0]], np.r_[np.arange(20.0) + 10, [5.0]]) -
                                           (sum((a > b) + 0.5 * (a == b) for a in np.r_[np.arange(20.0), [5.0]]
                                                for b in np.r_[np.arange(20.0) + 10, [5.0]]) / 441)) < 1e-12,
          (R[7, 0], w1))


# ---------------------------------------------------------------------------------------------------- the world
def make_world(root: Path, plant: bool, seed: int, n_stocks: int = 24):
    """Daily + 3-minute bars (one generator: the daily bar is the 3-minute bars' own OHLCV), indices, a panel, the
    TREE and TAGS runs. plant: a picked stock-day whose last hour rose in the top quarter gets +1% at each of the
    D2-D5 opens."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2020-11-02", "2025-06-30")
    cal = cal[~((cal.month == 1) & (cal.day == 26))]
    n = len(cal)
    syms = [f"S{i:02d}" for i in range(n_stocks)] + ["GOLDBEES"]
    W.write_mods(root)
    W.use_mods(root)
    (root / "intraday_3m").mkdir(parents=True, exist_ok=True)
    offs = pd.to_timedelta(9 * 60 + 15 + 3 * np.arange(N3), unit="m")
    rel = {}
    for s in syms:
        sig = rng.uniform(0.012, 0.035) if s != "GOLDBEES" else 0.006
        st = rng.normal(0, sig / np.sqrt(N3) / 2, (n, N3, 4)).reshape(n, -1).cumsum(1).reshape(n, N3, 4)
        bc = st[:, :, -1]
        bo = np.concatenate([np.zeros((n, 1)), bc[:, :-1]], 1)
        bh = np.maximum(bo, st.max(2))
        bl = np.minimum(bo, st.min(2))
        lo = np.log(100) + np.cumsum(rng.normal(0, 0.4 * sig, n) + np.r_[0, bc[:-1, -1]])
        vol = rng.lognormal(8, 0.5, (n, N3)) * (1 + 1.5 * np.exp(-np.arange(N3) / 10) + np.exp((np.arange(N3) - 124) / 10))
        rel[s] = [lo, bo, bh, bl, bc, vol, np.ones(n)]
    # picks
    t_first = int(np.searchsorted(cal, pd.Timestamp("2021-09-20")))
    picks = []
    for t in range(t_first, n - 8):
        d = rng.choice(n_stocks, 5, replace=False)
        others = [i for i in range(n_stocks) if i not in d]
        e = list(rng.permutation(d)[:3]) + list(rng.choice(others, 2, replace=False))
        dl = [syms[i] for i in d]
        if rng.random() < 0.05:
            dl[4] = "GOLDBEES"
        for eng, lst in (("D", dl), ("ENS", [syms[i] for i in e])):
            for r, s in enumerate(lst, 1):
                picks.append((eng, r, s, t))
    sd_ = sorted({(s, t) for _, _, s, t in picks})
    if plant:                                              # decided on the 3-minute shape, in % (before any scaling)
        lh = np.array([rel[s][4][t, -1] - rel[s][4][t, 104] for s, t in sd_])
        cut = np.quantile(lh, 0.75)
        for (s, t), x in zip(sd_, lh):
            if x > cut:
                for k in range(2, 6):
                    rel[s][6][t + k:] *= 1.01
    daily = {}
    for s in syms:
        lo, bo, bh, bl, bc, vol, sc = rel[s]
        base = np.exp(lo)[:, None] * sc[:, None]
        O3, H3, L3, C3 = (base * np.exp(x) for x in (bo, bh, bl, bc))
        daily[s] = pd.DataFrame({"open": O3[:, 0], "high": H3.max(1), "low": L3.min(1), "close": C3[:, -1],
                                 "volume": vol.sum(1)})
        out = daily[s].copy()
        out.insert(0, "timestamp", cal.tz_localize(IST))
        out.to_parquet(root / f"{s}_daily.parquet", index=False)
        keep = np.ones((n, N3), bool)
        keep[rng.random(n) < 0.02, 0] = False                  # no 09:15 bar: unusable
        mid = rng.random(n) < 0.05
        keep[mid, rng.integers(20, 100, mid.sum())] = False      # one missing bar: carried
        ts = (cal.values[:, None] + offs.values[None, :])[keep]
        pd.DataFrame({"timestamp": pd.DatetimeIndex(ts).tz_localize(IST), "open": O3[keep], "high": H3[keep],
                      "low": L3[keep], "close": C3[keep], "volume": vol[keep]}).to_parquet(
            root / "intraday_3m" / f"{s}_3m.parquet", index=False)
    for nm, sg, p0 in (("NIFTY50", 0.009, 18000), ("NIFTYMIDCAP150", 0.011, 12000), ("NIFTYSMLCAP250", 0.013, 9000),
                       ("INDIAVIX", 0.05, 16)):
        c = p0 * np.exp(np.cumsum(rng.normal(0, sg, n)))
        o = np.r_[p0, c[:-1]] * np.exp(rng.normal(0, sg / 3, n))
        if nm == "NIFTYSMLCAP250":
            o[rng.random(n) < 0.01] = np.nan
        pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": o, "high": np.fmax(o, c) * 1.004,
                      "low": np.fmin(o, c) * 0.996, "close": c, "volume": 1e6}).to_parquet(
            root / f"{nm}_daily.parquet", index=False)
    # panel: the 60 features, random, one row a stock-day
    feats, _ = SK.features_final(SL)
    (root / "panel").mkdir(exist_ok=True)
    P = pd.DataFrame({"symbol": np.repeat(syms, n), "timestamp": np.tile(cal.tz_localize(IST), len(syms))})
    for f in feats:
        P[f] = rng.normal(size=len(P)).astype(np.float32)
    P.to_parquet(root / "panel" / "panel.parquet", index=False)
    # the tree run: every pick, lane from the simple ATR, a setup on 40% of the jumpy stock-days
    look = {}
    for s, t in sd_:
        D = daily[s]
        atr = SL.atr_simple(D["high"].to_numpy(), D["low"].to_numpy(), D["close"].to_numpy())[t]
        jumpy = atr > 0.045
        caught = jumpy and rng.random() < 0.4
        o1, c5 = D["open"].iat[t + 1], D["close"].iat[t + 5]
        look[(s, t)] = {"s_atr14": atr, "lane": "JUMPY" if jumpy else "CALM",
                        "first_setup": "S2@D2" if caught else "",
                        "setup_net": (c5 / D["open"].iat[t + 2] - 1) * 100 - 0.35 if caught else np.nan,
                        "d1_net": (c5 / o1 - 1) * 100 - 0.35}
    rows = []
    for eng, r, s, t in picks:
        x = look[(s, t)]
        rows.append({"trade_id": f"{eng}-{cal[t]:%Y%m%d}-{r}", "engine": eng, "rank": r, "symbol": s,
                     "signal_day": f"{cal[t]:%Y-%m-%d}", "s_atr14": x["s_atr14"], "cutoff": 0.045, "lane": x["lane"],
                     "etf": s == "GOLDBEES", "gap_pct": 0.0, "opened_up": True, "dip_2pct": False, "runner": False,
                     "first_setup": x["first_setup"], "setup_net": x["setup_net"], "bunch": "", "d1_net": x["d1_net"],
                     "action": "", "how": "", "in_book_start1": False, "complete": True})
    sbase = root / "setuplab_out"
    tr = SL.new_run_dir(sbase / "TREE", "TREE")
    pd.DataFrame(rows).to_parquet(tr / "tree_tags.parquet", index=False)
    (tr / "TREE_RUN.json").write_text(json.dumps({"version": "setuplab v1.1", "frozen_sha256": "f" * 64}), encoding="utf-8")
    SL.write_hashes(tr, ["tree_tags.parquet", "TREE_RUN.json"])
    tg = SL.new_run_dir(sbase / "TAGS", "TAGS")
    pd.DataFrame({"trade_id": [r_["trade_id"] for r_ in rows]}).to_parquet(tg / "setup_tags.parquet", index=False)
    (tg / "TAGS.json").write_text(json.dumps({"version": "setuplab v1.1", "frozen_sha256": "f" * 64,
                                              "panel": str(root / "panel" / "panel.parquet"),
                                              "watchlist": str(root / "wl" / "watchlist.parquet"),
                                              "setups": [{"id": s_, "primary_exit": "original_d5"} for s_ in
                                                         ("S1", "S2", "S3", "C1", "C2", "C3", "N1")]}), encoding="utf-8")
    SL.write_hashes(tg, ["setup_tags.parquet", "TAGS.json"])
    return {"root": root, "sbase": sbase, "cal": cal, "daily": daily, "tree": pd.DataFrame(rows), "feats": feats}


def run(w, out, extra=()):
    rc, log = quiet(SK.main, ["run", "--root", str(w["root"]), "--setups", str(w["sbase"]), "--out", str(out),
                              "--stage-e-any"] + list(extra))
    runs = sorted((Path(out) / "runs").glob("SK_*")) if (Path(out) / "runs").exists() else []
    return rc, log, (runs[-1] if runs else None)


def t6_planted():
    tmp = Path(tempfile.mkdtemp(prefix="skiplab_planted_"))
    try:
        w = make_world(tmp / "cache", True, seed=11)
        out = tmp / "out"
        rc, log, run_ = run(w, out)
        check("t6a the planted world runs (exit 0, a run folder, RESULT)", rc == 0 and run_ is not None and
              "RESULT:" in log, log[-1500:])
        if run_ is None:
            return
        rj = json.loads((run_ / "run.json").read_text(encoding="utf-8"))
        rep = (run_ / "REPORT.md").read_text(encoding="utf-8")
        F = rj["filters"]
        hit = [f for f in F if f["final"] == "REPEATABLE" and "T0_last_hour" in f["text"]]
        check("t6b the planted look (a strong T0 last hour) is found on 2021-2023 and holds on 2024 onward: REPEATABLE",
              len(hit) >= 1, [(f["text"], f["final"], f.get("diff_lo"), f.get("chk_lo")) for f in F])
        M = pd.read_csv(run_ / "measures.csv")
        lh = M[M["measure"] == "T0_last_hour"].iloc[0]
        check("t6c the atlas lists T0_last_hour as a repeatable association (higher is better, both periods)",
              lh["repeatable_association"] == "higher is better", lh.to_dict())
        d = rj["data"]
        check("t6d data checks: the tree's D1 net equals the bars on every stock-day, the panel row found for all, most "
              "sessions usable, the ETF and the index-open fallback seen",
              d["chk_same"] == d["chk_n"] > 1000 and d["panel_found"] == 1.0 and 0.9 < d["usable_T0"] < 1 and
              d["etf"] > 0 and d["index_open_fallback"] > 0, d)
        X = pd.read_parquet(run_ / "picks.parquet")
        bad = []
        P = pd.read_parquet(w["root"] / "panel" / "panel.parquet", columns=["symbol", "timestamp", w["feats"][5]])
        P["day"] = P["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).dt.normalize()
        IX = pd.read_parquet(w["root"] / "NIFTYSMLCAP250_daily.parquet")
        for q in np.random.default_rng(2).choice(np.flatnonzero(X["period"].ne("").to_numpy()), 6, replace=False):
            r = X.iloc[q]
            D = w["daily"][r["symbol"]]
            t = int(np.flatnonzero(w["cal"] == pd.Timestamp(r["sday"]))[0])
            atr = SL.atr_simple(D["high"].to_numpy(), D["low"].to_numpy(), D["close"].to_numpy())[t] * D["close"].iat[t]
            want_clv = (D["close"].iat[t - 1] - D["low"].iat[t - 1]) / (D["high"].iat[t - 1] - D["low"].iat[t - 1])
            o1 = D["open"].iat[t + 1]
            pv = P[(P["symbol"] == r["symbol"]) & (P["day"] == pd.Timestamp(r["sday"]))][w["feats"][5]].iat[0]
            io1 = IX["open"].iat[t + 1] if np.isfinite(IX["open"].iat[t + 1]) else IX["close"].iat[t]
            got = (r["Tm1_clv"], r["T0_oc"], r["mfe"], r[w["feats"][5]], r["d1_net"], r["excess"])
            want = (want_clv, (D["close"].iat[t] - D["open"].iat[t]) / atr, D["high"].iloc[t + 1:t + 6].max() / o1 - 1,
                    float(pv), (D["close"].iat[t + 5] / o1 - 1) * 100 - 0.35,
                    (D["close"].iat[t + 5] / o1 - IX["close"].iat[t + 5] / io1) * 100)
            if not close(got, want, 1e-6):
                bad.append((r["symbol"], str(r["sday"]), got, want))
        check("t6e six stock-days by hand from the world's own bars and panel (T-1 close location, T0 open-to-close, "
              "MFE, a panel feature, the D1 net, the excess over Smallcap 250's own open and close)", not bad, bad)
        ps = [f["p"] for f in F]
        order = sorted(range(len(F)), key=lambda i: (ps[i], i))
        going, want_final = True, {}
        for k, i in enumerate(order):
            keep = going and ps[i] <= 0.025 / (len(F) - k)
            going = keep
            hold = F[i]["diff_lo"] > 0 and F[i]["chk_lo"] > 0
            want_final[i] = "REPEATABLE" if keep and hold else "NOT REPEATABLE"
        cnt_ok = all(int((X[f"in_filter_{f['rank']}"] & (X["period"] == "discovery") & (X["group"] == "N")).sum()) ==
                     f["train_n"] and int((X[f"in_filter_{f['rank']}"] & (X["period"] == "test") &
                                           (X["group"] == "N")).sum()) == f["n"] for f in F)
        check("t6k each filter's discovery picks are the never-caught picks of Oct 2021-2023 inside it, and its test "
              "picks those of 2024 onward (counted from picks.parquet)", cnt_ok,
              [(f["train_n"], f["n"]) for f in F])
        check("t6j Holm by hand on the 5 filters' p-values (step-down at 0.025, both intervals above 0)",
              all(F[i]["final"] == want_final[i] for i in range(len(F))) and
              sorted(round(f["holm_limit"], 6) for f in F) == sorted(round(0.025 / k, 6) for k in range(1, 6)),
              [(f["p"], f["holm_limit"], f["final"]) for f in F])
        T = w["tree"]
        T = T.assign(sday=pd.to_datetime(T["signal_day"]))
        tr_ = pd.read_csv(run_ / "tradability.csv")
        okt = True
        for f in F:
            col = f"in_filter_{f['rank']}"
            key = X[["symbol", "sday", col, "period"]]
            J = T[(T["rank"] <= 3) & T["lane"].eq("JUMPY") & ~T["etf"]].merge(key, on=["symbol", "sday"])
            J = J[(J["period"] == "test") & J[col] & (J["first_setup"].eq("") | J["setup_net"].notna())]
            for eng in ("D", "ENS"):
                got = tr_[(tr_["filter"] == f["rank"]) & (tr_["engine"] == eng)]["picks"]
                okt &= len(got) == 1 and int(got.iat[0]) == int((J["engine"] == eng).sum())
        check("t6f tradability: each filter's picks per engine = every jumpy ranks 1-3 test pick inside it (caught or "
              "not), counted independently from the tree file", okt, tr_.head(10).to_dict("list"))
        hs = {ln.split("  ")[1].strip(): ln.split("  ")[0] for ln in (run_ / "outputs.sha256").read_text().splitlines()}
        allok = all(hashlib.sha256((run_ / k).read_bytes()).hexdigest() == v for k, v in hs.items())
        led = [json.loads(x) for x in (out / SK.LEDGER).read_text(encoding="utf-8").splitlines()]
        check("t6g outputs hashed and matching; the ledger line; REPORT leads with the verdict and lists the filters",
              allok and len(hs) == 11 and len(led) == 1 and led[0]["run"] == run_.name and
              rep.split("## ")[1].startswith("Verdict first") and "REPEATABLE" in rep, (len(hs), led))
        rc2, log2, _ = run(w, out)
        rc3, log3, run3 = run(w, out, ["--rerun-reason", "test: a verified bug"])
        led = [json.loads(x) for x in (out / SK.LEDGER).read_text(encoding="utf-8").splitlines()]
        check("t6h a second run is refused without --rerun-reason, and runs (recorded) with one",
              rc2 == 2 and "already ran" in log2 and rc3 == 0 and run3 != run_ and len(led) == 2 and
              led[1]["rerun_reason"] == "test: a verified bug", log2[-300:])
        # no look-ahead: every bar after T0 of one stock changed -> its T-1 / T0 measures do not move
        s = X[X["period"] == "test"]["symbol"].iat[0]
        rows = X[X["symbol"] == s].sort_values("sday")
        r0 = rows.iloc[len(rows) // 2]
        t = int(np.flatnonzero(w["cal"] == pd.Timestamp(r0["sday"]))[0])
        root = w["root"]
        D = pd.read_parquet(root / f"{s}_daily.parquet")
        I3 = pd.read_parquet(root / "intraday_3m" / f"{s}_3m.parquet")
        cut = w["cal"][t + 1].tz_localize(IST)
        fd = 1 + 0.2 * np.sin(np.arange(len(D)))                 # a different factor every later session
        later = (D["timestamp"] >= cut).to_numpy()
        D.loc[later, ["open", "high", "low", "close"]] = D.loc[later, ["open", "high", "low", "close"]].mul(
            fd[later], axis=0)
        f3 = pd.Series(fd, index=D["timestamp"].dt.normalize()).reindex(I3["timestamp"].dt.normalize()).to_numpy()
        l3 = (I3["timestamp"] >= cut).to_numpy()
        I3.loc[l3, ["open", "high", "low", "close"]] = I3.loc[l3, ["open", "high", "low", "close"]].mul(f3[l3], axis=0)
        D.to_parquet(root / f"{s}_daily.parquet", index=False)
        I3.to_parquet(root / "intraday_3m" / f"{s}_3m.parquet", index=False)
        mk = TD.Market(root, TD.Production(stage_e_any=True))
        U1 = X[(X["symbol"] == s) & (X["sday"] == r0["sday"])][["symbol", "sday"]].reset_index(drop=True)
        Xb, _ = SK.build(SL, JL, mk, U1, log=lambda m_: None)
        cols = [c for c in Xb.columns if c.startswith(("Tm1_", "T0_", "x_", "z_")) or c in SK.DAILY or c in SL.ZDIM]
        cols = [c for c in cols if not c.endswith(("_type", "_usable"))]
        moved = [c for c in cols if not close([Xb[c].iat[0]], [r0[c]], 1e-9)]
        check("t6i no look-ahead: every session after T0 rescaled by its own factor leaves all T-1 / T0 / daily / zone "
              "measures as they were, and the outcome moves", not moved and
              not close([Xb["mfe"].iat[0]], [r0["mfe"]], 1e-9), (moved, Xb["mfe"].iat[0], r0["mfe"]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t7_absent():
    tmp = Path(tempfile.mkdtemp(prefix="skiplab_absent_"))
    try:
        w = make_world(tmp / "cache", False, seed=12)
        rc, log, run_ = run(w, tmp / "out")
        rj = json.loads((run_ / "run.json").read_text(encoding="utf-8")) if run_ else {"filters": []}
        F = rj["filters"]
        check("t7a absent world: 5 filters chosen and none REPEATABLE", rc == 0 and len(F) == 5 and
              not any(f["final"] == "REPEATABLE" for f in F),
              [(f["text"], f["final"], f.get("diff_lo"), f.get("chk_lo")) for f in F] or log[-800:])
        M = pd.read_csv(run_ / "measures.csv") if run_ else pd.DataFrame()
        check("t7b absent world: T0_last_hour is no repeatable association (nothing planted)",
              len(M) and M[M["measure"] == "T0_last_hour"]["repeatable_association"].fillna("").iat[0] == "",
              M[M["measure"] == "T0_last_hour"].to_dict("records") if len(M) else None)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------------------------------------------- 8-9 SK2 (book)
BFEATS = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_bb_bw_20", "d_wq_44",
          "d_bb_pctb_20", "d_atr_pct"]


def make_book_world(root: Path, seed: int = 5, pick_share: float = 1.0) -> dict:
    """setuplab's research layout: a calendar to June 2025 with a few Monday holidays, 40 stocks + GOLDBEES, a panel
    with the frozen setups' features, D and ENS picks of ranks 1-3 on a share of the sessions (s_atr14 one per
    stock-day)."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-07-01", "2025-06-30")
    cal = cal[~((cal.weekday == 0) & (cal.day <= 7) & np.isin(cal.month, [1, 4, 7, 10]))]
    syms = [f"S{i:03d}" for i in range(40)] + ["GOLDBEES"]
    n = len(cal)
    bars, rows, atr = {}, [], {}
    for s in syms:
        c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
        o = np.r_[c[0], c[:-1]] * np.exp(rng.normal(0, 0.008, n))
        bars[s] = (o, c)
        atr[s] = (np.exp(rng.normal(np.log(0.05), 0.35, n)) if s != "GOLDBEES" else      # the ETF jumpy, from its
                  np.exp(np.random.default_rng(seed + 1).normal(np.log(0.09), 0.35, n)))    # own draws
        f = {"symbol": s, "timestamp": cal, "w_ret_13w": np.cumsum(rng.normal(0, 1, n)).astype(np.float32)}
        for x in BFEATS:
            f[x] = np.cumsum(rng.normal(0, 1, n)) if x != "d_atr_pct" else np.abs(rng.normal(3, 1, n))
        f["d_bb_pctb_20"] = rng.normal(0.4, 0.5, n)
        rows.append(pd.DataFrame(f))
    (root / "panel").mkdir(parents=True, exist_ok=True)
    pd.concat(rows, ignore_index=True).to_parquet(root / "panel" / "panel.parquet", index=False)
    picks = []
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-02")))
    for t in range(t0, n - 12):
        if rng.random() >= pick_share:
            continue
        for eng in ("D", "ENS"):
            for r, si in enumerate(rng.choice(len(syms), 3, replace=False), 1):
                s = syms[si]
                o, c = bars[s]
                ent = o[t + 1]
                rec = {"trade_id": f"{eng}-{cal[t]:%Y%m%d}-{r}", "engine": eng, "rank": r, "symbol": s,
                       "signal_day": cal[t], "entry_day": cal[t + 1], "entry": ent, "signal_close": c[t],
                       "status": "ok", "net_bp": (c[t + 5] / ent - 1) * 1e4 - 35, "s_atr14": float(atr[s][t]),
                       "pre_state": ""}
                for k in range(1, 11):
                    rec[f"close_{k}"] = c[t + k] / ent - 1
                for k in range(2, 11):
                    rec[f"overnight_{k}"] = o[t + k] / c[t + k - 1] - 1
                picks.append(rec)
    return {"cal": cal, "wl": pd.DataFrame(picks), "root": root}


def book_setuplab(Wb, tmp: Path):
    """The world's watchlist and setuplab's own tag and tree commands (a test TREE.json with 2020-2024 cut-offs)."""
    wl_dir, out = tmp / "WL", tmp / "setuplab_out"
    wl_dir.mkdir(parents=True, exist_ok=True)
    Wb["wl"].to_parquet(wl_dir / "watchlist.parquet", index=False)
    pd.DataFrame({"date": Wb["cal"]}).to_parquet(wl_dir / "calendar.parquet", index=False)
    _, d = SL.load_tree()
    d = json.loads(json.dumps(d))
    d.pop("sha256", None)
    d.pop("history_reference", None)
    d["lane"]["cutoffs"] = {str(y): 0.057 for y in range(2020, 2025)}
    d["sha256"] = SL.frozen_hash(d)
    tdoc = tmp / "TREE_test.json"
    tdoc.write_text(json.dumps(d), encoding="utf-8")
    rc1, l1 = quiet(SL.main, ["tag", "--data", str(wl_dir), "--features", str(Wb["root"] / "panel" / "panel.parquet"),
                              "--out", str(out)])
    rc2, l2 = quiet(SL.main, ["tree", "--data", str(wl_dir), "--out", str(out), "--tree", str(tdoc), "--reruns", "2"])
    return wl_dir, out, rc1, rc2, l1 + l2


def fake_sk1(out: Path, trinfo: dict, X: pd.DataFrame, filters: list, decl_sha: str = None) -> Path:
    """An SK1 run folder as skiplab's run command writes it (picks.parquet: symbol, sday, in_filter_<k>; run.json;
    outputs.sha256) with the marks given."""
    run = SL.new_run_dir(out / "runs", "SK")
    X.to_parquet(run / "picks.parquet", index=False)
    rj = {"tool": "skiplab v1.0", "declaration_sha256": decl_sha or SK.DECL_SHA, "tree_run": trinfo["run"],
          "tree_sha256": trinfo["sha256"], "filters": filters}
    (run / "run.json").write_text(json.dumps(rj), encoding="utf-8")
    SL.write_hashes(run, ["picks.parquet", "run.json"])
    return run


def oracle_book(trades: pd.DataFrame, wl: pd.DataFrame, cal, s0: int, t1: int, k: int = 3):
    """An independent k-place book from the watchlist's own paths: each buy 1/k of the closed value at its entry open
    (the same open: rank, symbol, trade id), full = skipped, an exit at the close frees the place from the next open;
    marked at each close with close_k / the entry open. -> (closed, marked, taken trade ids in order)."""
    W_ = wl.set_index("trade_id")
    pos_of = {d: i for i, d in enumerate(pd.DatetimeIndex(cal))}
    tr = trades[(trades["ent"] >= s0) & (trades["ent"] <= t1)].copy()
    tr["trade_id"] = tr["trade_id"].astype(str)
    tr = tr.sort_values(["ent", "rank", "symbol", "trade_id"])
    cash, pos, took, eqc, eqm = 1.0, [], [], [], []
    for t in range(s0, t1 + 1):
        for r in tr[tr["ent"] == t].itertuples(index=False):
            if len(pos) < k:
                size = (cash + sum(p["size"] for p in pos)) / k
                w = W_.loc[r.trade_id]
                ek = int(r.ek)
                o_rel = 1.0 if ek == 1 else (1 + w[f"close_{ek - 1}"]) * (1 + w[f"overnight_{ek}"])
                pos.append({"ex": int(r.ex), "size": size, "pnl": size * float(r.net) / 100, "w": w, "o_rel": o_rel,
                            "i1": pos_of[pd.Timestamp(w["entry_day"])]})
                cash -= size
                took.append(r.trade_id)
        keep = []
        for p in pos:
            if p["ex"] <= t:
                cash += p["size"] + p["pnl"]
            else:
                keep.append(p)
        pos = keep
        eqc.append(cash + sum(p["size"] for p in pos))
        mk = cash
        for p in pos:
            kk = t - p["i1"] + 1
            mk += p["size"] * (1 + p["w"][f"close_{kk}"]) / p["o_rel"] if 1 <= kk <= 10 else p["size"]
        eqm.append(mk)
    return np.array(eqc), np.array(eqm), took


def t8_book():
    tmp = Path(tempfile.mkdtemp(prefix="skiplab_sk2_"))
    try:
        Wb = make_book_world(tmp, 5, pick_share=0.35)
        wl_dir, sout, rc1, rc2, log = book_setuplab(Wb, tmp)
        check("t8a setuplab's own tag and tree commands ran on the world", rc1 == 0 and rc2 == 0, log[-600:])
        tree, trinfo = SU.load_tree(sout, need=True)
        wl = Wb["wl"].assign(trade_id=Wb["wl"]["trade_id"].astype(str))
        tags = pd.read_parquet(Path(trinfo["folder"]) / "tree_tags.parquet")
        tags["trade_id"] = tags["trade_id"].astype(str)
        tags = tags.merge(wl[["trade_id", "entry_day", "signal_day"]].rename(columns={"signal_day": "sd"}),
                          on="trade_id")
        # the marks, one per stock-day: planted (#1), random (#2), calm only (#3), planted but NOT REPEATABLE (#4)
        U = wl.drop_duplicates(["symbol", "signal_day"])[["symbol", "signal_day", "close_1", "close_5"]]
        start = Wb["cal"][Wb["cal"] >= "2024-01-01"][0]
        lanes = tags.groupby(["symbol", "sd"])["lane"].agg(lambda s: set(s)).rename("lanes").reset_index()
        U = U.merge(lanes, left_on=["symbol", "signal_day"], right_on=["symbol", "sd"], how="left")
        up = (U["close_1"].to_numpy() > 0) & (U["close_5"].to_numpy() > 0.02)
        rng = np.random.default_rng(23)
        calm_only = U["lanes"].apply(lambda s: isinstance(s, set) and s == {"CALM"}).to_numpy()
        X = pd.DataFrame({"symbol": U["symbol"].to_numpy(),
                          "sday": pd.to_datetime(U["signal_day"]).astype("datetime64[ns]").to_numpy(),
                          "in_filter_1": up, "in_filter_2": rng.random(len(U)) < 0.3,
                          "in_filter_3": calm_only & (rng.random(len(U)) < 0.5), "in_filter_4": up})
        filters = [{"rank": 1, "text": "planted", "final": "REPEATABLE"},
                   {"rank": 2, "text": "random", "final": "REPEATABLE"},
                   {"rank": 3, "text": "calm only", "final": "REPEATABLE"},
                   {"rank": 4, "text": "planted, not repeatable", "final": "NOT REPEATABLE"}]
        bout = tmp / "skiplab_out"
        sk1 = fake_sk1(bout, trinfo, X, filters)
        rc, out = quiet(SK.main, ["book", "--setups", str(sout), "--out", str(bout)])
        runs = sorted((bout / "books").glob("SK2_*")) if (bout / "books").is_dir() else []
        check("t8b 'book' ran on genuine setuplab TAGS / TREE runs and a SK1 run", rc == 0 and len(runs) == 1,
              out[-1500:])
        if not runs:
            return
        run = runs[-1]
        rj = json.loads((run / "run.json").read_text(encoding="utf-8"))
        rec = rj["reconcile"]
        check("t8c the tree rebuilt with setuplab's functions: every pick as the tree run tagged it, and exactly the "
              "tree run's trades (D and ENS)", all(rec[b]["same"] and rec[b]["rebuilt"] == rec[b]["tree_run"] > 100
                                                   for b in ("picks", "D tree", "ENS tree")), rec)
        R = {(r["part"], r["filter"], r["engine"]): r for r in rj["rows"]}
        check("t8d per REPEATABLE filter and engine one pocket and one shared comparison; the NOT REPEATABLE one is "
              "not tested", sorted(R) == sorted((p_, f, e) for p_ in ("pocket", "shared") for f in (1, 2, 3)
                                                for e in ("D", "ENS")), sorted(R))
        # by hand, from the tree run's own tags: the marked jumpy picks and what the tree did with each
        mk = X.set_index(["symbol", "sday"])

        def marked(f, e):
            m = tags[(tags["engine"] == e) & (tags["rank"] <= 3) & tags["complete"].astype(bool) &
                     tags["lane"].isin(["JUMPY", "NO ATR"]) & ~tags["etf"].astype(bool) &
                     (pd.to_datetime(tags["entry_day"]) >= start)]
            if f == 0:
                return m
            key = list(zip(m["symbol"], pd.to_datetime(m["sd"]).astype("datetime64[ns]")))
            return m[mk.reindex(key)[f"in_filter_{f}"].fillna(False).astype(bool).to_numpy()]
        okc = {}
        for (p_, f, e), r in R.items():
            m = marked(f, e)
            how = m["how"].fillna("").astype(str)
            if p_ == "shared":
                hand = {"picks": len(m), "kept": int(how.str.endswith("@D1").sum()),
                        "moved": int(((how != "") & ~how.str.endswith("@D1")).sum()), "added": int((how == "").sum())}
            else:
                hand = {"picks": len(m)}
            okc[(p_, f, e)] = all(r[x] == hand[x] for x in hand), hand, {x: r[x] for x in hand}
        check("t8e the marked jumpy picks by hand (the tree run's tags): pocket picks; shared: added (tree skipped), "
              "moved to D1 (setup later), left to the tree (setup on D1)",
              all(v[0] for v in okc.values()) and R[("shared", 1, "D")]["added"] > 5 and
              R[("shared", 1, "D")]["moved"] + R[("shared", 1, "ENS")]["moved"] > 0 and
              R[("pocket", 3, "D")]["picks"] == R[("shared", 3, "ENS")]["picks"] == 0,
              {k: v[1:] for k, v in okc.items() if not v[0]} or {k: v[1] for k, v in okc.items()})
        # by hand: every book with an independent simulator on the watchlist's own paths
        T = quiet(SK.tree_inputs, SL, sout, lambda *a: None)[0]
        book = T["book"]
        s0, t1 = int(np.searchsorted(book.cal, np.datetime64(start))), T["t1"]
        D = pd.read_csv(run / "daily.csv")
        Tr = pd.read_csv(run / "trades.csv", dtype={"trade_id": str})
        wli = wl.set_index("trade_id")
        pos_of = {d: i for i, d in enumerate(pd.DatetimeIndex(Wb["cal"]))}

        def d1(ids):
            B = pd.DataFrame({"trade_id": list(ids), "ent": [pos_of[pd.Timestamp(wli.at[i, "entry_day"])] for i in ids],
                              "ek": 1, "net": [wli.at[i, "close_5"] * 100 - 0.35 for i in ids],
                              "rank": [int(wli.at[i, "rank"]) for i in ids],
                              "symbol": [wli.at[i, "symbol"] for i in ids]})
            B["ex"] = B["ent"] + 4
            return B

        yrs = float((book.cal[t1] - book.cal[s0]) / np.timedelta64(1, "D")) / 365.25
        bt = SL.Boot(np.asarray(book.cal[s0:t1 + 1]).astype("datetime64[D]"))

        def rule(cA, mA, cB, mB):
            ra = lambda q: q / np.r_[1.0, q[:-1]] - 1      # noqa: E731
            d = (ra(mB) - ra(mA)) * 1e4
            ay = lambda q: (q[-1] ** (1 / yrs) - 1) * 100   # noqa: E731
            fl = lambda q: 100 * np.max(1 - q / np.maximum.accumulate(q))   # noqa: E731
            Rb = (bt.M @ d) / bt.M.sum(1)
            return (d.mean(), np.percentile(Rb, 2.5), np.percentile(Rb, 97.5), (1 + np.sum(Rb <= 0)) / (len(Rb) + 1),
                    ay(cB), ay(cA), fl(mB), fl(mA))

        bad, hand_rule, hand_itf = [], {}, {}
        for e in ("D", "ENS"):
            T_ = T["books"][f"{e} tree"][0]
            c0, m0, k0 = oracle_book(T_, wl, Wb["cal"], s0, t1)
            if not (close(m0, D[f"{e} tree"].to_numpy(), 1e-6) and
                    set(k0) == set(Tr.loc[Tr["book"] == f"{e} tree", "trade_id"])):
                bad.append(f"{e} tree")
            cv, mv, kv = oracle_book(d1(marked(0, e)["trade_id"]), wl, Wb["cal"], s0, t1)
            if not (close(mv, D[f"{e} everything pocket"].to_numpy(), 1e-6) and
                    set(kv) == set(Tr.loc[Tr["book"] == f"{e} everything pocket", "trade_id"])):
                bad.append(f"{e} everything pocket")
            n = np.zeros(t1 - s0 + 1)
            for i in k0:
                a = T_.loc[T_["trade_id"].astype(str) == i, ["ent", "ex"]].iloc[0]
                n[a["ent"] - s0: min(a["ex"], t1) - s0 + 1] += 1
            busy = float((n >= 3).mean())
            for f in (1, 2, 3):
                m = marked(f, e)
                cq, mq, kq = oracle_book(d1(m["trade_id"]), wl, Wb["cal"], s0, t1)
                col = f"{e} pocket SK#{f}"
                if not (close(mq, D[col].to_numpy(), 1e-6) and set(kq) == set(Tr.loc[Tr["book"] == col, "trade_id"])):
                    bad.append(col)
                hand_rule[("pocket", f, e)] = rule(cv, mv, cq, mq)
                hand_itf[("pocket", f, e)] = (len(kq), len(m) - len(kq), len(set(kq) & set(k0)))
                how = m["how"].fillna("").astype(str)
                swap = m[~how.str.endswith("@D1")]["trade_id"].tolist()
                T2 = pd.concat([T_[~T_["trade_id"].astype(str).isin(swap)][["trade_id", "ent", "ek", "net", "rank",
                                                                            "symbol", "ex"]], d1(swap)],
                               ignore_index=True)
                c1, m1, k1 = oracle_book(T2, wl, Wb["cal"], s0, t1)
                col = f"{e} tree + SK#{f}"
                if not (close(m1, D[col].to_numpy(), 1e-6) and set(k1) == set(Tr.loc[Tr["book"] == col, "trade_id"])):
                    bad.append(col)
                hand_rule[("shared", f, e)] = rule(c0, m0, c1, m1)
                sw = set(swap)
                hand_itf[("shared", f, e)] = (len((set(k0) - sw) - (set(k1) - sw)), len((set(k1) - sw) - set(k0)),
                                              sum(1 for i in k1 if i in sw), busy)
        check("t8f every book by an independent simulator on the watchlist's paths: the same marked value each day "
              "and the same trades (the tree, the everything pocket, each filter's pocket and branch)", not bad, bad)
        keys = ("diff_bp", "diff_lo", "diff_hi", "p", "a_year", "a_year_ref", "fall", "fall_ref")
        okr = all(close([R[k][x] for x in keys], v, 1e-6) for k, v in hand_rule.items())
        check("t8g the rule's numbers by hand for both parts: daily difference (bp), its 95% interval and p (10-day "
              "blocks, 2,000, seed 7), a year (closed value), worst fall (marked)", okr,
              {k: (v, [R[k][x] for x in keys]) for k, v in hand_rule.items()
               if not close([R[k][x] for x in keys], v, 1e-6)})
        oki = all(((R[k]["taken"], R[k]["skipped_full"], R[k]["also_in_tree"]) == v) if k[0] == "pocket" else
                  ((R[k]["pushed_out"], R[k]["gained"], R[k]["branch_taken"]) == v[:3] and
                   abs(R[k]["busy_share"] - v[3]) < 1e-12) for k, v in hand_itf.items())
        check("t8h by hand: the pocket's buys taken / skipped and those the tree also bought; the branch's tree trades "
              "pushed out and gained, its D1 buys taken, the share of days all 3 places were busy", oki,
              {k: (v, R[k].get("taken"), R[k].get("pushed_out"), R[k].get("gained")) for k, v in hand_itf.items()})
        okh = True
        for fam in [(p_, e) for p_ in ("pocket", "shared") for e in ("D", "ENS")]:
            ks = sorted([k for k in R if (k[0], k[2]) == fam], key=lambda k: (R[k]["p"], k[1]))
            going = True
            for j, k in enumerate(ks):
                going = going and R[k]["p"] <= 0.025 / (len(ks) - j)
                okh &= R[k]["holm_kept"] == going and abs(R[k]["holm_limit"] - 0.025 / (len(ks) - j)) < 1e-12
                okh &= R[k]["final"] == ("FINAL PASS" if going and R[k]["verdict"] == "PASS" else "FAIL")
        check("t8i Holm by hand per part and engine (0.025 / 3, / 2, / 1 in p order; FINAL PASS = kept AND PASS)", okh)
        pv = lambda k: (R[k]["final"], R[k]["diff_bp"], R[k]["diff_lo"], R[k]["p"], R[k]["a_year"],   # noqa: E731
                        R[k]["a_year_ref"], R[k]["fall"], R[k]["fall_ref"])
        check("t8j PLANTED: the filter that marks jumpy winners passes as a pocket on both engines, and inside the "
              "tree's places it adds on both and passes on at least one (that part is noisier: the places are busy)",
              R[("pocket", 1, "D")]["final"] == R[("pocket", 1, "ENS")]["final"] == "FINAL PASS" and
              R[("shared", 1, "D")]["diff_bp"] > 0 and R[("shared", 1, "ENS")]["diff_bp"] > 0 and
              "FINAL PASS" in (R[("shared", 1, "D")]["final"], R[("shared", 1, "ENS")]["final"]),
              {k: pv(k) for k in R if k[1] == 1})
        check("t8k ABSENT: a random filter passes nowhere; a filter of calm picks only has an empty pocket and leaves "
              "the tree's book exactly as it was",
              all(R[(p_, 2, e)]["final"] == "FAIL" for p_ in ("pocket", "shared") for e in ("D", "ENS")) and
              all(R[("pocket", 3, e)]["verdict"] == "FAIL" and R[("pocket", 3, e)]["a_year"] == 0 and
                  R[("shared", 3, e)]["final"] == "FAIL" and R[("shared", 3, e)]["diff_bp"] == 0 and
                  R[("shared", 3, e)]["pushed_out"] == R[("shared", 3, e)]["gained"] == 0 and
                  np.array_equal(D[f"{e} tree"].to_numpy(), D[f"{e} tree + SK#3"].to_numpy()) for e in ("D", "ENS")),
              {k: pv(k) for k in R if k[1] in (2, 3)})
        rep = (run / "REPORT.md").read_text(encoding="utf-8")
        led = [json.loads(x) for x in (bout / SK.LEDGER).read_text(encoding="utf-8").splitlines()]
        npass = sum(1 for r in R.values() if r["final"] == "FINAL PASS")
        check("t8l outputs: REPORT (verdict first for both parts, the interference answer, checks), books / trades / "
              "daily, the declaration, hashes, one ledger line",
              rep.index("## Verdict first") < rep.index("## A. Separate pocket") < rep.index("## B. Inside") <
              rep.index("## Does it disturb") < rep.index("## Checks") and "A. Separate pocket (the tree untouched): "
              "2 of 6 FINAL PASS" in rep and SK.hashed_ok(run) and
              (run / "DECLARATION.json").read_bytes() == SK.SK2_FILE.read_bytes() and len(led) == 1 and
              led[0]["event"] == "book" and led[0]["sk1_run"] == sk1.name and len(led[0]["final_pass"]) == npass and
              "pocket #1 D" in led[0]["final_pass"], (rep[:900], led))
        rc2_, out2 = quiet(SK.main, ["book", "--setups", str(sout), "--out", str(bout)])
        rc3_, out3 = quiet(SK.main, ["book", "--setups", str(sout), "--out", str(bout), "--rerun-reason", "test bug"])
        led = [json.loads(x) for x in (bout / SK.LEDGER).read_text(encoding="utf-8").splitlines()]
        check("t8m a second run is refused without --rerun-reason, allowed with one (ledger keeps both)",
              rc2_ == 2 and "already ran" in out2 and rc3_ == 0 and len(led) == 2 and
              led[1]["rerun_reason"] == "test bug", (out2[-300:], out3[-300:]))
        t9_guards(Wb, wl_dir, sout, trinfo, X, filters, tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t10_rule():
    """The rule on made-up books: a pocket losing slowly against an everything pocket losing fast."""
    cal = pd.bdate_range("2024-01-01", periods=300).to_numpy().astype("datetime64[ns]")
    rng = np.random.default_rng(3)
    n = len(cal)
    ev = np.cumprod(1 + rng.normal(-0.0015, 0.002, n))             # everything: about -30% a year
    pk = np.cumprod(1 + rng.normal(-0.0001, 0.0005, n))            # the pocket: a little below 0
    r1 = SK.book_rule(SL, cal, 0, n - 1, (ev, ev), (pk, pk), above0=True)
    r2 = SK.book_rule(SL, cal, 0, n - 1, (ev, ev), (pk, pk), above0=False)
    up = np.cumprod(1 + rng.normal(0.0004, 0.0005, n))
    r3 = SK.book_rule(SL, cal, 0, n - 1, (ev, ev), (up, up), above0=True)
    deep = up.copy()
    deep[150:] *= 0.5                                                  # higher a year but a deeper fall
    deep[200:] *= 2.6
    r4 = SK.book_rule(SL, cal, 0, n - 1, (up, up), (deep, deep))
    check("t10a the rule on made-up books: a pocket that beats a fast-losing everything pocket but itself loses money "
          "FAILS (and would pass without 'above 0'); one that makes money PASSES; a higher a year with a deeper "
          "fall FAILS", r1["diff_lo"] > 0 and r1["a_year"] < 0 and r1["verdict"] == "FAIL" and r2["verdict"] == "PASS"
          and r3["verdict"] == "PASS" and r4["a_year"] > r4["a_year_ref"] and r4["fall"] > r4["fall_ref"] and
          r4["verdict"] == "FAIL", (r1, r2, r3, r4))
    X = pd.DataFrame({"symbol": ["abc "], "sday": pd.to_datetime(["2024-03-05"]).tz_localize("Asia/Kolkata"),
                      "in_filter_1": [True]})
    Pe = pd.DataFrame({"symbol": ["ABC", "ABC"], "sday": np.array(["2024-03-05", "2024-03-06"], dtype="datetime64[ns]")})
    m = SK.sk2_marks(Pe, X, 1)
    check("t10b a zoned SK1 stock-day and a padded symbol still mark the same pick, and only it", list(m) == [True, False],
          m)


def t9_guards(Wb, wl_dir, sout, trinfo, X, filters, tmp: Path):
    def book(out, extra=()):
        return quiet(SK.main, ["book", "--setups", str(sout), "--out", str(out)] + list(extra))
    o1 = tmp / "g1"
    r1 = fake_sk1(o1, trinfo, X, filters)
    pq = pd.read_parquet(r1 / "picks.parquet")
    pq.loc[0, "in_filter_1"] = not pq.loc[0, "in_filter_1"]
    pq.to_parquet(r1 / "picks.parquet", index=False)
    rc1, l1 = book(o1)
    fake_sk1(tmp / "g2", dict(trinfo, run="TREE_20000101_001"), X, filters)
    rc2, l2 = book(tmp / "g2")
    fake_sk1(tmp / "g3", trinfo, X, [dict(f, final="NOT REPEATABLE") for f in filters])
    rc3, l3 = book(tmp / "g3")
    fake_sk1(tmp / "g4", trinfo, X, filters, decl_sha="0" * 64)
    rc4, l4 = book(tmp / "g4")
    check("t9a refused: a changed SK1 file, a SK1 run on another tree run, no repeatable filter, another declaration",
          rc1 == 2 and "outputs.sha256" in l1 and rc2 == 2 and "one tree for both" in l2 and rc3 == 2 and
          "nothing to test" in l3 and rc4 == 2 and "pinned declaration" in l4, (l1[-200:], l2[-200:], l3[-200:],
                                                                                 l4[-200:]))
    os.environ["CACHE_DAILY_ROOT"] = str(tmp / "cache")
    try:
        rc5, l5 = book(tmp / "cache" / "out")
    finally:
        os.environ.pop("CACHE_DAILY_ROOT", None)
    check("t9b an output folder inside the daily cache is refused", rc5 == 2 and "never writes there" in l5, l5[-300:])
    o6 = tmp / "g6"
    fake_sk1(o6, trinfo, X, filters)
    wl0 = pd.read_parquet(wl_dir / "watchlist.parquet")
    tg = pd.read_parquet(Path(trinfo["folder"]) / "tree_tags.parquet")
    tid = str(tg.loc[(tg["lane"] == "JUMPY") & (tg["how"].fillna("") == "") & tg["complete"].astype(bool) &
                     (tg["signal_day"] >= "2024-02-01"), "trade_id"].iloc[0])      # a pick the tree never trades
    wl = wl0.copy()
    wl.loc[wl["trade_id"].astype(str) == tid, "close_5"] += 0.01
    wl.to_parquet(wl_dir / "watchlist.parquet", index=False)
    try:
        rc6, l6 = book(o6)
    finally:
        wl0.to_parquet(wl_dir / "watchlist.parquet", index=False)
    check("t9c a watchlist changed after the tree run (one skipped pick's D5 close): RECONCILE FAILED, nothing judged, "
          "nothing written", rc6 == 2 and "RECONCILE FAILED" in l6 and "picks: rebuilt" in l6 and
          not (o6 / "books").exists(), l6[-400:])
    p = tmp / "sk2.json"
    p.write_text(SK.SK2_FILE.read_text(encoding="utf-8").replace("2,000 resamples", "1,000 resamples"), encoding="utf-8")
    try:
        SK.load_sk2(p)
        ref = False
    except SK.SKError as e:
        ref = "pinned" in str(e)
    rc7, l7 = quiet(SK.main, ["check"])
    check("t9d a changed SK2 declaration is refused; 'check' names both declarations",
          ref and rc7 == 0 and SK.SK2_SHA in l7 and SK.DECL_SHA in l7, l7[-300:])
    folder = Path(trinfo["folder"])
    names = [ln.split("  ", 1)[1] for ln in (folder / "outputs.sha256").read_text(encoding="utf-8").splitlines() if ln]
    tt0 = (folder / "tree_trades.csv").read_bytes()
    res = []
    for what in ("net", "exit_date"):
        tt = pd.read_csv(folder / "tree_trades.csv", dtype={"trade_id": str, "entry_date": str, "exit_date": str})
        i = tt.index[tt["book"] == "ENS tree"][7]
        tt.loc[i, what] = tt.loc[i, "net"] + 0.01 if what == "net" else tt.loc[i, "entry_date"]
        tt.to_csv(folder / "tree_trades.csv", index=False)
        SL.write_hashes(folder, names)                       # a tree run whose own record says otherwise
        o = tmp / f"g8_{what}"
        fake_sk1(o, trinfo, X, filters)
        try:
            rc8, l8 = book(o)
        finally:
            (folder / "tree_trades.csv").write_bytes(tt0)
            SL.write_hashes(folder, names)
        res.append((rc8 == 2 and "ENS tree: rebuilt" in l8 and "DIFFERENT" in l8 and "RECONCILE FAILED" in l8, l8[-300:]))
    check("t9e a tree run whose trade list differs in one net or one exit day: RECONCILE FAILED",
          all(x[0] for x in res), [x[1] for x in res if not x[0]])


def main():
    print(f"{SK.VERSION} self-test")
    for t in (t1_declaration, t2_bar, t3_session, t4_stock_days, t5_panel_buckets, t6_planted, t7_absent, t8_book,
              t10_rule):
        print(f"- {t.__name__}", flush=True)
        try:
            t()
        except Exception as e:  # a crash is a failure, with its trace
            import traceback
            traceback.print_exc()
            check(f"{t.__name__} ran without an error", False, repr(e))
    nf = sum(1 for _, ok in RESULTS if not ok)
    print(f"{len(RESULTS)} checks, {nf} failed")
    if nf == 0:
        print(f"VERIFIED ({SK.VERSION})")
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
