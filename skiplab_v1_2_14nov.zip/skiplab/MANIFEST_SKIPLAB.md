# MANIFEST - skiplab v1.2 (study SK1, backtest SK2, buy triggers SK3)

Built 14 Nov 2026. Folder: C:\Users\karanvsi\PyCharmMiscProject\skiplab (beside tradelab, setuplab, jumplab and clashlab, never inside bigmove_deploy). Outputs: C:\QuantData\skiplab. Reads production, setuplab's runs, the research watchlist and the panel READ ONLY.

Uses, unchanged and version-checked: tradelab (tl_data, tl_setups v1.7; SK3: tl_state's divergence and the 3-minute store), setuplab v1.1 (zones, ATR, the bootstrap, run folders; SK2: the tree's book; SK3: Book, replay2, stats, rank_rows, both_exits), jumplab v1.0 / v1.0.1 (daily features), clashlab cl2 v1.0 (the search, judge and Holm). Nothing in those folders changes.

Declarations: SK1 0fe32bffb8fb9a083ce5fc1536b7587bf49f902698369f3fa33422b4db08a84b (unchanged); SK2 2444726dbe5b33106ad74e4fcb01b626ffcffe5c305b52e03717615d497a34a5 (unchanged); SK3 00bd6f331bd98c76fcaba866b768021d906021451b4397ce4014d9193d1c8164 (new).

| file | version | sha256 (first 16) | in the v1.2 zip | role |
|---|---|---|---|---|
| skiplab.py | skiplab v1.2 | de9170c5dba84e58 | yes (replaces v1.1) | COMMAND: check / run (SK1) / book (SK2) / trig (SK3: bullish divergence and the VWAP reclaim as buy triggers on the picks, judged with setuplab's own yardstick and leaderboard rule) |
| SK3_DECLARATION.json | SK3, declared 14 Nov 2026 | 00bd6f331bd98c76 | yes (new) | the five triggers, their twins and the rule, fixed before any run (skiplab.py refuses another sha256) |
| SK2_DECLARATION.json | SK2, declared 14 Nov 2026 | 2444726dbe5b3310 | no (unchanged) | the SK2 backtest |
| SKIPLAB_DECLARATION.json | SK1, declared 14 Nov 2026 | 0fe32bffb8fb9a08 | no (unchanged) | the SK1 study |
| env_skiplab.bat | skiplab v1.0 | 841d26df31828cb3 | no (unchanged) | start a session: env_daily.bat, PYTHONPATH (skiplab, tradelab, setuplab, jumplab, clashlab, open_close, bigmove_deploy), SETUPLAB_OUT, SKIPLAB_OUT (CRLF) |
| README_SKIPLAB.md | skiplab v1.2 | 244c18f279f1a97a | yes | the question, SK1, SK2, SK3, install and run, outputs, tests |
| tests/test_skiplab.py | skiplab v1.2 | f4b7f3f028ab5fa1 | yes | the self-test (60 checks; must end VERIFIED (skiplab v1.2)); verified on pandas 3.0.5 / numpy 2.5.3 and on pandas 2.3.3 / numpy 2.4.1 |

Planted bugs: SK1 25 of 25 caught; SK2 29 of 31 (the 2 not caught change nothing in the history); SK3 22 of 22 caught (the VWAP price and window, the event order, the twin, missing sessions, the watchlist-open check, the 3-minute start, both exits, costs, the session day, the divergence's direction and newness, the dip, the twin rule, the engines, the both-exits verdict, the lanes, the trade table, the rerun guard, the entry time).
