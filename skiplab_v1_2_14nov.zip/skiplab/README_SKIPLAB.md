# skiplab v1.2 — the jumpy picks no frozen setup catches (study SK1, backtest SK2, buy triggers SK3)

**Question (Karan, 14 Nov 2026).** The frozen tree never buys a jumpy pick unless a frozen setup fills on D1–D5. What did those picks look like *inside the session* on the signal day (T0) and the day before (T-1)? Collate it with the panel's features, SDE and the market, and check which looks repeat.

Everything is declared in **`SKIPLAB_DECLARATION.json`** (14 Nov 2026, before any run); `skiplab.py` refuses any other sha256.

**The picks.** Every pick of setuplab's newest TREE run (D and ENS, ranks 1–10, from Oct 2021 when the 3-minute history starts), one row per stock-day. N = jumpy and never caught (the study), C = jumpy and caught by a setup, K = calm. ETFs out. For ranks 1–3, N are the picks the frozen tree skips.

**The outcome.** Buy at the D1 open, sell at the D5 close, net of 0.35 pp (the tree's own D1 net); excess = over NIFTY Smallcap 250 on the same dates. MFE, MAE, +5% / +10% / −8% touched and OPEN6 alongside.

**What it measures (all known at the T0 close).**
- T-1 and T0, from the daily bar: gap, open-to-close, range, close location, wicks, relative volume, and a **day type** (QUIET, GAP_UP_GO, GAP_UP_FADE, GAP_DN_RECOVER, GAP_DN_GO, TREND_UP, TREND_DN, REVERSAL_UP, REVERSAL_DN, RANGE).
- T-1 and T0, from the 3-minute bars: intraday SDE (efficiency), close vs VWAP and time above it, time of the high and low, the 30-minute drive and opening-range break, midday and last-hour moves, first / last hour volume shares, realised volatility, the largest jump, the deepest fall and biggest rise.
- T0 against T-1: higher high / higher low, close vs the T-1 high, range and volume ratios, two-session SDE.
- Daily and SDE (jumplab's features: SDE 3/5/10/20, returns, close location, distance to highs/lows, volatility shapes), setuplab's 12 zones, the panel's 60 features (features_final.txt), rank and both-engines.

**Two parts.**
1. **The repeatable test (decides).** clashlab CL2's search, unchanged: every single range and every pair of ranges of two measures (quarters at the discovery quartiles; zones and day types their own buckets) on the never-caught picks of Oct 2021–2023. Eligible: 90+ picks, 20+ sessions, 10+ picks with a positive mean in each of 2021 (from October), 2022 and 2023. The 5 best by mean net (overlap ≤ 50%) are fixed and judged on 2024 onward: inside minus the rest AND excess over Smallcap 250, both 95% intervals above 0, Holm across the 5 → **REPEATABLE**.
2. **The atlas (describes).** How never-caught picks differ from caught and calm ones (medians, AUC, by period); which measures line up with their outcome (top-minus-bottom spreads with intervals in both periods, year by year); day types and the T-1 → T0 table; chart examples per filter.

**Tradability check (descriptive).** "Never caught" is known only after D5, so each filter is also read at the T0 close on every jumpy pick of ranks 1–3 in the test years and compared with what the frozen tree did with them (its setup trade, 0 when skipped).

## SK2 — the backtest of SK1's repeatable filters (`book`, v1.1)

**Question (Karan, 14 Nov 2026 17:52).** "Yes build backtest. Also hope this doesn't interfere with the other tree's picks." Declared in **`SK2_DECLARATION.json`** (14 Nov 2026, before any run on real data); `skiplab.py` refuses any other sha256.

**The trade.** Every jumpy pick of ranks 1–3 (JUMPY or NO ATR, not an ETF, complete) whose stock-day a REPEATABLE filter marks — read at the T0 close, exactly as SK1 stored it — is bought at the D1 open and sold at the D5 close, net of 0.35 pp. From the first session of 2024. Every book uses the tree's own rules (setuplab's `tree_sim`: value 1.0, 3 places, each buy 1/3 of the closed value, full = skip).

**Two parts, each judged on its own.**
- **A. Separate pocket — no interference.** The filter's picks get their own money and their own 3 places; the frozen tree is not touched. Judged against an *everything* pocket that buys every jumpy pick the same way. PASS = daily difference 95% interval above 0 AND the pocket's a-year return above 0 AND above the everything pocket's AND its worst fall no deeper.
- **B. Inside the tree's 3 places (the branch SK1 declared).** A setup buy on D1 stays; a later setup buy is replaced by the D1 buy; a skipped pick gets the D1 buy; every other pick is the tree's. Judged against the frozen tree alone, like BR1. The places are busy most days, so this part also counts the tree's own trades pushed out and gained.
- Holm per part and engine across the filters (0.025). FINAL PASS = PASS and kept.

**Before anything is judged**, the tree is rebuilt with setuplab's own functions from the newest tree run's record (its TREE.json, frozen setups, TAGS run, watchlist and cut-offs, all checked) and must match the tree run pick for pick (lane, ETF, complete, D1 net, setup net) and trade for trade (D tree and ENS tree, tree_trades.csv); else RECONCILE FAILED. The SK1 run must be built on that same tree run.

## SK3 — bullish RSI divergence and the VWAP reclaim as buy triggers (`trig`, v1.2)

**Question (Karan, 14 Nov 2026 19:05 / 19:09).** "Any indicator, divergence, confluence that will help identify a buy trigger? For trading view" — "First lets test". Declared in **`SK3_DECLARATION.json`** (before any run); `skiplab.py` refuses any other sha256.

**Judged exactly like the frozen setups.** setuplab v1.1's own Book, replay2, stats, rank_rows and both_exits are called: watch D1–D5, each trigger's own trades against buying the same picks at the D1 open (Karan's comparison), exits original_d5 and fresh, 0.35 pp, 10-day block bootstrap; PASS = setuplab's leaderboard rule (1)–(5) in both engines under both exits (300+ trades; better than D1 with a 95% interval above 0; beats its twin; net above 0 in all but one year and in both halves). Picks: setuplab's research watchlist (`--data`, WL_R1_10: D and ENS, ranks 1–10).

**The five triggers.**
- DIV_ON — tradelab tl_state's bullish divergence (a lower swing low with RSI 14 five points higher) on at the close → buy the next open.
- DIV_NEW — the divergence appears at the close → buy the next open.
- DIV_DIP2 — divergence on and the close 2%+ under the D1 open → buy the next open (twin: the same dip alone).
- VW_D1 — on D1, a 3-minute close under the session VWAP, then back over it → buy the next bar's open (twin: buy right after the first close under it).
- VW_D15 — the same on the first of D1–D5 where it happens. VWAP triggers: picks with D1 from Oct 2021 (the 3-minute history); tradelab's usable sessions only.

## Install and run

Unzip into `C:\Users\karanvsi\PyCharmMiscProject` (the `skiplab` folder beside tradelab, setuplab, jumplab and clashlab; nothing else changes). v1.2 replaces skiplab.py, the test, README and MANIFEST and adds SK3_DECLARATION.json; env_skiplab.bat, SKIPLAB_DECLARATION.json and SK2_DECLARATION.json are unchanged.

```
call C:\Users\karanvsi\PyCharmMiscProject\skiplab\env_skiplab.bat
python tests\test_skiplab.py
python skiplab.py check
python skiplab.py run --root %CACHE_DAILY_ROOT%          (SK1 - done once)
python skiplab.py book                                   (SK2 - done once)
python skiplab.py trig --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10     (SK3)
```

The test must end `VERIFIED (skiplab v1.2)`. `run` prints progress every 200 stocks and ends with the 5 filters and a `RESULT:` line; `book` prints the reconcile, one line per filter, part and engine, and a `RESULT:` line. A second run of either is refused unless `--rerun-reason "<a verified bug>"` is given (recorded in the ledger).

**SK3 outputs** (`C:\QuantData\skiplab\trig\SK3_<date>_<nnn>\`): REPORT.md (verdict first, the rule trigger by trigger, where each works — jumpy / calm, ranks, years — and the data checks), triggers.csv (setuplab's numbers per trigger, exit and engine, with the rule's reasons), groups.csv, trades.csv (every trade: entry day, date, time, price, both nets, the D1 trade beside it), run.json, DECLARATION.json, outputs.sha256; a ledger line.

**SK2 outputs** (`C:\QuantData\skiplab\books\SK2_<date>_<nnn>\`): REPORT.md (verdict first for both parts, then "does it disturb the tree's other trades?"), books.csv (one row per part, filter and engine), trades.csv (every book's trades taken), daily.csv (every book's marked value each day), run.json, DECLARATION.json, outputs.sha256; a ledger line.

**SK1 outputs** (`C:\QuantData\skiplab\runs\SK_<date>_<nnn>\`): REPORT.md (verdict first), picks.parquet (every stock-day with every measure, its group, period and filter flags), groups.csv, measures.csv, daytypes.csv, transitions.csv, filters.csv, top25.csv, tradability.csv, run.json, DECLARATION.json, outputs.sha256; one line per run in `C:\QuantData\skiplab\skiplab_ledger.jsonl`.

**Reads only:** setuplab's newest TREE and TAGS runs (hash-checked), the panel the TAGS run used, the research watchlist the tree run used (SK2), the daily cache and 3-minute bars through tradelab's loaders (SK1). **Writes only** under `SKIPLAB_OUT`.

## Tests (`tests\test_skiplab.py`, 60 checks)

- By hand: the 10 day types and their order; the daily-bar measures; every 3-minute measure against an independent loop (also with missing bars and real highs/lows); unusable sessions blank; T0 against T-1; one row per stock-day and the tree's result; the panel reader (zoned stamps, any case); buckets from the discovery picks only; the bootstrap and AUC.
- Synthetic worlds in the real file layouts (daily + 3-minute bars from one generator, indices, a panel, setuplab TREE / TAGS runs, tradelab's production stand-ins): a **planted** world (a strong T0 last hour is followed by +4% over D2–D5) — found on 2021–2023 and REPEATABLE on 2024 onward, listed as a repeatable association; an **absent** world — nothing REPEATABLE; six stock-days and the excess by hand; tradability counts; Holm by hand; no look-ahead (every later session rescaled: no measure moves); outputs, ledger and the rerun guard.
- SK2 (20 checks): a world run through setuplab's own `tag` and `tree` commands; the rebuilt tree matches the tree run pick for pick and trade for trade; every book (the tree, the everything pocket, each filter's pocket and branch) against an independent simulator on the watchlist's own paths — same value each day, same trades; the rule's numbers, the interference counts, the busy share and Holm by hand; a **planted** filter (jumpy winners) passes as a pocket on both engines and inside the places on D; a **random** filter and a **calm-only** filter pass nowhere (the calm-only branch leaves the tree's book exactly as it was); the rule on made-up books (a pocket that beats a fast-losing everything pocket but loses money itself fails); a zoned SK1 stock-day still marks the right pick; refused: changed SK1 files, an SK1 run on another tree run, no repeatable filter, another declaration, a watchlist changed after the tree run or a tree run whose own trade list differs (RECONCILE FAILED), the daily cache as output; the rerun guard.
- SK3 (14 checks): worlds with daily and 3-minute bars from one generator and setuplab's watchlist built from them; the divergence = tl_state's on each stock's own bars; **every trade by hand** (the divergence at the previous close with setuplab's missing rule; the VWAP events recomputed from the raw 3-minute files) — the same picks, entry day, price, time and both nets; setuplab's numbers and rule (1)–(5) by hand for every trigger, engine and exit; an **absent** world passes nothing; a **planted** world (a divergence that marks real good entries; sessions that dip 3% and climb back) passes; descriptive rows add up (the jumpy rows = the trades on jumpy picks); a watchlist 1% off the 3-minute bars is refused session by session; the verdict needs both exits; outputs, ledger, rerun guard and refusals.
- Planted bugs, each caught (see MANIFEST).
