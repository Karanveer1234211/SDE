# MANIFEST - soullab v1.0

Built 2026-11-21. Folder: C:\Users\karanvsi\PyCharmMiscProject\soullab (beside setuplab, never inside bigmove_deploy). Outputs: C:\QuantData\soullab. Needs setuplab v1.1 in PyCharmMiscProject\setuplab (imported read only). Production files are read, never written.

| file | sha256 (first 16) | role |
|---|---|---|
| README_SOULLAB.md | 88d62ac2f68174c2 | how to install, check, run and read it |
| SOULLAB_DECLARATION.json | e6a0d0b48120adb0 | the study's rules, declared 21 Nov 2026 before any real run (sha256-checked; an edited file is refused) |
| soullab.py | aaf5fa1742638561 | COMMAND: run (BUY / SKIP / TRIGGER rule search on Soul x D's inputs, replay 2022-2026, money books); --check-only |
| tests/test_soullab.py | 9a285547b9840b8f | 38 checks on planted and absent synthetic worlds (must end VERIFIED (soullab v1.0)); 21 Nov fix: run folders matched exactly (Windows ignores case, so SOULLAB_* also matched soullab_ledger.jsonl) |

Read only (on your PC, unchanged): C:\QuantData\setuplab\WL_R1_10 (watchlist.parquet, calendar.parquet); %CACHE_DAILY_ROOT%\panel_oc\panel.parquet; %CACHE_DAILY_ROOT%\panel_oc\frozen\production\PRODUCTION.json (engine D's input list; else FROZEN_ENGINES.json's stage_d.json); %CACHE_DAILY_ROOT%\panel\soul\soul_v3_open.parquet and its _meta.json (or --soul).

