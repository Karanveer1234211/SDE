"""
tests for soullab v1.0 - synthetic worlds only; nothing real is read and nothing outside a temporary folder is written.

    python tests\\test_soullab.py          (from the soullab folder, in tradelab's env)

Ends with  VERIFIED (soullab v1.0)  or  FAILED.
  u1-u3  the screens = brute force (pairs and triples at the D1 open; triggers: the first watch day, by a plain loop)
  u4     the conditions = a hand reading of the values, day by day
  u5     point in time: values after the close a condition reads never change it
  u6     the lift = the net minus the same day's mean, by hand
  u7     the join check catches a pick reading the wrong session
  u8     the earn check = the smallest bound over the simpler versions; a condition adding nothing fails
  u9     a rule qualifies only when D and ENS each point the same way
  e1     PLANTED world (a BUY pair, a SKIP pair, a TRIGGER pair, each Soul x feature): each found among its list's
         candidates, each list HOLDS in the replay, the money books written, the inputs filtered (raw level, label_,
         missing), every output hashed, two ledger lines
  e2     ABSENT world (no effect): no list HOLDS
  e3     --check-only writes nothing; an edited declaration and an output folder inside the cache are refused
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import soullab as S  # noqa: E402
import setuplab as SU  # noqa: E402

FAILS = []
N_OK = [0]


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   %s" % what)
    else:
        FAILS.append(what)
        print("  FAIL %s" % what)


# ---------------------------------------------------------------------------------------------------- the world
DFEATS = ["f%02d" % i for i in range(10)]
SOUL = ["soul_a", "soul_b", "soul_c"]


def make_world(base: Path, seed: int, plant: bool, n_sym=60, per_day=6, start="2019-09-02", end="2026-10-30"):
    """root (panel_oc\\panel.parquet, PRODUCTION.json, panel\\soul\\soul_v3_open.parquet + meta) and data
    (watchlist.parquet, calendar.parquet). Planted (Soul x feature, read at a close):
      BUY      soul_a in its high third AND f03 rose on the signal day      -> +1.2% a session D1-D5
      SKIP     soul_b in its low third AND f05 fell on the signal day       -> -1.2% a session D1-D5
      TRIGGER  soul_c in its high third AND f07 rose that session (the close before watch day k; first such k)
               -> -1.0% a session before watch day k, then +1.5% a session from its open to the D5 close"""
    rng = np.random.default_rng(seed)
    root, data = base / "root", base / "data"
    for p in (root / "panel_oc" / "frozen" / "production", root / "panel" / "soul", data):
        p.mkdir(parents=True, exist_ok=True)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    syms = ["S%03d" % i for i in range(n_sym)]
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)), axis=1) for f in DFEATS}
    X["d_sma200"] = 100 + np.cumsum(rng.normal(0, 1, (n_sym, T)), axis=1)
    X["label_x"] = rng.normal(0, 1, (n_sym, T))
    SV = {}
    for f in SOUL:
        a = np.zeros((n_sym, T))
        a[:, 0] = rng.normal(0, 1, n_sym)
        e = rng.normal(0, 0.2, (n_sym, T))
        for t in range(1, T):
            a[:, t] = 0.98 * a[:, t - 1] + e[:, t]
        SV[f] = a
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(cal, n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    so = pd.DataFrame({"timestamp": np.tile(cal, n_sym), "symbol": np.repeat(syms, T)})
    for f, v in SV.items():
        so[f] = v.ravel().astype("float32")
    so["soul_state_missing"] = 0
    so.to_parquet(root / "panel" / "soul" / "soul_v3_open.parquet", index=False)
    (root / "panel" / "soul" / "soul_v3_open_meta.json").write_text(json.dumps(
        {"code": "soul_v3.2", "entry": "open", "config": {"lag": 6, "horizon": 5},
         "features": SOUL + ["soul_state_missing"]}), encoding="utf-8")
    (root / "panel_oc" / "frozen" / "production" / "PRODUCTION.json").write_text(json.dumps(
        {"models": {"D": {"file": "D.pkl", "features": [f.upper() if f == "f00" else f for f in DFEATS] +
                          ["d_sma200", "label_x", "f_missing"]}}}), encoding="utf-8")
    q = {f: np.quantile(SV[f][:, 60:], [1 / 3, 2 / 3]) for f in SOUL}
    chg = {f: np.diff(X[f], axis=1, prepend=np.nan) for f in DFEATS}
    first = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    rows, paths = [], {}
    for t in range(first, T - 11):
        pick_d = rng.choice(n_sym, per_day, replace=False)
        pick_e = np.concatenate([pick_d[:per_day // 2], rng.choice(np.setdiff1d(np.arange(n_sym), pick_d),
                                                                   per_day - per_day // 2, replace=False)])
        rng.shuffle(pick_e)
        for eng, picks in (("D", pick_d), ("ENS", pick_e)):
            for rk, s in enumerate(picks, 1):
                key = (t, s)
                if key not in paths:
                    r = rng.normal(0.0005, 0.02, 11)
                    g = rng.normal(0, 0.006, 11)
                    if plant:
                        if SV["soul_a"][s, t] > q["soul_a"][1] and chg["f03"][s, t] > 0:
                            r[1:6] += 0.012
                        if SV["soul_b"][s, t] < q["soul_b"][0] and chg["f05"][s, t] < 0:
                            r[1:6] -= 0.012
                        for k in range(1, 6):
                            j = t + k - 1
                            if SV["soul_c"][s, j] > q["soul_c"][1] and chg["f07"][s, j] > 0:
                                r[1:k] -= 0.01          # it slides until the trigger, then climbs
                                r[k:6] += 0.015
                                break
                    sc = 100.0 * np.exp(rng.normal(0, 0.5))
                    O, C = np.zeros(11), np.zeros(11)
                    O[1] = sc * (1 + g[1])
                    C[1] = O[1] * (1 + r[1])
                    for k in range(2, 11):
                        O[k] = C[k - 1] * (1 + g[k])
                        C[k] = O[k] * (1 + r[k])
                    paths[key] = (sc, O, C)
                sc, O, C = paths[key]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": sc, "entry": O[1], "status": "ok",
                       "net_bp": (C[5] / O[1] - 1) * 1e4 - 35, "s_atr14": 0.03, "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[k] / O[1] - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[k] / C[k - 1] - 1
                rows.append(row)
    W = pd.DataFrame(rows)
    W.to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return root, data, {"q": q, "cal": cal}


def args(root, data, out, **kw):
    return SimpleNamespace(root=str(root), data=str(data), out=str(out), panel=kw.get("panel"), soul=kw.get("soul"),
                           check_only=kw.get("check_only", False), setuplab_any=False)


def world_obj(root, data):
    panel = root / "panel_oc" / "panel.parquet"
    soul = root / "panel" / "soul" / "soul_v3_open.parquet"
    dfeats, _, _ = S.d_features(root)
    _, scols, _ = S.soul_meta(soul)
    dcols, excl = S.choose_features(dfeats, panel)
    book, _ = S.load_book(data, panel, soul, dcols, scols, log=lambda *a: None)
    feats = [f for f in dcols + scols if f in book.F]
    return S.World(book, feats, set(scols)), feats, scols, dcols, excl, panel, soul


# ---------------------------------------------------------------------------------------------------- unit checks
def unit_checks(W, feats, scols, panel, soul, dcols):
    print("u1-u3: the screens = brute force")
    specs = S.atom_specs(feats, set(scols))
    atoms = S.resolve(specs, W, W.pool)
    DM = S.day_masks(atoms, W)
    P = S.make_pop(W, W.pool)
    DMp = DM[:, P["pos"]]
    MAb = (DMp & 1).astype(bool)
    fam = S.fam_ids(atoms)
    rng = np.random.default_rng(3)
    y = P["lift"]
    min_n = 50.0
    scr = S.screen_open(MAb, y, fam, min_n, keep=10 ** 9)
    bad = 0
    pr = scr["buy"]["pairs"]
    sk = scr["skip"]["pairs"]
    look = {tuple(r[:2]): (lb, n, m) for r, lb, n, m in zip(pr["rules"], pr["lb"], pr["n"], pr["mean"])}
    looks = {tuple(r[:2]): (lb, m) for r, lb, m in zip(sk["rules"], sk["lb"], sk["mean"])}
    tested = 0
    for _ in range(400):
        i, j = sorted(rng.choice(len(atoms), 2, replace=False))
        if fam[i] == fam[j]:
            continue
        m = MAb[i] & MAb[j]
        n = int(m.sum())
        if n < min_n:
            bad += (i, j) in look
            continue
        x = y[m]
        mean, se = x.mean(), x.std(ddof=1) / np.sqrt(n)
        lb, nn, mm = look[(i, j)]
        lbs, ms = looks[(i, j)]
        tested += 1
        if not (nn == n and abs(mm - mean) < 1e-4 and abs(lb - (mean - S.Z * se)) < 1e-4 and
                abs(ms + mean) < 1e-4 and abs(lbs - (-mean - S.Z * se)) < 1e-4):
            bad += 1
    check(tested > 50 and bad == 0, "u1 pairs at the D1 open: count, mean and quick bound (BUY and SKIP) = brute "
                                    "force on %d pairs" % tested)
    pairs = [(int(r[0]), int(r[1])) for r in pr["rules"][:5]]
    T3 = S.screen_open_triples(MAb, y, fam, pairs, min_n, 10 ** 9, 1.0)
    bad = 0
    for r, lb, n in list(zip(T3["rules"], T3["lb"], T3["n"]))[:300]:
        m = MAb[r[0]] & MAb[r[1]] & MAb[r[2]]
        x = y[m]
        if not (len(set(fam[list(r)])) == 3 and int(m.sum()) == n and
                abs(lb - (x.mean() - S.Z * x.std(ddof=1) / np.sqrt(len(x)))) < 1e-4):
            bad += 1
    check(len(T3["lb"]) > 50 and bad == 0, "u2 triples: three families, count and quick bound = brute force")
    # triggers: a plain loop over picks and watch days
    TL = P["TL"]
    st = S.screen_trigger(DMp, TL, fam, min_n, 10 ** 9)
    lookt = {tuple(r[:2]): (lb, n) for r, lb, n in zip(st["pairs"]["rules"], st["pairs"]["lb"], st["pairs"]["n"])}
    bad = tested = 0
    for _ in range(200):
        i, j = sorted(rng.choice(len(atoms), 2, replace=False))
        if fam[i] == fam[j]:
            continue
        vals = []
        for p in range(P["n"]):
            for k in range(5):
                if (DMp[i, p] >> k) & 1 and (DMp[j, p] >> k) & 1:
                    vals.append(W.NO[P["pos"][p], k] - P["dm"][p])
                    break
        vals = np.array(vals)
        if len(vals) < min_n:
            continue
        tested += 1
        lb, n = lookt[(i, j)]
        if not (n == len(vals) and abs(lb - (vals.mean() - S.Z * vals.std(ddof=1) / np.sqrt(len(vals)))) < 1e-3):
            bad += 1
        if tested >= 25:
            break
    check(tested >= 10 and bad == 0, "u3 trigger pairs: first watch day, count and quick bound = a plain loop "
                                     "(%d pairs)" % tested)
    print("u4: the conditions by hand")
    bad = 0
    for _ in range(300):
        a = atoms[rng.integers(len(atoms))]
        r = int(rng.integers(W.n))
        k = int(rng.integers(1, 6))
        v, c, p = W.V[a["f"]][r, k], W.Cg[a["f"]][r, k], W.Cg[a["f"]][r, k - 1]
        if a["kind"] == "lvl":
            want = bool(np.isfinite(v) and a["lo"] < v <= a["hi"])
        else:
            code = a["code"]
            want = {"up0": c > 0, "dn0": c < 0, "up1": p > 0, "dn1": p < 0, "upup": p > 0 and c > 0,
                    "dndn": p < 0 and c < 0, "dnup": p < 0 and c > 0, "updn": p > 0 and c < 0}[code]
        want = bool(want) and bool(W.sess[r, k - 1])
        got = bool((DM[atoms.index(a), r] >> (k - 1)) & 1)
        bad += want != got
    check(bad == 0, "u4 300 conditions read by hand on random picks and watch days")
    # the Book's values = the panel's own rows (signal close = column 1; the change = this session minus the last)
    pn = pd.read_parquet(panel).set_index(["symbol", "timestamp"]).sort_index()
    bad = 0
    for r in rng.integers(0, W.n, 100):
        d0 = pd.Timestamp(W.cal[W.i1[r] - 1])
        dm1 = pd.Timestamp(W.cal[W.i1[r] - 2])
        a, b = float(pn.at[(W.sym[r], d0), "f04"]), float(pn.at[(W.sym[r], dm1), "f04"])
        bad += not (abs(W.V["f04"][r, 1] - a) < 1e-3 and abs(W.Cg["f04"][r, 1] - (a - b)) < 1e-3)
    check(bad == 0, "u4 the value at the signal close and its change = the panel's rows (100 picks)")
    print("u5: point in time")
    keepV = {f: W.V[f].copy() for f in feats}
    keepC = {f: W.Cg[f].copy() for f in feats}
    b0 = DM & 1
    rule = (atoms.index(next(a for a in atoms if a["id"] == "soul_c:H3")),
            atoms.index(next(a for a in atoms if a["id"] == "f07:up0")))
    K0 = S.trig_entries(DM, rule)
    for f in feats:
        W.V[f][:, 3:] = rng.normal(0, 50, W.V[f][:, 3:].shape)
        W.Cg[f][:, 3:] = rng.normal(0, 50, W.Cg[f][:, 3:].shape)
    DM2 = S.day_masks(atoms, W)
    K2 = S.trig_entries(DM2, rule)
    check(np.array_equal(b0, DM2 & 1), "u5 every BUY / SKIP condition unchanged when every later value is scrambled")
    check(np.array_equal(K0[K0 <= 1], K2[K0 <= 1]) and (K0 <= 1).sum() > 100,
          "u5 a trigger entering on D1 or D2 unchanged when the values read for D3-D5 are scrambled")
    for f in feats:
        W.V[f][:] = keepV[f]
        W.Cg[f][:] = keepC[f]
    print("u6: the lift")
    d = pd.DataFrame({"day": P["day"], "net": P["netA"]})
    want = d["net"] - d.groupby("day")["net"].transform("mean")
    check(np.allclose(want.to_numpy(), P["lift"]), "u6 the lift = the net minus the same day's mean (pooled picks)")
    print("u8: every condition earns its place")
    y = P["lift"]
    bad = 0
    for _ in range(60):
        c = tuple(sorted(int(x) for x in rng.choice(len(atoms), int(rng.integers(2, 4)), replace=False)))
        m = S.open_mask(MAb, c)
        want = np.inf
        for dd in range(len(c)):
            x = S.open_mask(MAb, c[:dd] + c[dd + 1:]) & ~m
            v = SU._dlb(P["di"][m], y[m], P["di"][x], y[x], P["nd"])
            v = v if np.isfinite(v) else -np.inf
            want = min(want, v)
        got = S.earn_quick_open(MAb, c, y, P["di"], P["nd"])
        bad += not ((got == want) or (want <= 0 and got <= 0) or abs(got - want) < 1e-9)
    check(bad == 0, "u8 the quick earn check = the smallest bound over the rule's simpler versions (60 rules)")
    h3 = next(i for i, a in enumerate(atoms) if a["id"] == "f02:H3")
    hi = next(i for i, a in enumerate(atoms) if a["id"] == "f02:HI")
    check(not S.earn_quick_open(MAb, (h3, hi), y, P["di"], P["nd"]) > 0,
          "u8 a condition that adds nothing (upper half on top of the high third) does not earn its place")
    print("u9: both engines must point the same way")
    boot = SU.Boot(P["day"], B=S.BOOT_B, block=S.BOOT_BLOCK, seed=S.BOOT_SEED)
    ia = next(i for i, a in enumerate(atoms) if a["id"] == "soul_a:H3")
    ib = next(i for i, a in enumerate(atoms) if a["id"] == "f03:up0")
    rule = (min(ia, ib), max(ia, ib))
    EP = []
    for e in ("D", "ENS"):
        pe = np.flatnonzero(W.eng == e)
        PE = S.make_pop(W, pe, e)
        EP.append((e, PE, (DM[:, pe] & 1).astype(bool)))
    r1 = S.eval_open("buy", rule, P, MAb, boot, EP)
    flip = dict(EP[1][1])
    flip["lift"] = -flip["lift"]
    r2 = S.eval_open("buy", rule, P, MAb, boot, [EP[0], ("ENS", flip, EP[1][2])])
    check(r1["qualifies"] and r1["engines_agree"] and not r2["engines_agree"] and not r2["qualifies"],
          "u9 the planted BUY rule qualifies; the same rule with one engine's picks trailing does not")
    ET = [(e, PE, DM[:, PE["pos"]]) for e, PE, _ in EP]
    ic = next(i for i, a in enumerate(atoms) if a["id"] == "soul_c:H3")
    i7 = next(i for i, a in enumerate(atoms) if a["id"] == "f07:up0")
    trule = (min(ic, i7), max(ic, i7))
    t1 = S.eval_trig(trule, P, DMp, boot, ET)
    lowered = dict(ET[0][1])
    lowered["NO6"] = lowered["NO6"] - 20.0
    t2 = S.eval_trig(trule, P, DMp, boot, [("D", lowered, ET[0][2]), ET[1]])
    check(t1["qualifies"] and t1["engines_agree"] and not t2["engines_agree"] and not t2["qualifies"],
          "u9 the planted TRIGGER rule qualifies; with one engine's trades losing it does not")
    print("u7: the join check")
    jc = S.join_check(W, panel, soul, dcols, scols)
    check(jc["checked"] > 1000 and jc["mismatches"] == 0, "u7 the join check passes on a correct world (%d values)" %
          jc["checked"])
    for f in feats:
        W.V[f][:, 1] = keepV[f][:, 2]                      # a pick reading the NEXT session's value
    jc2 = S.join_check(W, panel, soul, dcols, scols)
    check(jc2["mismatches"] > 0, "u7 the join check catches a pick reading the next session (%d mismatches)" %
          jc2["mismatches"])
    for f in feats:
        W.V[f][:] = keepV[f]


# ---------------------------------------------------------------------------------------------------- end to end
def runs(out):
    """The run folders SOULLAB_YYYYMMDD_NNN, matched exactly (Windows matches file names without case, so a glob
    for SOULLAB_* also returns soullab_ledger.jsonl)."""
    out = Path(out)
    if not out.is_dir():
        return []
    return sorted(p for p in out.iterdir() if p.is_dir() and re.fullmatch(r"SOULLAB_\d{8}_\d{3}", p.name))


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return all(hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0]
               for ln in lines) and len(lines) >= 10


def main():
    t0 = time.time()
    tmp = Path(tempfile.mkdtemp(prefix="soullab_test_"))
    try:
        print("%s tests (%s; pandas %s, numpy %s)" % (S.VERSION, SU.VERSION, pd.__version__, np.__version__))
        root, data, info = make_world(tmp / "planted", seed=11, plant=True)
        W, feats, scols, dcols, excl, panel, soul = world_obj(root, data)
        ex = dict(excl)
        check(set(dcols) == set(DFEATS) and ex.get("d_sma200", "").startswith("raw") and
              ex.get("label_x", "").startswith("label") and ex.get("f_missing") == "not in the panel",
              "inputs: D's 10 features used (one listed in capitals), the raw level, the label_ column and a missing "
              "one left out")
        check(scols == SOUL, "inputs: Soul's features from its meta, soul_state_missing left out")
        unit_checks(W, feats, scols, panel, soul, dcols)
        print("e1: the planted world, end to end")
        out = tmp / "out"
        rc = S.main(["run", "--root", str(root), "--data", str(data), "--out", str(out)])
        check(rc == 0, "e1 run returns 0")
        d = runs(out)[-1]
        doc = json.loads((d / "SOULLAB_CANDIDATES.json").read_text(encoding="utf-8"))
        sha = doc.pop("sha256")
        check(sha == SU.frozen_hash(json.loads(json.dumps(doc))), "e1 the candidates file carries its own sha256")
        # the planted pair, or a narrower version of it (rose twice / turned up also rose that session)
        want = {"buy": ("soul_a", ("H3", "HI"), "f03", ("up0", "upup", "dnup")),
                "skip": ("soul_b", ("L3", "LO"), "f05", ("dn0", "dndn", "updn")),
                "trigger": ("soul_c", ("H3", "HI"), "f07", ("up0", "upup", "dnup"))}

        def planted(rule, w):
            ids = rule.split(" & ")
            return any(x in ids for x in ["%s:%s" % (w[0], c) for c in w[1]]) and \
                any(x in ids for x in ["%s:%s" % (w[2], c) for c in w[3]])
        for lst in S.LISTS:
            rules = [c["rule"] for c in doc["lists"][lst]["candidates"]]
            check(any(planted(r, want[lst]) for r in rules), "e1 %s: the planted Soul x feature pair is in a "
                                                              "candidate (%s)" % (lst, "; ".join(rules)))
            srules = [c["rule"] for c in doc["lists"][lst]["soul_candidates"]]
            check(any(planted(r, want[lst]) for r in srules), "e1 %s: and in a Soul candidate" % lst)
            v = doc["lists"][lst]["replay"]
            check(v["verdict"] == "HOLDS", "e1 %s: the replay HOLDS (out of sample %d picks, lift %.3f [%.3f, %.3f])" % (
                lst, v["picks"], v["lift"], v["lift_lo"], v["lift_hi"]))
        MO = pd.read_csv(d / "money.csv")
        check(len(MO) and set(MO["slots"]) == {2, 3, 5, 7} and MO["book"].str.contains("baseline").any() and
              MO["book"].str.contains("BUY out of sample").any() and MO["book"].str.contains("SKIP").any() and
              MO["book"].str.contains("TRIGGER out of sample").any(), "e1 the money books: baseline and the three "
                                                                    "out-of-sample arms, 2 / 3 / 5 / 7 slots")
        b3 = MO[(MO["slots"] == 3) & (MO["mtf"] == "none")].set_index("book")["cagr"]
        check(b3.filter(like="BUY out").iloc[0] > b3.filter(like="baseline").iloc[0] and
              b3.filter(like="SKIP").iloc[0] > b3.filter(like="baseline").iloc[0],
              "e1 BUY and SKIP out of sample grow the 3-slot book faster than the baseline")
        check(outputs_ok(d), "e1 every output matches outputs.sha256")
        md = (d / "SOULLAB.md").read_text(encoding="utf-8")
        check("## Verdict" in md and "Soul on its own" in md and "Money from 2022" in md and "join check" in md,
              "e1 SOULLAB.md: verdict first, Soul alone, money, the checks")
        L = [json.loads(x) for x in (out / "soullab_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        check([x["event"] for x in L] == ["start", "end"] and L[0]["declaration_sha256"] == S.load_declaration()[1][
            "sha256"], "e1 the ledger: a start line (with the declaration's sha256) and an end line")
        WY = pd.read_csv(d / "replay_years.csv")
        check(len(WY) == 5 and all(pd.Timestamp(r.train_last_exit) < pd.Timestamp("%d-01-01" % r.year)
                                   for r in WY.itertuples()), "e1 the replay: each year chose with picks fully "
                                                              "exited before 1 January (the D9 close)")
        F = pd.read_csv(d / "features.csv")
        check(not F.loc[F["feature"].isin(["d_sma200", "label_x"]), "used"].any(), "e1 features.csv: the raw level "
                                                                                 "and the label_ column unused")
        print("e2: the absent world")
        root2, data2, _ = make_world(tmp / "absent", seed=29, plant=False)
        out2 = tmp / "out2"
        rc = S.main(["run", "--root", str(root2), "--data", str(data2), "--out", str(out2)])
        d2 = runs(out2)[-1]
        doc2 = json.loads((d2 / "SOULLAB_CANDIDATES.json").read_text(encoding="utf-8"))
        vv = {lst: doc2["lists"][lst]["replay"]["verdict"] for lst in S.LISTS}
        check(rc == 0 and all(v != "HOLDS" for v in vv.values()), "e2 no list HOLDS when nothing is planted (%s)" %
              ", ".join("%s %s" % kv for kv in vv.items()))
        print("e3: refusals")
        out3 = tmp / "out3"
        rc = S.main(["run", "--root", str(root), "--data", str(data), "--out", str(out3), "--check-only"])
        check(rc == 0 and not runs(out3) and not (out3 / "soullab_ledger.jsonl").exists(),
              "e3 --check-only searches and writes nothing")
        rc = S.main(["run", "--root", str(root), "--data", str(data), "--out", str(root / "x")])
        check(rc == 3, "e3 an output folder inside the cache is refused")
        dp = S.HERE / S.DECL_FILE
        keep = dp.read_bytes()
        try:
            dp.write_bytes(keep.replace(b"25 or more trades a year", b"20 or more trades a year", 1))
            rc = S.main(["run", "--root", str(root), "--data", str(data), "--out", str(out3)])
            check(rc == 3, "e3 an edited declaration is refused")
        finally:
            dp.write_bytes(keep)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("\n%d checks, %d failed (%.0f s)" % (N_OK[0] + len(FAILS), len(FAILS), time.time() - t0))
    if FAILS:
        print("FAILED:\n  " + "\n  ".join(FAILS))
        return 1
    print("VERIFIED (%s)" % S.VERSION)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
