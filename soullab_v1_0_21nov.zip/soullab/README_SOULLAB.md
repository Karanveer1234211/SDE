# soullab v1.0 - new rules from Soul x engine D's inputs

Your question (21 Nov 2026): *new rules, and the interactions of Soul with the model's features.* Your answers: a rule
decides **both** (buy at the D1 open or skip, **and** wait for a trigger), using **all of engine D's features**.

soullab sits beside setuplab (`PyCharmMiscProject\soullab`). It reads production **read only** (the watchlist folder
setuplab built, `panel_oc\panel.parquet`, Soul's file, D's input list) and writes only under `C:\QuantData\soullab`.
Nothing in production, the paper test or the frozen tree changes. The rules of the study are in
`SOULLAB_DECLARATION.json` (sha256-checked; an edited file is refused).

## What it does, in plain words

1. **The picks:** D and ENS, ranks 1-10, 2020-2026, from `C:\QuantData\setuplab\WL_R1_10`. A stock picked by both
   engines on the same day counts once.
2. **The inputs:** every input of engine D (from `PRODUCTION.json`), except raw price levels and `label_` columns,
   plus every Soul v3 value (`soul_p_tp`, `soul_p_ret`, the memory values ...).
3. **Each input becomes 12 yes/no conditions**, read at a close: its level (low third, high third, lower half, upper
   half of the picks), whether it rose or fell that session, rose or fell the session before, and rose twice / fell
   twice / turned up / turned down.
4. **Three lists, searched at once:**

| list | when it reads | what it does | judged against |
|---|---|---|---|
| BUY | the signal close | buys at the D1 open, sells at the D5 close | all picks of the same days |
| SKIP | the signal close | the picks to leave out | all picks of the same days (they must trail them and lose money) |
| TRIGGER | the close before each watch day D1-D5 | waits; buys the first open after all conditions hold; sells at the D5 close (the fresh exit must make money too) | all picks of the same days, and D1 on the same picks |

5. **Every single condition, every pair, and the best pairs with a third condition.** Each condition must earn its
   place: the rule must beat the picks its simpler version (that condition dropped) would add. The best go through
   the block bootstrap (10-day blocks, 2,000 draws).
6. **The luck check (the replay):** the whole search is redone for each year 2022-2026 using only the picks that had
   fully exited before 1 January, and its chosen rules are judged on that year only. **HOLDS** = they beat the
   other picks out of sample (95%). **NOT SHOWN** = no clear difference: the in-sample list may be luck.
7. **Money from 2022:** setuplab's book (Rs 5 L, 2 / 3 / 5 / 7 slots, no MTF and MTF 2x): plain ranks 1-3 at the D1
   open against each list's out-of-sample arm.

**Example.** A BUY rule *"soul_p_tp in its high third AND d_rsi14 fell on the signal day"* buys, at the D1 open, every
pick whose Soul hit-rate is in the top third of all picks and whose RSI fell that day. It qualifies only if those
picks beat the day's other picks (95%), made money (95%), lost money in at most 2 of the 7 years, pointed the same way
in D and in ENS, and **each** of its two conditions adds something on its own.

A TRIGGER rule *"soul_p_ret in its upper half AND d_mdi14 turned down"* is checked at the D0 close (buy D1 open), then
the D1 close (buy D2 open) ... up to the D4 close (buy D5 open); the first time both hold, it buys.

## Install and run

Copy the `soullab` folder to `C:\Users\karanvsi\PyCharmMiscProject\soullab` (beside `setuplab` - it imports
setuplab v1.1 from there, read only). Then in `cmd`:

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\soullab
python tests\test_soullab.py
```

It must end `38 checks, 0 failed` / `VERIFIED (soullab v1.0)` (about 2 minutes; synthetic data only).

```
python soullab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\soullab --check-only
```

A few minutes: checks D's input list and Soul's timing, reads Soul and 8 of D's inputs, runs the join check, and
prints how many inputs it will use and the **time estimate**. It ends `CHECK OK`. Nothing is searched or written.
Then the real run (leave the PC on):

```
python soullab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\soullab
```

It logs progress (with minutes left) and ends `SOULLAB WRITTEN C:\QuantData\soullab\SOULLAB_<date>_<nnn>`.
Time: reading every input from the panel (about the time setuplab's nodip took, times the number of inputs / 60),
then the search. Measured where it was built: about 6.2e-9 s per pair x pick for the trigger list, so with ~250 inputs
(3,000 conditions) and ~23,000 pooled picks about 11 minutes for one full trigger search, about 45 minutes with the
five replay years, plus the BUY / SKIP lists (seconds) and the bootstraps (minutes). The time grows with the square of
the number of inputs; `--check-only` prints the estimate for yours.
If it says the Soul file is missing, point it at the close-world file:
`--soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet`.

## What you get (`C:\QuantData\soullab\SOULLAB_<date>_<nnn>\`)

- **`SOULLAB.md` - read this first.** The verdict of each list (HOLDS / NOT SHOWN / WORSE), then each list's
  candidates (trades a year, net % [95%], vs all picks [95%], bad years, D / ENS trades, the replay years that chose
  the same rule, Rs a year at Rs 1 L a trade), the candidates **with a Soul condition**, the 10 best qualified or not
  (with what each failed), **Soul on its own**, the money books, the replay year by year, the checks.
- `SOULLAB_CANDIDATES.json` (hash-checked), `finalists_buy.csv`, `finalists_skip.csv`, `finalists_trigger.csv`
  (every rule fully tested), `replay_years.csv`, `replay_rules.csv`, `money.csv`, `soul_alone.csv`,
  `features.csv` (what was used and why anything was left out), `conditions.csv` (every condition with its
  cut-offs), `picks.parquet` (every pooled pick with each candidate's flag), `RUN.json`, `DECLARATION.json`,
  `outputs.sha256`; a start and an end line in `C:\QuantData\soullab\soullab_ledger.jsonl`.

Send me `SOULLAB.md` first.

## Checks built in

- **Join check:** 200 random picks' values are read again from the panel and the Soul file; every one must equal what
  the pick used (the session before D1). Otherwise the run stops.
- **Soul timing:** Soul's meta must show lag > horizon (it only uses trades finished before the day).
- **Firewall:** no `label_` column, no raw price level, ever.

## Limits

- 2020-2026 is where the engines, the tree and the setups were found. The replay re-uses those years; only the forward
  paper ledger is clean evidence. A rule you want to trade gets its own freeze and is judged forward.
- The D1-D5 path is setuplab's watchlist; lower-circuit locks are not modelled.
- Plain 95% per rule (open, as you asked): with thousands of rules some qualify by luck - the replay column is what
  separates them.
- The money books compare with plain ranks 1-3, not with the frozen tree. A rule that HOLDS is compared with the tree
  next (whylab-style), before any freeze.

## Verified (v1.0)

38 checks, 0 failed on pandas 3.0.5 / numpy 2.5.3 and pandas 2.3.3 / numpy 2.4.1. Planted bugs caught: 9 of 9 (the
first watch day, the two sessions of a move swapped, the lift without the day's mean, the replay choosing with picks
still open, the earn check always passing, the trigger trading at the D1 open, the engines' check ignored in BUY /
SKIP and in TRIGGER, the join check reading the next session). On synthetic worlds: the screens = brute force (pairs, triples, triggers by a plain loop); every condition by
hand; point in time (scrambling later values never changes a condition); the lift by hand; the earn check; the join
check passes a correct world and catches a pick reading the next session; a rule qualifies only when D and ENS each
point the same way; a planted world (a BUY, a SKIP and a TRIGGER
Soul x feature pair) - each found, each list HOLDS, the money books beat the baseline; an absent world - no list
HOLDS; the replay chooses only with picks exited before 1 January; refusals (edited declaration, output inside the
cache).
