"""
soullab.py - soullab v1.0: new rules from the Soul x model-feature interactions on the D and ENS picks.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\soullab
    python soullab.py run --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --out C:\\QuantData\\soullab
    python soullab.py run ... --check-only        inputs, counts, the join check and the time estimate; no search

Karan, 21 Nov 2026: "new rules ... and also interactions with soul + model features"; a rule decides BOTH (buy at the
D1 open or skip, AND wait for a trigger); ALL of engine D's features. The rules of the study are fixed in
SOULLAB_DECLARATION.json (beside this file, sha256-checked, written before any real run).

What it does, in plain words:
  1. Reads the picks (D and ENS, ranks 1-10, 2020-2026) from setuplab's watchlist folder - each pick's D1-D10 opens and
     closes - and, READ ONLY, every input of engine D (from PRODUCTION.json) out of panel_oc\\panel.parquet and every
     Soul v3 value (panel\\soul\\soul_v3_open.parquet). Raw price levels and label_ columns are never used.
  2. Turns each feature into 12 yes/no conditions read at a close: its level (low third, high third, lower half, upper
     half - the cut-offs come from the picks the rule is chosen on), whether it rose or fell that session, rose or fell
     the session before, and the four two-session patterns (rose twice, fell twice, turned up, turned down).
  3. Searches three lists at once, on the pooled picks (a stock picked by both engines on a day counts once):
       BUY      conditions at the signal close; buy at the D1 open, sell at the D5 close; the rule's picks must beat
                all picks of the same days
       SKIP     the same, mirrored: the rule's picks trail the day's other picks and lose money
       TRIGGER  conditions read at the close before each watch day D1..D5; buy the first open where they all hold;
                sell at the D5 close (also judged at the 'fresh' exit, 4 sessions after the entry)
     Every single condition, every pair from different families and the best pairs with a third condition. Each
     condition must earn its place. The best go through the block bootstrap (10-day blocks, 2,000 draws).
  4. Luck check: the whole search is replayed year by year (2022-2026), each year choosing with the picks that had
     fully exited before 1 January, and judged on that year only. HOLDS / NOT SHOWN / WORSE.
  5. Money from 2022: Rs 5 L in 2 / 3 / 5 / 7 slots, no MTF and MTF 2x - the plain ranks 1-3 at the D1 open against
     each list's out-of-sample arm.
Example: a BUY rule "soul_p_tp in its high third AND d_rsi14 fell on the signal day" buys, at the D1 open, every pick
whose Soul hit-rate is in the top third of the picks and whose RSI fell that day; it qualifies only if those picks beat
the other picks of the same days (95%), made money (95%), and each of the two conditions adds something on its own.

Writes only under --out: SOULLAB_<date>_<nnn>\\ (SOULLAB.md first) and a line per run in soullab_ledger.jsonl.
Research only: nothing here changes the paper test, the frozen tree or production.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
_SL_DIR = Path(os.environ.get("SETUPLAB_DIR") or (HERE.parent / "setuplab"))
if str(_SL_DIR) not in sys.path:
    sys.path.insert(0, str(_SL_DIR))
import setuplab as SU  # noqa: E402

VERSION = "soullab v1.0"
NEEDS = "setuplab v1.1"
DECL_FILE = "SOULLAB_DECLARATION.json"
LISTS = ("buy", "skip", "trigger")
LIST_NAME = {"buy": "BUY at the D1 open", "skip": "SKIP", "trigger": "TRIGGER (wait on D1-D5, buy the next open)"}
WATCH = 5
COST = SU.COST                     # 0.35 pp a round trip
MIN_PER_YEAR = 25                  # trades a year a rule must keep (pooled picks)
MAX_BAD_YEARS = 2
ENGINE_MIN = 10                    # trades a rule needs in each engine for its direction check
KEEP = 5000                        # per list, the best pairs (and triples) kept by the quick screen
EARN_WALK = 5000                   # per list, the best by the quick bound checked for every condition earning its place
TRIPLE_PAIRS = 150                 # per list, the best earning pairs that get a third condition
FINALISTS = 60                     # per list, the first earning rules that get the full block bootstrap
TOP = 5
OPEN = 10
OVERLAP = 0.70
Z = 1.96
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
WF_YEARS = (2022, 2023, 2024, 2025, 2026)
WF_MIN = 600                       # pooled picks a training window needs
GROUP = 8                          # feature columns read from a panel at a time
JOIN_SAMPLE = 200
LEVELS = (("L3", None, 0, "in its low third"), ("H3", 2, None, "in its high third"),
          ("LO", None, 1, "in its lower half"), ("HI", 1, None, "in its upper half"))
MOVES = (("up0", "rose that session"), ("dn0", "fell that session"),
         ("up1", "rose the session before"), ("dn1", "fell the session before"),
         ("upup", "rose twice (the session before and that session)"),
         ("dndn", "fell twice (the session before and that session)"),
         ("dnup", "turned up (fell the session before, rose that session)"),
         ("updn", "turned down (rose the session before, fell that session)"))
MOVE_FN = {"up0": lambda p, c: c > 0, "dn0": lambda p, c: c < 0, "up1": lambda p, c: p > 0,
           "dn1": lambda p, c: p < 0, "upup": lambda p, c: (p > 0) & (c > 0), "dndn": lambda p, c: (p < 0) & (c < 0),
           "dnup": lambda p, c: (p < 0) & (c > 0), "updn": lambda p, c: (p > 0) & (c < 0)}
BITS = np.array([1, 2, 4, 8, 16], np.uint8)
FIRST = np.full(256, 5, np.uint8)                  # lowest set bit among the five watch days (5 = none)
for _b in range(1, 256):
    _f = (_b & -_b).bit_length() - 1
    FIRST[_b] = _f if _f < 5 else 5


class SLError(Exception):
    pass


def say(msg):
    print("%s  %s" % (time.strftime("%H:%M:%S"), msg), flush=True)


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def constants():
    return {"min_per_year": MIN_PER_YEAR, "max_bad_years": MAX_BAD_YEARS, "engine_min": ENGINE_MIN, "keep": KEEP,
            "earn_walk": EARN_WALK, "triple_pairs": TRIPLE_PAIRS, "finalists": FINALISTS, "top": TOP, "open": OPEN,
            "overlap": OVERLAP, "z": Z, "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "wf_years": list(WF_YEARS),
            "wf_min": WF_MIN, "cost_pp": COST, "levels": [x[0] for x in LEVELS], "moves": [x[0] for x in MOVES]}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise SLError("no declaration at %s (it ships beside soullab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise SLError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise SLError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


# ====================================================================================================== inputs
def d_features(root):
    """Engine D's inputs: PRODUCTION.json (the frozen production D.pkl), else the frozen stage D run's stage_d.json."""
    p = Path(root) / "panel_oc" / "frozen" / "production" / "PRODUCTION.json"
    if p.is_file():
        f = json.loads(p.read_text(encoding="utf-8")).get("models", {}).get("D", {}).get("features")
        if f:
            return [str(x) for x in f], str(p), sha256_file(p)
    fz = Path(root) / "panel_oc" / "frozen" / "FROZEN_ENGINES.json"
    if fz.is_file():
        run = json.loads(fz.read_text(encoding="utf-8")).get("engines", {}).get("D", {}).get("run")
        sd = Path(root) / "panel_oc" / "stage_d" / str(run) / "stage_d.json"
        if run and sd.is_file():
            f = json.loads(sd.read_text(encoding="utf-8")).get("features")
            if f:
                return [str(x) for x in f], str(sd), sha256_file(sd)
    raise SLError("engine D's feature list not found (%s, or FROZEN_ENGINES.json's stage_d.json)" % p)


def soul_meta(path):
    """The Soul file's meta: the timing rule (lag > horizon: only finished trades) and its features."""
    path = Path(path)
    if not path.is_file():
        raise SLError("Soul file not found: %s (soul_v3.py build --entry open writes it; or pass --soul)" % path)
    mp = path.with_name(path.name[:-len(".parquet")] + "_meta.json")
    if not mp.is_file():
        raise SLError("no %s beside the Soul file - its timing cannot be checked" % mp.name)
    meta = json.loads(mp.read_text(encoding="utf-8"))
    cfg = meta.get("config") or {}
    lag, hor = cfg.get("lag"), cfg.get("horizon")
    if lag is None or hor is None or int(lag) < int(hor) + 1:
        raise SLError("the Soul file's lag (%s) is not above its horizon (%s): it could use unfinished trades" % (
            lag, hor))
    import pyarrow.parquet as pq
    have = {c.lower() for c in pq.read_schema(path).names}
    feats = [str(f).lower() for f in (meta.get("features") or []) if str(f).lower().startswith("soul_")]
    feats = [f for f in feats if f != "soul_state_missing" and "label" not in f and f in have]
    if not feats:
        raise SLError("the Soul file lists no soul_ features")
    return meta, list(dict.fromkeys(feats)), mp


def choose_features(dfeats, panel_path):
    """D's inputs we can use: never label_ (firewall), never raw price levels / codes / flags (setuplab's rule)."""
    import pyarrow.parquet as pq
    have = {c.lower() for c in pq.read_schema(panel_path).names}
    used, excl = [], []
    for f in dfeats:
        lf = str(f).lower()
        if lf.startswith("label_") or "label_" in lf:
            excl.append((f, "label_ column (firewall)"))
        elif SU.RAW_LEVEL.search(lf):
            excl.append((f, "raw price level / code / flag"))
        elif lf.endswith("_change"):
            excl.append((f, "a stored change column (its base feature's moves are used)"))
        elif lf.startswith("soul_"):
            excl.append((f, "a Soul column (read from the Soul file)"))
        elif lf not in have:
            excl.append((f, "not in the panel"))
        elif lf in used:
            excl.append((f, "listed twice"))
        else:
            used.append(lf)
    return used, excl


def load_book(data, panel, soul, dcols, scols, log=say):
    """setuplab's Book of every pick (D and ENS, ranks 1-10) with each feature at the session before each watch day
    (column 0 = the session before the signal day); read a few columns at a time, kept as float32."""
    data = Path(data)
    for nm in ("watchlist.parquet", "calendar.parquet"):
        if not (data / nm).is_file():
            raise SLError("no %s in %s (setuplab build writes the watchlist folder)" % (nm, data))
    wl = pd.read_parquet(data / "watchlist.parquet")
    cal = pd.read_parquet(data / "calendar.parquet")["date"]
    book = SU.Book(wl, cal, None, None, None, list(range(1, 11)))
    book.prev_session = True
    missing = []
    for src, cols, nm in ((panel, dcols, "D's inputs"), (soul, scols, "Soul")):
        t0 = time.time()
        for s in range(0, len(cols), GROUP):
            got, ms = book.attach(src, cols[s:s + GROUP], chunk=GROUP)
            missing += ms
            for c in got:
                for k in (c, c + "_change"):
                    if k in book.F and book.F[k].dtype != np.float32:
                        book.F[k] = book.F[k].astype(np.float32)
            if (s // GROUP) % 5 == 4 or s + GROUP >= len(cols):
                log(" read %s: %d of %d columns (%.0f s)" % (nm, min(s + GROUP, len(cols)), len(cols),
                                                              time.time() - t0))
    return book, missing


class World:
    """The complete picks (D1 open and D5 close known) with targets and every feature as float32 (n, 6) arrays."""

    def __init__(self, book, feats, soulset):
        ok = book.ok & np.isfinite(book.O[:, 1]) & np.isfinite(book.C[:, 5]) & (book.O[:, 1] > 0)
        R = np.flatnonzero(ok)
        self.n = len(R)
        self.ids = book.ids[R]
        self.day = book.signal_day[R].astype("datetime64[D]")
        self.sym = book.symbols[R].astype(str)
        self.rank = book.rank[R].astype(int)
        self.eng = book.engine_arr[R].astype(str)
        self.i1 = book.i1[R].astype(np.int64)
        self.cal = np.asarray(book.cal).astype("datetime64[D]")
        O, C = book.O[R], book.C[R]
        self.sess = np.isfinite(O[:, 1:WATCH + 1]) & (np.nan_to_num(O[:, 1:WATCH + 1]) > 0)
        with np.errstate(invalid="ignore", divide="ignore"):
            self.netA = (C[:, 5] / O[:, 1] - 1) * 100 - COST
            self.NO = np.full((self.n, WATCH), np.nan)
            self.NF = np.full((self.n, WATCH), np.nan)
            for k in range(1, WATCH + 1):
                self.NO[:, k - 1] = np.where(self.sess[:, k - 1], (C[:, 5] / O[:, k] - 1) * 100 - COST, np.nan)
                if k + 4 <= SU.PATH:
                    self.NF[:, k - 1] = np.where(self.sess[:, k - 1], (C[:, k + 4] / O[:, k] - 1) * 100 - COST,
                                                 np.nan)
        self.feats = list(feats)
        self.soul = set(soulset)
        self.V = {f: np.asarray(book.F[f][R], np.float32) for f in self.feats}
        self.Cg = {f: np.asarray(book.F[f + "_change"][R], np.float32) for f in self.feats}
        self.key = np.char.add(np.char.add(self.day.astype(str), "|"), self.sym)
        eo = np.where(self.eng == "D", 0, np.where(self.eng == "ENS", 1, 2))
        o = np.lexsort((eo, self.rank, self.key))
        ks = self.key[o]
        self.pool = np.sort(o[np.r_[True, ks[1:] != ks[:-1]]]) if self.n else np.zeros(0, int)
        self.exit9 = self.cal[np.minimum(self.i1 + 8, len(self.cal) - 1)]
        self.gap_days = int((self.cal[np.maximum(self.i1 - 1, 0)] != self.day).sum())


def make_pop(W, pos, name="pooled"):
    """A population (row positions in the World): day index, the same-day mean of the D1-open net, the lift and the
    trigger tables (row k-1 = entering on watch day k; row 5 = no entry)."""
    pos = np.asarray(pos, int)
    day = W.day[pos]
    days = np.unique(day)
    di = np.searchsorted(days, day)
    nd = len(days)
    cnt = np.bincount(di, minlength=nd)
    s = np.bincount(di, weights=W.netA[pos], minlength=nd)
    dm = (s / np.maximum(cnt, 1))[di]
    P = {"name": name, "pos": pos, "n": len(pos), "day": day, "days": days, "di": di, "nd": nd,
         "year": day.astype("datetime64[Y]").astype(int) + 1970, "years": SU._years(day) if len(day) else 0.5,
         "netA": W.netA[pos], "dm": dm, "lift": W.netA[pos] - dm, "rank": W.rank[pos], "i1": W.i1[pos],
         "sym": W.sym[pos], "key": W.key[pos]}
    z = np.zeros((1, len(pos)))
    P["NO6"] = np.vstack([W.NO[pos].T, z])
    P["NF6"] = np.vstack([W.NF[pos].T, z])
    P["TL"] = np.vstack([W.NO[pos].T - dm[None, :], z])
    P["TL"][~np.isfinite(P["TL"])] = 0.0
    return P


# ====================================================================================================== atoms
def atom_specs(feats, soulset):
    A = []
    for f in feats:
        s = f in soulset
        for code, lo_i, hi_i, w in LEVELS:
            A.append({"id": "%s:%s" % (f, code), "fam": "V|" + f, "f": f, "kind": "lvl", "code": code,
                      "lo_i": lo_i, "hi_i": hi_i, "soul": s, "words": "%s %s" % (f, w)})
        for code, w in MOVES:
            A.append({"id": "%s:%s" % (f, code), "fam": "B|" + f, "f": f, "kind": "mv", "code": code, "soul": s,
                      "words": "%s %s" % (f, w)})
    return A


def resolve(specs, W, ref_pos):
    """Level conditions get their cut-offs from the reference picks' values at the signal close (never later ones)."""
    out, qs = [], {}
    for a in specs:
        if a["kind"] != "lvl":
            out.append(dict(a))
            continue
        f = a["f"]
        if f not in qs:
            x = W.V[f][ref_pos, 1].astype(np.float64)
            x = x[np.isfinite(x)]
            qs[f] = np.quantile(x, [1 / 3, 0.5, 2 / 3]) if len(x) >= 30 else None
        q = qs[f]
        if q is None:
            continue
        lo = -np.inf if a["lo_i"] is None else float(q[a["lo_i"]])
        hi = np.inf if a["hi_i"] is None else float(q[a["hi_i"]])
        b = dict(a, lo=lo, hi=hi)
        b["words"] = a["words"] + (" (<= %.6g)" % hi if a["lo_i"] is None else " (> %.6g)" % lo)
        out.append(b)
    return out


def day_masks(atoms, W):
    """(atoms, picks) uint8: bit k-1 set when the condition holds at the close before watch day k (k = 1: the signal
    close) and watch day k has a session to buy at."""
    DM = np.zeros((len(atoms), W.n), np.uint8)
    for i, a in enumerate(atoms):
        with np.errstate(invalid="ignore"):
            if a["kind"] == "lvl":
                x = W.V[a["f"]][:, 1:WATCH + 1]
                ok = (x > a["lo"]) & (x <= a["hi"])
            else:
                c = W.Cg[a["f"]]
                ok = MOVE_FN[a["code"]](c[:, 0:WATCH], c[:, 1:WATCH + 1])
        ok &= W.sess
        DM[i] = (ok.astype(np.uint8) * BITS).sum(1).astype(np.uint8)
    return DM


def fam_ids(atoms):
    u = {}
    return np.array([u.setdefault(a["fam"], len(u)) for a in atoms], np.int64)


# ====================================================================================================== the screens
def _prune(store, k):
    """Keep the k best rows (by the quick bound) of a store {lb, rules (m, 3) int with -1 = unused, n, mean}."""
    if store is None or len(store["lb"]) <= k:
        return store
    idx = np.argpartition(-store["lb"], k - 1)[:k]
    return {key: v[idx] for key, v in store.items()}


def _add(store, lb, rules, n, mean, k):
    if not len(lb):
        return store
    new = {"lb": np.asarray(lb, float), "rules": np.asarray(rules, np.int32).reshape(-1, 3),
           "n": np.asarray(n, float), "mean": np.asarray(mean, float)}
    if store is not None:
        new = {key: np.concatenate([store[key], new[key]]) for key in new}
    return _prune(new, k) if len(new["lb"]) > 2 * k else new


def _iid_lb(N, S1, S2, sign):
    """mean and the quick 95% lower bound (iid standard error) of sign * y over each rule's picks."""
    with np.errstate(invalid="ignore", divide="ignore"):
        m = S1 / N
        var = np.maximum(S2 - S1 * m, 0) / np.maximum(N - 1, 1)
        se = np.sqrt(var / N)
        return sign * m, sign * m - Z * se


def _r3(a, b=None, c=None):
    a = np.asarray(a, np.int32)
    b = np.full(len(a), -1, np.int32) if b is None else np.asarray(b, np.int32)
    c = np.full(len(a), -1, np.int32) if c is None else np.asarray(c, np.int32)
    return np.column_stack([a, b, c])


def screen_open(MAb, y, fam, min_n, keep, signs=(("buy", 1.0), ("skip", -1.0)), block=512):
    """Singles and every pair from different families, the target y (the lift) on the rule's picks (bought at the D1
    open), for each list's sign - all pairs at once through matrix products (counts and sums of y and y^2)."""
    A, n = MAb.shape
    MA = MAb.astype(np.float32)
    yv, y2 = y.astype(np.float32), (y * y).astype(np.float32)
    N1 = MA.sum(1, dtype=np.float64)
    S11, S21 = (MA @ yv).astype(np.float64), (MA @ y2).astype(np.float64)
    out = {}
    for lst, sg in signs:
        m, lb = _iid_lb(N1, S11, S21, sg)
        out[lst] = {"singles": {"lb": np.where(N1 >= min_n, lb, -np.inf), "rules": _r3(np.arange(A)), "n": N1,
                                "mean": m}, "pairs": None}
    MAT = MA.T
    jj = np.arange(A)[None, :]
    for s in range(0, A, block):
        e = min(A, s + block)
        Mb = MA[s:e]
        N = (Mb @ MAT).astype(np.float64)
        S1 = ((Mb * yv) @ MAT).astype(np.float64)
        S2 = ((Mb * y2) @ MAT).astype(np.float64)
        valid = (jj > np.arange(s, e)[:, None]) & (fam[None, :] != fam[s:e, None]) & (N >= min_n)
        if not valid.any():
            continue
        ii, jx = np.nonzero(valid)
        Nv, S1v, S2v = N[ii, jx], S1[ii, jx], S2[ii, jx]
        for lst, sg in signs:
            mv, lbv = _iid_lb(Nv, S1v, S2v, sg)
            kk = min(keep, len(lbv))
            idx = np.argpartition(-lbv, kk - 1)[:kk] if len(lbv) > kk else np.arange(len(lbv))
            out[lst]["pairs"] = _add(out[lst]["pairs"], lbv[idx], _r3(ii[idx] + s, jx[idx]), Nv[idx], mv[idx], keep)
    for lst, _ in signs:
        out[lst]["pairs"] = _prune(out[lst]["pairs"], keep)
    return out


def screen_open_triples(MAb, y, fam, pairs, min_n, keep, sign):
    """The given pairs with one more condition from another family."""
    A, n = MAb.shape
    MA = MAb.astype(np.float32)
    yv, y2 = y.astype(np.float32), (y * y).astype(np.float32)
    store, seen = None, set()
    for c in pairs:
        x = MA[c[0]] * MA[c[1]]
        N = (MA @ x).astype(np.float64)
        S1 = (MA @ (x * yv)).astype(np.float64)
        S2 = (MA @ (x * y2)).astype(np.float64)
        ks = np.flatnonzero((N >= min_n) & (fam != fam[c[0]]) & (fam != fam[c[1]]))
        R = np.sort(np.column_stack([np.full(len(ks), c[0]), np.full(len(ks), c[1]), ks]), axis=1)
        new = np.array([tuple(r) not in seen for r in R], bool) if len(R) else np.zeros(0, bool)
        if not new.any():
            continue
        seen.update(tuple(r) for r in R[new])
        ks = ks[new]
        m, lb = _iid_lb(N[ks], S1[ks], S2[ks], sign)
        store = _add(store, lb, R[new], N[ks], m, keep)
    return _prune(store, keep)


def _trig_block(B, TLr, n, ar):
    K = FIRST[B]
    cnt = (K < 5).sum(1).astype(np.float64)
    G = TLr[K.astype(np.int32) * n + ar]
    return cnt, G.sum(1, dtype=np.float64), np.einsum("ij,ij->i", G, G, dtype=np.float64)


def screen_trigger(DMp, TL, fam, min_n, keep, log=None, block=1024):
    """Singles and every pair from different families as triggers: the first watch day whose bits all hold -> the entry
    on that day's open; target = the trade's net (D5 close) minus the signal day's mean D1-open net of all picks."""
    A, n = DMp.shape
    TLr = np.ascontiguousarray(TL.astype(np.float32)).ravel()
    ar = np.arange(n, dtype=np.int32)
    active = (DMp != 0).sum(1) >= min_n
    cnt, S1, S2 = np.zeros(A), np.zeros(A), np.zeros(A)
    for s in range(0, A, block):
        c, a1, a2 = _trig_block(DMp[s:s + block], TLr, n, ar)
        cnt[s:s + block], S1[s:s + block], S2[s:s + block] = c, a1, a2
    m, lb = _iid_lb(cnt, S1, S2, 1.0)
    singles = {"lb": np.where(cnt >= min_n, lb, -np.inf), "rules": _r3(np.arange(A)), "n": cnt, "mean": m}
    store, t0, idxs = None, time.time(), np.arange(A)
    work = np.array([((active & (fam != fam[i]) & (idxs > i)).sum() if active[i] else 0) for i in range(A)], float)
    total, done, next_report = work.sum(), 0.0, 0.05
    for i in range(A):
        if not active[i]:
            continue
        J = np.flatnonzero(active & (fam != fam[i]) & (idxs > i))
        for s in range(0, len(J), block):
            Jb = J[s:s + block]
            c, a1, a2 = _trig_block(DMp[Jb] & DMp[i], TLr, n, ar)
            ok = c >= min_n
            if not ok.any():
                continue
            mv, lbv = _iid_lb(c[ok], a1[ok], a2[ok], 1.0)
            store = _add(store, lbv, _r3(np.full(int(ok.sum()), i), Jb[ok]), c[ok], mv, keep)
        done += work[i]
        if log and total and done / total >= next_report:
            el = time.time() - t0
            log("   trigger pairs: %.0f%% (%.0f min so far, about %.0f min to go)" % (
                100 * done / total, el / 60, el / 60 * (total - done) / max(done, 1)))
            next_report += 0.05
    return {"singles": singles, "pairs": _prune(store, keep)}


def screen_trigger_triples(DMp, TL, fam, pairs, min_n, keep, block=1024):
    A, n = DMp.shape
    TLr = np.ascontiguousarray(TL.astype(np.float32)).ravel()
    ar = np.arange(n, dtype=np.int32)
    active = (DMp != 0).sum(1) >= min_n
    store, seen = None, set()
    for c in pairs:
        base = DMp[c[0]] & DMp[c[1]]
        ks = np.flatnonzero(active & (fam != fam[c[0]]) & (fam != fam[c[1]]))
        R = np.sort(np.column_stack([np.full(len(ks), c[0]), np.full(len(ks), c[1]), ks]), axis=1)
        new = np.array([tuple(r) not in seen for r in R], bool) if len(R) else np.zeros(0, bool)
        ks, R = ks[new], R[new]
        seen.update(tuple(r) for r in R)
        for s in range(0, len(ks), block):
            kb = ks[s:s + block]
            cn, a1, a2 = _trig_block(DMp[kb] & base, TLr, n, ar)
            ok = cn >= min_n
            if not ok.any():
                continue
            mv, lbv = _iid_lb(cn[ok], a1[ok], a2[ok], 1.0)
            store = _add(store, lbv, R[s:s + block][ok], cn[ok], mv, keep)
    return _prune(store, keep)


# ====================================================================================================== rules
def open_mask(MAb, c):
    m = MAb[c[0]].copy()
    for x in c[1:]:
        m &= MAb[x]
    return m


def trig_entries(DMp, c):
    """The watch day index (0 = D1 ... 4 = D5) of the first open where every condition holds; 5 = no entry."""
    b = DMp[c[0]].copy()
    for x in c[1:]:
        b &= DMp[x]
    return FIRST[b]


def earn_quick_open(MAb, c, y, di, nd):
    """The smallest quick 95% lower bound, over the rule's conditions, of: its target minus the target of the picks its
    simpler version (that condition dropped) adds. +inf for one condition; -inf when a simpler version adds none."""
    if len(c) < 2:
        return np.inf
    m = open_mask(MAb, c)
    ic, out = np.flatnonzero(m), np.inf
    for d in range(len(c)):
        x = open_mask(MAb, c[:d] + c[d + 1:]) & ~m
        ix = np.flatnonzero(x)
        v = SU._dlb(di[ic], y[ic], di[ix], y[ix], nd)
        if not np.isfinite(v) or v <= 0:
            return v if np.isfinite(v) else -np.inf
        out = min(out, v)
    return out


def earn_quick_trig(DMp, c, TL, di, nd):
    if len(c) < 2:
        return np.inf
    ar = np.arange(DMp.shape[1])
    K = trig_entries(DMp, c)
    m = K < 5
    val = TL[K, ar]
    out = np.inf
    for d in range(len(c)):
        Ks = trig_entries(DMp, c[:d] + c[d + 1:])
        x = (Ks < 5) & ~m
        vx = TL[Ks, ar]
        v = SU._dlb(di[m], val[m], di[x], vx[x], nd)
        if not np.isfinite(v) or v <= 0:
            return v if np.isfinite(v) else -np.inf
        out = min(out, v)
    return out


def walk(store_list, min_n, k, earnf, size=None, limit=EARN_WALK):
    """Rules in the order of their quick bound; each checked for every condition earning its place; the first k that
    pass (at most `limit` checked). store_list: stores to merge. -> (rules, quick bounds, checked)."""
    lb = np.concatenate([s["lb"] for s in store_list if s is not None]) if any(
        s is not None for s in store_list) else np.zeros(0)
    if not len(lb):
        return [], [], 0
    rules = np.concatenate([s["rules"] for s in store_list if s is not None])
    n = np.concatenate([s["n"] for s in store_list if s is not None])
    out, qb, walked, seen = [], [], 0, set()
    for i in np.argsort(-np.where(np.isfinite(lb) & (n >= min_n), lb, -np.inf), kind="stable"):
        if not np.isfinite(lb[i]) or n[i] < min_n or len(out) == k or walked >= limit:
            break
        r = tuple(int(x) for x in rules[i] if x >= 0)
        if (size and len(r) != size) or r in seen:
            continue
        seen.add(r)
        walked += 1
        if earnf(r) > 0:
            out.append(r)
            qb.append(float(lb[i]))
    return out, qb, walked


def _ci(boot, di, v):
    v = np.asarray(v, float)
    ok = np.isfinite(v)
    if ok.sum() < 2:
        return np.nan, np.nan
    return boot.ci_idx(di[ok], v[ok])


def _years_bad(year, v, bad):
    u = np.unique(year)
    return int(len(u)), int(sum(bad(float(np.mean(v[year == y]))) for y in u))


def eval_open(lst, c, P, MAb, boot, EP):
    m = open_mask(MAb, c)
    n = int(m.sum())
    di = P["di"]
    r = {"n": n, "per_year": n / P["years"]}
    r["lift"] = float(P["lift"][m].mean()) if n else np.nan
    r["net"] = float(P["netA"][m].mean()) if n else np.nan
    r["lift_lo"], r["lift_hi"] = _ci(boot, di[m], P["lift"][m])
    r["net_lo"], r["net_hi"] = _ci(boot, di[m], P["netA"][m])
    y = P["lift"] if lst == "buy" else -P["lift"]
    r["earn_lo"] = np.inf
    if len(c) > 1:
        los = []
        for d in range(len(c)):
            x = open_mask(MAb, c[:d] + c[d + 1:]) & ~m
            los.append(boot.ci_diff(di[m], y[m], di[x], y[x])[0] if n >= 2 and x.sum() >= 2 else -np.inf)
        r["earn_lo"] = float(np.nanmin(los)) if np.isfinite(los).any() else -np.inf
    if n:
        if lst == "buy":
            r["years"], r["bad_years"] = _years_bad(P["year"][m], P["netA"][m], lambda v: v <= 0)
        else:
            r["years"], r["bad_years"] = _years_bad(P["year"][m], P["lift"][m], lambda v: v >= 0)
    else:
        r["years"], r["bad_years"] = 0, 0
    cons = True
    for nm, PE, MAbE in EP:
        me = open_mask(MAbE, c)
        ne = int(me.sum())
        le = float(PE["lift"][me].mean()) if ne else np.nan
        nt = float(PE["netA"][me].mean()) if ne else np.nan
        r.update({nm + "_n": ne, nm + "_lift": le, nm + "_net": nt})
        cons = cons and ne >= ENGINE_MIN and ((le > 0 and nt > 0) if lst == "buy" else (le < 0))
    r["engines_agree"] = bool(cons)
    earn_ok = len(c) == 1 or r["earn_lo"] > 0
    if lst == "buy":
        q = (r["per_year"] >= MIN_PER_YEAR and r["lift_lo"] > 0 and r["net_lo"] > 0 and earn_ok
             and r["bad_years"] <= MAX_BAD_YEARS and cons)
        r["score"] = r["lift_lo"]
        r["rs_year"] = r["per_year"] * r["net"] * 1000.0
    else:
        q = (r["per_year"] >= MIN_PER_YEAR and r["lift_hi"] < 0 and r["net"] < 0 and earn_ok
             and r["bad_years"] <= MAX_BAD_YEARS and cons)
        r["score"] = -r["lift_hi"] if np.isfinite(r["lift_hi"]) else np.nan
        r["rs_year"] = -r["per_year"] * r["net"] * 1000.0
    r["qualifies"] = bool(q)
    return r


def eval_trig(c, P, DMp, boot, EP):
    ar = np.arange(P["n"])
    K = trig_entries(DMp, c)
    m = K < 5
    n = int(m.sum())
    di = P["di"]
    lift = P["TL"][K, ar][m]
    no = P["NO6"][K, ar][m]
    nf = P["NF6"][K, ar][m]
    d1 = no - P["netA"][m]
    r = {"n": n, "per_year": n / P["years"]}
    for nm, v in (("lift", lift), ("net", no), ("net_fresh", nf), ("vs_d1", d1)):
        r[nm] = float(np.nanmean(v)) if n and np.isfinite(v).any() else np.nan
        r[nm + "_lo"], r[nm + "_hi"] = _ci(boot, di[m], v)
    r["entry_day"] = float((K[m] + 1).mean()) if n else np.nan
    r["on_d1"] = float((K[m] == 0).mean()) if n else np.nan
    r["earn_lo"] = np.inf
    if len(c) > 1:
        los = []
        for d in range(len(c)):
            Ks = trig_entries(DMp, c[:d] + c[d + 1:])
            x = (Ks < 5) & ~m
            vx = P["TL"][Ks, ar][x]
            los.append(boot.ci_diff(di[m], lift, di[x], vx)[0] if n >= 2 and x.sum() >= 2 else -np.inf)
        r["earn_lo"] = float(np.nanmin(los)) if np.isfinite(los).any() else -np.inf
    r["years"], r["bad_years"] = _years_bad(P["year"][m], no, lambda v: v <= 0) if n else (0, 0)
    cons = True
    for nm, PE, DME in EP:
        ke = trig_entries(DME, c)
        me = ke < 5
        ne = int(me.sum())
        are = np.arange(PE["n"])
        noe = PE["NO6"][ke, are][me]
        ne_net = float(noe.mean()) if ne else np.nan
        ne_d1 = float((noe - PE["netA"][me]).mean()) if ne else np.nan
        r.update({nm + "_n": ne, nm + "_net": ne_net, nm + "_vs_d1": ne_d1})
        cons = cons and ne >= ENGINE_MIN and ne_net > 0 and ne_d1 > 0
    r["engines_agree"] = bool(cons)
    earn_ok = len(c) == 1 or r["earn_lo"] > 0
    r["qualifies"] = bool(r["per_year"] >= MIN_PER_YEAR and r["lift_lo"] > 0 and r["net_lo"] > 0
                          and r["net_fresh_lo"] > 0 and r["vs_d1_lo"] > 0 and earn_ok
                          and r["bad_years"] <= MAX_BAD_YEARS and cons)
    r["score"] = r["lift_lo"]
    r["rs_year"] = r["per_year"] * r["net"] * 1000.0 if n else np.nan
    return r


# ====================================================================================================== the search
def _table(rows, atoms):
    T = pd.DataFrame(rows)
    if len(T):
        T.insert(0, "rule", [" & ".join(atoms[x]["id"] for x in c) for c in T["cand"]])
        T.insert(1, "text", [" AND ".join(atoms[x]["words"] for x in c) for c in T["cand"]])
        T.insert(2, "soul", [any(atoms[x]["soul"] for x in c) for c in T["cand"]])
        T.insert(3, "size", [len(c) for c in T["cand"]])
        T = T.sort_values(["qualifies", "score"], ascending=[False, False], kind="stable").reset_index(drop=True)
    return T


def search_open(P, atoms, MAb, EP, log=lambda *a: None):
    """BUY and SKIP on population P. -> {list: (finalists table, counts)}"""
    fam = fam_ids(atoms)
    min_n = MIN_PER_YEAR * P["years"]
    S = screen_open(MAb, P["lift"].astype(np.float64), fam, min_n, KEEP)
    boot = SU.Boot(P["day"], B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    out = {}
    for lst, sign in (("buy", 1.0), ("skip", -1.0)):
        y = sign * P["lift"]

        def earnf(c):
            return earn_quick_open(MAb, c, y, P["di"], P["nd"])
        pairs, _, w0 = walk([S[lst]["pairs"]], min_n, TRIPLE_PAIRS, earnf, size=2)
        T3 = screen_open_triples(MAb, P["lift"].astype(np.float64), fam, pairs, min_n, KEEP, sign)
        fin, qb, w1 = walk([S[lst]["singles"], S[lst]["pairs"], T3], min_n, FINALISTS, earnf)
        rows = []
        for c, q in zip(fin, qb):
            rows.append({"cand": c, "screen_lb": q, **eval_open(lst, c, P, MAb, boot, EP)})
        T = _table(rows, atoms)
        cnt = {"singles": int(np.isfinite(S[lst]["singles"]["lb"]).sum()),
               "pairs_kept": len(S[lst]["pairs"]["lb"]) if S[lst]["pairs"] is not None else 0,
               "triples_kept": len(T3["lb"]) if T3 is not None else 0, "earn_checked": w0 + w1,
               "finalists": len(T), "qualify": int(T["qualifies"].sum()) if len(T) else 0}
        out[lst] = (T, cnt)
        log("   %s: %d finalists, %d qualify" % (lst, cnt["finalists"], cnt["qualify"]))
    return out


def search_trig(P, atoms, DMp, EP, log=lambda *a: None):
    fam = fam_ids(atoms)
    min_n = MIN_PER_YEAR * P["years"]
    S = screen_trigger(DMp, P["TL"], fam, min_n, KEEP, log)
    boot = SU.Boot(P["day"], B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)

    def earnf(c):
        return earn_quick_trig(DMp, c, P["TL"], P["di"], P["nd"])
    pairs, _, w0 = walk([S["pairs"]], min_n, TRIPLE_PAIRS, earnf, size=2)
    T3 = screen_trigger_triples(DMp, P["TL"], fam, pairs, min_n, KEEP)
    fin, qb, w1 = walk([S["singles"], S["pairs"], T3], min_n, FINALISTS, earnf)
    rows = [{"cand": c, "screen_lb": q, **eval_trig(c, P, DMp, boot, EP)} for c, q in zip(fin, qb)]
    T = _table(rows, atoms)
    cnt = {"singles": int(np.isfinite(S["singles"]["lb"]).sum()),
           "pairs_kept": len(S["pairs"]["lb"]) if S["pairs"] is not None else 0,
           "triples_kept": len(T3["lb"]) if T3 is not None else 0, "earn_checked": w0 + w1, "finalists": len(T),
           "qualify": int(T["qualifies"].sum()) if len(T) else 0}
    log("   trigger: %d finalists, %d qualify" % (cnt["finalists"], cnt["qualify"]))
    return {"trigger": (T, cnt)}


def rule_keys(lst, c, P, MAb, DMp):
    if lst == "trigger":
        return set(P["key"][trig_entries(DMp, c) < 5])
    return set(P["key"][open_mask(MAb, c)])


def pick_top(T, lst, P, MAb, DMp, k=TOP, only_q=True, need=None):
    """The best rules that are not versions of each other (one's conditions within the other's, or 70% of the same
    picks)."""
    chosen = []
    if T is None or not len(T):
        return []
    for r in T.itertuples(index=False):
        if only_q and not r.qualifies:
            continue
        c = tuple(r.cand)
        if need is not None and not need(c):
            continue
        sc, keys = set(c), rule_keys(lst, c, P, MAb, DMp)
        if any(set(c2) <= sc or sc <= set(c2) or SU.overlap(keys, k2) >= OVERLAP for c2, k2 in chosen):
            continue
        chosen.append((c, keys))
        if len(chosen) == k:
            break
    return [c for c, _ in chosen]


def masks_for(atoms, W, pos_list):
    DM = day_masks(atoms, W)
    return DM, [(DM[:, p], (DM[:, p] & 1).astype(bool)) for p in pos_list]


def run_search(W, atoms, P, EPs, lists, log=say):
    """One full search on population P (engine populations EPs) -> {list: (table, counts)}, and the masks."""
    DM, mk = masks_for(atoms, W, [P["pos"]] + [E["pos"] for _, E in EPs])
    DMp, MAb = mk[0]
    EPo = [(nm, E, mk[i + 1][1]) for i, (nm, E) in enumerate(EPs)]
    EPt = [(nm, E, mk[i + 1][0]) for i, (nm, E) in enumerate(EPs)]
    res = {}
    if "buy" in lists or "skip" in lists:
        res.update(search_open(P, atoms, MAb, EPo, log))
    if "trigger" in lists:
        res.update(search_trig(P, atoms, DMp, EPt, log))
    return res, DM, DMp, MAb


# ====================================================================================================== replay
def replay(W, specs, lists=LISTS, log=say):
    """The search replayed year by year: cut-offs and rules from the pooled picks whose last possible exit (the D9
    close) was before 1 January; the top rules judged on that year's picks."""
    rows, rrows, sel = [], [], {lst: [] for lst in lists}
    test_all = []
    for Y in WF_YEARS:
        cut, nxt = np.datetime64("%d-01-01" % Y), np.datetime64("%d-01-01" % (Y + 1))
        pool = W.pool
        tr = pool[W.exit9[pool] < cut]
        te = pool[(W.day[pool] >= cut) & (W.day[pool] < nxt)]
        if len(tr) < WF_MIN or not len(te):
            rows.append({"year": Y, "train_picks": len(tr), "test_picks": len(te), "note": "too few picks"})
            continue
        log(" replay %d: choosing with %d pooled picks (exits before %s), judging %d" % (Y, len(tr), cut, len(te)))
        atoms = resolve(specs, W, tr)
        Ptr = make_pop(W, tr, "train")
        EPs = []
        for e in ("D", "ENS"):
            pe = np.flatnonzero((W.eng == e) & (W.exit9 < cut))
            if len(pe):
                EPs.append((e, make_pop(W, pe, e)))
        res, DM, DMp, MAb = run_search(W, atoms, Ptr, EPs, lists, log)
        Pte = make_pop(W, te, "test")
        test_all.append(te)
        DMt = DM[:, te]
        MAt = (DMt & 1).astype(bool)
        row = {"year": Y, "train_picks": len(tr), "train_last_exit": str(W.exit9[tr].max()),
               "test_picks": len(te), "all_net": float(Pte["netA"].mean())}
        ar = np.arange(Pte["n"])
        for lst in lists:
            T = res[lst][0]
            top = pick_top(T, lst, Ptr, MAb, DMp)
            row[lst + "_rules"] = "; ".join(" & ".join(atoms[x]["id"] for x in c) for c in top) or "none qualified"
            if lst == "trigger":
                K = np.full(Pte["n"], 5, np.uint8)
                for c in top:
                    K = np.minimum(K, trig_entries(DMt, c))
                m = K < 5
                if m.any():
                    sel[lst].append(pd.DataFrame({"pos": te[m], "k": K[m].astype(int), "day": Pte["day"][m],
                                                  "lift": Pte["TL"][K, ar][m], "net": Pte["NO6"][K, ar][m],
                                                  "vs_d1": Pte["NO6"][K, ar][m] - Pte["netA"][m]}))
                row[lst + "_n"] = int(m.sum())
                row[lst + "_lift"] = float(Pte["TL"][K, ar][m].mean()) if m.any() else np.nan
                row[lst + "_net"] = float(Pte["NO6"][K, ar][m].mean()) if m.any() else np.nan
                for c in top:
                    kc = trig_entries(DMt, c)
                    mc = kc < 5
                    rrows.append({"year": Y, "list": lst, "rule": " & ".join(atoms[x]["id"] for x in c),
                                  "n": int(mc.sum()), "lift": float(Pte["TL"][kc, ar][mc].mean()) if mc.any() else
                                  np.nan, "net": float(Pte["NO6"][kc, ar][mc].mean()) if mc.any() else np.nan})
            else:
                m = np.zeros(Pte["n"], bool)
                for c in top:
                    m |= open_mask(MAt, c)
                if m.any():
                    sel[lst].append(pd.DataFrame({"pos": te[m], "k": 0, "day": Pte["day"][m],
                                                  "lift": Pte["lift"][m], "net": Pte["netA"][m]}))
                row[lst + "_n"] = int(m.sum())
                row[lst + "_lift"] = float(Pte["lift"][m].mean()) if m.any() else np.nan
                row[lst + "_net"] = float(Pte["netA"][m].mean()) if m.any() else np.nan
                for c in top:
                    mc = open_mask(MAt, c)
                    rrows.append({"year": Y, "list": lst, "rule": " & ".join(atoms[x]["id"] for x in c),
                                  "n": int(mc.sum()), "lift": float(Pte["lift"][mc].mean()) if mc.any() else np.nan,
                                  "net": float(Pte["netA"][mc].mean()) if mc.any() else np.nan})
        rows.append(row)
        log(" replay %d done: " % Y + "; ".join("%s %d picks" % (lst, row[lst + "_n"]) for lst in lists))
    verdicts = {}
    allte = np.unique(np.concatenate(test_all)) if test_all else np.zeros(0, int)
    days = np.unique(W.day[allte]) if len(allte) else np.zeros(0, "datetime64[D]")
    boot = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED) if len(days) >= 2 else None
    for lst in lists:
        S = pd.concat(sel[lst], ignore_index=True) if sel[lst] else pd.DataFrame(columns=["pos", "day", "lift"])
        v = {"list": lst, "picks": int(len(S)), "lift": float(S["lift"].mean()) if len(S) else np.nan,
             "net": float(S["net"].mean()) if len(S) else np.nan, "lift_lo": np.nan, "lift_hi": np.nan}
        if boot is not None and len(S) >= 2:
            v["lift_lo"], v["lift_hi"] = boot.ci_idx(np.searchsorted(boot.days, S["day"].to_numpy()),
                                                     S["lift"].to_numpy(float))
        if lst == "trigger" and len(S) >= 2 and boot is not None:
            v["vs_d1"] = float(S["vs_d1"].mean())
            v["vs_d1_lo"], v["vs_d1_hi"] = boot.ci_idx(np.searchsorted(boot.days, S["day"].to_numpy()),
                                                       S["vs_d1"].to_numpy(float))
        lo, hi = v["lift_lo"], v["lift_hi"]
        if not len(S):
            v["verdict"] = "NO RULE CHOSEN"
        elif lst == "skip":
            v["verdict"] = "HOLDS" if hi < 0 else "WORSE" if lo > 0 else "NOT SHOWN"
        else:
            v["verdict"] = "HOLDS" if lo > 0 else "WORSE" if hi < 0 else "NOT SHOWN"
        verdicts[lst] = v
    return pd.DataFrame(rows), pd.DataFrame(rrows), verdicts, sel


# ====================================================================================================== money
def money(W, base_pos, arms):
    """setuplab's money book (Rs 5 L; 2 / 3 / 5 / 7 slots; no MTF and MTF 2x; from 2022): the pooled ranks 1-3 at the
    D1 open, and each arm {name: (positions, entry watch-day index 0-4, net %)}."""
    def frame(pos, k, net):
        pos = np.asarray(pos, int)
        return pd.DataFrame({"pick": W.key[pos], "ent": W.i1[pos] + np.asarray(k, int), "ex": W.i1[pos] + 4,
                             "net": np.asarray(net, float), "prio": W.rank[pos].astype(float), "sym": W.sym[pos]})
    books = {"baseline: pooled ranks 1-3 at the D1 open": frame(base_pos, np.zeros(len(base_pos)), W.netA[base_pos])}
    for name, (pos, k, net) in arms.items():
        if len(pos):
            books[name] = frame(pos, k, net)
    return SU.run_money(books, W.cal)


# ====================================================================================================== checks
def join_check(W, panel, soul, dcols, scols, k=JOIN_SAMPLE, seed=7):
    """The value each pick reads at the signal close = the file's row for that stock on the session before D1."""
    import pyarrow.parquet as pq
    rng = np.random.default_rng(seed)
    if not len(W.pool):
        return {"checked": 0, "mismatches": 0, "examples": []}
    rows = rng.choice(W.pool, size=min(k, len(W.pool)), replace=False)
    want_day = W.cal[np.maximum(W.i1[rows] - 1, 0)]
    syms = sorted(set(W.sym[rows]))
    out = {"checked": 0, "mismatches": 0, "examples": []}
    for src, cols in ((panel, list(rng.permutation(dcols)[:8]) if dcols else []), (soul, list(scols[:8]))):
        if not cols:
            continue
        names = pq.read_schema(src).names
        low = {c.lower(): c for c in names}
        dk = low.get("timestamp") or low.get("date")
        rc = [low["symbol"], dk] + [low[c] for c in cols]
        try:
            F = pq.read_table(src, columns=rc, filters=[(low["symbol"], "in", syms)]).to_pandas()
        except Exception:  # noqa: BLE001 - a reader without filters
            F = pd.read_parquet(src, columns=rc)
        F.columns = [str(c).lower() for c in F.columns]
        dkl = dk.lower()
        t = pd.to_datetime(F[dkl])
        if getattr(t.dt, "tz", None) is not None:
            t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        F["_d"] = t.dt.normalize().to_numpy().astype("datetime64[D]")
        F["symbol"] = F["symbol"].astype(str).str.strip().str.upper()
        F = F.drop_duplicates(["symbol", "_d"]).set_index(["symbol", "_d"])
        for c in cols:
            for r, d in zip(rows, want_day):
                a = float(W.V[c][r, 1])
                try:
                    b = float(F.at[(W.sym[r], d), c])
                except KeyError:
                    b = np.nan
                out["checked"] += 1
                same = (np.isnan(a) and np.isnan(b)) or (np.isfinite(a) and np.isfinite(b) and
                                                         abs(a - b) <= 1e-6 * max(1.0, abs(b)))
                if not same:
                    out["mismatches"] += 1
                    if len(out["examples"]) < 5:
                        out["examples"].append("%s %s %s: pick reads %r, file has %r" % (W.sym[r], d, c, a, b))
    return out


def guard_out(out, root):
    o = Path(out).resolve()
    bad = [Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(), _SL_DIR.resolve()]
    for b in bad:
        if o == b or b in o.parents:
            raise SLError("--out %s is inside %s - outputs go under C:\\QuantData\\soullab" % (o, b))
    return o


def ledger(out, rec):
    with open(Path(out) / "soullab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


# ====================================================================================================== report
def _p(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "n/a"
    return ("%+.*f" if sign else "%.*f") % (nd, x)


def _ci_txt(r, k, nd=2):
    return "%s [%s, %s]" % (_p(r.get(k), nd), _p(r.get(k + "_lo"), nd), _p(r.get(k + "_hi"), nd))


def cand_table(lst, T, cands, evid):
    if not cands:
        return ["No rule qualifies.", ""]
    L = []
    if lst == "trigger":
        L += ["| # | rule | trades/yr | net % (D5 close) [95%] | fresh exit % | vs all picks, same days, pp [95%] | "
              "vs D1 on the same picks, pp [95%] | entry day | bad years | D / ENS | chosen in the replay | Rs a year "
              "at Rs 1 L a trade |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    else:
        L += ["| # | rule | trades/yr | net % (D1 open to D5 close) [95%] | vs all picks, same days, pp [95%] | "
              "bad years | D / ENS | chosen in the replay | Rs a year at Rs 1 L a trade" +
              (" (saved by skipping)" if lst == "skip" else "") + " |", "|---|---|---|---|---|---|---|---|---|"]
    for i, c in enumerate(cands, 1):
        r = T[T["cand"].apply(lambda x: tuple(x) == tuple(c))].iloc[0].to_dict()
        eng = "%d / %d" % (r.get("D_n", 0), r.get("ENS_n", 0))
        ev = evid.get(r["rule"], "never chosen")
        if lst == "trigger":
            L.append("| %d | %s | %.1f | %s | %s | %s | %s | %.2f | %d of %d | %s | %s | %s |" % (
                i, r["text"], r["per_year"], _ci_txt(r, "net"), _ci_txt(r, "net_fresh"), _ci_txt(r, "lift"),
                _ci_txt(r, "vs_d1"), r["entry_day"], r["bad_years"], r["years"], eng, ev,
                "{:,.0f}".format(r["rs_year"]) if np.isfinite(r["rs_year"]) else "n/a"))
        else:
            L.append("| %d | %s | %.1f | %s | %s | %d of %d | %s | %s | %s |" % (
                i, r["text"], r["per_year"], _ci_txt(r, "net"), _ci_txt(r, "lift"), r["bad_years"], r["years"], eng,
                ev, "{:,.0f}".format(r["rs_year"]) if np.isfinite(r["rs_year"]) else "n/a"))
    return L + [""]


def write_report(d, info, results, cands, soulc, open_l, verdicts, WFY, WFR, MO, singles, evid):
    L = ["# soullab v1.0 - new rules from Soul x engine D's inputs (%s)" % d.name, "",
         "%s | %s | declaration %s | %s" % (VERSION, SU.VERSION, info["declaration_sha"][:16], info["finished"]), "",
         "Research only: every number below is on 2020-2026, the years the engines were studied on. A rule worth "
         "trading is frozen on its own and judged by the forward paper ledger; the frozen tree does not change.", "",
         "## Verdict (the luck check: the search replayed year by year, 2022-2026)", "",
         "| list | out-of-sample picks | their net % | vs all picks of the same days, pp [95%] | verdict |",
         "|---|---|---|---|---|"]
    for lst in LISTS:
        v = verdicts.get(lst, {})
        L.append("| %s | %d | %s | %s | **%s** |" % (LIST_NAME[lst], v.get("picks", 0), _p(v.get("net")),
                                                     "%s [%s, %s]" % (_p(v.get("lift")), _p(v.get("lift_lo")),
                                                                      _p(v.get("lift_hi"))),
                                                     v.get("verdict", "not run")))
    L += ["", "HOLDS = each year's chosen rules, judged only on that year, beat all picks of the same days (95%; SKIP: "
          "trailed them). NOT SHOWN = no clear difference out of sample: what the in-sample lists show may be luck. "
          "WORSE = the wrong side.", ""]
    for lst in LISTS:
        T, cnt = results[lst]
        L += ["## %s - candidates (in-sample, plain 95%% per rule)" % LIST_NAME[lst], "",
              "Searched: %d single conditions, the best %d pairs and %d triples kept by the quick screen, %d checked "
              "for every condition earning its place, %d through the block bootstrap; **%d qualify**." % (
                  cnt["singles"], cnt["pairs_kept"], cnt["triples_kept"], cnt["earn_checked"], cnt["finalists"],
                  cnt["qualify"]), ""]
        L += cand_table(lst, T, cands[lst], evid)
        L += ["**With a Soul condition** (Soul x model interactions):", ""]
        L += cand_table(lst, T, soulc[lst], evid)
        if len(T):
            L += ["The %d best by score, qualified or not:" % min(OPEN, len(open_l[lst])), ""]
            for c in open_l[lst]:
                r = T[T["cand"].apply(lambda x: tuple(x) == tuple(c))].iloc[0]
                L.append("- %s%s - %d trades, net %s, vs all picks %s%s" % (
                    "**QUALIFIES** " if r["qualifies"] else "", r["text"], r["n"], _p(r["net"]), _ci_txt(r, "lift"),
                    "" if r["qualifies"] else " (fails: %s)" % fails(lst, r)))
            L.append("")
    L += ["## Soul on its own (each Soul level at the signal close; picks bought at the D1 open)", "",
          "| Soul condition | picks | net % | vs all picks of the same days, pp [95%] |", "|---|---|---|---|"]
    for r in singles.itertuples(index=False):
        L.append("| %s | %d | %s | %s [%s, %s] |" % (r.text, r.n, _p(r.net), _p(r.lift), _p(r.lift_lo), _p(r.lift_hi)))
    L += ["", "## Money from 2022 (Rs 5 L, profits reinvested; setuplab's money book)", ""]
    if MO is not None and len(MO):
        L += ["| book | slots | MTF | a year % | worst fall % | Rs 5 L became | trades a week |",
              "|---|---|---|---|---|---|---|"]
        for r in MO[MO["slots"] == 3].itertuples(index=False):
            L.append("| %s | %d | %s | %s | %s | Rs %s | %.1f |" % (r.book, r.slots, r.mtf, _p(r.cagr), _p(r.worst_fall,
                                                                                                         sign=False),
                                                                "{:,.0f}".format(r.end_rs), r.per_week))
        L += ["", "3 slots shown (your capital); 2 / 5 / 7 slots in money.csv. Out-of-sample arms: each year the rules "
              "chosen from the years before. In-sample arms: the candidates above, on the years they were found on.",
              ""]
    else:
        L += ["No money books (no arm had trades from 2022).", ""]
    L += ["## The replay, year by year", ""]
    if len(WFY):
        L += WFY.to_markdown(index=False).splitlines() if hasattr(WFY, "to_markdown") and _has_tabulate() else \
            ["```", WFY.to_string(index=False), "```"]
    L += ["", "## Inputs and checks", ""]
    for k, v in info["checks"].items():
        L.append("- %s: %s" % (k, v))
    L += ["", "## How to read it", "",
          "- A rule's picks are judged against **all picks of the same days** (so a rule that only finds good market "
          "days shows nothing) and must make money; every condition must add something on its own (the rule beats the "
          "picks its simpler version adds).",
          "- BUY: buy at the D1 open, sell at the D5 close. SKIP: the picks to leave out. TRIGGER: watch D1-D5 and buy "
          "the first open after a close where every condition holds; sell at the D5 close (and the fresh exit, 4 "
          "sessions after the entry, must also make money).",
          "- Plain 95% per rule (be open): with thousands of rules, some qualify by luck - the replay is what tells "
          "them apart. A rule 'chosen in the replay' in a year was picked from the years before and judged on that "
          "year.", "",
          "## Limits", "",
          "- 2020-2026 is where the engines, the tree and the setups were found: everything here is in-sample except "
          "the replay, and the replay re-uses the same years. Only the forward paper ledger is clean evidence.",
          "- The D1-D5 path is setuplab's (the watchlist's own closes); lower-circuit locks are not modelled here.",
          "- Soul v3 is used as stored (its own timing rule: only trades finished before the day; checked from its "
          "meta); D's inputs as the panel stores them.", ""]
    (d / "SOULLAB.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def _has_tabulate():
    try:
        import tabulate  # noqa: F401
        return True
    except ImportError:
        return False


def fails(lst, r):
    f = []
    if r["per_year"] < MIN_PER_YEAR:
        f.append("trades a year")
    if lst == "skip":
        if not r["lift_hi"] < 0:
            f.append("not below the day's picks (95%)")
        if not r["net"] < 0:
            f.append("makes money")
    else:
        if not r["lift_lo"] > 0:
            f.append("not above the day's picks (95%)")
        if not r["net_lo"] > 0:
            f.append("net (95%)")
        if lst == "trigger":
            if not r["net_fresh_lo"] > 0:
                f.append("fresh exit (95%)")
            if not r["vs_d1_lo"] > 0:
                f.append("not above D1 on the same picks (95%)")
    if r["size"] > 1 and not r["earn_lo"] > 0:
        f.append("a condition does not earn its place")
    if r["bad_years"] > MAX_BAD_YEARS:
        f.append("bad years")
    if not r["engines_agree"]:
        f.append("the engines disagree")
    return ", ".join(f) or "-"


# ====================================================================================================== the command
def cmd_run(a, log=say):
    t_start = time.time()
    if SU.VERSION != NEEDS and not a.setuplab_any:
        raise SLError("soullab needs %s beside it (found %s at %s)" % (NEEDS, SU.VERSION, _SL_DIR))
    dpath, decl = load_declaration()
    dsha = decl["sha256"]
    root = Path(a.root)
    if not root.is_dir():
        raise SLError("--root %s is not a folder" % root)
    out = guard_out(a.out, root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    soul = Path(a.soul) if a.soul else root / "panel" / "soul" / "soul_v3_open.parquet"
    if not panel.is_file():
        raise SLError("panel not found: %s" % panel)
    dfeats, dsrc, dsha_src = d_features(root)
    smeta, scols, smp = soul_meta(soul)
    dcols, excl = choose_features(dfeats, panel)
    if not dcols:
        raise SLError("none of engine D's inputs is usable")
    log("%s (%s): D's inputs %d listed, %d used; Soul %d features (%s, lag %s)" % (
        VERSION, SU.VERSION, len(dfeats), len(dcols), len(scols), smeta.get("code"), smeta["config"].get("lag")))
    # --check-only reads a sample of D's inputs (the join check); the run reads them all
    book, missing = load_book(a.data, panel, soul, dcols[:GROUP] if a.check_only else dcols, scols, log)
    feats = [f for f in dcols + scols if f in book.F and f + "_change" in book.F]
    lost = [f for f in (dcols[:GROUP] if a.check_only else dcols) + scols if f not in feats]
    W = World(book, feats, set(scols))
    book.F = {}
    if not len(W.pool):
        raise SLError("no complete picks in the watchlist folder")
    jc = join_check(W, panel, soul, [f for f in dcols if f in feats], [f for f in scols if f in feats])
    log(" join check: %d values, %d mismatches" % (jc["checked"], jc["mismatches"]))
    if jc["mismatches"]:
        raise SLError("the join check failed - a pick does not read its own row: " + "; ".join(jc["examples"]))
    nA = 12 * (len(dcols) + len(scols)) if a.check_only else 12 * len(feats)
    npool = len(W.pool)
    secs = (nA * nA / 2.0) * npool * 6.5e-9 * 3.94 + TRIPLE_PAIRS * nA * npool * 6.5e-9 * 6 + 300
    info_counts = {"picks (complete)": "%d rows: D %d, ENS %d; pooled %d stock-days, %s to %s" % (
        W.n, int((W.eng == "D").sum()), int((W.eng == "ENS").sum()), npool, W.day.min(), W.day.max()),
        "features": "%d of D's %d inputs used (%s), %d Soul" % (
            len(dcols), len(dfeats),
            ", ".join("%d %s" % (n_, r_) for r_, n_ in pd.Series([e[1] for e in excl]).value_counts().items())
            if excl else "none excluded", len(scols)),
        "conditions": "%d (12 per feature)" % nA,
        "estimated time": "the search about %.1f to %.1f hours, plus reading %d columns of the panel" % (
            secs / 3600 * 0.6, secs / 3600 * 2.0, len(dcols))}
    for k, v in info_counts.items():
        log(" %s: %s" % (k, v))
    if a.check_only:
        log("CHECK OK - inputs readable, join check passed; nothing searched or written. Run again without "
            "--check-only.")
        return 0
    specs = atom_specs(feats, set(scols))
    d = SU.new_run_dir(out, "SOULLAB")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": dsha, "d_features": dsrc, "d_features_sha256": dsha_src,
                 "soul": str(soul), "soul_meta_sha256": sha256_file(smp), "data": str(a.data), "panel": str(panel)})
    # ---- the full period
    log("the search on every pooled pick (%d conditions)" % nA)
    atoms = resolve(specs, W, W.pool)
    P = make_pop(W, W.pool)
    EPs = [(e, make_pop(W, np.flatnonzero(W.eng == e), e)) for e in ("D", "ENS") if (W.eng == e).any()]
    results, DM, DMp, MAb = run_search(W, atoms, P, EPs, LISTS, log)
    cands, soulc, open_l = {}, {}, {}
    for lst in LISTS:
        T = results[lst][0]
        cands[lst] = pick_top(T, lst, P, MAb, DMp)
        soulc[lst] = pick_top(T, lst, P, MAb, DMp, need=lambda c: any(atoms[x]["soul"] for x in c))
        open_l[lst] = pick_top(T, lst, P, MAb, DMp, k=OPEN, only_q=False)
    # Soul on its own
    boot = SU.Boot(P["day"], B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    srows = []
    for i, at in enumerate(atoms):
        if at["soul"] and at["kind"] == "lvl":
            m = MAb[i]
            lo, hi = _ci(boot, P["di"][m], P["lift"][m])
            srows.append({"rule": at["id"], "text": at["words"], "n": int(m.sum()),
                          "net": float(P["netA"][m].mean()) if m.any() else np.nan,
                          "lift": float(P["lift"][m].mean()) if m.any() else np.nan, "lift_lo": lo, "lift_hi": hi})
    singles = pd.DataFrame(srows, columns=["rule", "text", "n", "net", "lift", "lift_lo", "lift_hi"])
    # ---- the replay
    log("the replay, year by year (%s)" % ", ".join(map(str, WF_YEARS)))
    WFY, WFR, verdicts, sel = replay(W, specs, LISTS, log)
    evid = {}
    if len(WFR):
        for rule, G in WFR.groupby("rule"):
            evid[rule] = ", ".join("%d (%s pp)" % (int(r.year), _p(r.lift)) for r in G.itertuples(index=False))
    # ---- money
    base = W.pool[W.rank[W.pool] <= 3]
    arms = {}
    for lst in LISTS:
        S = pd.concat(sel[lst], ignore_index=True) if sel[lst] else None
        if lst == "skip":
            if S is not None and len(S):
                keep = base[~np.isin(base, S["pos"].to_numpy())]
                arms["SKIP out of sample: ranks 1-3 without the skipped picks"] = (keep, np.zeros(len(keep)),
                                                                                    W.netA[keep])
        elif S is not None and len(S):
            arms["%s out of sample" % lst.upper()] = (S["pos"].to_numpy(), S["k"].to_numpy(), S["net"].to_numpy())
        if lst != "skip" and cands[lst]:
            ar = np.arange(P["n"])
            if lst == "buy":
                m = np.zeros(P["n"], bool)
                for c in cands[lst]:
                    m |= open_mask(MAb, c)
                arms["BUY in-sample (the candidates)"] = (P["pos"][m], np.zeros(int(m.sum())), P["netA"][m])
            else:
                K = np.full(P["n"], 5, np.uint8)
                for c in cands[lst]:
                    K = np.minimum(K, trig_entries(DMp, c))
                m = K < 5
                arms["TRIGGER in-sample (the candidates)"] = (P["pos"][m], K[m].astype(int), P["NO6"][K, ar][m])
    MO = money(W, base, arms)
    # ---- outputs
    names = []
    for lst in LISTS:
        T = results[lst][0].copy()
        if len(T):
            T["cand"] = T["cand"].apply(lambda c: json.dumps(list(c)))
        fn = "finalists_%s.csv" % lst
        T.to_csv(d / fn, index=False, float_format="%.6g")
        names.append(fn)
    for fn, X in (("replay_years.csv", WFY), ("replay_rules.csv", WFR), ("money.csv", MO),
                  ("soul_alone.csv", singles)):
        (X if X is not None else pd.DataFrame()).to_csv(d / fn, index=False, float_format="%.6g")
        names.append(fn)
    pd.DataFrame([{"feature": f, "used": f in feats, "soul": f in set(scols),
                   "note": "" if f in feats else "not readable"} for f in dcols + scols] +
                 [{"feature": f, "used": False, "soul": False, "note": r} for f, r in excl]).to_csv(
        d / "features.csv", index=False)
    pd.DataFrame([{k: at.get(k) for k in ("id", "fam", "words", "lo", "hi", "soul")} for at in atoms]).to_csv(
        d / "conditions.csv", index=False, float_format="%.6g")
    names += ["features.csv", "conditions.csv"]

    def cdoc(lst, cs):
        return [{"rule": " & ".join(atoms[x]["id"] for x in c), "text": " AND ".join(atoms[x]["words"] for x in c),
                 "conditions": [{k: atoms[x].get(k) for k in ("id", "f", "kind", "code", "lo", "hi")} for x in c]}
                for c in cs]
    doc = {"tool": VERSION, "declaration_sha256": dsha, "run": d.name,
           "lists": {lst: {"candidates": cdoc(lst, cands[lst]), "soul_candidates": cdoc(lst, soulc[lst]),
                           "replay": verdicts.get(lst)} for lst in LISTS}}
    doc["sha256"] = SU.frozen_hash(json.loads(json.dumps(doc, default=float)))
    (d / "SOULLAB_CANDIDATES.json").write_text(json.dumps(doc, indent=2, default=float), encoding="utf-8")
    names.append("SOULLAB_CANDIDATES.json")
    (d / "DECLARATION.json").write_text(dpath.read_text(encoding="utf-8"), encoding="utf-8")
    names.append("DECLARATION.json")
    piks = pd.DataFrame({"trade_id": W.ids[W.pool], "engine": W.eng[W.pool], "rank": W.rank[W.pool],
                         "symbol": W.sym[W.pool], "signal_day": W.day[W.pool], "net_d1": W.netA[W.pool],
                         "lift": P["lift"]})
    for lst in ("buy", "skip"):
        for i, c in enumerate(cands[lst], 1):
            piks["%s_R%d" % (lst, i)] = open_mask(MAb, c)
    for i, c in enumerate(cands["trigger"], 1):
        k = trig_entries(DMp, c)
        piks["trigger_R%d_day" % i] = np.where(k < 5, k.astype(int) + 1, 0)
    piks.to_parquet(d / "picks.parquet", index=False)
    names.append("picks.parquet")
    secs = time.time() - t_start
    checks = dict(info_counts)
    checks.pop("estimated time", None)
    checks.update({"D's input list": "%s (sha256 %s)" % (dsrc, dsha_src[:16]),
                   "Soul file": "%s (%s, lag %s, horizon %s; meta sha256 %s)" % (
                       soul, smeta.get("code"), smeta["config"].get("lag"), smeta["config"].get("horizon"),
                       sha256_file(smp)[:16]),
                   "join check": "%d values of %d picks read again from the files: %d mismatches" % (
                       jc["checked"], JOIN_SAMPLE, jc["mismatches"]),
                   "picks whose signal day is not the session before D1": str(W.gap_days),
                   "unreadable features": ", ".join(lost) if lost else "none",
                   "time": "%.1f hours" % (secs / 3600)})
    info = {"declaration_sha": dsha, "finished": time.strftime("%Y-%m-%d %H:%M"), "checks": checks}
    write_report(d, info, results, cands, soulc, open_l, verdicts, WFY, WFR, MO, singles, evid)
    names.insert(0, "SOULLAB.md")
    run = {"tool": VERSION, "setuplab": SU.VERSION, "declaration_sha256": dsha, "checks": checks,
           "counts": {lst: results[lst][1] for lst in LISTS}, "verdicts": verdicts,
           "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__}
    (d / "RUN.json").write_text(json.dumps(run, indent=2, default=float), encoding="utf-8")
    names.append("RUN.json")
    SU.write_hashes(d, names)
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "verdicts": {k: v.get("verdict") for k, v in verdicts.items()},
                 "candidates": {lst: [" & ".join(atoms[x]["id"] for x in c) for c in cands[lst]] for lst in LISTS},
                 "hours": round(secs / 3600, 2)})
    log("SOULLAB WRITTEN %s (%.1f hours)" % (d, secs / 3600))
    for lst in LISTS:
        v = verdicts.get(lst, {})
        log("  %-45s %d candidates; replay: %s" % (LIST_NAME[lst], len(cands[lst]), v.get("verdict")))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="soullab: new rules from Soul x engine D's inputs")
    sub = ap.add_subparsers(dest="cmd")
    r = sub.add_parser("run")
    r.add_argument("--root", required=True, help="%%CACHE_DAILY_ROOT%%")
    r.add_argument("--data", required=True, help="setuplab's watchlist folder (WL_R1_10)")
    r.add_argument("--out", required=True, help="C:\\QuantData\\soullab")
    r.add_argument("--panel", default=None, help="default <root>\\panel_oc\\panel.parquet")
    r.add_argument("--soul", default=None, help="default <root>\\panel\\soul\\soul_v3_open.parquet")
    r.add_argument("--check-only", action="store_true")
    r.add_argument("--setuplab-any", action="store_true")
    a = ap.parse_args(argv)
    if a.cmd != "run":
        ap.print_help()
        return 2
    try:
        return cmd_run(a)
    except SLError as e:
        print("REFUSED: %s" % e)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
