# MANIFEST - stratlab v1.0.1 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\stratlab` (a research folder beside `soullab` and `setuplab`).
Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\stratlab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `stratlab.py` | 9f3367742804d5fe | 57313 |
| `STRATLAB_DECLARATION.json` | f2e491e6924151fe | 7601 |
| `README_STRATLAB.md` | e250fa13f8883f5d | 6674 |
| `tests\test_stratlab.py` | 13974c69ca986d61 | 16555 |
| `MANIFEST_STRATLAB.md` | this file | - |

Needs, read only, as sibling folders: `soullab` v1.0 (soullab.py sha16 aaf5fa1742638561) and `setuplab` v1.1.

Declaration: `STRATLAB_DECLARATION.json`, internal sha256 c5c7d162d4623157... - checked at every start; an edited file is refused.

## History
- v1.0.1 (22 Nov 2026): panel_oc stores returns as fractions (0.012 = +1.2%). v1.0 read `label_oc_h` as points; the
  first check-only on Karan's PC stopped on that (median |label_oc_5| 0.03049) before anything was searched or written.
  v1.0.1 turns the fractions into points (net = 100 x label_oc_h - 0.35) and stops on a panel that is not in fractions.
  The declaration records the amendment (`units_note`); no rule, list, judge or threshold changed.
- v1.0 (21 Nov 2026): first build.

## Verified (synthetic data, pandas 3.0.5 and pandas 2.3.3): `31 checks, 0 failed` / `VERIFIED (stratlab v1.0.1)`
- Planted world: the planted market BUY/AVOID rules (holds 2, 3, 5), the picks BUY, SKIP-by-context and TRIGGER
  rules all found and CONFIRMED; money in the hidden years beats buying everything.
- Fading world (an effect only in the searched half): found, then NOT CONFIRMED.
- Absent world (nothing planted): nothing CONFIRMED out of every rule judged.
- Units: net = 100 x label_oc_5 - 0.35 by hand on 300 stock-days; a panel in points is refused.
- Mutation test: 8 of 8 planted bugs caught (hidden stocks = the searched half; no correction for the number of rules
  judged; thirds swapped; a move read from the next session; ETFs kept; hidden years overlapping the search; fractions
  not turned into points; the unit check removed).
