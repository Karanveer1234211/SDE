# stratlab v1.0.1 - the strategy factory

Your question (21 Nov 2026): *a code which creates the best strategies from anything, everything, any combination of
the data on my PC - not necessarily known strategies - rigorously created and backtested, helped by what we already
know.* Your answer: **both the whole market and the picks.**

stratlab sits beside soullab and setuplab (`PyCharmMiscProject\stratlab`) and uses their tested engine (read only). It
reads production **read only** and writes only under `C:\QuantData\stratlab`. Nothing in production, the paper test or
the frozen tree changes. Its rules are in `STRATLAB_DECLARATION.json` (sha256-checked; an edited file is refused).

## What it does, in plain words

**1. It builds rules from everything.**
- **Building blocks:** every input of engine D (from `PRODUCTION.json`) and every Soul value, plus each
  pick's context (market environment, stock state, rank 1-3, picked by both engines, D1's weekday).
- **Conditions:** each building block becomes yes/no conditions read at a close. For example: its level is in the high
  third, it rose today, it fell twice in a row, it turned up.
- **Rules:** a rule is 1, 2 or 3 conditions joined by AND. That gives millions of rules.

**2. Two searches:**

| search | where | a rule ... | it must beat |
|---|---|---|---|
| MARKET | every eligible stock, every day (D's own universe, ETFs out) | buys every stock it selects at the next open, sells at the 2nd, 3rd or 5th close | buying **every** eligible stock at the same open - and make money (BUY) / trail it and lose money (AVOID) |
| PICKS | D's and ENS's picks, ranks 1-10 | BUY / SKIP at the D1 open (sold at the D5 close, the D6 open or the D10 close), or TRIGGER (waits on D1-D5) | the day's other picks |

**3. What we already know, built in.**
- **What it reuses:**
  - entry at the next open (close entries are shelved);
  - 0.35 points of costs;
  - ETFs out;
  - the project's yardstick: beat buying everything, or beat the day's other picks;
  - soullab's search and checks.
- **What it does not search:** profit targets and brackets. They lost three times.

**4. The judges it never sees - this is what makes it honest.**
- **How the stocks are split:** by a fixed rule, a hash of the symbol. The search sees only **half A**.
- **What gets judged:** every rule that qualifies on half A meets, **once**:
  - **half B** - the other stocks, the same years;
  - **every stock before 2020** (market only). No rule search in this project has used those years.
- **CONFIRMED** means the rule beats its yardstick on every judge, with p at most 0.05 divided by the number of rules
  judged. This correction means judging many rules cannot confirm luck. A world with no effect confirmed nothing; an
  effect that existed only in the searched half was found and then rejected (see Verified).

**Example:**
- **The rule:** a market rule such as *"one of D's momentum inputs fell on the signal day AND one Soul value is in its
  high third"* selects those stocks every day, buys them at the next open, and sells at the 5th close.
- **On half A (2020-2026):** it qualifies only if:
  - those stocks beat all stocks bought at the same opens (95%);
  - they made money (95%);
  - they lost to the rest in at most 2 of 7 years;
  - each condition adds something on its own.
- **The judges:** it then meets half B and the years before 2020. If it holds on both, it is CONFIRMED.

## Install and run

Copy the `stratlab` folder to `C:\Users\karanvsi\PyCharmMiscProject\stratlab` (beside `soullab` and `setuplab` -
it imports soullab v1.0 and setuplab v1.1 from there, read only). Then in `cmd`:

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\stratlab
python tests\test_stratlab.py
```

It must end `31 checks, 0 failed` / `VERIFIED (stratlab v1.0.1)` (about 2-3 minutes; synthetic data only).

```
python stratlab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\stratlab --soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet --check-only
```

This takes a few minutes and ends `CHECK OK`. It prints:
- how many eligible stock-days it found;
- the first and last day, so you can see whether the panel reaches back to 2016;
- how the stock-days split: searched, hidden stocks, hidden years;
- the label check: panel_oc stores returns as fractions (0.012 = +1.2%); stratlab turns them into points and
  stops if they are not fractions;
- the picks;
- the join check;
- the time estimate.

Then the real run, the same without `--check-only`. Leave the PC on:

```
python stratlab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\stratlab --soul %CACHE_DAILY_ROOT%\panel\soul\soul_v3.parquet
```

- **When it ends:** it prints `STRATLAB WRITTEN C:\QuantData\stratlab\STRATLAB_<date>_<nnn>`, then one line per list
  with the number of rules that qualified, were judged and were CONFIRMED.
- **One part only:** `--part market` or `--part picks`.

## What you get (`C:\QuantData\stratlab\STRATLAB_<date>_<nnn>\`)

- **`STRATLAB.md` - read this first.** It contains, in order:
  - the **verdict** table: for each list, how many rules qualified, were judged and were **CONFIRMED**;
  - the **CONFIRMED rules** in words, with their numbers on half A, half B and the years before 2020;
  - each list's rules;
  - the market's rules read on **your picks**;
  - **money in the hidden years**: Rs 5 L, 3 slots, no MTF and MTF 2x - the rules against buying everything;
  - the checks.
- `rules_<part>_<list>_<hold or exit>.csv` - every rule fully tested, with its judges.
- `STRATLAB_CANDIDATES.json` (hash-checked), `money_hidden_years.csv`, `market_rules_on_picks.csv`, `conditions.csv`,
  `RUN.json`, `DECLARATION.json`, `outputs.sha256`.
- A start and an end line in `C:\QuantData\stratlab\stratlab_ledger.jsonl`.

Send me `STRATLAB.md` first.

## Limits

- **Half B shares the same market days as half A.** The yardstick removes the day's market move, but stocks in one
  sector move together across the halves.
- **Before 2020:**
  - the engines were trained on those years, though no rule search used them;
  - the cache only has stocks that still trade, which flatters buying beaten-down stocks there.
- **Targets and paths:**
  - market targets are the panel's `label_oc_2/3/5`, and lower-circuit locks are not modelled;
  - picks use setuplab's watchlist path.
- **Compared with buying everything, or with the day's other picks - not with the frozen tree.** A CONFIRMED rule is
  compared with the tree next, then frozen on its own date and judged by the forward paper ledger.
