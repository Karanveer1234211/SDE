# MANIFEST - stratlab v1.0 (21 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\stratlab` (a NEW research folder beside `soullab` and `setuplab`).
Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\stratlab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `stratlab.py` | 1e5c04dcf58568ff | 56546 |
| `STRATLAB_DECLARATION.json` | c62285aa6d9e4f6f | 7312 |
| `README_STRATLAB.md` | 7e79c7d409180c94 | 6524 |
| `tests\test_stratlab.py` | 4aa6cb2440d51178 | 15400 |
| `MANIFEST_STRATLAB.md` | this file | - |

Needs, read only, as sibling folders: `soullab` v1.0 (soullab.py sha16 aaf5fa1742638561) and `setuplab` v1.1.

Declaration: `STRATLAB_DECLARATION.json`, internal sha256 cc6bbc97d44be26e... - checked at every start; an edited file is refused.

Verified on synthetic data, pandas 3.0.5 and pandas 2.3.3: `29 checks, 0 failed` / `VERIFIED (stratlab v1.0)`.
- Planted world: the planted market BUY/AVOID rules (holds 2, 3, 5), the picks BUY, SKIP-by-context and TRIGGER
  rules all found and CONFIRMED; money in the hidden years beats buying everything.
- Fading world (an effect only in the searched half): found, then NOT CONFIRMED.
- Absent world (nothing planted): nothing CONFIRMED out of every rule judged.
- Mutation test: 6 of 6 planted bugs caught (hidden stocks = the searched half; no correction for the number of rules
  judged; thirds swapped; a move read from the next session; ETFs kept; hidden years overlapping the search).
