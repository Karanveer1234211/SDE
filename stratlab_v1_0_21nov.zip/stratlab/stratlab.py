"""
stratlab.py - stratlab v1.0: the strategy factory. It builds rules out of everything on your PC (every input of engine
D, every Soul value, and each pick's context), backtests every one, and keeps only the rules that also work on stocks
and years the search never saw.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\stratlab
    python stratlab.py run --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --out C:\\QuantData\\stratlab
                           --soul %CACHE_DAILY_ROOT%\\panel\\soul\\soul_v3.parquet  [--part market|picks|both] [--check-only]

Karan, 21 Nov 2026: "a code which creates best strategies based on anything, everything, certain combinations from the
data set in my pc ... rigorously create strategy and backtest ... takes helps from what we know already"; "Both whole
market and picks". The rules are fixed in STRATLAB_DECLARATION.json (beside this file, sha256-checked).

Two searches, one engine (soullab's, tested):
  MARKET  every eligible stock on every day (engine D's own universe: panel_oc\\panel.parquet, its eligibility column;
          ETFs out). A rule = 1-3 conditions read at the signal close. It buys every stock it selects at the next open
          and sells at the close 2, 3 or 5 sessions later (the panel's label_oc_2 / _3 / _5). BUY rules must beat
          buying every stock at the same open and make money; AVOID rules must trail it and lose money.
  PICKS   D's and ENS's picks (ranks 1-10). As soullab, plus each pick's context (its market, state, rank, both
          engines, D1's weekday) as conditions, and three exits for the lists that buy at the D1 open: the D5 close,
          the D6 open, the D10 close. TRIGGER (wait on D1-D5, buy the next open) as soullab.
What we already know shapes it: the entry is the next open (entries at the close are shelved), costs are 0.35 pp,
the D5 hold is the reference, targets / brackets are not searched (they lost three times), ETFs are out, and the
yardstick is the one the project adopted: beat buying everything (market) or the day's other picks (picks).

The judges the search never sees:
  * HIDDEN STOCKS: every symbol goes to half A or half B by a fixed rule (sha256 of "stratlab-v1|SYMBOL", even = A).
    The search sees only half A. Every rule it keeps is judged ONCE on half B - the same years, other stocks.
  * HIDDEN YEARS (market): every stock before 2020. No rule search in this project has used those years.
  CONFIRMED = the rule beats its yardstick on every judge (95%). Nothing is re-run to change a verdict.

Example: the market rule "d_rsi14 fell on the signal day AND soul_p_ret in its high third" selects, each day, the
stocks matching both, buys them at the next open and sells at the 5th close. It qualifies on half A in 2020-2026 only if
those stocks beat all stocks bought at the same opens (95%), made money (95%), lost to them in at most 2 of 7 years
and each condition adds something. Then it meets half B and the years before 2020, once.

Writes only under --out: STRATLAB_<date>_<nnn>\\ (STRATLAB.md first) and a line per run in stratlab_ledger.jsonl.
Research only: nothing in production, the paper test or the frozen tree changes.
"""
from __future__ import annotations

import argparse
import copy
import datetime as _dt
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
for _d in (os.environ.get("SOULLAB_DIR") or str(HERE.parent / "soullab"),
           os.environ.get("SETUPLAB_DIR") or str(HERE.parent / "setuplab")):
    if _d not in sys.path:
        sys.path.insert(0, _d)
import soullab as SL  # noqa: E402
import setuplab as SU  # noqa: E402

VERSION = "stratlab v1.0"
NEEDS = {"soullab": "soullab v1.0", "setuplab": "setuplab v1.1"}
DECL_FILE = "STRATLAB_DECLARATION.json"
SALT = "stratlab-v1"
DISCOVERY_FROM = np.datetime64("2020-01-01")
HOLDS = (2, 3, 5)
PICK_EXITS = (("d5_close", "the D5 close"), ("d6_open", "the D6 open"), ("d10_close", "the D10 close"))
SAMPLE = 150_000                  # market: the searched stock-days screened on a fixed random sample of this size
SAMPLE_SEED = 7
HIDDEN_YEARS_MIN_DAYS = 250       # sessions before 2020 the hidden-years judge needs, else it is not available
SNAP_MAX_CODES = 12
MONEY_SEEDS = (1, 2, 3, 4, 5)
MONEY_SLOTS = 3
ALPHA = 0.05                      # the judges: one-sided, Bonferroni over the rules judged in a part
COST = SL.COST
BITS = SL.BITS
LOG = SL.say


class STError(Exception):
    pass


def constants():
    return {"soullab": SL.constants(), "salt": SALT, "discovery_from": str(DISCOVERY_FROM), "holds": list(HOLDS),
            "pick_exits": [e for e, _ in PICK_EXITS], "sample": SAMPLE, "sample_seed": SAMPLE_SEED,
            "hidden_years_min_days": HIDDEN_YEARS_MIN_DAYS, "snap_max_codes": SNAP_MAX_CODES,
            "money_seeds": list(MONEY_SEEDS), "money_slots": MONEY_SLOTS, "alpha": ALPHA}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise STError("no declaration at %s (it ships beside stratlab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise STError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" %
                      p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise STError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def half_of(sym):
    """0 = half A (searched), 1 = half B (hidden): the parity of sha256('stratlab-v1|SYMBOL')."""
    return int(hashlib.sha256((SALT + "|" + str(sym).strip().upper()).encode()).hexdigest(), 16) % 2


def halves(symbols):
    u = {s: half_of(s) for s in set(symbols)}
    return np.array([u[s] for s in symbols], np.int8)


def elig_column(arg):
    if arg:
        return arg
    try:
        import stage_b_screen as SB
        return str(SB.ELIG_COL)
    except Exception as e:  # noqa: BLE001
        raise STError("cannot read stage_b_screen.ELIG_COL (start with env_tradelab.bat, or pass --elig-col): %s: %s"
                      % (type(e).__name__, e))


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(),
              SL.HERE.resolve(), SL._SL_DIR.resolve()):
        if o == b or b in o.parents:
            raise STError("--out %s is inside %s - outputs go under C:\\QuantData\\stratlab" % (o, b))
    return o


def ledger(out, rec):
    with open(Path(out) / "stratlab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def _naive_days(s):
    t = pd.to_datetime(s)
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t.dt.normalize().to_numpy().astype("datetime64[D]")


# ====================================================================================================== market data
def _diffs(x_sorted, same):
    """this session minus the stock's previous row, and the same one session earlier (NaN across stocks)."""
    d0 = np.full(len(x_sorted), np.nan, np.float64)
    d0[1:] = x_sorted[1:] - x_sorted[:-1]
    d0[~same] = np.nan
    d1 = np.full(len(x_sorted), np.nan, np.float64)
    d1[1:] = d0[:-1]
    d1[~same] = np.nan
    return d0, d1


def encode(v, c0, c1, q):
    """The 12 conditions of a feature as bits: 0-3 levels (L3, H3, LO, HI; none without cut-offs), 4-11 moves (up0,
    dn0, up1, dn1, upup, dndn, dnup, updn) - soullab's order. A missing value sets no bit."""
    b = np.zeros(len(v), np.uint16)
    u = np.uint16
    with np.errstate(invalid="ignore"):
        if q is not None:
            for bit, ok in enumerate((v <= q[0], v > q[2], v <= q[1], v > q[1])):
                b |= ok.astype(u) << u(bit)
        for bit, ok in enumerate((c0 > 0, c0 < 0, c1 > 0, c1 < 0, (c1 > 0) & (c0 > 0), (c1 < 0) & (c0 < 0),
                                  (c1 < 0) & (c0 > 0), (c1 > 0) & (c0 < 0)), start=4):
            b |= ok.astype(u) << u(bit)
    return b


def market_atoms(feats, soulset, cuts):
    A = []
    for f in feats:
        q = cuts.get(f)
        s = f in soulset
        if q is not None:
            for bit, (code, lo_i, hi_i, w) in enumerate(SL.LEVELS):
                lo = -np.inf if lo_i is None else float(q[lo_i])
                hi = np.inf if hi_i is None else float(q[hi_i])
                A.append({"id": "%s:%s" % (f, code), "fam": "V|" + f, "f": f, "kind": "lvl", "code": code, "bit": bit,
                          "lo": lo, "hi": hi, "soul": s,
                          "words": "%s %s" % (f, w) + (" (<= %.6g)" % hi if lo_i is None else " (> %.6g)" % lo)})
        for bit, (code, w) in enumerate(SL.MOVES, start=4):
            A.append({"id": "%s:%s" % (f, code), "fam": "B|" + f, "f": f, "kind": "mv", "code": code, "bit": bit,
                      "soul": s, "words": "%s %s" % (f, w)})
    return A


class Market:
    pass


def load_market(panel, soul, dcols, scols, elig, root, log=LOG, check_only=False):
    """Every eligible stock-day (ETFs out) with its targets and every feature's 12 conditions as uint16 bits."""
    import pyarrow.parquet as pq
    names = pq.read_schema(panel).names
    low = {c.lower(): c for c in names}
    dk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or not dk:
        raise STError("the panel needs symbol and timestamp columns")
    if elig.lower() not in low:
        raise STError("the panel has no eligibility column %s" % elig)
    holds = [h for h in HOLDS if "label_oc_%d" % h in low]
    if 5 not in holds:
        raise STError("the panel has no label_oc_5 (buy the next open, sell the 5th close)")
    base = pq.read_table(panel, columns=[low["symbol"], dk, low[elig.lower()]] +
                         [low["label_oc_%d" % h] for h in holds]).to_pandas()
    sym = base[low["symbol"]].astype(str).str.strip().str.upper().to_numpy()
    day = _naive_days(base[dk])
    el = pd.to_numeric(base[low[elig.lower()]], errors="coerce").to_numpy(float)
    lab = {h: pd.to_numeric(base[low["label_oc_%d" % h]], errors="coerce").to_numpy(float) for h in holds}
    del base
    o = np.lexsort((day, sym))
    so, do = sym[o], day[o]
    same = np.r_[False, so[1:] == so[:-1]]
    if (same & np.r_[False, do[1:] == do[:-1]]).any():
        raise STError("the panel has duplicated symbol / day rows")
    _, tdoc = SU.load_tree()
    us = np.unique(so)
    etf_u = SU.tree_etf(us, tdoc, SU.etf_list(root))
    etf = etf_u[np.searchsorted(us, so)]
    keep = (el[o] == 1) & np.isfinite(lab[5][o]) & ~etf
    pos = np.flatnonzero(keep)
    M = Market()
    M.holds = holds
    M.n = len(pos)
    M.sym = so[pos]
    M.day = do[pos]
    M.half = halves(M.sym)
    M.cal = np.unique(day)
    M.i_sig = np.searchsorted(M.cal, M.day)
    M.i1 = M.i_sig + 1
    med = float(np.nanmedian(np.abs(lab[5][o][pos]))) if M.n else np.nan
    if not (med >= 0.3):
        raise STError("label_oc_5 looks like a fraction (median |value| %.4g), not points as stage D wrote it - "
                      "stopping rather than guessing" % med)
    M.net = {h: lab[h][o][pos] - COST for h in holds}
    dd = np.unique(M.day, return_inverse=True)[1]
    nd = int(dd.max()) + 1 if M.n else 0
    cnt = np.bincount(dd, minlength=nd)
    M.excess = {}
    for h in holds:
        v = M.net[h]
        okv = np.isfinite(v)
        s = np.bincount(dd[okv], weights=v[okv], minlength=nd)
        c = np.bincount(dd[okv], minlength=nd)
        M.excess[h] = v - (s / np.maximum(c, 1))[dd]
    M.disc = (M.day >= DISCOVERY_FROM) & (M.half == 0)
    M.hid_stocks = (M.day >= DISCOVERY_FROM) & (M.half == 1)
    M.hid_years = M.day < DISCOVERY_FROM
    M.hid_years_days = int(len(np.unique(M.day[M.hid_years])))
    M.etfs = int(etf.sum())
    M.counts = cnt
    M.B, M.cuts = {}, {}
    disc_pos = np.flatnonzero(M.disc)
    feats_all = list(dcols) + list(scols)
    groups = [(panel, dcols, False), (soul, scols, True)]
    t0 = time.time()
    done = 0
    for src, cols, is_soul in groups:
        if not cols:
            continue
        if is_soul:
            sn = pq.read_schema(src).names
            sl = {c.lower(): c for c in sn}
            sk = sl.get("timestamp") or sl.get("date")
            S = pq.read_table(src, columns=[sl["symbol"], sk] + [sl[c] for c in cols]).to_pandas()
            ssym = S[sl["symbol"]].astype(str).str.strip().str.upper().to_numpy()
            sday = _naive_days(S[sk])
            so2 = np.lexsort((sday, ssym))
            ssym, sday = ssym[so2], sday[so2]
            ssame = np.r_[False, ssym[1:] == ssym[:-1]]
            key_s = np.char.add(np.char.add(ssym.astype(str), "|"), sday.astype(str))
            key_m = np.char.add(np.char.add(M.sym.astype(str), "|"), M.day.astype(str))
            ks = np.argsort(key_s)
            hit = np.searchsorted(key_s[ks], key_m)
            hit = np.minimum(hit, len(key_s) - 1)
            found = key_s[ks][hit] == key_m
            rowmap = np.where(found, ks[hit], -1)
            for c in cols:
                x = pd.to_numeric(S[sl[c]], errors="coerce").to_numpy(np.float64)[so2]
                d0, d1 = _diffs(x, ssame)
                g = lambda a: np.where(rowmap >= 0, a[np.maximum(rowmap, 0)], np.nan)  # noqa: E731
                _store(M, c, g(x), g(d0), g(d1), disc_pos)
            del S
            done += len(cols)
            log(" market: Soul %d columns read (%.0f s)" % (len(cols), time.time() - t0))
            continue
        for s in range(0, len(cols), SL.GROUP):
            part = cols[s:s + SL.GROUP]
            T = pq.read_table(src, columns=[low[c] for c in part]).to_pandas()
            for c in part:
                x = pd.to_numeric(T[low[c]], errors="coerce").to_numpy(np.float64)[o]
                d0, d1 = _diffs(x, same)
                _store(M, c, x[pos], d0[pos], d1[pos], disc_pos)
            del T
            done += len(part)
            if (s // SL.GROUP) % 5 == 4 or s + SL.GROUP >= len(cols):
                log(" market: D's inputs %d of %d columns read (%.0f s)" % (min(s + SL.GROUP, len(cols)), len(cols),
                                                                           time.time() - t0))
    M.feats = [f for f in feats_all if f in M.B]
    M.soul = set(scols)
    return M


def _store(M, f, v, c0, c1, disc_pos):
    x = v[disc_pos]
    x = x[np.isfinite(x)]
    q = np.quantile(x, [1 / 3, 0.5, 2 / 3]) if len(x) >= 30 else None
    M.cuts[f] = q
    M.B[f] = encode(v, c0, c1, q)


def rule_mask(M, atoms, c, rows):
    m = None
    for x in c:
        a = atoms[x]
        b = ((M.B[a["f"]][rows] >> np.uint16(a["bit"])) & np.uint16(1)).astype(bool)
        m = b if m is None else (m & b)
    return m


# ====================================================================================================== market search
def eval_market(lst, h, c, M, atoms, rows, boot, di, years):
    m = rule_mask(M, atoms, c, rows)
    n = int(m.sum())
    ex, nt = M.excess[h][rows], M.net[h][rows]
    r = {"n": n, "per_year": n / years, "per_day": n / max(1, len(np.unique(di[m]))) if n else 0.0,
         "share": n / max(1, len(rows))}
    r["excess"] = float(np.nanmean(ex[m])) if n else np.nan
    r["net"] = float(np.nanmean(nt[m])) if n else np.nan
    r["excess_lo"], r["excess_hi"] = SL._ci(boot, di[m], ex[m])
    r["net_lo"], r["net_hi"] = SL._ci(boot, di[m], nt[m])
    y = ex if lst == "buy" else -ex
    r["earn_lo"] = np.inf
    if len(c) > 1:
        los = []
        for d in range(len(c)):
            x = rule_mask(M, atoms, c[:d] + c[d + 1:], rows) & ~m
            los.append(boot.ci_diff(di[m], y[m], di[x], y[x])[0] if n >= 2 and x.sum() >= 2 else -np.inf)
        r["earn_lo"] = float(np.nanmin(los)) if np.isfinite(los).any() else -np.inf
    if n:
        yr = M.day[rows][m].astype("datetime64[Y]").astype(int) + 1970
        r["years"], r["bad_years"] = SL._years_bad(yr, ex[m], (lambda v: v <= 0) if lst == "buy" else
                                                   (lambda v: v >= 0))
    else:
        r["years"], r["bad_years"] = 0, 0
    earn_ok = len(c) == 1 or r["earn_lo"] > 0
    if lst == "buy":
        r["qualifies"] = bool(r["per_year"] >= SL.MIN_PER_YEAR and r["excess_lo"] > 0 and r["net_lo"] > 0 and earn_ok
                              and r["bad_years"] <= SL.MAX_BAD_YEARS)
        r["score"] = r["excess_lo"]
    else:
        r["qualifies"] = bool(r["per_year"] >= SL.MIN_PER_YEAR and r["excess_hi"] < 0 and r["net"] < 0 and earn_ok
                              and r["bad_years"] <= SL.MAX_BAD_YEARS)
        r["score"] = -r["excess_hi"] if np.isfinite(r["excess_hi"]) else np.nan
    r["rs_year"] = r["per_year"] * r["net"] * 1000.0 * (1 if lst == "buy" else -1) if n else np.nan
    return r


def market_top(T, M, atoms, rows, k, only_q=True, need=None):
    chosen = []
    if T is None or not len(T):
        return []
    for r in T.itertuples(index=False):
        if only_q and not r.qualifies:
            continue
        c = tuple(r.cand)
        if need is not None and not need(c):
            continue
        m = rule_mask(M, atoms, c, rows)
        sc = set(c)
        bad = False
        for c2, m2 in chosen:
            ov = (m & m2).sum() / max(1, min(m.sum(), m2.sum()))
            if set(c2) <= sc or sc <= set(c2) or ov >= SL.OVERLAP:
                bad = True
                break
        if bad:
            continue
        chosen.append((c, m))
        if len(chosen) == k:
            break
    return [c for c, _ in chosen]


def market_search(M, atoms, log=LOG):
    disc = np.flatnonzero(M.disc)
    years = SU._years(M.day[disc]) if len(disc) else 0.5
    rng = np.random.default_rng(SAMPLE_SEED)
    S = np.sort(rng.choice(disc, size=min(SAMPLE, len(disc)), replace=False))
    frac = len(S) / max(1, len(disc))
    min_full = SL.MIN_PER_YEAR * years
    min_s = max(10.0, min_full * frac)
    A = len(atoms)
    MAb = np.zeros((A, len(S)), bool)
    for i, a in enumerate(atoms):
        MAb[i] = ((M.B[a["f"]][S] >> np.uint16(a["bit"])) & np.uint16(1)).astype(bool)
    sdays = np.unique(M.day[S])
    di_s = np.searchsorted(sdays, M.day[S])
    nd_s = len(sdays)
    fam = SL.fam_ids(atoms)
    boot = SU.Boot(M.day[disc], B=SL.BOOT_B, block=SL.BOOT_BLOCK, seed=SL.BOOT_SEED)
    di = np.searchsorted(boot.days, M.day[disc])
    log(" market search: %d conditions; %d searched stock-days (half A, %s on), screened on %d of them" % (
        A, len(disc), DISCOVERY_FROM, len(S)))
    res = {}
    for h in M.holds:
        ys = M.excess[h][S].astype(np.float64)
        ys = np.where(np.isfinite(ys), ys, 0.0)
        scr = SL.screen_open(MAb, ys, fam, min_s, SL.KEEP)
        for lst, sign, key in (("buy", 1.0, "buy"), ("avoid", -1.0, "skip")):
            y = sign * ys

            def earnf(c, y=y):
                return SL.earn_quick_open(MAb, c, y, di_s, nd_s)
            pairs, _, w0 = SL.walk([scr[key]["pairs"]], min_s, SL.TRIPLE_PAIRS, earnf, size=2)
            T3 = SL.screen_open_triples(MAb, ys, fam, pairs, min_s, SL.KEEP, sign)
            fin, qb, w1 = SL.walk([scr[key]["singles"], scr[key]["pairs"], T3], min_s, SL.FINALISTS, earnf)
            rows = [{"cand": c, "screen_lb": q, **eval_market(lst, h, c, M, atoms, disc, boot, di, years)}
                    for c, q in zip(fin, qb)]
            T = SL._table(rows, atoms)
            cnt = {"singles": int(np.isfinite(scr[key]["singles"]["lb"]).sum()),
                   "pairs_kept": len(scr[key]["pairs"]["lb"]) if scr[key]["pairs"] is not None else 0,
                   "triples_kept": len(T3["lb"]) if T3 is not None else 0, "earn_checked": w0 + w1,
                   "finalists": len(T), "qualify": int(T["qualifies"].sum()) if len(T) else 0}
            res[("market", lst, h)] = (T, cnt)
            log("   market %s, hold %d: %d finalists, %d qualify" % (lst, h, cnt["finalists"], cnt["qualify"]))
    return res, disc


def judge(lst, vals, days, B_):
    """The yardstick on a judge's stock-days: mean, 95% interval (shown), and the one-sided p that it is on the right
    side (normal approximation from the 2,000 resamples' standard deviation) - the p the correction uses."""
    vals = np.asarray(vals, float)
    days = np.asarray(days)
    ok = np.isfinite(vals)
    vals, days = vals[ok], days[ok]
    n = len(vals)
    if n < 2:
        return {"n": n, "mean": float(np.mean(vals)) if n else np.nan, "lo": np.nan, "hi": np.nan, "p": 1.0,
                "verdict": "TOO FEW"}
    nd = len(B_.days)
    di = np.searchsorted(B_.days, days)
    with np.errstate(invalid="ignore", divide="ignore"):
        S = B_.M @ np.bincount(di, weights=vals, minlength=nd)
        C = B_.M @ np.bincount(di, minlength=nd).astype(float)
        mb = S / np.where(C > 0, C, np.nan)
    lo, hi = float(np.nanpercentile(mb, 2.5)), float(np.nanpercentile(mb, 97.5))
    sd = float(np.nanstd(mb))
    mean = float(vals.mean())
    sign = 1.0 if lst in ("buy", "trigger") else -1.0
    z = sign * mean / sd if sd > 0 else (np.inf if sign * mean > 0 else -np.inf)
    p = float(0.5 * math.erfc(z / math.sqrt(2.0))) if np.isfinite(z) else (0.0 if z > 0 else 1.0)
    good = (lo > 0) if sign > 0 else (hi < 0)
    bad = (hi < 0) if sign > 0 else (lo > 0)
    return {"n": n, "mean": mean, "lo": lo, "hi": hi, "p": p,
            "verdict": "HOLDS" if good else "WORSE" if bad else "NOT SHOWN"}


def decide(judged, alpha=ALPHA):
    """CONFIRMED when, on every available judge, the rule is on the right side with a one-sided p at most alpha / K
    (K = the rules judged in that part: Bonferroni). WORSE when a judge's interval is on the wrong side."""
    K = max(1, len(judged))
    thr = alpha / K
    for rec in judged.values():
        js = [rec[k] for k in ("stocks", "years") if k in rec and rec[k].get("verdict") not in ("NOT AVAILABLE",)]
        if not js:
            rec["verdict"] = "NOT JUDGED"
        elif all(j.get("p", 1.0) <= thr and j["verdict"] == "HOLDS" for j in js):
            rec["verdict"] = "CONFIRMED"
        elif any(j["verdict"] == "WORSE" for j in js):
            rec["verdict"] = "WORSE"
        else:
            rec["verdict"] = "NOT CONFIRMED"
        rec["threshold"] = thr
    return K, thr


def market_judges(M, atoms, res, log=LOG):
    """Each qualified rule (the top 5 and the top 5 with Soul) once on the hidden stocks (half B, 2020 on) and the
    hidden years (every stock before 2020); CONFIRMED by decide()."""
    hs = np.flatnonzero(M.hid_stocks)
    hy = np.flatnonzero(M.hid_years)
    hy_ok = M.hid_years_days >= HIDDEN_YEARS_MIN_DAYS
    Bs = SU.Boot(M.day[hs], B=SL.BOOT_B, block=SL.BOOT_BLOCK, seed=SL.BOOT_SEED) if len(hs) > 1 else None
    By = SU.Boot(M.day[hy], B=SL.BOOT_B, block=SL.BOOT_BLOCK, seed=SL.BOOT_SEED) if hy_ok and len(hy) > 1 else None
    disc = np.flatnonzero(M.disc)
    out, lists = {}, {}

    def measure(lst, h, m_of):
        rec = {}
        for nm, rows, B_ in (("stocks", hs, Bs), ("years", hy, By)):
            if B_ is None:
                rec[nm] = {"verdict": "NOT AVAILABLE", "n": 0, "p": 1.0}
                continue
            m = m_of(rows)
            rec[nm] = judge(lst, M.excess[h][rows][m], M.day[rows][m], B_)
            rec[nm]["net"] = float(np.nanmean(M.net[h][rows][m])) if m.any() else np.nan
        return rec
    for key, (T, cnt) in res.items():
        _, lst, h = key
        top = market_top(T, M, atoms, disc, SL.TOP)
        soul = market_top(T, M, atoms, disc, SL.TOP, need=lambda c: any(atoms[x]["soul"] for x in c))
        opn = market_top(T, M, atoms, disc, SL.OPEN, only_q=False)
        lists[key] = {"top": top, "soul": soul, "open": opn}
        for c in dict.fromkeys(top + soul):
            out[(key, c)] = measure(lst, h, lambda rows, c=c: rule_mask(M, atoms, c, rows))
        if top:
            def um(rows, top=top):
                m = np.zeros(len(rows), bool)
                for c in top:
                    m |= rule_mask(M, atoms, c, rows)
                return m
            lists[key]["union"] = measure(lst, h, um)
        else:
            lists[key]["union"] = {}
    K, thr = decide(out)
    for key in lists:
        lists[key]["confirmed"] = sum(1 for (k, c), r in out.items() if k == key and r["verdict"] == "CONFIRMED")
        lists[key]["judged"] = sum(1 for (k, c) in out if k == key)
        log("   judges, market %s hold %d: %d judged, %d CONFIRMED" % (key[1], key[2], lists[key]["judged"],
                                                                         lists[key]["confirmed"]))
    log("   market: %d rules judged; each needs p <= %.2g on every judge (0.05 / %d)" % (K, thr, K))
    return out, lists, K, thr


def market_money(M, atoms, lists, log=LOG):
    """The hidden years with Rs 5 L in 3 equal slots (setuplab's book), no MTF and MTF 2x: every eligible stock vs
    each BUY list's rules and the market without each AVOID list's stocks; the same open in a random order, the
    average of 5 orders."""
    hy = np.flatnonzero(M.hid_years)
    if M.hid_years_days < HIDDEN_YEARS_MIN_DAYS or not len(hy):
        return pd.DataFrame()
    rows = []
    t0 = int(M.i1[hy].min())
    for h in M.holds:
        base_m = np.ones(len(hy), bool)
        arms = {"every eligible stock (buy everything), hold %d" % h: base_m}
        for (part, lst, hh), L in lists.items():
            if hh != h or not L["top"]:
                continue
            m = np.zeros(len(hy), bool)
            for c in L["top"]:
                m |= rule_mask(M, atoms, c, hy)
            if lst == "buy":
                arms["BUY rules, hold %d" % h] = m
            else:
                arms["every eligible stock without the AVOID stocks, hold %d" % h] = ~m
        for name, m in arms.items():
            r = hy[m]
            ok = np.isfinite(M.net[h][r]) & (M.i1[r] + h - 1 < len(M.cal))
            r = r[ok]
            if not len(r):
                continue
            ent, ex = M.i1[r].astype(np.int64), (M.i1[r] + h - 1).astype(np.int64)
            t1 = int(ex.max())
            years = max(1e-9, float((M.cal[t1] - M.cal[t0]) / np.timedelta64(1, "D")) / 365.25)
            for lev in (1, 2):
                st = []
                for sd in MONEY_SEEDS:
                    prio = np.random.default_rng(sd).random(len(r))
                    eq, n, sk = SU.run_sim(ent, ex, M.net[h][r], prio, M.sym[r], t0, t1, M.cal, MONEY_SLOTS, lev)
                    st.append(SU.run_book_stats(eq, n, sk, years))
                rows.append({"book": name, "hold": h, "mtf": "2x" if lev == 2 else "none", "slots": MONEY_SLOTS,
                             "from": str(M.cal[t0]), "to": str(M.cal[t1]),
                             "cagr": float(np.mean([s["cagr"] for s in st])),
                             "worst_fall": float(np.mean([s["worst_fall"] for s in st])),
                             "end_rs": float(np.mean([s["end_rs"] for s in st])),
                             "per_week": float(np.mean([s["per_week"] for s in st])), "candidates": int(len(r))})
        log("   money in the hidden years, hold %d: %d books" % (h, len(arms)))
    return pd.DataFrame(rows)


# ====================================================================================================== picks
SNAP_SKIP = re.compile(r"label|^post_|_name$|_list$|_text$|_reason$")
SNAP_RAW = re.compile(r"(^|_)(open|high|low|close|vwap|price|entry)$")   # raw prices; codes are kept (one per value)


def snap_values(book, R, W):
    """Each pick's context known at the signal close: every numeric pre_* column of the watchlist (raw prices and
    names left out; codes kept - one condition per value), rank 1-3, both engines, D1's weekday."""
    wl = book.wl.iloc[R].reset_index(drop=True)
    out = {}
    for c in wl.columns:
        lc = str(c).lower()
        if not lc.startswith("pre_") or SNAP_SKIP.search(lc) or SNAP_RAW.search(lc[4:]):
            continue
        v = pd.to_numeric(wl[c], errors="coerce").to_numpy(float)
        if np.isfinite(v).mean() >= 0.05 and len(np.unique(v[np.isfinite(v)])) >= 2:
            out["ctx_" + lc[4:]] = v
    out["ctx_rank_1_3"] = (W.rank <= 3).astype(float)
    eng_by_key = pd.Series(W.eng).groupby(W.key).nunique()
    out["ctx_both_engines"] = (eng_by_key.reindex(W.key).to_numpy() >= 2).astype(float)
    out["ctx_d1_weekday"] = pd.DatetimeIndex(W.cal[np.minimum(W.i1, len(W.cal) - 1)]).weekday.to_numpy().astype(float)
    return out


def snap_atoms(snaps, ref):
    A = []
    for f, v in snaps.items():
        x = v[ref]
        x = x[np.isfinite(x)]
        u = np.unique(x)
        if len(u) < 2:
            continue
        if len(u) <= SNAP_MAX_CODES:
            for val in u:
                w = ("%s is %g" % (f, val)) if f != "ctx_d1_weekday" else "D1 is a %s" % SU.WEEKDAYS[int(val)] \
                    if 0 <= int(val) < 5 else "%s is %g" % (f, val)
                A.append({"id": "%s=%g" % (f, val), "fam": "S|" + f, "f": f, "kind": "snap_eq", "value": float(val),
                          "soul": False, "words": w})
        else:
            q = np.quantile(x, [1 / 3, 0.5, 2 / 3])
            for code, lo_i, hi_i, w in SL.LEVELS:
                lo = -np.inf if lo_i is None else float(q[lo_i])
                hi = np.inf if hi_i is None else float(q[hi_i])
                A.append({"id": "%s:%s" % (f, code), "fam": "S|" + f, "f": f, "kind": "snap_lvl", "lo": lo, "hi": hi,
                          "soul": False, "words": "%s %s" % (f, w) + (" (<= %.6g)" % hi if lo_i is None else
                                                                      " (> %.6g)" % lo)})
    return A


def snap_masks(atoms, snaps, W):
    sb = (W.sess.astype(np.uint8) * BITS).sum(1).astype(np.uint8)
    DM = np.zeros((len(atoms), W.n), np.uint8)
    for i, a in enumerate(atoms):
        v = snaps[a["f"]]
        with np.errstate(invalid="ignore"):
            ok = (v == a["value"]) if a["kind"] == "snap_eq" else (v > a["lo"]) & (v <= a["hi"])
        DM[i] = np.where(ok, sb, 0).astype(np.uint8)
    return DM


def picks_world(data, panel, soul, dcols, scols, log=LOG):
    book, _ = SL.load_book(data, panel, soul, dcols, scols, log)
    feats = [f for f in dcols + scols if f in book.F and f + "_change" in book.F]
    ok = book.ok & np.isfinite(book.O[:, 1]) & np.isfinite(book.C[:, 5]) & (book.O[:, 1] > 0)
    R = np.flatnonzero(ok)
    O, C = book.O[R], book.C[R]
    W = SL.World(book, feats, set(scols))
    with np.errstate(invalid="ignore", divide="ignore"):
        nets = {"d5_close": W.netA.copy(), "d6_open": (O[:, 6] / O[:, 1] - 1) * 100 - COST,
                "d10_close": (C[:, 10] / O[:, 1] - 1) * 100 - COST}
    snaps = snap_values(book, R, W)
    book.F = {}
    W.half = halves(W.sym)
    return W, nets, snaps, feats


def _with_net(W, net):
    W2 = copy.copy(W)
    W2.netA = net
    return W2


def picks_search(W, nets, snaps, feats, scols, log=LOG):
    poolA = W.pool[W.half[W.pool] == 0]
    poolB = W.pool[W.half[W.pool] == 1]
    specs = SL.atom_specs(feats, set(scols))
    fa = SL.resolve(specs, W, poolA)
    sa = snap_atoms(snaps, poolA)
    atoms = fa + sa
    DM = np.vstack([SL.day_masks(fa, W), snap_masks(sa, snaps, W)]) if sa else SL.day_masks(fa, W)
    log(" picks search: %d conditions (%d from D's inputs and Soul, %d from the pick's context); %d pooled picks in "
        "half A searched, %d in half B hidden" % (len(atoms), len(fa), len(sa), len(poolA), len(poolB)))
    engA = {e: np.flatnonzero((W.eng == e) & (W.half == 0)) for e in ("D", "ENS")}
    res = {}
    for ex, _ in PICK_EXITS:
        WE = _with_net(W, nets[ex])
        ok = np.isfinite(WE.netA)
        pA = poolA[ok[poolA]]
        P = SL.make_pop(WE, pA)
        MAb = (DM[:, pA] & 1).astype(bool)
        EP = [(e, SL.make_pop(WE, p[ok[p]], e), (DM[:, p[ok[p]]] & 1).astype(bool)) for e, p in engA.items() if len(p)]
        r = SL.search_open(P, atoms, MAb, EP, log)
        for lst in ("buy", "skip"):
            res[("picks", lst, ex)] = r[lst]
    P = SL.make_pop(W, poolA)
    EPt = [(e, SL.make_pop(W, p, e), DM[:, p]) for e, p in engA.items() if len(p)]
    res[("picks", "trigger", "d5_close")] = SL.search_trig(P, atoms, DM[:, poolA], EPt, log)["trigger"]
    return res, atoms, DM, poolA, poolB


def picks_judges(W, nets, atoms, DM, poolA, poolB, res, log=LOG):
    """Each qualified rule (the top 5 and the top 5 with Soul) once on half B's picks; CONFIRMED by decide()."""
    out, lists = {}, {}
    for key, (T, cnt) in res.items():
        _, lst, ex = key
        WE = _with_net(W, nets[ex])
        ok = np.isfinite(WE.netA)
        pA, pB = poolA[ok[poolA]], poolB[ok[poolB]]
        PA, PB = SL.make_pop(WE, pA), SL.make_pop(WE, pB)
        MAa, MAb_ = (DM[:, pA] & 1).astype(bool), (DM[:, pB] & 1).astype(bool)
        DMa, DMb = DM[:, pA], DM[:, pB]
        top = SL.pick_top(T, lst, PA, MAa, DMa)
        soul = SL.pick_top(T, lst, PA, MAa, DMa, need=lambda c: any(atoms[x]["soul"] for x in c))
        opn = SL.pick_top(T, lst, PA, MAa, DMa, k=SL.OPEN, only_q=False)
        lists[key] = {"top": top, "soul": soul, "open": opn}
        B_ = SU.Boot(PB["day"], B=SL.BOOT_B, block=SL.BOOT_BLOCK, seed=SL.BOOT_SEED) if PB["n"] > 1 else None
        arB = np.arange(PB["n"])
        kind = "buy" if lst in ("buy", "trigger") else "avoid"

        def sel(c):
            if lst == "trigger":
                K_ = SL.trig_entries(DMb, c)
                return K_ < 5, PB["TL"][K_, arB], PB["NO6"][K_, arB]
            return SL.open_mask(MAb_, c), PB["lift"], PB["netA"]
        for c in dict.fromkeys(top + soul):
            if B_ is None:
                out[(key, c)] = {"stocks": {"verdict": "NOT AVAILABLE", "n": 0, "p": 1.0}}
                continue
            m, y, nt = sel(c)
            j = judge(kind, y[m], PB["day"][m], B_)
            j["net"] = float(np.nanmean(nt[m])) if m.any() else np.nan
            out[(key, c)] = {"stocks": j}
        if B_ is not None and top:
            m = np.zeros(PB["n"], bool)
            yy, nn = np.zeros(PB["n"]), np.zeros(PB["n"])
            for c in top:
                mc, y, nt = sel(c)
                new = mc & ~m
                yy[new], nn[new] = y[new], nt[new]
                m |= mc
            j = judge(kind, yy[m], PB["day"][m], B_)
            j["net"] = float(np.nanmean(nn[m])) if m.any() else np.nan
            lists[key]["union"] = {"stocks": j}
        else:
            lists[key]["union"] = {}
    K, thr = decide(out)
    for key in lists:
        lists[key]["confirmed"] = sum(1 for (k, c), r in out.items() if k == key and r["verdict"] == "CONFIRMED")
        lists[key]["judged"] = sum(1 for (k, c) in out if k == key)
        log("   judge, picks %s (%s): %d judged, %d CONFIRMED" % (key[1], key[2], lists[key]["judged"],
                                                                     lists[key]["confirmed"]))
    log("   picks: %d rules judged; each needs p <= %.2g on half B (0.05 / %d)" % (K, thr, K))
    return out, lists, K, thr


def market_on_picks(M, matoms, mlists, W, log=LOG):
    """Each market candidate read on your pooled picks (its own cut-offs): the picks it selects vs the day's other
    picks (D1 open to D5 close)."""
    if W is None:
        return pd.DataFrame()
    P = SL.make_pop(W, W.pool)
    B_ = SU.Boot(P["day"], B=SL.BOOT_B, block=SL.BOOT_BLOCK, seed=SL.BOOT_SEED)
    rows = []
    for key, L in mlists.items():
        _, lst, h = key
        for c in L["top"] + [x for x in L["soul"] if x not in L["top"]]:
            m = np.ones(P["n"], bool)
            okall = True
            for x in c:
                a = matoms[x]
                f = a["f"]
                if f not in W.V:
                    okall = False
                    break
                v, c0, c1 = W.V[f][P["pos"], 1], W.Cg[f][P["pos"], 1], W.Cg[f][P["pos"], 0]
                with np.errstate(invalid="ignore"):
                    if a["kind"] == "lvl":
                        mm = (v > a["lo"]) & (v <= a["hi"])
                    else:
                        mm = SL.MOVE_FN[a["code"]](c1, c0)
                m &= mm
            if not okall:
                continue
            j = judge("buy" if lst == "buy" else "avoid", P["lift"][m], P["day"][m], B_)
            rows.append({"list": "market %s hold %d" % (lst, h), "rule": " & ".join(matoms[x]["id"] for x in c),
                         "picks": j["n"], "lift": j["mean"], "lift_lo": j["lo"], "lift_hi": j["hi"],
                         "on_picks": j["verdict"], "net": float(np.nanmean(P["netA"][m])) if m.any() else np.nan})
    return pd.DataFrame(rows)


# ====================================================================================================== report
def _p(x, nd=2, sign=True):
    return SL._p(x, nd, sign)


def _ci3(m, lo, hi):
    return "%s [%s, %s]" % (_p(m), _p(lo), _p(hi))


def list_name(key):
    part, lst, x = key
    if part == "market":
        return "MARKET %s, hold %d sessions" % ({"buy": "BUY", "avoid": "AVOID"}[lst], x)
    return "PICKS %s%s" % ({"buy": "BUY at the D1 open", "skip": "SKIP", "trigger": "TRIGGER (wait on D1-D5)"}[lst],
                           "" if lst == "trigger" else ", sold at " + dict(PICK_EXITS)[x])


def _row(T, c):
    return T[T["cand"].apply(lambda x: tuple(x) == tuple(c))].iloc[0]


def _jt(j):
    if not j or j.get("verdict") in ("NOT AVAILABLE", None):
        return "-" if not j else j.get("verdict")
    return "%d: %s, p %.2g" % (j["n"], _ci3(j["mean"], j["lo"], j["hi"]), j.get("p", np.nan))


def write_report(d, info, res, judges, lists, MO, MP):
    L = ["# stratlab v1.0 - the strategy factory (%s)" % d.name, "",
         "%s | %s | %s | declaration %s | %s" % (VERSION, SL.VERSION, SU.VERSION, info["declaration_sha"][:16],
                                                 info["finished"]), "",
         "Every rule was built and chosen on HALF A of the stocks (2020-2026). Then each qualified rule met, once, the "
         "judges it never saw: HALF B (the other stocks, the same years) and, for the market, EVERY STOCK BEFORE 2020. "
         "CONFIRMED = right side on every judge with p at most 0.05 divided by the number of rules judged (%s). "
         "Research only: a rule worth trading is frozen on its own and judged forward." % info["thresholds"], "",
         "## Verdict", "", "| list | qualified on half A | judged | **CONFIRMED** | the top rules together: hidden stocks "
                           "| hidden years |", "|---|---|---|---|---|---|"]
    for key in res:
        T, cnt = res[key]
        Ls = lists.get(key, {})
        u = Ls.get("union", {})
        L.append("| %s | %d | %d | **%d** | %s | %s |" % (list_name(key), cnt["qualify"], Ls.get("judged", 0),
                                                         Ls.get("confirmed", 0), _jt(u.get("stocks")),
                                                         _jt(u.get("years")) if key[0] == "market" else "-"))
    L += ["", "Numbers: stock-days, the mean of the yardstick in points [95%] and its one-sided p - market: vs every "
          "eligible stock bought at the same open; picks: vs the day's other picks (TRIGGER: its trades vs the day's "
          "D1-open picks). AVOID / SKIP want it below 0.", ""]
    conf = [(key, c) for (key, c), r in judges.items() if r.get("verdict") == "CONFIRMED"]
    L += ["## CONFIRMED rules", ""]
    if not conf:
        L += ["None. Every rule that qualified on half A failed at least one judge it never saw (or did not clear the "
              "corrected threshold): what it showed on half A is best read as luck.", ""]
    for key, c in conf:
        T = res[key][0]
        r = _row(T, c)
        j = judges[(key, c)]
        ym = "excess" if key[0] == "market" else "lift"
        L.append("- **%s** - %s. Half A: %d trades (%.1f a year), net %s, yardstick %s. Hidden stocks: %s.%s" % (
            list_name(key), r["text"], r["n"], r["per_year"], _ci3(r["net"], r["net_lo"], r["net_hi"]),
            _ci3(r[ym], r[ym + "_lo"], r[ym + "_hi"]), _jt(j.get("stocks")),
            (" Hidden years: %s." % _jt(j["years"])) if "years" in j and j["years"].get("verdict") != "NOT AVAILABLE"
            else ""))
    L.append("")
    for key in res:
        T, cnt = res[key]
        Ls = lists.get(key, {})
        L += ["## %s" % list_name(key), "",
              "Searched on half A: %d single conditions, the best %d pairs and %d triples kept by the quick screen, %d "
              "checked for every condition earning its place, %d through the block bootstrap; **%d qualify**." % (
                  cnt["singles"], cnt["pairs_kept"], cnt["triples_kept"], cnt["earn_checked"], cnt["finalists"],
                  cnt["qualify"]), ""]
        if not len(T):
            L += ["No rule reached the bootstrap.", ""]
            continue
        mk = key[0] == "market"
        ym = "excess" if mk else "lift"
        L += ["| | rule | half A: trades/yr | net % [95%] | yardstick, pp [95%] | bad years | hidden stocks | hidden "
              "years | verdict |", "|---|---|---|---|---|---|---|---|---|"]
        for c in list(dict.fromkeys(Ls.get("top", []) + Ls.get("soul", []) + Ls.get("open", []))):
            r = _row(T, c)
            j = judges.get((key, c), {})
            tag = ("R" if c in Ls.get("top", []) else "") + ("S" if c in Ls.get("soul", []) else "")
            L.append("| %s | %s%s | %.1f | %s | %s | %d of %d | %s | %s | %s |" % (
                tag or "-", r["text"], "" if r["qualifies"] else " *(does not qualify)*", r["per_year"],
                _ci3(r["net"], r["net_lo"], r["net_hi"]), _ci3(r[ym], r[ym + "_lo"], r[ym + "_hi"]), r["bad_years"],
                r["years"], _jt(j.get("stocks")), _jt(j.get("years")) if mk else "-",
                j.get("verdict", "not judged (did not qualify)" if not r["qualifies"] else "-")))
        L += ["", "R = a top qualifier, S = a top qualifier with a Soul condition (both judged), - = among the 10 best "
              "by score (shown, judged only if also R or S).", ""]
    if MP is not None and len(MP):
        L += ["## The market's rules on your picks (D1 open to D5 close, vs the day's other picks; plain 95%, "
              "information)", "", "| market list | rule | picks | vs the day's other picks, pp [95%] | net % |",
              "|---|---|---|---|---|"]
        for r in MP.itertuples(index=False):
            L.append("| %s | %s | %d | %s %s | %s |" % (r.list, r.rule, r.picks, _ci3(r.lift, r.lift_lo, r.lift_hi),
                                                       r.on_picks, _p(r.net)))
        L.append("")
    if MO is not None and len(MO):
        L += ["## Money in the hidden years (before 2020; Rs 5 L, 3 equal slots, the same open in a random order, the "
              "mean of 5 orders)", "", "| book | MTF | a year % | worst fall % | Rs 5 L became | trades a week |",
              "|---|---|---|---|---|---|"]
        for r in MO.itertuples(index=False):
            L.append("| %s | %s | %s | %s | Rs %s | %.1f |" % (r.book, r.mtf, _p(r.cagr), _p(r.worst_fall, sign=False),
                                                              "{:,.0f}".format(r.end_rs), r.per_week))
        L.append("")
    L += ["## Inputs and checks", ""] + ["- %s: %s" % kv for kv in info["checks"].items()]
    L += ["", "## How to read it", "",
          "- Start with the verdict table, then the CONFIRMED rules. A rule that qualified on half A but is NOT "
          "CONFIRMED did not survive data it never saw (or not clearly enough after the correction).",
          "- MARKET rules select stocks from the whole market each day; their yardstick is buying every eligible stock "
          "at the same open. PICKS rules work inside D's and ENS's picks; their yardstick is the day's other picks.",
          "- The search is very open (plain 95% per rule, thousands of rules); the judges are strict (Bonferroni over "
          "the rules they judge). They run once, after the search; nothing is re-run to change them.", "",
          "## Limits", "",
          "- Half B shares the market days with half A: a rule that only finds good market days cannot pass (the "
          "yardstick takes the day out), but stocks in one sector can move together across the halves.",
          "- The years before 2020: the engines were trained on them, but no rule search used them. The cache keeps the "
          "stocks that still trade (delisted ones are missing), which flatters buying beaten-down stocks there.",
          "- Market targets are the panel's label_oc_h (next open to the h-th close); lower-circuit locks are not "
          "modelled. Picks use setuplab's watchlist path.",
          "- Compared with buying everything / the day's other picks, not with the frozen tree. A CONFIRMED rule is "
          "compared with the tree next, then frozen and judged forward.", ""]
    (d / "STRATLAB.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ====================================================================================================== the command
def cmd_run(a, log=LOG):
    t_start = time.time()
    if SL.VERSION != NEEDS["soullab"] or SU.VERSION != NEEDS["setuplab"]:
        raise STError("stratlab needs %s and %s beside it (found %s, %s)" % (NEEDS["soullab"], NEEDS["setuplab"],
                                                                            SL.VERSION, SU.VERSION))
    dpath, decl = load_declaration()
    dsha = decl["sha256"]
    root = Path(a.root)
    if not root.is_dir():
        raise STError("--root %s is not a folder" % root)
    out = guard_out(a.out, root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    soul = Path(a.soul) if a.soul else root / "panel" / "soul" / "soul_v3_open.parquet"
    if not panel.is_file():
        raise STError("panel not found: %s" % panel)
    try:
        dfeats, dsrc, dsha_src = SL.d_features(root)
        smeta, scols, smp = SL.soul_meta(soul)
    except SL.SLError as e:
        raise STError(str(e))
    dcols, excl = SL.choose_features(dfeats, panel)
    parts = ("market", "picks") if a.part == "both" else (a.part,)
    log("%s: parts %s; D's inputs %d listed, %d used; Soul %d (%s, lag %s)" % (
        VERSION, " + ".join(parts), len(dfeats), len(dcols), len(scols), smeta.get("code"),
        smeta["config"].get("lag")))
    checks = {"D's input list": "%s (sha256 %s): %d listed, %d used (%s)" % (
        dsrc, dsha_src[:16], len(dfeats), len(dcols), ", ".join(
            "%d %s" % (n_, r_) for r_, n_ in pd.Series([e[1] for e in excl]).value_counts().items()) if excl else
        "none left out"),
        "Soul": "%s (%s, lag %s > horizon %s; %d features)" % (soul, smeta.get("code"), smeta["config"].get("lag"),
                                                              smeta["config"].get("horizon"), len(scols)),
        "stock halves": "sha256('%s|SYMBOL') even = half A (searched), odd = half B (hidden)" % SALT}
    M = W = None
    if "market" in parts:
        elig = elig_column(a.elig_col)
        M = load_market(panel, soul, dcols[:SL.GROUP] if a.check_only else dcols, scols, elig, root, log)
        yrs = M.day[M.hid_years]
        checks["market"] = ("%d eligible stock-days (%s to %s; %d ETF rows left out); searched (half A, %s on) %d; "
                            "hidden stocks %d; hidden years %d stock-days on %d sessions (%s to %s)%s; holds %s" % (
                                M.n, M.day.min(), M.day.max(), M.etfs, DISCOVERY_FROM, int(M.disc.sum()),
                                int(M.hid_stocks.sum()), int(M.hid_years.sum()), M.hid_years_days,
                                yrs.min() if len(yrs) else "-", yrs.max() if len(yrs) else "-",
                                "" if M.hid_years_days >= HIDDEN_YEARS_MIN_DAYS else " - NOT ENOUGH: that judge is "
                                                                                     "not available",
                                ", ".join(map(str, M.holds))))
        log(" " + checks["market"])
    if "picks" in parts:
        W, nets, snaps, feats_p = picks_world(a.data, panel, soul, dcols[:SL.GROUP] if a.check_only else dcols, scols,
                                              log)
        jc = SL.join_check(W, panel, soul, [f for f in dcols if f in feats_p], [f for f in scols if f in feats_p])
        if jc["mismatches"]:
            raise STError("the join check failed - a pick does not read its own row: " + "; ".join(jc["examples"]))
        checks["picks"] = ("%d complete picks, pooled %d stock-days (half A %d, half B %d); %d context columns; join "
                           "check %d values, 0 mismatches" % (W.n, len(W.pool), int((W.half[W.pool] == 0).sum()),
                                                              int((W.half[W.pool] == 1).sum()), len(snaps),
                                                              jc["checked"]))
        log(" " + checks["picks"])
    nA = 12 * (len(dcols) + len(scols))
    est = 0.0
    if M is not None:
        est += 3 * len(M.holds) * (nA ** 2) * min(SAMPLE, int(M.disc.sum())) / 4e10 + 600
    if W is not None:
        nAp = nA + 60
        est += (nAp ** 2 / 2) * (len(W.pool) / 2) * 6.5e-9 + 600
    checks["estimated time"] = "the search about %.1f to %.1f hours, plus reading %d columns" % (
        est / 3600 * 0.6, est / 3600 * 2.0, len(dcols))
    log(" estimated time: " + checks["estimated time"])
    if a.check_only:
        log("CHECK OK - inputs readable; nothing searched or written. Run again without --check-only.")
        return 0
    d = SU.new_run_dir(out, "STRATLAB")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": dsha, "parts": parts, "d_features_sha256": dsha_src,
                 "soul_meta_sha256": SL.sha256_file(smp), "panel": str(panel), "data": str(a.data)})
    res, judges, lists = {}, {}, {}
    thresholds = []
    matoms = None
    MO = MP = None
    if M is not None:
        matoms = market_atoms(M.feats, M.soul, M.cuts)
        r, _ = market_search(M, matoms, log)
        j, ls, Km, thm = market_judges(M, matoms, r, log)
        thresholds.append("market %d rules, p <= %.2g" % (Km, thm))
        res.update(r)
        judges.update(j)
        lists.update(ls)
        MO = market_money(M, matoms, ls, log)
    if W is not None:
        r, patoms, DM, poolA, poolB = picks_search(W, nets, snaps, feats_p, scols, log)
        j, ls, Kp, thp = picks_judges(W, nets, patoms, DM, poolA, poolB, r, log)
        thresholds.append("picks %d rules, p <= %.2g" % (Kp, thp))
        res.update(r)
        judges.update(j)
        lists.update(ls)
    if M is not None and W is not None:
        MP = market_on_picks(M, matoms, {k: v for k, v in lists.items() if k[0] == "market"}, W, log)
    # ---- outputs
    names = []
    atoms_of = {}
    for key in res:
        atoms_of[key] = matoms if key[0] == "market" else patoms
    for key, (T, cnt) in res.items():
        X = T.copy()
        if len(X):
            jv = [judges.get((key, tuple(c)), {}) for c in X["cand"]]
            X["hidden_stocks"] = [j.get("stocks", {}).get("verdict", "") for j in jv]
            X["hidden_stocks_mean"] = [j.get("stocks", {}).get("mean", np.nan) for j in jv]
            X["hidden_years"] = [j.get("years", {}).get("verdict", "") for j in jv]
            X["hidden_years_mean"] = [j.get("years", {}).get("mean", np.nan) for j in jv]
            X["verdict"] = [j.get("verdict", "") for j in jv]
            X["cand"] = X["cand"].apply(lambda c: json.dumps(list(c)))
        fn = "rules_%s_%s_%s.csv" % key
        X.to_csv(d / fn, index=False, float_format="%.6g")
        names.append(fn)
    for fn, X in (("money_hidden_years.csv", MO), ("market_rules_on_picks.csv", MP)):
        (X if X is not None else pd.DataFrame()).to_csv(d / fn, index=False, float_format="%.6g")
        names.append(fn)
    cond_rows = []
    for nm, at in (("market", matoms), ("picks", patoms if W is not None else None)):
        if at:
            cond_rows += [{"part": nm, **{k: x.get(k) for k in ("id", "fam", "words", "lo", "hi", "value", "soul")}}
                          for x in at]
    pd.DataFrame(cond_rows).to_csv(d / "conditions.csv", index=False, float_format="%.6g")
    names.append("conditions.csv")

    def cdoc(key, cs):
        at = atoms_of[key]
        return [{"rule": " & ".join(at[x]["id"] for x in c), "text": " AND ".join(at[x]["words"] for x in c),
                 "verdict": judges.get((key, c), {}).get("verdict"),
                 "conditions": [{k: at[x].get(k) for k in ("id", "f", "kind", "code", "lo", "hi", "value")}
                                for x in c]} for c in cs]
    doc = {"tool": VERSION, "declaration_sha256": dsha, "run": d.name,
           "lists": {"%s %s %s" % key: {"top": cdoc(key, lists[key]["top"]), "soul": cdoc(key, lists[key]["soul"]),
                                        "union": lists[key].get("union"), "judged": lists[key].get("judged", 0),
                                        "confirmed": lists[key].get("confirmed", 0)} for key in res},
           "thresholds": thresholds}
    doc["sha256"] = SU.frozen_hash(json.loads(json.dumps(doc, default=float)))
    (d / "STRATLAB_CANDIDATES.json").write_text(json.dumps(doc, indent=2, default=float), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dpath.read_text(encoding="utf-8"), encoding="utf-8")
    names += ["STRATLAB_CANDIDATES.json", "DECLARATION.json"]
    secs = time.time() - t_start
    checks.pop("estimated time", None)
    checks["time"] = "%.1f hours" % (secs / 3600)
    info = {"declaration_sha": dsha, "finished": time.strftime("%Y-%m-%d %H:%M"), "checks": checks,
            "thresholds": "; ".join(thresholds) or "-"}
    write_report(d, info, res, judges, lists, MO, MP)
    names.insert(0, "STRATLAB.md")
    run = {"tool": VERSION, "soullab": SL.VERSION, "setuplab": SU.VERSION, "declaration_sha256": dsha,
           "checks": checks, "counts": {"%s %s %s" % k: v[1] for k, v in res.items()},
           "confirmed": {"%s %s %s" % k: lists[k].get("confirmed", 0) for k in res}, "thresholds": thresholds,
           "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__}
    (d / "RUN.json").write_text(json.dumps(run, indent=2, default=float), encoding="utf-8")
    names.append("RUN.json")
    SU.write_hashes(d, names)
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "confirmed_by_list": run["confirmed"], "confirmed": sum(1 for (k, c), r in judges.items()
                                                                         if r.get("verdict") == "CONFIRMED"),
                 "hours": round(secs / 3600, 2)})
    log("STRATLAB WRITTEN %s (%.1f hours)" % (d, secs / 3600))
    for key in res:
        log("  %-60s %d qualified, %d judged, %d CONFIRMED" % (list_name(key), res[key][1]["qualify"],
                                                                 lists[key].get("judged", 0),
                                                                 lists[key].get("confirmed", 0)))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="stratlab: the strategy factory")
    sub = ap.add_subparsers(dest="cmd")
    r = sub.add_parser("run")
    r.add_argument("--root", required=True, help="%%CACHE_DAILY_ROOT%%")
    r.add_argument("--data", required=True, help="setuplab's watchlist folder (WL_R1_10)")
    r.add_argument("--out", required=True, help="C:\\QuantData\\stratlab")
    r.add_argument("--soul", default=None, help="default <root>\\panel\\soul\\soul_v3_open.parquet")
    r.add_argument("--panel", default=None, help="default <root>\\panel_oc\\panel.parquet")
    r.add_argument("--elig-col", default=None, help="default: stage_b_screen.ELIG_COL")
    r.add_argument("--part", default="both", choices=["both", "market", "picks"])
    r.add_argument("--check-only", action="store_true")
    a = ap.parse_args(argv)
    if a.cmd != "run":
        ap.print_help()
        return 2
    try:
        return cmd_run(a)
    except (STError, SL.SLError) as e:
        print("REFUSED: %s" % e)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
