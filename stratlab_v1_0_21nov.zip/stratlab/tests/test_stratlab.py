"""
tests for stratlab v1.0 - synthetic worlds only; nothing real is read, nothing outside a temporary folder is written.

    python tests\\test_stratlab.py          (from the stratlab folder, in tradelab's env)

Ends with  VERIFIED (stratlab v1.0)  or  FAILED.
  b1  every condition's bit = the panel's own values, by hand (levels against the cut-offs; moves against the stock's
      previous rows)
  b2  the halves: sha256 parity; searched / hidden stocks / hidden years never overlap
  b3  the yardstick = the net minus the mean of every eligible stock that day, by hand; ETFs left out
  b4  a judge's number = the plain mean of the rule's hidden stock-days
  w1  PLANTED world (a market BUY and AVOID pair, Soul x feature; a picks BUY pair and a picks SKIP context): each
      found on half A and CONFIRMED by the judges it never saw; the money in the hidden years beats buying everything
  w2  FADING world (the market effect only in half A from 2020): found on half A, NOT confirmed
  w3  ABSENT world: nothing CONFIRMED anywhere
  w4  outputs hashed, ledger lines, refusals (edited declaration, output inside the cache)
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import stratlab as S  # noqa: E402
import soullab as SL  # noqa: E402
import setuplab as SU  # noqa: E402

sys.path.insert(0, str(Path(SL.__file__).resolve().parent / "tests"))
import test_soullab as TS  # noqa: E402

FAILS = []
N_OK = [0]


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   %s" % what)
    else:
        FAILS.append(what)
        print("  FAIL %s" % what)


def make_world(base: Path, seed: int, mode: str):
    """soullab's test world (panel features, Soul, picks) from mid-2015, plus: an eligibility column, label_oc_2/3/5
    in points, an ETF, and two context columns on the picks. Market plant (Soul x feature, at the signal close):
      BUY    soul_a in its high third AND f03 rose      -> +0.9 points a session held
      AVOID  soul_b in its low third AND f05 fell       -> -0.9 points a session held
    planted: every stock and year; fading: only half A from 2020; absent: none. Picks (planted only): soullab's three
    plants, and pre_env_code 3 -> the pick slides 9% by the D5 close."""
    rng = np.random.default_rng(seed + 1000)
    root, data, info = TS.make_world(base, seed=seed, plant=(mode == "planted"), start="2015-06-01")
    pp = root / "panel_oc" / "panel.parquet"
    P = pd.read_parquet(pp)
    so = pd.read_parquet(root / "panel" / "soul" / "soul_v3_open.parquet")
    P = P.merge(so[["timestamp", "symbol", "soul_a", "soul_b"]], on=["timestamp", "symbol"], how="left")
    P = P.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
    c03 = P.groupby("symbol")["f03"].diff().to_numpy()
    c05 = P.groupby("symbol")["f05"].diff().to_numpy()
    qa = np.nanquantile(P["soul_a"], 2 / 3)
    qb = np.nanquantile(P["soul_b"], 1 / 3)
    day = P["timestamp"].to_numpy().astype("datetime64[D]")
    half = S.halves(P["symbol"].to_numpy())
    zone = np.ones(len(P), bool) if mode == "planted" else (half == 0) & (day >= S.DISCOVERY_FROM) \
        if mode == "fading" else np.zeros(len(P), bool)
    buy = zone & (P["soul_a"].to_numpy() > qa) & (c03 > 0)
    avoid = zone & (P["soul_b"].to_numpy() < qb) & (c05 < 0)
    for h in (2, 3, 5):
        y = rng.normal(0.05 * h, 1.5 * np.sqrt(h), len(P)) + 0.9 * h * buy - 0.9 * h * avoid
        P["label_oc_%d" % h] = y
    P.loc[P.groupby("symbol").cumcount(ascending=False) < 5, ["label_oc_2", "label_oc_3", "label_oc_5"]] = np.nan
    P["elig"] = (rng.random(len(P)) > 0.03).astype(float)
    cal = np.sort(P["timestamp"].unique())
    E = pd.DataFrame({"symbol": "GOLDBEES", "timestamp": cal, "elig": 1.0, "label_oc_2": 10.0, "label_oc_3": 15.0,
                      "label_oc_5": 25.0})
    for c in P.columns:
        if c not in E.columns and c not in ("soul_a", "soul_b"):
            E[c] = rng.normal(0, 1, len(E))
    P = pd.concat([P.drop(columns=["soul_a", "soul_b"]), E], ignore_index=True)
    P.to_parquet(pp, index=False)
    W = pd.read_parquet(data / "watchlist.parquet")
    keys = W["signal_day"].astype(str) + "|" + W["symbol"]
    uk = keys.unique()
    env = dict(zip(uk, rng.integers(0, 4, len(uk))))
    vix = dict(zip(uk, rng.random(len(uk))))
    W["pre_env_code"] = keys.map(env).astype(float)
    W["pre_vix_pct250"] = keys.map(vix).astype(float)
    W["pre_home_index_name"] = "Smallcap 250"
    if mode == "planted":
        hit = W["pre_env_code"] == 3
        for k in range(1, 11):
            W.loc[hit, "close_%d" % k] = (1 + W.loc[hit, "close_%d" % k]) * (1 - 0.09 * min(k, 5) / 5) - 1
        W.loc[hit, "net_bp"] = W.loc[hit, "close_5"] * 1e4 - 35
    W.to_parquet(data / "watchlist.parquet", index=False)
    soul = root / "panel" / "soul" / "soul_v3_open.parquet"
    return root, data, soul


def run(root, data, soul, out, *extra):
    return S.main(["run", "--root", str(root), "--data", str(data), "--out", str(out), "--soul", str(soul),
                   "--elig-col", "elig"] + list(extra))


def runs(out):
    out = Path(out)
    if not out.is_dir():
        return []
    return sorted(p for p in out.iterdir() if p.is_dir() and re.fullmatch(r"STRATLAB_\d{8}_\d{3}", p.name))


def has(rule, f1, codes1, f2, codes2):
    ids = rule.split(" & ")
    return any("%s:%s" % (f1, c) in ids for c in codes1) and any("%s:%s" % (f2, c) in ids for c in codes2)


UP = ("up0", "upup", "dnup")
DN = ("dn0", "dndn", "updn")


def unit_checks(root, soul):
    print("b1-b4: the market data by hand")
    panel = root / "panel_oc" / "panel.parquet"
    dfeats, _, _ = SL.d_features(root)
    _, scols, _ = SL.soul_meta(soul)
    dcols, _ = SL.choose_features(dfeats, panel)
    M = S.load_market(panel, soul, dcols, scols, "elig", root, log=lambda *a: None)
    P = pd.read_parquet(panel)
    P["day"] = P["timestamp"].to_numpy().astype("datetime64[D]")
    P = P.sort_values(["symbol", "day"]).reset_index(drop=True)
    so = pd.read_parquet(soul)
    so["day"] = so["timestamp"].to_numpy().astype("datetime64[D]")
    so = so.sort_values(["symbol", "day"]).reset_index(drop=True)
    rng = np.random.default_rng(5)
    bad = 0
    for r in rng.integers(0, M.n, 400):
        f = (dcols + scols)[rng.integers(len(dcols) + len(scols))]
        src = so if f.startswith("soul_") else P
        g = src[src["symbol"] == M.sym[r]]
        hit = np.flatnonzero(g["day"].to_numpy() == M.day[r])
        if not len(hit):  # a market row with no source row of its own (e.g. an ETF that should not be there)
            bad += 1
            continue
        i = int(hit[0])
        x = g[f].to_numpy(float)
        v = x[i]
        c0 = x[i] - x[i - 1] if i >= 1 else np.nan
        c1 = x[i - 1] - x[i - 2] if i >= 2 else np.nan
        q = M.cuts[f]
        want = [v <= q[0], v > q[2], v <= q[1], v > q[1], c0 > 0, c0 < 0, c1 > 0, c1 < 0, c1 > 0 and c0 > 0,
                c1 < 0 and c0 < 0, c1 < 0 and c0 > 0, c1 > 0 and c0 < 0]
        got = [bool((int(M.B[f][r]) >> b) & 1) for b in range(12)]
        bad += [bool(w) for w in want] != got
    check(bad == 0, "b1 400 random stock-days: all 12 conditions = the panel's / Soul's own rows by hand")
    d = M.disc
    check(not (d & M.hid_stocks).any() and not (d & M.hid_years).any() and not (M.hid_stocks & M.hid_years).any()
          and (d | M.hid_stocks | M.hid_years).all(), "b2 searched, hidden stocks and hidden years never overlap and "
                                                      "cover every stock-day")
    check(all(S.half_of(s) == (int(hashlib.sha256(("stratlab-v1|" + s).encode()).hexdigest(), 16) % 2)
              for s in np.unique(M.sym)[:20]) and not (M.half[d] != 0).any() and not (M.half[M.hid_stocks] != 1).any(),
          "b2 the halves = sha256('stratlab-v1|SYMBOL') parity; the search sees half A only")
    E = pd.DataFrame({"day": M.day, "net": M.net[5]})
    want = E["net"] - E.groupby("day")["net"].transform("mean")
    check(np.allclose(want.to_numpy(), M.excess[5]) and "GOLDBEES" not in set(M.sym) and M.etfs > 0,
          "b3 the yardstick = the net minus the same day's mean of every eligible stock; the ETF left out")
    atoms = S.market_atoms(M.feats, M.soul, M.cuts)
    ia = next(i for i, a in enumerate(atoms) if a["id"] == "soul_a:H3")
    ib = next(i for i, a in enumerate(atoms) if a["id"] == "f03:up0")
    hs = np.flatnonzero(M.hid_stocks)
    m = S.rule_mask(M, atoms, (ia, ib), hs)
    B_ = SU.Boot(M.day[hs], B=200, block=10, seed=7)
    j = S.judge("buy", M.excess[5][hs][m], M.day[hs][m], B_)
    check(abs(j["mean"] - float(np.mean(M.excess[5][hs][m]))) < 1e-12 and j["n"] == int(m.sum()),
          "b4 a judge's number = the plain mean of the rule's hidden stock-days")


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return all(hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0]
               for ln in lines) and len(lines) >= 10


def main():
    t0 = time.time()
    tmp = Path(tempfile.mkdtemp(prefix="stratlab_test_"))
    try:
        print("%s tests (%s, %s; pandas %s, numpy %s)" % (S.VERSION, SL.VERSION, SU.VERSION, pd.__version__,
                                                          np.__version__))
        root, data, soul = make_world(tmp / "planted", 11, "planted")
        unit_checks(root, soul)
        print("w1: the planted world, both parts")
        out = tmp / "out1"
        check(run(root, data, soul, out) == 0, "w1 run returns 0")
        d = runs(out)[-1]
        doc = json.loads((d / "STRATLAB_CANDIDATES.json").read_text(encoding="utf-8"))
        sha = doc.pop("sha256")
        check(sha == SU.frozen_hash(json.loads(json.dumps(doc))), "w1 the candidates file carries its own sha256")
        L = doc["lists"]
        for h in (2, 3, 5):
            b = L["market buy %d" % h]
            ok = [c for c in b["top"] + b["soul"] if has(c["rule"], "soul_a", ("H3", "HI"), "f03", UP)]
            check(ok and any(c["verdict"] == "CONFIRMED" for c in ok),
                  "w1 market BUY hold %d: the planted Soul x feature pair found and CONFIRMED (%s)" % (
                      h, "; ".join("%s %s" % (c["rule"], c["verdict"]) for c in b["top"])))
            av = L["market avoid %d" % h]
            ok = [c for c in av["top"] + av["soul"] if has(c["rule"], "soul_b", ("L3", "LO"), "f05", DN)]
            check(ok and any(c["verdict"] == "CONFIRMED" for c in ok),
                  "w1 market AVOID hold %d: found and CONFIRMED" % h)
        bp = L["picks buy d5_close"]
        ok = [c for c in bp["top"] + bp["soul"] if has(c["rule"], "soul_a", ("H3", "HI"), "f03", UP) or
              has(c["rule"], "soul_c", ("H3", "HI"), "f07", UP)]
        check(ok and any(c["verdict"] == "CONFIRMED" for c in ok),
              "w1 picks BUY (D5 close): a planted pair found and CONFIRMED on the hidden stocks")
        sk = [c for k in ("d5_close", "d6_open", "d10_close") for c in L["picks skip %s" % k]["top"]]
        ok = [c for c in sk if "ctx_env_code=3" in c["rule"].split(" & ")]
        check(ok and any(c["verdict"] == "CONFIRMED" for c in ok),
              "w1 picks SKIP: the planted context (pre_env_code 3) found and CONFIRMED (%s)" % (
                  "; ".join(c["rule"] for c in sk[:6])))
        tr = L["picks trigger d5_close"]
        ok = [c for c in tr["top"] if has(c["rule"], "soul_c", ("H3", "HI"), "f07", UP)]
        check(ok and any(c["verdict"] == "CONFIRMED" for c in ok), "w1 picks TRIGGER: the planted pair CONFIRMED")
        MO = pd.read_csv(d / "money_hidden_years.csv")
        m5 = MO[(MO["hold"] == 5) & (MO["mtf"] == "none")].set_index("book")["cagr"]
        check(m5.filter(like="BUY rules").iloc[0] > m5.filter(like="buy everything").iloc[0] and
              m5.filter(like="without the AVOID").iloc[0] > m5.filter(like="buy everything").iloc[0],
              "w1 money in the hidden years: the BUY rules and the market without the AVOID stocks beat buying "
              "everything (3 slots)")
        MP = pd.read_csv(d / "market_rules_on_picks.csv")
        check(len(MP) > 0 and set(MP.columns) >= {"rule", "picks", "lift", "on_picks"},
              "w1 the market's rules read on the picks")
        md = (d / "STRATLAB.md").read_text(encoding="utf-8")
        check("## Verdict" in md and "CONFIRMED rules" in md and "Money in the hidden years" in md,
              "w1 STRATLAB.md: verdict first, the CONFIRMED rules, the money")
        check(outputs_ok(d), "w1 every output matches outputs.sha256")
        Lg = [json.loads(x) for x in (out / "stratlab_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        check([x["event"] for x in Lg] == ["start", "end"] and Lg[1]["confirmed"] > 0, "w1 the ledger: start and end")
        print("w2: the fading world (the market effect only in half A from 2020)")
        root2, data2, soul2 = make_world(tmp / "fading", 23, "fading")
        out2 = tmp / "out2"
        check(run(root2, data2, soul2, out2, "--part", "market") == 0, "w2 run returns 0")
        d2 = runs(out2)[-1]
        L2 = json.loads((d2 / "STRATLAB_CANDIDATES.json").read_text(encoding="utf-8"))["lists"]
        b = L2["market buy 5"]
        found = [c for c in b["top"] + b["soul"] if has(c["rule"], "soul_a", ("H3", "HI"), "f03", UP)]
        check(bool(found), "w2 the half-A-only effect is found on half A")
        check(found and all(c["verdict"] != "CONFIRMED" for c in found) and b["confirmed"] == 0,
              "w2 and NOT confirmed by the judges it never saw (%s)" % "; ".join(c["verdict"] for c in found))
        print("w3: the absent world")
        root3, data3, soul3 = make_world(tmp / "absent", 37, "absent")
        out3 = tmp / "out3"
        check(run(root3, data3, soul3, out3) == 0, "w3 run returns 0")
        d3 = runs(out3)[-1]
        allr = []
        for f in d3.glob("rules_*.csv"):
            X = pd.read_csv(f)
            if len(X) and "verdict" in X.columns:
                allr += list(X["verdict"].astype(str))
        check(allr and "CONFIRMED" not in allr, "w3 nothing CONFIRMED when nothing is planted (%d rules judged)" %
              sum(1 for v in allr if v not in ("", "nan")))
        print("w4: refusals")
        check(run(root, data, soul, tmp / "out4", "--check-only") == 0 and not runs(tmp / "out4"),
              "w4 --check-only searches and writes nothing")
        check(run(root, data, soul, root / "x") == 3, "w4 an output folder inside the cache is refused")
        dp = S.HERE / S.DECL_FILE
        keep = dp.read_bytes()
        try:
            dp.write_bytes(keep.replace(b"25 or more trades a year", b"20 or more trades a year", 1))
            check(run(root, data, soul, tmp / "out5") == 3, "w4 an edited declaration is refused")
        finally:
            dp.write_bytes(keep)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("\n%d checks, %d failed (%.0f s)" % (N_OK[0] + len(FAILS), len(FAILS), time.time() - t0))
    if FAILS:
        print("FAILED:\n  " + "\n  ".join(FAILS))
        return 1
    print("VERIFIED (%s)" % S.VERSION)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
