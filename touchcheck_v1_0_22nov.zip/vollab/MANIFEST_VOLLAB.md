# MANIFEST - vollab v1.0 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\vollab` (a research folder beside `tradelab`, `setuplab`, `treelab` and `triggerlab`). Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\vollab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `vollab.py` | 59fbb6467f5e7a06 | 67751 |
| `VOLLAB_DECLARATION.json` | b96fa6a2439576bf | 13127 |
| `README_VOLLAB.md` | 4b96cab7917f9e23 | 6007 |
| `tests\test_vollab.py` | 41b8bdcc51447ef5 | 33098 |
| `tests\vl_world.py` | 0606e264d95840d5 | 12891 |
| `touchcheck.py` | a24ffb0bfbd738f5 | 10820 |
| `tests\test_touchcheck.py` | 9bd308df14553bcb | 7174 |
| `MANIFEST_VOLLAB.md` | this file | - |

Needs, read only, as sibling folders (versions checked at every start):
- triggerlab v1.0 (triggerlab.py sha16 a0342ef93421a11b: Universe, load_paths, frozen_trades, book_sim, the gate);
- treelab v1.0 (treelab.py sha16 64ac932f584fade1);
- setuplab v1.1 (setuplab.py sha16 9979d418aecec6de, with FROZEN_SETUPS.json and TREE.json);
- tradelab v1.3.1 (tl_data.py sha16 46ceff88fdadda7f, tl_common.py sha16 ad7e75715da7556a);
- through tradelab's env (env_tradelab.bat): stage_e_execution (the shipped v1.2), intraday_cache and stage_b_screen (ELIG_COL) from bigmove_deploy\open_close.

Declaration: `VOLLAB_DECLARATION.json`, internal sha256 `386a894ca68ca283...`. Declared at 2026-11-22 20:40 IST; amended 2026-11-22 22:05 IST. It is checked at every start against this code's settings, and an edited file is refused.

Inputs:
- `%CACHE_DAILY_ROOT%\panel_oc\panel.parquet` (eligibility, the frozen setups' inputs);
- setuplab's watchlist folder (`C:\QuantData\setuplab\WL_R1_10`);
- the daily cache through stage E's loader; the 3-minute bars (`intraday_cache.store`).

## History
- v1.0 (22 Nov 2026): first build - the research report's Part 1 (stage A forecast race, stage B mappings S, T, R).
- touchcheck v1.0 (22 Nov 2026, 23:55): an add-on, run after vollab. It checks how accurate the +5% and +10% touch chances implied by M5 and by ATR14 are, on the tree's picks. Its measures are fixed in its header: Brier, skill, AUC, tenths, by year. `tests\test_touchcheck.py`: VERIFIED, 6 checks, both library versions.

## Verified (synthetic data only)
`tests\test_vollab.py` ends `VERIFIED (vollab v1.0) - 37 checks` on Python 3.13 with pandas 3.0.5 + numpy 2.5.3 (about 155 s) and with pandas 2.3.3 + numpy 2.4.1 (about 190 s).
- the 3-minute measures by a bar-by-bar loop (sessions with bars missing too); the usability rule = tradelab's IntradayStore._judge;
- the target, ATR14, close-to-close, Yang-Zhang and the HAR averages by loops; GARCH's filter, forecast and fit (recovers a simulated (0.08, 0.90));
- the firewall: prices changed after a day leave every earlier forecast of all 9 models unchanged; the 5-session embargo on every refit;
- QLIKE and its interval by an explicit loop; decision A both ways;
- the book = triggerlab's book_sim, and a hand loop with multipliers and caps; the yearly restart;
- S's multipliers (mean exactly 1), T's exits on hand-built paths, R's flags by loop, the matched variance ratio and the touch table by hand;
- PLANTED world: REPLACE (a HAR model), S ADOPTED; PLANTED_T: T ADOPTED; PLANTED_R: R ADOPTED; ABSENT: S, T, R NOT ADOPTED;
- refusals: edited declaration, --out inside the cache, no eligibility column, too little 3-minute history, bars stamped at their end; --check-only writes nothing; outputs hash-checked.

**Mutation test:** 27 deliberate bugs, each in its own copy of vollab.py; every one makes the tests fail. The first run caught 17 of 26: 9 slipped past (a missing 3-minute bar not carried, the daily models left unscaled, and seven in stage B's decision: R's cap from the entry day's own close, R's percentile including today, the raw variance ratio, no Holm, no 3 bp margin, no worst-fall condition). Checks were added for each (sessions with missing bars, kappa per refit, R's cap and percentiles by loop, decision B by hand, the reported ratios and Holm p's rebuilt from the daily returns), and those 9 plus one more (the HAR flag's percentile including today) are now caught. The 17: the 15-minute grid, the subsampled grids' ends, bipower's pi/2, the target's overnight and length, the embargo, training on the test month, GARCH's missing-return rule, Yang-Zhang's k, the usability count and its open check, REPLACE on the point estimate, S's clip, T's gap fill and window, the book's slot release, the yearly restart, stage B's start.
