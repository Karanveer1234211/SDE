"""
tests for touchcheck v1.0 - a synthetic world (tests/vl_world.py) run through vollab, then touchcheck; everything
rebuilt by hand. Ends with  VERIFIED (touchcheck v1.0)  or  FAILED.
  t1  each pick's D1 open, D1-D5 high and +5% / +10% touches = the world's own bars (every pick, by loop)
  t2  the chance formula by hand (sigma5 8%: P5 = 53.2%, P10 = 21.1%)
  t3  the touch rate, mean chance, Brier, skill and AUC (scikit-learn's roc_auc_score) by hand, per level, per forecast,
      per year
  t4  the tenths by hand; M5's Brier minus ATR14's and its interval by an explicit loop over the resampled days
  t5  refusals: a folder without pick_forecasts.csv, --out inside the cache
"""
from __future__ import annotations

import io
import math
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import touchcheck as TK  # noqa: E402
import vollab as VL  # noqa: E402
import vl_world as VW  # noqa: E402

FAILS, N_OK = [], [0]


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)


def same(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


def main():
    print("%s self-test (pandas %s, numpy %s)" % (TK.VERSION, pd.__version__, np.__version__))
    tmp = Path(tempfile.mkdtemp(prefix="touchcheck_test_"))
    try:
        root, data, W = VW.make_world(tmp / "w", 27, "planted", SU=VL.SU)
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = VL.main(["run", "--root", str(root), "--data", str(data), "--out", str(tmp / "vl"), "--stage-e-any"])
        runs = sorted((tmp / "vl").glob("VOLLAB_*"))
        if rc != 0 or not runs:
            check(False, "vollab runs on the world (rc %s) %s" % (rc, buf.getvalue()[-1500:]))
            return 1
        with redirect_stdout(io.StringIO()):
            rc = TK.main(["--root", str(root), "--run", str(runs[0]), "--out", str(tmp / "vl"), "--stage-e-any"])
        d = sorted((tmp / "vl").glob("TOUCH_*"))
        check(rc == 0 and len(d) == 1, "touchcheck runs on vollab's run folder")
        d = d[0]
        P = pd.read_csv(d / "touch_picks.csv", parse_dates=["signal_day"])
        cal = pd.DatetimeIndex(W["cal"])
        pos = {s: i for i, s in enumerate(W["syms"])}
        bad = 0
        for r in P.itertuples():
            t = cal.get_loc(r.signal_day)
            s = pos[r.symbol]
            o, hm = W["O"][s, t + 1], W["H"][s, t + 1:t + 6].max()
            bad += not (same(r.d1_open, o, 1e-6) and same(r.d1_d5_high, hm, 1e-6) and
                        bool(r.touched_5) == (hm >= o * 1.05 - 1e-9) and bool(r.touched_10) == (hm >= o * 1.10 - 1e-9))
        PF = pd.read_csv(runs[0] / "pick_forecasts.csv", parse_dates=["signal_day"])
        both = PF[np.isfinite(PF["sigma5_M5_pct"]) & np.isfinite(PF["sigma5_M0_pct"])]
        last_ok = both["signal_day"] <= cal[-6]
        check(bad == 0 and len(P) == int(last_ok.sum()) and len(P) > 1000,
              "t1 every pick's D1 open, D1-D5 high and touches = the world's bars (%d picks)" % len(P))
        p = TK.chance(5, np.array([8.0])), TK.chance(10, np.array([8.0]))
        ref = [2 * (1 - 0.5 * (1 + math.erf(0.625 / math.sqrt(2)))), 2 * (1 - 0.5 * (1 + math.erf(1.25 / math.sqrt(2))))]
        check(same([p[0][0], p[1][0]], ref, 1e-12) and abs(p[0][0] - 0.532) < 1e-3 and abs(p[1][0] - 0.2113) < 1e-3,
              "t2 the chance formula: sigma5 8%% -> P5 %.1f%%, P10 %.1f%%" % (100 * p[0][0], 100 * p[1][0]))
        from sklearn.metrics import roc_auc_score
        S = pd.read_csv(d / "touch_summary.csv")
        Y = pd.read_csv(d / "touch_years.csv")
        okm = True
        for k in (5, 10):
            y = P["touched_%d" % k].to_numpy(bool)
            for nm in ("M5", "ATR14"):
                pr = P["p%d_%s_pct" % (k, nm)].to_numpy() / 100
                col = "sigma5_M5_pct" if nm == "M5" else "sigma5_M0_pct"
                okm &= same(pr, 2 * (1 - VL.phi_arr(k / P[col].to_numpy())), 1e-12)
                r = S[(S["level_pct"] == k) & (S["forecast"] == nm)].iloc[0]
                br = np.mean((pr - y) ** 2)
                rate = y.mean()
                okm &= same([r["touch_rate_pct"], r["mean_chance_pct"], r["brier"], r["brier_skill"], r["auc"]],
                            [100 * rate, 100 * pr.mean(), br, 1 - br / (rate * (1 - rate)), roc_auc_score(y, pr)], 1e-9)
                for yy in sorted(set(P["signal_day"].dt.year)):
                    m = (P["signal_day"].dt.year == yy).to_numpy()
                    ry = Y[(Y["level_pct"] == k) & (Y["forecast"] == nm) & (Y["year"] == yy)].iloc[0]
                    okm &= same(ry["brier"], np.mean((pr[m] - y[m]) ** 2), 1e-9) and ry["picks"] == m.sum()
        check(okm, "t3 the chances, touch rates, Brier, skill, AUC (scikit-learn) and the per-year numbers by hand")
        Cb = pd.read_csv(d / "touch_tenths.csv")
        k, nm = 10, "M5"
        pr = P["p10_M5_pct"].to_numpy() / 100
        y = P["touched_10"].to_numpy(bool)
        q = pd.qcut(pd.Series(pr), 10, labels=False, duplicates="drop").to_numpy()
        c = Cb[(Cb["level_pct"] == k) & (Cb["forecast"] == nm)].set_index("tenth")
        okc = all(same([c.loc[g + 1, "predicted_pct"], c.loc[g + 1, "touched_pct"]],
                       [100 * pr[q == g].mean(), 100 * y[q == g].mean()], 1e-9) for g in np.unique(q))
        days = np.unique(P["signal_day"].to_numpy().astype("datetime64[D]"))
        B_ = VL.SU.Boot(days, B=300, block=10, seed=7)
        pr0 = P["p10_ATR14_pct"].to_numpy() / 100
        dd = (pr - y) ** 2 - (pr0 - y) ** 2
        dpos = {x: i for i, x in enumerate(days)}
        di = np.array([dpos[x] for x in P["signal_day"].to_numpy().astype("datetime64[D]")])
        ms = [np.concatenate([dd[di == j] for j in ix]).mean() for ix in B_.ix]
        est, lo, hi, _ = VL.boot_mean(B_, di, dd)
        check(okc and same([lo, hi], np.percentile(ms, [2.5, 97.5]), 1e-9) and same(est, dd.mean()),
              "t4 the tenths by hand; the Brier difference and its interval = an explicit loop over the resamples")
        with redirect_stdout(io.StringIO()) as b2:
            rc1 = TK.main(["--root", str(root), "--run", str(tmp), "--out", str(tmp / "vl"), "--stage-e-any"])
            rc2 = TK.main(["--root", str(root), "--run", str(runs[0]), "--out", str(root / "x"), "--stage-e-any"])
        check(rc1 == 3 and rc2 == 3 and len(list((tmp / "vl").glob("TOUCH_*"))) == 1,
              "t5 refused: a folder without pick_forecasts.csv, --out inside the cache; nothing written")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print("FAILED: %d of %d checks" % (len(FAILS), len(FAILS) + N_OK[0]))
        return 1
    print("VERIFIED (%s) - %d checks" % (TK.VERSION, N_OK[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
