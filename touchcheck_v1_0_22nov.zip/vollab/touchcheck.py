"""
touchcheck.py - touchcheck v1.0 (beside vollab v1.0): how accurate are the chances of touching +5% and +10%
that a 5-session volatility forecast implies? M5 (vollab's chosen HARQ forecast) against ATR14 (M0), on the tree's
picks.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\vollab
    python tests\\test_touchcheck.py
    python touchcheck.py --root %CACHE_DAILY_ROOT% --run C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn> --out C:\\QuantData\\vollab

Karan, 22 Nov 2026 23:49: "Now I want to see m5 volatility + p5 and p10 accuracy".

THE CHANCE (vollab's touch formula): P(touch +k%) = 2 x (1 - Phi(k / sigma5)), sigma5 = the forecast 5-session move in %
(a driftless stock watched all the time). Example: sigma5 = 8% -> P5 = 2(1 - Phi(0.625)) = 53%, P10 = 2(1 - Phi(1.25))
= 21%.

WHAT HAPPENED: from the D1 open (the entry) to the D5 close, did any daily high reach the open x 1.05 (x 1.10)? The
stock needs a daily bar on each of D1..D5 (NIFTY50's next five sessions).

THE MEASURES (fixed before any run): for each level and each forecast, on the picks with both forecasts and five bars:
  the touch rate and the mean predicted chance; the Brier score (mean of (chance - touched)^2) and its skill over always
  guessing the touch rate; the AUC (how often a pick that touched had a higher chance than one that did not; 0.5 =
  no better than a coin); calibration by tenths of the predicted chance; each by year; M5's Brier minus ATR14's with a
  95% day-block interval (setuplab's Boot: blocks of 10 days, 2,000 resamples, seed 7).
Reads vollab's pick_forecasts.csv and the daily cache (stage E's loader), read only. Writes only TOUCH_<date>_<nnn>\\
under --out and a line in vollab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import vollab as VL  # noqa: E402

SU, TD, TC = VL.SU, VL.TD, VL.TC
VERSION = "touchcheck v1.0"
LEVELS = (5.0, 10.0)
MODELS = (("M5", "sigma5_M5_pct"), ("ATR14", "sigma5_M0_pct"))
TENTHS = 10
LOG = VL.LOG


class TCError(Exception):
    pass


def chance(k, sig):
    """P(touch +k%) for a driftless stock with 5-session sd sig (both in %)."""
    sig = np.asarray(sig, float)
    out = np.full(sig.shape, np.nan)
    ok = np.isfinite(sig) & (sig > 0)
    out[ok] = 2 * (1 - VL.phi_arr(k / sig[ok]))
    return out


def auc(p, y):
    """Mann-Whitney AUC with average ranks; NaN without both outcomes."""
    p, y = np.asarray(p, float), np.asarray(y, bool)
    n1, n0 = int(y.sum()), int((~y).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = pd.Series(p).rank(method="average").to_numpy()
    return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def outcomes(F, mk, cal):
    """Each pick's D1 open and highest high over D1..D5 (NaN unless the stock has a bar on all five sessions)."""
    O1 = np.full(len(F), np.nan)
    HM = np.full(len(F), np.nan)
    day = F["signal_day"].to_numpy().astype("datetime64[D]")
    tpos = np.searchsorted(cal, day)
    syms = F["symbol"].astype(str).to_numpy()
    us = np.unique(syms)
    for i in range(0, len(us), 200):
        mk.load([str(s) for s in us[i:i + 200]])
    for s in us:
        rows = np.flatnonzero(syms == s)
        O, H, L, C, _ = VL.daily_on_cal(mk.series(str(s)), cal)
        for r in rows:
            t = int(tpos[r])
            if t >= len(cal) or cal[t] != day[r] or t + 5 >= len(cal):
                continue
            o, h = O[t + 1], H[t + 1:t + 6]
            if np.isfinite(o) and o > 0 and np.isfinite(h).all():
                O1[r], HM[r] = o, h.max()
    return O1, HM


def measures(p, y):
    p, y = np.asarray(p, float), np.asarray(y, float)
    rate = float(y.mean())
    brier = float(np.mean((p - y) ** 2))
    base = rate * (1 - rate)
    return {"picks": int(len(y)), "touch_rate_pct": 100 * rate, "mean_chance_pct": 100 * float(p.mean()),
            "brier": brier, "brier_skill": (1 - brier / base) if base > 0 else np.nan, "auc": auc(p, y > 0.5)}


def run(root, run_dir, out, stage_e_any=False, log=LOG):
    t0 = time.time()
    rd = Path(run_dir)
    pf = rd / "pick_forecasts.csv"
    if not pf.is_file():
        raise TCError("%s not found (give --run a VOLLAB_<date>_<nnn> folder)" % pf)
    o = VL.guard_out(out, root)
    F = pd.read_csv(pf)
    need = {"symbol", "signal_day"} | {c for _, c in MODELS}
    if not need <= set(F.columns):
        raise TCError("%s lacks %s" % (pf.name, sorted(need - set(F.columns))))
    F["signal_day"] = pd.to_datetime(F["signal_day"])
    F = F[np.isfinite(F[MODELS[0][1]]) & np.isfinite(F[MODELS[1][1]])].reset_index(drop=True)
    if not len(F):
        raise TCError("no pick has both forecasts")
    mk = TD.Market(root, TD.Production(stage_e_any=stage_e_any))
    cal = np.asarray(mk.cal).astype("datetime64[D]")
    O1, HM = outcomes(F, mk, cal)
    ok = np.isfinite(O1) & np.isfinite(HM)
    F = F[ok].reset_index(drop=True)
    O1, HM = O1[ok], HM[ok]
    if len(F) < 100:
        raise TCError("only %d picks have both forecasts and five daily bars" % len(F))
    F["d1_open"], F["d1_d5_high"] = O1, HM
    F["max_up_pct"] = 100 * (HM / O1 - 1)
    days, di = np.unique(F["signal_day"].to_numpy().astype("datetime64[D]"), return_inverse=True)
    B_ = SU.Boot(days, B=VL.BOOT_B, block=VL.BOOT_BLOCK, seed=VL.BOOT_SEED)
    summ, cal_rows, year_rows = [], [], []
    yrs = F["signal_day"].dt.year.to_numpy()
    for k in LEVELS:
        y = (F["max_up_pct"].to_numpy() >= k - 1e-9)
        F["touched_%d" % k] = y
        P = {}
        for nm, col in MODELS:
            P[nm] = chance(k, F[col].to_numpy(float))
            F["p%d_%s_pct" % (k, nm)] = 100 * P[nm]
            row = {"level_pct": k, "forecast": nm}
            row.update(measures(P[nm], y))
            summ.append(row)
            q = pd.qcut(pd.Series(P[nm]), TENTHS, labels=False, duplicates="drop").to_numpy()
            for g in np.unique(q):
                m = q == g
                cal_rows.append({"level_pct": k, "forecast": nm, "tenth": int(g) + 1, "picks": int(m.sum()),
                                 "predicted_pct": 100 * P[nm][m].mean(), "touched_pct": 100 * y[m].mean()})
            for yy in np.unique(yrs):
                m = yrs == yy
                r2 = {"level_pct": k, "forecast": nm, "year": int(yy)}
                r2.update(measures(P[nm][m], y[m]))
                year_rows.append(r2)
        d = (P["M5"] - y) ** 2 - (P["ATR14"] - y) ** 2
        est, lo, hi, _ = VL.boot_mean(B_, di, d)
        summ.append({"level_pct": k, "forecast": "M5 - ATR14 (Brier)", "picks": int(len(y)), "brier": est,
                     "brier_lo": lo, "brier_hi": hi})
    d = SU.new_run_dir(o, "TOUCH")
    S, Cb, Y = pd.DataFrame(summ), pd.DataFrame(cal_rows), pd.DataFrame(year_rows)
    S.to_csv(d / "touch_summary.csv", index=False)
    Cb.to_csv(d / "touch_tenths.csv", index=False)
    Y.to_csv(d / "touch_years.csv", index=False)
    F.to_csv(d / "touch_picks.csv", index=False, float_format="%.12g")
    L = ["# %s - the chances of +5%% and +10%% from M5 and ATR14" % VERSION, "",
         "vollab run %s; %d picks (%s .. %s) with both forecasts and five daily bars. P(touch +k%%) = 2(1 - Phi(k / "
         "sigma5)); touched = a daily high from D1 to D5 at or above the D1 open x (1 + k%%)." % (
             rd.name, len(F), str(days[0]), str(days[-1])), ""]
    for k in LEVELS:
        L += ["## +%d%%" % k, "", "| forecast | touched | mean chance | Brier (lower better) | skill vs the touch "
              "rate | AUC (0.5 = coin) |", "|---|---|---|---|---|---|"]
        for r in summ:
            if r["level_pct"] == k and r["forecast"] in ("M5", "ATR14"):
                L.append("| %s | %.1f%% | %.1f%% | %.4f | %+.3f | %.3f |" % (
                    r["forecast"], r["touch_rate_pct"], r["mean_chance_pct"], r["brier"], r["brier_skill"], r["auc"]))
        r = next(x for x in summ if x["level_pct"] == k and x["forecast"].startswith("M5 -"))
        L += ["", "M5's Brier minus ATR14's: %+.4f [%+.4f, %+.4f] (below 0 = M5 better)." % (r["brier"], r["brier_lo"],
                                                                                         r["brier_hi"]), "",
              "| tenth | M5 said | touched | ATR14 said | touched |", "|---|---|---|---|---|"]
        c5 = Cb[(Cb["level_pct"] == k) & (Cb["forecast"] == "M5")].set_index("tenth")
        c0 = Cb[(Cb["level_pct"] == k) & (Cb["forecast"] == "ATR14")].set_index("tenth")
        for t in sorted(set(c5.index) | set(c0.index)):
            a = c5.loc[t] if t in c5.index else None
            b = c0.loc[t] if t in c0.index else None
            L.append("| %d | %s | %s | %s | %s |" % (
                t, "%.1f%%" % a["predicted_pct"] if a is not None else "-",
                "%.1f%%" % a["touched_pct"] if a is not None else "-",
                "%.1f%%" % b["predicted_pct"] if b is not None else "-",
                "%.1f%%" % b["touched_pct"] if b is not None else "-"))
        L.append("")
    (d / "TOUCHCHECK.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    SU.write_hashes(d, ["touch_summary.csv", "touch_tenths.csv", "touch_years.csv", "touch_picks.csv",
                        "TOUCHCHECK.md"])
    VL.ledger(o, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "touchcheck", "tool": VERSION,
                  "run": d.name, "vollab_run": rd.name, "picks": int(len(F))})
    log("TOUCHCHECK WRITTEN %s (%d picks, %.1f minutes)" % (d, len(F), (time.time() - t0) / 60))
    for r in summ:
        if r["forecast"] in ("M5", "ATR14"):
            log(" +%d%% %-5s touched %.1f%%, mean chance %.1f%%, Brier %.4f, AUC %.3f" % (
                r["level_pct"], r["forecast"], r["touch_rate_pct"], r["mean_chance_pct"], r["brier"], r["auc"]))
    return d


def main(argv=None):
    ap = argparse.ArgumentParser(prog="touchcheck", description=VERSION)
    ap.add_argument("--root", required=True, help="the cache root (%%CACHE_DAILY_ROOT%%)")
    ap.add_argument("--run", required=True, help="a vollab run folder (C:\\QuantData\\vollab\\VOLLAB_<date>_<nnn>)")
    ap.add_argument("--out", required=True, help="the output folder (C:\\QuantData\\vollab)")
    ap.add_argument("--stage-e-any", dest="stage_e_any", action="store_true",
                    help="accept a stage_e_execution.py that is not the shipped v1.2")
    a = ap.parse_args(argv)
    try:
        run(Path(a.root), a.run, a.out, a.stage_e_any)
    except (TCError, VL.VLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
