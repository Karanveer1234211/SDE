# MANIFEST - tradelab v1.3.1 + setups add-on v1.4

Built 2026-10-25. Added the same evening: tl_journal.py (tl_journal v1.0), an add-on - every other file below is unchanged and tradelab is still v1.3.1. Folder: C:\Users\karanvsi\PyCharmMiscProject\tradelab (beside bigmove_deploy, never inside it). Outputs: C:\QuantData\tradelab. Production files are read, never written. 'tradelab v1' = unchanged since the v1 bundle (a6cbcd209f3bc759); v1.1 = unchanged since the v1.1 bundle (14584256599dd3aa); v1.2 = unchanged since the v1.2 bundle (9352fdf46e7cdfcb); v1.2.1 = unchanged since the v1.2.1 bundle (48afedf09a571524); v1.3 = unchanged since the v1.3 bundle (f5e3b6149876888c); v1.3.1 = new or changed in v1.3.1.

Added 2026-11-08: the setups add-on v1.0 - the seven frozen setups (setuplab v0.7) in the watch page, the backtester, the simulator and the journal, and a nightly setup scan in run_tonight.bat. New: tl_setups.py, tests/test_setups.py, strategies/setup_s2_d5.py; changed: the rows marked 'setups add-on v1.0'. tradelab's VERSION stays 'tradelab v1.3.1' (v2engine and pathlab check it). Needs setuplab v0.7 at C:\Users\karanvsi\PyCharmMiscProject\setuplab (SETUPLAB_DIR) writing to C:\QuantData\setuplab (SETUPLAB_OUT).

Evening of 2026-11-08: setups add-on v1.1 - tl_setups.py words each setup row with its zone (setuplab v0.8); tests/test_setups.py and tests/test_tradelab.py follow; tests/test_context.py: the section 13 simulator check no longer crashes the suite. Rows marked 'setups add-on v1.1'.

Night of 2026-11-08: setups add-on v1.1.1 - tests/test_tradelab.py only: production folders are taken off the test's path (the stand-ins are always used), tl_check is reloaded with the other modules, and a final check confirms no production folder came back. Rows marked 'setups add-on v1.1.1'.

Later the same night: setups add-on v1.1.2 - tl_watch.py v1.2.1 (watch_all.csv rebuilt from the day pages only; on Windows WATCH_*.csv also matched watch_all.csv and doubled its rows each run); tests/test_state.py (a planted look-alike file; the stand-in Run Now ends with exit /b like the real one; diagnostics); tests/test_tradelab.py (VERIFIED line). Rows marked 'setups add-on v1.1.2'.

9 Nov 2026: setups add-on v1.2 - calm / jumpy and setuplab v1.1's entry tree (TREE.json, frozen 9 Nov) in the journal, the backtester and the simulator: tl_setups.py v1.2 reads the newest TREE run (hash-checked), 'calm' becomes a pick attribute, the engine's tree entry / tree exit trade the tree (strategies/tree.py, new), the report gets a lane table, the journal a CALM / JUMPY AND THE ENTRY TREE band. Section 18 of the tests (8 checks; 12 planted bugs each caught). Rows marked 'setups add-on v1.2'.

11 Nov 2026: setups add-on v1.3 - the watch page shows one line per stock: one card per stock to buy at the next open (with the entry tree's orders and lanes), one card per purchase held (RRKABEL's 7 setup x pick rows = 1 card), the tree books' open positions; tl_setups.py v1.3, tl_watch.py v1.3. Display only. Section 17 adds the cases (8 planted bugs each caught). Rows marked 'setups add-on v1.3'.

11 Nov 2026 (evening): setups add-on v1.4 - SDE (signed directional efficiency, 3 / 5 / 10 / 20 sessions) at every pick: pick attributes for filters, an SDE section and SDE10 breakdown in every backtest, the simulator's SDE line; the tree entry's open_if (strategies/tree_sde.py, the sketch's empty branch, declared before any run); decision rules on the money view (daily_diff_bp, cagr_and_drawdown); comparisons get the tree / setups they trade. Section 19 (6 checks; 10 planted bugs each caught). Rows marked 'setups add-on v1.4'.

| file | version | sha256 (first 16) | role |
|---|---|---|---|
| env_tradelab.bat | setups add-on v1.0 | 6beae2e89d6e1f27 | start a session: env_daily.bat, PYTHONPATH (tradelab, open_close, bigmove_deploy), TRADELAB_OUT (CRLF); SETUPLAB_DIR / SETUPLAB_OUT (setuplab's folder and outputs) |
| plugins/example_plugin.py | tradelab v1 | 52b7f8a1462d4a50 | example plugin: vol_surge, range_pos20, above_for() |
| README_TRADELAB.md | setups add-on v1.4 | 6544f928cafcbbe9 | how to install, run, read the watch page, the market layer and the stock states, write strategies; changelog; the setups add-on sections (8 Nov setups; 9 Nov the entry tree; 11 Nov one line per stock; 11 Nov SDE and the tree's branch) |
| run_tonight.bat | setups add-on v1.0 | 006fedb8dc82864a | v1.3.1: EVERY NIGHT, one double-click - Run Now (unchanged, child cmd), pick_meta publish --all-missing + score, tl_watch --all-missing; every step reported; 'auto' for Task Scheduler (CRLF); step 3 of 4 (new): setuplab scan --all-missing; tl_watch is step 4; log line adds setup_scan= |
| run_watch.bat | tradelab v1.3.1 | db63eec3f428871c | the watch page alone, by hand (arguments pass through, e.g. --date ... --force); opens the newest day's page (CRLF) |
| STATE_RULES.md | tradelab v1.3.1 | 2d0a68f0b1c5144e | v1.3: every stock state's rules, the precedence, confidence, phase, events, risk flags and settings (written by tl_state.py rules) |
| strategies/dip_or_fallback.py | tradelab v1 | fce97d839c256931 | example strategy |
| strategies/filtered_rsi_entry.py | tradelab v1 | af30c8ad09315f78 | example strategy |
| strategies/half_target_stop.py | tradelab v1 | 8f5ebeb98f88cf03 | example strategy |
| strategies/hypo_skip_smallcap_fall.py | tradelab v1.1 | e0f3691f06adfaed | example HYPOTHESIS (not a rule): the plan skipping W6 picks; run with --split-date |
| strategies/open6.py | tradelab v1 | 86a67db320a11d6f | example strategy |
| strategies/orb_add_on.py | tradelab v1 | e7ac4b38b71d56da | example strategy |
| strategies/plan.py | tradelab v1 | 98481fc8789d03e3 | example strategy |
| strategies/plan_intraday.py | tradelab v1 | fca2e77d51d4af68 | example strategy |
| strategies/scale_20_80_vwap.py | tradelab v1 | 629d2b225be2814a | example strategy |
| strategies/setup_s2_d5.py | setups add-on v1.0 | 51bc764168bf4bc0 | example: frozen setup S2 as a strategy (D and ENS ranks 1-10, buy S2's own entry-day open, sell the 5th close) |
| strategies/tree.py | setups add-on v1.2 | b9d3159e5d8de78f | the entry tree as a strategy (setuplab TREE.json): buy where the tree bought, sell where it sold; D ranks 1-3 from 2021, Rs 5 L, 3 positions; --engines ENS for ENS |
| strategies/tree_sde.py | setups add-on v1.4 | e525401c510ae3c7 | the tree's empty branch, declared 11 Nov: the frozen tree + jumpy tree picks with SDE10 below -0.5 bought at the D1 open (5th close); compared with strategies/tree.py; decision rule daily_diff_bp lower > 0 + cagr_and_drawdown |
| strategies/trail_after_5pct.py | tradelab v1 | cc08706cd7df6fd6 | example strategy |
| strategies/weak_close_exit.py | tradelab v1 | 64f072d7314c6535 | example strategy |
| tests/test_context.py | setups add-on v1.1 | 9f17bb2808f64bf3 | sections 10-13: the market layer by hand, point in time, research, integration; v1.1: the simulator check takes a pick with 3-minute bars and reports a failure instead of crashing |
| tests/test_setups.py | setups add-on v1.4 | cb40ce928db119b1 | sections 17-19: setups (watch cards v1.3), the entry tree (v1.2), SDE and the tree's open_if (v1.4: SDE by hand, the branch against the frozen tree, money decision rules, guards) |
| tests/test_state.py | setups add-on v1.1.2 | e585e92caeb8914c | sections 14-16: stock states (planted / absent, rules, point in time), the watch page / export / research integration, v1.3.1 catch-up, run_tonight.bat (executed on Windows), states in backtest / sim; the 4-step run_tonight.bat incl. the setup scan (executed on Windows; a failing scan); v1.1.2: watch_all.csv look-alike file, stand-in Run Now ends with exit /b, diagnostics |
| tests/test_tradelab.py | setups add-on v1.4 | d0cf8ca9e0fbf11b | the test suite, sections 1-19 (must end VERIFIED (tradelab v1.3.1 + setups add-on v1.4)); v1.1.1: production folders off the test's path, tl_check reloaded, a final no-production check |
| tests/tl_ctx_world.py | tradelab v1.1 | 887f935958821722 | synthetic worlds with planted size / index structure and AMFI lists (CSV / Excel / PDF) |
| tests/tl_state_world.py | tradelab v1.3 | 43af9c384800a6f1 | price paths with planted stock states (S01..S12, S04 / S11 / S10 events, S05) |
| tests/tl_world.py | tradelab v1 | d70cd0564be62ba0 | synthetic worlds + stand-in production modules for the tests |
| tl_backtest.py | setups add-on v1.4 | 8c2c9fd16774cb9f | COMMAND: a strategy vs the plan (or --compare) on the same picks, paired 95% intervals, money view, environment and stock-state breakdowns, ledger; setups and tree; v1.4: SDE on every run (section, SDE10 breakdown), daily_diff_bp / cagr_and_drawdown decision rules, comparisons get the tree / setups they trade |
| tl_cards.py | tradelab v1.3 | d71662e5573d0be5 | COMMAND: trade cards (known before entry / forecasts / day by day / verdict) and the market diary |
| tl_check.py | setups add-on v1.0 | 3d0f6d2234f732dc | COMMAND: 30-second preflight on real data (reads only), incl. index files, breadth count, AMFI lists; the tonight block shows the setup scan step and whether setuplab's freeze file is found |
| tl_common.py | tradelab v1.3.1 | ad7e75715da7556a | versions, path guards (never writes into the cache or production), hashing, tables, ledger, block bootstrap |
| tl_context.py | tradelab v1.2.1 | c3e65f0fa44e2467 | COMMAND + library: the market layer - indices, divergence, breadth, VIX, AMFI size, beta / correlation, declared environment labels, pre_/post_ context |
| tl_data.py | tradelab v1.1 | 46ceff88fdadda7f | read-only production access: picks (pick_meta run, hash-checked), daily bars + lock rule (stage E), calendar, 3-minute sessions, panel features (label firewall) |
| tl_dictionary.py | setups add-on v1.4 | e7d6e8e2738e113f | the data dictionary: every column's meaning, unit and when it is known; setup and tree columns; v1.4: pre_sde3/5/10/20 |
| tl_engine.py | engine v1.3 (setups add-on v1.4) | 3f9215ed99eaa91d | strategies and the bar-by-bar trade engine (fills, intrabar policy, honest exits, path, timeline); setup entries, hold exits, the tree entry / exit; v1.4: the tree entry's open_if (a pick rule: buy at the D1 open, sell at the 5th close) |
| tl_export.py | tradelab v1.3 | f5a8bad758c5f30c | COMMAND: every pick with outcomes, day by day, the market around it, research, cards, dictionary; reconcile safety stop |
| tl_journal.py | tl_journal v1.2 (setups add-on v1.2) | f1955f452d2aecac | COMMAND: one readable Excel file for an export, TRADE_JOURNAL.xlsx in the export folder - Trades (newest first, in bands), Market days, What worked, Read me; reads the export read-only; --selftest; v1.1: the FROZEN SETUPS band; v1.2: the CALM / JUMPY AND THE ENTRY TREE band (lane, ATR, cut-off, opened up, the tree's action, where it bought, its net); --setups |
| tl_portfolio.py | tradelab v1.2 | b15f0570f3aca067 | the money layer: sizing rules, capital, cash, integer shares, limits, equity, drawdown (v1.1: unfunded trades are skipped, not open) |
| tl_research.py | tradelab v1.3 | d06e2b3809d13f58 | COMMAND + library: winners / losers / severe losers, warning signs W1-W8, purged walk-forward with Bonferroni, money-view returns and drawdowns (research-declaration-2) |
| tl_rules.py | tradelab v1.1 | 0ff123752954d1f6 | the rule language: safe expression compiler, values, functions, events, plugins; post_* refused |
| tl_run.py | tradelab v1.3.1 (setups add-on v1.4) | 297677ca1f70b4c2 | one run's data and simulation, symbol by symbol; v1.2: 'calm' a pick attribute with the tree; v1.4: pre_sde3/5/10/20 pick attributes |
| tl_setups.py | tl_setups v1.4 (setups add-on v1.4) | 5794378dadd14ddb | the add-on's reader: setuplab's tag run (hash-checked), the nightly scan; tag columns; refuses rules naming a tag; v1.2 the entry tree; v1.3 one line per stock for the watch page; v1.4: SDE at every pick (pre_sde3/5/10/20, split guard), SDE10 buckets, the tree's per-pick plan with tagged / ETF |
| tl_sim.py | setups add-on v1.4 | 35662c9d324d0b17 | COMMAND: replay trades bar by bar: story, timeline, chart; setups, tree lines; v1.4: the story's SDE line, strategies parsed on the replayed picks (SDE filters, open_if) |
| tl_state.py | tradelab v1.3.1 | 36cfecb1f9c0c35a | COMMAND + library: the stock-state engine (primary state, events, risk flags, volatility, confidence, transitions; point in time); v1.1: what ends a state worded as the rules apply it |
| tl_watch.py | tl_watch v1.3 (setups add-on v1.3) | b44d71ee2d6568e8 | COMMAND: tonight's watch page (market banner, D and ENS tables, a card per stock); the setups section as cards: one per stock to buy at the next open with the entry tree's orders, one per purchase held, the tree books' positions; the scan's rows folded away |

Read-only production dependencies (on your PC, unchanged): bigmove_deploy\open_close\stage_e_execution.py (v1.2, 158883f0af70728d - checked at start; --stage-e-any to accept another), EXECUTION_DECLARATION.json, intraday_cache.py (+ its declaration), research_common.py; bigmove_deploy\data_quality.py, panel_build.py (optional); %CACHE_DAILY_ROOT% (daily bars incl. NIFTY50 / NIFTYMIDCAP150 / NIFTYSMLCAP250 / INDIAVIX, intraday_3m, panel_oc, research2\pick_meta\PM_20261017_001, sectors\amfi\ for AMFI's lists; v1.3 watch page: paper\ledger.jsonl, paper\watchlists\WL_YYYYMMDD.md, research2\pick_meta\forward\PM_cards_YYYYMMDD.csv, optional sectors\sector_map.csv).

Python packages beyond production's: pypdf, openpyxl (AMFI lists); pdfplumber, reportlab (the tests).
