"""THE TREE'S EMPTY BRANCH, filled with SDE (setups add-on v1.4) - declared 11 Nov 2026 before any run.

Karan's sketch: Model(3) -> D / ENS -> CALM / JUMPY -> JUMPY -> SETUP / NOT PICKED BY SETUP -> [ ? ].
"Not picked by a setup" is known only at D5, so it cannot trigger a buy. The branch decides at the D1 OPEN from what is
known at the pick's close:

    a JUMPY tree pick whose SDE10 at the pick is below -0.5 (an orderly 10-session fall)  -> buy at the D1 open,
                                                                                           sell at the 5th close
    every other pick                                                                       -> the frozen tree, unchanged

SDE10 = (close - close 10 sessions before) / the sum of the 10 absolute close-to-close moves. The -0.5 threshold is the
SDE handover's NEG bucket (11 Nov 2026), not tuned here. ETFs are never bought. Same account as strategies/tree.py:
Rs 5 L, 3 positions, 35 bp, honest exits (a close locked at the lower circuit sells at the first open that is not).

Compared with the FROZEN TREE (not the plan):
    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\tree_sde.py --compare strategies\\tree.py --declare "SDE branch vs frozen tree, D, 2021-2026, declared 11 Nov"
    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\tree_sde.py --compare strategies\\tree.py --engines ENS --declare "SDE branch vs frozen tree, ENS, 2021-2026, declared 11 Nov"

Decision rule (declared before any run; one per engine): PASS = the money view's daily-return difference against the
frozen tree has a 95% interval above 0 AND the CAGR is higher AND the worst drawdown is no deeper. These years are the
history the tree and the SDE research were found on, so a PASS only makes the branch a forward candidate (a new tree
with its own freeze date); the frozen tree keeps running unchanged either way.
"""
STRATEGY = {
    "name": "tree_sde",
    "description": "the frozen tree + jumpy picks with SDE10 below -0.5 bought at the D1 open (5th close), 35 bp",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": "2021-01-01"},
    "max_sessions": 9,
    "entries": [{"name": "tree", "size": 1.0, "tree": True, "open_if": "calm == 0 and pre_sde10 < -0.5"}],
    "exits": [{"name": "tree", "type": "time", "tree": True}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "sizing": {"rule": "equal_slots", "slots": 3, "max_pct": 0.34},
    "portfolio": {"capital": 500000, "max_open": 3},
    "decision_rule": {"metric": "daily_diff_bp", "pass_if": "lower > 0", "money": "cagr_and_drawdown"},
}
