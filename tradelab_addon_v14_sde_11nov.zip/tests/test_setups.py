"""
tests/test_setups.py - the setups add-on (tl_setups v1.0) for tradelab v1.3.1, checked (section 17 of the suite).

Run it through tests/test_tradelab.py. Synthetic worlds only (tests/tl_world.py, tests/tl_ctx_world.py and the watch
world of tests/test_state.py) with a fake setuplab output (tags + a nightly scan) planted by hand:
  17 setups  the tags are read only when their hash matches; a strategy enters at a setup's OWN entry day and nowhere
             else (entry price = that day's open, the D5-close exit and a 'hold' exit by hand); the same-trade line of
             the report; every guard (a filter or rule naming a tag, a setup leg without tags, an unknown setup, a
             hold that cannot fit, a setup leg with a session); tag columns on a plain backtest, documented; the
             simulator's story line; the watch page's setups column and section from the scan (and without one);
             the trade journal's FROZEN SETUPS band; v1.3: the watch page's one line per stock (one card per
             purchase however many setup x pick rows name it; the entry tree's orders, lanes and books)
  18 tree    (setups add-on v1.2) setuplab's entry-tree run read only when its hash matches; the tree strategy buys
             where the tree bought (the D1 open, or the first setup's own open) and sells where it sold (the 5th close;
             N1 4 sessions after its entry, up to session 9) - prices by hand; skipped picks not entered; 'calm' as a
             filter (and refused without the tree); every guard (tree_* / opened_up in a rule, a tree entry without
             its exit or with a session or beside another entry, max_sessions < 9, no tree run, a tree that disagrees
             with the tags); lane / tree columns documented; the report's lane table by hand; the simulator's line;
             the journal's CALM / JUMPY AND THE ENTRY TREE band; without a tree run nothing changes
  19 sde     (setups add-on v1.4) SDE by hand (orderly fall = -1, choppy, flat / missing / split windows blank) and at
             real picks against the world's closes; pre_sde* filters; the tree's open_if buys exactly the jumpy
             non-ETF picks the rule names at the D1 open (5th close) and leaves every other pick as the frozen tree
             (difference 0 against --compare strategies/tree.py); a comparison that trades the tree gets the tree;
             the daily_diff_bp + cagr_and_drawdown decision rule by hand; the SDE section and table by hand; the
             simulator's SDE line; the guards (open_if off the tree, on a tree column, on a bar value)
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import tl_world as W  # noqa: E402
import tl_ctx_world as CW  # noqa: E402

IST = "Asia/Kolkata"


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def fake_tags(base: Path, picks: pd.DataFrame, plan: dict) -> Path:
    """setuplab tag's output for the planted entries: plan = {trade_id: {setup id: watch day}}."""
    run = base / "TAGS" / "TAGS_20261108_001"
    run.mkdir(parents=True, exist_ok=True)
    ids = ["S2", "C1", "N1"]
    rows = []
    for t in picks["trade_id"].astype(str):
        r = {"trade_id": t}
        d = plan.get(t, {})
        for sid in ids:
            r[f"su_{sid}_day"] = float(d[sid]) if sid in d else np.nan
            r[f"su_{sid}_net_d5"] = 1.0 + 0.1 * d[sid] if sid in d else np.nan
            r[f"su_{sid}_net_fresh"] = 2.0 + 0.1 * d[sid] if sid in d else np.nan
        r["setups"] = " ".join(f"{s}@D{d[s]}" for s in ids if s in d)
        r["n_setups"] = len(d)
        rows.append(r)
    T = pd.DataFrame(rows)
    T.to_parquet(run / "setup_tags.parquet", index=False)
    meta = {"version": "setuplab v0.7", "frozen_sha256": "f" * 64, "signal_days": ["2023-01-02", "2023-08-01"],
            "setups": [{"id": "S2", "name": "Bad week + minus-DI 5-day change rising + gap down",
                        "primary_exit": "original_d5"},
                       {"id": "C1", "name": "Bad week + minus-DI rising + 2% dip", "primary_exit": "original_d5"},
                       {"id": "N1", "name": "Below the lower Bollinger band + 2% dip", "primary_exit": "fresh"}]}
    (run / "TAGS.json").write_text(json.dumps(meta), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'setup_tags.parquet')}  setup_tags.parquet\n", encoding="utf-8")
    return run


def run_all(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        """the suite's check(cond, msg); a failing check also names what it saw"""
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("17. setups add-on: frozen setups (setuplab) in the backtester, simulator, watch page and journal")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "su_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    from tl_common import TLError
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    cand = P[(P["engine"] == "D") & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)].sort_values(["sig", "rank"])
    cand = cand.iloc[::9].head(24)
    plan = {}
    for i, t in enumerate(cand["trade_id"]):
        d = {"S2": 1 + i % 5}
        if i % 3 == 0:
            d["C1"] = 1 + (i + 2) % 5
        if i % 4 == 1:
            d["N1"] = 2
        plan[t] = d
    base = TMP / "su_out"
    run = fake_tags(base, P, plan)
    # ---- the tags: read only with their hash
    T0, i0 = SU.load_tags(None)
    try:
        SU.load_tags(None, need=True)
        need_ok = False
    except TLError as e:
        need_ok = "--setups" in str(e)
    tags, info = SU.load_tags(base)
    good = (run / "setup_tags.parquet").read_bytes()
    pd.read_parquet(run / "setup_tags.parquet").assign(n_setups=9).to_parquet(run / "setup_tags.parquet", index=False)
    try:
        SU.load_tags(base)
        tamper = False
    except TLError as e:
        tamper = "does not match" in str(e)
    (run / "setup_tags.parquet").write_bytes(good)
    check(T0 is None and not i0["used"] and need_ok and tags is not None and info["setups"] == ["S2", "C1", "N1"] and
          info["primary_exit"]["N1"] == "fresh" and tamper,
          "tags: none without --setups / SETUPLAB_OUT (and a clear refusal when a strategy needs them); the newest "
          "TAGS run is read only when its outputs.sha256 matches - a changed table is refused")
    # ---- a strategy that enters at S2's own entry day, sold at the D5 close; and with a 'hold' exit
    import tl_backtest as BT
    sdir = TMP / "su_strats"
    sdir.mkdir(exist_ok=True)
    s_d5 = sdir / "s2_d5.py"
    s_d5.write_text('STRATEGY = {"name": "s2_d5", "mode": "daily", "max_sessions": 5, "picks": {"engines": ["D"], '
                    '"ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}, "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}], '
                    '"exits": [{"name": "d5", "type": "time", "at": "close", "session": 5}]}\n', encoding="utf-8")
    s_fr = sdir / "s2_fresh.py"
    s_fr.write_text('STRATEGY = {"name": "s2_fresh", "mode": "daily", "max_sessions": 9, "picks": {"engines": ["D"], '
                    '"ranks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}, "entries": [{"name": "s2", "size": 1.0, "setup": "S2"}], '
                    '"exits": [{"name": "fresh", "type": "time", "hold": 5}]}\n', encoding="utf-8")
    out = TMP / "su_bt"
    daily = {s: pd.read_parquet(root / f"{s}_daily.parquet") for s in w["names"]}
    res = {}
    for nm, sp in (("d5", s_d5), ("fresh", s_fr)):
        rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                                  "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)])
        bt = sorted((out / "backtest").glob("TLB_*"))[-1]
        res[nm] = (rc, log, pd.read_parquet(bt / "trades.parquet"), json.loads((bt / "summary.json").read_text()),
                   (bt / "report.md").read_text(encoding="utf-8"), bt)
    ok_ent, bad = True, []
    for nm, hold in (("d5", None), ("fresh", 5)):
        rc, log, A, sm, rep, bt = res[nm]
        A = A.set_index("trade_id")
        for t, d in plan.items():
            k = d["S2"]
            r = A.loc[t]
            sym = cand.set_index("trade_id").at[t, "symbol"]
            sig = int(cand.set_index("trade_id").at[t, "sig"])
            o = float(daily[sym]["open"].iloc[sig + k])
            xs = 5 if hold is None else k + hold - 1
            c = float(daily[sym]["close"].iloc[sig + xs])
            want = (c / o - 1 - 0.0035) * 1e4
            good_row = (r["status"] == "ok" and int(r["entry_session"]) == k and abs(r["first_entry"] - o) < 1e-9
                        and int(r["exit_session"]) == xs and abs(r["net_bp"] - want) < 1e-6
                        and r["setups"] == plan_txt(d))
            if not good_row:
                bad.append((nm, t, r["status"], r["entry_session"], k, r["exit_session"], xs))
            ok_ent &= good_row
        others = A.drop(index=list(plan))
        ok_ent &= bool((others["status"].isin(["not_entered", "pending"])).all() and
                       (others.loc[others["status"] == "not_entered", "net_bp"] == 0).all() and
                       (others["status"] == "not_entered").mean() > 0.9)
        ok_ent &= rc == 0
    rc, log, A, sm, rep, bt = res["d5"]
    traded = A[A["entered"].astype(bool)]
    same = abs(sm["paired"]["diff_on_traded"][0] - traded["diff_bp"].mean()) < 1e-6
    check(ok_ent and same and "## Frozen setups (setuplab tags)" in rep and "ENTERS at setups ['S2']" in rep and
          sm["setups"]["run"] == run.name and sm["strategy"]["setup_entries"] == ["S2"],
          f"setup entries: each of the {len(plan)} planted S2 picks bought at the open of ITS entry day (D1-D5) and "
          f"nowhere else; sold at the D5 close, or with 'hold': 5 at the close 4 sessions after the entry (net = "
          f"exit / that open - 1 - 35 bp, by hand); every other pick not entered (0 bp); 'on the picks the strategy "
          f"traded' = the setup's own trades vs the plan on the same picks", bad[:4])
    # ---- the guards
    def bt_rc(text, extra=()):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none"] + list(extra))
    g1 = bt_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"], "filter": "su_S2_day > 0"}}\n', ["--setups", str(base)])
    g2 = bt_rc('STRATEGY = {"name": "g2", "picks": {"engines": ["D"]}, "entries": [{"name": "b", "size": 1.0, '
               '"when": "close < open and n_setups > 0", "sessions": [1, 4]}]}\n', ["--setups", str(base)])
    g3 = bt_rc(s_d5.read_text(encoding="utf-8"))
    g4 = bt_rc(s_d5.read_text(encoding="utf-8").replace('"S2"', '"S9"'), ["--setups", str(base)])
    g5 = bt_rc(s_fr.read_text(encoding="utf-8").replace('"max_sessions": 9', '"max_sessions": 8'), ["--setups", str(base)])
    g6 = bt_rc(s_d5.read_text(encoding="utf-8").replace('"setup": "S2"', '"setup": "S2", "session": 2'),
               ["--setups", str(base)])
    check(g1[0] == 2 and "is a setup tag" in g1[1] and g2[0] == 2 and "'n_setups' is a setup tag" in g2[1] and
          g3[0] == 2 and "needs the frozen setups' tags" in g3[1] and g4[0] == 2 and "not frozen setups" in g4[1] and
          g5[0] == 2 and "max_sessions >= 9" in g5[1] and g6[0] == 2 and "takes no 'session'" in g6[1],
          "guards: a filter or an entry rule naming a setup tag is refused (look-ahead), with the way out; a setup "
          "leg without tags, an unknown setup, a 5-session hold that cannot fit after a D5 entry, and a setup leg "
          "with its own session are refused",
          [x[1][-160:] for x in (g1, g2, g3, g4, g5, g6) if x[0] != 2])
    # ---- tag columns on a plain backtest (hindsight), every column documented
    rc, log = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                              "--strategy", str(LAB / "strategies" / "plan.py"), "--no-portfolio", "--context", "none",
                              "--setups", str(base)])
    bt = sorted((out / "backtest").glob("TLB_*"))[-1]
    A = pd.read_parquet(bt / "trades.parquet").set_index("trade_id")
    dd = pd.read_csv(bt / "data_dictionary.csv")
    rep = (bt / "report.md").read_text(encoding="utf-8")
    tag_ok = all(A.at[t, "setups"] == plan_txt(d) and int(A.at[t, "su_S2_day"]) == d["S2"] for t, d in plan.items()
                 if t in A.index)
    check(rc == 0 and tag_ok and {"setups", "n_setups", "su_S2_day", "su_C1_day", "su_N1_day", "setups_tagged"} <=
          set(A.columns) and bool(A["setups_tagged"].all()) and not (dd["meaning"] == "UNDOCUMENTED").any() and
          "hindsight" in rep,
          "the plan's own backtest carries the tags (setups 'S2@D3 C1@D5', su_<ID>_day) as hindsight columns, "
          "documented in the data dictionary; the report says they describe trades, never choose them")
    # ---- the simulator's story
    import tl_sim as SIM
    t1 = next(iter(plan))
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t1, "--strategy", str(s_d5), "--context", "none", "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t1}__s2_d5_story.md").read_text(encoding="utf-8")
    ssum = json.loads((sim / "summary.json").read_text())
    rs = ssum["results"]["s2_d5"][0]
    check(rc == 0 and "Frozen setups on this pick" in story and f"S2 on D{plan[t1]['S2']}" in story and
          int(rs["entry_session"]) == plan[t1]["S2"],
          "the simulator: the story names the pick's frozen setups (hindsight before their day) and a setup "
          "strategy enters on S2's own day")
    # ---- the watch page: the setups column and section from the scan
    import test_state as TST
    winfo = CW.make_ctx_world(TMP / "su_watch_world", "absent", 7, n_days=420)
    wroot = winfo["root"]
    fresh_modules(wroot)
    import tl_watch as WT
    day_idx = 400
    planted = TST._write_planted(wroot, winfo["days"], day_idx)
    day = TST._paper(wroot, winfo, day_idx, planted)
    L = [json.loads(x) for x in (wroot / "paper" / "ledger.jsonl").read_text().splitlines() if x.startswith("{")]
    tonight = [x for x in L if x["date"] == f"{day:%Y-%m-%d}" and x["engine"] == "D"]
    older = [x for x in L if x["date"] < f"{day:%Y-%m-%d}"]
    r1, r2, r3 = tonight[0], tonight[1], older[0]
    scan = pd.DataFrame([
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "C3", "status": "FIRES", "trade_id": "x1", "engine": "D",
         "rank": r1["rank"], "symbol": r1["symbol"], "signal_day": r1["date"], "next_watch_day": 1, "rule_at_open": "",
         "entered_day": "", "entry": np.nan, "zone": "IN"},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "S2", "status": "ARMED", "trade_id": "x2", "engine": "D",
         "rank": r2["rank"], "symbol": r2["symbol"], "signal_day": r2["date"], "next_watch_day": 1,
         "rule_at_open": "open below 123.45", "entered_day": "", "entry": np.nan, "zone": "OUT"},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "C1", "status": "ENTERED", "trade_id": "x3", "engine": r3["engine"],
         "rank": r3["rank"], "symbol": r3["symbol"], "signal_day": r3["date"], "next_watch_day": 4, "rule_at_open": "",
         "entered_day": 3, "entry": 99.5},
        {"scan_date": f"{day:%Y-%m-%d}", "setup": "S1", "status": "WATCHING", "trade_id": "x4", "engine": "D",
         "rank": r1["rank"], "symbol": r1["symbol"], "signal_day": r1["date"], "next_watch_day": 1, "rule_at_open": "",
         "entered_day": "", "entry": np.nan}])
    sdir2 = base / "scan"
    sdir2.mkdir(parents=True, exist_ok=True)
    scan.to_csv(sdir2 / f"scan_{day:%Y%m%d}.csv", index=False)
    (sdir2 / "setup_ledger.jsonl").write_text(json.dumps({"event": "scan", "scan_date": f"{day:%Y-%m-%d}",
                                                          "on_time": True, "recorded_at": "x"}) + "\n", encoding="utf-8")
    wout = TMP / "su_watch_out"
    rc, log = quiet(WT.main, ["--root", str(wroot), "--out", str(wout), "--stage-e-any", "--setups", str(base)])
    R = pd.read_csv(wout / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    md = (wout / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    H = (wout / "watch" / f"WATCH_{day:%Y%m%d}.html").read_text(encoding="utf-8")
    g = R.set_index(["engine", "rank"])["setups"].fillna("")
    rc2, log2 = quiet(WT.main, ["--root", str(wroot), "--out", str(TMP / "su_watch_out2"), "--stage-e-any"])
    md2 = (TMP / "su_watch_out2" / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    R2 = pd.read_csv(TMP / "su_watch_out2" / "watch" / f"WATCH_{day:%Y%m%d}.csv")
    sec = md.split("## Frozen setups and the entry tree at the next open")[1].split("## Stock cards")[0] \
        if "## Frozen setups and the entry tree at the next open" in md else ""
    check(rc == 0 and g[("D", r1["rank"])] == "BUY at the open: C3 in zone" and
          g[("D", r2["rank"])] == "S2 outside zone only if open below 123.45" and
          "recorded ON TIME" in sec and "C1 entered D3 at 99.50" in sec and f"**{r3['symbol']}** bought" in sec and
          "S1" not in sec and "Frozen setups and the entry tree at the next open" in H and "class='scard'" in H and
          rc2 == 0 and "Setup scan: no --setups and no SETUPLAB_OUT" in md2 and R2["setups"].fillna("").eq("").all(),
          "the watch page: tonight's picks show what fires / is armed at the next open (v1.3: 'BUY at the open: C3 in "
          "zone'), a section with one card per stock (FIRES / ARMED / ENTERED of the last five sessions, never "
          "WATCHING; the scan's own rows folded away) that says the scan was on time; without a scan the column is "
          "blank and the page says so")
    # ---- v1.3: one line per stock - the RRKABEL case (one purchase named by 7 setup x pick rows) and the tree
    sa, sb, sc_ = "RRKABEL", "SUYOG", "AIAENG"
    d_a, d_b = "2026-01-05", "2026-01-08"
    dup = [{"scan_date": f"{day:%Y-%m-%d}", "setup": sid, "status": "ENTERED", "trade_id": f"D-a-4", "engine": "D",
            "rank": 4, "symbol": sa, "signal_day": d_a, "next_watch_day": 5, "rule_at_open": "", "entered_day": 3,
            "entry_date": "2026-01-08", "entry": 1970.0, "mark_pct": -2.59, "primary_exit": "original_d5", "zone": ""}
           for sid in ("C1", "C2", "C3", "S1", "S3")]
    dup += [{"scan_date": f"{day:%Y-%m-%d}", "setup": "C3", "status": "ENTERED", "trade_id": f"{e}-b-{k}", "engine": e,
             "rank": k, "symbol": sa, "signal_day": d_b, "next_watch_day": 2, "rule_at_open": "", "entered_day": 1,
             "entry_date": "2026-01-08", "entry": 1970.0, "mark_pct": -2.59, "primary_exit": "original_d5", "zone": ""}
            for e, k in (("ENS", 1), ("D", 2))]
    dup += [{"scan_date": f"{day:%Y-%m-%d}", "setup": "N1", "status": "ENTERED", "trade_id": "D-c-6", "engine": "D",
             "rank": 6, "symbol": sb, "signal_day": d_b, "next_watch_day": 3, "rule_at_open": "", "entered_day": 2,
             "entry_date": "2026-01-09", "entry": 55.5, "mark_pct": 1.25, "primary_exit": "fresh", "zone": ""},
            {"scan_date": f"{day:%Y-%m-%d}", "setup": "N1", "status": "FIRES", "trade_id": "D-d-1", "engine": "D",
             "rank": 1, "symbol": sc_, "signal_day": d_b, "next_watch_day": 3, "rule_at_open": "", "entered_day": "",
             "entry_date": "", "entry": np.nan, "mark_pct": np.nan, "primary_exit": "fresh", "zone": "IN",
             "close_tonight": 101.0},
            {"scan_date": f"{day:%Y-%m-%d}", "setup": "S2", "status": "ARMED", "trade_id": "ENS-d-3", "engine": "ENS",
             "rank": 3, "symbol": sc_, "signal_day": d_a, "next_watch_day": 5, "rule_at_open": "open below 99.00",
             "entered_day": "", "entry_date": "", "entry": np.nan, "mark_pct": np.nan, "primary_exit": "original_d5",
             "zone": "", "close_tonight": 101.0}]
    base3 = TMP / "su_watch_dup"
    (base3 / "scan").mkdir(parents=True, exist_ok=True)
    pd.DataFrame(dup).to_csv(base3 / "scan" / f"scan_{day:%Y%m%d}.csv", index=False)
    (base3 / "scan" / "setup_ledger.jsonl").write_text(json.dumps({"event": "scan", "scan_date": f"{day:%Y-%m-%d}",
                                                                   "on_time": True, "recorded_at": "x"}) + "\n",
                                                       encoding="utf-8")
    trec = {"event": "tree", "scan_date": f"{day:%Y-%m-%d}", "on_time": True,
            "picks": [{"trade_id": "D-t-1", "engine": "D", "rank": 1, "symbol": "CALMONE", "lane": "CALM", "close": 250.0},
                      {"trade_id": "D-t-2", "engine": "D", "rank": 2, "symbol": "CALMTWO", "lane": "CALM", "close": 80.0},
                      {"trade_id": "ENS-t-1", "engine": "ENS", "rank": 1, "symbol": "CALMONE", "lane": "CALM",
                       "close": 250.0},
                      {"trade_id": "D-d-1", "engine": "D", "rank": 1, "symbol": sc_, "lane": "JUMPY", "close": 101.0}],
            "orders": {"D_calm_in_rank_order": ["D-t-1", "D-t-2"], "ENS_calm_at_open": ["ENS-t-1"],
                       "setup_buys": [{"trade_id": "D-d-1", "engine": "D", "setup": "N1", "status": "FIRES",
                                       "rule_at_open": "", "unless_calm_buy": False}]}}
    old_rec = dict(trec, scan_date=f"{day - pd.Timedelta(days=3):%Y-%m-%d}", picks=[{"trade_id": "D-a-4", "lane": "JUMPY"}])
    (base3 / "scan" / "tree_ledger.jsonl").write_text(json.dumps(old_rec) + "\n" + json.dumps(trec) + "\n",
                                                      encoding="utf-8")
    pd.DataFrame([{"book": "D tree", "trade_id": "D-a-4", "engine": "D", "rank": 4, "symbol": sa, "how": "C1@D3",
                   "entry_date": "2026-01-08", "entry": 1970.0, "exit_date": "2026-01-12", "status": "held",
                   "net": np.nan, "now_pct": -2.59},
                  {"book": "ENS tree", "trade_id": "ENS-b-1", "engine": "ENS", "rank": 1, "symbol": sa, "how": "open",
                   "entry_date": "2026-01-08", "entry": 1970.0, "exit_date": "2026-01-14", "status": "held",
                   "net": np.nan, "now_pct": -2.59},
                  {"book": "D baseline", "trade_id": "D-z-1", "engine": "D", "rank": 1, "symbol": "BASEONLY",
                   "how": "open", "entry_date": "2026-01-08", "entry": 10.0, "exit_date": "2026-01-14",
                   "status": "held", "net": np.nan, "now_pct": 0.5}]).to_csv(base3 / "scan" / "tree_book.csv", index=False)
    import tl_setups as SU3
    Sd = pd.read_csv(base3 / "scan" / f"scan_{day:%Y%m%d}.csv", dtype={"trade_id": str})
    tr3 = SU3.read_tree_night(base3, day)
    hg, ng, tg = SU3.held_groups(Sd), SU3.next_open_groups(Sd, tr3), SU3.tree_books_held(tr3)
    ha = [x for x in hg if x["symbol"] == sa]
    hb = [x for x in hg if x["symbol"] == sb]
    nxs = {x["symbol"]: x for x in ng}
    sells_a = " | ".join(ha[0]["sells"]) if ha else ""
    f_ok = (len(hg) == 2 and len(ha) == 1 and ha[0]["n_rows"] == 7 and len(ha[0]["setups"]) == 3 and
            any("C1 C2 C3 S1 S3" in t for t in ha[0]["setups"]) and ha[0]["sells"] == [
                "tomorrow's close: C1 C2 C3 S1 S3 (D #4, 5 Jan pick)",
                "the close in 4 sessions: C3 (ENS #1, 8 Jan pick); C3 (D #2, 8 Jan pick)"] and
            len(hb) == 1 and hb[0]["sells"] == ["the close in 4 sessions: N1 (D #6, 8 Jan pick)"] and
            set(nxs) == {sc_, "CALMONE", "CALMTWO"} and nxs[sc_]["do"] == "BUY at the open" and
            len(nxs[sc_]["setups"]) == 2 and nxs[sc_]["lane"] == "JUMPY" and
            nxs[sc_]["tree"] == ["D tree: buy through N1"] and
            any("D tree: buy at the open if it opens at or above 250.00" in t and "#1 of 2" in t
                for t in nxs["CALMONE"]["tree"]) and "ENS tree: BUY at the open (calm)" in nxs["CALMONE"]["tree"] and
            nxs["CALMONE"]["do"] == "" and [x["symbol"] for x in tg] == [sa] and len(tg[0]["books"]) == 2 and
            tr3["lanes"].get("D-a-4") == "JUMPY")
    wout3 = TMP / "su_watch_out3"
    rc3, log3 = quiet(WT.main, ["--root", str(wroot), "--out", str(wout3), "--stage-e-any", "--setups", str(base3)])
    H3 = (wout3 / "watch" / f"WATCH_{day:%Y%m%d}.html").read_text(encoding="utf-8")
    md3 = (wout3 / "watch" / f"WATCH_{day:%Y%m%d}.md").read_text(encoding="utf-8")
    held_html = H3.split("Frozen setups held")[1].split("Entry tree books held")[0] if "Frozen setups held" in H3 else ""
    # a later scan makes tonight's tree book stale: not shown
    (base3 / "scan" / "tree_ledger.jsonl").write_text(json.dumps(old_rec) + "\n" + json.dumps(trec) + "\n" +
                                                      json.dumps(dict(trec, scan_date="2099-01-01")) + "\n",
                                                      encoding="utf-8")
    stale = SU3.read_tree_night(base3, day)
    check(f_ok and rc3 == 0 and held_html.count(f"<b>{sa}</b>") == 1 and "7 setup rows - one purchase" in H3 and
          f"- **{sa}** bought 2026-01-08 at 1970.00, now -2.59% (gross) - 7 setup rows, one purchase" in md3 and
          "Entry tree books held" in H3 and "BASEONLY" not in H3 and "<details><summary>The scan's rows (" in H3 and
          stale["found"] and stale["book"] is None,
          "v1.3 one line per stock: a purchase named by 7 setup x pick rows (5 setups on one pick + C3 on two more) is "
          "ONE card listing every pick, its setups and when each sells, soonest first (D5 close: tomorrow / in 4 "
          "sessions; N1 fresh: D6); a stock with FIRES and ARMED on two picks is one 'at the next open' line with both; the entry tree's "
          "orders (D calm list with the open rule, ENS calm buy, a setup buy) and lanes per stock; the tree books' "
          "held stocks (baseline books never) and only while no later scan has run; the scan's rows folded away",
          (f_ok, rc3, held_html.count(f"<b>{sa}</b>"), [x.get("sells") for x in hg], [(k_, v["tree"], v["do"]) for k_, v in nxs.items()]))
    # ---- the trade journal: the FROZEN SETUPS band
    import tl_export as X
    import tl_journal as J
    rc, log = quiet(X.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(TMP / "su_exp"),
                             "--stage-e-any", "--features", "none", "--no-benchmark"])
    ex = sorted((TMP / "su_exp" / "export").glob("TLX_*"))[-1]
    from openpyxl import load_workbook
    res_j = {}
    for nm, sb in (("with", str(base)), ("without", None)):
        quiet(J.build, ex, False, f"J_{nm}.xlsx", lambda m: None, sb)
        wb = load_workbook(ex / f"J_{nm}.xlsx", read_only=True)
        ws = wb["Trades"]
        rows = list(ws.iter_rows(values_only=True))
        hdr = next(r for r in rows if r and "Symbol" in r)
        res_j[nm] = (hdr, rows[rows.index(hdr) + 1:])
    hdr, body = res_j["with"]
    traded_tagged = [t for t in plan if int(t.rsplit("-", 1)[1]) <= 3]
    ci = hdr.index("Setups")
    n_tagged = sum(1 for r in body if r[ci])
    check("Setups" in hdr and "S2 %" in hdr and "N1 %" in hdr and n_tagged == len(traded_tagged) and
          "Setups" not in res_j["without"][0],
          f"the trade journal: a FROZEN SETUPS band (which setups entered each traded pick, each setup's net at its "
          f"primary exit) - {len(traded_tagged)} tagged traded picks; no band without the tags",
          (n_tagged, len(traded_tagged)))


def plan_txt(d: dict) -> str:
    return " ".join(f"{s}@D{d[s]}" for s in ("S2", "C1", "N1") if s in d)


def fake_tree(base: Path, picks: pd.DataFrame, rows: dict, frozen: str = "f" * 64) -> Path:
    """setuplab tree's output: rows = {trade_id: {lane, how, action, ...}}; every other pick: lane JUMPY, no action."""
    run = base / "TREE" / "TREE_20261109_001"
    run.mkdir(parents=True, exist_ok=True)
    out = []
    for t, e, rk, sy, sd in zip(picks["trade_id"].astype(str), picks["engine"], picks["rank"], picks["symbol"],
                                picks["signal_day"]):
        r = rows.get(t, {})
        lane = r.get("lane", "JUMPY")
        out.append({"trade_id": t, "engine": e, "rank": int(rk), "symbol": sy, "signal_day": f"{pd.Timestamp(sd):%Y-%m-%d}",
                    "s_atr14": 0.04 if lane == "CALM" else 0.07, "cutoff": 0.055, "lane": lane, "etf": bool(r.get("etf", False)),
                    "gap_pct": r.get("gap", 0.5), "opened_up": r.get("gap", 0.5) >= 0, "dip_2pct": False,
                    "runner": False, "first_setup": r.get("first", ""), "setup_net": r.get("setup_net", np.nan),
                    "bunch": np.nan, "d1_net": r.get("d1_net", 0.25), "action": r.get("action", ""),
                    "how": r.get("how", ""), "in_book_start1": False, "complete": True})
    pd.DataFrame(out).to_parquet(run / "tree_tags.parquet", index=False)
    meta = {"version": "setuplab v1.1", "tree_sha256": "a" * 64, "frozen_sha256": frozen,
            "window": ["2021-01-01", "2026-09-22"], "reconciled": True, "cutoffs": {"2023": 0.055}}
    (run / "TREE_RUN.json").write_text(json.dumps(meta), encoding="utf-8")
    (run / "outputs.sha256").write_text(f"{_sha(run / 'tree_tags.parquet')}  tree_tags.parquet\n", encoding="utf-8")
    return run


def run_tree(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("18. setups add-on v1.2: calm / jumpy and the entry tree in the backtester, simulator and journal")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "tr_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    import tl_backtest as BT
    from tl_common import TLError
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::7].head(30).set_index("trade_id")
    # the planted tree: open buys (calm), S2 / C1 / N1 buys on their own day, skips; tags agree with the setup buys
    kinds = ["open", "S2@D3", "N1@D4", "skip", "C1@D2", "N1@D5", "open", "S2@D1", "skip", "skip"]
    rows, tplan, want = {}, {}, {}
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        if k == "open":
            rows[t] = {"lane": "CALM", "how": "open", "action": "BUY AT OPEN (calm, opened up)", "d1_net": 1.5 + i}
            want[t] = (1, 5)
        elif k == "skip":
            rows[t] = {"lane": "JUMPY", "how": "", "action": "WAIT: jumpy -> no setup: skipped", "gap": -0.4}
            want[t] = None
        else:
            sid, kk = k.split("@D")
            kk = int(kk)
            rows[t] = {"lane": "JUMPY" if i % 2 else "CALM", "how": k, "action": f"WAIT: jumpy -> {k}", "first": k,
                       "setup_net": -2.0 + i, "gap": -1.0}
            tplan[t] = {sid: kk}
            want[t] = (kk, kk + 4 if sid == "N1" else 5)
    base = TMP / "tr_out"
    fake_tags(base, P, tplan)
    run = fake_tree(base, P, rows)
    # ---- the tree run: read only with its hash
    t0_, i0 = SU.load_tree(None)
    try:
        SU.load_tree(None, need=True)
        need_ok = False
    except TLError as e:
        need_ok = "entry tree" in str(e) and "--setups" in str(e)
    tree, tinf = SU.load_tree(base)
    good = (run / "tree_tags.parquet").read_bytes()
    pd.read_parquet(run / "tree_tags.parquet").assign(lane="CALM").to_parquet(run / "tree_tags.parquet", index=False)
    try:
        SU.load_tree(base)
        tamper = False
    except TLError as e:
        tamper = "does not match" in str(e)
    (run / "tree_tags.parquet").write_bytes(good)
    _, i_none = SU.load_tree(TMP / "tr_nothing")
    check(t0_ is None and not i0["used"] and need_ok and tree is not None and tinf["run"] == run.name and
          tinf["reconciled"] is True and tamper and not i_none["used"] and "run setuplab's tree command" in i_none["why"],
          "tree run: none without --setups / SETUPLAB_OUT (a clear refusal when needed, and when the folder has no "
          "TREE run); the newest TREE run is read only when its outputs.sha256 matches - a changed table is refused")
    # ---- the tree strategy: buys where the tree bought, sells where it sold
    sdir = TMP / "tr_strats"
    sdir.mkdir(exist_ok=True)
    tree_src = (LAB / "strategies" / "tree.py").read_text(encoding="utf-8").replace('"from": "2021-01-01"',
                                                                                   '"from": "2023-01-01"')
    s_tree = sdir / "tree.py"
    s_tree.write_text(tree_src, encoding="utf-8")
    out = TMP / "tr_bt"

    def bt(strategy, extra=(), setups=True):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--context", "none"] + list(extra) + (["--setups", str(base)] if setups else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_

    rc, log, d = bt(s_tree)
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    rep = (d / "report.md").read_text(encoding="utf-8")
    dd = pd.read_csv(d / "data_dictionary.csv")
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    ok_t, bad = rc == 0, []
    for t, wv in want.items():
        r = A.loc[t]
        if wv is None:
            g = r["status"] == "not_entered" and r["net_bp"] == 0
        else:
            k, xs = wv
            sym, sig = cand.at[t, "symbol"], int(cand.at[t, "sig"])
            o = float(daily[sym]["open"].iloc[sig + k])
            c = float(daily[sym]["close"].iloc[sig + xs])
            net = (c / o - 1 - 0.0035) * 1e4
            g = (r["status"] == "ok" and int(r["entry_session"]) == k and abs(r["first_entry"] - o) < 1e-9 and
                 int(r["exit_session"]) == xs and abs(r["net_bp"] - net) < 1e-6 and r["tree_how"] == rows[t]["how"])
        if not g:
            bad.append((t, r["status"], r.get("entry_session"), wv, r.get("exit_session")))
        ok_t &= bool(g)
    others = A.drop(index=list(want))
    ok_t &= bool((others["status"].isin(["not_entered", "pending"])).all())
    n_buy = sum(1 for v in want.values() if v)
    check(ok_t and sm["strategy"]["tree_entry"] is True and "This strategy IS the tree" in rep and
          int(A["entered"].astype(bool).sum()) == n_buy and any(v and v[1] == 9 for v in want.values()),
          f"tree strategy: each of the {n_buy} planted tree buys entered at ITS open (D1 for a calm open buy, the setup's "
          f"own day for S2 / C1 / N1) and sold at its close (the 5th; N1 4 sessions after its entry - session 9 for N1 "
          f"on D5); net = exit / open - 1 - 35 bp by hand; every skipped pick and every other pick not entered", bad[:4])
    # ---- columns, documented; the lane table by hand
    tcol = A.loc[list(want)]
    col_ok = all(tcol.at[t, "lane"] == rows[t]["lane"] and tcol.at[t, "tree_action"] == rows[t]["action"] and
                 (tcol.at[t, "calm"] == 1.0) == (rows[t]["lane"] == "CALM") for t in want)
    net_ok = all((abs(tcol.at[t, "tree_net"] - (rows[t]["d1_net"] if rows[t]["how"] == "open" else rows[t]["setup_net"]))
                  < 1e-9) if rows[t]["how"] else not np.isfinite(tcol.at[t, "tree_net"]) for t in want)
    paired = A[A["paired"].astype(bool)]
    lanes = {(r_["engine"], r_["lane"]): r_ for r_ in sm["tree"]["lanes"]}
    lt_ok = True
    for ln in ("CALM", "JUMPY"):
        g = paired[paired["lane"] == ln]
        r_ = lanes.get(("D", ln))
        lt_ok &= r_ is not None and r_["picks"] == len(g) and abs(r_["diff"][0] - (g["net_bp"] - g["net_bp_compare"]).mean()) < 1e-6
    check(rc == 0 and col_ok and net_ok and lt_ok and {"lane", "lane_atr14", "lane_cutoff", "calm", "opened_up",
          "tree_action", "tree_how", "tree_net", "tree_tagged"} <= set(A.columns) and
          not (dd["meaning"] == "UNDOCUMENTED").any() and "## Calm / jumpy lanes and the entry tree" in rep and
          "| D | CALM |" in rep and "| D | JUMPY |" in rep,
          "trades.csv carries the lane (lane, ATR, cut-off, calm) and the tree's action / buy / net on every pick, "
          "documented; the report's lane table = the paired picks by lane, difference by hand",
          (col_ok, net_ok, lt_ok))
    # ---- 'calm' as a filter (and refused without the tree)
    s_calm = sdir / "calm_plan.py"
    s_calm.write_text('STRATEGY = {"name": "calm_plan", "mode": "daily", "picks": {"engines": ["D"], "ranks": [1, 2, 3], '
                      '"filter": "calm == 1"}}\n', encoding="utf-8")
    rc, log, d = bt(s_calm, ["--no-portfolio"])
    C_ = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    calm_ids = {t for t, r_ in rows.items() if r_["lane"] == "CALM"}
    fil = C_.loc[[t for t in rows if t in C_.index]]
    f_ok = all((fil.at[t, "status"] == "filtered") != (t in calm_ids) for t in fil.index) and \
        bool((C_.drop(index=list(fil.index))["status"] == "filtered").all())
    rc2, log2, _ = bt(s_calm, ["--no-portfolio"], setups=False)
    rc_ok = SU.reads_calm({"picks": {"filter": "calm == 1"}}) and SU.reads_calm(
        {"entries": [{"name": "a", "when": "calm > 0 and close > open"}]}) and not SU.reads_calm(
        {"name": "calm", "description": "a calm strategy", "picks": {"filter": "calmness > 1"}})
    check(rc == 0 and f_ok and rc2 == 2 and "needs setuplab's tree run" in log2 and rc_ok,
          "'calm' is a pick attribute (known at the pick's close): filter 'calm == 1' trades the calm picks and filters "
          "the jumpy ones; without a tree run the filter is refused with the reason (a name or description saying 'calm' is "
          "not a rule)", (rc, f_ok, rc2, log2[-200:], rc_ok))
    # ---- the guards
    def g_rc(text, setups=True, root_base=None):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(sp), "--no-portfolio", "--context", "none"]
        if setups:
            args += ["--setups", str(root_base or base)]
        return quiet(BT.main, args)
    g1 = g_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"], "filter": "tree_net > 0"}}\n')
    g2 = g_rc('STRATEGY = {"name": "g2", "picks": {"engines": ["D"]}, "entries": [{"name": "b", "size": 1.0, '
              '"when": "opened_up and close > open", "sessions": [1, 4]}]}\n')
    g3 = g_rc(tree_src.replace('{"name": "tree", "type": "time", "tree": True}', '{"name": "d5", "type": "time", "session": 5}'))
    g4 = g_rc(tree_src.replace('"max_sessions": 9', '"max_sessions": 8'))
    g5 = g_rc(tree_src.replace('{"name": "tree", "size": 1.0, "tree": True}',
                               '{"name": "tree", "size": 1.0, "tree": True, "session": 2}'))
    g6 = g_rc(tree_src.replace('{"name": "tree", "size": 1.0, "tree": True}',
                               '{"name": "tree", "size": 1.0, "tree": True}, {"name": "o", "size": 1.0, "at": "open", '
                               '"session": 1}'))
    g7 = g_rc(tree_src, setups=False)
    bad_base = TMP / "tr_out_bad"
    fake_tags(bad_base, P, {t: {k_: v + 1 if v < 5 else 1 for k_, v in d_.items()} for t, d_ in tplan.items()})
    fake_tree(bad_base, P, rows)
    g8 = g_rc(tree_src, root_base=bad_base)
    other_base = TMP / "tr_out_other"
    fake_tags(other_base, P, tplan)
    fake_tree(other_base, P, rows, frozen="e" * 64)
    g9 = g_rc(tree_src, root_base=other_base)
    gs = (g1, g2, g3, g4, g5, g6, g7, g8, g9)
    check(g1[0] == 2 and "'tree_net' is an entry-tree column" in g1[1] and g2[0] == 2 and
          "'opened_up' is an entry-tree column" in g2[1] and g3[0] == 2 and "go together" in g3[1] and
          g4[0] == 2 and "max_sessions >= 9" in g4[1] and g5[0] == 2 and "takes no 'session'" in g5[1] and
          g6[0] == 2 and "must be the only entry" in g6[1] and g7[0] == 2 and "needs" in g7[1] and
          g8[0] == 2 and "disagree" in g8[1] and g9[0] == 2 and "freeze" in g9[1],
          "guards: a filter or rule naming a tree column (tree_net, opened_up) is refused (look-ahead) with the way out; "
          "a tree entry without the tree exit, with max_sessions 8, with a session, beside another entry, without the "
          "tree run, with tags that disagree with the tree's setup days, or with a tree on another freeze is refused",
          [x[1][-160:] for x in gs if x[0] != 2])
    # ---- without a tree run: nothing changes (no columns, no section)
    nb = TMP / "tr_out_tagsonly"
    fake_tags(nb, P, tplan)
    rc, log, d = bt(LAB / "strategies" / "plan.py", ["--no-portfolio"], setups=False)
    A0 = pd.read_parquet(d / "trades.parquet")
    rep0 = (d / "report.md").read_text(encoding="utf-8")
    rc_b, log_b = quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                                  "--strategy", str(LAB / "strategies" / "plan.py"), "--no-portfolio", "--context",
                                  "none", "--setups", str(nb)])
    d_b = sorted((out / "backtest").glob("TLB_*"))[-1]
    A_b = pd.read_parquet(d_b / "trades.parquet")
    check(rc == 0 and rc_b == 0 and "lane" not in A0.columns and "lane" not in A_b.columns and "setups" in A_b.columns
          and "Calm / jumpy" not in rep0 and "Calm / jumpy" not in (d_b / "report.md").read_text(encoding="utf-8"),
          "without a tree run (no --setups, or a setuplab folder with tags only) the backtest runs as before: no lane "
          "columns, no lane section")
    # ---- the simulator's line and a tree strategy there
    import tl_sim as SIM
    t_n1 = next(t for t, v in want.items() if v and v[1] == 9)
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t_n1, "--strategy", str(s_tree), "--context", "none", "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t_n1}__tree_story.md").read_text(encoding="utf-8")
    rs = json.loads((sim / "summary.json").read_text())["results"]["tree"][0]
    check(rc == 0 and "**Entry tree**" in story and f"lane {rows[t_n1]['lane']}" in story and rows[t_n1]["action"] in
          story and int(rs["entry_session"]) == 5 and int(rs["exit_session"]) == 9,
          "the simulator: the story names the pick's lane and the tree's action; the tree strategy buys N1 on D5 and "
          "sells it at session 9", (rc, story[-400:], rs.get("entry_session"), rs.get("exit_session")))
    # ---- the trade journal's band
    import tl_export as X
    import tl_journal as J
    rc, log = quiet(X.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(TMP / "tr_exp"),
                             "--stage-e-any", "--features", "none", "--no-benchmark"])
    ex = sorted((TMP / "tr_exp" / "export").glob("TLX_*"))[-1]
    from openpyxl import load_workbook
    res_j = {}
    for nm, sb in (("with", str(base)), ("without", None), ("tagsonly", str(nb))):
        quiet(J.build, ex, False, f"J_{nm}.xlsx", lambda m: None, sb)
        wb = load_workbook(ex / f"J_{nm}.xlsx", read_only=True)
        rows_x = list(wb["Trades"].iter_rows(values_only=True))
        hdr = next(r_ for r_ in rows_x if r_ and "Symbol" in r_)
        res_j[nm] = (hdr, rows_x[rows_x.index(hdr) + 1:], wb)
    hdr, body, wb = res_j["with"]
    need_h = ("Engine", "Rank", "Symbol", "Lane", "Tree", "Tree buy", "Tree %", "Pick day")
    ix = {h: hdr.index(h) for h in need_h if h in hdr}
    seen, j_ok = 0, len(ix) == len(need_h)
    for r_ in body if j_ok else []:
        if not r_ or r_[ix["Engine"]] != "D":
            continue
        day_ = pd.Timestamp(r_[ix["Pick day"]])
        t = f"D-{day_:%Y%m%d}-{int(r_[ix['Rank']])}"
        if t in rows:
            seen += 1
            rr = rows[t]
            tp = r_[ix["Tree %"]]
            want_pct = (rr["d1_net"] if rr["how"] == "open" else rr.get("setup_net", np.nan)) / 100 if rr["how"] else None
            j_ok &= (r_[ix["Lane"]] == rr["lane"] and r_[ix["Tree"]] == rr["action"] and
                     (r_[ix["Tree buy"]] or "") == ("D1 open" if rr["how"] == "open" else rr["how"]) and
                     ((tp is None) if want_pct is None else (tp is not None and abs(tp - want_pct) < 1e-9)))
    readme = " ".join(str(c) for r_ in wb["Read me"].iter_rows(values_only=True) for c in r_ if c)
    check(seen == len(rows) and j_ok and "Lane" not in res_j["without"][0] and "Lane" not in res_j["tagsonly"][0] and
          "Setups" in res_j["tagsonly"][0] and "Calm / jumpy and the entry tree" in readme,
          f"the trade journal: a CALM / JUMPY AND THE ENTRY TREE band (lane, ATR, cut-off, opened up, the tree's action, "
          f"where it bought, its net) on all {len(rows)} planted picks, explained in the Read me; no band without a "
          f"tree run", (seen, len(rows), j_ok))


def run_sde(check_suite, quiet, fresh_modules, TMP: Path, LAB: Path) -> None:
    def check(cond, msg, detail=None):
        check_suite(cond, msg if cond or detail is None else f"{msg}   <- {str(detail)[:600]}")

    print("19. setups add-on v1.4: SDE at the pick and the tree's open_if branch")
    os.environ.pop("SETUPLAB_OUT", None)
    w = W.make_world(TMP / "sde_world", "absent", seed=11, n_syms=12, n_days=170, with_special=False)
    root = w["root"]
    fresh_modules(root)
    import tl_setups as SU
    import tl_backtest as BT
    # ---- SDE by hand
    fall = np.array([100.0 - 2 * i for i in range(11)])
    chop = np.array([100, 105, 95, 105, 95, 105, 95, 105, 95, 105, 90.0])
    flat = np.full(11, 50.0)
    miss = fall.copy()
    miss[4] = np.nan
    split = fall.copy()
    split[6:] = split[6:] / 2.0                                  # a 1:2 split not adjusted
    up3 = np.array([10, 11, 10.5, 12.0])
    h_ok = (abs(SU.sde_series(fall, 10)[-1] + 1.0) < 1e-12 and
            abs(SU.sde_series(chop, 10)[-1] - (90 - 100) / (5 + 10 * 8 + 15)) < 1e-12 and
            np.isnan(SU.sde_series(flat, 10)[-1]) and np.isnan(SU.sde_series(miss, 10)[-1]) and
            np.isnan(SU.sde_series(split, 10)[-1]) and np.isnan(SU.sde_series(fall[:10], 10)).all() and
            abs(SU.sde_series(up3, 3)[-1] - 2.0 / (1 + 0.5 + 1.5)) < 1e-12 and
            np.isnan(SU.sde_series(fall, 10)[:10]).all() and
            list(SU.bucket_sde([-0.9, -0.5, 0.0, 0.5, np.nan])) == ["NEG < -0.5", "MID", "MID", "POS >= +0.5", ""])
    check(h_ok, "SDE by hand: an orderly fall = -1; a choppy path = net / the sum of the moves; blank for a flat window, "
                "a missing bar, an unadjusted split (a move above 45%) and too little history; buckets NEG < -0.5 / "
                "MID / POS >= +0.5")
    # ---- the world, a planted tree, the tags it agrees with
    P = pd.read_parquet(root / "research2" / "pick_meta" / "PM_TEST_001" / "predictions.parquet")
    days = w["days"]
    P["signal_day"] = pd.to_datetime(P["signal_day"]).dt.normalize()
    P["trade_id"] = [f"{e}-{d:%Y%m%d}-{int(r)}" for e, d, r in zip(P["engine"], P["signal_day"], P["rank"])]
    pos = {d.normalize(): i for i, d in enumerate(days)}
    P["sig"] = P["signal_day"].map(lambda d: pos.get(pd.Timestamp(d).tz_localize(None).normalize(), -1))
    daily = {s_: pd.read_parquet(root / f"{s_}_daily.parquet") for s_ in w["names"]}
    cl = {s_: daily[s_]["close"].to_numpy(float) for s_ in w["names"]}

    def sde_hand(sym, sig, n=10):
        c = cl[sym][sig - n:sig + 1]
        den = np.abs(np.diff(c)).sum()
        return (c[-1] - c[0]) / den if den > 0 else np.nan
    cand = P[(P["engine"] == "D") & (P["rank"] <= 3) & (P["sig"] >= 40) & (P["sig"] <= len(days) - 15)]
    cand = cand.sort_values(["sig", "rank"]).iloc[::5].head(40).set_index("trade_id")
    cand["sde_h"] = [sde_hand(s_, int(g)) for s_, g in zip(cand["symbol"], cand["sig"])]
    thr = float(np.nanmedian(cand["sde_h"]))
    rows, tplan = {}, {}
    kinds = ["open", "S2@D3", "skip", "N1@D4", "skip", "skip"]
    for i, t in enumerate(cand.index):
        k = kinds[i % len(kinds)]
        lane = "CALM" if k == "open" else ("JUMPY" if i % 4 else "CALM")
        r = {"lane": lane, "how": "" if k == "skip" else k, "action": "x", "d1_net": 0.5, "setup_net": 0.25,
             "etf": False}
        if "@D" in k:
            sid, kk = k.split("@D")
            tplan[t] = {sid: int(kk)}
            r["first"] = k
        rows[t] = r
    # one ETF the rule would buy (jumpy, SDE10 below the threshold): the tree never buys an ETF
    etf_t = next(t for t in cand.index if rows[t]["lane"] == "JUMPY" and rows[t]["how"] == "" and
                 np.isfinite(cand.at[t, "sde_h"]) and cand.at[t, "sde_h"] < thr)
    rows[etf_t]["etf"] = True
    base = TMP / "sde_out"
    fake_tags(base, P, tplan)
    fake_tree(base, P, rows)
    sdir = TMP / "sde_strats"
    sdir.mkdir(exist_ok=True)
    tree_src = (LAB / "strategies" / "tree.py").read_text(encoding="utf-8").replace('"from": "2021-01-01"',
                                                                                   '"from": "2023-01-01"')
    (sdir / "tree.py").write_text(tree_src, encoding="utf-8")
    sde_src = (LAB / "strategies" / "tree_sde.py").read_text(encoding="utf-8").replace(
        '"from": "2021-01-01"', '"from": "2023-01-01"').replace("pre_sde10 < -0.5", f"pre_sde10 < {thr!r}")
    (sdir / "tree_sde.py").write_text(sde_src, encoding="utf-8")
    out = TMP / "sde_bt"

    def bt(strategy, extra=(), setups=True, nopf=False):
        args = ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any", "--strategy",
                str(strategy), "--context", "none"] + list(extra) + (["--setups", str(base)] if setups else []) + \
            (["--no-portfolio"] if nopf else [])
        rc_, log_ = quiet(BT.main, args)
        d_ = sorted((out / "backtest").glob("TLB_*"))[-1] if (out / "backtest").exists() else None
        return rc_, log_, d_
    rc, log, d = bt(sdir / "tree_sde.py", ["--compare", str(sdir / "tree.py")])
    A = pd.read_parquet(d / "trades.parquet").set_index("trade_id")
    sm = json.loads((d / "summary.json").read_text())
    rep = (d / "report.md").read_text(encoding="utf-8")
    dd = pd.read_csv(d / "data_dictionary.csv")
    # SDE at real picks against the world's closes
    sd_ok = all(abs(A.at[t, "pre_sde10"] - cand.at[t, "sde_h"]) < 1e-9 if np.isfinite(cand.at[t, "sde_h"]) else
                np.isnan(A.at[t, "pre_sde10"]) for t in cand.index)
    # the branch: jumpy, not ETF, SDE10 below the threshold -> D1 open, 5th close; everyone else = the frozen tree
    br_ok, n_br, bad = True, 0, []
    for t in cand.index:
        r, a_ = rows[t], A.loc[t]
        sym, sig = cand.at[t, "symbol"], int(cand.at[t, "sig"])
        hit = r["lane"] == "JUMPY" and not r["etf"] and np.isfinite(cand.at[t, "sde_h"]) and cand.at[t, "sde_h"] < thr
        if hit:
            n_br += 1
            o = float(daily[sym]["open"].iloc[sig + 1])
            c5 = float(daily[sym]["close"].iloc[sig + 5])
            g = (a_["status"] == "ok" and int(a_["entry_session"]) == 1 and int(a_["exit_session"]) == 5 and
                 abs(a_["net_bp"] - (c5 / o - 1 - 0.0035) * 1e4) < 1e-6)
        else:
            g = (a_["status"] == a_["status_compare"] and (abs(a_["net_bp"] - a_["net_bp_compare"]) < 1e-9 or
                                                          (np.isnan(a_["net_bp"]) and np.isnan(a_["net_bp_compare"]))))
        if not g:
            bad.append((t, r["lane"], r["etf"], cand.at[t, "sde_h"], a_["status"], a_.get("entry_session")))
        br_ok &= bool(g)
    etf_ok = rows[etf_t]["etf"] and A.at[etf_t, "status"] == A.at[etf_t, "status_compare"] == "not_entered"
    # every other pick (the tree run tags them JUMPY, skipped): the rule decides alone - below the threshold = D1 open
    others = A.drop(index=list(cand.index))
    o_hit = (others["lane"] == "JUMPY") & (others["pre_sde10"] < thr)
    oth_ok = bool(((others.loc[o_hit, "entry_session"] == 1) | (others.loc[o_hit, "status"] == "pending")).all() and
                  (others.loc[~o_hit, "status"] == others.loc[~o_hit, "status_compare"]).all() and o_hit.any())
    check(rc == 0 and sd_ok and br_ok and etf_ok and oth_ok and n_br >= 3 and sm["strategy"]["tree_open_if"] and
          sm["compare"]["name"] == "tree",
          f"the tree's open_if: the {n_br} jumpy non-ETF tree picks whose SDE10 (by hand from the world's closes) is "
          f"below the rule's threshold are bought at the D1 open and sold at the 5th close (net by hand); every other "
          f"pick - calm, ETF, above the threshold, untagged - trades exactly as the frozen tree it is compared with",
          (rc, sd_ok, br_ok, etf_ok, oth_ok, n_br, bad[:3], log[-300:]))
    # the decision rule (daily_diff_bp + cagr_and_drawdown) and the SDE section, by hand from the outputs
    dec = sm["decision"]
    pf = sm.get("portfolio") or {}
    sS, sC = pf.get("strategy") or {}, pf.get("compare") or {}
    lo = (pf.get("daily_ret_diff_bp") or [np.nan] * 3)[1]
    want = "PASS" if (lo > 0 and sS.get("cagr", np.nan) > sC.get("cagr", np.nan) and
                      sS.get("max_drawdown", np.nan) >= sC.get("max_drawdown", np.nan)) else "FAIL"
    tab = {(r_["engine"], r_["lane"], r_["sde10"]): r_ for r_ in sm["sde"]["table"]}
    paired = A[A["paired"].astype(bool)].copy()
    paired["b"] = SU.bucket_sde(paired["pre_sde10"].to_numpy(float))
    t_ok = True
    for (e_, ln, bk), r_ in tab.items():
        g = paired[(paired["engine"] == e_) & (paired["lane"].where(paired["lane"].isin(["CALM", "JUMPY"]), "no lane")
                                               == ln) & (paired["b"].replace("", "no SDE") == bk)]
        t_ok &= r_["picks"] == len(g) and abs(r_["diff"][0] - (g["net_bp"] - g["net_bp_compare"]).mean()) < 1e-6
    # decide() by hand on planted money numbers: each condition matters
    ev0 = {"summary": {"diff": [1.0, 0.5, 2.0], "strategy": [1.0, 0.5, 2.0]}}

    def pf0(lo_, cg, dd_):
        return {"stats": {"daily_ret_diff_bp": [1.0, lo_, 3.0], "strategy": {"cagr": cg[0], "max_drawdown": dd_[0]},
                          "compare": {"cagr": cg[1], "max_drawdown": dd_[1]}}}
    rule0 = {"metric": "daily_diff_bp", "pass_if": "lower > 0", "money": "cagr_and_drawdown"}
    d_ok = (BT.decide(rule0, ev0, pf0(0.2, (0.5, 0.4), (-0.2, -0.3)))["verdict"] == "PASS" and
            BT.decide(rule0, ev0, pf0(0.2, (0.5, 0.4), (-0.35, -0.3)))["verdict"] == "FAIL" and
            BT.decide(rule0, ev0, pf0(0.2, (0.3, 0.4), (-0.2, -0.3)))["verdict"] == "FAIL" and
            BT.decide(rule0, ev0, pf0(-0.1, (0.5, 0.4), (-0.2, -0.3)))["verdict"] == "FAIL" and
            BT.decide(rule0, ev0, None)["verdict"].startswith("NO MONEY VIEW") and
            BT.decide({"metric": "daily_diff_bp", "pass_if": "lower > 0"}, ev0, pf0(0.2, (0.3, 0.4), (-0.5, -0.3)))[
                "verdict"] == "PASS")
    m_want = bool(sS.get("cagr", np.nan) > sC.get("cagr", np.nan) and
                  sS.get("max_drawdown", np.nan) >= sC.get("max_drawdown", np.nan))
    check(d_ok and dec.get("verdict") == want and dec.get("money_ok") == m_want and np.isfinite(lo) and
          abs(dec.get("value", np.nan) - lo) < 1e-9 and "cagr" in sS and "## SDE at the pick" in rep and
          "| D | JUMPY |" in rep.split("## SDE at the pick")[1] and t_ok and len(tab) >= 2 and
          {"pre_sde3", "pre_sde5", "pre_sde10", "pre_sde20"} <= set(A.columns) and
          not (dd["meaning"] == "UNDOCUMENTED").any(),
          "decision rule daily_diff_bp + cagr_and_drawdown: PASS only when the daily-difference interval is above 0 AND "
          "the CAGR is higher AND the worst drawdown no deeper (each condition flipped by hand; and against the run's "
          "own money numbers); the "
          "SDE section's table = the paired picks by engine, lane and SDE10, difference by hand; pre_sde* documented",
          (d_ok, dec, want, t_ok, list(tab)[:4]))
    # ---- pre_sde10 in a filter; a comparison that trades the tree gets the tree; SDE without tree / context
    (sdir / "neg.py").write_text(f'STRATEGY = {{"name": "neg", "picks": {{"engines": ["D"], "ranks": [1, 2, 3], '
                                 f'"from": "2023-01-01", "filter": "pre_sde10 < {thr!r}"}}}}\n', encoding="utf-8")
    rc2, log2, d2 = bt(sdir / "neg.py", nopf=True, setups=False)
    N = pd.read_parquet(d2 / "trades.parquet")
    f_ok = bool(((N["status"] == "filtered") == ~(N["pre_sde10"] < thr)).all()) and (N["status"] != "filtered").any()
    rep2 = (d2 / "report.md").read_text(encoding="utf-8")
    (sdir / "plan3.py").write_text('STRATEGY = {"name": "plan3", "picks": {"engines": ["D"], "ranks": [1, 2, 3], '
                                   '"from": "2023-01-01"}, "max_sessions": 9}\n', encoding="utf-8")
    rc3, log3, d3 = bt(sdir / "plan3.py", ["--compare", str(sdir / "tree.py")], nopf=True)
    C3 = pd.read_parquet(d3 / "trades.parquet").set_index("trade_id")
    c_ok = all((C3.at[t, "status_compare"] == "ok") == bool(rows[t]["how"]) or C3.at[t, "status_compare"] == "pending"
               for t in cand.index)
    check(rc2 == 0 and f_ok and "## SDE at the pick" in rep2 and "| D | all |" in rep2 and rc3 == 0 and c_ok,
          "pre_sde10 is a pick attribute: a filter keeps exactly the picks below its threshold; the SDE section runs "
          "without a tree run and without market context (lane 'all'); a plan compared with strategies/tree.py gets "
          "the tree's entries for the comparison (never a silent 'not entered')", (rc2, f_ok, rc3, c_ok, log3[-300:]))
    # ---- guards
    def g_rc(text):
        sp = sdir / "guard.py"
        sp.write_text(text, encoding="utf-8")
        return quiet(BT.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--strategy", str(sp), "--no-portfolio", "--context", "none", "--setups", str(base)])
    g1 = g_rc('STRATEGY = {"name": "g1", "picks": {"engines": ["D"]}, "entries": [{"name": "o", "size": 1.0, "at": '
              '"open", "session": 1, "open_if": "pre_sde10 < 0"}]}\n')
    g2 = g_rc(tree_src.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "tree_net > 0"}],\n    "exits"'))
    g3 = g_rc(tree_src.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": "close > 0"}],\n    "exits"'))
    g4 = g_rc(tree_src.replace('"tree": True}],\n    "exits"', '"tree": True, "open_if": ""}],\n    "exits"'))
    check(g1[0] == 2 and "open_if belongs to the tree entry" in g1[1] and g2[0] == 2 and "entry-tree column" in g2[1]
          and g3[0] == 2 and "pick attributes only" in g3[1] and g4[0] == 2 and "open_if must be a rule" in g4[1],
          "guards: open_if off the tree entry, naming a tree column (hindsight), reading a bar value (not known at the "
          "pick) or empty is refused with the reason", [x[1][-160:] for x in (g1, g2, g3, g4) if x[0] != 2])
    # ---- the simulator's SDE line
    import tl_sim as SIM
    t_h = next(t for t in cand.index if np.isfinite(cand.at[t, "sde_h"]))
    rc, log = quiet(SIM.main, ["--root", str(root), "--pm-run", "PM_TEST_001", "--out", str(out), "--stage-e-any",
                               "--trade", t_h, "--strategy", str(sdir / "tree_sde.py"), "--context", "none",
                               "--setups", str(base)])
    sim = sorted((out / "sim").glob("TLS_*"))[-1]
    story = (sim / f"{t_h}__tree_sde_story.md").read_text(encoding="utf-8")
    check(rc == 0 and "**SDE at the pick**" in story and f"{cand.at[t_h, 'sde_h']:+.2f}" in story,
          "the simulator: the story gives SDE at the pick (3 / 5 / 10 / 20) and the tree_sde strategy runs there",
          (rc, story[-300:]))
