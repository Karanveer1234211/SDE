"""
tl_engine.py - tradelab v1.1: strategies and the trade engine (v1.1: market-context values in rules).

A STRATEGY (a Python file with a STRATEGY dict, or JSON) says which picks to trade and how:

    STRATEGY = {
        "name": "scale_20_80_vwap",
        "mode": "intraday",                       # "daily" (daily bars) or "intraday" (3-minute bars)
        "picks": {"engines": ["D"], "ranks": [1, 2, 3], "filter": "prob_trap < 0.10"},
        "max_sessions": 5,                        # last session the trade may run (default exit: its close)
        "events": {"vwap_up": "crosses_above(close, vwap)"},
        "entries": [
            {"name": "open20", "size": 0.20, "at": "open", "session": 1},
            {"name": "vwap80", "size": 0.80, "when": "vwap_up", "sessions": [1, 2]},
        ],
        "exits": [
            {"name": "stop", "type": "stop", "level": "avg_entry * 0.95"},
            {"name": "time", "type": "time", "at": "close", "session": 5},
        ],
    }

Every trade is simulated bar by bar (one bar = one session in daily mode, one 3-minute bar in intraday mode):
  - a rule that fires at a bar's close acts at the NEXT bar's open ('next_open', the default);
  - stop / limit orders use levels computed at the previous bar's close (state-based levels such as
    avg_entry * 0.95 are refreshed right after fills at a bar's open);
  - 'at open' / 'at close' orders use the session's OFFICIAL open / close (the daily bar);
  - a stop and a target inside one bar: the open decides when it can (a gap); otherwise the 'intrabar'
    policy: worst (stop first, default), best, or intraday (daily mode: read the session's 3-minute bars);
  - an entry filled inside a bar cannot also exit inside that bar (the path after the fill is unknown);
  - honest exits (stage E's rule): a close locked at the lower circuit sells at the first unlocked open
    within 20 sessions, else the trade is 'stuck'; a frozen bar (o = h = l = c, locked) sells nothing.
P&L is measured against the trade's TARGET size (1.0 = the full slot): net_alloc. The flat cost model charges
half of the round trip on the buy notional at the buy and half on the sold shares' entry notional at the sale,
so a plain trade ends at exactly gross - 35 bp (the project convention).
"""
from __future__ import annotations

import copy
import json
import runpy
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from tl_common import COST_RT_BP_DEFAULT, SESSION_START_MIN, TLError, sha16
from tl_data import BAR_MIN, BARS_PER_SESSION, DailySeries, LOCK_SEARCH, Market, Session, is_forbidden_name
import tl_rules as R
import tl_setups as SU

ENGINE_VERSION = "tradelab engine v1.3 (setups add-on: setup entries, hold exits, tree entries, tree open_if)"


# ======================================================================
# costs
# ======================================================================
ZERODHA_DEFAULT = {  # delivery equity, per side unless noted; CHECK against Zerodha's current charge list
    "stt_pct": 0.1, "txn_pct": 0.00297, "sebi_pct": 0.0001, "stamp_buy_pct": 0.015, "gst_pct": 18.0,
    "brokerage_pct": 0.0, "dp_rupees_per_sell": 15.93, "ref_notional": 100000.0}


class CostModel:
    """flat (default 35 bp round trip on entry notional), per_side (buy_bp / sell_bp on each side's value),
    zerodha (itemised delivery charges; DP charge as rupees per sell, scaled by ref_notional at trade level)."""

    def __init__(self, spec: Optional[dict] = None):
        spec = dict(spec or {})
        self.model = str(spec.pop("model", "flat"))
        if self.model == "flat":
            self.rt = float(spec.pop("round_trip_bp", COST_RT_BP_DEFAULT)) / 1e4
        elif self.model == "per_side":
            self.buy_bp = float(spec.pop("buy_bp")) / 1e4
            self.sell_bp = float(spec.pop("sell_bp")) / 1e4
        elif self.model == "zerodha":
            z = dict(ZERODHA_DEFAULT)
            for k in list(spec):
                if k in z:
                    z[k] = float(spec.pop(k))
            self.z = z
        else:
            raise TLError(f"costs: unknown model '{self.model}' (flat | per_side | zerodha)")
        if spec:
            raise TLError(f"costs: unknown keys {sorted(spec)} for model {self.model}")

    def buy(self, notional: float, rupees: bool = False) -> float:
        if self.model == "flat":
            return notional * self.rt / 2
        if self.model == "per_side":
            return notional * self.buy_bp
        z = self.z
        reg = notional * (z["txn_pct"] + z["sebi_pct"] + z["brokerage_pct"]) / 100
        return notional * (z["stt_pct"] + z["stamp_buy_pct"]) / 100 + reg * (1 + z["gst_pct"] / 100)

    def sell(self, proceeds: float, basis_sold: float, rupees: bool = False) -> float:
        if self.model == "flat":
            return basis_sold * self.rt / 2
        if self.model == "per_side":
            return proceeds * self.sell_bp
        z = self.z
        reg = proceeds * (z["txn_pct"] + z["sebi_pct"] + z["brokerage_pct"]) / 100
        dp = z["dp_rupees_per_sell"] if rupees else (z["dp_rupees_per_sell"] / z["ref_notional"]) * (basis_sold > 0)
        return proceeds * z["stt_pct"] / 100 + reg * (1 + z["gst_pct"] / 100) + dp

    def describe(self) -> str:
        if self.model == "flat":
            return f"flat {self.rt * 1e4:g} bp round trip on entry notional (half at buy, half at sale)"
        if self.model == "per_side":
            return f"per side: buy {self.buy_bp * 1e4:g} bp, sell {self.sell_bp * 1e4:g} bp"
        return "zerodha itemised: " + ", ".join(f"{k}={v:g}" for k, v in self.z.items())


# ======================================================================
# strategies
# ======================================================================
_TOP_KEYS = {"name", "version", "description", "mode", "picks", "warmup_sessions", "max_sessions", "events",
             "entries", "exits", "intrabar", "same_bar_close_fills", "reentry", "on_missing_intraday", "costs",
             "slippage_bp", "sizing", "portfolio", "decision_rule", "plugins", "notes"}
_LEG_KEYS = {"name", "size", "at", "session", "when", "fill", "level", "sessions", "time", "cancel_if", "note",
             "setup", "tree", "open_if"}
_EXIT_KEYS = {"name", "type", "size", "at", "session", "when", "fill", "level", "pct", "atr", "trail_from",
              "activate", "sessions", "time", "once", "note", "hold", "tree"}
SETUP_WATCH = 5          # a frozen setup enters on watch day 1..5 after the pick (setuplab)


def _hhmm_to_min(s, what) -> int:
    try:
        hh, mm = str(s).split(":")
        m = int(hh) * 60 + int(mm) - SESSION_START_MIN
    except Exception:
        raise TLError(f"{what}: time '{s}' must be HH:MM (e.g. 09:30)")
    if not (0 <= m <= (BARS_PER_SESSION - 1) * BAR_MIN):
        raise TLError(f"{what}: time '{s}' is outside 09:15..15:27 (3-minute bar starts)")
    return m


@dataclass
class Leg:
    name: str
    size: float
    at: Optional[str]
    session: Optional[int]
    when: Optional[R.Rule]
    fill: str
    level: Optional[R.Rule]
    lo: int
    hi: int
    t_from: int
    t_until: int
    once: bool
    cancel_if: Optional[R.Rule]
    setup: Optional[str] = None          # setups add-on: buy at the open of this frozen setup's own entry day
    tree: bool = False                   # setups add-on v1.2: buy where setuplab's entry tree bought this pick
    open_if: Optional[str] = None        # setups add-on v1.4: a pick rule - true = buy the tree pick at the D1 open


@dataclass
class Exit:
    name: str
    type: str
    size: float
    at: Optional[str]
    session: Optional[int]
    when: Optional[R.Rule]
    fill: str
    level: Optional[R.Rule]
    pct: Optional[float]
    atr: Optional[float]
    trail_from: str
    activate: Optional[R.Rule]
    lo: int
    hi: int
    t_from: int
    t_until: int
    once: bool
    hold: Optional[int] = None           # setups add-on: a time exit at the close of the entry session + hold - 1
    tree: bool = False                   # setups add-on v1.2: a time exit at the close the entry tree sells at


class Strategy:
    def __init__(self, raw: dict, path: Optional[Path] = None, pick_attrs: Sequence[str] = ()):
        if not isinstance(raw, dict):
            raise TLError("STRATEGY must be a dict")
        extra = set(raw) - _TOP_KEYS
        if extra:
            raise TLError(f"strategy: unknown keys {sorted(extra)}.{R.suggest(sorted(extra)[0], _TOP_KEYS)}")
        self.raw = copy.deepcopy(raw)
        self.path = Path(path) if path else None
        self.sha = sha16(path) if path else _sha_obj(raw)
        self.name = str(raw.get("name") or (self.path.stem if self.path else "unnamed"))
        self.mode = str(raw.get("mode", "daily"))
        if self.mode not in ("daily", "intraday"):
            raise TLError(f"strategy {self.name}: mode must be 'daily' or 'intraday'")
        pk = dict(raw.get("picks") or {})
        bad = set(pk) - {"engines", "ranks", "from", "to", "filter"}
        if bad:
            raise TLError(f"strategy {self.name}: picks has unknown keys {sorted(bad)}")
        self.picks = {"engines": list(pk.get("engines", ["D"])), "ranks": list(pk.get("ranks", [1, 2, 3])),
                      "from": pk.get("from"), "to": pk.get("to"), "filter": pk.get("filter")}
        self.max_sessions = int(raw.get("max_sessions", 5))
        if not (1 <= self.max_sessions <= 30):
            raise TLError(f"strategy {self.name}: max_sessions must be 1..30")
        wd = 30 if self.mode == "daily" else 1
        self.warmup = int(raw.get("warmup_sessions", wd))
        if self.warmup < 0 or self.warmup > 260:
            raise TLError(f"strategy {self.name}: warmup_sessions must be 0..260")
        self.intrabar = str(raw.get("intrabar", "worst"))
        if self.intrabar not in ("worst", "best", "intraday"):
            raise TLError(f"strategy {self.name}: intrabar must be worst | best | intraday")
        if self.intrabar == "intraday" and self.mode != "daily":
            raise TLError(f"strategy {self.name}: intrabar 'intraday' is for daily mode (3-minute bars already decide)")
        self.same_bar = bool(raw.get("same_bar_close_fills", False))
        self.reentry = bool(raw.get("reentry", False))
        self.on_missing = str(raw.get("on_missing_intraday", "exclude"))
        if self.on_missing != "exclude":
            raise TLError(f"strategy {self.name}: on_missing_intraday supports 'exclude' only in v1")
        self.costs = CostModel(raw.get("costs"))
        self.slippage_bp = float(raw.get("slippage_bp", 0.0))
        self.sizing = dict(raw.get("sizing") or {"rule": "equal_slots", "slots": 15})
        self.portfolio = dict(raw.get("portfolio") or {})
        self.decision_rule = raw.get("decision_rule")
        self.plugins = list(raw.get("plugins") or [])
        events = dict(raw.get("events") or {})
        for k in events:
            if not str(k).isidentifier() or str(k).startswith("_"):
                raise TLError(f"strategy {self.name}: event name '{k}' must be a plain identifier")
            if k in R.MARKET_VARS or k in R.STATE_VARS or is_forbidden_name(k):
                raise TLError(f"strategy {self.name}: event name '{k}' clashes with a built-in or firewalled name")
        self.events = events
        legs_raw = list(raw.get("entries") or [{"name": "open", "size": 1.0, "at": "open", "session": 1}])
        exits_raw = list(raw.get("exits") or [])
        # setups add-on: a setup tag is known only on its own entry day - no filter or rule may read one
        texts = [self.picks.get("filter")] + list(events.values()) + [str((self.sizing or {}).get("expression") or "")]
        for d in legs_raw + exits_raw:
            texts += [str(d.get(k)) for k in ("when", "level", "cancel_if", "activate", "open_if")
                      if d.get(k) is not None]
        SU.refuse_tag_names(texts, f"strategy {self.name}")
        leg_names = [str(l.get("name", "")) for l in legs_raw]
        self.names = R.Names(self.mode, pick_attrs=pick_attrs, features=None, leg_names=leg_names, events=events)
        self.rules: List[R.Rule] = []
        self.legs = [self._leg(l, i) for i, l in enumerate(legs_raw)]
        if len({l.name for l in self.legs}) != len(self.legs):
            raise TLError(f"strategy {self.name}: entry names must be unique")
        self.setup_ids = list(dict.fromkeys(l.setup for l in self.legs if l.setup))
        if self.setup_ids and self.mode != "daily":
            raise TLError(f"strategy {self.name}: setup entries are for mode 'daily' (setuplab's setups are daily)")
        self.uses_tree = any(l.tree for l in self.legs)       # setups add-on v1.2: the entry tree
        if self.uses_tree:
            if len(self.legs) != 1:
                raise TLError(f"strategy {self.name}: the tree entry decides the whole entry - it must be the only entry")
            if self.mode != "daily":
                raise TLError(f"strategy {self.name}: the tree entry is for mode 'daily' (setuplab's tree is daily)")
            if self.max_sessions < SU.TREE_LAST_EXIT:
                raise TLError(f"strategy {self.name}: the tree may buy N1 on D5 and sell it 4 sessions later, so it needs "
                              f"max_sessions >= {SU.TREE_LAST_EXIT}")
        # entry sizes may add up to more than 1.0 when legs are alternatives (e.g. a dip limit OR a fallback);
        # at run time a buy is clipped so the position never exceeds the target size (1.0)
        self.exits = [self._exit(x, i) for i, x in enumerate(exits_raw)]
        if len({x.name for x in self.exits}) != len(self.exits):
            raise TLError(f"strategy {self.name}: exit names must be unique")
        tree_x = [x for x in self.exits if x.tree]
        if self.uses_tree != bool(tree_x):
            raise TLError(f"strategy {self.name}: the tree entry and the tree exit go together - entry "
                          f"{{'name': 'tree', 'tree': True}} and exit {{'name': 'tree', 'type': 'time', 'tree': True}}")
        holds = [x.hold for x in self.exits if x.hold]
        if holds and self.setup_ids and self.max_sessions < SETUP_WATCH + max(holds) - 1:
            raise TLError(f"strategy {self.name}: a setup may enter on D{SETUP_WATCH}, so a hold of {max(holds)} needs "
                          f"max_sessions >= {SETUP_WATCH + max(holds) - 1}")
        if not any(x.type == "time" and x.size >= 1.0 - 1e-12 and x.session == self.max_sessions and x.at == "close"
                   for x in self.exits):
            self.exits.append(Exit("end", "time", 1.0, "close", self.max_sessions, None, "close", None, None, None,
                                   "high", None, 1, self.max_sessions, 0, 10 ** 6, True))
        opens = [x.session for x in self.exits if x.type == "time" and x.at == "open" and x.size >= 1.0 - 1e-12]
        self.open_cut = min(opens) if opens else None        # a full exit at session K's open ends the trade
        last_req = self.max_sessions if self.open_cut is None else self.open_cut - 1
        self.required_sessions = list(range(1, max(1, last_req) + 1))
        self.filter = R.Rule(self.picks["filter"], self.names, "picks.filter") if self.picks["filter"] else None
        if self.filter is not None:
            if self.filter.market or self.filter.state_used or self.filter.features or self.filter.plugins:
                raise TLError(f"strategy {self.name}: picks.filter may use pick attributes only "
                              f"({sorted(self.names.pick_attrs)})")
        self.event_rules = {k: R.Rule(k, self.names, f"event {k}") for k in self.events}
        oi = next((l.open_if for l in self.legs if l.tree and l.open_if), None)     # setups add-on v1.4
        self.tree_open_if = R.Rule(oi, self.names, "tree open_if") if oi else None
        if self.tree_open_if is not None and (self.tree_open_if.market or self.tree_open_if.state_used or
                                              self.tree_open_if.features or self.tree_open_if.plugins):
            raise TLError(f"strategy {self.name}: the tree's open_if may use pick attributes only (known at the pick's "
                          f"close: {sorted(self.names.pick_attrs)})")
        self.observed: List[str] = []

    # --- parsing helpers ---
    def _rule(self, src, what, kind="bool") -> R.Rule:
        r = R.Rule(src, self.names, what, kind)
        self.rules.append(r)
        return r

    def _window(self, d: dict, what: str) -> Tuple[int, int, int, int]:
        lo, hi = 1, self.max_sessions
        if d.get("sessions") is not None:
            s = d["sessions"]
            if isinstance(s, int):
                lo = hi = int(s)
            else:
                lo, hi = int(s[0]), int(s[1])
        if not (1 <= lo <= hi <= self.max_sessions):
            raise TLError(f"{what}: sessions [{lo}, {hi}] must lie within 1..max_sessions ({self.max_sessions})")
        tf, tu = 0, 10 ** 6
        if d.get("time") is not None:
            if self.mode != "intraday":
                raise TLError(f"{what}: a time window needs mode 'intraday'")
            tf, tu = _hhmm_to_min(d["time"][0], what), _hhmm_to_min(d["time"][1], what)
            if tu < tf:
                raise TLError(f"{what}: time window ends before it starts")
        return lo, hi, tf, tu

    def _leg(self, d: dict, i: int) -> Leg:
        what = f"entry {d.get('name', i)}"
        bad = set(d) - _LEG_KEYS
        if bad:
            raise TLError(f"{what}: unknown keys {sorted(bad)}")
        name = str(d.get("name", ""))
        if not name.isidentifier():
            raise TLError(f"{what}: name must be a plain identifier (it becomes filled_{name})")
        size = float(d.get("size", 1.0))
        if not (0 < size <= 1.0):
            raise TLError(f"{what}: size must be in (0, 1] (a fraction of the target size)")
        if d.get("tree") is not None:
            if d["tree"] is not True:
                raise TLError(f"{what}: tree must be True (buy where setuplab's entry tree bought the pick)")
            for k in ("at", "session", "when", "fill", "level", "sessions", "time", "cancel_if", "setup"):
                if d.get(k) is not None:
                    raise TLError(f"{what}: a tree entry buys at the open the entry tree chose (the D1 open or a frozen "
                                  f"setup's own day) - it takes no '{k}'")
            oi = d.get("open_if")
            if oi is not None and (not isinstance(oi, str) or not oi.strip()):
                raise TLError(f"{what}: open_if must be a rule on pick attributes, e.g. 'calm == 0 and pre_sde10 < -0.5'")
            return Leg(name, size, "open", None, None, "open", None, 1, self.max_sessions, 0, 10 ** 6, True, None, None,
                       True, oi)
        if d.get("open_if") is not None:
            raise TLError(f"{what}: open_if belongs to the tree entry ({{'name': 'tree', 'tree': True, 'open_if': ...}})")
        if d.get("setup") is not None:
            for k in ("at", "session", "when", "fill", "level", "sessions", "time", "cancel_if"):
                if d.get(k) is not None:
                    raise TLError(f"{what}: a setup entry buys at the open of the setup's own entry day (setuplab's "
                                  f"tags) - it takes no '{k}'")
            sid = str(d["setup"]).strip().upper()
            if not sid or not sid.isalnum():
                raise TLError(f"{what}: setup must be a frozen setup's id (e.g. 'S2')")
            return Leg(name, size, "open", None, None, "open", None, 1, self.max_sessions, 0, 10 ** 6, True, None, sid)
        at, when = d.get("at"), d.get("when")
        fill = d.get("fill")
        if at is not None:
            if when is not None or fill is not None:
                raise TLError(f"{what}: use either 'at' (open/close of a session) or 'when'/'fill', not both")
            if at not in ("open", "close"):
                raise TLError(f"{what}: at must be 'open' or 'close'")
            if at == "close" and not self.same_bar:
                raise TLError(f"{what}: buying at a session's close needs same_bar_close_fills: True (close entry "
                              f"was shelved for the paper test; allowed here only knowingly)")
            sess = int(d.get("session", 1))
            if not (1 <= sess <= self.max_sessions):
                raise TLError(f"{what}: session must be 1..max_sessions")
            return Leg(name, size, at, sess, None, at, None, sess, sess, 0, 10 ** 6, True, None)
        fill = str(fill or ("next_open" if when is not None else ""))
        if fill not in ("next_open", "close", "stop", "limit"):
            raise TLError(f"{what}: fill must be next_open | close | stop | limit")
        if fill == "close" and not self.same_bar:
            raise TLError(f"{what}: fill 'close' (same bar) needs same_bar_close_fills: True")
        if when is None and fill in ("next_open", "close"):
            raise TLError(f"{what}: needs 'when' (a condition) or 'at'")
        level = None
        if fill in ("stop", "limit"):
            if d.get("level") is None:
                raise TLError(f"{what}: a {fill} entry needs 'level' (a price rule)")
            level = self._rule(d["level"], f"{what}.level", "num")
        lo, hi, tf, tu = self._window(d, what)
        w = self._rule(when, f"{what}.when") if when is not None else None
        ci = self._rule(d["cancel_if"], f"{what}.cancel_if") if d.get("cancel_if") is not None else None
        return Leg(name, size, None, None, w, fill, level, lo, hi, tf, tu, True, ci)

    def _exit(self, d: dict, i: int) -> Exit:
        what = f"exit {d.get('name', i)}"
        bad = set(d) - _EXIT_KEYS
        if bad:
            raise TLError(f"{what}: unknown keys {sorted(bad)}")
        name = str(d.get("name", f"exit{i}"))
        typ = str(d.get("type", "signal" if d.get("when") is not None else ""))
        if typ not in ("time", "stop", "target", "trail", "signal"):
            raise TLError(f"{what}: type must be time | stop | target | trail | signal")
        size = float(d.get("size", 1.0))
        if not (0 < size <= 1.0):
            raise TLError(f"{what}: size must be in (0, 1] (a fraction of the position held)")
        lo, hi, tf, tu = self._window(d, what)
        once = bool(d.get("once", True))
        if typ != "time" and d.get("hold") is not None:
            raise TLError(f"{what}: 'hold' belongs to a time exit")
        if d.get("tree") is not None:
            if d["tree"] is not True or typ != "time":
                raise TLError(f"{what}: 'tree': True belongs to a time exit (the close the entry tree sells at)")
            if d.get("session") is not None or d.get("hold") is not None or d.get("at", "close") != "close":
                raise TLError(f"{what}: a tree exit sells at the close the tree chose (the 5th close; N1: 4 sessions "
                              f"after its entry) - no 'session' or 'hold'; at 'close'")
            return Exit(name, typ, size, "close", None, None, "close", None, None, None, "high", None, 1,
                        self.max_sessions, 0, 10 ** 6, True, None, True)
        if typ == "time" and d.get("hold") is not None:
            if d.get("session") is not None or d.get("at", "close") != "close":
                raise TLError(f"{what}: a hold exit sells at the close of the entry session + hold - 1 (no 'session'; "
                              f"at 'close')")
            hold = int(d["hold"])
            if not (1 <= hold <= self.max_sessions):
                raise TLError(f"{what}: hold must be 1..max_sessions ({self.max_sessions})")
            return Exit(name, typ, size, "close", None, None, "close", None, None, None, "high", None, 1,
                        self.max_sessions, 0, 10 ** 6, True, hold)
        if typ == "time":
            at = d.get("at", "close")
            if at not in ("open", "close"):
                raise TLError(f"{what}: at must be 'open' or 'close'")
            sess = int(d.get("session", self.max_sessions))
            if not (1 <= sess <= self.max_sessions):
                raise TLError(f"{what}: session {sess} is outside 1..max_sessions ({self.max_sessions}); raise "
                              f"max_sessions (e.g. 6 for an exit at the 6th open)")
            return Exit(name, typ, size, at, sess, None, at, None, None, None, "high", None, sess, sess, 0, 10 ** 6, True)
        if typ in ("stop", "target"):
            if d.get("level") is None:
                raise TLError(f"{what}: needs 'level' (a price rule, e.g. avg_entry * 0.95)")
            lv = self._rule(d["level"], f"{what}.level", "num")
            return Exit(name, typ, size, None, None, None, typ, lv, None, None, "high", None, lo, hi, tf, tu, once)
        if typ == "trail":
            pct, atr = d.get("pct"), d.get("atr")
            if (pct is None) == (atr is None):
                raise TLError(f"{what}: a trail needs exactly one of pct (e.g. 0.04) or atr (e.g. 2.0)")
            tfm = str(d.get("trail_from", "high"))
            if tfm not in ("high", "close"):
                raise TLError(f"{what}: trail_from must be high or close")
            act = self._rule(d["activate"], f"{what}.activate") if d.get("activate") is not None else None
            return Exit(name, typ, size, None, None, None, "stop", None, None if pct is None else float(pct),
                        None if atr is None else float(atr), tfm, act, lo, hi, tf, tu, once)
        if d.get("when") is None:
            raise TLError(f"{what}: a signal exit needs 'when'")
        fill = str(d.get("fill", "next_open"))
        if fill not in ("next_open", "close"):
            raise TLError(f"{what}: fill must be next_open or close")
        if fill == "close" and not self.same_bar:
            raise TLError(f"{what}: fill 'close' (same bar) needs same_bar_close_fills: True")
        w = self._rule(d["when"], f"{what}.when")
        return Exit(name, typ, size, None, None, w, fill, None, None, None, "high", None, lo, hi, tf, tu, once)

    # --- features ---
    def features_needed(self) -> List[str]:
        return sorted(self.names.unknown_features)

    def observe(self, names: Sequence[str], panel_allowed: Sequence[str] = ()) -> None:
        """Record extra values in the timeline (not traded on): built-ins, plugin values, pick attributes, features."""
        allowed = set(panel_allowed)
        for nm in names:
            if nm.startswith("label_") or (nm not in R.MARKET_VARS and nm not in R.PLUGIN_VARS and is_forbidden_name(nm)):
                raise TLError(f"--values: '{nm}' is a label or forward-looking name (firewall)")
            if nm in R.MARKET_VARS:
                if R.MARKET_VARS[nm][0] == "intraday" and self.mode == "daily":
                    raise TLError(f"--values: '{nm}' needs 3-minute bars (strategy {self.name} is daily)")
            elif nm in R.PLUGIN_VARS or nm in self.names.pick_attrs:
                pass
            elif nm in allowed:
                self.names.unknown_features.add(nm)
            else:
                raise TLError(f"--values: unknown name '{nm}'.{R.suggest(nm, set(R.MARKET_VARS) | allowed | self.names.pick_attrs)}")
            self.observed.append(nm)

    def check_features(self, allowed: Sequence[str]) -> None:
        allowed = set(allowed)
        for f in self.features_needed():
            if f not in allowed:
                raise TLError(f"strategy {self.name}: unknown name '{f}'."
                              f"{R.suggest(f, self.names.all_known() | allowed)}")

    def summary(self) -> dict:
        return {"name": self.name, "path": str(self.path) if self.path else None, "sha16": self.sha,
                "mode": self.mode, "picks": self.picks, "max_sessions": self.max_sessions,
                "warmup_sessions": self.warmup, "intrabar": self.intrabar, "same_bar_close_fills": self.same_bar,
                "costs": self.costs.describe(), "slippage_bp": self.slippage_bp,
                "entries": [{k: v for k, v in l.items()} for l in self.raw.get("entries") or
                            [{"name": "open", "size": 1.0, "at": "open", "session": 1}]],
                "exits": [x.name for x in self.exits], "events": self.events, "features": self.features_needed(),
                "setup_entries": self.setup_ids, "tree_entry": self.uses_tree,
                "tree_open_if": self.tree_open_if.src if self.tree_open_if is not None else None}


def _sha_obj(o) -> str:
    import hashlib
    return hashlib.sha256(json.dumps(o, sort_keys=True, default=str).encode()).hexdigest()[:16]


def read_strategy(path) -> Tuple[dict, Path]:
    """The STRATEGY dict of a .py / .json file (plugins it lists are loaded), without compiling its rules."""
    p = Path(path)
    if not p.exists():
        here = Path(__file__).resolve().parent / "strategies" / p.name
        if here.exists():
            p = here
        else:
            raise TLError(f"strategy file {path} not found")
    if p.suffix.lower() == ".json":
        raw = json.loads(p.read_text(encoding="utf-8"))
    elif p.suffix.lower() == ".py":
        ns = runpy.run_path(str(p), run_name="tradelab_strategy")
        if "STRATEGY" not in ns:
            raise TLError(f"{p.name} defines no STRATEGY dict")
        raw = ns["STRATEGY"]
    else:
        raise TLError(f"{p.name}: strategy files are .py (STRATEGY = {{...}}) or .json")
    if not isinstance(raw, dict):
        raise TLError(f"{p.name}: STRATEGY must be a dict")
    for pl in (raw.get("plugins") or []):
        load_plugin(pl, base=p.parent)
    return raw, p


def load_strategy(path, pick_attrs: Sequence[str] = ()) -> Strategy:
    raw, p = read_strategy(path)
    return Strategy(raw, p, pick_attrs)


def load_plugin(path, base: Optional[Path] = None) -> None:
    p = Path(path)
    cands = [p] + ([Path(base) / p] if base else []) + [Path(__file__).resolve().parent / "plugins" / p.name]
    for c in cands:
        if c.exists():
            runpy.run_path(str(c), run_name="tradelab_plugin")
            return
    raise TLError(f"plugin {path} not found")


# ======================================================================
# the bar clock of one trade
# ======================================================================
class Clock:
    """Bars of one trade: warm-up sessions, then sessions 1..last. Arrays are aligned bar by bar."""

    def __init__(self, mode: str, ds: DailySeries, sig: int):
        self.mode = mode
        self.ds = ds
        self.sig = sig
        self.o = self.h = self.l = self.c = self.v = None
        self.session = self.bis = self.minute = self.day_pos = None
        self.ts = None
        self.n = 0
        self.first_active = 0

    def finish(self) -> None:
        self.n = len(self.o)
        s = self.session
        self.is_first = np.r_[True, s[1:] != s[:-1]] if self.n else np.zeros(0, bool)
        self.is_last = np.r_[s[1:] != s[:-1], True] if self.n else np.zeros(0, bool)
        fa = np.flatnonzero(s >= 1)
        self.first_active = int(fa[0]) if len(fa) else self.n
        self.sess_first = {int(k): int(i) for i, k in zip(np.flatnonzero(self.is_first), s[self.is_first])}
        self.sess_last = {int(k): int(i) for i, k in zip(np.flatnonzero(self.is_last), s[self.is_last])}

    def truncated(self, T: int) -> "Clock":
        c = Clock(self.mode, self.ds, self.sig)
        for k in ("o", "h", "l", "c", "v", "session", "bis", "minute", "day_pos", "ts"):
            setattr(c, k, getattr(self, k)[:T + 1])
        c.finish()
        return c


def daily_clock(ds: DailySeries, sig: int, warmup: int, last_session: int) -> Clock:
    a = max(0, sig - warmup)
    b = min(len(ds) - 1, sig + last_session)
    c = Clock("daily", ds, sig)
    sl = slice(a, b + 1)
    c.o, c.h, c.l, c.c, c.v = ds.o[sl], ds.h[sl], ds.l[sl], ds.c[sl], ds.v[sl]
    c.day_pos = np.arange(a, b + 1)
    c.session = c.day_pos - sig
    c.bis = np.zeros(len(c.o), dtype=np.int64)
    c.minute = np.zeros(len(c.o), dtype=np.int64)
    c.ts = ds.dates[sl].astype("datetime64[m]") + np.timedelta64(SESSION_START_MIN, "m")
    c.finish()
    return c


def intraday_clock(ds: DailySeries, sig: int, warmup: int, last_session: int, sessions: Dict) -> Tuple[Optional[Clock], List[int]]:
    """3-minute clock; returns (clock, missing required session numbers)."""
    parts, missing = [], []
    for k in range(-warmup, last_session + 1):
        j = sig + k
        if j < 0 or j >= len(ds):
            if k >= 1:
                missing.append(k)
            continue
        s = sessions.get(ds.dates[j])
        if s is None or not s.usable:
            if k >= 1:
                missing.append(k)
            continue
        parts.append((k, j, s))
    if not parts:
        return None, missing
    c = Clock("intraday", ds, sig)
    c.o = np.concatenate([p[2].o for p in parts])
    c.h = np.concatenate([p[2].h for p in parts])
    c.l = np.concatenate([p[2].l for p in parts])
    c.c = np.concatenate([p[2].c for p in parts])
    c.v = np.concatenate([p[2].v for p in parts])
    c.session = np.concatenate([np.full(len(p[2].slot), p[0], dtype=np.int64) for p in parts])
    c.bis = np.concatenate([p[2].slot for p in parts]).astype(np.int64)
    c.minute = c.bis * BAR_MIN
    c.day_pos = np.concatenate([np.full(len(p[2].slot), p[1], dtype=np.int64) for p in parts])
    c.ts = np.concatenate([p[2].ts() for p in parts])
    c.finish()
    return c, missing


# ======================================================================
# market values of one trade (lazy)
# ======================================================================
def _daily_context(ds: DailySeries) -> None:
    """Per-series arrays cached on the series: true range ATR14 (simple mean) and the 20-session volume median."""
    if getattr(ds, "_ctx_ready", False):
        return
    c_prev = np.r_[np.nan, ds.c[:-1]]
    tr = np.fmax(ds.h - ds.l, np.fmax(np.abs(ds.h - c_prev), np.abs(ds.l - c_prev)))
    tr[0] = ds.h[0] - ds.l[0]
    ds._atr14 = pd.Series(tr).rolling(14, min_periods=14).mean().to_numpy(float)
    ds._volmed20 = pd.Series(ds.v).rolling(20, min_periods=20).median().to_numpy(float)
    ds._ctx_ready = True


class DailyView:
    """Daily bars for a plugin, cut at the last bar a rule at the clock's end may know."""

    def __init__(self, ds: DailySeries, last: int):
        sl = slice(0, max(0, last + 1))
        self.dates, self.o, self.h, self.l, self.c, self.v = (ds.dates[sl], ds.o[sl], ds.h[sl], ds.l[sl], ds.c[sl],
                                                             ds.v[sl])


class Vars:
    """Lazy market values for a clock (built-ins, pick attributes, panel features, plugins)."""

    def __init__(self, clock: Clock, market: Market, pick: dict, strat: Strategy,
                 feats: Optional[Dict[np.datetime64, Dict[str, float]]], nifty3: Optional[Dict]):
        self.k = clock
        self.m = market
        self.pick = pick
        self.s = strat
        self.feats = feats or {}
        self.nifty3 = nifty3
        self.cache: Dict[str, np.ndarray] = {}
        _daily_context(clock.ds)
        last_known = int(clock.day_pos[-1]) - (1 if clock.mode == "intraday" else 0) if clock.n else -1
        self.ctx = R.Ctx(clock.n, clock.session, clock.bis, clock.first_active,
                         {"open": clock.o, "high": clock.h, "low": clock.l, "close": clock.c, "volume": clock.v},
                         getter=self.get, daily=DailyView(clock.ds, last_known), day_pos=clock.day_pos)

    def known_day(self) -> np.ndarray:
        """Daily position of the last COMPLETED session at each bar (intraday: previous day; daily: this day)."""
        return self.k.day_pos - (1 if self.k.mode == "intraday" else 0)

    def get(self, name: str) -> np.ndarray:
        v = self.cache.get(name)
        if v is None:
            v = self._compute(name)
            if np.ndim(v) == 0:
                v = np.full(self.k.n, float(v))
            self.cache[name] = v
        return v

    def _d(self, arr: np.ndarray, pos: np.ndarray) -> np.ndarray:
        out = np.full(len(pos), np.nan)
        ok = (pos >= 0) & (pos < len(arr))
        out[ok] = arr[pos[ok]]
        return out

    def _compute(self, nm: str):
        k, ds = self.k, self.k.ds
        o, h, l, c, v = k.o, k.h, k.l, k.c, k.v
        g = self.get
        if nm == "open":
            return o
        if nm == "high":
            return h
        if nm == "low":
            return l
        if nm == "close":
            return c
        if nm == "volume":
            return v
        if nm == "typical":
            return (h + l + c) / 3.0
        if nm == "hl_range":
            return h - l
        if nm == "body":
            return c - o
        if nm == "upper_wick":
            return h - np.maximum(o, c)
        if nm == "lower_wick":
            return np.minimum(o, c) - l
        if nm == "clv":
            rng = h - l
            with np.errstate(divide="ignore", invalid="ignore"):
                return np.where(rng > 0, (c - l) / rng, 0.5)
        if nm == "bar_ret":
            with np.errstate(divide="ignore", invalid="ignore"):
                return c / np.r_[np.nan, c[:-1]] - 1.0
        if nm == "session":
            return k.session.astype(float)
        if nm == "bar_in_session":
            return k.bis.astype(float)
        if nm == "minute":
            return k.minute.astype(float)
        if nm == "hhmm":
            t = SESSION_START_MIN + k.minute
            return (t // 60 * 100 + t % 60).astype(float)
        if nm == "is_first_bar":
            return k.is_first.astype(float)
        if nm == "is_last_bar":
            return k.is_last.astype(float)
        if nm == "weekday":
            d = ds.dates[k.day_pos].astype("datetime64[D]").astype(np.int64)
            return ((d + 3) % 7).astype(float)
        if nm == "sessions_left":
            return (self.s.max_sessions - k.session).astype(float)
        if nm == "vwap":
            tp = g("typical")
            out = np.empty(k.n)
            pv = pd.Series(tp * v).groupby(k.session).cumsum().to_numpy(float)
            vv = pd.Series(v).groupby(k.session).cumsum().to_numpy(float)
            with np.errstate(divide="ignore", invalid="ignore"):
                out[:] = np.where(vv > 0, pv / vv, tp)
            return out
        if nm == "session_open":
            return self._d(ds.o, k.day_pos)
        if nm == "session_high":
            return h if k.mode == "daily" else pd.Series(h).groupby(k.session).cummax().to_numpy(float)
        if nm == "session_low":
            return l if k.mode == "daily" else pd.Series(l).groupby(k.session).cummin().to_numpy(float)
        if nm == "session_volume":
            return v if k.mode == "daily" else pd.Series(v).groupby(k.session).cumsum().to_numpy(float)
        if nm in ("prev_close", "prev_open", "prev_high", "prev_low", "prev_volume"):
            arr = {"prev_close": ds.c, "prev_open": ds.o, "prev_high": ds.h, "prev_low": ds.l, "prev_volume": ds.v}[nm]
            return self._d(arr, k.day_pos - 1)
        if nm == "day_ret":
            with np.errstate(divide="ignore", invalid="ignore"):
                return c / g("prev_close") - 1.0
        if nm == "gap":
            with np.errstate(divide="ignore", invalid="ignore"):
                return g("session_open") / g("prev_close") - 1.0
        if nm == "dist_prev_high":
            with np.errstate(divide="ignore", invalid="ignore"):
                return c / g("prev_high") - 1.0
        if nm == "dist_prev_low":
            with np.errstate(divide="ignore", invalid="ignore"):
                return c / g("prev_low") - 1.0
        if nm == "entry_open":            # known from session 1's open on, never before
            v = float(ds.o[k.sig + 1]) if k.sig + 1 < len(ds) else np.nan
            return np.where(k.session >= 1, v, np.nan)
        if nm == "signal_close":
            return float(ds.c[k.sig])
        if nm == "ret_vs_entry_open":
            with np.errstate(divide="ignore", invalid="ignore"):
                return c / g("entry_open") - 1.0
        if nm == "atr14":
            return self._d(ds._atr14, self.known_day())
        if nm == "atr14_pct":
            with np.errstate(divide="ignore", invalid="ignore"):
                return g("atr14") / self._d(ds.c, self.known_day())
        if nm == "vol_med20":
            return self._d(ds._volmed20, self.known_day())
        if nm == "rvol":
            with np.errstate(divide="ignore", invalid="ignore"):
                return g("session_volume") / g("vol_med20")
        if nm in ("nifty", "nifty_day_ret", "rel_nifty_day", "nifty_ret5"):
            return self._nifty(nm)
        if nm in R.CONTEXT_VARS:
            return self._context(nm)
        if nm in R.PLUGIN_VARS:
            fn = R.PLUGIN_VARS[nm][0]
            out = np.asarray(fn(self.ctx), dtype=float)
            if out.shape != (k.n,):
                raise R.RuleError(f"plugin value {nm} returned shape {out.shape}, expected ({k.n},)")
            return out
        if nm in self.s.names.pick_attrs:
            x = self.pick.get(nm, np.nan)
            try:
                return float(x)
            except (TypeError, ValueError):
                return np.nan
        if nm in self.s.names.unknown_features:
            kd = self.known_day()
            out = np.full(k.n, np.nan)
            for i in range(k.n):
                j = kd[i]
                if 0 <= j < len(ds):
                    row = self.feats.get(ds.dates[j])
                    if row is not None:
                        out[i] = row.get(nm, np.nan)
            return out
        raise R.RuleError(f"no value '{nm}'")

    def _nifty(self, nm: str):
        k, ds = self.k, self.k.ds
        N = self.m.daily["NIFTY50"]
        # NIFTY daily position of each bar's day
        npos = np.array([N.idx(d) for d in ds.dates[k.day_pos]], dtype=np.int64)
        nprev = np.where(npos > 0, npos - 1, -1)
        if nm == "nifty":
            if k.mode == "intraday" and self.nifty3 is not None:
                return self._nifty3()
            if k.mode == "intraday":
                return self._d(N.c, nprev)      # the last completed NIFTY close
            return self._d(N.c, npos)
        if nm == "nifty_day_ret":
            with np.errstate(divide="ignore", invalid="ignore"):
                if k.mode == "intraday":
                    if self.nifty3 is None:
                        return np.full(k.n, np.nan)
                    return self._nifty3() / self._d(N.c, nprev) - 1.0
                return self._d(N.c, npos) / self._d(N.c, nprev) - 1.0
        if nm == "rel_nifty_day":
            return self.get("day_ret") - self.get("nifty_day_ret")
        if nm == "nifty_ret5":
            kn = nprev if k.mode == "intraday" else npos
            with np.errstate(divide="ignore", invalid="ignore"):
                return self._d(N.c, kn) / self._d(N.c, np.where(kn >= 5, kn - 5, -1)) - 1.0
        raise R.RuleError(nm)

    def _context(self, nm: str) -> np.ndarray:
        """v1.1 market context by the bar's day (tl_context); see tl_rules.CONTEXT_VARS for the timing."""
        import tl_context as C
        ctx = C.light_context(self.m)
        k = self.k
        p = ctx.ib.pos(k.ds.dates[k.day_pos])
        prev = np.where(p > 0, p - 1, -1)
        if nm.endswith("_day_ret"):
            if k.mode == "intraday":
                return np.full(k.n, np.nan)
            return ctx.fcol(nm[:-len("_day_ret")] + "_ret", p).astype(float)
        if nm.endswith("_prev_ret"):
            return ctx.fcol(nm[:-len("_prev_ret")] + "_ret", prev).astype(float)
        q = p if k.mode == "daily" else prev
        return ctx.fcol(nm, q).astype(float)

    def _nifty3(self) -> np.ndarray:
        k = self.k
        out = np.full(k.n, np.nan)
        dates = k.ds.dates[k.day_pos]
        for i in range(k.n):
            s = self.nifty3.get(dates[i])
            if s is not None:
                j = np.searchsorted(s.slot, k.bis[i])
                if j < len(s.slot) and s.slot[j] == k.bis[i]:
                    out[i] = s.c[j]
        return out

    def env(self, names: Sequence[str]) -> dict:
        e = {"__builtins__": {}, **R.BASE_NS, **R.series_namespace(self.ctx)}
        for nm in names:
            e[nm] = self.get(nm)
        return e


# ======================================================================
# results
# ======================================================================
@dataclass
class Fill:
    leg: str
    side: str           # buy / sell
    bar: int            # clock bar (-1 = after the clock, honest exit in the daily domain)
    session: int
    when: str           # timestamp text
    price: float        # fill price after slippage
    raw: float          # market price before slippage
    frac: float         # buy: fraction of the target bought; sell: fraction of the position sold
    notional: float     # buy: value bought (target = 1.0); sell: value received
    basis: float        # sell: entry notional of the shares sold
    cost: float
    kind: str           # open / close / next_open / stop / limit / target / trail / locked_open
    reason: str
    ts: Any = None      # numpy datetime64[m]: sortable time (open = bar start, inside = +1 min, close = bar end)


@dataclass
class TradeResult:
    pick: dict
    strategy: str
    status: str
    note: str = ""
    fills: List[Fill] = field(default_factory=list)
    path: List[dict] = field(default_factory=list)
    timeline: Optional[pd.DataFrame] = None
    net: float = float("nan")              # net P&L / target size
    gross: float = float("nan")
    costs: float = float("nan")
    deployed: float = 0.0                  # total bought (target = 1.0)
    max_pos: float = 0.0
    first_entry: float = float("nan")
    avg_entry: float = float("nan")
    exit_price: float = float("nan")       # last sale price
    exit_reason: str = ""
    entry_session: int = 0
    exit_session: int = 0
    entry_time: str = ""
    exit_time: str = ""
    bars_held: int = 0
    mfe: float = float("nan")              # best high since the first buy / first_entry - 1 (to the exit)
    mae: float = float("nan")
    mfe_session: int = 0
    mae_session: int = 0
    locked_exit: bool = False
    ambiguous_bars: int = 0
    events_first: Dict[str, str] = field(default_factory=dict)

    @property
    def net_deployed(self) -> float:
        return self.net / self.deployed if self.deployed > 0 else float("nan")

    def row(self) -> dict:
        p = self.pick
        r = {"trade_id": p.get("trade_id"), "engine": p.get("engine"), "signal_day": p.get("signal_day"),
             "symbol": p.get("symbol"), "rank": p.get("rank"), "strategy": self.strategy, "status": self.status,
             "note": self.note, "entered": self.deployed > 0, "deployed": self.deployed, "max_pos": self.max_pos,
             "first_entry": self.first_entry, "avg_entry": self.avg_entry, "exit_price": self.exit_price,
             "exit_reason": self.exit_reason, "entry_session": self.entry_session, "exit_session": self.exit_session,
             "entry_time": self.entry_time, "exit_time": self.exit_time, "bars_held": self.bars_held,
             "gross": self.gross, "costs": self.costs, "net": self.net, "net_bp": self.net * 1e4,
             "net_deployed_bp": self.net_deployed * 1e4, "win": (self.net > 0) if np.isfinite(self.net) else np.nan,
             "mfe": self.mfe, "mae": self.mae, "mfe_session": self.mfe_session, "mae_session": self.mae_session,
             "locked_exit": self.locked_exit, "ambiguous_bars": self.ambiguous_bars, "n_fills": len(self.fills),
             "legs_filled": ";".join(dict.fromkeys(f.leg for f in self.fills if f.side == "buy")),
             "exits_used": ";".join(dict.fromkeys(f.leg for f in self.fills if f.side == "sell"))}
        for k, v in self.events_first.items():
            r[f"ev_{k}"] = v
        return r


# ======================================================================
# the simulator
# ======================================================================
class _Book:
    """Position accounting against a target size of 1.0 (average cost)."""

    def __init__(self, costs: CostModel, slip_bp: float):
        self.cm = costs
        self.slip = slip_bp / 1e4
        self.Q = 0.0           # shares (units of 1 / price)
        self.basis = 0.0       # entry notional of the shares held
        self.realized = 0.0    # gross realized P&L
        self.costs = 0.0
        self.bought = 0.0
        self.first = float("nan")
        self.max_pos = 0.0

    def buy(self, size: float, raw: float) -> Tuple[float, float, float]:
        px = raw * (1 + self.slip)
        self.Q += size / px
        self.basis += size
        self.bought += size
        c = self.cm.buy(size)
        self.costs += c
        if not np.isfinite(self.first):
            self.first = px
        self.max_pos = max(self.max_pos, self.basis)
        return px, size, c

    def sell(self, frac: float, raw: float) -> Tuple[float, float, float, float]:
        px = raw * (1 - self.slip)
        q = self.Q * frac
        basis = self.basis * frac
        proceeds = q * px
        self.Q -= q
        self.basis -= basis
        if self.Q < 1e-15:
            self.Q, self.basis = 0.0, 0.0
        self.realized += proceeds - basis
        c = self.cm.sell(proceeds, basis)
        self.costs += c
        return px, proceeds, basis, c

    @property
    def avg(self) -> float:
        return self.basis / self.Q if self.Q > 0 else float("nan")

    def mtm(self, price: float) -> float:
        """Net P&L so far if marked at `price` (costs paid so far included)."""
        return self.realized + (self.Q * price - self.basis if self.Q > 0 else 0.0) - self.costs


class TradeSim:
    """Simulates one strategy on many picks. Build once per run; call run(pick)."""

    def __init__(self, strat: Strategy, market: Market, features: Optional[Dict] = None,
                 intraday_cache: Optional[Dict] = None, nifty3: Optional[Dict] = None, pit_checks: int = 3):
        self.s = strat
        self.m = market
        self.features = features or {}           # (symbol, day) -> {feature: value}
        self.intraday_cache = intraday_cache     # symbol -> {day: Session}
        self.nifty3 = nifty3
        self.pit_left = pit_checks if R.PLUGIN_VARS or R.PLUGIN_FUNCS else 0
        rules = strat.rules + list(strat.event_rules.values()) + ([strat.filter] if strat.filter else [])
        self.used_names = sorted({nm for r in rules for nm in r.used if nm not in strat.names.state}
                                 | set(strat.observed))

    # ----- helpers -----
    def _status(self, pick, status, note="") -> TradeResult:
        return TradeResult(pick=pick, strategy=self.s.name, status=status, note=note)

    @staticmethod
    def _ts(k: Clock, t: int) -> str:
        if t < 0 or t >= k.n:
            return ""
        x = pd.Timestamp(k.ts[t])
        return f"{x:%Y-%m-%d}" if k.mode == "daily" else f"{x:%Y-%m-%d %H:%M}"

    def tree_plan(self, pick: dict) -> dict:
        """setups add-on v1.4: the tree's schedule for this pick - setuplab's (pick['_tree']), or the D1 open and the 5th
        close when the tree entry's open_if holds for a tree pick that is not an ETF."""
        tr = pick.get("_tree") or {}
        f = self.s.tree_open_if
        if f is None or not tr.get("tagged") or tr.get("etf"):
            return tr
        env = {"__builtins__": {}, **R.BASE_NS}
        for nm in f.picks:
            try:
                env[nm] = float(pick.get(nm, np.nan))
            except (TypeError, ValueError):
                env[nm] = np.nan
        if bool(np.asarray(R._b(eval(f.code, env))).item()):
            return dict(tr, day=1, exit=5, how=f"open (open_if: {f.src})")
        return tr

    def filter_ok(self, pick: dict) -> bool:
        f = self.s.filter
        if f is None:
            return True
        env = {"__builtins__": {}, **R.BASE_NS}
        for nm in f.picks:
            try:
                env[nm] = float(pick.get(nm, np.nan))
            except (TypeError, ValueError):
                env[nm] = np.nan
        return bool(np.asarray(R._b(eval(f.code, env))).item())

    def prepare(self, pick: dict):
        """(clock, Vars) for a pick, or a TradeResult explaining why it cannot be simulated."""
        s, m = self.s, self.m
        if not self.filter_ok(pick):
            r = self._status(pick, "filtered", f"picks.filter false: {s.filter.src}")
            r.net = r.gross = r.costs = 0.0          # a skipped pick is a slot left in cash: 0 bp
            return r
        ds = m.series(pick["symbol"])
        if ds is None:
            return self._status(pick, "no_bars", "no daily bars in the cache")
        sday = np.datetime64(pick["signal_day"], "D")
        sig = ds.idx(sday)
        if sig < 0:
            return self._status(pick, "no_signal_bar", "no bar on the signal day")
        nxt = m.next_session(sday)
        if nxt is None:
            return self._status(pick, "pending", "no session after the signal day yet")
        if ds.idx(nxt) != sig + 1:
            return self._status(pick, "no_entry_bar", f"no bar on the entry session {nxt}")
        last_needed = s.max_sessions if s.open_cut is None else s.open_cut
        if sig + last_needed >= len(ds):
            return self._status(pick, "pending", f"data ends before session {last_needed}")
        if s.mode == "daily":
            clock = daily_clock(ds, sig, s.warmup, s.max_sessions)
        else:
            if self.intraday_cache is None:
                raise TLError("intraday mode needs 3-minute sessions (internal: no intraday cache given)")
            sess = self.intraday_cache.get(pick["symbol"], {})
            last_s = s.required_sessions[-1]
            clock, missing = intraday_clock(ds, sig, s.warmup, last_s, sess)
            miss_req = [kk for kk in missing if kk in s.required_sessions]
            if clock is None or miss_req:
                return self._status(pick, "no_intraday", f"no usable 3-minute bars for session(s) {miss_req}")
        feats = {}
        if s.features_needed():
            sym = pick["symbol"]
            for jj in range(max(0, int(clock.day_pos[0]) - 1), int(clock.day_pos[-1]) + 1):
                row = self.features.get((sym, ds.dates[jj]))
                if row is not None:
                    feats[ds.dates[jj]] = row
        V = Vars(clock, m, pick, s, feats, self.nifty3)
        if self.pit_left > 0 and clock.n >= 10:
            self._pit_check(V, clock, pick, feats)
        return clock, V

    def run(self, pick: dict, timeline: bool = False) -> TradeResult:
        p = self.prepare(pick)
        if isinstance(p, TradeResult):
            return p
        clock, V = p
        return self._simulate(pick, clock, V, timeline)

    def _pit_check(self, V: Vars, clock: Clock, pick: dict, feats) -> None:
        """Plugins: values up to bar T must not change when the bars after T are removed."""
        self.pit_left -= 1
        for T in sorted({clock.n // 3, clock.n // 2, (2 * clock.n) // 3}):
            ct = clock.truncated(T)
            Vt = Vars(ct, self.m, pick, self.s, feats, self.nifty3)
            for nm in R.PLUGIN_VARS:
                full = V.get(nm)[:T + 1]
                try:
                    part = Vt.get(nm)
                except Exception as e:
                    raise R.RuleError(f"plugin value '{nm}' fails when the bars after the current one are removed "
                                      f"({type(e).__name__}: {e}) - it reads data that is not known yet") from None
                _same_or_raise(full, part, f"plugin value '{nm}'", T, pick)
            for nm, (fn, lo, hi, _) in R.PLUGIN_FUNCS.items():
                x = clock.c
                args = [x] + [5] * (lo - 1)
                try:
                    full = np.asarray(fn(*args), float)[:T + 1]
                    part = np.asarray(fn(*([x[:T + 1]] + args[1:])), float)
                except Exception as e:
                    raise R.RuleError(f"plugin function '{nm}' failed the look-ahead check ({e})") from None
                _same_or_raise(full, part, f"plugin function '{nm}'", T, pick)

    # ----- the bar loop -----
    def _simulate(self, pick: dict, k: Clock, V: Vars, timeline: bool) -> TradeResult:
        s = self.s
        n = k.n
        ds = k.ds
        env = V.env(self.used_names)
        vec: Dict[int, np.ndarray] = {}
        pre: Dict[int, List[Tuple[str, np.ndarray]]] = {}
        for r in s.rules:
            if r.stateful:
                pre[id(r)] = r.prepare(env, n)
            else:
                vec[id(r)] = r.vector(env, n)
        evv = {nm: r.vector(env, n) for nm, r in s.event_rules.items() if not r.stateful}
        tplan = self.tree_plan(pick) if s.uses_tree else {}
        book = _Book(s.costs, s.slippage_bp)
        res = TradeResult(pick=pick, strategy=s.name, status="ok")
        legs = {l.name: {"filled": False, "cancelled": False, "armed": False, "level": np.nan} for l in s.legs}
        exs = {x.name: {"done": False, "active": False, "hh": -np.inf, "level": np.nan} for x in s.exits}
        pending: List[Tuple[str, Any, float, str]] = []      # (side, spec, size, reason) for the next bar's open
        closed = False
        honest_after: Optional[Tuple[int, str]] = None        # (daily position, reason)
        st = {"pos": 0.0, "in_pos": 0.0, "avg_entry": np.nan, "first_entry": np.nan, "upnl": np.nan,
              "upnl_first": np.nan, "mfe_sofar": np.nan, "mae_sofar": np.nan, "peak_close": np.nan,
              "bars_in_trade": np.nan, "sessions_in_trade": np.nan, "legs_filled": 0.0, "exits_done": 0.0,
              "realized": 0.0}
        for l in s.legs:
            st[f"filled_{l.name}"] = 0.0
        first_bar = first_sess = None
        ext = {"hi": -np.inf, "lo": np.inf, "hi_s": 0, "lo_s": 0}
        tl_rows: List[dict] = []
        snaps: Dict[int, dict] = {}
        ev_first: Dict[str, str] = {}
        fills_bar: List[Fill] = []

        def touch(px: float, sess: int) -> None:
            if px > ext["hi"]:
                ext["hi"], ext["hi_s"] = float(px), sess
            if px < ext["lo"]:
                ext["lo"], ext["lo_s"] = float(px), sess

        def ns_for(r: R.Rule, t: int) -> dict:
            d = {"__builtins__": {}, **R.BASE_NS}
            for nm, arr in pre[id(r)]:
                d[nm] = arr[t]
            d.update(st)
            return d

        def val(r: R.Rule, t: int):
            if r.stateful:
                return r.scalar(ns_for(r, t))
            x = vec[id(r)][t]
            return bool(x) if r.kind == "bool" else float(x)

        def in_window(spec, t: int) -> bool:
            if t < 0 or t >= n:
                return False
            sess = int(k.session[t])
            return spec.lo <= sess <= spec.hi and spec.t_from <= k.minute[t] <= spec.t_until

        def refresh(price: float) -> None:
            st["pos"] = book.basis
            st["in_pos"] = 1.0 if book.Q > 0 else 0.0
            st["avg_entry"] = book.avg
            st["first_entry"] = book.first
            st["upnl"] = price / book.avg - 1 if book.Q > 0 else np.nan
            st["upnl_first"] = price / book.first - 1 if np.isfinite(book.first) else np.nan
            st["realized"] = book.realized

        def do_buy(leg: Leg, t: int, raw: float, kind: str, reason: str) -> None:
            nonlocal first_bar, first_sess
            size = min(leg.size, 1.0 - book.basis)
            if size <= 1e-12:                      # the position is already at the target size
                legs[leg.name]["cancelled"] = True
                legs[leg.name]["armed"] = False
                return
            if size < leg.size - 1e-12:
                reason += f" (clipped to {size:.0%}: the position may not exceed the target)"
            px, notional, c = book.buy(size, raw)
            f = Fill(leg.name, "buy", t, int(k.session[t]), self._ts(k, t), px, raw, size, notional, 0.0, c,
                     kind, reason, fill_time(k, t, kind))
            res.fills.append(f)
            fills_bar.append(f)
            legs[leg.name]["filled"] = True
            legs[leg.name]["armed"] = False
            st[f"filled_{leg.name}"] = 1.0
            st["legs_filled"] += 1
            if first_bar is None:
                first_bar, first_sess = t, int(k.session[t])

        def do_sell(name: str, frac: float, t: int, raw: float, kind: str, reason: str, sess=None, when=None) -> None:
            if book.Q <= 0:
                return
            px, proceeds, basis, c = book.sell(frac, raw)
            f = Fill(name, "sell", t, int(k.session[t]) if sess is None else int(sess),
                     self._ts(k, t) if when is None else when, px, raw, frac, proceeds, basis, c, kind, reason,
                     fill_time(k, t, kind, day=when))
            res.fills.append(f)
            fills_bar.append(f)
            st["exits_done"] += 1

        def blocked(t: int, at_open: bool) -> bool:
            """Can nothing be sold here? Daily: a locked open / a frozen day. 3-minute: a flat bar on the lower band."""
            j = int(k.day_pos[t])
            if k.mode == "daily":
                return ds.locked(j, "open") if at_open else ds.frozen(j)
            if at_open and k.is_first[t]:
                return ds.locked(j, "open")
            if not ds.locked(j, "close"):
                return False
            return bool(k.o[t] == k.h[t] == k.l[t] == k.c[t]) and k.l[t] <= ds.l[j] * (1 + 1e-9)

        def exit_level(x: Exit, t: int) -> float:
            if x.type == "trail":
                return exs[x.name]["level"] if exs[x.name]["active"] else np.nan
            if t - 1 < 0:
                return np.nan
            if x.level.stateful:
                return x.level.scalar(ns_for(x.level, t - 1))
            return float(vec[id(x.level)][t - 1])

        for t in range(n):
            fills_bar = []
            sess = int(k.session[t])
            j = int(k.day_pos[t])
            fos, los = bool(k.is_first[t]), bool(k.is_last[t])
            amb = False
            held_open = False
            sold_intrabar: List[float] = []
            bought_intrabar: List[float] = []
            sold_at_close = False
            if sess >= 1 and not closed:
                # ---------------- A. the open: sells first, then buys ----------------
                off_open = float(ds.o[j]) if fos else float(k.o[t])
                keep = []
                for side, spec, size, reason in pending:
                    if side != "sell":
                        continue
                    if book.Q <= 0:
                        continue
                    if blocked(t, at_open=True):
                        keep.append((side, spec, size, reason))
                        continue
                    do_sell(spec.name, size, t, off_open, "next_open", reason)
                    if spec.once:
                        exs[spec.name]["done"] = True
                if fos:
                    for x in s.exits:
                        if x.type == "time" and x.at == "open" and x.session == sess and not exs[x.name]["done"]:
                            exs[x.name]["done"] = True
                            if book.Q > 0:
                                if ds.locked(j, "open"):
                                    if x.size >= 1.0 - 1e-12:
                                        honest_after = (j, f"{x.name}: open locked at the lower band")
                                        res.locked_exit = True
                                else:
                                    do_sell(x.name, x.size, t, off_open, "open", f"time exit at the session {sess} open")
                if res.fills and book.Q == 0 and not s.reentry:
                    closed = True
                if honest_after is not None:
                    closed = True
                if not closed:
                    for side, spec, size, reason in pending:
                        if side == "buy" and not legs[spec.name]["filled"] and not legs[spec.name]["cancelled"]:
                            do_buy(spec, t, off_open, "next_open", reason)
                    if fos:
                        sdays = pick.get("_setup_days") or {}
                        tr = tplan
                        for l in s.legs:
                            if l.tree:
                                if tr.get("day") == sess and not legs[l.name]["filled"]:
                                    do_buy(l, t, off_open, "open", f"entry tree: {tr.get('how')} (D{sess} open)")
                            elif l.setup is not None:
                                if sdays.get(l.setup) == sess and not legs[l.name]["filled"]:
                                    do_buy(l, t, off_open, "open", f"setup {l.setup}: its entry day (D{sess}) open")
                            elif l.at == "open" and l.session == sess and not legs[l.name]["filled"]:
                                do_buy(l, t, off_open, "open", f"at the session {sess} open")
                pending = keep
                held_open = book.Q > 0
                if any(f.side == "buy" for f in fills_bar):
                    refresh(off_open)
                # ---------------- B. inside the bar: exits on what was held from the open, then entries ------
                if held_open and not closed and not blocked(t, at_open=False):
                    stops, targets = [], []
                    for x in s.exits:
                        if x.type not in ("stop", "target", "trail") or exs[x.name]["done"] or not in_window(x, t):
                            continue
                        L = exit_level(x, t)
                        if not np.isfinite(L):
                            continue
                        if x.type == "target":
                            if k.h[t] >= L:
                                targets.append((L, x))
                        elif k.l[t] <= L:
                            stops.append((L, x))
                    stops.sort(key=lambda z: -z[0])
                    targets.sort(key=lambda z: z[0])
                    if stops and targets:
                        if k.o[t] <= stops[0][0]:
                            order = stops + targets
                        elif k.o[t] >= targets[0][0]:
                            order = targets + stops
                        else:
                            amb = True
                            res.ambiguous_bars += 1
                            first = s.intrabar
                            if first == "intraday":
                                first = self._resolve_by_3m(pick["symbol"], ds, j, stops[0][0], targets[0][0])
                            order = stops + targets if first in ("worst", "stop") else targets + stops
                    else:
                        order = stops + targets
                    for L, x in order:
                        if book.Q <= 0:
                            break
                        if x.type == "target":
                            raw = k.o[t] if k.o[t] >= L else L
                        else:
                            raw = k.o[t] if k.o[t] <= L else L
                        do_sell(x.name, x.size, t, float(raw), x.type, f"{x.type} at {L:.4f}")
                        sold_intrabar.append(float(raw))
                        if x.once:
                            exs[x.name]["done"] = True
                    if res.fills and book.Q == 0 and not s.reentry:
                        closed = True
                if not closed:
                    for l in s.legs:
                        if l.fill not in ("stop", "limit") or legs[l.name]["filled"] or legs[l.name]["cancelled"]:
                            continue
                        if not legs[l.name]["armed"] or not in_window(l, t):
                            continue
                        L = legs[l.name]["level"]
                        if not np.isfinite(L):
                            continue
                        if l.fill == "stop" and k.h[t] >= L:
                            raw = k.o[t] if k.o[t] >= L else L
                            do_buy(l, t, float(raw), "stop", f"buy stop at {L:.4f}")
                            bought_intrabar.append(float(raw))
                        elif l.fill == "limit" and k.l[t] <= L:
                            raw = k.o[t] if k.o[t] <= L else L
                            do_buy(l, t, float(raw), "limit", f"buy limit at {L:.4f}")
                            bought_intrabar.append(float(raw))
                # ---------------- C. the close ----------------
                c_off = float(ds.c[j]) if los else float(k.c[t])
                if los:
                    for x in s.exits:
                        xs = (tplan.get("exit") if x.tree else x.session if x.hold is None else
                              (first_sess + x.hold - 1 if first_sess is not None else None))
                        if x.type == "time" and x.at == "close" and xs == sess and not exs[x.name]["done"]:
                            exs[x.name]["done"] = True
                            if book.Q > 0 and honest_after is None:
                                if ds.locked(j, "close"):
                                    if x.size >= 1.0 - 1e-12:
                                        honest_after = (j, f"{x.name}: close locked at the lower band")
                                        res.locked_exit = True
                                        closed = True
                                else:
                                    do_sell(x.name, x.size, t, c_off, "close", f"time exit at the session {sess} close")
                                    sold_at_close = True
                    if not closed:
                        for l in s.legs:
                            if l.at == "close" and l.session == sess and not legs[l.name]["filled"]:
                                do_buy(l, t, c_off, "close", f"at the session {sess} close")
                                bought_intrabar.append(c_off)
                    if sess >= s.max_sessions:
                        closed = True
                if res.fills and book.Q == 0 and not s.reentry:
                    closed = True
            # ---------------- D. best / worst prices while held ----------------
            if sess >= 1:
                if held_open:
                    if sold_intrabar and book.Q == 0 and not sold_at_close:
                        touch(float(k.o[t]), sess)
                        for px in sold_intrabar:
                            touch(px, sess)
                    else:
                        touch(float(k.h[t]), sess)
                        touch(float(k.l[t]), sess)
                elif bought_intrabar:
                    for px in bought_intrabar:
                        touch(px, sess)
                    if book.Q > 0:
                        touch(float(k.c[t]), sess)
            # ---------------- E. state at the close ----------------
            price = float(ds.c[j]) if (los and sess >= 1) else float(k.c[t])
            refresh(price)
            if first_bar is not None:
                st["bars_in_trade"] = float(t - first_bar)
                st["sessions_in_trade"] = float(sess - first_sess)
                fe = book.first
                st["mfe_sofar"] = ext["hi"] / fe - 1 if np.isfinite(ext["hi"]) else np.nan
                st["mae_sofar"] = ext["lo"] / fe - 1 if np.isfinite(ext["lo"]) else np.nan
                if book.Q > 0:
                    st["peak_close"] = price if not np.isfinite(st["peak_close"]) else max(st["peak_close"], price)
            # ---------------- F. decisions for the next bar ----------------
            if not closed and honest_after is None and t >= k.first_active - 1 and t + 1 < n:
                # trailing stops: the reference is the highest high (or close) since the first buy; the stop
                # becomes live once 'activate' is true and then trails pct (or atr x ATR14) under that reference
                for x in s.exits:
                    if x.type != "trail" or exs[x.name]["done"]:
                        continue
                    ex = exs[x.name]
                    if book.Q <= 0:
                        continue
                    if held_open:
                        ref = k.h[t] if x.trail_from == "high" else k.c[t]
                    else:
                        ref = max(bought_intrabar + [float(k.c[t])]) if x.trail_from == "high" else float(k.c[t])
                    ex["hh"] = max(ex["hh"], float(ref))
                    if not ex["active"] and (x.activate is None or val(x.activate, t)):
                        ex["active"] = True
                    if ex["active"]:
                        if x.pct is not None:
                            ex["level"] = ex["hh"] * (1 - x.pct)
                        else:
                            a = V.get("atr14")[t]
                            ex["level"] = ex["hh"] - x.atr * a if np.isfinite(a) else np.nan
                # signal exits: checked at this close, sold at the next bar's open (or this close)
                if book.Q > 0:
                    for x in s.exits:
                        if x.type != "signal" or exs[x.name]["done"]:
                            continue
                        if x.fill == "close":
                            if in_window(x, t) and val(x.when, t) and not blocked(t, at_open=False):
                                do_sell(x.name, x.size, t, price, "close", f"signal {x.when.src}")
                                if x.once:
                                    exs[x.name]["done"] = True
                            continue
                        if any(p_[1] is x for p_ in pending):
                            continue
                        if in_window(x, t + 1) and val(x.when, t):
                            pending.append(("sell", x, x.size, f"signal {x.when.src}"))
                    if res.fills and book.Q == 0 and not s.reentry:
                        closed = True
                # conditional entries
                if not closed:
                    for l in s.legs:
                        L_ = legs[l.name]
                        if l.at is not None or L_["filled"] or L_["cancelled"]:
                            continue
                        if l.cancel_if is not None and val(l.cancel_if, t):
                            L_["cancelled"], L_["armed"] = True, False
                            continue
                        if l.fill == "close":
                            if in_window(l, t) and val(l.when, t):
                                do_buy(l, t, price, "close", f"signal {l.when.src}")
                            continue
                        if l.fill == "next_open":
                            if any(p_[1] is l for p_ in pending):
                                continue
                            if in_window(l, t + 1) and val(l.when, t):
                                pending.append(("buy", l, l.size, f"signal {l.when.src}"))
                            continue
                        # stop / limit: resting during the next bar if armed now and the next bar is in the window
                        armed = in_window(l, t + 1) and (l.when is None or val(l.when, t))
                        L_["armed"] = bool(armed)
                        L_["level"] = val(l.level, t) if armed else np.nan
            # ---------------- G. records ----------------
            if los:
                snaps[sess] = {"pos": book.basis, "avg_entry": book.avg, "mtm_net": book.mtm(price),
                               "realized": book.realized, "costs_paid": book.costs}
            if sess >= 1:
                for nm, arr in evv.items():
                    if arr[t] and nm not in ev_first:
                        ev_first[nm] = self._ts(k, t)
            if timeline:
                tl_rows.append(self._tl_row(k, t, V, evv, st, fills_bar, legs, exs, amb))
        # ---------------- after the clock ----------------
        last_sess = int(k.session[-1])
        if book.Q > 0 and honest_after is None:
            if s.open_cut is not None and last_sess < s.open_cut:
                jK = k.sig + s.open_cut
                x = next(x for x in s.exits if x.type == "time" and x.at == "open" and x.session == s.open_cut
                         and x.size >= 1.0 - 1e-12)
                if ds.locked(jK, "open"):
                    honest_after = (jK, f"{x.name}: open locked at the lower band")
                    res.locked_exit = True
                else:
                    touch(float(ds.o[jK]), s.open_cut)
                    do_sell(x.name, 1.0, -1, float(ds.o[jK]), "open", f"time exit at the session {s.open_cut} open",
                            sess=s.open_cut, when=str(ds.dates[jK]))
                    snaps[s.open_cut] = {"pos": 0.0, "avg_entry": np.nan, "mtm_net": book.mtm(0.0),
                                         "realized": book.realized, "costs_paid": book.costs}
            elif any(p_[0] == "sell" for p_ in pending):
                honest_after = (int(k.day_pos[-1]), "sell order blocked at the lower band until the clock ended")
                res.locked_exit = True
            else:
                res.status, res.note = "pending", "position still open when the clock ended (data)"
                do_sell("end", 1.0, n - 1, float(ds.c[int(k.day_pos[-1])]), "close", "end of the clock (data)")
        if book.Q > 0 and honest_after is not None:
            j0, why = honest_after
            q, how = ds.honest_open_after(j0, LOCK_SEARCH)
            for jj in range(j0 + 1, q):
                kk = int(jj - k.sig)
                touch(float(ds.h[jj]), kk)
                touch(float(ds.l[jj]), kk)
                snaps[kk] = {"pos": book.basis, "avg_entry": book.avg, "mtm_net": book.mtm(float(ds.c[jj])),
                             "realized": book.realized, "costs_paid": book.costs}
            kq = int(q - k.sig)
            nm = why.split(":")[0]
            if how == "ok":
                touch(float(ds.o[q]), kq)
                do_sell(nm, 1.0, -1, float(ds.o[q]), "locked_open", why + "; first unlocked open", sess=kq,
                        when=str(ds.dates[q]))
            elif how == "stuck":
                touch(float(ds.h[q]), kq)
                touch(float(ds.l[q]), kq)
                do_sell(nm, 1.0, -1, float(ds.c[q]), "stuck_close", why + f"; still locked after {LOCK_SEARCH} "
                        f"sessions (marked at this close)", sess=kq, when=str(ds.dates[q]))
                res.status, res.note = "stuck", f"locked for more than {LOCK_SEARCH} sessions"
            else:
                do_sell(nm, 1.0, -1, float(ds.c[q]), "data_end", why + "; data ends (marked at the last close)",
                        sess=kq, when=str(ds.dates[q]))
                res.status, res.note = "pending", "locked exit not settled (data ends)"
            final = {"pos": 0.0, "avg_entry": np.nan, "mtm_net": book.mtm(0.0), "realized": book.realized,
                     "costs_paid": book.costs}
            for kk in [kk for kk in snaps if kk >= kq]:      # sessions recorded in the clock after the honest sale
                snaps[kk] = dict(final)
            snaps[kq] = dict(final)
        # ---------------- results ----------------
        buys = [f for f in res.fills if f.side == "buy"]
        sells = [f for f in res.fills if f.side == "sell"]
        res.deployed, res.max_pos = book.bought, book.max_pos
        res.costs, res.gross = book.costs, book.realized
        res.net = book.realized - book.costs
        res.events_first = ev_first
        if not buys:
            if res.status == "ok":
                res.status = "not_entered"
            res.net = res.gross = res.costs = 0.0
        else:
            res.first_entry = buys[0].price
            res.avg_entry = sum(f.notional for f in buys) / sum(f.notional / f.price for f in buys)
            res.entry_session, res.entry_time = buys[0].session, buys[0].when
            if sells:
                res.exit_price, res.exit_reason = sells[-1].price, sells[-1].leg
                res.exit_session, res.exit_time = sells[-1].session, sells[-1].when
            last_bar = max([f.bar for f in sells if f.bar >= 0], default=n - 1)
            res.bars_held = (last_bar if not any(f.bar < 0 for f in sells) else n - 1) - buys[0].bar
            fe = buys[0].raw
            if np.isfinite(ext["hi"]):
                res.mfe, res.mfe_session = ext["hi"] / fe - 1, ext["hi_s"]
                res.mae, res.mae_session = ext["lo"] / fe - 1, ext["lo_s"]
        res.path = self._path(k, snaps, res)
        if timeline:
            res.timeline = pd.DataFrame(tl_rows)
        return res

    def _path(self, k: Clock, snaps: Dict[int, dict], res: TradeResult) -> List[dict]:
        """One row per session from the signal day to the later of max_sessions and the exit (daily bars)."""
        ds = k.ds
        last = max([self.s.max_sessions] + list(snaps))
        rows, prev_mtm, carry = [], 0.0, {"pos": 0.0, "avg_entry": np.nan, "mtm_net": 0.0, "realized": 0.0,
                                          "costs_paid": 0.0}
        for kk in range(0, last + 1):
            jj = k.sig + kk
            if jj >= len(ds):
                break
            sn = snaps.get(kk)
            if sn is None:
                sn = dict(carry)
                if sn["pos"] > 0:        # no snapshot (e.g. a missing 3-minute session): mark at the daily close
                    sn["mtm_net"] = np.nan
            carry = sn
            r = {"session": kk, "date": str(ds.dates[jj]), "open": float(ds.o[jj]), "high": float(ds.h[jj]),
                 "low": float(ds.l[jj]), "close": float(ds.c[jj]), "volume": float(ds.v[jj]),
                 "pos": float(sn["pos"]), "avg_entry": float(sn["avg_entry"]), "mtm_net": float(sn["mtm_net"]),
                 "realized": float(sn["realized"]), "costs_paid": float(sn["costs_paid"]),
                 "buys": ";".join(f"{f.leg}@{f.price:.4f}" for f in res.fills if f.side == "buy" and f.session == kk),
                 "sells": ";".join(f"{f.leg}@{f.price:.4f}" for f in res.fills if f.side == "sell" and f.session == kk)}
            r["day_net"] = (r["mtm_net"] - prev_mtm) if kk >= 1 and np.isfinite(r["mtm_net"]) else (0.0 if kk == 0 else np.nan)
            if np.isfinite(r["mtm_net"]):
                prev_mtm = r["mtm_net"]
            rows.append(r)
        return rows

    def _resolve_by_3m(self, sym: str, ds: DailySeries, j: int, stop: float, target: float) -> str:
        """Daily mode, intrabar 'intraday': which level did the session's 3-minute bars reach first?"""
        if self.intraday_cache is None:
            return "worst"
        sx = self.intraday_cache.get(sym, {}).get(ds.dates[j])
        if sx is None or not sx.usable:
            return "worst"
        for lo_, hi_ in zip(sx.l, sx.h):
            hs, ht = lo_ <= stop, hi_ >= target
            if hs and ht:
                return "worst"
            if hs:
                return "stop"
            if ht:
                return "target"
        return "worst"

    def _tl_row(self, k: Clock, t: int, V: Vars, evv, st, fills, legs, exs, amb) -> dict:
        r = {"bar": t, "time": self._ts(k, t), "session": int(k.session[t]), "bar_in_session": int(k.bis[t]),
             "open": float(k.o[t]), "high": float(k.h[t]), "low": float(k.l[t]), "close": float(k.c[t]),
             "volume": float(k.v[t])}
        if k.mode == "intraday":
            r["vwap"] = float(V.get("vwap")[t])
        for nm in self.used_names:
            if nm in r:
                continue
            try:
                r[nm] = float(V.get(nm)[t])
            except Exception:
                pass
        for nm, arr in evv.items():
            r[f"event:{nm}"] = bool(arr[t])
        for kk in ("pos", "avg_entry", "upnl", "mfe_sofar", "mae_sofar", "realized"):
            r[kk] = st[kk]
        for nm, L_ in legs.items():
            if L_["armed"]:
                r[f"armed:{nm}"] = L_["level"]
        for nm, ex in exs.items():
            if ex["active"] and np.isfinite(ex["level"]):
                r[f"trail:{nm}"] = ex["level"]
        r["fills"] = "; ".join(f"{f.side} {f.leg} {f.frac:.0%} @ {f.price:.4f} ({f.kind}: {f.reason})" for f in fills)
        r["ambiguous"] = amb
        return r


_INSIDE = ("stop", "limit", "target", "trail")


def fill_time(k: "Clock", t: int, kind: str, day=None) -> np.datetime64:
    """A sortable time for a fill: opens at the bar start, fills inside a bar 1 minute in (daily: 12:00),
    closes at the bar's end (daily: 15:30). After the clock (honest exits) `day` gives the session."""
    if t < 0 or t >= k.n:
        base = np.datetime64(day, "m") + np.timedelta64(SESSION_START_MIN, "m")
        return base + (np.timedelta64(375, "m") if kind in ("stuck_close", "data_end", "close") else np.timedelta64(0, "m"))
    base = np.datetime64(k.ts[t], "m")
    if kind in _INSIDE:
        return base + (np.timedelta64(165, "m") if k.mode == "daily" else np.timedelta64(1, "m"))
    if kind == "close":
        return base + (np.timedelta64(375, "m") if k.mode == "daily" else np.timedelta64(BAR_MIN, "m"))
    return base


def _same_or_raise(full: np.ndarray, part: np.ndarray, what: str, T: int, pick: dict) -> None:
    full = np.asarray(full, float)
    part = np.asarray(part, float)
    if full.shape != part.shape:
        raise R.RuleError(f"{what} returned {part.shape} values for {full.shape} bars when later bars were removed")
    same = (np.isnan(full) & np.isnan(part)) | (np.abs(full - part) <= 1e-9 * np.maximum(1.0, np.abs(full)))
    if not same.all():
        t0 = int(np.flatnonzero(~same)[0])
        raise R.RuleError(f"{what} looks ahead: its value at bar {t0} changes when the bars after bar {T} are "
                          f"removed ({full[t0]!r} vs {part[t0]!r}; trade {pick.get('trade_id')})")
