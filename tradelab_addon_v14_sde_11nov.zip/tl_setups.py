"""
tl_setups.py - tl_setups v1.0, the setups add-on for tradelab v1.3.1: the FROZEN entry setups (setuplab v0.7) in
tradelab's tools - the watch page, the trade journal, the backtester and the simulator.

It reads setuplab's outputs READ ONLY (nothing here computes a setup: one source of truth, setuplab's own rules):
  <SETUPLAB_OUT>\\TAGS\\TAGS_<date>_<nnn>\\setup_tags.parquet   every past pick: which frozen setups entered it, on which
                                                                watch day (D1..D5), at what price, both exits
                                                                (setuplab tag; checked against its outputs.sha256)
  <SETUPLAB_OUT>\\scan\\scan_<YYYYMMDD>.csv                     the nightly scan of the last five sessions' picks
  <SETUPLAB_OUT>\\scan\\setup_ledger.jsonl                      the scan's on-time record (for the watch page's ON TIME)
  <SETUPLAB_OUT>\\TREE\\TREE_<date>_<nnn>\\tree_tags.parquet     v1.2: the entry tree on every pick (setuplab v1.1 tree;
                                                                checked against its outputs.sha256): the lane (CALM /
                                                                JUMPY by the pick's ATR against the year's cut-off),
                                                                and on ranks 1-3 the tree's action and how it bought
SETUPLAB_OUT comes from --setups or the environment variable SETUPLAB_OUT (env_tradelab.bat sets it). Neither given =
no setup tags (said once, never guessed).

v1.2 (9 Nov 2026) - the entry tree (setuplab TREE.json, frozen 9 Nov): the lane is known at the pick's close (the
cut-off is the 2/3 quantile of earlier years' ATRs), so 'calm' (1 calm, 0 jumpy, blank = no lane) is a pick attribute
a filter may read. The tree's action / how / net are decided day by day after the pick (the open, then each setup's
own day): hindsight columns, and the entry leg {"tree": True} with the exit {"type": "time", "tree": True} trades
them - a filter or rule naming tree_* or opened_up is refused like a setup tag.

v1.3 (11 Nov 2026) - one line per stock on the watch page: the scan lists one row per setup x pick, so one purchase
(RRKABEL bought once at 1970.00 on 3 Nov) showed as 7 rows. next_open_groups / held_groups fold them: one row per
stock at the next open (with the entry tree's orders for each book from scan\\tree_ledger.jsonl and the stock's
lane) and one row per position held (symbol + entry day + price), listing every setup and pick behind it and when
each sells; tree_books_held reads the tree books' open positions (scan\\tree_book.csv). Display only: no rule,
record or number changes.

v1.4 (11 Nov 2026) - SDE, signed directional efficiency at the pick (the SDE handover of 11 Nov): for N = 3, 5, 10, 20
sessions, pre_sdeN = (close(t) - close(t-N)) / sum of |close(i) - close(i-1)| over the N moves ending at the pick's
close t; -1 = a perfectly orderly fall, +1 = an orderly rise; blank when the moves sum to 0, a bar is missing, or one
close-to-close move inside the window exceeds 45% (a split or bonus not adjusted - never a real NSE day). Known at the
pick's close: filters may read pre_sde3 / 5 / 10 / 20. The backtester splits every strategy by SDE10 (NEG < -0.5,
MID, POS >= +0.5) and, with the tree, by lane x SDE10. The tree entry takes "open_if": a pick rule (pick attributes
only) under which a tree pick (ETFs never) is bought at the D1 open and sold at the 5th close instead of the tree's
own schedule - the sketch's empty branch: {"tree": True, "open_if": "calm == 0 and pre_sde10 < -0.5"}.

A setup tag is known only on the setup's OWN entry day (its conditions are read at the close before it). So a tag
may describe a trade (a column, a breakdown labelled hindsight) or open a trade at that entry ({"setup": "S2"} entry
legs in a strategy) - it may never decide a D1 entry: filters and rules that name a tag are refused.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from tl_common import TLError

SETUPS_VERSION = "tl_setups v1.4"
ENV = "SETUPLAB_OUT"
TAG_NAME = re.compile(r"\b(su_[A-Za-z0-9_]+|n_setups|setups|tree_[A-Za-z0-9_]+|opened_up)\b")
TAGS_FILE = "setup_tags.parquet"
TREE_FILE = "tree_tags.parquet"
TREE_PICK_ATTRS = ["calm"]                  # v1.2: known at the pick's close - a filter may read it
TREE_COLS = ["lane", "lane_atr14", "lane_cutoff", "calm", "opened_up", "tree_action", "tree_how", "tree_net",
             "tree_tagged"]
TREE_HOLD = 5                               # a setup with the 'fresh' primary exit is sold 4 sessions after its entry
TREE_LAST_EXIT = 5 + TREE_HOLD - 1          # N1 entering on D5 is sold at the close of session 9
SDE_HORIZONS = (3, 5, 10, 20)               # v1.4: signed directional efficiency at the pick
SDE_PICK_ATTRS = tuple(f"pre_sde{n}" for n in SDE_HORIZONS)
SDE_JUMP = 0.45                             # a close-to-close move above this inside the window: SDE left blank
SDE_EDGES = ((-np.inf, -0.5, 0.5, np.inf), ("NEG < -0.5", "MID", "POS >= +0.5"))
SDE_DIMS = (("SDE10 at the pick (signed directional efficiency, 10 sessions)", "pre_sde10", SDE_EDGES, "before"),)


def base_dir(cli: Optional[str] = None) -> Optional[Path]:
    """setuplab's output folder: --setups, else SETUPLAB_OUT, else None (no tags)."""
    v = cli if cli else os.environ.get(ENV, "")
    return Path(v) if v else None


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _checked(run: Path, name: str) -> str:
    """The file's sha256 when it matches the run's outputs.sha256 ('<sha>  <name>' lines); refused otherwise."""
    p = run / name
    rec = {}
    hf = run / "outputs.sha256"
    if hf.is_file():
        for ln in hf.read_text(encoding="utf-8").splitlines():
            parts = ln.split("  ", 1)
            if len(parts) == 2:
                rec[parts[1].strip()] = parts[0].strip()
    sha = _sha(p)
    if rec.get(name) != sha:
        raise TLError(f"{p} does not match {hf} (recorded {str(rec.get(name))[:16]}, file {sha[:16]}) - refusing")
    return sha


def latest_tags(base: Path) -> Path:
    runs = sorted((Path(base) / "TAGS").glob("TAGS_*"))
    runs = [r for r in runs if (r / TAGS_FILE).is_file()]
    if not runs:
        raise TLError(f"no setup tags under {Path(base) / 'TAGS'} - run setuplab's tag command first "
                      f"(python setuplab.py tag --data ... --features ... --out {base})")
    return runs[-1]


def load_tags(base: Optional[Path], need: bool = False) -> Tuple[Optional[pd.DataFrame], dict]:
    """The newest tag run (setup_tags.parquet, hash-checked) and its TAGS.json. need=False: (None, why) when absent."""
    if base is None:
        if need:
            raise TLError(f"this needs the frozen setups' tags: pass --setups <setuplab output folder> or set {ENV} "
                          f"(env_tradelab.bat sets it)")
        return None, {"used": False, "why": f"no --setups and no {ENV}"}
    try:
        run = latest_tags(base)
    except TLError as e:
        if need:
            raise
        return None, {"used": False, "why": str(e)}
    p = run / TAGS_FILE
    sha = _checked(run, TAGS_FILE)
    meta = {}
    if (run / "TAGS.json").is_file():
        meta = json.loads((run / "TAGS.json").read_text(encoding="utf-8"))
    T = pd.read_parquet(p)
    T["trade_id"] = T["trade_id"].astype(str)
    ids = [s["id"] for s in meta.get("setups", [])] or sorted({c[3:].rsplit("_", 1)[0] for c in T.columns
                                                                if c.startswith("su_") and c.endswith("_day")})
    info = {"used": True, "run": run.name, "folder": str(run), "sha256": sha, "frozen_sha256": meta.get("frozen_sha256"),
            "setups": ids, "names": {s["id"]: s.get("name", "") for s in meta.get("setups", [])},
            "primary_exit": {s["id"]: s.get("primary_exit", "original_d5") for s in meta.get("setups", [])},
            "signal_days": meta.get("signal_days"), "picks": int(len(T)), "tool": meta.get("version")}
    return T, info


def refuse_tag_names(texts: Sequence[str], where: str) -> None:
    """A filter or rule that names a setup tag would decide on later sessions' closes: refused with the way out."""
    for t in texts:
        if not t:
            continue
        m = TAG_NAME.search(str(t))
        if m:
            if m.group(1).startswith("tree_") or m.group(1) == "opened_up":
                raise TLError(f"{where}: '{m.group(1)}' is an entry-tree column. The tree decides after the pick (the "
                              f"open, then each setup's own day), so a filter or rule cannot read it - it would look at "
                              f"sessions after the pick. To trade the tree, use the entry {{'name': 'tree', 'tree': True}} "
                              f"with the exit {{'name': 'tree', 'type': 'time', 'tree': True}}; 'calm' (the lane, known "
                              f"at the pick's close) may be filtered on.")
            raise TLError(f"{where}: '{m.group(1)}' is a setup tag. A setup is known only on its own entry day (its "
                          f"conditions are read at the close before it), so a filter or rule cannot read it - it would "
                          f"look at sessions after the pick. To trade a setup, use an entry leg such as "
                          f"{{'name': 's2', 'setup': 'S2'}}.")


def setup_days(tags: Optional[pd.DataFrame], ids: Sequence[str]) -> Dict[str, Dict[str, int]]:
    """trade_id -> {setup id: watch day it entered} (only the setups that entered)."""
    out: Dict[str, Dict[str, int]] = {}
    if tags is None:
        return out
    for sid in ids:
        col = f"su_{sid}_day"
        if col not in tags.columns:
            continue
        g = tags[["trade_id", col]].dropna()
        for t, d in zip(g["trade_id"], g[col]):
            out.setdefault(str(t), {})[sid] = int(d)
    return out


def tag_columns(df: pd.DataFrame, tags: Optional[pd.DataFrame], ids: Sequence[str], primary: Optional[dict] = None,
                nets: bool = False) -> pd.DataFrame:
    """df (with trade_id) + setups (e.g. 'S2@D3 C1@D3'), n_setups, su_<ID>_day; nets=True also su_<ID>_net (net % at
    the setup's primary exit). Picks the tag run does not cover get blank tags and setups_tagged = False."""
    X = df.copy()
    if tags is None:
        return X
    keep = ["trade_id", "setups", "n_setups"] + [f"su_{s}_day" for s in ids if f"su_{s}_day" in tags.columns]
    J = tags[keep].copy()
    if nets:
        for s in ids:
            pe = (primary or {}).get(s, "original_d5")
            col = f"su_{s}_net_{'d5' if pe == 'original_d5' else 'fresh'}"
            if col in tags.columns:
                J[f"su_{s}_net"] = tags[col].to_numpy()
    J["setups_tagged"] = True
    drop = [c for c in J.columns if c != "trade_id" and c in X.columns]
    X = X.drop(columns=drop).merge(J, on="trade_id", how="left")
    X["setups_tagged"] = X["setups_tagged"].astype("boolean").fillna(False).astype(bool)
    X["setups"] = X["setups"].astype(object).where(X["setups"].notna(), "")
    X["n_setups"] = pd.to_numeric(X["n_setups"], errors="coerce").fillna(0).astype(int)
    return X


# ---------------------------------------------------------------------------------------------------- the entry tree
def latest_tree(base: Path) -> Path:
    runs = sorted((Path(base) / "TREE").glob("TREE_*"))
    runs = [r for r in runs if (r / TREE_FILE).is_file()]
    if not runs:
        raise TLError(f"no entry-tree run under {Path(base) / 'TREE'} - run setuplab's tree command first "
                      f"(python setuplab.py tree --data ... --out {base})")
    return runs[-1]


def load_tree(base: Optional[Path], need: bool = False) -> Tuple[Optional[pd.DataFrame], dict]:
    """v1.2: the newest tree run (tree_tags.parquet, hash-checked) and its TREE_RUN.json. need=False: (None, why)."""
    if base is None:
        if need:
            raise TLError(f"this needs setuplab's entry tree: pass --setups <setuplab output folder> or set {ENV} "
                          f"(env_tradelab.bat sets it)")
        return None, {"used": False, "why": f"no --setups and no {ENV}"}
    try:
        run = latest_tree(base)
    except TLError as e:
        if need:
            raise
        return None, {"used": False, "why": str(e)}
    sha = _checked(run, TREE_FILE)
    meta = {}
    if (run / "TREE_RUN.json").is_file():
        meta = json.loads((run / "TREE_RUN.json").read_text(encoding="utf-8"))
    T = pd.read_parquet(run / TREE_FILE)
    T["trade_id"] = T["trade_id"].astype(str)
    if T["trade_id"].duplicated().any():
        raise TLError(f"{run / TREE_FILE}: a trade id appears twice - refusing")
    info = {"used": True, "run": run.name, "folder": str(run), "sha256": sha, "tree_sha256": meta.get("tree_sha256"),
            "frozen_sha256": meta.get("frozen_sha256"), "window": meta.get("window"),
            "reconciled": meta.get("reconciled"), "cutoffs": meta.get("cutoffs"), "picks": int(len(T)),
            "tool": meta.get("version")}
    return T, info


def reads_calm(raw: dict) -> bool:
    """A strategy (its raw dict) whose filter, rules or sizing expression read 'calm' (the tree's lane)."""
    texts = [str((raw.get("picks") or {}).get("filter") or ""), str((raw.get("sizing") or {}).get("expression") or "")]
    texts += [str(v) for v in (raw.get("events") or {}).values()]
    for d in list(raw.get("entries") or []) + list(raw.get("exits") or []):
        texts += [str(d.get(k) or "") for k in ("when", "level", "cancel_if", "activate")]
    return any(re.search(r"\bcalm\b", t) for t in texts)


def sde_series(c, n: int) -> np.ndarray:
    """SDE_n at every bar t of one close series: (c[t] - c[t-n]) / sum_{i=t-n+1..t} |c[i] - c[i-1]|; NaN for the first
    n bars, when the moves sum to 0, when a close inside the window is missing, or when one move exceeds SDE_JUMP."""
    c = np.asarray(c, float)
    out = np.full(len(c), np.nan)
    if len(c) <= n:
        return out
    d = np.diff(c)
    miss = ~np.isfinite(d)
    with np.errstate(divide="ignore", invalid="ignore"):
        jump = np.abs(c[1:] / c[:-1] - 1) > SDE_JUMP
    jump &= ~miss
    ad = np.where(miss, 0.0, np.abs(d))
    cs, cm, cj = (np.concatenate([[0.0], np.cumsum(x)]) for x in (ad, miss.astype(float), jump.astype(float)))
    t = np.arange(n, len(c))
    den = cs[t] - cs[t - n]
    with np.errstate(divide="ignore", invalid="ignore"):
        v = (c[t] - c[t - n]) / den
    bad = ~(den > 1e-12) | (cm[t] - cm[t - n] > 0) | (cj[t] - cj[t - n] > 0) | ~np.isfinite(v)
    v[bad] = np.nan
    out[t] = np.clip(v, -1.0, 1.0)
    return out


def add_sde(market, T: pd.DataFrame, log=None) -> Tuple[pd.DataFrame, dict]:
    """v1.4: T + pre_sde3 / 5 / 10 / 20 at each pick's signal-day close (blank: no bar that day, too little history,
    a flat or broken window). Returns (T, info with coverage)."""
    X = T.copy()
    n = len(X)
    vals = {c: np.full(n, np.nan) for c in SDE_PICK_ATTRS}
    if n:
        days = pd.to_datetime(X["signal_day"]).dt.normalize().to_numpy().astype("datetime64[D]")
        syms = X["symbol"].astype(str).to_numpy()
        for sym, idxs in pd.Series(np.arange(n)).groupby(syms):
            ds = market.series(sym)
            if ds is None or not len(ds):
                continue
            pos = np.array([ds.idx(days[j]) for j in idxs.to_numpy()], dtype=np.int64)
            ok = pos >= 0
            for h, col in zip(SDE_HORIZONS, SDE_PICK_ATTRS):
                srs = sde_series(ds.c, h)
                vals[col][idxs.to_numpy()[ok]] = srs[pos[ok]]
    for c in SDE_PICK_ATTRS:
        X[c] = vals[c]
    b = bucket_sde(X["pre_sde10"].to_numpy(float)) if n else np.array([], dtype=object)
    info = {"horizons": list(SDE_HORIZONS), "picks": int(n), "with_sde10": int(np.isfinite(vals["pre_sde10"]).sum()),
            "buckets": {k: int((b == k).sum()) for k in SDE_EDGES[1]}, "jump_guard": SDE_JUMP}
    if log:
        log(f"   SDE at the pick: SDE10 known for {info['with_sde10']:,} of {n:,} picks "
            f"({', '.join(f'{k} {v:,}' for k, v in info['buckets'].items())})")
    return X, info


def bucket_sde(v) -> np.ndarray:
    """SDE10 -> 'NEG < -0.5' / 'MID' / 'POS >= +0.5' (blank when unknown); edges as the breakdown's."""
    v = np.asarray(v, float)
    out = np.full(len(v), "", dtype=object)
    ok = np.isfinite(v)
    k = np.searchsorted(np.asarray(SDE_EDGES[0][1:-1], float), v[ok], side="right")
    out[ok] = np.asarray(SDE_EDGES[1], dtype=object)[k]
    return out


def tree_frame(tree: pd.DataFrame) -> pd.DataFrame:
    """The tree run as tradelab's columns (one row per trade id): lane, lane_atr14 / lane_cutoff (ATR14 / close and
    the year's cut-off, fractions), calm, opened_up, tree_action, tree_how ('open', 'S2@D3' or blank), tree_net (net %
    of the tree's own trade on the pick: the D5 close for 'open', the setup's primary exit for a setup; blank =
    not traded by the tree)."""
    lane = tree["lane"].fillna("").astype(str).to_numpy()
    how = tree["how"].fillna("").astype(str).to_numpy()
    d1 = pd.to_numeric(tree["d1_net"], errors="coerce").to_numpy(float)
    sn = pd.to_numeric(tree["setup_net"], errors="coerce").to_numpy(float)
    gap = pd.to_numeric(tree["gap_pct"], errors="coerce").to_numpy(float)
    up = tree["opened_up"].astype("boolean").fillna(False).to_numpy(bool)
    return pd.DataFrame({
        "trade_id": tree["trade_id"].astype(str).to_numpy(), "lane": lane,
        "lane_atr14": pd.to_numeric(tree["s_atr14"], errors="coerce").to_numpy(float),
        "lane_cutoff": pd.to_numeric(tree["cutoff"], errors="coerce").to_numpy(float),
        "calm": np.where(lane == "CALM", 1.0, np.where(lane == "JUMPY", 0.0, np.nan)),
        "opened_up": np.where(np.isfinite(gap), up, None),          # blank = the open is not known
        "tree_action": tree["action"].fillna("").astype(str).to_numpy(), "tree_how": how,
        "tree_net": np.where(how == "open", d1, np.where(how != "", sn, np.nan)),
        "tree_etf": tree["etf"].astype("boolean").fillna(False).to_numpy(bool) if "etf" in tree.columns
        else np.zeros(len(tree), dtype=bool)})


def tree_columns(df: pd.DataFrame, tree: Optional[pd.DataFrame], cols: Sequence[str] = tuple(TREE_COLS)) -> pd.DataFrame:
    """df (with trade_id) + the tree's columns; picks the tree run does not cover: blank, tree_tagged = False."""
    X = df.copy()
    if tree is None:
        return X
    J = tree_frame(tree)
    J["tree_tagged"] = True
    J = J[["trade_id"] + [c for c in cols if c in J.columns]]
    drop = [c for c in J.columns if c != "trade_id" and c in X.columns]
    tid = X["trade_id"].astype(str)
    X = X.drop(columns=drop).assign(trade_id=tid).merge(J, on="trade_id", how="left")
    if "tree_tagged" in X:
        X["tree_tagged"] = X["tree_tagged"].astype("boolean").fillna(False).astype(bool)
    for c in ("lane", "tree_action", "tree_how"):
        if c in X:
            X[c] = X[c].astype(object).where(X[c].notna(), "")
    return X


def tree_entries(T: pd.DataFrame, tree: pd.DataFrame, tags: Optional[pd.DataFrame], tinfo: dict,
                 trinfo: dict) -> List[dict]:
    """trade_id -> the tree's own trade on the pick, for the entry leg {"tree": True}: {"day": the watch day it buys at
    the open (1 = the pick's first session), "exit": the session whose close sells it, "how": ...}; {} = the tree does
    not trade the pick. 'open' and S1-S3 / C1-C3 sell at the 5th close; a 'fresh' setup (N1) 4 sessions after its
    entry. Every setup entry is checked against setuplab's setup tags (the same day) - one source of truth."""
    if tags is None:
        raise TLError("the tree's setup entries need the setup tags too (setuplab's TAGS run)")
    if trinfo.get("frozen_sha256") and tinfo.get("frozen_sha256") and trinfo["frozen_sha256"] != tinfo["frozen_sha256"]:
        raise TLError(f"the tree run {trinfo.get('run')} was built on freeze {str(trinfo['frozen_sha256'])[:16]} but "
                      f"the tags {tinfo.get('run')} on {str(tinfo['frozen_sha256'])[:16]} - refusing")
    TF = tree_frame(tree).set_index("trade_id")
    tids_s = T["trade_id"].astype(str)
    how = tids_s.map(TF["tree_how"]).fillna("").astype(str)
    covered = tids_s.isin(TF.index).to_numpy()
    etf = tids_s.map(TF["tree_etf"]).fillna(False).astype(bool).to_numpy()
    m = how.str.fullmatch(r"([A-Z][0-9]+)@D([1-5])")
    bad_fmt = how[(how != "") & (how != "open") & ~m]
    if len(bad_fmt):
        raise TLError(f"tree run {trinfo.get('run')}: unreadable 'how' {bad_fmt.iloc[0]!r} on {bad_fmt.index[0]}")
    parts = how.str.extract(r"^([A-Z][0-9]+)@D([1-5])$")
    sid, k = parts[0].fillna(""), pd.to_numeric(parts[1], errors="coerce")
    unknown = sorted(set(sid[sid != ""]) - set(tinfo.get("setups", [])))
    if unknown:
        raise TLError(f"tree run {trinfo.get('run')} buys through {unknown}, which the tags {tinfo.get('run')} do not hold")
    sd = setup_days(tags, tinfo.get("setups", []))
    tids = T["trade_id"].astype(str).to_numpy()
    wrong = [t for t, s_, kk in zip(tids, sid, k) if s_ and sd.get(t, {}).get(s_) != int(kk)]
    if wrong:
        raise TLError(f"the tree run {trinfo.get('run')} and the tags {tinfo.get('run')} disagree on {len(wrong)} setup "
                      f"entries (e.g. {wrong[0]}: tree {how[T['trade_id'].astype(str) == wrong[0]].iloc[0]}, tags "
                      f"{sd.get(wrong[0])}) - refusing")
    prim = tinfo.get("primary_exit", {})
    out = []
    for h, s_, kk, cv, ef in zip(how, sid, k, covered, etf):
        base = {"tagged": True, "etf": bool(ef)} if cv else {}
        if h == "open":
            out.append(dict(base, day=1, exit=5, how=h))
        elif s_:
            kk = int(kk)
            out.append(dict(base, day=kk, exit=kk + TREE_HOLD - 1 if prim.get(s_) == "fresh" else 5, how=h))
        else:
            out.append(base)
    return out


# ---------------------------------------------------------------------------------------------------- the nightly scan
def scan_path(base: Optional[Path], day) -> Optional[Path]:
    if base is None:
        return None
    return Path(base) / "scan" / f"scan_{pd.Timestamp(day):%Y%m%d}.csv"


def read_scan(base: Optional[Path], day) -> Tuple[Optional[pd.DataFrame], dict]:
    """The scan of one evening (setuplab scan) and whether its ledger record was on time."""
    p = scan_path(base, day)
    if p is None:
        return None, {"found": False, "why": f"no --setups and no {ENV}"}
    if not p.is_file():
        return None, {"found": False, "file": str(p), "why": "no setup scan for this evening (run_tonight.bat runs it "
                                                              "before the watch page)"}
    S = pd.read_csv(p, dtype={"trade_id": str})
    info = {"found": True, "file": str(p), "sha256": _sha(p), "rows": int(len(S)), "on_time": None}
    lp = Path(base) / "scan" / "setup_ledger.jsonl"
    if lp.is_file():
        d = f"{pd.Timestamp(day):%Y-%m-%d}"
        for ln in lp.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(ln)
            except json.JSONDecodeError:
                continue
            if r.get("event") == "scan" and r.get("scan_date") == d:
                info.update({"on_time": bool(r.get("on_time")), "recorded_at": r.get("recorded_at"),
                             "frozen_sha256": r.get("frozen_sha256")})
                break
    return S, info


def int_text(x) -> str:
    """A watch day from a CSV cell (int, float or blank) as text: 3 / 3.0 -> '3', blank / NaN -> ''."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    return str(int(v)) if np.isfinite(v) else ""


def scan_words(r: dict) -> str:
    """One scan row in words for the watch page (v1.1: with its zone, when setuplab's zones file names one)."""
    st = str(r.get("status") or "")
    sid = str(r.get("setup") or "")
    z = str(r.get("zone") or "")
    zw = {"IN": " (in its zone)", "OUT": " (outside its zone)"}.get(z, "")
    if st == "FIRES":
        return f"{sid} buy at the open{zw}"
    if st == "ARMED":
        return f"{sid} buy at the open only if {r.get('rule_at_open') or 'the open meets its rule'}{zw}"
    if st == "ENTERED":
        try:
            px = f" at {float(r.get('entry')):.2f}"
        except (TypeError, ValueError):
            px = ""
        return f"{sid} entered D{int_text(r.get('entered_day'))}{px}{zw}"
    return ""


def pick_setups_text(S: Optional[pd.DataFrame], engine: str, rank: int, symbol: str, day) -> str:
    """The setups column of one of tonight's picks: what fires / is armed at the next open."""
    if S is None or S.empty:
        return ""
    d = f"{pd.Timestamp(day):%Y-%m-%d}"
    g = S[(S["engine"].astype(str) == str(engine)) & (pd.to_numeric(S["rank"], errors="coerce") == int(rank)) &
          (S["symbol"].astype(str) == str(symbol)) & (S["signal_day"].astype(str) == d) &
          (S["status"].isin(["FIRES", "ARMED"]))]
    rec = g.to_dict("records")
    fires = [r for r in rec if r["status"] == "FIRES"]
    zw = {"IN": " in zone", "OUT": " outside zone"}
    bits = [("BUY at the open: " + ", ".join(f"{r['setup']}{zw.get(str(r.get('zone') or ''), '')}" for r in fires))] \
        if fires else []
    bits += [f"{r['setup']}{zw.get(str(r.get('zone') or ''), '')} only if {r.get('rule_at_open') or 'the open meets its rule'}"
             for r in rec if r["status"] == "ARMED"]
    return "; ".join(bits)


def _day_txt(d) -> str:
    try:
        return f"{pd.Timestamp(d):%d %b}".lstrip("0")
    except (TypeError, ValueError):
        return str(d or "")


def _px(x) -> str:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    return f"{v:.2f}" if np.isfinite(v) else ""


def _int(x) -> Optional[int]:
    t = int_text(x)
    return int(t) if t else None


def read_tree_night(base: Optional[Path], day) -> dict:
    """v1.3: the entry tree's record of this evening (scan\\tree_ledger.jsonl, event 'tree'), every pick's lane from all
    records up to this evening, and the tree books (scan\\tree_book.csv) when this evening's record exists."""
    out = {"found": False, "rec": None, "lanes": {}, "book": None}
    if base is None:
        return out
    tl = Path(base) / "scan" / "tree_ledger.jsonl"
    if not tl.is_file():
        return out
    d = f"{pd.Timestamp(day):%Y-%m-%d}"
    newest = ""
    for ln in tl.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(ln)
        except json.JSONDecodeError:
            continue
        if r.get("event") != "tree":
            continue
        newest = max(newest, str(r.get("scan_date")))
        if str(r.get("scan_date")) > d:
            continue
        for pk in r.get("picks") or []:
            out["lanes"][str(pk.get("trade_id"))] = str(pk.get("lane") or "")
        if r.get("scan_date") == d:
            out.update({"found": True, "rec": r})
    bk = Path(base) / "scan" / "tree_book.csv"       # rewritten by every scan: tonight's only if no later scan ran
    if out["found"] and newest == d and bk.is_file():
        out["book"] = pd.read_csv(bk, dtype={"trade_id": str})
    return out


def _pick_key(r: dict) -> Tuple[str, int, str]:
    return str(r.get("engine")), int(float(r.get("rank"))), str(r.get("signal_day"))


def _pick_name(e: str, k: int, sd: str) -> str:
    return f"{e} #{k} ({_day_txt(sd)} pick)"


def next_open_groups(S: Optional[pd.DataFrame], tree: Optional[dict] = None) -> List[dict]:
    """v1.3: one row per stock for the next open - every FIRES / ARMED setup of every pick of the stock, folded, plus
    the entry tree's orders (each tree book buys a stock once) and the stock's lane."""
    tree = tree or {}
    rec = tree.get("rec") or {}
    lanes = tree.get("lanes") or {}
    orders = rec.get("orders") or {}
    picks = {str(p.get("trade_id")): p for p in rec.get("picks") or []}
    G: Dict[str, dict] = {}

    def grp(sym):
        return G.setdefault(sym, {"symbol": sym, "lane": "", "tree": [], "picks": {}, "fires": False, "rules": [],
                                  "close": np.nan, "zones": {}})
    if S is not None and len(S):
        A = S[S["status"].isin(["FIRES", "ARMED"])].copy()
        for c in ("close_tonight", "zone", "rule_at_open", "next_watch_day", "trade_id"):
            if c not in A.columns:
                A[c] = np.nan
        for r in A.sort_values(["engine", "rank", "setup"]).to_dict("records"):
            g = grp(str(r["symbol"]))
            pk = _pick_key(r)
            g["picks"].setdefault(pk, {"fires": [], "armed": [], "wd": _int(r.get("next_watch_day"))})
            z = {"IN": " in zone", "OUT": " outside zone"}.get(str(r.get("zone") or ""), "")
            if r["status"] == "FIRES":
                g["picks"][pk]["fires"].append(f"{r['setup']}{z}")
                g["fires"] = True
            else:
                rule = str(r.get("rule_at_open") or "the open meets its rule")
                g["picks"][pk]["armed"].append(f"{r['setup']}{z} if {rule}")
                if rule not in g["rules"]:
                    g["rules"].append(rule)
            if not np.isfinite(g["close"]):
                try:
                    g["close"] = float(r.get("close_tonight"))
                except (TypeError, ValueError):
                    pass
            ln = lanes.get(str(r.get("trade_id")), "")
            if ln and not g["lane"]:
                g["lane"] = ln
    dl = [str(t) for t in orders.get("D_calm_in_rank_order") or []]
    for j, t in enumerate(dl):
        p = picks.get(t, {})
        g = grp(str(p.get("symbol", t)))
        g["lane"] = g["lane"] or str(p.get("lane") or "")
        thr = _px(p.get("close"))
        g["tree"].append(f"D tree: buy at the open if it opens at or above {thr or 'its close'}"
                         + ("" if len(dl) == 1 else f" and no calm pick before it in the list did (#{j + 1} of {len(dl)})"))
        if not np.isfinite(g["close"]):
            g["close"] = float(p.get("close")) if p.get("close") is not None else np.nan
    for t in [str(t) for t in orders.get("ENS_calm_at_open") or []]:
        p = picks.get(t, {})
        g = grp(str(p.get("symbol", t)))
        g["lane"] = g["lane"] or str(p.get("lane") or "")
        g["tree"].append("ENS tree: BUY at the open (calm)")
        if not np.isfinite(g["close"]) and p.get("close") is not None:
            g["close"] = float(p.get("close"))
    sym_of = {}
    if S is not None and len(S):
        sym_of = dict(zip(S["trade_id"].astype(str), S["symbol"].astype(str))) if "trade_id" in S.columns else {}
    for b in orders.get("setup_buys") or []:
        t = str(b.get("trade_id"))
        sym = picks.get(t, {}).get("symbol") or sym_of.get(t)
        if not sym:
            continue
        g = grp(str(sym))
        rule = "" if b.get("status") == "FIRES" else f" if {b.get('rule_at_open')}"
        txt = f"{b.get('engine')} tree: buy through {b.get('setup')}{rule}" + \
              (" - unless that open makes it the D calm buy" if b.get("unless_calm_buy") else "")
        if txt not in g["tree"]:
            g["tree"].append(txt)
    out = []
    for sym, g in G.items():
        lines = []
        for (e, k, sd), v in g["picks"].items():
            bits = ([f"BUY {', '.join(v['fires'])}"] if v["fires"] else []) + v["armed"]
            lines.append(f"{_pick_name(e, k, sd)}" + (f", watch day {v['wd']}" if v["wd"] else "") + ": " + "; ".join(bits))
        do = ("BUY at the open" if g["fires"] else
              ("BUY at the open only if " + " or ".join(g["rules"]) if g["rules"] else ""))
        out.append({"symbol": sym, "lane": g["lane"], "tree": g["tree"], "setups": lines, "do": do,
                    "close": g["close"], "n_rows": sum(len(v["fires"]) + len(v["armed"]) for v in g["picks"].values())})
    return sorted(out, key=lambda x: (not x["tree"], x["do"] != "BUY at the open", x["symbol"]))


def _when_order(w: str) -> int:
    if w.startswith("tomorrow"):
        return 1
    m = re.search(r"in (\d+) sessions", w)
    return int(m.group(1)) if m else 99


def held_groups(S: Optional[pd.DataFrame]) -> List[dict]:
    """v1.3: the frozen setups' open positions, one row per position (stock + entry day + entry price): every setup and
    pick that bought it, and when each sells (original_d5 = the pick's D5 close; fresh = 4 sessions after entry)."""
    if S is None or S.empty:
        return []
    E = S[S["status"] == "ENTERED"].copy()
    if E.empty:
        return []
    for c in ("entry_date", "entry", "mark_pct", "primary_exit", "next_watch_day", "entered_day"):
        if c not in E.columns:
            E[c] = np.nan
    E["entry_date"] = E["entry_date"].astype(object).where(E["entry_date"].notna(), "")
    E["_px"] = pd.to_numeric(E["entry"], errors="coerce").round(4)
    out = []
    for (sym, ed, px), g in E.groupby(["symbol", "entry_date", "_px"], sort=False, dropna=False):
        lines, sells = [], {}
        for pk, h in g.groupby(["engine", "rank", "signal_day"], sort=False):
            e, k, sd = str(pk[0]), int(float(pk[1])), str(pk[2])
            kd = _int(h["entered_day"].iloc[0])
            lines.append(f"{_pick_name(e, k, sd)}" + (f", watch day {kd}" if kd else "") + ": "
                         + " ".join(sorted(h["setup"].astype(str))))
            for r in h.to_dict("records"):
                pe = str(r.get("primary_exit") or "original_d5")
                xd = 5 if pe == "original_d5" else ((kd or 0) + 4 if kd else None)
                nw = _int(r.get("next_watch_day"))
                when = ""
                if xd is not None and nw is not None and xd >= nw:
                    n = xd - nw + 1
                    when = "tomorrow's close" if n == 1 else f"the close in {n} sessions"
                key = when or (f"the pick's D{xd} close" if xd else "4 sessions after entry")
                sells.setdefault(key, {}).setdefault(f"{e} #{k}, {_day_txt(sd)} pick", []).append(str(r.get("setup")))
        mk = pd.to_numeric(g["mark_pct"], errors="coerce").dropna()
        out.append({"symbol": str(sym), "entry_date": str(ed), "entry": float(px) if px == px else np.nan,
                    "mark_pct": float(mk.iloc[0]) if len(mk) else np.nan, "setups": lines,
                    "sells": [f"{k_}: " + "; ".join(f"{' '.join(sorted(ids))} ({pk_})" for pk_, ids in v.items())
                              for k_, v in sorted(sells.items(), key=lambda kv: _when_order(kv[0]))],
                    "n_rows": int(len(g))})
    return sorted(out, key=lambda x: (x["entry_date"], x["symbol"]))


def tree_books_held(tree: Optional[dict]) -> List[dict]:
    """v1.3: the tree books' open positions (tree_book.csv, books named '... tree'), one row per stock."""
    B = (tree or {}).get("book")
    if B is None or B.empty:
        return []
    H = B[(B["status"] == "held") & B["book"].astype(str).str.endswith("tree")]
    out = []
    for sym, g in H.groupby("symbol", sort=False):
        out.append({"symbol": str(sym), "books": [f"{r['book']}: {r['how']} on {_day_txt(r['entry_date'])} at "
                                                  f"{_px(r['entry'])}, now {float(r['now_pct']):+.2f}%, sells at the "
                                                  f"close of {_day_txt(r['exit_date'])}"
                                                  if pd.notna(r.get("now_pct")) else
                                                  f"{r['book']}: {r['how']} on {_day_txt(r['entry_date'])} at "
                                                  f"{_px(r['entry'])}, sells at the close of {_day_txt(r['exit_date'])}"
                                                  for r in g.to_dict("records")]})
    return out


def action_rows(S: Optional[pd.DataFrame]) -> List[dict]:
    """The scan's FIRES / ARMED / ENTERED rows (every pick of the last five sessions), for the watch page's section."""
    if S is None or S.empty:
        return []
    order = {"FIRES": 0, "ARMED": 1, "ENTERED": 2}
    g = S[S["status"].isin(list(order))].copy()
    g["_o"] = g["status"].map(order)
    g = g.sort_values(["_o", "setup", "engine", "rank"]).drop(columns="_o")
    return g.to_dict("records")
