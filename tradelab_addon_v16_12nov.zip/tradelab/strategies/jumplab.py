"""strategies/jumplab.py - jumplab JL1, Stage 2 (setups add-on v1.6). Declared 12 Nov 2026 before any run
(jumplab\\JUMPLAB_DECLARATION.json; 'python jumplab.py check' confirms this file's sha256).

Every variant is the FROZEN entry tree (strategies\\tree.py: Rs 5 L, 3 positions, 35 bp, honest exits) with one change,
compared with the frozen tree on the same picks - once for engine D, once for ENS. All need --jumplab <JL run folder>.

  T - swing targets on the tree's own buys (ranks 1-3, from 2022: pick_meta's out-of-sample forecasts start there)
    T1  sell at +5% when P(+5% touch) >= 0.5          T5  sell at +5% always (control)
    T2  sell at +3% when P(+5% touch) >= 0.5          T6  sell at +3% always (control)
    T3  sell at + the forecast median swing            T7  T3 + a stop at the forecast 20% dip
    T4  sell at + the forecast 20% swing (likely)      T8  a 3% trail once the forecast median swing is reached
  J - the jumpy meta model (ranks 1-10 from 2021; ranks 4-10 are outside the tree, so open_untagged)
    J0  buy every jumpy pick at the D1 open (control)  J4  J1 + no setup buy for a jumpy pick in the meta's bottom 30%
    J1  jumpy + meta expected net in its top 30%       J5  J1 + T3's target (from 2022)
    J2  jumpy + meta expected net above 0              J6  jumpy + random 30% (control)
    J3  J1 + meta dip risk at or below its median      J7  J1 on ranks 1-3 only

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\jumplab.py#J1 --compare strategies\\tree.py --engines D --jumplab <JL run folder> --declare "jumplab JL1 J1 D"

Decision (declared; per engine): the daily-return difference against the frozen tree has a 95% interval above 0, the
CAGR is higher and the worst drawdown no deeper; then 'python jumplab.py holm' Holm-corrects each engine's family of 16
(0.025, one-sided). A PASS is a forward candidate only (these are the years the tree was found on).
"""
import copy

_TREE = {
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": "2021-01-01"},
    "max_sessions": 9,
    "entries": [{"name": "tree", "size": 1.0, "tree": True}],
    "exits": [{"name": "tree", "type": "time", "tree": True}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "sizing": {"rule": "equal_slots", "slots": 3, "max_pct": 0.34},
    "portfolio": {"capital": 500000, "max_open": 3},
    "decision_rule": {"metric": "daily_diff_bp", "pass_if": "lower > 0", "money": "cagr_and_drawdown"},
}
_NEVER = "avg_entry * 1000"                        # a level no price reaches: no target / no stop for this pick


def _v(name: str, description: str, entry: dict = None, exits: list = None, ranks=(1, 2, 3), start="2021-01-01"):
    s = copy.deepcopy(_TREE)
    s["name"], s["description"] = f"jumplab_{name}", description
    s["picks"].update(ranks=list(ranks), **{"from": start})
    if entry:
        s["entries"][0].update(entry)
    if exits:
        s["exits"] += exits
    return s


def _tp(level: str) -> dict:
    return {"name": "tp", "type": "target", "level": level}


_MED = f"avg_entry * (1 + jm_mfe50) if jm_mfe50 > 0 else {_NEVER}"
_J1 = "jm_jumpy == 1 and jm_net_q >= 0.7"
_ALL = tuple(range(1, 11))
STRATEGIES = {
    "T1": _v("T1", "tree; sell at +5% when P(+5%) >= 0.5", exits=[_tp(f"avg_entry * 1.05 if jm_up5 >= 0.5 else {_NEVER}")],
             start="2022-01-01"),
    "T2": _v("T2", "tree; sell at +3% when P(+5%) >= 0.5", exits=[_tp(f"avg_entry * 1.03 if jm_up5 >= 0.5 else {_NEVER}")],
             start="2022-01-01"),
    "T3": _v("T3", "tree; sell at + the forecast median swing", exits=[_tp(_MED)], start="2022-01-01"),
    "T4": _v("T4", "tree; sell at + the forecast 20% swing",
             exits=[_tp(f"avg_entry * (1 + jm_mfe20) if jm_mfe20 > 0 else {_NEVER}")], start="2022-01-01"),
    "T5": _v("T5", "tree; sell at +5%", exits=[_tp("avg_entry * 1.05")], start="2022-01-01"),
    "T6": _v("T6", "tree; sell at +3%", exits=[_tp("avg_entry * 1.03")], start="2022-01-01"),
    "T7": _v("T7", "tree; forecast median swing target + a stop at the forecast 20% dip",
             exits=[_tp(_MED), {"name": "sl", "type": "stop",
                                "level": "avg_entry * (1 + jm_mae20) if jm_mae20 < 0 else 0"}], start="2022-01-01"),
    "T8": _v("T8", "tree; a 3% trail once the forecast median swing is reached",
             exits=[{"name": "trail", "type": "trail", "pct": 0.03, "activate": "mfe_sofar >= jm_mfe50"}],
             start="2022-01-01"),
    "J0": _v("J0", "tree + every jumpy pick of ranks 1-10 at the D1 open",
             entry={"open_if": "jm_jumpy == 1", "open_untagged": True}, ranks=_ALL),
    "J1": _v("J1", "tree + jumpy picks (ranks 1-10) in the meta's top 30% at the D1 open",
             entry={"open_if": _J1, "open_untagged": True}, ranks=_ALL),
    "J2": _v("J2", "tree + jumpy picks (ranks 1-10) with the meta's expected net above 0 at the D1 open",
             entry={"open_if": "jm_jumpy == 1 and jm_net > 0", "open_untagged": True}, ranks=_ALL),
    "J3": _v("J3", "J1 with the meta's dip risk at or below its median",
             entry={"open_if": _J1 + " and jm_dip_q <= 0.5", "open_untagged": True}, ranks=_ALL),
    "J4": _v("J4", "J1 + no setup buy for a jumpy pick in the meta's bottom 30%",
             entry={"open_if": _J1, "open_untagged": True, "veto_if": "jm_jumpy == 1 and jm_net_q <= 0.3"}, ranks=_ALL),
    "J5": _v("J5", "J1 + a target at the forecast median swing",
             entry={"open_if": _J1, "open_untagged": True}, exits=[_tp(_MED)], ranks=_ALL, start="2022-01-01"),
    "J6": _v("J6", "tree + a random 30% of the jumpy picks (ranks 1-10) at the D1 open (control)",
             entry={"open_if": "jm_jumpy == 1 and jm_rand < 0.3", "open_untagged": True}, ranks=_ALL),
    "J7": _v("J7", "J1 on ranks 1-3 only", entry={"open_if": _J1, "open_untagged": True}),
}
