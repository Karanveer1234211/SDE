"""
tl_dictionary.py - tradelab v1.1: what every column of every output table means.

Each output folder gets DATA_DICTIONARY.md and data_dictionary.csv listing the columns of the tables it wrote:
the meaning, the unit and WHEN the value is known:
  id      identifies the row
  pick    known at the pick day's close (session 0) - a rule may use it
  day     known at that row's own close (market_days / trade_days rows)
  after   known only after the pick - explains an outcome; never a rule input or a selection criterion
  record  pick_meta's recorded value (reconciliation only)
  info    run metadata
Units: 'fraction' = 0.012 means +1.2%; 'bp' = basis points (100 bp = 1%); 'pts' = percentage points as a fraction.
The test suite checks that every column written has an entry here.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd

E = Tuple[str, str, str, str]          # (column or regex, meaning, unit, timing)

_BRD = "(nifty|mid|small)"

MARKET_DAY: List[E] = [
    ("date", "the session (NIFTY 50 calendar, IST); every value is as of its 15:30 close", "date", "id"),
    ("weekday", "Mon..Fri", "text", "id"),
    (rf"{_BRD}_close", "index close", "index points", "day"),
    (rf"{_BRD}_ret", "index day return: close / previous session's close - 1", "fraction", "day"),
    (rf"{_BRD}_gap", "index open / previous close - 1 (blank when the cache's index open is unusable)", "fraction", "day"),
    (rf"{_BRD}_intraday", "index close / open - 1 (the open-to-close move)", "fraction", "day"),
    (rf"{_BRD}_ret(5|20)", "index return over the last 5 / 20 sessions (to this close)", "fraction", "day"),
    (rf"{_BRD}_vs_ma50", "close / its 50-session average - 1", "fraction", "day"),
    (rf"{_BRD}_up50", "1 when the index closed at or above its 50-session average (the environment's 'up')", "0/1",
     "day"),
    (rf"{_BRD}_ret_z", "day return / standard deviation of the previous 60 day returns (2.5 or more = abnormal)",
     "sd", "day"),
    ("vix", "India VIX close", "level", "day"),
    ("vix_chg_pct", "VIX close / previous close - 1", "fraction", "day"),
    ("vix_chg5_pct", "VIX close / its close 5 sessions earlier - 1", "fraction", "day"),
    ("vix_pct250", "share of the last 250 VIX closes (today included) at or below today's", "0..1", "day"),
    ("nifty_minus_(mid|small)", "NIFTY's day return minus Midcap's / Smallcap's (> 0 = NIFTY ahead)", "pts", "day"),
    ("nifty_minus_(mid|small)_20", "NIFTY's 20-session return minus Midcap's / Smallcap's", "pts", "day"),
    ("adv", "cached stocks that closed above their previous close", "count", "day"),
    ("dec", "cached stocks that closed below their previous close", "count", "day"),
    ("unch", "cached stocks unchanged", "count", "day"),
    ("ad_n", "cached stocks with a bar that session and the one before (the breadth sample; not every NSE stock; "
             "stocks delisted before the cache was built are missing)", "count", "day"),
    ("ad_ratio", "adv / (adv + dec): the breadth (unchanged left out)", "0..1", "day"),
    ("ad_ratio_10", "10-session average of ad_ratio (the environment's breadth)", "0..1", "day"),
    ("env_direction", "broad_bullish / narrow_bullish / broad_bearish / mixed (declared rules in tl_context.py; blank "
                      "when an input is missing)", "code", "day"),
    ("env_code", "env_direction as 0 broad_bullish, 1 narrow_bullish, 2 mixed, 3 broad_bearish", "0..3", "day"),
    ("high_stress", "1 = VIX at its 90th percentile or above, or VIX +25% in 5 sessions, or a NIFTY / Smallcap move of "
                    "2.5 sd or more; 0 = none of these; blank = unknown (no condition fired and an input is missing)",
     "0/1", "day"),
    ("stress_reason", "which stress conditions fired", "text", "day"),
    ("environment", "the five-label view: high_stress when the flag is on, else env_direction", "code", "day"),
    ("env_text", "the environment in words", "text", "day"),
    ("missing", "core inputs missing that session (nifty / mid / small / vix / breadth) - never filled", "text", "day"),
    ("summary", "the day in one plain-English line", "text", "day"),
]

TRADES_V1: List[E] = [
    ("trade_id", "ENGINE-YYYYMMDD-RANK (the signal day)", "text", "id"),
    ("engine", "D or ENS", "text", "id"),
    ("signal_day", "the pick day = session 0; the model ranks at its close", "date", "id"),
    ("symbol", "NSE symbol", "text", "id"),
    ("rank", "the engine's rank that day (1 = best raw score)", "1..10", "pick"),
    ("traded", "rank <= 3 (the paper plan's trades)", "bool", "pick"),
    ("score", "the engine's raw score", "number", "pick"),
    ("other_rank", "the other engine's rank for the same stock that day (blank = not in its top 10)", "1..10", "pick"),
    ("both_engines", "traded by both engines (both ranks <= 3)", "bool", "pick"),
    ("repeat_of", "the same engine's earlier traded pick of this stock still inside its 5-session hold", "text", "pick"),
    ("repeat", "repeat_of is not blank", "bool", "pick"),
    ("fold", "pick_meta's walk-forward fold", "number", "pick"),
    ("(pred|prob)_.+", "pick_meta's forecast for this pick, made at the pick", "number", "pick"),
    ("s_atr14", "ATR14 / close at the pick (pick_meta)", "fraction", "pick"),
    ("meta_rank", "pick_meta's rank", "number", "pick"),
    ("status", "ok (finished) / pending (data ends) / stuck (locked for 20 sessions)", "text", "after"),
    ("note", "simulation note", "text", "after"),
    ("signal_close", "close of session 0", "price", "pick"),
    ("entry_day", "session 1 (bought at its open)", "date", "after"),
    ("entry", "session 1 open = the entry price", "price", "after"),
    ("entry_gap", "entry / signal_close - 1 (the overnight gap into the trade)", "fraction", "after"),
    ("exit_day", "when the position was sold", "date-time", "after"),
    ("exit_price", "the sale price", "price", "after"),
    ("exit_kind", "close (session 5's close) or locked_open (the first free open after a lower-circuit lock)", "text",
     "after"),
    ("locked_exit", "the exit was delayed by a lower-circuit lock", "bool", "after"),
    ("sessions_held", "session of the sale", "number", "after"),
    ("gross_bp", "exit / entry - 1, before costs", "bp", "after"),
    ("net_bp", "gross - 35 bp round trip", "bp", "after"),
    ("win", "1 when net > 0", "0/1", "after"),
    ("mfe", "best high of sessions 1-5 / entry - 1 (pick_meta's definition)", "fraction", "after"),
    ("mae", "worst low of sessions 1-5 / entry - 1", "fraction", "after"),
    ("(mfe|mae)_session", "the session (1-5) of the best high / worst low", "1..5", "after"),
    ("(mfe|mae)_held", "the same while actually held (a locked exit holds longer)", "fraction", "after"),
    ("(best|worst)_close_session", "the session (1-5) of the best / worst close", "1..5", "after"),
    ("open6_status", "status if sold at session 6's open instead", "text", "after"),
    ("open6_net_bp", "net if sold at session 6's open instead (honest exits)", "bp", "after"),
    ("hold10_status", "status if held to session 10's close", "text", "after"),
    ("hold10_net_bp", "net if held to session 10's close", "bp", "after"),
    (r"close_ret_s[1-5]", "close of session k / entry - 1", "fraction", "after"),
    (r"open_ret_s[2-6]", "open of session k / entry - 1", "fraction", "after"),
    (r"touch_up(3|5|10)_session", "first session (1-5) whose high reached +3 / +5 / +10% from entry (blank = never)",
     "1..5", "after"),
    (r"touch_dn(3|5|8)_session", "first session (1-5) whose low reached -3 / -5 / -8% from entry (blank = never)",
     "1..5", "after"),
    ("up5_and_dn5_same_session", "one session touched both +5% and -5%", "bool", "after"),
    ("status_recorded", "pick_meta's recorded status", "text", "record"),
    ("net_recorded_bp", "pick_meta's recorded net", "bp", "record"),
    ("(mfe|mae)_recorded", "pick_meta's recorded MFE / MAE", "fraction", "record"),
    ("matches_record", "status and net reproduce pick_meta's record (the safety stop)", "bool", "record"),
    ("mfe_mae_match_record", "MFE / MAE reproduce the record", "bool", "record"),
    ("settled_since_record", "recorded pending, finished now", "bool", "record"),
    ("mkt_net_bp", "buy everything: the plan's average net on every panel stock that signal day", "bp", "after"),
    ("mkt_n", "stocks in that average", "count", "after"),
    ("excess_bp", "net_bp - mkt_net_bp", "bp", "after"),
]

PICK_CTX: List[E] = [
    ("pre_prev_date", "the session before the pick day", "date", "pick"),
    (rf"pre_{_BRD}_ret", "index day return on the pick day", "fraction", "pick"),
    (rf"pre_{_BRD}_ret(5|20)", "index return over the 5 / 20 sessions to the pick day", "fraction", "pick"),
    (rf"pre_{_BRD}_vs_ma50", "index / its 50-session average - 1 on the pick day", "fraction", "pick"),
    ("pre_nifty_minus_(mid|small)", "NIFTY minus Midcap / Smallcap on the pick day", "pts", "pick"),
    ("pre_nifty_minus_(mid|small)_20", "NIFTY minus Midcap / Smallcap over the 20 sessions to the pick day", "pts",
     "pick"),
    ("pre_ad_ratio", "breadth on the pick day: advancers / (advancers + decliners)", "0..1", "pick"),
    ("pre_ad_ratio_10", "breadth, 10-session average, on the pick day", "0..1", "pick"),
    ("pre_ad_n", "stocks in the breadth count on the pick day", "count", "pick"),
    ("pre_vix", "VIX close on the pick day", "level", "pick"),
    ("pre_vix_chg_pct", "VIX day change on the pick day", "fraction", "pick"),
    ("pre_vix_chg5_pct", "VIX 5-session change to the pick day", "fraction", "pick"),
    ("pre_vix_pct250", "VIX percentile within the last 250 sessions on the pick day", "0..1", "pick"),
    ("pre_env_direction", "environment direction on the pick day", "code", "pick"),
    ("pre_env_code", "0 broad_bullish, 1 narrow_bullish, 2 mixed, 3 broad_bearish", "0..3", "pick"),
    ("pre_high_stress", "high-stress flag on the pick day (1 / 0 / blank = unknown)", "0/1", "pick"),
    ("pre_stress_reason", "which stress conditions fired on the pick day", "text", "pick"),
    ("pre_environment", "five-label view on the pick day (high_stress overrides the direction)", "code", "pick"),
    ("pre_missing", "core market inputs missing on the pick day", "text", "pick"),
    (rf"pre_prev_{_BRD}_ret", "index day return on the session before the pick day", "fraction", "pick"),
    ("pre_prev_ad_ratio", "breadth on the session before the pick day", "0..1", "pick"),
    ("pre_prev_vix_chg_pct", "VIX change on the session before the pick day", "fraction", "pick"),
    ("pre_prev_environment", "five-label environment the session before the pick day", "code", "pick"),
    ("pre_prev_high_stress", "high-stress flag the session before the pick day", "0/1", "pick"),
    ("pre_stock_ret", "the stock's own return on the pick day", "fraction", "pick"),
    ("pre_prev_stock_ret", "the stock's return on its session before the pick day", "fraction", "pick"),
    ("pre_stock_minus_home", "the stock's pick-day return minus its home index's", "pts", "pick"),
    ("pre_size_class", "large / mid / small from the AMFI list in force on the pick day; 'not in list' (the list "
                       "does not name the stock) / 'no list' (no list in force: before the first, or the half-year's "
                       "list is missing - an older list is never carried on)", "text", "pick"),
    ("pre_size_class_num", "1 large, 2 mid, 3 small (blank when no AMFI class)", "1..3", "pick"),
    ("pre_amfi_rank", "the stock's rank in that AMFI list (by average market cap)", "rank", "pick"),
    ("pre_amfi_list", "the AMFI list in force on the pick day; '(via ISIN ...)' when the stock was found by its "
                      "company's ISIN because that list used an older symbol (a rename)", "text", "pick"),
    ("pre_exposure_days", "valid daily returns in the 120-session sensitivity window", "count", "pick"),
    (rf"pre_beta_{_BRD}", "beta of the stock's daily returns on the index's, 120 sessions to the pick day", "number",
     "pick"),
    (rf"pre_corr_{_BRD}", "correlation of those daily returns with the index's", "-1..1", "pick"),
    ("pre_home_index", "nifty / mid / small: the index the stock correlates with most", "code", "pick"),
    ("pre_home_index_name", "NIFTY 50 / Midcap 150 / Smallcap 250", "text", "pick"),
    ("pre_home_index_num", "1 NIFTY 50, 2 Midcap 150, 3 Smallcap 250", "1..3", "pick"),
    ("pre_beta_home", "beta on the home index", "number", "pick"),
    ("pre_corr_home", "correlation with the home index", "-1..1", "pick"),
    ("pre_context_complete", "1 when every core pre-entry market value is present (indices, VIX, breadth, labels)",
     "0/1", "pick"),
    # v1.3: the stock's state at the pick (tl_state; known at the pick day's close; STATE_RULES.md has every rule)
    ("pre_state", "primary state at the pick day's close: S01 strong bullish continuation, S02 emerging bullish, S03 "
                  "bullish consolidation, S06 bullish reversal attempt, S07 neutral range, S08 bearish continuation, S09 "
                  "emerging bearish, S12 unstable / disorderly, UNKNOWN (evidence conflicts), INSUFFICIENT_DATA (< 60 "
                  "sessions); blank when the stock has no bar on the signal day", "code", "pick"),
    ("pre_state_name", "the state in words", "text", "pick"),
    ("pre_state_num", "the state as a number (1, 2, 3, 6, 7, 8, 9, 12 = S01..S12; 0 UNKNOWN; -1 INSUFFICIENT_DATA)",
     "code", "pick"),
    ("pre_state_bullish|pre_state_bearish", "1 when the state is S01-S03 / S08-S09", "0/1", "pick"),
    ("pre_state_confidence", "HIGH / MEDIUM / LOW / UNKNOWN: evidence agreement, conflicts, persistence and data "
                             "completeness - not a probability", "text", "pick"),
    ("pre_state_conf_num", "3 HIGH, 2 MEDIUM, 1 LOW, 0 UNKNOWN", "0..3", "pick"),
    ("pre_state_phase", "EARLY (the first 5 sessions) / MATURE / DETERIORATING (a change pending, support under 50% "
                        "or 2+ conflicting signs)", "text", "pick"),
    ("pre_state_phase_num", "1 early, 2 mature, 3 deteriorating", "1..3", "pick"),
    ("pre_state_age", "sessions in the state, counted from the session the change began", "sessions", "pick"),
    ("pre_state_prev", "the state before the current one", "code", "pick"),
    ("pre_state_raw", "that session's own reading before confirmation (a change needs 2 sessions in a row)", "code",
     "pick"),
    ("pre_state_pending", "the new reading when a change is pending (blank when none)", "code", "pick"),
    ("pre_state_support", "share of the state's supporting conditions that hold (of those that can be evaluated)",
     "0..1", "pick"),
    ("pre_state_conflicts", "how many of the state's conflicting conditions hold", "count", "pick"),
    ("pre_state_event", "the event shown at the pick (last 10 sessions): BREAKOUT / FAILED_BREAKOUT / BREAKDOWN / "
                        "FAILED_BREAKDOWN with NEW / CONFIRMED / STALLED / FAILED; blank = none", "code", "pick"),
    ("pre_state_event_num", "0 none; 1 / 2 / 3 breakout new / confirmed / stalled; 4 failed breakout; 5 / 6 / 7 "
                            "breakdown new / confirmed / stalled; 8 failed breakdown", "code", "pick"),
    ("pre_state_event_age", "sessions since that event began", "sessions", "pick"),
    ("pre_state_breakout_recent|pre_state_failed_breakout|pre_state_breakdown_recent",
     "1 when that event is the one shown (S04 / S11 / S10)", "0/1", "pick"),
    ("pre_state_overextended", "S05 overextension: 0 no, 1 overextended, 2 extreme (a risk flag, not a sell signal)",
     "0..2", "pick"),
    ("pre_state_risks|pre_state_notes", "risk flags / notes, comma-separated codes (STATE_RULES.md)", "text", "pick"),
    ("pre_state_vol_regime", "the stock's volatility: COMPRESSED / NORMAL / ELEVATED / EXTREME", "text", "pick"),
    ("pre_state_vol_elevated", "1 when that volatility is ELEVATED or EXTREME", "0/1", "pick"),
    ("pre_state_big_down", "1 after a 2+ ATR down candle in the last 5 sessions", "0/1", "pick"),
    ("pre_state_bear_div", "1 for a bearish RSI divergence candidate on confirmed swings", "0/1", "pick"),
    ("pre_state_ext20_atr|pre_state_ext50_atr", "close minus EMA20 / EMA50, in ATR (14, Wilder)", "ATR", "pick"),
    ("pre_state_ema20_slope_atr|pre_state_ema50_slope_atr", "EMA20's change over 5 sessions / EMA50's over 10, in ATR",
     "ATR", "pick"),
    ("pre_state_eff20", "20-session efficiency: net move / sum of the absolute daily moves", "-1..1", "pick"),
    ("pre_state_rsi14", "RSI 14 (Wilder)", "0..100", "pick"),
    ("pre_state_macd_hist_atr", "MACD (12, 26, 9) histogram in ATR", "ATR", "pick"),
    ("pre_state_r20|pre_state_r60", "the stock's 20 / 60-session return", "fraction", "pick"),
    ("pre_state_vol_ratio", "10-session / 60-session realised volatility", "ratio", "pick"),
    ("pre_state_atr_rank", "ATR% percentile within its last 250 sessions (today included)", "0..1", "pick"),
    ("pre_state_rvol", "the day's volume / the median of the previous 50 sessions", "ratio", "pick"),
    ("pre_state_flow20", "signed volume share over 20 sessions: OBV change / volume (a candidate, never proof of "
                         "accumulation)", "-1..1", "pick"),
    ("pre_state_cons_range_atr", "high-low range of the last 15 sessions, in ATR (consolidation width)", "ATR", "pick"),
    ("pre_state_pos20", "close within the previous 20 sessions' high-low range (above 1 = above it)", "ratio", "pick"),
    (rf"post_entry_{_BRD}_(gap|intraday)", "index gap / open-to-close on the entry day (session 1)", "fraction", "after"),
    ("post_entry_ad_ratio", "breadth on the entry day", "0..1", "after"),
    ("post_entry_vix_chg_pct", "VIX change on the entry day", "fraction", "after"),
    ("post_entry_environment", "five-label environment on the entry day (at its close)", "code", "after"),
    ("post_entry_high_stress", "high-stress flag on the entry day", "0/1", "after"),
    ("post_hold_start", "index open (the indices' opens are usable) or previous close", "text", "after"),
    (rf"post_hold_{_BRD}_ret", "index return over exactly the hold: the entry day's open to the exit (close or open)",
     "fraction", "after"),
    ("post_hold_home_ret", "the home index over the hold", "fraction", "after"),
    ("post_hold_vix_chg_pct", "VIX change from the close before the entry to the exit", "fraction", "after"),
    ("post_hold_ad_ratio_avg", "average breadth over the held sessions", "0..1", "after"),
    ("post_hold_stress_days", "held sessions flagged high stress", "count", "after"),
    ("post_gross_ret", "the trade's gross return (exit / entry - 1)", "fraction", "after"),
    ("post_mkt_part_bp", "market part = pre_beta_home x post_hold_home_ret", "bp", "after"),
    ("post_stock_part_bp", "stock part = gross - market part (what the stock did beyond its market)", "bp", "after"),
    ("post_cost_bp", "costs charged (negative)", "bp", "after"),
    ("post_driver", "market (|market| >= 2 x |stock|) / stock (the reverse) / both (same sign) / opposite / flat "
                    "(everything under 0.5%)", "code", "after"),
    (rf"post_excess_vs_{_BRD}_bp", "gross - the index over the same hold", "bp", "after"),
    ("post_excess_vs_home_bp", "gross - the home index over the same hold", "bp", "after"),
    ("outcome", "winner (net > 0) / loser (-500 < net <= 0) / severe_loser (net <= -500 bp); finished trades only",
     "code", "after"),
    ("story", "the trade as a one-line chain: market before -> pick -> trade -> market during -> split", "text",
     "after"),
    ("warnings_fired", "declared warning signs (tl_research) true before entry", "text", "pick"),
]

TRADE_DAYS: List[E] = [
    ("trade_id", "the trade", "text", "id"), ("engine", "D or ENS", "text", "id"),
    ("rank", "rank", "1..10", "id"), ("traded", "rank <= 3", "bool", "id"), ("symbol", "NSE symbol", "text", "id"),
    ("signal_day", "the pick day", "date", "id"),
    ("session", "0 = pick day, 1 = entry day, 2, 3, ... (beyond 5 only while a lock delays the exit)", "number", "id"),
    ("date", "the session's date", "date", "id"),
    ("in_window", "session 1-5", "bool", "id"), ("is_entry_day", "session 1", "bool", "id"),
    ("is_exit_day", "the session the position was sold", "bool", "after"),
    ("after_exit", "after the sale (shows what the stock did next, no position)", "bool", "after"),
    ("held_at_close", "a position was held at this close", "bool", "day"),
    ("(open|high|low|close)", "the stock's official daily price", "price", "day"),
    ("volume", "the stock's daily volume", "shares", "day"),
    ("entry", "the trade's entry price (session 1 open)", "price", "after"),
    (r"ret_(open|high|low|close)_vs_entry", "this session's price / entry - 1", "fraction", "day"),
    ("(mfe|mae)_sofar", "best high / worst low since the entry / entry - 1", "fraction", "day"),
    ("day_ret", "the stock's close / previous close - 1", "fraction", "day"),
    ("gap", "the stock's open / previous close - 1", "fraction", "day"),
    ("range_pct", "(high - low) / previous close", "fraction", "day"),
    ("clv", "close location in the day's range", "0..1", "day"),
    ("vol_ratio20", "volume / median volume of the previous 20 sessions", "ratio", "day"),
    ("atr_ratio", "today's range / ATR14 of the previous session", "ratio", "day"),
    ("nifty_day_ret", "NIFTY 50 day return", "fraction", "day"),
    ("rel_nifty_day", "day_ret - nifty_day_ret", "pts", "day"),
    ("(mid|small)_day_ret", "Midcap 150 / Smallcap 250 day return", "fraction", "day"),
    ("nifty_minus_small_day", "NIFTY's day return minus Smallcap's", "pts", "day"),
    ("vix_close", "India VIX close", "level", "day"), ("vix_chg_pct", "VIX change", "fraction", "day"),
    ("ad_ratio", "breadth that session: advancers / (advancers + decliners)", "0..1", "day"),
    ("environment", "five-label environment that session (at its close)", "code", "day"),
    ("high_stress", "high-stress flag that session", "0/1", "day"),
    ("home_index", "the trade's home index (from the pick day)", "code", "pick"),
    ("home_day_ret", "the home index's day return", "fraction", "day"),
    ("rel_home_day", "day_ret - home_day_ret", "pts", "day"),
    ("held_ret", "the stock's move over the part of the day the position was held (entry day: open to close; "
                 "later: previous close to the close, or to the open when sold at an open)", "fraction", "day"),
    ("home_held_ret", "the home index over the same part of the day", "fraction", "day"),
    ("mkt_part_day_bp", "beta_home x home_held_ret", "bp", "day"),
    ("stock_part_day_bp", "held_ret - the market part", "bp", "day"),
    ("market_line", "NIFTY / Midcap / Smallcap / VIX that session in words", "text", "day"),
    ("day_pnl_bp", "change in the trade's P&L marked at this close (half the 35 bp at the buy, half at the sale)",
     "bp", "day"),
    ("cum_pnl_bp", "the trade's P&L so far, marked at this close; ends at net_bp", "bp", "day"),
    ("pos", "fraction of the target held at the close", "0..1", "day"),
    ("avg_entry", "average entry price of what is held", "price", "day"),
    ("(buys|sells)", "fills that session: leg@price", "text", "day"),
    ("strategy", "the strategy name", "text", "id"),
    ("realized", "realized gross P&L so far / target", "fraction", "day"),
    ("costs_paid", "costs paid so far / target", "fraction", "day"),
    ("mtm_net_bp", "P&L so far marked at this close", "bp", "day"),
    ("day_net_bp", "change in mtm_net_bp", "bp", "day"),
    ("(mtm_net|day_net)", "the same as a fraction", "fraction", "day"),
]

FEATURES: List[E] = [
    ("trade_id", "the trade", "text", "id"), ("symbol", "NSE symbol", "text", "id"),
    ("session", "session number", "number", "id"), ("date", "the session's date", "date", "id"),
    (r"(?!label_).+", "a panel feature (panel_oc) at that session's close, after the label firewall", "number", "day"),
]

BOOK: List[E] = [
    ("engine", "D or ENS", "text", "id"), ("date", "session", "date", "id"),
    ("positions_at_close", "traded picks held at the close", "count", "day"),
    ("new", "entries that session", "count", "day"), ("exits", "exits that session", "count", "day"),
    ("day_pnl_bp_sum", "sum of the held trades' day P&L", "bp", "day"),
    ("day_pnl_bp_mean", "average day P&L of the held trades", "bp", "day"),
    ("book_day_ret_slot", "the book's day return with 1/15 of capital a slot (a proxy)", "fraction", "day"),
    ("book_cum_ret_slot", "running sum of book_day_ret_slot", "fraction", "day"),
]

BARS3: List[E] = [
    ("trade_id", "the trade", "text", "id"), ("symbol", "NSE symbol", "text", "id"),
    ("session", "session number", "number", "id"), ("time", "bar start, IST", "date-time", "id"),
    ("bar_in_session", "0..124 (0 = 09:15)", "number", "id"),
    ("usable_session", "the session passed the 3-minute quality checks", "bool", "day"),
    ("(open|high|low|close)", "3-minute price", "price", "day"), ("volume", "3-minute volume", "shares", "day"),
    ("vwap", "session VWAP to this bar", "price", "day"), ("cum_volume", "session volume to this bar", "shares", "day"),
    ("ret_vs_entry", "close / entry - 1", "fraction", "day"),
    ("ret_vs_prev_close", "close / previous session's close - 1", "fraction", "day"),
    ("session_(high|low)", "the session's high / low so far", "price", "day"),
]

BREAKDOWN: List[E] = [
    ("engine", "D or ENS (or the strategy)", "text", "id"),
    ("dimension", "what the trades are grouped by", "text", "id"),
    ("timing", "before = known at the pick (could choose trades); after = known only afterwards (explains)", "text",
     "id"),
    ("bucket", "the group", "text", "id"), ("trades", "trades in the group", "count", "info"),
    ("share", "share of the engine's trades", "0..1", "info"), ("days", "signal days in the group", "count", "info"),
    (r".+_mean", "average of that column in the group", "bp", "info"),
    (r".+_(lo|hi)", "95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7)",
     "bp", "info"),
    ("win_rate", "share of trades with net > 0", "0..1", "info"),
    ("severe_rate", "share of trades with net <= -500 bp", "0..1", "info"),
]

ENV_TABLE: List[E] = [
    ("group|account", "the engine (export) or the account (backtest)", "text", "id"),
    ("environment", "the environment known at the PREVIOUS session's close (what was known that morning)", "code", "id"),
    ("days", "sessions in that environment", "count", "info"), ("share_of_days", "their share", "0..1", "info"),
    ("mean_day_bp", "mean day return of the account / book (bp of capital)", "bp", "info"),
    ("(lo|hi)", "95% block-bootstrap interval of mean_day_bp", "bp", "info"),
    ("total_return", "those days' returns added (book) or compounded (account)", "fraction", "info"),
    ("max_drawdown_inside", "worst drawdown with only that environment's days chained together", "fraction", "info"),
    ("(worst|best)_day_bp", "worst / best day", "bp", "info"),
    ("avg_positions|max_positions", "positions held at the close: average / most at once (simultaneous exposure)",
     "count", "info"),
    ("avg_exposure|max_exposure", "invested / equity: average / highest", "0..1", "info"),
]

BT_TRADES: List[E] = [
    ("trade_id", "ENGINE-YYYYMMDD-RANK (the signal day)", "text", "id"),
    ("engine", "D or ENS", "text", "id"),
    ("signal_day", "the pick day = session 0", "date", "id"),
    ("symbol", "NSE symbol", "text", "id"),
    ("rank", "the engine's rank that day", "1..10", "pick"),
    ("status", "ok / not_entered (no entry fired: cash) / filtered (the picks filter skipped it: cash) / stuck / "
               "pending / no_data", "text", "after"),
    ("note", "simulation note", "text", "after"),
    ("exit_price", "last sale price", "price", "after"),
    ("net_bp", "net P&L / the trade's target size (an unfilled leg is cash)", "bp", "after"),
    ("win", "net > 0", "bool", "after"),
    ("mfe", "best high since the first buy / first entry - 1, while held", "fraction", "after"),
    ("mae", "worst low since the first buy / first entry - 1, while held", "fraction", "after"),
    ("(mfe|mae)_session", "session of that high / low", "number", "after"),
    ("locked_exit", "a sale was delayed by a lower-circuit lock", "bool", "after"),
    ("strategy", "the strategy", "text", "id"),
    ("entered", "anything was bought", "bool", "after"), ("deployed", "total bought / target", "fraction", "after"),
    ("max_pos", "largest position / target", "fraction", "after"),
    ("first_entry", "price of the first buy", "price", "after"), ("avg_entry", "average entry", "price", "after"),
    ("exit_reason", "the exit rule that sold last", "text", "after"),
    ("(entry|exit)_session", "session of the first buy / last sale", "number", "after"),
    ("(entry|exit)_time", "time of the first buy / last sale", "date-time", "after"),
    ("bars_held", "bars from the first buy to the last sale", "count", "after"),
    ("gross", "gross P&L / target", "fraction", "after"), ("costs", "costs / target", "fraction", "after"),
    ("net", "net P&L / target", "fraction", "after"), ("net_deployed_bp", "net / deployed", "bp", "after"),
    ("ambiguous_bars", "bars where a stop and a target were both inside the bar", "count", "after"),
    ("n_fills", "number of fills", "count", "after"),
    ("legs_filled", "entry legs that filled", "text", "after"), ("exits_used", "exit rules that sold", "text", "after"),
    (r"ev_.+", "first time the named event was true", "date-time", "after"),
    ("net_bp_compare", "the comparison strategy's net on the same pick", "bp", "after"),
    ("status_compare", "its status", "text", "after"),
    ("diff_bp", "net_bp - net_bp_compare (paired picks only)", "bp", "after"),
    ("paired", "in the paired comparison", "bool", "after"),
    (rf"post_hold_{_BRD}_ret", "index return from the first buy (session open or close) to the last sale", "fraction",
     "after"),
    ("post_hold_home_ret", "the home index over the same span", "fraction", "after"),
]

FILLS: List[E] = [
    ("trade_id", "the trade", "text", "id"), ("strategy", "the strategy", "text", "id"),
    ("symbol", "NSE symbol", "text", "id"), ("leg", "entry leg / exit rule name", "text", "after"),
    ("side", "buy / sell", "text", "after"), ("session", "session", "number", "after"),
    ("time", "when", "date-time", "after"), ("ts", "sortable time", "date-time", "after"),
    ("price", "fill price after slippage", "price", "after"), ("raw", "market price before slippage", "price", "after"),
    ("frac", "buy: share of the target; sell: share of the position", "fraction", "after"),
    ("notional", "value bought / received (target = 1)", "fraction", "after"),
    ("basis", "entry value of the shares sold", "fraction", "after"), ("cost", "cost of the fill", "fraction", "after"),
    ("kind", "open / close / next_open / stop / limit / target / trail / locked_open", "text", "after"),
    ("reason", "why it filled", "text", "after"),
]

PORT_DAILY: List[E] = [
    ("date", "session", "date", "id"), ("equity", "account value", "rupees", "day"), ("cash", "cash", "rupees", "day"),
    ("invested", "positions at the close", "rupees", "day"), ("exposure", "invested / equity", "0..1", "day"),
    ("n_open", "open positions", "count", "day"), ("new_trades", "positions opened", "count", "day"),
    ("day_ret", "equity / previous equity - 1", "fraction", "day"),
    ("drawdown", "equity / running peak - 1", "fraction", "day"),
    (r".+_compare", "the same for the comparison strategy", "number", "day"),
]

PORT_TRADES: List[E] = [
    ("trade_id", "the trade", "text", "id"), ("engine", "engine", "text", "id"), ("symbol", "symbol", "text", "id"),
    ("signal_day", "pick day", "date", "id"), ("rank", "rank", "number", "id"), ("status", "status", "text", "after"),
    ("opened", "the account opened it", "bool", "after"), ("skip_reason", "why not", "text", "after"),
    ("target_rupees", "target size", "rupees", "after"), ("bought_rupees", "bought", "rupees", "after"),
    ("sold_rupees", "received", "rupees", "after"), ("costs_rupees", "costs", "rupees", "after"),
    ("open_value", "value still open at the end", "rupees", "after"), ("pnl_rupees", "P&L", "rupees", "after"),
    ("ret_on_target", "P&L / target", "fraction", "after"), ("legs_trimmed", "legs trimmed by cash", "count", "after"),
    ("legs_skipped", "legs skipped by cash", "count", "after"), ("still_open", "open at the end", "bool", "after"),
]

RESEARCH: Dict[str, List[E]] = {
    "outcome_groups": [("engine", "D or ENS", "text", "id"), ("group", "winner / loser / severe_loser", "code", "id"),
                       ("trades", "trades in the group", "count", "info"), ("share", "share of the engine's trades",
                                                                             "0..1", "info"),
                       ("mean_net_bp", "mean net", "bp", "info"), ("net_(lo|hi)", "its 95% interval", "bp", "info"),
                       ("sum_net_bp", "total net (bp of one slot, summed)", "bp", "info"),
                       ("median_mae", "median worst low vs entry, sessions 1-5", "fraction", "info"),
                       ("mean_(mkt|stock)_part_bp", "mean market part / stock part", "bp", "info"),
                       ("share_driven_by_market", "share whose driver is 'market'", "0..1", "info")],
    "outcome_profiles": [("engine", "D or ENS", "text", "id"), ("field", "the pre-entry column", "text", "id"),
                         ("meaning", "in words", "text", "id"), ("kind", "mean (median) or share of the group", "text",
                                                                  "id"),
                         ("format", "how to read the numbers: pct (fraction), ratio, level, num, share", "text", "id"),
                         ("(winner|loser|severe_loser)_(mean|median)", "the group's mean / median (or share)", "number",
                          "info"),
                         ("severe_minus_winner_in_sd", "(severe losers - winners) / pooled sd", "sd", "info")],
    "warning_signs": [("engine", "D or ENS", "text", "id"), ("warning", "declared sign id", "text", "id"),
                      ("words", "the sign in words", "text", "id"), ("rule", "column operator threshold", "text", "id"),
                      ("trades|known|flagged|flag_days|severe_caught|severe_total|winners_flagged|winners_total|"
                       "losers_flagged", "counts (known = trades with the value present)", "count", "info"),
                      ("flagged_share|severe_recall|winner_cost|severe_rate_flagged|severe_rate_all",
                       "shares: flagged / all; severe caught / all severe; winners flagged / all winners; severe rate "
                       "among flagged / among all", "0..1", "info"),
                      ("lift", "severe rate among flagged / severe rate among all", "ratio", "info"),
                      ("mean_net_(flagged|unflagged)_bp", "mean net of flagged / unflagged trades", "bp", "info"),
                      ("diff_bp|diff_(lo|hi)", "flagged minus KNOWN unflagged mean net (blank inputs left out) and "
                       "its 95% interval", "bp", "info"),
                      ("diff_p", "one-sided bootstrap p: share of resamples where flagged - unflagged >= 0", "0..1",
                       "info"),
                      ("unknown", "trades whose input for this sign is blank (never flagged, left out of the "
                       "comparison)", "count", "info"),
                      ("book_return|book_return_if_skipped", "the money view's total return with all trades / without "
                       "the flagged ones (compounded, cash-limited; not stage E)", "fraction", "info"),
                      ("losses_avoided_bp|wins_forgone_bp|pnl_change_if_skipped_bp",
                       "skipping the flagged trades: losses avoided, wins given up, net change (bp of one slot, summed)",
                       "bp", "info"),
                      ("book_max_dd|book_max_dd_if_skipped|book_dd_change",
                       "the money view's worst drawdown (from the starting capital) with all trades / without the "
                       "flagged ones / the change", "fraction",
                       "info")],
    "walk_forward": [("engine", "D or ENS", "text", "id"), ("warning", "sign id (ANY = every qualified sign)", "text",
                                                           "id"),
                     ("test_year", "the year judged", "year", "id"), ("train_years", "the years it was chosen on",
                                                                     "text", "id"),
                     ("train_flagged|train_flag_days", "flagged trades / days in the training years", "count", "info"),
                     ("train_trades|train_purged|train_unknown", "training trades used / left out because they "
                      "exited inside the test year (purge) / with a blank input", "count", "info"),
                     ("train_p|p_needed", "the training one-sided bootstrap p (10,000 resamples) and the Bonferroni "
                      "threshold 0.05 / 8 it had to meet", "0..1", "info"),
                     ("test_unknown", "test-year trades with a blank input (kept: a blank never skips)", "count",
                      "info"),
                     ("test_return|test_return_if_skipped|test_return_change", "the test year's money-view return "
                      "(fresh capital) with all trades / without the flagged ones / the change", "fraction", "info"),
                     ("train_diff_bp|train_diff_(lo|hi)", "training flagged minus unflagged mean net, 95% interval",
                      "bp", "info"),
                     ("qualified", "the declared qualification rule passed on the training years", "bool", "info"),
                     ("test_trades|test_flagged|test_severe_avoided|test_winners_forgone", "test-year counts",
                      "count", "info"),
                     ("test_pnl_change_bp", "net change from skipping the flagged test-year trades", "bp", "info"),
                     ("test_mean_net_flagged_bp", "mean net of the flagged test-year trades", "bp", "info"),
                     ("test_book_max_dd|test_book_max_dd_if_skipped", "the test year's worst money-view drawdown "
                      "with / without them", "fraction", "info"),
                     ("test_dd_improved", "the drawdown got smaller", "bool", "info")],
    "state_book": [("engine", "D or ENS", "text", "id"),
                   ("grouping", "state x phase / state / phase / confidence / event / S05 / stock volatility",
                    "text", "id"), ("cell", "the group (e.g. 'S01 / EARLY')", "text", "id"),
                   ("trades|days", "traded picks / signal days in the cell", "count", "info"),
                   ("share", "share of the engine's traded picks", "0..1", "info"),
                   ("net_bp_mean|net_bp_lo|net_bp_hi", "mean net per trade and its 95% interval (block bootstrap "
                    "over signal days)", "bp", "info"),
                   ("diff_vs_rest_bp|diff_lo|diff_hi", "the cell minus the engine's other picks whose value is "
                    "known, 95% interval", "bp", "info"),
                   ("diff_p_two_sided", "two-sided bootstrap p of that difference (not corrected for the many cells)",
                    "0..1", "info"),
                   ("win_rate|severe_rate", "share with net > 0 / net <= -500 bp", "0..1", "info")],
    "walk_forward_verdicts": [("engine", "D or ENS", "text", "id"), ("warning", "sign id", "text", "id"),
                              ("test_years|qualified_years|severe_avoided|winners_forgone|dd_improved_years",
                               "counts over the test years", "count", "info"),
                              ("pnl_change_bp", "net change over the qualified test years", "bp", "info"),
                              ("return_change", "money-view return change summed over the qualified test years",
                               "fraction", "info"),
                              ("verdict", "CANDIDATE for a stage E replay / NOT SUPPORTED / NEVER "
                                          "QUALIFIED (declared rule in tl_research.py)", "text", "info")],
}

WATCH: List[E] = [   # v1.3: tl_watch's WATCH_YYYYMMDD.csv (one row per recorded pick)
    ("date", "the signal day (the watchlist is for the next session's open)", "date", "id"),
    ("engine|rank|symbol|score", "as the paper test recorded them in paper\\ledger.jsonl", "text", "id"),
    ("recorded_at", "when the paper test recorded the line", "time", "id"),
    ("also_in", "the same stock's rank in the other engine's list", "text", "id"),
    ("environment|env_direction", "the market at the signal day's close (tl_context's declared labels)", "code", "pick"),
    ("high_stress|stress_reason", "the separate high-stress flag and why", "0/1", "pick"),
    ("breadth|breadth_10d", "advancers / (advancers + decliners) over the cached stocks, today / 10-session average",
     "0..1", "pick"),
    ("vix|vix_chg5|vix_pct250", "India VIX, its 5-session change, its percentile of 250 sessions", "level", "pick"),
    ("nifty_minus_small_20", "NIFTY's 20-session return minus Smallcap 250's", "pts", "pick"),
    ("size_class|amfi_rank|amfi_list", "AMFI size class (membership in the list in force that day), rank, list",
     "text", "pick"),
    ("home_index|beta_home|corr_home", "the index the stock moves with most over 120 sessions (sensitivity, not "
     "membership), its beta and correlation", "number", "pick"),
    (rf"beta_{_BRD}", "beta to NIFTY 50 / Midcap 150 / Smallcap 250 (120 sessions)", "number", "pick"),
    ("stock_ret|stock_minus_home", "the stock's day return, and minus its home index's", "fraction", "pick"),
    ("ret20|ret60", "the stock's 20 / 60-session return", "fraction", "pick"),
    ("rs20_size|rs60_size", "relative strength: the stock's 20 / 60-session return minus its AMFI size index's",
     "pts", "pick"),
    ("rs20_home|rs60_home", "the same against its home index", "pts", "pick"),
    ("sector_index|rs20_sector|rs60_sector", "the sector index from sectors\\sector_map.csv (when given) and the "
     "relative strength against it", "pts", "pick"),
    ("state|state_name|state_short|side", "tl_state's primary state (code, name, short name, bull / turn / flat / "
     "bear / wild / none)", "code", "pick"),
    ("confidence|phase|age|prev_state|pending|pending_n|state_began|state_confirmed",
     "confidence, phase, sessions in the state, the state before, a pending change and its count, when the state "
     "began and was confirmed (STATE_RULES.md)", "text", "pick"),
    ("support|conflicts|completeness", "the state's evidence: share of supporting signs, conflicting signs present, "
     "share of its conditions that could be evaluated", "number", "pick"),
    ("event|event_status|event_age|event_text", "the event of the last 10 sessions and what became of it",
     "text", "pick"),
    ("risks|notes|vol_regime", "risk flags, notes and the stock's volatility (codes)", "text", "pick"),
    ("headline|invalidation", "the state in one line; what would end it (price levels for reading, never inputs)",
     "text", "pick"),
    ("d20|d50|d200", "close minus EMA20 / EMA50 / EMA200 in ATR", "ATR", "pick"),
    ("s20|s50", "EMA20 change over 5 sessions / EMA50 over 10, in ATR", "ATR", "pick"),
    ("eff20", "20-session efficiency", "-1..1", "pick"), ("rsi14", "RSI 14", "0..100", "pick"),
    ("macd_h", "MACD histogram in ATR", "ATR", "pick"),
    ("acc", "10-session move in ATR minus the 10 before (momentum acceleration)", "ATR", "pick"),
    ("r5", "5-session return", "fraction", "pick"), ("atr_pct|atr_rank", "ATR as a share of price; its "
     "percentile in 250 sessions", "fraction", "pick"),
    ("vol_ratio", "10 / 60-session realised volatility", "ratio", "pick"),
    ("rvol|vtrend|flow20", "relative volume, 10 / 50-session median volume, signed volume share", "ratio", "pick"),
    ("rng_cons", "range of the last 15 sessions in ATR", "ATR", "pick"),
    ("pos20", "close within the previous 20 sessions' range", "ratio", "pick"),
    ("bull_age|bear_age", "sessions the bullish / bearish structure has held", "sessions", "pick"),
    ("pm_found", "pick_meta published a card for this pick", "bool", "pick"),
    ("pm_up5|pm_up10|pm_dip8|pm_stuck", "pick_meta's P(+5%), P(+10%), P(-8%), P(stuck) as its card shows them",
     "percent", "pick"),
    ("pm_up5_mark|pm_up10_mark|pm_dip8_mark|pm_stuck_mark", "pick_meta's mark: ! failed its check, base = no skill, "
     "(raw) = not corrected", "text", "pick"),
    ("pm_class|pm_swing_p20|pm_swing_p50|pm_swing_p80|pm_swing_lt5|pm_swing_ge10",
     "swing class 1-10 and what past picks of the class swung (20 / 50 / 80% and the shares under 5% / 10%+)",
     "percent", "pick"),
    ("pm_up_room|pm_down_risk", "pick_meta's median forecast best / worst point", "percent", "pick"),
    ("soul_found", "the paper watchlist had a Soul card for the stock (copied into the page)", "bool", "pick"),
    ("warnings", "tl_research's declared warning signs W1-W8 true at the signal day's close (comma separated; shown for "
                 "information, nothing filtered)", "text", "pick"),
    ("warnings_unknown", "signs that could not be evaluated (an input missing)", "text", "pick"),
    ("page_written_at|page_late", "watch_all.csv only (v1.3.1): when that day's page was written, and whether it was "
     "LATE (written at or after 09:00 of the next weekday - not forward evidence)", "text", "info"),
    ("setups", "setups add-on (tl_watch v1.2): setuplab's nightly scan for this pick at the next open - which frozen "
               "setups fire (buy at the open) or are armed (buy only if the open meets the setup's rule); blank = none "
               "or no scan", "text", "pick"),
]

SETUP_TAGS: List[E] = [   # setups add-on (tl_setups v1.0): setuplab's tags joined on trade_id
    ("setups", "the frozen entry setups (setuplab) that entered this pick, with the watch day, e.g. 'S2@D3 C1@D3'. A "
               "setup is known only on its own entry day: hindsight for any entry before it - describe trades with it, "
               "never choose them by it", "text", "after"),
    ("n_setups", "how many frozen setups entered this pick", "count", "after"),
    ("su_[A-Za-z0-9]+_day", "the watch day (1-5 after the pick) a frozen setup bought at its open; blank = it did not",
     "1..5", "after"),
    ("su_[A-Za-z0-9]+_net", "that setup's net % after 0.35 pp at its primary exit (setuplab)", "percent", "after"),
    ("setups_tagged", "setuplab's tag run covers this pick (blank tags on a covered pick = no setup entered)", "bool",
     "info"),
]

TREE_TAGS: List[E] = [    # setups add-on v1.2 (tl_setups v1.2): setuplab's entry tree joined on trade_id
    ("lane", "setuplab's entry tree: CALM = the pick's 14-session ATR / close at or below its year's cut-off, JUMPY = "
             "above; NO ATR / NO CUT-OFF (before the first cut-off year) otherwise - known at the pick's close", "text",
     "pick"),
    ("lane_atr14", "the pick's 14-session ATR as a share of its close (setuplab's s_atr14) - sets the lane", "fraction",
     "pick"),
    ("lane_cutoff", "the year's calm / jumpy cut-off: the 2/3 quantile of earlier years' picks' ATR / close", "fraction",
     "pick"),
    ("calm", "1 = CALM, 0 = JUMPY, blank = no lane; a pick attribute a filter may read (picks.filter: 'calm == 1')",
     "flag", "pick"),
    ("opened_up", "the D1 open was at or above the pick's close (the tree's D rule) - known only at the open", "bool",
     "after"),
    ("tree_action", "what the entry tree did with the pick (ranks 1-3 from the first cut-off year): buy at the open, "
                    "wait for a setup (-> S2@D3) or skip - decided at the open and on each setup's own day: hindsight "
                    "for any entry before then; never choose trades by it", "text", "after"),
    ("tree_how", "where the tree bought: 'open' (the D1 open), 'S2@D3' (setup S2's own day-3 open); blank = skipped",
     "text", "after"),
    ("tree_net", "net % after 0.35 pp of the tree's own trade on the pick (the D5 close for 'open'; the setup's primary "
                 "exit for a setup buy)", "percent", "after"),
    ("tree_tagged", "setuplab's tree run covers this pick", "bool", "info"),
    ("pre_sde(3|5|10|20)", "setups add-on v1.4: signed directional efficiency over the N sessions to the pick's close = "
                           "(close - close N sessions before) / the sum of the N absolute close-to-close moves; -1 an "
                           "orderly fall, +1 an orderly rise; blank: flat window, missing bar or a move above 45%",
     "-1..+1", "pick"),
    ("pre_rsj10", "setups add-on v1.5 (voldir VD1): (up-day minus down-day squared log returns) / their sum over the 10 "
                  "returns to the pick's close; -1 = all variance from falls", "-1..+1", "pick"),
    ("pre_turn_rel", "v1.5: mean turnover (close x volume) of the 10 sessions to the pick / the median of the 120 "
                     "sessions before them", "ratio", "pick"),
    ("pre_lds10", "v1.5: largest-day share - the largest of the 10 absolute close-to-close moves to the pick / their sum",
     "0..1", "pick"),
    ("pre_shock", "v1.5: 1 = a single close-to-close fall of 2 ATR14 or more among the 10 moves to the pick", "flag",
     "pick"),
    ("pre_ret20", "v1.5: close at the pick / close 20 sessions before - 1", "fraction", "pick"),
    ("pre_atrp", "v1.5: ATR14 (simple mean of true ranges) / close at the pick", "fraction", "pick"),
    ("pre_lock3", "v1.5: 1 = a close locked at the lower circuit (production's rule) on one of the 3 sessions to the "
                  "pick", "flag", "pick"),
    ("pre_semivol20", "v1.5: downside semideviation sqrt(2 x mean(r^2 on down days)) over the 20 returns to the pick",
     "fraction", "pick"),
    ("pre_semivol_w", "v1.5: B1's size weight min(1.5, median pre_semivol20 of the engine's picks over the 365 days "
                      "before / this pick's); 1 when unknown or fewer than 50 earlier picks", "ratio", "pick"),
    ("pre_(rsj_lo|rsj_hi|turn_lo|turn_hi|atr_hi|ret20_top)", "v1.5: 1 = in the day's universe tail (voldir's cuts): "
     "RSJ10 <= 10th / >= 90th percentile, turnover ratio <= 33rd / >= 67th, ATR% >= 67th, 20-day return >= 90th; blank "
     "without --voldir", "flag", "pick"),
    ("jm_jumpy", "v1.6 (jumplab JL1): 1 = the pick is in the tree's JUMPY lane (s_atr14 above the year's cut-off or no "
                 "ATR) and not an ETF; 0 = calm or ETF", "flag", "pick"),
    ("jm_(net|dip)", "v1.6: jumplab's out-of-sample meta model: expected net (D1 open -> 5th close, after 35 bp) / chance "
                     "of a dip to -8% or worse; blank = not scored", "fraction", "pick"),
    ("jm_(net|dip)_q", "v1.6: where jm_net / jm_dip sits among the model's own predictions on its training years (0..1)",
     "0..1", "pick"),
    ("jm_rand", "v1.6: a fixed uniform number per pick (from its trade_id) for the random control", "0..1", "pick"),
    ("jm_(up5|deep|mfe20|mfe50|mfe80|mae20|mae50)", "v1.6: pick_meta's frozen out-of-sample forecasts re-exported by "
     "jumplab: P(+5% touch), P(-8% dip), the 5-session swing up (20/50/80% quantiles) and dip (20/50%)", "fraction", "pick"),
    ("pre_mvol_(high|falling)", "v1.5: NIFTY50 GJR-GARCH volatility forecast at the pick >= its 80th percentile of the "
     "252 sessions before / below its value 5 sessions before (voldir); blank without --voldir", "flag", "pick"),
]

TABLES: Dict[str, List[E]] = {
    "watch": WATCH,
    "watch_all": WATCH,
    "trades": TRADES_V1 + PICK_CTX,
    "trade_days": TRADE_DAYS,
    "trade_day_features": FEATURES,
    "daily_book": BOOK,
    "trade_bars_3m": BARS3,
    "market_days": MARKET_DAY,
    "context_breakdown": BREAKDOWN,
    "backtest_trades": BT_TRADES + PICK_CTX + SETUP_TAGS + TREE_TAGS,
    "fills": FILLS,
    "backtest_trade_days": TRADE_DAYS,
    "portfolio_daily": PORT_DAILY,
    "portfolio_trades": PORT_TRADES,
    "book_by_environment": ENV_TABLE,
    "money_by_environment": ENV_TABLE,
    **RESEARCH,
}


def lookup(table: str, column: str) -> Optional[E]:
    for e in TABLES.get(table, []):
        if re.fullmatch(e[0], column):
            return e
    return None


def undocumented(table: str, columns: Iterable[str]) -> List[str]:
    return [c for c in columns if lookup(table, c) is None]


def rows_for(tables: Dict[str, Sequence[str]]) -> pd.DataFrame:
    out = []
    for t, cols in tables.items():
        for c in cols:
            e = lookup(t, c)
            out.append({"table": t, "column": c, "meaning": e[1] if e else "UNDOCUMENTED",
                        "unit": e[2] if e else "", "known": e[3] if e else ""})
    return pd.DataFrame(out, columns=["table", "column", "meaning", "unit", "known"])


KNOWN_TEXT = {"id": "identifies the row", "pick": "known at the pick day's close - a rule may use it",
              "day": "known at that row's own close", "after": "known only afterwards - explains, never a rule input",
              "record": "pick_meta's recorded value (reconciliation)", "info": "summary statistic"}


def write(run_dir: Path, tables: Dict[str, Sequence[str]], title: str = "Data dictionary") -> List[str]:
    """DATA_DICTIONARY.md + data_dictionary.csv for the tables (name -> its columns) written in run_dir."""
    R = rows_for(tables)
    R.to_csv(Path(run_dir) / "data_dictionary.csv", index=False)
    L = [f"# {title}", "", "Units: fraction = 0.012 means +1.2%; bp = basis points (100 bp = 1%); pts = difference of "
         "two returns, as a fraction. 'known' says WHEN a value is known:", ""]
    L += [f"- **{k}**: {v}" for k, v in KNOWN_TEXT.items()]
    for t, G in R.groupby("table", sort=False):
        L += ["", f"## {t}", "", "| column | known | unit | meaning |", "|---|---|---|---|"]
        for r in G.itertuples(index=False):
            L.append(f"| {r.column} | {r.known} | {r.unit} | {r.meaning} |")
    (Path(run_dir) / "DATA_DICTIONARY.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return ["DATA_DICTIONARY.md", "data_dictionary.csv"]
