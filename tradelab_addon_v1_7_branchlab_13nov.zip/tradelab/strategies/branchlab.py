"""strategies/branchlab.py - branchlab BR1, Stage 2 (setups add-on v1.7). Declared 13 Nov 2026 before any run
(branchlab\\BRANCHLAB_DECLARATION.json; 'python branchlab.py check' confirms this file's sha256).

Every variant is the FROZEN entry tree (strategies\\tree.py: D / ENS ranks 1-3 from 2021, Rs 5 L, 3 positions, 35 bp,
honest exits) with ONE change, compared with the frozen tree on the same picks. The change is a watch day per pick that
branchlab computed (br_<V>_day, --branchlab <BR run folder>); 'first' = the pick is bought on the earlier of the tree's
own buy and that day (the same day keeps the tree's buy), sold at the 5th close; a pick is entered once.

  P - the bad-week setups with the week's state HELD (jumpy picks)     N - the same setups WITHOUT the weekly condition
    P_S1 .. P_C3   one setup, the state held until the next weekly update   N_S1 .. N_C3   one setup
    P_ALL          the six, the earliest day                                N_ALL          the six, the earliest day
    P_ALL1 / P_ALL2  the six, the state held 1 / 2 sessions after its update
  B - price levels of D1 (jumpy picks; buy at the open after the close that completes the pattern)
    B_BRK  a close above D1's high     B_RET  then a dip to D1's high that closes above it     B_RCL  back above D1's low
  K - calm D picks (D only)
    K_SLOT  every calm pick opening at or above its close, at the D1 open (not only the day's best-ranked)
    K_LATE  a calm pick that opened lower: the first D2-D5 open at or above its close        K_BOTH  either
  E_OPEN (ENS only)  an ENS calm pick that opens below its close is not bought at the open: its first frozen setup
                     instead (that setup's own exit), none = no buy  ('replace' on those picks)
  X_D2   control: every jumpy pick at the D2 open

    python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\\branchlab.py#P_ALL --compare strategies\\tree.py --engines D --branchlab <BR run folder> --declare "branchlab BR1 P_ALL D"

Decision (declared; per engine): the daily-return difference against the frozen tree has a 95% interval above 0, the
CAGR is higher and the worst drawdown no deeper; then 'python branchlab.py holm' Holm-corrects each engine's family
(D 23 runs, ENS 21; 0.025, one-sided). A PASS is a forward candidate only: these are the years the tree was found on.
"""
import copy

_TREE = {
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": "2021-01-01"},
    "max_sessions": 9,
    "entries": [{"name": "tree", "size": 1.0, "tree": True}],
    "exits": [{"name": "tree", "type": "time", "tree": True}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "sizing": {"rule": "equal_slots", "slots": 3, "max_pct": 0.34},
    "portfolio": {"capital": 500000, "max_open": 3},
    "decision_rule": {"metric": "daily_diff_bp", "pass_if": "lower > 0", "money": "cagr_and_drawdown"},
}


def _v(name: str, description: str, **also) -> dict:
    s = copy.deepcopy(_TREE)
    s["name"], s["description"] = f"branchlab_{name}", description
    s["entries"][0].update({"also_day": f"br_{name}_day", "also_exit": 5, "also_mode": "first"})
    s["entries"][0].update(also)
    return s


_SET = {"S1": "S1 (WQ-16 up, 1 ATR under the D1 open)", "S2": "S2 (minus-DI 5-day change up, gap down)",
        "S3": "S3 (WQ-40 up, 3% under the D1 open)", "C1": "C1 (minus-DI up, 2% under the D1 open)",
        "C2": "C2 (EMA20 angle down, 3% under the D1 open)", "C3": "C3 (Bollinger width up, EMA20 angle down, WQ-44 up)"}
STRATEGIES = {}
for _k, _t in _SET.items():
    STRATEGIES[f"P_{_k}"] = _v(f"P_{_k}", f"tree + {_t} with the bad week held all week, jumpy picks")
STRATEGIES["P_ALL"] = _v("P_ALL", "tree + the six bad-week setups with the bad week held all week, jumpy picks")
STRATEGIES["P_ALL1"] = _v("P_ALL1", "tree + the six bad-week setups with the bad week held 1 session after its update")
STRATEGIES["P_ALL2"] = _v("P_ALL2", "tree + the six bad-week setups with the bad week held 2 sessions after its update")
for _k, _t in _SET.items():
    STRATEGIES[f"N_{_k}"] = _v(f"N_{_k}", f"tree + {_t} without the weekly condition, jumpy picks")
STRATEGIES["N_ALL"] = _v("N_ALL", "tree + the six setups without the weekly condition, jumpy picks")
STRATEGIES["B_BRK"] = _v("B_BRK", "tree + jumpy picks bought at the open after a close above D1's high")
STRATEGIES["B_RET"] = _v("B_RET", "tree + jumpy picks bought at the open after a dip to D1's high closes above it")
STRATEGIES["B_RCL"] = _v("B_RCL", "tree + jumpy picks bought at the open after a close back above D1's low")
STRATEGIES["K_SLOT"] = _v("K_SLOT", "tree + every calm D pick opening at or above its close, at the D1 open")
STRATEGIES["K_LATE"] = _v("K_LATE", "tree + calm D picks that opened lower, at the first D2-D5 open at or above the close")
STRATEGIES["K_BOTH"] = _v("K_BOTH", "tree + K_SLOT and K_LATE")
STRATEGIES["X_D2"] = _v("X_D2", "tree + every jumpy pick at the D2 open (control)")
STRATEGIES["E_OPEN"] = _v("E_OPEN", "ENS tree with D's open check: a calm pick opening below its close goes through the "
                                    "frozen setups instead", also_exit="br_E_OPEN_exit", also_mode="replace",
                          also_if="br_E_OPEN == 1")
