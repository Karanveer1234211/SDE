"""
tl_setups.py - tl_setups v1.0, the setups add-on for tradelab v1.3.1: the FROZEN entry setups (setuplab v0.7) in
tradelab's tools - the watch page, the trade journal, the backtester and the simulator.

It reads setuplab's outputs READ ONLY (nothing here computes a setup: one source of truth, setuplab's own rules):
  <SETUPLAB_OUT>\\TAGS\\TAGS_<date>_<nnn>\\setup_tags.parquet   every past pick: which frozen setups entered it, on which
                                                                watch day (D1..D5), at what price, both exits
                                                                (setuplab tag; checked against its outputs.sha256)
  <SETUPLAB_OUT>\\scan\\scan_<YYYYMMDD>.csv                     the nightly scan of the last five sessions' picks
  <SETUPLAB_OUT>\\scan\\setup_ledger.jsonl                      the scan's on-time record (for the watch page's ON TIME)
  <SETUPLAB_OUT>\\TREE\\TREE_<date>_<nnn>\\tree_tags.parquet     v1.2: the entry tree on every pick (setuplab v1.1 tree;
                                                                checked against its outputs.sha256): the lane (CALM /
                                                                JUMPY by the pick's ATR against the year's cut-off),
                                                                and on ranks 1-3 the tree's action and how it bought
SETUPLAB_OUT comes from --setups or the environment variable SETUPLAB_OUT (env_tradelab.bat sets it). Neither given =
no setup tags (said once, never guessed).

v1.2 (9 Nov 2026) - the entry tree (setuplab TREE.json, frozen 9 Nov): the lane is known at the pick's close (the
cut-off is the 2/3 quantile of earlier years' ATRs), so 'calm' (1 calm, 0 jumpy, blank = no lane) is a pick attribute
a filter may read. The tree's action / how / net are decided day by day after the pick (the open, then each setup's
own day): hindsight columns, and the entry leg {"tree": True} with the exit {"type": "time", "tree": True} trades
them - a filter or rule naming tree_* or opened_up is refused like a setup tag.

v1.3 (11 Nov 2026) - one line per stock on the watch page: the scan lists one row per setup x pick, so one purchase
(RRKABEL bought once at 1970.00 on 3 Nov) showed as 7 rows. next_open_groups / held_groups fold them: one row per
stock at the next open (with the entry tree's orders for each book from scan\\tree_ledger.jsonl and the stock's
lane) and one row per position held (symbol + entry day + price), listing every setup and pick behind it and when
each sells; tree_books_held reads the tree books' open positions (scan\\tree_book.csv). Display only: no rule,
record or number changes.

v1.4 (11 Nov 2026) - SDE, signed directional efficiency at the pick (the SDE handover of 11 Nov): for N = 3, 5, 10, 20
sessions, pre_sdeN = (close(t) - close(t-N)) / sum of |close(i) - close(i-1)| over the N moves ending at the pick's
close t; -1 = a perfectly orderly fall, +1 = an orderly rise; blank when the moves sum to 0, a bar is missing, or one
close-to-close move inside the window exceeds 45% (a split or bonus not adjusted - never a real NSE day). Known at the
pick's close: filters may read pre_sde3 / 5 / 10 / 20. The backtester splits every strategy by SDE10 (NEG < -0.5,
MID, POS >= +0.5) and, with the tree, by lane x SDE10. The tree entry takes "open_if": a pick rule (pick attributes
only) under which a tree pick (ETFs never) is bought at the D1 open and sold at the 5th close instead of the tree's
own schedule - the sketch's empty branch: {"tree": True, "open_if": "calm == 0 and pre_sde10 < -0.5"}.

v1.5 (12 Nov 2026) - volatility x direction (voldir VD1, sdelab\\VOLDIR_DECLARATION.json): at every pick's close the
stock's rsj10 (up minus down variance over 10 returns / their sum), turn_rel (10-session turnover against the 120 before),
lds10 (largest-day share of the 10 moves), shock, ret20, atrp, lock3 (a lower-circuit close on t-2..t, production's rule)
and semivol20 (downside semideviation) - pre_* pick attributes; with voldir's run (--voldir <VD run folder>) also the
flags against the day's universe cross-section (pre_rsj_lo / hi, pre_turn_lo / hi, pre_atr_hi, pre_ret20_top) and the
NIFTY GJR-GARCH regime (pre_mvol_high, pre_mvol_falling); and B1's weight pre_semivol_w. The tree entry takes
"open_exit" (the close an open_if buy sells at, default the 5th) and "veto_if" (a rule on those values read at each tree
buy's own signal close: true = that buy is not made). vol_arrays is the one definition voldir uses too.

v1.6 (12 Nov 2026) - jumplab JL1 (jumplab\\JUMPLAB_DECLARATION.json): its out-of-sample scores per pick (jm_* pick
attributes, --jumplab <JL run folder>, hash-checked): the lane (jm_jumpy), the meta model's expected net and dip risk and
their training percentiles, a fixed random number, and pick_meta's frozen swing forecasts re-exported under fixed names
(jm_up5, jm_deep, jm_mfe20/50/80, jm_mae20/50). The tree entry takes "open_untagged": True (open_if also reaches picks
the tree does not cover, ranks 4-10), and veto_if may read the jm_* scores (known at the pick's close).

v1.7 (13 Nov 2026) - branchlab BR1 (branchlab\\BRANCHLAB_DECLARATION.json): its per-pick watch days for the declared
changes to the tree (br_* pick attributes, --branchlab <BR run folder>, hash-checked and tied to the tree run it was built
from): br_jumpy, br_<V>_day for each variant V in BR_VARIANTS (the first watch day 1..5 the variant's rule buys the pick
at the open; blank = never), and E_OPEN's flag and exit session. The tree entry takes "also_day": a pick attribute
holding a watch day, "also_exit" (the close it sells at: a session, or a pick attribute), "also_mode" ("first": the pick
is bought on the earlier of the tree's own buy and also_day - a tie keeps the tree's buy and exit; "replace": for the
picks where "also_if" holds, also_day / also_exit replace the tree's plan, blank = no buy) and "also_if" (a rule on pick
attributes). branchlab computes every day from what is known at the close before it (or the open itself, like the
tree's own D rule); this module only reads them.

A setup tag is known only on the setup's OWN entry day (its conditions are read at the close before it). So a tag
may describe a trade (a column, a breakdown labelled hindsight) or open a trade at that entry ({"setup": "S2"} entry
legs in a strategy) - it may never decide a D1 entry: filters and rules that name a tag are refused.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from tl_common import TLError

SETUPS_VERSION = "tl_setups v1.7"
ENV = "SETUPLAB_OUT"
TAG_NAME = re.compile(r"\b(su_[A-Za-z0-9_]+|n_setups|setups|tree_[A-Za-z0-9_]+|opened_up)\b")
TAGS_FILE = "setup_tags.parquet"
TREE_FILE = "tree_tags.parquet"
TREE_PICK_ATTRS = ["calm"]                  # v1.2: known at the pick's close - a filter may read it
TREE_COLS = ["lane", "lane_atr14", "lane_cutoff", "calm", "opened_up", "tree_action", "tree_how", "tree_net",
             "tree_tagged"]
TREE_HOLD = 5                               # a setup with the 'fresh' primary exit is sold 4 sessions after its entry
TREE_LAST_EXIT = 5 + TREE_HOLD - 1          # N1 entering on D5 is sold at the close of session 9
SDE_HORIZONS = (3, 5, 10, 20)               # v1.4: signed directional efficiency at the pick
SDE_PICK_ATTRS = tuple(f"pre_sde{n}" for n in SDE_HORIZONS)
SDE_JUMP = 0.45                             # a close-to-close move above this inside the window: SDE left blank
SDE_EDGES = ((-np.inf, -0.5, 0.5, np.inf), ("NEG < -0.5", "MID", "POS >= +0.5"))
SDE_DIMS = (("SDE10 at the pick (signed directional efficiency, 10 sessions)", "pre_sde10", SDE_EDGES, "before"),)
VOL_ATTRS = ("pre_rsj10", "pre_turn_rel", "pre_lds10", "pre_shock", "pre_ret20", "pre_atrp", "pre_lock3",
             "pre_semivol20")                  # v1.5 (voldir VD1): volatility x direction at the pick's close
VOL_CUT_ATTRS = ("pre_rsj_lo", "pre_rsj_hi", "pre_turn_lo", "pre_turn_hi", "pre_atr_hi", "pre_ret20_top",
                 "pre_mvol_high", "pre_mvol_falling")    # against the day's cross-section (voldir's daily_cuts)
VOL_PICK_ATTRS = VOL_ATTRS + VOL_CUT_ATTRS + ("pre_semivol_w",)
VOL_DAY_ATTRS = ("pre_sde10",) + VOL_ATTRS + VOL_CUT_ATTRS   # what a tree veto reads at a buy's signal close
CUTS_FILE = "daily_cuts.parquet"
CUT_COLS = ("rsj10_p10", "rsj10_p90", "turn_rel_p33", "turn_rel_p67", "atrp_p67", "ret20_p90", "mvol", "mvol_high",
            "mvol_falling")
SEMI_CAP, SEMI_MIN, SEMI_DAYS = 1.5, 50, 365
JM_FILE = "jm_scores.parquet"                  # v1.6: jumplab's out-of-sample scores, one row per pick (trade_id)
JM_ATTRS = ("jm_jumpy", "jm_net", "jm_net_q", "jm_dip", "jm_dip_q", "jm_rand", "jm_up5", "jm_deep", "jm_mfe20",
            "jm_mfe50", "jm_mfe80", "jm_mae20", "jm_mae50")
BR_FILE = "br_scores.parquet"                  # v1.7: branchlab's per-pick days (BR1), one row per tree pick (trade_id)
BR_VARIANTS = ("P_S1", "P_S2", "P_S3", "P_C1", "P_C2", "P_C3", "P_ALL", "P_ALL1", "P_ALL2",
               "N_S1", "N_S2", "N_S3", "N_C1", "N_C2", "N_C3", "N_ALL", "B_BRK", "B_RET", "B_RCL",
               "K_SLOT", "K_LATE", "K_BOTH", "X_D2", "E_OPEN")
BR_ATTRS = ("br_jumpy",) + tuple(f"br_{v}_day" for v in BR_VARIANTS) + ("br_E_OPEN", "br_E_OPEN_exit")
ALSO_KEYS = ("also_day", "also_exit", "also_if")   # v1.7: the tree entry's keys that may name pick attributes
#   (B1: w = min(1.5, ref / semivol20); ref over 365 days, >= 50 picks
VOL_DIMS = (("RSJ10 at the pick (up minus down variance, 10 returns)", "pre_rsj10",
             ((-np.inf, -0.5, 0.5, np.inf), ("falls < -0.5", "MID", "rises >= +0.5")), "before"),
            ("Lower-circuit close in the 3 sessions to the pick", "pre_lock3", ((-np.inf, 0.5, np.inf), ("no", "yes")),
             "before"))


def base_dir(cli: Optional[str] = None) -> Optional[Path]:
    """setuplab's output folder: --setups, else SETUPLAB_OUT, else None (no tags)."""
    v = cli if cli else os.environ.get(ENV, "")
    return Path(v) if v else None


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _checked(run: Path, name: str) -> str:
    """The file's sha256 when it matches the run's outputs.sha256 ('<sha>  <name>' lines); refused otherwise."""
    p = run / name
    rec = {}
    hf = run / "outputs.sha256"
    if hf.is_file():
        for ln in hf.read_text(encoding="utf-8").splitlines():
            parts = ln.split("  ", 1)
            if len(parts) == 2:
                rec[parts[1].strip()] = parts[0].strip()
    sha = _sha(p)
    if rec.get(name) != sha:
        raise TLError(f"{p} does not match {hf} (recorded {str(rec.get(name))[:16]}, file {sha[:16]}) - refusing")
    return sha


def latest_tags(base: Path) -> Path:
    runs = sorted((Path(base) / "TAGS").glob("TAGS_*"))
    runs = [r for r in runs if (r / TAGS_FILE).is_file()]
    if not runs:
        raise TLError(f"no setup tags under {Path(base) / 'TAGS'} - run setuplab's tag command first "
                      f"(python setuplab.py tag --data ... --features ... --out {base})")
    return runs[-1]


def load_tags(base: Optional[Path], need: bool = False) -> Tuple[Optional[pd.DataFrame], dict]:
    """The newest tag run (setup_tags.parquet, hash-checked) and its TAGS.json. need=False: (None, why) when absent."""
    if base is None:
        if need:
            raise TLError(f"this needs the frozen setups' tags: pass --setups <setuplab output folder> or set {ENV} "
                          f"(env_tradelab.bat sets it)")
        return None, {"used": False, "why": f"no --setups and no {ENV}"}
    try:
        run = latest_tags(base)
    except TLError as e:
        if need:
            raise
        return None, {"used": False, "why": str(e)}
    p = run / TAGS_FILE
    sha = _checked(run, TAGS_FILE)
    meta = {}
    if (run / "TAGS.json").is_file():
        meta = json.loads((run / "TAGS.json").read_text(encoding="utf-8"))
    T = pd.read_parquet(p)
    T["trade_id"] = T["trade_id"].astype(str)
    ids = [s["id"] for s in meta.get("setups", [])] or sorted({c[3:].rsplit("_", 1)[0] for c in T.columns
                                                                if c.startswith("su_") and c.endswith("_day")})
    info = {"used": True, "run": run.name, "folder": str(run), "sha256": sha, "frozen_sha256": meta.get("frozen_sha256"),
            "setups": ids, "names": {s["id"]: s.get("name", "") for s in meta.get("setups", [])},
            "primary_exit": {s["id"]: s.get("primary_exit", "original_d5") for s in meta.get("setups", [])},
            "signal_days": meta.get("signal_days"), "picks": int(len(T)), "tool": meta.get("version")}
    return T, info


def refuse_tag_names(texts: Sequence[str], where: str) -> None:
    """A filter or rule that names a setup tag would decide on later sessions' closes: refused with the way out."""
    for t in texts:
        if not t:
            continue
        m = TAG_NAME.search(str(t))
        if m:
            if m.group(1).startswith("tree_") or m.group(1) == "opened_up":
                raise TLError(f"{where}: '{m.group(1)}' is an entry-tree column. The tree decides after the pick (the "
                              f"open, then each setup's own day), so a filter or rule cannot read it - it would look at "
                              f"sessions after the pick. To trade the tree, use the entry {{'name': 'tree', 'tree': True}} "
                              f"with the exit {{'name': 'tree', 'type': 'time', 'tree': True}}; 'calm' (the lane, known "
                              f"at the pick's close) may be filtered on.")
            raise TLError(f"{where}: '{m.group(1)}' is a setup tag. A setup is known only on its own entry day (its "
                          f"conditions are read at the close before it), so a filter or rule cannot read it - it would "
                          f"look at sessions after the pick. To trade a setup, use an entry leg such as "
                          f"{{'name': 's2', 'setup': 'S2'}}.")


def setup_days(tags: Optional[pd.DataFrame], ids: Sequence[str]) -> Dict[str, Dict[str, int]]:
    """trade_id -> {setup id: watch day it entered} (only the setups that entered)."""
    out: Dict[str, Dict[str, int]] = {}
    if tags is None:
        return out
    for sid in ids:
        col = f"su_{sid}_day"
        if col not in tags.columns:
            continue
        g = tags[["trade_id", col]].dropna()
        for t, d in zip(g["trade_id"], g[col]):
            out.setdefault(str(t), {})[sid] = int(d)
    return out


def tag_columns(df: pd.DataFrame, tags: Optional[pd.DataFrame], ids: Sequence[str], primary: Optional[dict] = None,
                nets: bool = False) -> pd.DataFrame:
    """df (with trade_id) + setups (e.g. 'S2@D3 C1@D3'), n_setups, su_<ID>_day; nets=True also su_<ID>_net (net % at
    the setup's primary exit). Picks the tag run does not cover get blank tags and setups_tagged = False."""
    X = df.copy()
    if tags is None:
        return X
    keep = ["trade_id", "setups", "n_setups"] + [f"su_{s}_day" for s in ids if f"su_{s}_day" in tags.columns]
    J = tags[keep].copy()
    if nets:
        for s in ids:
            pe = (primary or {}).get(s, "original_d5")
            col = f"su_{s}_net_{'d5' if pe == 'original_d5' else 'fresh'}"
            if col in tags.columns:
                J[f"su_{s}_net"] = tags[col].to_numpy()
    J["setups_tagged"] = True
    drop = [c for c in J.columns if c != "trade_id" and c in X.columns]
    X = X.drop(columns=drop).merge(J, on="trade_id", how="left")
    X["setups_tagged"] = X["setups_tagged"].astype("boolean").fillna(False).astype(bool)
    X["setups"] = X["setups"].astype(object).where(X["setups"].notna(), "")
    X["n_setups"] = pd.to_numeric(X["n_setups"], errors="coerce").fillna(0).astype(int)
    return X


# ---------------------------------------------------------------------------------------------------- the entry tree
def latest_tree(base: Path) -> Path:
    runs = sorted((Path(base) / "TREE").glob("TREE_*"))
    runs = [r for r in runs if (r / TREE_FILE).is_file()]
    if not runs:
        raise TLError(f"no entry-tree run under {Path(base) / 'TREE'} - run setuplab's tree command first "
                      f"(python setuplab.py tree --data ... --out {base})")
    return runs[-1]


def load_tree(base: Optional[Path], need: bool = False) -> Tuple[Optional[pd.DataFrame], dict]:
    """v1.2: the newest tree run (tree_tags.parquet, hash-checked) and its TREE_RUN.json. need=False: (None, why)."""
    if base is None:
        if need:
            raise TLError(f"this needs setuplab's entry tree: pass --setups <setuplab output folder> or set {ENV} "
                          f"(env_tradelab.bat sets it)")
        return None, {"used": False, "why": f"no --setups and no {ENV}"}
    try:
        run = latest_tree(base)
    except TLError as e:
        if need:
            raise
        return None, {"used": False, "why": str(e)}
    sha = _checked(run, TREE_FILE)
    meta = {}
    if (run / "TREE_RUN.json").is_file():
        meta = json.loads((run / "TREE_RUN.json").read_text(encoding="utf-8"))
    T = pd.read_parquet(run / TREE_FILE)
    T["trade_id"] = T["trade_id"].astype(str)
    if T["trade_id"].duplicated().any():
        raise TLError(f"{run / TREE_FILE}: a trade id appears twice - refusing")
    info = {"used": True, "run": run.name, "folder": str(run), "sha256": sha, "tree_sha256": meta.get("tree_sha256"),
            "frozen_sha256": meta.get("frozen_sha256"), "window": meta.get("window"),
            "reconciled": meta.get("reconciled"), "cutoffs": meta.get("cutoffs"), "picks": int(len(T)),
            "tool": meta.get("version")}
    return T, info


def reads_calm(raw: dict) -> bool:
    """A strategy (its raw dict) whose filter, rules or sizing expression read 'calm' (the tree's lane)."""
    texts = [str((raw.get("picks") or {}).get("filter") or ""), str((raw.get("sizing") or {}).get("expression") or "")]
    texts += [str(v) for v in (raw.get("events") or {}).values()]
    for d in list(raw.get("entries") or []) + list(raw.get("exits") or []):
        texts += [str(d.get(k) or "") for k in ("when", "level", "cancel_if", "activate")]
    return any(re.search(r"\bcalm\b", t) for t in texts)


def sde_series(c, n: int) -> np.ndarray:
    """SDE_n at every bar t of one close series: (c[t] - c[t-n]) / sum_{i=t-n+1..t} |c[i] - c[i-1]|; NaN for the first
    n bars, when the moves sum to 0, when a close inside the window is missing, or when one move exceeds SDE_JUMP."""
    c = np.asarray(c, float)
    out = np.full(len(c), np.nan)
    if len(c) <= n:
        return out
    d = np.diff(c)
    miss = ~np.isfinite(d)
    with np.errstate(divide="ignore", invalid="ignore"):
        jump = np.abs(c[1:] / c[:-1] - 1) > SDE_JUMP
    jump &= ~miss
    ad = np.where(miss, 0.0, np.abs(d))
    cs, cm, cj = (np.concatenate([[0.0], np.cumsum(x)]) for x in (ad, miss.astype(float), jump.astype(float)))
    t = np.arange(n, len(c))
    den = cs[t] - cs[t - n]
    with np.errstate(divide="ignore", invalid="ignore"):
        v = (c[t] - c[t - n]) / den
    bad = ~(den > 1e-12) | (cm[t] - cm[t - n] > 0) | (cj[t] - cj[t - n] > 0) | ~np.isfinite(v)
    v[bad] = np.nan
    out[t] = np.clip(v, -1.0, 1.0)
    return out


def add_sde(market, T: pd.DataFrame, log=None) -> Tuple[pd.DataFrame, dict]:
    """v1.4: T + pre_sde3 / 5 / 10 / 20 at each pick's signal-day close (blank: no bar that day, too little history,
    a flat or broken window). Returns (T, info with coverage)."""
    X = T.copy()
    n = len(X)
    vals = {c: np.full(n, np.nan) for c in SDE_PICK_ATTRS}
    if n:
        days = pd.to_datetime(X["signal_day"]).dt.normalize().to_numpy().astype("datetime64[D]")
        syms = X["symbol"].astype(str).to_numpy()
        for sym, idxs in pd.Series(np.arange(n)).groupby(syms):
            ds = market.series(sym)
            if ds is None or not len(ds):
                continue
            pos = np.array([ds.idx(days[j]) for j in idxs.to_numpy()], dtype=np.int64)
            ok = pos >= 0
            for h, col in zip(SDE_HORIZONS, SDE_PICK_ATTRS):
                srs = sde_series(ds.c, h)
                vals[col][idxs.to_numpy()[ok]] = srs[pos[ok]]
    for c in SDE_PICK_ATTRS:
        X[c] = vals[c]
    b = bucket_sde(X["pre_sde10"].to_numpy(float)) if n else np.array([], dtype=object)
    info = {"horizons": list(SDE_HORIZONS), "picks": int(n), "with_sde10": int(np.isfinite(vals["pre_sde10"]).sum()),
            "buckets": {k: int((b == k).sum()) for k in SDE_EDGES[1]}, "jump_guard": SDE_JUMP}
    if log:
        log(f"   SDE at the pick: SDE10 known for {info['with_sde10']:,} of {n:,} picks "
            f"({', '.join(f'{k} {v:,}' for k, v in info['buckets'].items())})")
    return X, info


def bucket_sde(v) -> np.ndarray:
    """SDE10 -> 'NEG < -0.5' / 'MID' / 'POS >= +0.5' (blank when unknown); edges as the breakdown's."""
    v = np.asarray(v, float)
    out = np.full(len(v), "", dtype=object)
    ok = np.isfinite(v)
    k = np.searchsorted(np.asarray(SDE_EDGES[0][1:-1], float), v[ok], side="right")
    out[ok] = np.asarray(SDE_EDGES[1], dtype=object)[k]
    return out


# ---------------------------------------------------------------------------------------------------- v1.5 volatility
def _roll(x, n: int, how: str, shift: int = 0) -> np.ndarray:
    s = pd.Series(np.asarray(x, float))
    if shift:
        s = s.shift(shift)
    return getattr(s.rolling(n, min_periods=n), how)().to_numpy(float)


def log_returns(c) -> np.ndarray:
    """r[t] = ln(c[t] / c[t-1]); blank when a close is missing / not positive or the move exceeds SDE_JUMP."""
    c = np.asarray(c, float)
    r = np.full(len(c), np.nan)
    if len(c) > 1:
        with np.errstate(divide="ignore", invalid="ignore"):
            ratio = c[1:] / c[:-1]
            rr = np.log(ratio)
        rr[~np.isfinite(rr) | ~(c[:-1] > 0) | (np.abs(ratio - 1) > SDE_JUMP)] = np.nan
        r[1:] = rr
    return r


def vol_arrays(o, h, l, c, v) -> Dict[str, np.ndarray]:
    """v1.5 (voldir VD1): every value at bar t is known at t's close. rsj10 (up minus down variance over the 10 returns
    to t, / their sum), turn_rel (10-session mean turnover / the median of the 120 sessions before them), lds10 (the
    largest of the 10 absolute moves / their sum), shock (a single fall >= 2 ATR14 among the 10 moves), ret20, atrp
    (ATR14 / close, simple mean of true ranges), semivol20 (sqrt(2 x mean(r^2 on down days)) over 20 returns), sde10."""
    o, h, l, c, v = (np.asarray(x, float) for x in (o, h, l, c, v))
    n = len(c)
    r = log_returns(c)
    fin = np.isfinite(r).astype(float)
    r2 = np.where(np.isfinite(r), r * r, 0.0)
    up, dn = np.where(r > 0, r2, 0.0), np.where(r < 0, r2, 0.0)
    c10, c20 = _roll(fin, 10, "sum"), _roll(fin, 20, "sum")
    su, sd = _roll(up, 10, "sum"), _roll(dn, 10, "sum")
    tot = su + sd
    with np.errstate(divide="ignore", invalid="ignore"):
        rsj = (su - sd) / tot
        rsj[~(c10 >= 10) | ~(tot > 0)] = np.nan
        ad = np.where(np.isfinite(r), np.abs(np.r_[np.nan, np.diff(c)]), 0.0)
        mx, sm = _roll(ad, 10, "max"), _roll(ad, 10, "sum")
        lds = mx / sm
        lds[~(c10 >= 10) | ~(sm > 0)] = np.nan
        pc = np.r_[np.nan, c[:-1]]
        tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
        if n:
            tr[0] = h[0] - l[0]
        atr = _roll(tr, 14, "mean")
        atrp = atr / c
        shock_v = _roll(pc - c, 10, "max") / atr
        shock = np.where(np.isfinite(shock_v), (shock_v >= 2.0).astype(float), np.nan)
        ret20 = np.full(n, np.nan)
        if n > 20:
            ret20[20:] = c[20:] / c[:-20] - 1
        ret20[~(c20 >= 20)] = np.nan
        semi = np.sqrt(2.0 * _roll(dn, 20, "mean"))
        semi[~(c20 >= 20)] = np.nan
        tv = c * v
        den = _roll(tv, 120, "median", shift=10)
        trel = _roll(tv, 10, "mean") / den
        trel[~(den > 0)] = np.nan
    return {"r": r, "rsj10": rsj, "turn_rel": trel, "lds10": lds, "shock": shock, "ret20": ret20, "atrp": atrp,
            "semivol20": semi, "sde10": sde_series(c, 10)}


def lower_locks(ds) -> np.ndarray:
    """Closes locked at the lower circuit by production's rule (asked only where the close is the day's low)."""
    c, l = np.asarray(ds.c, float), np.asarray(ds.l, float)
    lc = np.zeros(len(c), bool)
    for i in np.flatnonzero(c <= l * (1 + 1e-9)):
        lc[i] = bool(ds.locked(int(i), "close"))
    return lc


def lock3_of(lc) -> np.ndarray:
    """A lower-locked close on t-2, t-1 or t."""
    lc = np.asarray(lc, bool)
    out = lc.copy()
    out[1:] |= lc[:-1]
    out[2:] |= lc[:-2]
    return out


def cut_flags(rsj10, turn_rel, atrp, ret20, C: Optional[pd.DataFrame]) -> Dict[str, np.ndarray]:
    """1 / 0 / blank flags against the day's cross-section (voldir's daily_cuts rows aligned with the values)."""
    n = len(np.asarray(rsj10))
    if C is None:
        return {k: np.full(n, np.nan) for k in VOL_CUT_ATTRS}

    def cmp(a, b, ge):
        a, b = np.asarray(a, float), np.asarray(b, float)
        ok = np.isfinite(a) & np.isfinite(b)
        with np.errstate(invalid="ignore"):
            return np.where(ok, ((a >= b) if ge else (a <= b)).astype(float), np.nan)

    g = {k: C[k].to_numpy(float) for k in CUT_COLS}
    return {"pre_rsj_lo": cmp(rsj10, g["rsj10_p10"], False), "pre_rsj_hi": cmp(rsj10, g["rsj10_p90"], True),
            "pre_turn_lo": cmp(turn_rel, g["turn_rel_p33"], False), "pre_turn_hi": cmp(turn_rel, g["turn_rel_p67"], True),
            "pre_atr_hi": cmp(atrp, g["atrp_p67"], True), "pre_ret20_top": cmp(ret20, g["ret20_p90"], True),
            "pre_mvol_high": g["mvol_high"].astype(float), "pre_mvol_falling": g["mvol_falling"].astype(float)}


def load_cuts(path: Optional[str]) -> Tuple[Optional[pd.DataFrame], dict]:
    """v1.5: voldir's daily cross-sectional cuts (a VD run folder or its daily_cuts.parquet; hash-checked against the
    run's outputs.sha256), indexed by day. None given: (None, why)."""
    if not path:
        return None, {"used": False, "why": "no --voldir"}
    p = Path(path)
    run = p if p.is_dir() else p.parent
    if not (run / CUTS_FILE).is_file():
        raise TLError(f"--voldir {path}: no {CUTS_FILE} there (give a voldir run folder, ...\\runs\\VD_<date>_<nnn>)")
    sha = _checked(run, CUTS_FILE)
    meta = json.loads((run / "run.json").read_text(encoding="utf-8")) if (run / "run.json").is_file() else {}
    C = pd.read_parquet(run / CUTS_FILE)
    miss = [k for k in ("date",) + CUT_COLS if k not in C.columns]
    if miss:
        raise TLError(f"{run / CUTS_FILE}: columns {miss} missing - refusing")
    C = C.assign(date=pd.to_datetime(C["date"]).dt.normalize()).drop_duplicates("date").set_index("date").sort_index()
    return C, {"used": True, "run": run.name, "folder": str(run), "sha256": sha, "tool": meta.get("tool"),
               "declaration_sha256": meta.get("declaration_sha256"), "days": int(len(C))}


def load_jm(path: Optional[str]) -> Tuple[Optional[pd.DataFrame], dict]:
    """v1.6: jumplab's scores (a JL run folder or its jm_scores.parquet; hash-checked against the run's
    outputs.sha256), indexed by trade_id. None given: (None, why)."""
    if not path:
        return None, {"used": False, "why": "no --jumplab"}
    p = Path(path)
    run = p if p.is_dir() else p.parent
    if not (run / JM_FILE).is_file():
        raise TLError(f"--jumplab {path}: no {JM_FILE} there (give a jumplab run folder, ...\\runs\\JL_<date>_<nnn>)")
    sha = _checked(run, JM_FILE)
    meta = json.loads((run / "run.json").read_text(encoding="utf-8")) if (run / "run.json").is_file() else {}
    J = pd.read_parquet(run / JM_FILE)
    miss = [k for k in ("trade_id",) + JM_ATTRS if k not in J.columns]
    if miss:
        raise TLError(f"{run / JM_FILE}: columns {miss} missing - refusing")
    if J["trade_id"].duplicated().any():
        raise TLError(f"{run / JM_FILE}: a trade_id appears twice - refusing")
    return J.set_index("trade_id"), {"used": True, "run": run.name, "folder": str(run), "sha256": sha,
                                     "tool": meta.get("tool"), "declaration_sha256": meta.get("declaration_sha256"),
                                     "rows": int(len(J))}


def add_jm(T: pd.DataFrame, J: Optional[pd.DataFrame], log=None) -> Tuple[pd.DataFrame, dict]:
    """v1.6: T + jumplab's scores per pick (JM_ATTRS; blank without --jumplab or for a pick it did not score).
    Reports how often jumplab's lane (jm_jumpy) agrees with the tree's (calm) where both are known."""
    X = T.copy()
    info = {"picks": int(len(X)), "scored": 0, "lane_checked": 0, "lane_agree": 0}
    if J is None:
        for k in JM_ATTRS:
            X[k] = np.nan
        return X, info
    S = J.reindex(X["trade_id"].astype(str))
    for k in JM_ATTRS:
        X[k] = pd.to_numeric(S[k], errors="coerce").to_numpy(float)
    info["scored"] = int(np.isfinite(X["jm_jumpy"].to_numpy(float)).sum())
    if "calm" in X.columns:
        c, j = X["calm"].to_numpy(float), X["jm_jumpy"].to_numpy(float)
        m = np.isfinite(c) & np.isfinite(j)
        info["lane_checked"], info["lane_agree"] = int(m.sum()), int(((c[m] == 0) == (j[m] == 1)).sum())
    if log:
        log(f"   jumplab scores on {info['scored']:,} of {info['picks']:,} picks; its lane agrees with the tree's on "
            f"{info['lane_agree']:,} of {info['lane_checked']:,}")
    return X, info


def load_br(path: Optional[str]) -> Tuple[Optional[pd.DataFrame], dict]:
    """v1.7: branchlab's per-pick days (a BR run folder or its br_scores.parquet; hash-checked against the run's
    outputs.sha256), indexed by trade_id; run.json names the tree run they were built from. None given: (None, why)."""
    if not path:
        return None, {"used": False, "why": "no --branchlab"}
    p = Path(path)
    run = p if p.is_dir() else p.parent
    if not (run / BR_FILE).is_file():
        raise TLError(f"--branchlab {path}: no {BR_FILE} there (give a branchlab run folder, ...\\runs\\BR_<date>_<nnn>)")
    sha = _checked(run, BR_FILE)
    meta = json.loads((run / "run.json").read_text(encoding="utf-8")) if (run / "run.json").is_file() else {}
    B = pd.read_parquet(run / BR_FILE)
    miss = [k for k in ("trade_id",) + BR_ATTRS if k not in B.columns]
    if miss:
        raise TLError(f"{run / BR_FILE}: columns {miss} missing - refusing")
    B["trade_id"] = B["trade_id"].astype(str)
    if B["trade_id"].duplicated().any():
        raise TLError(f"{run / BR_FILE}: a trade_id appears twice - refusing")
    days = B[[f"br_{v}_day" for v in BR_VARIANTS]].to_numpy(float)
    ok = ~np.isfinite(days) | ((days >= 1) & (days <= 5) & (np.floor(days) == days))
    if not ok.all():
        raise TLError(f"{run / BR_FILE}: a day outside 1..5 - refusing")
    return B.set_index("trade_id"), {"used": True, "run": run.name, "folder": str(run), "sha256": sha,
                                     "tool": meta.get("tool"), "declaration_sha256": meta.get("declaration_sha256"),
                                     "tree_sha256": meta.get("tree_run_sha256"), "tree_run": meta.get("tree_run"),
                                     "rows": int(len(B))}


def add_br(T: pd.DataFrame, B: Optional[pd.DataFrame], binfo: Optional[dict] = None, trinfo: Optional[dict] = None,
           log=None) -> Tuple[pd.DataFrame, dict]:
    """v1.7: T + branchlab's days per pick (BR_ATTRS; blank without --branchlab or for a pick it did not cover). The run
    must have been built from the tree run tradelab reads (the same tree_tags.parquet sha256), and its jumpy flag may
    never contradict the tree's lane (br_jumpy 1 on a CALM pick) - else refused."""
    X = T.copy()
    info = {"picks": int(len(X)), "covered": 0, "jumpy": 0}
    if B is None:
        for k in BR_ATTRS:
            X[k] = np.nan
        return X, info
    if not (trinfo or {}).get("used"):
        raise TLError("branchlab's days change the entry tree's plan: they need setuplab's tree run too (--setups or "
                      f"{ENV})")
    have, want = (binfo or {}).get("tree_sha256"), trinfo.get("sha256")
    if not have or have != want:
        raise TLError(f"the branchlab run {(binfo or {}).get('run')} was built from tree run "
                      f"{(binfo or {}).get('tree_run')} (tree_tags sha256 {str(have)[:16]}), but tradelab reads "
                      f"{trinfo.get('run')} ({str(want)[:16]}) - rebuild it (python branchlab.py run) - refusing")
    S = B.reindex(X["trade_id"].astype(str))
    for k in BR_ATTRS:
        X[k] = pd.to_numeric(S[k], errors="coerce").to_numpy(float)
    info["covered"] = int(X["trade_id"].astype(str).isin(B.index).sum())
    info["jumpy"] = int((X["br_jumpy"].to_numpy(float) == 1).sum())
    if "calm" in X.columns:
        c, j = X["calm"].to_numpy(float), X["br_jumpy"].to_numpy(float)
        bad = int(((c == 1) & (j == 1)).sum())
        if bad:
            raise TLError(f"branchlab marks {bad} CALM tree picks as jumpy - its run was not built from this tree run")
    if log:
        log(f"   branchlab days on {info['covered']:,} of {info['picks']:,} picks ({info['jumpy']:,} jumpy)")
    return X, info


def also_counts(T: pd.DataFrame, day_attr: str, mode: str) -> dict:
    """v1.7, for the report: of the picks with a day in day_attr, how many the tree never buys, how many it buys later,
    on the same day or earlier (T carries _tree)."""
    out = {"with_day": 0, "tree_skips": 0, "before_tree": 0, "same_day": 0, "after_tree": 0}
    if day_attr not in T.columns or "_tree" not in T.columns:
        return out
    for v, tr in zip(T[day_attr].to_numpy(float), T["_tree"]):
        if not np.isfinite(v):
            continue
        out["with_day"] += 1
        d = (tr or {}).get("day")
        if not d:
            out["tree_skips"] += 1
        elif v < d:
            out["before_tree"] += 1
        elif v == d:
            out["same_day"] += 1
        else:
            out["after_tree"] += 1
    return out


def reads_any(raw: dict, names: Sequence[str]) -> List[str]:
    """The names (of `names`) that a strategy's filter, rules, sizing expression, open_if, veto_if or also_* read."""
    texts = [str((raw.get("picks") or {}).get("filter") or ""), str((raw.get("sizing") or {}).get("expression") or "")]
    texts += [str(v) for v in (raw.get("events") or {}).values()]
    for d in list(raw.get("entries") or []) + list(raw.get("exits") or []):
        texts += [str(d.get(k) or "") for k in ("when", "level", "cancel_if", "activate", "open_if", "veto_if")
                  + ALSO_KEYS]
    return [nm for nm in names if any(re.search(rf"\b{nm}\b", t) for t in texts)]


def semivol_weights(T: pd.DataFrame) -> np.ndarray:
    """B1's weight per pick: min(SEMI_CAP, ref / pre_semivol20), ref = the median pre_semivol20 of the same engine's
    picks in T over the SEMI_DAYS calendar days before the pick day (strictly before; at least SEMI_MIN), else 1.0;
    a pick without semivol20: 1.0."""
    n = len(T)
    w = np.ones(n)
    if not n or "pre_semivol20" not in T.columns:
        return w
    day = pd.to_datetime(T["signal_day"]).dt.normalize().to_numpy().astype("datetime64[D]").astype(np.int64)
    sv = T["pre_semivol20"].to_numpy(float)
    eng = T["engine"].astype(str).to_numpy() if "engine" in T.columns else np.full(n, "")
    for e in np.unique(eng):
        ix = np.flatnonzero(eng == e)
        o = ix[np.argsort(day[ix], kind="mergesort")]
        dd, vv = day[o], sv[o]
        for d in np.unique(dd):
            a, b = np.searchsorted(dd, d - SEMI_DAYS), np.searchsorted(dd, d)
            win = vv[a:b]
            win = win[np.isfinite(win)]
            if len(win) < SEMI_MIN:
                continue
            ref = float(np.median(win))
            k = o[dd == d]
            s_ = sv[k]
            with np.errstate(divide="ignore", invalid="ignore"):
                w[k] = np.where(np.isfinite(s_) & (s_ > 0), np.minimum(SEMI_CAP, ref / s_), 1.0)
    return w


class VolDay:
    """v1.5: the volatility values of a stock at any of its bars (for a veto read at a buy's signal close) - the same
    arrays add_vol reads at the pick. Arrays are built once per symbol."""

    def __init__(self, cuts: Optional[pd.DataFrame]):
        self.cuts = cuts
        self._a: Dict[str, Dict[str, np.ndarray]] = {}

    def arrays(self, ds) -> Dict[str, np.ndarray]:
        A = self._a.get(ds.sym)
        if A is None:
            A = vol_arrays(ds.o, ds.h, ds.l, ds.c, ds.v)
            A["lock3"] = lock3_of(lower_locks(ds))
            if self.cuts is not None:
                C = self.cuts.reindex(pd.DatetimeIndex(ds.dates.astype("datetime64[ns]")))
                A.update(cut_flags(A["rsj10"], A["turn_rel"], A["atrp"], A["ret20"], C))
            else:
                A.update(cut_flags(A["rsj10"], A["turn_rel"], A["atrp"], A["ret20"], None))
            self._a[ds.sym] = A
        return A

    def values(self, ds, i: int) -> Dict[str, float]:
        A = self.arrays(ds)
        if not (0 <= i < len(ds)):
            return {k: np.nan for k in VOL_DAY_ATTRS}
        out = {"pre_sde10": float(A["sde10"][i]), "pre_lock3": float(A["lock3"][i])}
        for k in VOL_ATTRS:
            if k not in out:
                out[k] = float(A[k[4:]][i])
        for k in VOL_CUT_ATTRS:
            out[k] = float(A[k][i])
        return out


def add_vol(market, T: pd.DataFrame, cuts: Optional[pd.DataFrame] = None, log=None) -> Tuple[pd.DataFrame, dict]:
    """v1.5: T + the volatility values at each pick's signal-day close (VOL_ATTRS), the day's cross-section flags
    (VOL_CUT_ATTRS, blank without voldir's cuts) and B1's weight pre_semivol_w. Returns (T, info)."""
    X = T.copy()
    n = len(X)
    vals = {k: np.full(n, np.nan) for k in VOL_ATTRS + VOL_CUT_ATTRS}
    vd = VolDay(cuts)
    if n:
        days = pd.to_datetime(X["signal_day"]).dt.normalize().to_numpy().astype("datetime64[D]")
        syms = X["symbol"].astype(str).to_numpy()
        for sym, idxs in pd.Series(np.arange(n)).groupby(syms):
            ds = market.series(sym)
            if ds is None or not len(ds):
                continue
            ii = idxs.to_numpy()
            pos = np.array([ds.idx(days[j]) for j in ii], dtype=np.int64)
            ok = pos >= 0
            A = vd.arrays(ds)
            for k in VOL_ATTRS:
                vals[k][ii[ok]] = A["lock3" if k == "pre_lock3" else k[4:]][pos[ok]].astype(float)
            for k in VOL_CUT_ATTRS:
                vals[k][ii[ok]] = A[k][pos[ok]]
            vd._a.pop(sym, None)
    for k, v in vals.items():
        X[k] = v
    X["pre_semivol_w"] = semivol_weights(X)
    info = {"picks": int(n), "with_rsj10": int(np.isfinite(vals["pre_rsj10"]).sum()),
            "with_semivol20": int(np.isfinite(vals["pre_semivol20"]).sum()),
            "lock3": int(np.nansum(vals["pre_lock3"])), "cuts": cuts is not None,
            "weights_not_1": int((np.abs(X["pre_semivol_w"].to_numpy(float) - 1) > 1e-12).sum())}
    if log:
        log(f"   volatility at the pick: RSJ10 known for {info['with_rsj10']:,} of {n:,} picks, lower lock in the last 3 "
            f"sessions on {info['lock3']:,}; day cross-section flags {'from voldir' if cuts is not None else 'blank (no --voldir)'}")
    return X, info


def tree_frame(tree: pd.DataFrame) -> pd.DataFrame:
    """The tree run as tradelab's columns (one row per trade id): lane, lane_atr14 / lane_cutoff (ATR14 / close and
    the year's cut-off, fractions), calm, opened_up, tree_action, tree_how ('open', 'S2@D3' or blank), tree_net (net %
    of the tree's own trade on the pick: the D5 close for 'open', the setup's primary exit for a setup; blank =
    not traded by the tree)."""
    lane = tree["lane"].fillna("").astype(str).to_numpy()
    how = tree["how"].fillna("").astype(str).to_numpy()
    d1 = pd.to_numeric(tree["d1_net"], errors="coerce").to_numpy(float)
    sn = pd.to_numeric(tree["setup_net"], errors="coerce").to_numpy(float)
    gap = pd.to_numeric(tree["gap_pct"], errors="coerce").to_numpy(float)
    up = tree["opened_up"].astype("boolean").fillna(False).to_numpy(bool)
    return pd.DataFrame({
        "trade_id": tree["trade_id"].astype(str).to_numpy(), "lane": lane,
        "lane_atr14": pd.to_numeric(tree["s_atr14"], errors="coerce").to_numpy(float),
        "lane_cutoff": pd.to_numeric(tree["cutoff"], errors="coerce").to_numpy(float),
        "calm": np.where(lane == "CALM", 1.0, np.where(lane == "JUMPY", 0.0, np.nan)),
        "opened_up": np.where(np.isfinite(gap), up, None),          # blank = the open is not known
        "tree_action": tree["action"].fillna("").astype(str).to_numpy(), "tree_how": how,
        "tree_net": np.where(how == "open", d1, np.where(how != "", sn, np.nan)),
        "tree_etf": tree["etf"].astype("boolean").fillna(False).to_numpy(bool) if "etf" in tree.columns
        else np.zeros(len(tree), dtype=bool)})


def tree_columns(df: pd.DataFrame, tree: Optional[pd.DataFrame], cols: Sequence[str] = tuple(TREE_COLS)) -> pd.DataFrame:
    """df (with trade_id) + the tree's columns; picks the tree run does not cover: blank, tree_tagged = False."""
    X = df.copy()
    if tree is None:
        return X
    J = tree_frame(tree)
    J["tree_tagged"] = True
    J = J[["trade_id"] + [c for c in cols if c in J.columns]]
    drop = [c for c in J.columns if c != "trade_id" and c in X.columns]
    tid = X["trade_id"].astype(str)
    X = X.drop(columns=drop).assign(trade_id=tid).merge(J, on="trade_id", how="left")
    if "tree_tagged" in X:
        X["tree_tagged"] = X["tree_tagged"].astype("boolean").fillna(False).astype(bool)
    for c in ("lane", "tree_action", "tree_how"):
        if c in X:
            X[c] = X[c].astype(object).where(X[c].notna(), "")
    return X


def tree_entries(T: pd.DataFrame, tree: pd.DataFrame, tags: Optional[pd.DataFrame], tinfo: dict,
                 trinfo: dict) -> List[dict]:
    """trade_id -> the tree's own trade on the pick, for the entry leg {"tree": True}: {"day": the watch day it buys at
    the open (1 = the pick's first session), "exit": the session whose close sells it, "how": ...}; {} = the tree does
    not trade the pick. 'open' and S1-S3 / C1-C3 sell at the 5th close; a 'fresh' setup (N1) 4 sessions after its
    entry. Every setup entry is checked against setuplab's setup tags (the same day) - one source of truth."""
    if tags is None:
        raise TLError("the tree's setup entries need the setup tags too (setuplab's TAGS run)")
    if trinfo.get("frozen_sha256") and tinfo.get("frozen_sha256") and trinfo["frozen_sha256"] != tinfo["frozen_sha256"]:
        raise TLError(f"the tree run {trinfo.get('run')} was built on freeze {str(trinfo['frozen_sha256'])[:16]} but "
                      f"the tags {tinfo.get('run')} on {str(tinfo['frozen_sha256'])[:16]} - refusing")
    TF = tree_frame(tree).set_index("trade_id")
    tids_s = T["trade_id"].astype(str)
    how = tids_s.map(TF["tree_how"]).fillna("").astype(str)
    covered = tids_s.isin(TF.index).to_numpy()
    etf = tids_s.map(TF["tree_etf"]).fillna(False).astype(bool).to_numpy()
    m = how.str.fullmatch(r"([A-Z][0-9]+)@D([1-5])")
    bad_fmt = how[(how != "") & (how != "open") & ~m]
    if len(bad_fmt):
        raise TLError(f"tree run {trinfo.get('run')}: unreadable 'how' {bad_fmt.iloc[0]!r} on {bad_fmt.index[0]}")
    parts = how.str.extract(r"^([A-Z][0-9]+)@D([1-5])$")
    sid, k = parts[0].fillna(""), pd.to_numeric(parts[1], errors="coerce")
    unknown = sorted(set(sid[sid != ""]) - set(tinfo.get("setups", [])))
    if unknown:
        raise TLError(f"tree run {trinfo.get('run')} buys through {unknown}, which the tags {tinfo.get('run')} do not hold")
    sd = setup_days(tags, tinfo.get("setups", []))
    tids = T["trade_id"].astype(str).to_numpy()
    wrong = [t for t, s_, kk in zip(tids, sid, k) if s_ and sd.get(t, {}).get(s_) != int(kk)]
    if wrong:
        raise TLError(f"the tree run {trinfo.get('run')} and the tags {tinfo.get('run')} disagree on {len(wrong)} setup "
                      f"entries (e.g. {wrong[0]}: tree {how[T['trade_id'].astype(str) == wrong[0]].iloc[0]}, tags "
                      f"{sd.get(wrong[0])}) - refusing")
    prim = tinfo.get("primary_exit", {})
    out = []
    for h, s_, kk, cv, ef in zip(how, sid, k, covered, etf):
        base = {"tagged": True, "etf": bool(ef)} if cv else {}
        if h == "open":
            out.append(dict(base, day=1, exit=5, how=h))
        elif s_:
            kk = int(kk)
            out.append(dict(base, day=kk, exit=kk + TREE_HOLD - 1 if prim.get(s_) == "fresh" else 5, how=h))
        else:
            out.append(base)
    return out


# ---------------------------------------------------------------------------------------------------- the nightly scan
def scan_path(base: Optional[Path], day) -> Optional[Path]:
    if base is None:
        return None
    return Path(base) / "scan" / f"scan_{pd.Timestamp(day):%Y%m%d}.csv"


def read_scan(base: Optional[Path], day) -> Tuple[Optional[pd.DataFrame], dict]:
    """The scan of one evening (setuplab scan) and whether its ledger record was on time."""
    p = scan_path(base, day)
    if p is None:
        return None, {"found": False, "why": f"no --setups and no {ENV}"}
    if not p.is_file():
        return None, {"found": False, "file": str(p), "why": "no setup scan for this evening (run_tonight.bat runs it "
                                                              "before the watch page)"}
    S = pd.read_csv(p, dtype={"trade_id": str})
    info = {"found": True, "file": str(p), "sha256": _sha(p), "rows": int(len(S)), "on_time": None}
    lp = Path(base) / "scan" / "setup_ledger.jsonl"
    if lp.is_file():
        d = f"{pd.Timestamp(day):%Y-%m-%d}"
        for ln in lp.read_text(encoding="utf-8").splitlines():
            try:
                r = json.loads(ln)
            except json.JSONDecodeError:
                continue
            if r.get("event") == "scan" and r.get("scan_date") == d:
                info.update({"on_time": bool(r.get("on_time")), "recorded_at": r.get("recorded_at"),
                             "frozen_sha256": r.get("frozen_sha256")})
                break
    return S, info


def int_text(x) -> str:
    """A watch day from a CSV cell (int, float or blank) as text: 3 / 3.0 -> '3', blank / NaN -> ''."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    return str(int(v)) if np.isfinite(v) else ""


def scan_words(r: dict) -> str:
    """One scan row in words for the watch page (v1.1: with its zone, when setuplab's zones file names one)."""
    st = str(r.get("status") or "")
    sid = str(r.get("setup") or "")
    z = str(r.get("zone") or "")
    zw = {"IN": " (in its zone)", "OUT": " (outside its zone)"}.get(z, "")
    if st == "FIRES":
        return f"{sid} buy at the open{zw}"
    if st == "ARMED":
        return f"{sid} buy at the open only if {r.get('rule_at_open') or 'the open meets its rule'}{zw}"
    if st == "ENTERED":
        try:
            px = f" at {float(r.get('entry')):.2f}"
        except (TypeError, ValueError):
            px = ""
        return f"{sid} entered D{int_text(r.get('entered_day'))}{px}{zw}"
    return ""


def pick_setups_text(S: Optional[pd.DataFrame], engine: str, rank: int, symbol: str, day) -> str:
    """The setups column of one of tonight's picks: what fires / is armed at the next open."""
    if S is None or S.empty:
        return ""
    d = f"{pd.Timestamp(day):%Y-%m-%d}"
    g = S[(S["engine"].astype(str) == str(engine)) & (pd.to_numeric(S["rank"], errors="coerce") == int(rank)) &
          (S["symbol"].astype(str) == str(symbol)) & (S["signal_day"].astype(str) == d) &
          (S["status"].isin(["FIRES", "ARMED"]))]
    rec = g.to_dict("records")
    fires = [r for r in rec if r["status"] == "FIRES"]
    zw = {"IN": " in zone", "OUT": " outside zone"}
    bits = [("BUY at the open: " + ", ".join(f"{r['setup']}{zw.get(str(r.get('zone') or ''), '')}" for r in fires))] \
        if fires else []
    bits += [f"{r['setup']}{zw.get(str(r.get('zone') or ''), '')} only if {r.get('rule_at_open') or 'the open meets its rule'}"
             for r in rec if r["status"] == "ARMED"]
    return "; ".join(bits)


def _day_txt(d) -> str:
    try:
        return f"{pd.Timestamp(d):%d %b}".lstrip("0")
    except (TypeError, ValueError):
        return str(d or "")


def _px(x) -> str:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return ""
    return f"{v:.2f}" if np.isfinite(v) else ""


def _int(x) -> Optional[int]:
    t = int_text(x)
    return int(t) if t else None


def read_tree_night(base: Optional[Path], day) -> dict:
    """v1.3: the entry tree's record of this evening (scan\\tree_ledger.jsonl, event 'tree'), every pick's lane from all
    records up to this evening, and the tree books (scan\\tree_book.csv) when this evening's record exists."""
    out = {"found": False, "rec": None, "lanes": {}, "book": None}
    if base is None:
        return out
    tl = Path(base) / "scan" / "tree_ledger.jsonl"
    if not tl.is_file():
        return out
    d = f"{pd.Timestamp(day):%Y-%m-%d}"
    newest = ""
    for ln in tl.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(ln)
        except json.JSONDecodeError:
            continue
        if r.get("event") != "tree":
            continue
        newest = max(newest, str(r.get("scan_date")))
        if str(r.get("scan_date")) > d:
            continue
        for pk in r.get("picks") or []:
            out["lanes"][str(pk.get("trade_id"))] = str(pk.get("lane") or "")
        if r.get("scan_date") == d:
            out.update({"found": True, "rec": r})
    bk = Path(base) / "scan" / "tree_book.csv"       # rewritten by every scan: tonight's only if no later scan ran
    if out["found"] and newest == d and bk.is_file():
        out["book"] = pd.read_csv(bk, dtype={"trade_id": str})
    return out


def _pick_key(r: dict) -> Tuple[str, int, str]:
    return str(r.get("engine")), int(float(r.get("rank"))), str(r.get("signal_day"))


def _pick_name(e: str, k: int, sd: str) -> str:
    return f"{e} #{k} ({_day_txt(sd)} pick)"


def next_open_groups(S: Optional[pd.DataFrame], tree: Optional[dict] = None) -> List[dict]:
    """v1.3: one row per stock for the next open - every FIRES / ARMED setup of every pick of the stock, folded, plus
    the entry tree's orders (each tree book buys a stock once) and the stock's lane."""
    tree = tree or {}
    rec = tree.get("rec") or {}
    lanes = tree.get("lanes") or {}
    orders = rec.get("orders") or {}
    picks = {str(p.get("trade_id")): p for p in rec.get("picks") or []}
    G: Dict[str, dict] = {}

    def grp(sym):
        return G.setdefault(sym, {"symbol": sym, "lane": "", "tree": [], "picks": {}, "fires": False, "rules": [],
                                  "close": np.nan, "zones": {}})
    if S is not None and len(S):
        A = S[S["status"].isin(["FIRES", "ARMED"])].copy()
        for c in ("close_tonight", "zone", "rule_at_open", "next_watch_day", "trade_id"):
            if c not in A.columns:
                A[c] = np.nan
        for r in A.sort_values(["engine", "rank", "setup"]).to_dict("records"):
            g = grp(str(r["symbol"]))
            pk = _pick_key(r)
            g["picks"].setdefault(pk, {"fires": [], "armed": [], "wd": _int(r.get("next_watch_day"))})
            z = {"IN": " in zone", "OUT": " outside zone"}.get(str(r.get("zone") or ""), "")
            if r["status"] == "FIRES":
                g["picks"][pk]["fires"].append(f"{r['setup']}{z}")
                g["fires"] = True
            else:
                rule = str(r.get("rule_at_open") or "the open meets its rule")
                g["picks"][pk]["armed"].append(f"{r['setup']}{z} if {rule}")
                if rule not in g["rules"]:
                    g["rules"].append(rule)
            if not np.isfinite(g["close"]):
                try:
                    g["close"] = float(r.get("close_tonight"))
                except (TypeError, ValueError):
                    pass
            ln = lanes.get(str(r.get("trade_id")), "")
            if ln and not g["lane"]:
                g["lane"] = ln
    dl = [str(t) for t in orders.get("D_calm_in_rank_order") or []]
    for j, t in enumerate(dl):
        p = picks.get(t, {})
        g = grp(str(p.get("symbol", t)))
        g["lane"] = g["lane"] or str(p.get("lane") or "")
        thr = _px(p.get("close"))
        g["tree"].append(f"D tree: buy at the open if it opens at or above {thr or 'its close'}"
                         + ("" if len(dl) == 1 else f" and no calm pick before it in the list did (#{j + 1} of {len(dl)})"))
        if not np.isfinite(g["close"]):
            g["close"] = float(p.get("close")) if p.get("close") is not None else np.nan
    for t in [str(t) for t in orders.get("ENS_calm_at_open") or []]:
        p = picks.get(t, {})
        g = grp(str(p.get("symbol", t)))
        g["lane"] = g["lane"] or str(p.get("lane") or "")
        g["tree"].append("ENS tree: BUY at the open (calm)")
        if not np.isfinite(g["close"]) and p.get("close") is not None:
            g["close"] = float(p.get("close"))
    sym_of = {}
    if S is not None and len(S):
        sym_of = dict(zip(S["trade_id"].astype(str), S["symbol"].astype(str))) if "trade_id" in S.columns else {}
    for b in orders.get("setup_buys") or []:
        t = str(b.get("trade_id"))
        sym = picks.get(t, {}).get("symbol") or sym_of.get(t)
        if not sym:
            continue
        g = grp(str(sym))
        rule = "" if b.get("status") == "FIRES" else f" if {b.get('rule_at_open')}"
        txt = f"{b.get('engine')} tree: buy through {b.get('setup')}{rule}" + \
              (" - unless that open makes it the D calm buy" if b.get("unless_calm_buy") else "")
        if txt not in g["tree"]:
            g["tree"].append(txt)
    out = []
    for sym, g in G.items():
        lines = []
        for (e, k, sd), v in g["picks"].items():
            bits = ([f"BUY {', '.join(v['fires'])}"] if v["fires"] else []) + v["armed"]
            lines.append(f"{_pick_name(e, k, sd)}" + (f", watch day {v['wd']}" if v["wd"] else "") + ": " + "; ".join(bits))
        do = ("BUY at the open" if g["fires"] else
              ("BUY at the open only if " + " or ".join(g["rules"]) if g["rules"] else ""))
        out.append({"symbol": sym, "lane": g["lane"], "tree": g["tree"], "setups": lines, "do": do,
                    "close": g["close"], "n_rows": sum(len(v["fires"]) + len(v["armed"]) for v in g["picks"].values())})
    return sorted(out, key=lambda x: (not x["tree"], x["do"] != "BUY at the open", x["symbol"]))


def _when_order(w: str) -> int:
    if w.startswith("tomorrow"):
        return 1
    m = re.search(r"in (\d+) sessions", w)
    return int(m.group(1)) if m else 99


def held_groups(S: Optional[pd.DataFrame]) -> List[dict]:
    """v1.3: the frozen setups' open positions, one row per position (stock + entry day + entry price): every setup and
    pick that bought it, and when each sells (original_d5 = the pick's D5 close; fresh = 4 sessions after entry)."""
    if S is None or S.empty:
        return []
    E = S[S["status"] == "ENTERED"].copy()
    if E.empty:
        return []
    for c in ("entry_date", "entry", "mark_pct", "primary_exit", "next_watch_day", "entered_day"):
        if c not in E.columns:
            E[c] = np.nan
    E["entry_date"] = E["entry_date"].astype(object).where(E["entry_date"].notna(), "")
    E["_px"] = pd.to_numeric(E["entry"], errors="coerce").round(4)
    out = []
    for (sym, ed, px), g in E.groupby(["symbol", "entry_date", "_px"], sort=False, dropna=False):
        lines, sells = [], {}
        for pk, h in g.groupby(["engine", "rank", "signal_day"], sort=False):
            e, k, sd = str(pk[0]), int(float(pk[1])), str(pk[2])
            kd = _int(h["entered_day"].iloc[0])
            lines.append(f"{_pick_name(e, k, sd)}" + (f", watch day {kd}" if kd else "") + ": "
                         + " ".join(sorted(h["setup"].astype(str))))
            for r in h.to_dict("records"):
                pe = str(r.get("primary_exit") or "original_d5")
                xd = 5 if pe == "original_d5" else ((kd or 0) + 4 if kd else None)
                nw = _int(r.get("next_watch_day"))
                when = ""
                if xd is not None and nw is not None and xd >= nw:
                    n = xd - nw + 1
                    when = "tomorrow's close" if n == 1 else f"the close in {n} sessions"
                key = when or (f"the pick's D{xd} close" if xd else "4 sessions after entry")
                sells.setdefault(key, {}).setdefault(f"{e} #{k}, {_day_txt(sd)} pick", []).append(str(r.get("setup")))
        mk = pd.to_numeric(g["mark_pct"], errors="coerce").dropna()
        out.append({"symbol": str(sym), "entry_date": str(ed), "entry": float(px) if px == px else np.nan,
                    "mark_pct": float(mk.iloc[0]) if len(mk) else np.nan, "setups": lines,
                    "sells": [f"{k_}: " + "; ".join(f"{' '.join(sorted(ids))} ({pk_})" for pk_, ids in v.items())
                              for k_, v in sorted(sells.items(), key=lambda kv: _when_order(kv[0]))],
                    "n_rows": int(len(g))})
    return sorted(out, key=lambda x: (x["entry_date"], x["symbol"]))


def tree_books_held(tree: Optional[dict]) -> List[dict]:
    """v1.3: the tree books' open positions (tree_book.csv, books named '... tree'), one row per stock."""
    B = (tree or {}).get("book")
    if B is None or B.empty:
        return []
    H = B[(B["status"] == "held") & B["book"].astype(str).str.endswith("tree")]
    out = []
    for sym, g in H.groupby("symbol", sort=False):
        out.append({"symbol": str(sym), "books": [f"{r['book']}: {r['how']} on {_day_txt(r['entry_date'])} at "
                                                  f"{_px(r['entry'])}, now {float(r['now_pct']):+.2f}%, sells at the "
                                                  f"close of {_day_txt(r['exit_date'])}"
                                                  if pd.notna(r.get("now_pct")) else
                                                  f"{r['book']}: {r['how']} on {_day_txt(r['entry_date'])} at "
                                                  f"{_px(r['entry'])}, sells at the close of {_day_txt(r['exit_date'])}"
                                                  for r in g.to_dict("records")]})
    return out


def action_rows(S: Optional[pd.DataFrame]) -> List[dict]:
    """The scan's FIRES / ARMED / ENTERED rows (every pick of the last five sessions), for the watch page's section."""
    if S is None or S.empty:
        return []
    order = {"FIRES": 0, "ARMED": 1, "ENTERED": 2}
    g = S[S["status"].isin(list(order))].copy()
    g["_o"] = g["status"].map(order)
    g = g.sort_values(["_o", "setup", "engine", "rank"]).drop(columns="_o")
    return g.to_dict("records")
