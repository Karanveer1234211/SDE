# MANIFEST - treelab v1.0 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\treelab` (a research folder beside `setuplab`, `anydaylab` and `tradelab`).
Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\treelab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `treelab.py` | 64ac932f584fade1 | 54273 |
| `TREELAB_DECLARATION.json` | 8c7a60ebf8fa1c05 | 7224 |
| `README_TREELAB.md` | a18e64789e981e90 | 6904 |
| `tests\test_treelab.py` | 4882b2c2ab720927 | 37447 |
| `MANIFEST_TREELAB.md` | this file | - |

Needs, read only, as a sibling folder: `setuplab` v1.1 (setuplab.py sha16 9979d418aecec6de, FROZEN_SETUPS.json sha16
bed8fd610cf686af and TREE.json sha16 5b447d0ff7eb16f7 beside it). Unchanged by treelab.

Declaration: `TREELAB_DECLARATION.json`, internal sha256 46be9f5ddc619f5a... (declared 22 Nov 2026 11:40 IST, before any
treelab run) - checked at every start with this code's settings; an edited file is refused.

Inputs: the panel (`%CACHE_DAILY_ROOT%\panel_oc\panel.parquet`: the frozen setups' inputs and `x_turnover_med`) and
setuplab's watchlist folder (`C:\QuantData\setuplab\WL_R1_10`: watchlist.parquet, calendar.parquet).

## History
- v1.0 (22 Nov 2026): first build. Every knob of the frozen tree (ranks, positions, calm / jumpy cut-off, calm entry,
  jumpy entry, exit, sizing, liquidity) for each engine - 6,480 trees each - and the D / ENS split, searched on the
  history window and judged walk-forward (2023-26, each year chosen on the years before it) against the frozen tree.
  PASS -> TREE v2 as a candidate second paper book; FAIL -> keep the frozen tree. Shown: the in-sample search, each
  knob, and the six Tuesday setups before / after 1 Sep 2025.

## Verified (synthetic data only)
`tests\test_treelab.py`: `24 checks, 0 failed` / `VERIFIED (treelab v1.0)` on Python 3.13 with pandas 3.0.5 + numpy
2.5.3 and with pandas 2.3.3 + numpy 2.4.1 (98 s each). What the checks cover:
- the plan and simulator give setuplab's tree_plan and tree_sim exactly (frozen D and ENS trees, 5 start days, 2 / 3 /
  4 positions; largest gap 2.7e-15);
- every exit, calm rule, jumpy subset, cut-off quantile, the sizing and the 1% cap (unknown turnover never skipped)
  by hand or against a day-by-day reference book (gap 4.4e-15);
- the selection rule's edges (a fall of exactly 25% counts; ties; the fallback) and the decision rule's edges;
- the firewall: changing every price after a selection period (setups re-run) leaves all 6,480 trees' selection
  numbers unchanged; a world whose volatile stocks fall only from 1 Jan 2026 gets exactly the same choices for every
  test year as the world without that fall;
- a planted world (calm stocks up, volatile stocks down) PASSES (+18.81 bp a day [+9.72, +27.74]; worst fall 20.8% vs
  43.4%) and no test year keeps the frozen jumpy entry; 5 trees of each grid, the joined walk-forward days and the
  decision's numbers re-computed by hand; the frozen five-start numbers = setuplab's tree_history;
- a world with no edge (no drift, no cost) FAILS; refusals (edited declaration, output inside the cache, panel without
  x_turnover_med, no test year); --check-only writes nothing; every output hash-checked.

Mutation test: 18 deliberate bugs in a copy of treelab.py (calm order, exits, slot release, the cap, sizing, the cap's
edge, the decision's edge, look-ahead in the choice, the cut-off quantile, the split, the selection period, the
1 Sep 2025 boundary, marking, the Tuesday six, the fresh exit, the five-start account, ETFs) - all 18 make the tests
fail.

Null calibration (not shipped): 10 more worlds with no edge (seeds 101-110) - the declared rule said FAIL in all 10
(daily gains -6.81 to +7.72 bp, every interval covering 0).
