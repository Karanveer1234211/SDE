# treelab v1.0 - every knob of the tree, searched on 2021-26 and judged walk-forward

Your ask (22 Nov 2026): *"How can we make the entire tree- calm and jumpy more profitable?"* ... *"dont mind searching
the same history. Infact I'd prefer that."* Then, on the plan: *"Go"*.

## What it answers

The frozen tree (TREE.json, 9 Nov 2026) has knobs that were set once, by hand: how many ranks to trade, how many
positions, where calm ends and jumpy starts, how calm picks are bought, which setups buy jumpy picks, when to sell.
treelab tries **every combination** of 8 knobs, for each engine's book, plus 5 ways to split the account:

| knob | frozen | the other options |
|---|---|---|
| ranks traded | 1-3 | 1-2, 1-5 |
| positions per book | 3 | 2, 4 |
| calm / jumpy cut-off (ATR quantile of the picks before 1 January) | 2/3 | 1/2, 4/5 |
| calm entry | D: the FIRST calm pick that opened at or above its close; ENS: EVERY calm pick at the open | the other two of those three |
| jumpy entry | the 7 frozen setups | the 6 Tuesday setups, N1 only, skip jumpy picks |
| exit | as frozen (D5 close; N1 4 sessions after its entry) | D4 close, D6 open, D7 close, D10 close |
| sizing | equal (1/k of the book) | x min(1, the year's cut-off / the pick's ATR) |
| liquidity | none | skip a trade bigger than 1% of the stock's median daily traded value |
| D / ENS split | 50/50 | 100/0, 70/30, 30/70, 0/100 |

That is 6,480 trees for D and 6,480 for ENS. The books are setuplab's own (Rs 5 L a book, each entry 1/k of the book,
all positions busy = skipped, 0.35 points a round trip).

## How it is judged (declared before any run - `TREELAB_DECLARATION.json`, sha256 `46be9f5ddc619f5a...`)

Searching 6,480 trees on the same years always finds something that looks better. So the search is judged
**walk-forward**: each year's tree is chosen only on the years before it.

**Example.** For 2023, every tree is scored on 2021-22 only; "best" = the highest a year with a worst fall of 25% or
less. Say that is *D: ranks 1-2, 4 positions, sell at the D7 close*. That tree trades 2023, and whatever 2023 does is
what the search earned. Then 2024 is chosen on 2021-23, 2025 on 2021-24, 2026 on 2021-25. The four test years are
joined and compared day by day with the frozen tree on the same days.

- **PASS** = the daily gain over the frozen tree has a 95% interval above 0 (block bootstrap over the days) **and** the
  joined worst fall is no deeper than the frozen tree's. Then **TREE v2** (the trees chosen on all of 2021-26 by the
  same rule) is a candidate for a **second paper book** beside the frozen tree - a new tree with its own freeze date.
  The frozen tree does not change.
- **FAIL** = searching the history does not beat the frozen tree on days it did not see: keep the frozen tree.
- Nothing is re-run with other settings to change a result.

Shown, never deciding:
- the in-sample best trees on all of 2021-26 (optimistic by construction) and each knob's best and median;
- **the six Tuesday setups before vs after 1 Sep 2025**: net per trade at the D5 close on every pooled pick, entries
  before vs on/after the day NSE's weekly expiry moved to Tuesday (the day those setups buy).

## Safety gates (it refuses rather than guess)

- The declaration must be the shipped file (its sha256 is checked).
- Before searching anything, its simulator must give setuplab's own frozen D and ENS books exactly (trades, nets, and
  the book's values on all 5 start days). When the window equals TREE.json's, setuplab's history must reproduce
  TREE.json's numbers (D tree +117.44% a year, worst fall 24.11%).
- The panel must have `x_turnover_med` and the frozen setups' inputs; the watchlist must reach a test year.
- It writes only under `--out`; an output folder inside the cache, treelab or setuplab is refused.

## Commands (Windows cmd)

1. Put the zip's `treelab` folder beside `setuplab`:
   ```
   tar -xf %USERPROFILE%\Downloads\treelab_v1_0_22nov.zip -C C:\Users\karanvsi\PyCharmMiscProject
   ```
   Result: `C:\Users\karanvsi\PyCharmMiscProject\treelab\` (treelab.py, TREELAB_DECLARATION.json, this README, the
   MANIFEST, tests\test_treelab.py). Nothing goes into `bigmove_deploy`.
2. Test it (synthetic worlds only; about 2-3 minutes):
   ```
   call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
   cd /d C:\Users\karanvsi\PyCharmMiscProject\treelab
   python tests\test_treelab.py
   ```
   It must end `24 checks, 0 failed` and `VERIFIED (treelab v1.0)`.
3. Check the inputs (reads, checks the simulator, writes nothing):
   ```
   python treelab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\treelab --check-only
   ```
   It must end `CHECK OK`.
4. The run:
   ```
   python treelab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\treelab
   ```
   It writes `C:\QuantData\treelab\TREELAB_<date>_<nnn>\` and a line in `C:\QuantData\treelab\treelab_ledger.jsonl`.

**Send back:** `TREELAB.md` (everything is in it), plus `walkforward.csv` and `knobs.csv` if convenient. The grids
(`grid_D.csv`, `grid_ENS.csv`) are big; keep them.

## The outputs

| file | what |
|---|---|
| `TREELAB.md` | the decision, each test year's trees and returns, TREE v2, the in-sample top 10 and the knobs, the Tuesday check |
| `walkforward.csv` | each test year: the trees chosen, D's share, that year's return and worst fall, the frozen tree's |
| `walkforward_daily.csv` | the joined test days: both accounts' daily returns and values |
| `grid_D.csv`, `grid_ENS.csv` | all 6,480 trees: a year, worst fall, end, trades a week; and the same to the end of each selection period |
| `knobs.csv` | each knob option: the best a year under the cap, the median a year, the median worst fall |
| `tuesday_expiry.csv` | the six Tuesday setups and WEEKLY: before / after 1 Sep 2025, with intervals |
| `curves.csv` | the frozen and TREE v2 books' daily values (start day 1) |
| `TREELAB_RESULT.json` | the numbers above, hashed; `DECLARATION.json` a copy of the rules; `RUN.json`; `outputs.sha256` |

## How to read it

- A year and worst fall in the search come from the book's value marked to market each close.
- The search uses start day 1; the five-start means (setuplab's convention) are shown for the frozen tree and TREE v2.
- A D6-open exit sells at the D6 open: the slot is free for that open; the position is marked at the D5 close until then.
- Liquidity cap: the trade's rupees (its share of the book x Rs 5 L x the book's growth) against 1% of the stock's
  60-session median daily traded value at the signal day; an unknown traded value is never skipped.
- Every section of `TREELAB.md` marked in-sample (and TREE v2's own numbers) is optimistic: those years built the
  tree. Only THE DECISION is judged on days the choice did not see. The forward paper ledger stays the final judge
  either way.
