"""
tests for treelab v1.0 - synthetic worlds only; nothing real is read, nothing outside a temporary folder is written.

    python tests\\test_treelab.py          (from the treelab folder, in tradelab's env; about 2-3 minutes)

Ends with  VERIFIED (treelab v1.0)  or  FAILED.
  u1  the plan and the simulator give setuplab's tree_plan and tree_sim exactly: the frozen D and ENS trees, the five
      start days, and 2 and 4 positions
  u2  every exit by hand (frozen, D4, D6 open, D7, D10); a D6-open exit frees its position for that open, a sale at
      that session's close does not
  u3  sizing, the liquidity cap and open exits against a day-by-day reference simulator (setuplab's tree_sim with the
      three changes), on the world's trees
  u4  the calm entry rules and the jumpy subsets by hand
  u5  the cut-off quantiles by hand (1/2, 2/3, 4/5)
  u6  the selection: the highest a year under the cap, a tie, the fallback, the split; and the firewall - every
      selection number of a year stays the same when every price after that year's selection period is changed
  u7  the decision rule's edges
  u8  the Tuesday before / after check by hand
  w1  PLANTED world (calm stocks drift up, volatile stocks drift down, in every year; the declared cost): the
      walk-forward never keeps the frozen jumpy entry -> PASS; every test year's trees = the best on the years before
      it; 5 trees of each grid, the joined walk-forward days and the decision's numbers re-computed by a day-by-day
      reference book; the frozen tree's five-start numbers = setuplab's tree_history
  w2  ABSENT world (no drift and no cost - test only: no tree has an edge): no PASS
  w3  LATE world (the absent world, the same draws, with volatile stocks falling from 1 Jan 2026): every test year's
      choice - 2026's included - is the absent world's (chosen without 2026), while the whole-window numbers change
  w4  refusals: an edited declaration, an output folder inside the cache, a panel without x_turnover_med, a watchlist
      without a test year; --check-only writes nothing; outputs hash-checked
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import treelab as TL  # noqa: E402

SU = TL.SU
FAILS = []
N_OK = [0]


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)


FZ = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_wq_44", "d_bb_bw_20"]
DRIFT_GOOD = 0.002           # the planted world: a calm stock's drift a session
DRIFT_BAD = -0.006           # a volatile stock's drift a session (planted: every year; late: from 2026)


def make_world(base: Path, seed: int, mode: str, n_sym=60, per_day=5, start="2019-05-06", end="2026-10-30",
               last_signal=None):
    """root: panel_oc\\panel.parquet (the frozen setups' inputs, w_ret_13w, x_turnover_med - unknown for one stock's
    first 600 sessions); data: setuplab's watchlist folder (D and ENS, ranks 1-per_day). The most volatile third of the
    stocks is 'bad'. mode: 'planted' = good stocks drift DRIFT_GOOD, bad ones DRIFT_BAD, every year; 'absent' = no
    drift; 'late' = the absent world's draws, the bad stocks drifting DRIFT_BAD from 2026-01-01 (numpy's normal(mu, s)
    is mu + s x the same standard draw, so everything before 2026 is the absent world's)."""
    rng = np.random.default_rng(seed)
    root, data = base / "root", base / "data"
    for p in (root / "panel_oc", data):
        p.mkdir(parents=True, exist_ok=True)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    late_t = int(np.searchsorted(cal, pd.Timestamp("2026-01-01")))
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]     # one ETF: the tree skips it
    wk = cal.to_period("W-FRI").to_numpy()
    first_of_week = np.r_[True, wk[1:] != wk[:-1]]
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)) * (rng.random((n_sym, T)) < 0.5), axis=1) for f in FZ}
    X["d_bb_pctb_20"] = rng.normal(0.5, 0.5, (n_sym, T))
    wval = np.zeros((n_sym, T))
    for s in range(n_sym):
        cur = rng.normal(0, 10)
        for t in range(T):
            if first_of_week[t] and rng.random() < 0.5:
                cur += rng.normal(0, 3)
            wval[s, t] = cur
    X["w_ret_13w"] = wval
    sig = rng.uniform(0.012, 0.035, n_sym)
    bad = sig >= np.quantile(sig, 2 / 3)
    X["x_turnover_med"] = np.exp(rng.normal(np.log(3e7), 1.0, n_sym))[:, None] * np.exp(
        rng.normal(0, 0.2, (n_sym, T)))
    X["x_turnover_med"][0, :600] = np.nan
    mu = np.zeros((n_sym, T))
    if mode == "planted":
        mu[~bad] = DRIFT_GOOD
        mu[bad] = DRIFT_BAD
    elif mode == "late":
        mu[bad, late_t:] = DRIFT_BAD
    O = np.zeros((n_sym, T))
    C = np.zeros((n_sym, T))
    H = np.zeros((n_sym, T))
    Lo = np.zeros((n_sym, T))
    for s in range(n_sym):
        c_prev = 100.0 * np.exp(rng.normal(0, 0.4))
        for t in range(T):
            g = rng.normal(0, 0.005)
            u = rng.normal(mu[s, t], sig[s])
            o = c_prev * (1 + g)
            c = o * (1 + u)
            O[s, t], C[s, t] = o, c
            H[s, t] = max(o, c) * (1 + abs(rng.normal(0, sig[s] / 3)))
            Lo[s, t] = min(o, c) * (1 - abs(rng.normal(0, sig[s] / 3)))
            c_prev = c
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(cal, n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    atr = np.vstack([SU.atr_simple(H[s], Lo[s], C[s]) for s in range(n_sym)])
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    tz = T - 11 if last_signal is None else int(np.searchsorted(cal, pd.Timestamp(last_signal)))
    rows = []
    for t in range(t0, tz):
        pick_d = rng.choice(n_sym, per_day, replace=False)
        pick_e = rng.choice(n_sym, per_day, replace=False)
        for eng, picks in (("D", pick_d), ("ENS", pick_e)):
            for rk, s in enumerate(picks, 1):
                e1 = O[s, t + 1]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": C[s, t], "entry": e1, "status": "ok",
                       "net_bp": (C[s, t + 5] / e1 - 1) * 1e4 - 35, "s_atr14": atr[s, t], "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[s, t + k] / e1 - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[s, t + k] / C[s, t + k - 1] - 1
                rows.append(row)
    pd.DataFrame(rows).to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return root, data, {"cal": cal, "bad": bad, "syms": syms}


@contextmanager
def no_cost():
    """A world without the round-trip cost (test only, for a world where no tree has an edge): setuplab's and
    treelab's cost set to 0; the declaration check still sees the shipped constants."""
    c_su, c_tl, k = SU.COST, TL.COST, TL.constants
    shipped = TL.constants()
    SU.COST, TL.COST = 0.0, 0.0
    TL.constants = lambda: shipped
    try:
        yield
    finally:
        SU.COST, TL.COST, TL.constants = c_su, c_tl, k


def args(root, data, out, **kw):
    return SimpleNamespace(root=str(root), data=str(data), out=str(out), panel=kw.get("panel"),
                           check_only=kw.get("check_only", False))


def runs(out):
    return sorted(p for p in Path(out).iterdir() if p.is_dir() and re.fullmatch(r"TREELAB_\d{8}_\d{3}", p.name))


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return len(lines) >= 10 and all(
        hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0] for ln in lines)


def setup_world(root, data):
    """What cmd_run builds before the search."""
    _, fdoc = SU.load_frozen()
    _, tdoc = SU.load_tree()
    fconds = SU.frozen_conds(fdoc)
    primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
    order = [s for s in SU.TREE_ORDER if s in fconds]
    ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
    bk, _ = TL.load_book(data, root / "panel_oc" / "panel.parquet", list(dict.fromkeys(ffeats + [TL.TURNOVER])),
                         log=lambda *a: None)
    fills = TL.replays(bk, fconds, primary)
    cuts = {q: TL.cutoffs(bk, v, tdoc) for q, v in TL.QUANT.items()}
    P0 = TL.frozen_picks(bk, fills, order, primary, tdoc, cuts["2/3"])
    s_ = TL.window_start(bk, cuts["2/3"])
    books, _ = SU.tree_run_books(P0, bk, s_)
    t1 = TL.window_end(bk, books)
    tv = bk.F[TL.TURNOVER][:, 1]
    ED = TL.Eng(bk, "D", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, tv)
    EE = TL.Eng(bk, "ENS", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, tv)
    return SimpleNamespace(bk=bk, fdoc=fdoc, tdoc=tdoc, fconds=fconds, primary=primary, order=order, fills=fills,
                           cuts=cuts, P0=P0, s_=s_, books=books, t1=t1, ED=ED, EE=EE)


def ref_sim(P, O, C, i1, s0, t1, k, m=None, tv=None, cap=False):
    """setuplab's tree_sim, day by day, with three changes: a size multiplier, the liquidity cap and open exits."""
    ent, ex, net, br, ek = P["ent"], P["ex"], P["net"], P["br"], P["ek"]
    oex = P["open_exit"]
    keep = np.flatnonzero((ent >= s0) & (ent <= t1))
    cash, pos, j = 1.0, [], 0
    eqc, eqm = np.empty(t1 - s0 + 1), np.empty(t1 - s0 + 1)
    for t in range(s0, t1 + 1):
        still = []
        for p in pos:                                   # sold at this open
            if p[5] and p[0] <= t:
                cash += p[1] + p[2]
            else:
                still.append(p)
        pos = still
        while j < len(keep) and ent[keep[j]] == t:
            x = keep[j]
            if len(pos) < k:
                size = (cash + sum(p[1] for p in pos)) / k * (m[x] if m is not None else 1.0)
                if size > 0 and not (cap and size * TL.BOOK_RS > TL.LIQ_SHARE * tv[x]):
                    cash -= size
                    pos.append((ex[x], size, size * net[x] / 100, br[x], O[br[x], ek[x]], bool(oex[x])))
            j += 1
        still = []
        for p in pos:                                   # sold at this close
            if (not p[5]) and p[0] <= t:
                cash += p[1] + p[2]
            else:
                still.append(p)
        pos = still
        eqc[t - s0] = cash + sum(p[1] for p in pos)
        mk = 0.0
        for p in pos:
            kk = t - i1[p[3]] + 1
            c_ = C[p[3], kk] if 1 <= kk <= TL.PATH else np.nan
            mk += p[1] * (c_ / p[4]) if np.isfinite(c_) and np.isfinite(p[4]) and p[4] > 0 else p[1]
        eqm[t - s0] = cash + mk
    return np.maximum(eqc, 0.0), np.maximum(eqm, 0.0)


# ---------------------------------------------------------------------------------------------------- unit checks
def unit_checks(W):
    bk, ED, EE, s_, t1 = W.bk, W.ED, W.EE, W.s_, W.t1
    print("u1: the frozen trees = setuplab's")
    worst, same = 0.0, True
    for E, nm, calm in ((ED, "D tree", "first_up"), (EE, "ENS tree", "all")):
        Tt, prow = W.books[nm]
        mine = E.plan(3, "2/3", calm, "all7", "frozen")
        a1 = np.sort(np.c_[prow[Tt["row"].to_numpy(np.int64)], Tt["ent"], Tt["ex"], Tt["ek"]].astype(np.int64), 0)
        a2 = np.sort(np.c_[mine["br"], mine["ent"], mine["ex"], mine["ek"]].astype(np.int64), 0)
        same &= a1.shape == a2.shape and bool((a1 == a2).all()) and bool(np.allclose(
            np.sort(Tt["net"].to_numpy(float)), np.sort(mine["net"]), rtol=0, atol=1e-9))
        for p_ in range(5):
            for k in (2, 3, 4):
                eqc1, eqm1, tk1 = SU.tree_sim(Tt, prow, bk.O, bk.C, bk.i1, s_ + p_, t1, k=k)
                eqc2, eqm2, taken, _ = TL.sim(mine, bk.O, bk.C, bk.i1, s_ + p_, t1, k)
                worst = max(worst, float(np.abs(eqm1 - eqm2).max()), float(np.abs(eqc1 - eqc2).max()))
                same &= int(taken.sum()) == len(tk1)
    check(same and worst < 1e-12, "u1 the frozen D and ENS trees: setuplab's tree_plan trades and nets, and tree_sim's "
                                  "values on all 5 start days with 2, 3 and 4 positions (largest gap %.1e)" % worst)

    print("u2: the exits by hand")
    ok = True
    n_checked = 0
    for x in ("frozen", "d4", "o6", "d7", "d10"):
        P = ED.plan(3, "2/3", "first_up", "all7", x)
        for j in range(0, len(P["ent"]), max(1, len(P["ent"]) // 40)):
            b, d_ = P["br"][j], P["ek"][j]
            fresh = W.primary.get(P["how"][j]) == "fresh"
            xk = {"frozen": d_ + 4 if fresh else 5, "d4": max(4, d_), "o6": 5, "d7": 7, "d10": 10}[x]
            pout = bk.O[b, 6] if x == "o6" else bk.C[b, xk]
            want = (pout / bk.O[b, d_] - 1) * 100 - TL.COST
            ex = bk.i1[b] + (5 if x == "o6" else xk - 1)
            ok &= abs(P["net"][j] - want) < 1e-9 and P["ex"][j] == ex and P["ent"][j] == bk.i1[b] + d_ - 1
            n_checked += 1
    # a toy book: one slot; trade A enters on day 0 and its D6 open is day 5; trade B enters on day 5
    O_ = np.full((2, TL.PATH + 1), np.nan)
    C_ = np.full((2, TL.PATH + 1), np.nan)
    O_[:, 1:] = 100.0
    C_[:, 1:] = 101.0
    i1_ = np.array([0, 5])
    toy = {"ent": np.array([0, 5]), "ex": np.array([5, 9]), "ek": np.array([1, 1]), "br": np.array([0, 1]),
           "net": np.array([2.0, 1.0]), "m_inv": np.ones(2), "tv": np.full(2, np.nan),
           "open_exit": np.array([True, False])}
    eqc_o, eqm_o, tk_o, _ = TL.sim(toy, O_, C_, i1_, 0, 12, 1)
    toyc = dict(toy, open_exit=np.array([False, False]))         # the same session, sold at its close instead
    eqc_c, eqm_c, tk_c, _ = TL.sim(toyc, O_, C_, i1_, 0, 12, 1)
    r_o = ref_sim(toy, O_, C_, i1_, 0, 12, 1)
    toy_ok = (tk_o.all() and tk_c.tolist() == [True, False] and abs(eqm_o[4] - 1.01) < 1e-12 and
              abs(eqc_o[5] - 1.02) < 1e-12 and abs(eqm_o[5] - (1.02 + 1.02 * 0.01)) < 1e-12 and
              abs(eqc_o[9] - (1.02 + 1.02 * 0.01)) < 1e-12 and abs(eqm_c[5] - 1.02) < 1e-12 and
              np.allclose(r_o[1], eqm_o, rtol=0, atol=1e-12))
    check(ok and n_checked > 100 and toy_ok,
          "u2 %d trades: each exit's net, entry and exit session by hand; a toy book of one position: a D6-open exit "
          "frees the position for that open (the next trade is taken) and is marked at the close before; sold at that "
          "session's close instead, the next trade is skipped" % n_checked)

    print("u3: sizing, the liquidity cap and open exits vs a day-by-day reference")
    worst = 0.0
    cases = 0
    for E, calm in ((ED, "first_up"), (EE, "all")):
        for x in ("frozen", "o6", "d10"):
            P = E.plan(5, "1/2", calm, "all7", x)
            for k in (2, 4):
                for sz, liq in (("invvol", "none"), ("equal", "cap1"), ("invvol", "cap1")):
                    eqc1, eqm1, _, _ = TL.sim(P, bk.O, bk.C, bk.i1, s_, t1, k, sz, liq)
                    eqc2, eqm2 = ref_sim(P, bk.O, bk.C, bk.i1, s_, t1, k,
                                         m=P["m_inv"] if sz == "invvol" else None, tv=P["tv"], cap=liq == "cap1")
                    worst = max(worst, float(np.abs(eqm1 - eqm2).max()), float(np.abs(eqc1 - eqc2).max()))
                    cases += 1
    m_ok = bool(np.all(ED.m_inv <= 1.0)) and bool(np.any(ED.m_inv < 1.0))
    fc = np.array([W.cuts["2/3"][int(y)] for y in ED.year])
    m_hand = np.minimum(1.0, fc / ED.atr)
    check(worst < 1e-12 and m_ok and np.allclose(ED.m_inv, m_hand),
          "u3 %d cases (2 and 4 positions; sized down by ATR, the 1%% cap, both; frozen, D6-open and D10 exits): the "
          "reference gives the same values (largest gap %.1e); the multiplier = min(1, cut-off / ATR) by hand" % (
              cases, worst))
    P = ED.plan(5, "2/3", "all", "all7", "frozen")
    win = (P["ent"] >= s_) & (P["ent"] <= t1)
    unknown = ~np.isfinite(P["tv"])
    tiny = dict(P, tv=np.where(unknown, np.nan, 1.0))           # every known turnover: Re 1 a day
    _, _, tk_t, _ = TL.sim(tiny, bk.O, bk.C, bk.i1, s_, t1, 50, "equal", "cap1")
    _, _, tk_n, _ = TL.sim(P, bk.O, bk.C, bk.i1, s_, t1, 3, "equal", "none")
    _, _, tk_c, _ = TL.sim(P, bk.O, bk.C, bk.i1, s_, t1, 3, "equal", "cap1")
    first_known = np.flatnonzero(win & ~unknown)[0]
    size1 = 1.0 / 3
    hand = size1 * TL.BOOK_RS > TL.LIQ_SHARE * P["tv"][first_known]
    check((unknown & win).sum() > 0 and bool((tk_t == (unknown & win)).all()) and
          tk_c.sum() < tk_n.sum() and tk_c[first_known] == (not hand),
          "u3 the 1%% cap: %d trades with an unknown turnover are all taken and every known one at Re 1 a day is "
          "skipped (50 positions); on the world's turnover the cap skips %d of %d trades; the first trade by hand "
          "(Rs %.0f vs 1%% of Rs %.0f: %s)" % (
              (unknown & win).sum(), tk_n.sum() - tk_c.sum(), tk_n.sum(), size1 * TL.BOOK_RS,
              P["tv"][first_known], "skipped" if hand else "taken"))

    print("u4: calm entry and the jumpy subsets by hand")
    E = ED
    good = True
    for calm in ("first_up", "all_up", "all"):
        for jumpy in ("all7", "tue6", "n1", "skip"):
            P = E.plan(5, "2/3", calm, jumpy, "frozen")
            cut = E.cut["2/3"]
            act = (E.rank <= 5) & ~E.etf & np.isfinite(cut)
            calm_ = act & (E.atr <= cut)
            known = np.isfinite(E.o1)
            up = known & (E.o1 >= E.sc)
            bought = np.zeros(len(E.rows), bool)
            for day in np.unique(E.sday):
                idx = np.flatnonzero(E.sday == day)
                if calm == "first_up":
                    c = [i for i in idx[np.argsort(E.rank[idx], kind="stable")] if calm_[i] and up[i]]
                    if c:
                        bought[c[0]] = True
                elif calm == "all_up":
                    bought[idx] = calm_[idx] & up[idx]
                else:
                    bought[idx] = calm_[idx] & known[idx]
            elig = act & ~bought & (~calm_ if calm == "all" else True)
            use = {"all7": E.order, "tue6": [s for s in E.order if s != "N1"], "n1": ["N1"], "skip": []}[jumpy]
            want = set(np.flatnonzero(bought).tolist())
            for i in np.flatnonzero(elig):
                best = None
                for s in use:
                    if E.fill[s][i] > 0 and (best is None or E.fill[s][i] < best):
                        best = E.fill[s][i]
                if best:
                    want.add(int(i))
            got = set(P["row"].tolist())
            good &= got == want
    check(good, "u4 every calm rule x jumpy subset: the picks traded = the rule by hand (calm: the first / every "
                "calm pick that opened at or above its close / every calm pick; jumpy: the earliest fill among the "
                "subset)")

    print("u5: the cut-off quantiles by hand")
    comp = SU.tree_complete(bk)
    sday = np.asarray(bk.signal_day).astype("datetime64[D]")
    good = True
    for q, v in TL.QUANT.items():
        for y, c in W.cuts[q].items():
            ref = comp & (sday < np.datetime64("%d-01-01" % y))
            a = bk.atr[ref]
            a = a[np.isfinite(a)]
            if len(a) >= 100:
                good &= abs(np.quantile(a, v) - c) < 1e-12
    c23 = {y: SU.tree_cutoff(bk.atr, bk.signal_day, comp, y)[0] for y in W.cuts["2/3"]}
    good &= all(abs(c23[y] - W.cuts["2/3"][y]) < 1e-12 for y in c23 if np.isfinite(c23[y]))
    check(good and W.cuts["1/2"][2023] < W.cuts["2/3"][2023] < W.cuts["4/5"][2023],
          "u5 the 1/2, 2/3 and 4/5 quantiles of the complete picks' ATR before each 1 January by hand; 2/3 = "
          "setuplab's tree_cutoff")

    print("u6: the selection and the firewall")
    G = pd.DataFrame({"a_year": [10.0, 30.0, 30.0, 50.0], "fall": [20.0, 24.0, 24.0, 26.0]})
    i1c, fb1 = TL.choose(G, "a_year", "fall")
    Gc = pd.DataFrame({"a_year": [10.0, 40.0, 50.0], "fall": [20.0, 25.0, 25.000001]})
    ic, fbc = TL.choose(Gc, "a_year", "fall")
    G2 = pd.DataFrame({"a_year": [10.0, 30.0], "fall": [30.0, 40.0]})
    i2c, fb2 = TL.choose(G2, "a_year", "fall")
    i1c = i1c if (ic == 1 and not fbc) else -1                  # a worst fall of exactly 25% is under the cap
    cal = bk.cal
    vD = np.linspace(1, 3, 600)
    vE = np.linspace(1, 1.5, 600)
    w, rows_, fbw = TL.choose_split(vD, vE, cal, 0, 599)
    v = np.r_[np.linspace(1, 2, 300), np.linspace(2, 1.2, 300)]
    st1 = TL.path_stats(v, cal, 0, 299)
    v2 = v.copy()
    v2[300:] *= 5
    st2 = TL.path_stats(v2, cal, 0, 299)
    check(i1c == 1 and not fb1 and i2c == 0 and fb2 and w == 1.0 and st1 == st2,
          "u6 the highest a year at a worst fall of 25% or less (exactly 25% counts; a tie: the earlier tree), none "
          "under the cap -> the frozen tree, the split, a path's numbers to a day ignore every later day")
    # the firewall end to end: change every price after a selection period's last session -> the period's numbers stay
    years = sorted(set(pd.DatetimeIndex(cal[s_:t1 + 1]).year))
    tests = [y for y in years if y >= years[0] + TL.FIRST_TEST]
    cy = pd.DatetimeIndex(cal[:t1 + 1]).year
    ends = {y: int(np.flatnonzero(cy == y - 1)[-1]) for y in tests}
    y0 = tests[1]
    pe = ends[y0]
    G1 = TL.search(ED, bk, s_, t1, {y0: pe}, log=lambda *a: None)
    O0, C0 = bk.O, bk.C
    rng = np.random.default_rng(1)
    day = bk.i1[:, None] + np.arange(bk.O.shape[1])[None, :] - 1       # column k = the session i1 + k - 1
    after = day > pe
    try:
        bk.O = np.where(after, O0 * np.exp(rng.normal(0, 0.05, O0.shape)), O0)
        bk.C = np.where(after, C0 * np.exp(rng.normal(0, 0.05, C0.shape)), C0)
        fills2 = TL.replays(bk, W.fconds, W.primary)                     # the setups re-run on the changed prices
        ED2 = TL.Eng(bk, "D", s_, W.cuts, W.cuts["2/3"], fills2, W.order, W.primary, W.tdoc,
                     bk.F[TL.TURNOVER][:, 1])
        G2b = TL.search(ED2, bk, s_, t1, {y0: pe}, log=lambda *a: None)
    finally:
        bk.O, bk.C = O0, C0
    col_a, col_f = "a_year_to_%d" % (y0 - 1), "fall_to_%d" % (y0 - 1)
    same = np.allclose(G1[col_a], G2b[col_a], rtol=0, atol=1e-9) and np.allclose(G1[col_f], G2b[col_f], rtol=0,
                                                                                 atol=1e-9)
    moved = not np.allclose(G1["a_year"], G2b["a_year"])
    check(same and moved, "u6 the firewall: every open and close after %s changed and the setups re-run (all 6,480 D "
                          "trees): the numbers the %d choice uses stay the same, the whole-window numbers move" % (
                              pd.Timestamp(cal[pe]).date(), y0))

    print("u7: the decision rule")
    cases = [TL.decide(0.1, 10.0, 12.0)[0], TL.decide(0.1, 12.0, 12.0)[0], TL.decide(0.0, 10.0, 12.0)[0],
             TL.decide(0.5, 12.5, 12.0)[0], TL.decide(np.nan, 10.0, 12.0)[0]]
    check(cases == ["PASS", "PASS", "FAIL", "FAIL", "FAIL"],
          "u7 PASS needs the interval above 0 and a worst fall no deeper (equal allowed): %s" % cases)

    print("u8: the Tuesday check by hand")
    weekly = [s for s in W.order if s != "N1"]
    etf = SU.tree_etf(bk.symbols, W.tdoc)
    R = TL.pooled_rows(bk, TL.complete_rows(bk) & ~etf)
    wk = "WEEKLY (earliest of the six)"

    def by_hand(fills):
        nets_b, nets_a = [], []
        for r in R:
            best, bn = None, np.nan
            for s in weekly:
                dd = fills[s][0][r]
                if dd > 0 and (best is None or dd < best):
                    best, bn = dd, fills[s][1][r]
            if best and np.isfinite(bn):
                ent = pd.Timestamp(bk.cal[bk.i1[r] + best - 1])
                (nets_a if ent >= pd.Timestamp(TL.EXPIRY_FROM) else nets_b).append(bn)    # on or after: after
        return nets_b, nets_a

    def same(T, nets_b, nets_a):
        row = T.loc[wk]
        return (row["before_trades"] == len(nets_b) and row["after_trades"] == len(nets_a) and
                abs(row["before_net"] - np.mean(nets_b)) < 1e-9 and abs(row["after_net"] - np.mean(nets_a)) < 1e-9)

    nb, na = by_hand(W.fills)
    ok1 = same(TL.tuesday_check(bk, W.fills, weekly, etf).set_index("lane"), nb, na) and len(na) > 10
    # one pick filled on 1 Sep 2025 itself: it counts after
    t_b = int(np.searchsorted(bk.cal, np.datetime64(TL.EXPIRY_FROM)))
    r0 = next(r for r in R if bk.i1[r] <= t_b <= bk.i1[r] + 4)
    fb = {s: (W.fills[s][0].copy(), W.fills[s][1].copy()) for s in W.fills}
    for s in weekly:
        fb[s][0][r0] = 0
    fb[weekly[0]][0][r0], fb[weekly[0]][1][r0] = t_b - bk.i1[r0] + 1, 1.234
    nb2, na2 = by_hand(fb)
    ok2 = same(TL.tuesday_check(bk, fb, weekly, etf).set_index("lane"), nb2, na2) and 1.234 in na2 and \
        pd.Timestamp(bk.cal[t_b]) == pd.Timestamp(TL.EXPIRY_FROM)
    check(ok1 and ok2, "u8 WEEKLY before / after %s by hand: %d and %d trades, the same means; a fill on %s itself "
                       "counts after" % (TL.EXPIRY_FROM, len(nb), len(na), TL.EXPIRY_FROM))


# ---------------------------------------------------------------------------------------------------- the worlds
def run_world(tmp, name, seed, mode, **kw):
    print("%s world" % name)
    root, data, info = make_world(tmp / name, seed, mode, **kw)
    out = tmp / name / "out"
    if mode == "planted":
        rc = TL.cmd_run(args(root, data, out))
    else:
        with no_cost():
            rc = TL.cmd_run(args(root, data, out))
    d = runs(out)[-1] if out.exists() and runs(out) else None
    return rc, d, root, data, info, out


def result_of(d):
    return json.loads((d / "TREELAB_RESULT.json").read_text(encoding="utf-8"))


def wiring(d):
    """Every test year's D and ENS trees = the highest a year at a worst fall under the cap on the years before it,
    read back from the grids (a tie: the earlier tree; none under the cap: the frozen tree)."""
    wf = pd.read_csv(d / "walkforward.csv")
    ok = True
    for e in ("D", "ENS"):
        g = pd.read_csv(d / ("grid_%s.csv" % e))
        for r in wf.to_dict("records"):
            ca, cf = "a_year_to_%d" % (r["year"] - 1), "fall_to_%d" % (r["year"] - 1)
            m = g[cf] <= TL.FALL_CAP
            want = g[m].sort_values([ca, "i"], ascending=[False, True]).iloc[0]["tree"] if m.any() else g.iloc[0]["tree"]
            ok &= r[e + "_tree"] == want and bool(r[e + "_fallback"]) == (not m.any())
    return ok, wf


def ref_path(E, row, W):
    """One tree's marked path from the window's first session, by the day-by-day reference book."""
    bk = W.bk
    P = E.plan(int(row["ranks"]), str(row["cutoff"]), row["calm"], row["jumpy"], row["exit"])
    return ref_sim(P, bk.O, bk.C, bk.i1, W.s_, W.t1, int(row["positions"]),
                   m=P["m_inv"] if row["sizing"] == "invvol" else None, tv=P["tv"], cap=row["liquidity"] == "cap1")[1]


def last_of_year(W, y):
    cy = pd.DatetimeIndex(W.bk.cal[:W.t1 + 1]).year
    return int(np.flatnonzero(cy == y)[-1])


def grid_by_hand(d, W, idx=(0, 777, 2048, 4097, 6479)):
    """Five trees of each grid: a year and worst fall over the window and each selection period, from the reference
    book's marked path."""
    cal, s_ = W.bk.cal, W.s_
    worst, n = 0.0, 0
    for E, nm in ((W.ED, "D"), (W.EE, "ENS")):
        g = pd.read_csv(d / ("grid_%s.csv" % nm))
        for i in idx:
            row = g.loc[i]
            v = ref_path(E, row, W)
            uptos = [("a_year", "fall", W.t1)] + [(c, "fall_to_" + c[len("a_year_to_"):],
                                                   last_of_year(W, int(c[len("a_year_to_"):])))
                                                  for c in g.columns if c.startswith("a_year_to_")]
            for ca, cf, upto in uptos:
                w = v[:upto - s_ + 1]
                yrs = float((cal[upto] - cal[s_]) / np.timedelta64(1, "D")) / 365.25
                ay = (w[-1] ** (1 / yrs) - 1) * 100
                fall = 100 * np.max(1 - w / np.maximum.accumulate(w))
                worst = max(worst, abs(ay - row[ca]), abs(fall - row[cf]))
                n += 1
    return worst, n


def wf_by_hand(d, W):
    """The joined walk-forward days: each year's chosen trees (and the frozen ones) re-simulated by the reference book,
    the account split at the previous year's last close; -> (largest gap to walkforward_daily.csv, the daily gain's
    mean, the joined worst falls)."""
    wf = pd.read_csv(d / "walkforward.csv")
    daily = pd.read_csv(d / "walkforward_daily.csv")
    gD, gE = pd.read_csv(d / "grid_D.csv"), pd.read_csv(d / "grid_ENS.csv")
    s_ = W.s_
    rw, rf = [], []
    for r in wf.to_dict("records"):
        y = int(r["year"])
        pe, ye = last_of_year(W, y - 1), last_of_year(W, y)
        for iD, iE, w, out in ((r["D_i"], r["ENS_i"], r["D_share"], rw), (0, 0, 0.5, rf)):
            a = ref_path(W.ED, gD.loc[iD], W)[pe - s_: ye - s_ + 1]
            b = ref_path(W.EE, gE.loc[iE], W)[pe - s_: ye - s_ + 1]
            v = w * a / a[0] + (1 - w) * b / b[0]
            out.append(v[1:] / v[:-1] - 1)
    rw, rf = np.concatenate(rw), np.concatenate(rf)
    gap = max(float(np.abs(rw - daily["walkforward_return"]).max()), float(np.abs(rf - daily["frozen_return"]).max()))
    diff = float(np.mean((np.log1p(rw) - np.log1p(rf)) * 1e4))
    return gap, diff, TL.worst_fall_of(np.r_[1.0, np.cumprod(1 + rw)]), TL.worst_fall_of(np.r_[1.0, np.cumprod(1 + rf)])


def main():
    t0 = time.time()
    tmp = Path(tempfile.mkdtemp(prefix="treelab_test_"))
    try:
        rc, d, root, data, info, out = run_world(tmp, "planted", 5, "planted")
        print("w1: the planted world")
        check(rc == 0 and d is not None and outputs_ok(d), "w1 run returns 0; every output matches outputs.sha256")
        W = setup_world(root, data)
        unit_checks(W)
        print("w1: the planted world's decision")
        if d is not None:
            res = result_of(d)
            ok_w, wf = wiring(d)
            md = (d / "TREELAB.md").read_text(encoding="utf-8")
            kept = [(r.D_tree.split()[4], r.ENS_tree.split()[4], r.D_share) for r in wf.itertuples()]
            uses_frozen_jumpy = any((dj == "all7" and ds > 0) or (ej == "all7" and ds < 1) for dj, ej, ds in kept)
            dec = res["decision"]
            check(dec["verdict"] == "PASS" and not uses_frozen_jumpy and "## THE DECISION: **PASS**" in md,
                  "w1 PASS (daily gain %+.2f bp %s, worst fall %.1f%% vs the frozen tree's %.1f%%); no test year keeps "
                  "the frozen jumpy entry in a book it uses (D / ENS jumpy entry, D's share: %s)" % (
                      dec["diff"], TL._ci(dec["diff_lo"], dec["diff_hi"]), dec["wf_fall"], dec["fz_fall"],
                      "; ".join("%s / %s %.0f%%" % (a_, b_, 100 * c_) for a_, b_, c_ in kept)))
            check(ok_w, "w1 every test year's D and ENS trees = the best on the years before it, read back from the "
                        "grids")
            gap_g, n_g = grid_by_hand(d, W)
            check(gap_g < 1e-8, "w1 the grids by hand: 5 trees of each engine re-simulated by the day-by-day reference "
                                "book - %d a-year and worst-fall numbers, largest gap %.1e" % (n_g, gap_g))
            gap_w, diff_w, fw, ff = wf_by_hand(d, W)
            check(gap_w < 1e-7 and abs(diff_w - dec["diff"]) < 1e-6 and abs(fw - dec["wf_fall"]) < 1e-6 and
                  abs(ff - dec["fz_fall"]) < 1e-6,
                  "w1 the decision by hand: each test year's chosen trees and the frozen ones re-simulated, the account "
                  "split at the year before's last close - the joined days equal walkforward_daily.csv (largest gap "
                  "%.1e), the daily gain %+.4f bp and both worst falls equal the decision's" % (gap_w, diff_w))
            hres, _, _ = SU.tree_history(W.bk, W.P0, W.books, W.s_, W.t1, reruns=0, log=lambda *a: None)
            hb = hres["both trees (Rs 2.5 L each)"]
            fz5 = res["frozen_five_starts"]
            gap5 = max(abs(np.mean([x[k] for x in hb]) - fz5[k]) for k in ("a_year", "fall", "end"))
            check(gap5 < 1e-9, "w1 the frozen tree's five-start numbers (%+.2f%% a year, worst fall %.2f%%) = "
                               "setuplab's tree_history 'both trees' (gap %.1e)" % (fz5["a_year"], fz5["fall"], gap5))
            g = pd.read_csv(d / "grid_D.csv")
            check(len(g) == 6480 and g.iloc[0]["tree"] == "r3 p3 c2/3 first_up all7 frozen equal none" and
                  len(pd.read_csv(d / "grid_ENS.csv")) == 6480 and
                  pd.read_csv(d / "grid_ENS.csv").iloc[0]["tree"] == "r3 p3 c2/3 all all7 frozen equal none",
                  "w1 6,480 trees per engine, the frozen tree first")
        else:
            check(False, "w1 the planted world's run")
        rc, dA, *_ = run_world(tmp, "absent", 8, "absent")
        print("w2: the absent world")
        if dA is not None:
            decA = result_of(dA)["decision"]
            check(rc == 0 and decA["verdict"] == "FAIL" and wiring(dA)[0],
                  "w2 no drift, no cost: %s (daily gain %+.2f bp %s, worst fall %.1f%% vs %.1f%%); the choices read "
                  "back from the grids" % (decA["verdict"], decA["diff"], TL._ci(decA["diff_lo"], decA["diff_hi"]),
                                           decA["wf_fall"], decA["fz_fall"]))
        else:
            check(False, "w2 the absent world's run")
        rc, dL, *_ = run_world(tmp, "late", 8, "late")
        print("w3: the late world")
        if dA is not None and dL is not None:
            wA, wL = pd.read_csv(dA / "walkforward.csv"), pd.read_csv(dL / "walkforward.csv")
            cols = ["year", "D_tree", "ENS_tree", "D_share", "D_fallback", "ENS_fallback", "split_fallback"]
            same_choice = wA[cols].equals(wL[cols])
            gA, gL = pd.read_csv(dA / "grid_D.csv"), pd.read_csv(dL / "grid_D.csv")
            eA, eL = pd.read_csv(dA / "grid_ENS.csv"), pd.read_csv(dL / "grid_ENS.csv")
            pre = [c for c in gA.columns if c.startswith("a_year_to_") or c.startswith("fall_to_")]
            same_pre = all(np.allclose(x[c], y[c], rtol=0, atol=1e-9) for x, y in ((gA, gL), (eA, eL)) for c in pre)
            moved = not np.allclose(gA["a_year"], gL["a_year"])
            last = int(wL["year"].max())
            v2L = result_of(dL)["tree_v2"]
            check(rc == 0 and same_choice and same_pre and moved,
                  "w3 volatile stocks falling from 1 Jan 2026: every test year's trees and split - 2026's included "
                  "(D %s, ENS %s) - are the absent world's; every selection number of both grids is the same, the "
                  "whole-window numbers move (the late world: %s; the tree chosen on all of 2021-26 takes jumpy "
                  "picks by '%s' / '%s')" % (
                      wL.loc[wL.year == last, "D_tree"].iloc[0], wL.loc[wL.year == last, "ENS_tree"].iloc[0],
                      result_of(dL)["decision"]["verdict"], v2L["D_config"]["jumpy"], v2L["ENS_config"]["jumpy"]))
        else:
            check(False, "w3 the late world's run")
        print("w4: refusals")
        out3 = tmp / "planted" / "out_check"
        rc = TL.cmd_run(args(root, data, out3, check_only=True))
        check(rc == 0 and not out3.exists(), "w4 --check-only reads, checks and writes nothing")
        doc = json.loads((TL.HERE / TL.DECL_FILE).read_text(encoding="utf-8"))
        doc["question"] = doc["question"] + " (edited)"
        edited = tmp / "edited_declaration.json"
        edited.write_text(json.dumps(doc, indent=1), encoding="utf-8")
        keep = TL.DECL_FILE
        TL.DECL_FILE = str(edited)              # HERE / an absolute path = that path: the shipped file is not touched
        try:
            rc = TL.cmd_run(args(root, data, tmp / "out_edit"))
        finally:
            TL.DECL_FILE = keep
        check(rc == 3 and not (tmp / "out_edit").exists(), "w4 an edited declaration is refused")
        rc = TL.cmd_run(args(root, data, root / "inside"))
        check(rc == 3, "w4 an output folder inside the cache is refused")
        p2 = tmp / "panel_no_tv.parquet"
        pd.read_parquet(root / "panel_oc" / "panel.parquet").drop(columns=[TL.TURNOVER]).to_parquet(p2, index=False)
        rc = TL.cmd_run(args(root, data, tmp / "out_tv", panel=str(p2)))
        check(rc == 3, "w4 a panel without %s is refused" % TL.TURNOVER)
        root4, data4, _ = make_world(tmp / "short", 7, "absent", last_signal="2022-06-30")
        rc = TL.cmd_run(args(root4, data4, tmp / "out_short"))
        check(rc == 3 and not (tmp / "out_short").exists(), "w4 a watchlist without a test year is refused")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("")
    print("%d checks, %d failed (%.0f s)" % (N_OK[0] + len(FAILS), len(FAILS), time.time() - t0))
    if FAILS:
        print("FAILED")
        for f in FAILS:
            print(" - " + f)
        return 1
    print("VERIFIED (%s)" % TL.VERSION)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
