"""
treelab.py - treelab v1.0: every knob of setuplab's frozen entry tree (calm and jumpy, both engines) searched together
on the 2021-26 history, and judged walk-forward.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\treelab
    python tests\\test_treelab.py
    python treelab.py run --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --out C:\\QuantData\\treelab

Karan, 22 Nov 2026: "How can we make the entire tree- calm and jumpy more profitable?" ... "dont mind searching the
same history. Infact I'd prefer that." ... "Go".

WHAT IT DOES
  The tree (TREE.json, frozen 9 Nov 2026) has knobs that were set once, by hand. treelab tries every combination of
  8 knobs for each engine's book - 6,480 trees for D and 6,480 for ENS - plus 5 ways to split the account between the
  two books:
    ranks traded            1-3 (frozen), 1-2, 1-5
    positions per book      3 (frozen), 2, 4
    calm / jumpy cut-off    ATR at or below the year's 2/3 quantile (frozen), 1/2, 4/5 (picks before 1 January)
    calm entry              D frozen: the FIRST calm pick that opened at or above its close; ENS frozen: EVERY calm
                            pick at the open; the other options: every calm pick that opened at or above its close
    jumpy entry             the seven frozen setups (frozen), the six Tuesday setups, N1 only, jumpy picks skipped
    exit                    as frozen (D5 close; N1 4 sessions after its entry), D4 close, D6 open, D7 close, D10 close
    sizing                  equal (frozen), or x min(1, the year's frozen cut-off / the pick's ATR)
    liquidity               none (frozen), or skip a trade bigger than 1% of the stock's median daily traded value
    D / ENS split           50/50 (frozen), 100/0, 70/30, 30/70, 0/100
  The books are setuplab's own: Rs 5 L a book, each entry 1/k of the book's value, all positions busy = skipped,
  0.35 points a round trip; the simulator is checked to give setuplab's tree_sim exactly at the frozen settings.

HOW IT IS JUDGED (TREELAB_DECLARATION.json, declared before any run)
  Walk-forward. For 2023 the best tree is chosen using 2021-22 only; for 2024 using 2021-23; and so on to 2026.
  "Best" = the highest a year with a worst fall of 25% or less on those years (each engine's book, then the split).
  The four test years - each chosen without seeing it - are joined and compared, day by day, with the frozen tree on
  the same days (both rebuilt the same way: the account split restarts each 1 January).
    PASS = the daily gain over the frozen tree has a 95% block-bootstrap interval above 0 AND the joined worst fall is
           no deeper than the frozen tree's. Then the tree chosen on all of 2021-26 is TREE v2: a candidate for a
           second paper book beside the frozen one (a new tree with its own freeze date; the frozen tree is unchanged).
    FAIL = searching the history does not beat the frozen tree on days it did not see: keep the frozen tree.
  Shown, never deciding: the 6,480 trees on all of 2021-26 (searched and judged on the same years - optimistic),
  each knob's best and median, and the six Tuesday setups before / after 1 Sep 2025 (NSE's weekly expiry moved to
  Tuesday that day - the day those setups buy).

Example: if in 2021-22 the best D book traded ranks 1-2 with 4 positions and sold at the D7 close, that is the D book
used for 2023; whatever 2023 then does is what the search earned. Do that for 2023-26, join the four years, and compare
with the frozen tree on the same days.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import heapq
import itertools
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
_d = os.environ.get("SETUPLAB_DIR") or str(HERE.parent / "setuplab")
if _d not in sys.path:
    sys.path.insert(0, _d)
import setuplab as SU  # noqa: E402

VERSION = "treelab v1.0"
NEEDS = {"setuplab": "setuplab v1.1"}
DECL_FILE = "TREELAB_DECLARATION.json"
COST = SU.COST
PATH = SU.PATH
QUANT = {"2/3": 2 / 3, "1/2": 1 / 2, "4/5": 4 / 5}
KNOBS = ("ranks", "positions", "cutoff", "calm", "jumpy", "exit", "sizing", "liquidity")
OPTS = {"ranks": (3, 2, 5), "positions": (3, 2, 4), "cutoff": ("2/3", "1/2", "4/5"),
        "calm": {"D": ("first_up", "all_up", "all"), "ENS": ("all", "first_up", "all_up")},
        "jumpy": ("all7", "tue6", "n1", "skip"), "exit": ("frozen", "d4", "o6", "d7", "d10"),
        "sizing": ("equal", "invvol"), "liquidity": ("none", "cap1")}
SPLITS = (0.5, 1.0, 0.7, 0.3, 0.0)        # D's share of the account; 0.5 = frozen
FALL_CAP = 25.0                           # points: the worst fall a chosen tree may have on the selection years
FIRST_TEST = 2                            # the window's 3rd calendar year is the first test year
BOOK_RS = 5e5                             # rupees a book (TREE.json: Rs 5 L)
LIQ_SHARE = 0.01                          # liquidity cap: a trade at most 1% of the median daily traded value
TURNOVER = "x_turnover_med"               # the panel's 60-session median of close x volume (rupees a day)
EXPIRY_FROM = "2025-09-01"                # SEBI: NSE equity-derivative expiries on Tuesday from this day
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
GROUP = 8
LOG = SU.say if hasattr(SU, "say") else (lambda m: print("%s  %s" % (time.strftime("%H:%M:%S"), m), flush=True))


class TLError(Exception):
    pass


def constants():
    return {"knobs": list(KNOBS), "options": {k: (v if not isinstance(v, dict) else {e: list(x) for e, x in v.items()})
                                             for k, v in OPTS.items()},
            "quantiles": QUANT, "splits": list(SPLITS), "fall_cap": FALL_CAP, "first_test": FIRST_TEST,
            "book_rs": BOOK_RS, "liq_share": LIQ_SHARE, "turnover": TURNOVER, "expiry_from": EXPIRY_FROM,
            "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "cost_pp": COST, "path": PATH}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise TLError("no declaration at %s (it ships beside treelab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise TLError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise TLError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(),
              Path(SU.__file__).resolve().parent):
        if o == b or b in o.parents:
            raise TLError("--out %s is inside %s - outputs go under C:\\QuantData\\treelab" % (o, b))
    return o


def ledger(out, rec):
    with open(Path(out) / "treelab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


# ====================================================================================================== inputs
def load_book(data, panel, cols, log=LOG):
    """setuplab's Book of every pick (D and ENS, every rank) with the columns given at the session before each watch
    day (column 1 = the signal day)."""
    data = Path(data)
    for nm in ("watchlist.parquet", "calendar.parquet"):
        if not (data / nm).is_file():
            raise TLError("no %s in %s (setuplab build writes the watchlist folder)" % (nm, data))
    wl = pd.read_parquet(data / "watchlist.parquet")
    cal = pd.read_parquet(data / "calendar.parquet")["date"]
    book = SU.Book(wl, cal, None, None, None, None)
    book.prev_session = True
    missing = []
    for s in range(0, len(cols), GROUP):
        got, ms = book.attach(panel, cols[s:s + GROUP], chunk=GROUP)
        missing += ms
    log(" read the panel: %d columns for %d picks" % (len(cols), book.n))
    return book, missing


def replays(bk, fconds, primary):
    """Each frozen setup on every pick (setuplab's trigger and exits): its fill day (0 = none) and its net at its
    primary exit."""
    out = {}
    for sid, cc in fconds.items():
        day, st = SU.trigger(bk, list(cc))
        r = SU.exits_arr(bk, day, st, primary[sid])
        out[sid] = (np.where(st == "Filled", day, 0).astype(np.int64), r["ret"])
    return out


def first_fill(su, order, primary, i1):
    """setuplab's tree_first_setup for the setups given: su = {id: (filled, watch day, net at the primary exit)}."""
    n = len(i1)
    sid = np.full(n, "", dtype=object)
    sk = np.zeros(n, dtype=np.int64)
    snet = np.full(n, np.nan)
    for s_ in order:
        f, k, net = su[s_]
        k = np.asarray(k, float)
        f = np.asarray(f, bool) & np.isfinite(k)
        better = f & ((sk == 0) | (np.where(f, k, 1e9) < sk))
        sid[better], sk[better], snet[better] = s_, k[better].astype(np.int64), np.asarray(net, float)[better]
    has = sk > 0
    ent = np.where(has, np.asarray(i1) + sk - 1, -1)
    ex = np.full(n, -1, dtype=np.int64)
    for s_ in order:
        m = has & (sid == s_)
        ex[m] = np.where(primary[s_] == "fresh", ent[m] + 4, np.asarray(i1)[m] + 4)
    return sid, sk, ent, ex, snet


def cutoffs(bk, q, tdoc=None):
    """year -> the q quantile of s_atr14 over every complete pick (D and ENS, every rank) whose signal day is before
    1 January of the year (setuplab's rule at q = 2/3; at 2/3 a year without 100 such picks takes TREE.json's)."""
    comp = SU.tree_complete(bk)
    sday = np.asarray(bk.signal_day).astype("datetime64[D]")
    atr = np.asarray(bk.atr, float)
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    declared = {int(k): float(v) for k, v in tdoc["lane"]["cutoffs"].items()} if (tdoc and q == QUANT["2/3"]) else {}
    out = {}
    for y in sorted(set(int(x) for x in years)):
        ref = comp & (sday < np.datetime64("%d-01-01" % y))
        v = atr[ref]
        v = v[np.isfinite(v)]
        if len(v) >= 100:
            out[y] = float(np.quantile(v, q))
        elif y in declared:
            out[y] = declared[y]
    return out


def frozen_picks(bk, fills, order, primary, tdoc, cuts):
    """setuplab's tree_history_picks with the replays (not a TAGS run): the frame setuplab's tree_run_books takes."""
    su = {s: (fills[s][0] > 0, np.where(fills[s][0] > 0, fills[s][0], np.nan), fills[s][1]) for s in order}
    sid, sk, sent, sex, snet = first_fill(su, order, primary, bk.i1)
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    return pd.DataFrame({"trade_id": bk.ids, "engine": bk.engine_arr, "rank": bk.rank, "symbol": bk.symbols,
                         "sday": bk.signal_day, "i1": bk.i1, "o1": bk.O[:, 1], "sc": bk.sc, "c5": bk.C[:, 5],
                         "s_atr14": bk.atr, "lane": SU.tree_lanes(bk.atr, years, cuts),
                         "etf": SU.tree_etf(bk.symbols, tdoc), "complete": SU.tree_complete(bk),
                         "su_id": sid, "su_k": sk, "su_ent": sent, "su_ex": sex,
                         "su_net": np.where(sk > 0, snet, np.nan)})


def window_start(bk, cuts23):
    """s_ = the first session of the first year with a cut-off and picks (setuplab's history window)."""
    years = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
    lane_years = sorted(y for y in cuts23 if (years == y).any())
    if not lane_years:
        raise TLError("no year of the watchlist has a tree cut-off")
    return int(np.searchsorted(bk.cal, np.datetime64("%d-01-01" % lane_years[0])))


def window_end(bk, books):
    """t1 = the end of the frozen books' trades (the tree's and the baselines'), as setuplab's history."""
    ex = [int(b[0]["ex"].max()) for b in books.values() if len(b[0])]
    if not ex:
        raise TLError("the frozen books have no trades")
    return int(min(len(bk.cal) - 1, max(ex)))


# ====================================================================================================== the books
class Eng:
    """One engine's candidate picks (ranks 1-5, complete, signal day in the window) with everything a tree needs."""

    def __init__(self, bk, e, s_, cuts, frozen_cut, fills, order, primary, tdoc, turnover):
        sday = np.asarray(bk.signal_day).astype("datetime64[D]")
        m = (bk.engine_arr == e) & (bk.rank <= max(OPTS["ranks"])) & SU.tree_complete(bk) & \
            (sday >= np.asarray(bk.cal[s_]).astype("datetime64[D]"))
        r = np.flatnonzero(m)
        self.e, self.rows = e, r
        self.rank = bk.rank[r]
        self.sday = sday[r]
        self.i1 = bk.i1[r]
        self.o1, self.sc, self.atr = bk.O[r, 1], bk.sc[r], np.asarray(bk.atr, float)[r]
        self.ids, self.sym = bk.ids[r], bk.symbols[r]
        self.etf = SU.tree_etf(bk.symbols, tdoc)[r]
        self.year = pd.DatetimeIndex(bk.signal_day[r]).year.to_numpy()
        self.cut = {q: np.array([cuts[q].get(int(y), np.nan) for y in self.year]) for q in QUANT}
        fc = np.array([frozen_cut.get(int(y), np.nan) for y in self.year])
        with np.errstate(invalid="ignore", divide="ignore"):
            self.m_inv = np.where(np.isfinite(self.atr) & (self.atr > 0) & np.isfinite(fc),
                                  np.minimum(1.0, fc / self.atr), 1.0)
        self.tv = np.asarray(turnover, float)[r]
        self.fill = {s: fills[s][0][r] for s in order}
        self.order, self.primary = list(order), dict(primary)
        self.O, self.C = bk.O, bk.C
        # one id per signal day (for "the first calm pick of the evening")
        _, self.day_id = np.unique(self.sday, return_inverse=True)
        self._plans = {}

    def plan(self, ranks, cutq, calm, jumpy, exit_):
        """The trades of one tree (ranks, cut-off, calm entry, jumpy entry, exit), sorted as setuplab's tree_sim:
        (entry, rank, symbol, trade id). -> dict of arrays (book row, entry, exit, entry day k, net, size multiplier,
        turnover)."""
        key = (ranks, cutq, calm, jumpy, exit_)
        if key in self._plans:
            return self._plans[key]
        n = len(self.rows)
        sel = self.rank <= ranks
        cut = self.cut[cutq]
        nocut = ~np.isfinite(cut)
        with np.errstate(invalid="ignore"):
            calm_ = ~nocut & (self.atr <= cut)
        act = sel & ~self.etf & ~nocut
        known = np.isfinite(self.o1)
        with np.errstate(invalid="ignore"):
            up = known & np.isfinite(self.sc) & (self.o1 >= self.sc)
        bought = np.zeros(n, bool)
        if calm == "first_up":
            cand = np.flatnonzero(act & calm_ & up)
            if len(cand):
                o = cand[np.lexsort((self.rank[cand], self.day_id[cand]))]
                first = o[np.r_[True, self.day_id[o][1:] != self.day_id[o][:-1]]]
                bought[first] = True
            elig = act & ~bought
        elif calm == "all_up":
            bought = act & calm_ & up
            elig = act & ~bought
        elif calm == "all":
            bought = act & calm_ & known
            elig = act & ~bought & ~calm_
        else:
            raise TLError("calm entry %r" % calm)
        use = {"all7": self.order, "tue6": [s for s in self.order if s != "N1"], "n1": ["N1"], "skip": []}[jumpy]
        sk = np.zeros(n, np.int64)
        sid = np.full(n, "", dtype=object)
        for s in use:
            k = self.fill[s]
            better = elig & (k > 0) & ((sk == 0) | (k < sk))
            sk[better], sid[better] = k[better], s
        has = sk > 0
        ob, sb = np.flatnonzero(bought & known), np.flatnonzero(has)
        rows = np.r_[ob, sb]
        d = np.r_[np.ones(len(ob), np.int64), sk[sb]]
        fresh = np.r_[np.zeros(len(ob), bool), np.array([self.primary.get(s) == "fresh" for s in sid[sb]], bool)]
        br = self.rows[rows]
        i1 = self.i1[rows]
        pin = self.O[br, d]
        if exit_ == "frozen":
            x = np.where(fresh, d + 4, 5)
        elif exit_ == "d4":
            x = np.maximum(4, d)
        elif exit_ == "o6":
            x = np.full(len(d), 5)                          # held to the D5 close, sold at the D6 open
        elif exit_ == "d7":
            x = np.full(len(d), 7)
        elif exit_ == "d10":
            x = np.full(len(d), 10)
        else:
            raise TLError("exit %r" % exit_)
        x = np.minimum(x, PATH)
        pout = self.O[br, 6] if exit_ == "o6" else self.C[br, x]
        ex = i1 + (5 if exit_ == "o6" else x - 1)           # o6: sold at the D6 open (index i1 + 5)
        # setuplab's rule (exits_arr): every close from the entry day to the exit day must be known
        j = np.arange(1, PATH + 1)[None, :]
        win = (j >= d[:, None]) & (j <= x[:, None])
        held = ~(win & ~np.isfinite(self.C[br, 1:])).any(1) if len(br) else np.zeros(0, bool)
        with np.errstate(invalid="ignore", divide="ignore"):
            net = (pout / pin - 1) * 100 - COST
        ok = np.isfinite(net) & np.isfinite(pin) & (pin > 0) & held
        rows, d, br, i1, net, ex = rows[ok], d[ok], br[ok], i1[ok], net[ok], ex[ok]
        ent = i1 + d - 1
        o = np.lexsort((self.ids[rows], self.sym[rows], self.rank[rows], ent))
        how = np.r_[np.full(len(ob), "open", dtype=object), sid[sb]][ok]
        P = {"row": rows[o], "br": br[o], "ent": ent[o], "ex": ex[o], "ek": d[o], "net": net[o],
             "m_inv": self.m_inv[rows][o], "tv": self.tv[rows][o], "rank": self.rank[rows][o], "how": how[o],
             "open_exit": np.full(len(o), exit_ == "o6")}
        self._plans[key] = P
        return P


def sim(P, O, C, i1_all, s0, t1, k, sizing="equal", liquidity="none"):
    """setuplab's tree_sim, trade by trade (the same numbers): a k-position book worth 1.0 at s0 on calendar indices
    s0..t1; each entry gets 1/k of the book's closed value (x the sizing multiplier) at its entry open, all positions
    busy = skipped, a full tie in setuplab's order; an exit at a close frees the position from the next open, an exit
    at an open (the D6-open exit) frees it for that same open and is marked to the close before.
    liquidity "cap1": a trade bigger than LIQ_SHARE of its median daily traded value (the book = BOOK_RS rupees at 1.0)
    is skipped (unknown turnover: not skipped). -> (closed value, marked value, taken mask, sizes)."""
    ent, ex, net, br, ek = P["ent"], P["ex"], P["net"], P["br"], P["ek"]
    oexit = P.get("open_exit")
    key = ex - 0.5 * oexit if oexit is not None else ex.astype(float)
    keep = np.flatnonzero((ent >= s0) & (ent <= t1))
    mm = P["m_inv"] if sizing == "invvol" else None
    cap = liquidity == "cap1"
    tv = P["tv"]
    nd = t1 - s0 + 1
    sizes = np.zeros(len(ent))
    taken = np.zeros(len(ent), bool)
    heap, realized = [], 0.0
    for j in keep:
        t = ent[j]
        while heap and heap[0][0] < t:
            _, jj = heapq.heappop(heap)
            realized += sizes[jj] * net[jj] / 100
        if len(heap) < k:
            size = (1.0 + realized) / k
            if mm is not None:
                size *= mm[j]
            if size > 0 and not (cap and size * BOOK_RS > LIQ_SHARE * tv[j]):
                sizes[j] = size
                taken[j] = True
                heapq.heappush(heap, (key[j], j))
    tk = np.flatnonzero(taken)
    pnl = sizes[tk] * net[tk] / 100
    exd = ex[tk] - s0
    inside = exd <= nd - 1
    eqc = 1.0 + np.cumsum(np.bincount(exd[inside], weights=pnl[inside], minlength=nd)[:nd])
    eqm = eqc.copy()
    # open positions at each close: size x (close / entry price - 1), as tree_sim marks them
    lens = np.minimum(ex[tk], t1 + 1) - ent[tk]          # sessions open at a close: entry .. exit - 1
    has = lens > 0
    if has.any():
        tk2, L = tk[has], lens[has]
        start = ent[tk2]
        rep = np.repeat(np.arange(len(tk2)), L)
        off = np.arange(L.sum()) - np.repeat(np.cumsum(L) - L, L)
        t = start[rep] + off
        b = br[tk2][rep]
        kk = t - i1_all[b] + 1
        pin = O[br[tk2], ek[tk2]][rep]
        ok = (kk >= 1) & (kk <= PATH)
        c_ = np.where(ok, C[b, np.clip(kk, 1, PATH)], np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            good = np.isfinite(c_) & np.isfinite(pin) & (pin > 0)
            val = np.where(good, sizes[tk2][rep] * (c_ / pin - 1), 0.0)
        np.add.at(eqm, t - s0, val)
    return np.maximum(eqc, 0.0), np.maximum(eqm, 0.0), taken, sizes


def path_stats(v, cal, s0, upto):
    """A year and worst fall (%) of a marked value path (1.0 at s0) from s0 to calendar index upto."""
    w = v[:upto - s0 + 1]
    yrs = float((cal[upto] - cal[s0]) / np.timedelta64(1, "D")) / 365.25
    ay = (w[-1] ** (1 / yrs) - 1) * 100 if (w[-1] > 0 and yrs > 0) else -100.0
    fall = float(100 * np.max(1 - w / np.maximum.accumulate(w))) if len(w) else np.nan
    return float(ay), fall


# ====================================================================================================== the search
def configs(e):
    """Every tree of one engine: tuples of knob values, the frozen tree first (every knob's first option)."""
    lists = [OPTS[k][e] if k == "calm" else OPTS[k] for k in KNOBS]
    return list(itertools.product(*lists))


def cfg_words(c, e):
    r, k, q, calm, j, x, s, liq = c
    cw = {"first_up": "the first calm pick that opened at or above its close", "all_up": "every calm pick that opened "
          "at or above its close", "all": "every calm pick at the open"}[calm]
    jw = {"all7": "the 7 frozen setups", "tue6": "the 6 Tuesday setups", "n1": "N1 only", "skip": "skipped"}[j]
    xw = {"frozen": "as frozen", "d4": "D4 close", "o6": "D6 open", "d7": "D7 close", "d10": "D10 close"}[x]
    return "ranks 1-%d, %d positions, calm = ATR <= %s quantile, calm: %s, jumpy: %s, exit %s%s%s" % (
        r, k, q, cw, jw, xw, ", sized down by ATR" if s == "invvol" else "",
        ", liquidity cap 1%" if liq == "cap1" else "")


def cfg_short(c):
    r, k, q, calm, j, x, s, liq = c
    return "r%d p%d c%s %s %s %s %s %s" % (r, k, q, calm, j, x, s, liq)


def search(E, bk, s_, t1, ends, log=LOG):
    """Every tree of one engine on start day 1: its a year and worst fall over the whole window and over each
    selection period (s_ .. ends[y]). -> DataFrame (one row per tree, the frozen tree first)."""
    cs = configs(E.e)
    rows = []
    t0 = time.time()
    for n_, c in enumerate(cs):
        r, k, q, calm, j, x, s, liq = c
        P = E.plan(r, q, calm, j, x)
        eqc, eqm, taken, _ = sim(P, bk.O, bk.C, bk.i1, s_, t1, k, s, liq)
        ay, fall = path_stats(eqm, bk.cal, s_, t1)
        yrs = float((bk.cal[t1] - bk.cal[s_]) / np.timedelta64(1, "D")) / 365.25
        row = {"engine": E.e, "i": n_, "tree": cfg_short(c), **dict(zip(KNOBS, c)), "a_year": ay, "fall": fall,
               "end": float(eqm[-1]), "trades_week": float(taken.sum() / (yrs * 52.18))}
        for y, pe in ends.items():
            a2, f2 = path_stats(eqm, bk.cal, s_, pe)
            row["a_year_to_%d" % (y - 1)], row["fall_to_%d" % (y - 1)] = a2, f2
        rows.append(row)
        if (n_ + 1) % 648 == 0:
            log(" %s: %d of %d trees (%.0f s)" % (E.e, n_ + 1, len(cs), time.time() - t0))
    return pd.DataFrame(rows)


def choose(G, ay_col, fall_col, cap=FALL_CAP):
    """The highest a year with a worst fall at or under the cap (a tie: the earlier tree, the frozen tree first);
    none under the cap: the frozen tree (row 0). -> row index, whether the fallback was used."""
    ok = G[fall_col].to_numpy(float) <= cap
    if not ok.any():
        return 0, True
    a = np.where(ok, G[ay_col].to_numpy(float), -np.inf)
    return int(np.flatnonzero(a == a.max())[0]), False


def choose_split(vD, vE, cal, s_, pe, cap=FALL_CAP):
    """The split (D's share) with the highest a year at a worst fall at or under the cap, on the two books' paths from
    s_ to pe (each book 1.0 at s_, compounding on its own); none: 50/50."""
    best, bi, rows = None, None, []
    for w in SPLITS:
        v = w * vD[:pe - s_ + 1] + (1 - w) * vE[:pe - s_ + 1]
        ay, fall = path_stats(v, cal, s_, pe)
        rows.append((w, ay, fall))
        if fall <= cap and (best is None or ay > best):
            best, bi = ay, w
    return (bi if bi is not None else 0.5), rows, bi is None


def year_returns(vD, vE, w, s_, pe, ye):
    """Daily returns of an account split w : 1-w between two books at the close of pe (the last session before the
    year), each book's path rescaled to 1 there; the days pe+1 .. ye."""
    def rel(v):
        seg = v[pe - s_: ye - s_ + 1]
        return seg / seg[0] if seg[0] > 0 else np.ones(len(seg))    # a book at 0 stays at 0: no return
    v = w * rel(vD) + (1 - w) * rel(vE)
    with np.errstate(invalid="ignore", divide="ignore"):
        r = np.where(v[:-1] > 0, v[1:] / v[:-1] - 1, 0.0)
    return r


def decide(diff_lo, fall_wf, fall_fz):
    """The declared rule: PASS = the daily gain's 95% interval above 0 and a worst fall no deeper than the frozen
    tree's; otherwise FAIL."""
    above = bool(np.isfinite(diff_lo) and diff_lo > 0)
    shallower = bool(np.isfinite(fall_wf) and np.isfinite(fall_fz) and fall_wf <= fall_fz)
    return ("PASS" if (above and shallower) else "FAIL"), above, shallower


def walk_forward(GD, GE, ED, EE, bk, s_, t1, ends, log=LOG):
    """Each test year: each engine's tree chosen on the years before it, then the split; the year's daily returns of
    the chosen account and of the frozen one (50/50, the same yearly restart)."""
    cD, cE = configs("D"), configs("ENS")
    curves = {}

    def curve(E, cs, i):
        if (E.e, i) not in curves:
            r, k, q, calm, j, x, s, liq = cs[i]
            curves[(E.e, i)] = sim(E.plan(r, q, calm, j, x), bk.O, bk.C, bk.i1, s_, t1, k, s, liq)[1]
        return curves[(E.e, i)]

    fzD, fzE = curve(ED, cD, 0), curve(EE, cE, 0)
    rows, rWF, rFZ, days = [], [], [], []
    for y, pe in ends.items():
        ycol, fcol = "a_year_to_%d" % (y - 1), "fall_to_%d" % (y - 1)
        iD, fbD = choose(GD, ycol, fcol)
        iE, fbE = choose(GE, ycol, fcol)
        vD, vE = curve(ED, cD, iD), curve(EE, cE, iE)
        w, srows, fbW = choose_split(vD, vE, bk.cal, s_, pe)
        ye = int(np.flatnonzero(pd.DatetimeIndex(bk.cal[:t1 + 1]).year == y)[-1])
        rw = year_returns(vD, vE, w, s_, pe, ye)
        rf = year_returns(fzD, fzE, 0.5, s_, pe, ye)
        rWF.append(rw)
        rFZ.append(rf)
        days.append(bk.cal[pe + 1: ye + 1])
        rows.append({"year": y, "chosen_on": "%s .. %s" % (pd.Timestamp(bk.cal[s_]).date(), pd.Timestamp(bk.cal[pe]).date()),
                     "D_tree": cfg_short(cD[iD]), "D_words": cfg_words(cD[iD], "D"), "D_i": iD, "D_fallback": fbD,
                     "ENS_tree": cfg_short(cE[iE]), "ENS_words": cfg_words(cE[iE], "ENS"), "ENS_i": iE,
                     "ENS_fallback": fbE, "D_share": w, "split_fallback": fbW,
                     "year_return_pct": float((np.prod(1 + rw) - 1) * 100),
                     "frozen_year_return_pct": float((np.prod(1 + rf) - 1) * 100),
                     "year_fall_pct": worst_fall_of(np.r_[1.0, np.cumprod(1 + rw)]),
                     "frozen_year_fall_pct": worst_fall_of(np.r_[1.0, np.cumprod(1 + rf)]),
                     "sel_D_a_year": float(GD.at[iD, ycol]), "sel_D_fall": float(GD.at[iD, fcol]),
                     "sel_ENS_a_year": float(GE.at[iE, ycol]), "sel_ENS_fall": float(GE.at[iE, fcol]),
                     "sel_frozen_D_a_year": float(GD.at[0, ycol]), "sel_frozen_ENS_a_year": float(GE.at[0, ycol])})
        log(" walk-forward %d: D %s | ENS %s | D share %.1f -> %+.1f%% (frozen %+.1f%%)" % (
            y, cfg_short(cD[iD]), cfg_short(cE[iE]), w, rows[-1]["year_return_pct"],
            rows[-1]["frozen_year_return_pct"]))
    rWF, rFZ, days = np.concatenate(rWF), np.concatenate(rFZ), np.concatenate(days)
    return pd.DataFrame(rows), rWF, rFZ, days, curves


def worst_fall_of(v):
    v = np.asarray(v, float)
    return float(100 * np.max(1 - v / np.maximum.accumulate(v))) if len(v) else np.nan


def five_starts(E, c, bk, s_, t1):
    """setuplab's history convention for one book: the five start days -> per start day (closed-value a year, marked
    worst fall, end) and the start-day-1 marked path."""
    r, k, q, calm, j, x, s, liq = c
    P = E.plan(r, q, calm, j, x)
    out, first = [], None
    for p_ in range(5):
        s0 = s_ + p_
        eqc, eqm, taken, _ = sim(P, bk.O, bk.C, bk.i1, s0, t1, k, s, liq)
        yrs = float((bk.cal[t1] - bk.cal[s0]) / np.timedelta64(1, "D")) / 365.25
        out.append({"a_year": (eqc[-1] ** (1 / yrs) - 1) * 100 if eqc[-1] > 0 else -100.0,
                    "fall": worst_fall_of(eqm), "end": float(eqc[-1]), "eqc": eqc, "eqm": eqm})
        if p_ == 0:
            first = eqm
    return out, first


def account_five(oD, oE, w, bk, s_, t1):
    """The two books' five start days combined as setuplab's 'both' group (w and 1-w of the account, each book
    compounding on its own) -> mean a year, mean worst fall, mean end."""
    res = []
    for p_, (a, b) in enumerate(zip(oD, oE)):
        s0 = s_ + p_
        eqc, eqm = w * a["eqc"] + (1 - w) * b["eqc"], w * a["eqm"] + (1 - w) * b["eqm"]
        yrs = float((bk.cal[t1] - bk.cal[s0]) / np.timedelta64(1, "D")) / 365.25
        res.append(((eqc[-1] ** (1 / yrs) - 1) * 100 if eqc[-1] > 0 else -100.0, worst_fall_of(eqm), float(eqc[-1])))
    a = np.array(res)
    return float(a[:, 0].mean()), float(a[:, 1].mean()), float(a[:, 2].mean())


# ====================================================================================================== the Tuesday check
def complete_rows(bk):
    with np.errstate(invalid="ignore"):
        return (bk.ok & np.isfinite(bk.O[:, 1:6]).all(1) & np.isfinite(bk.C[:, 1:10]).all(1) & (bk.O[:, 1] > 0))


def pooled_rows(bk, ok):
    """One row per (signal day, stock): its best rank, D first."""
    key = np.char.add(np.char.add(pd.DatetimeIndex(bk.signal_day).strftime("%Y-%m-%d").to_numpy().astype(str), "|"),
                      bk.symbols.astype(str))
    eo = np.where(bk.engine_arr == "D", 0, np.where(bk.engine_arr == "ENS", 1, 2))
    idx = np.flatnonzero(ok)
    o = idx[np.lexsort((eo[idx], bk.rank[idx], key[idx]))]
    ks = key[o]
    first = o[np.r_[True, ks[1:] != ks[:-1]]] if len(o) else o
    return np.sort(first)


def tuesday_check(bk, fills, weekly_ids, etf):
    """The six Tuesday setups on every pooled pick: net per trade at their D5 close, entries before vs on or after
    EXPIRY_FROM (95% block bootstrap over signal days, the same draws for both periods)."""
    R = pooled_rows(bk, complete_rows(bk) & ~etf)
    B_ = SU.Boot(bk.signal_day[R], B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    di = B_.index(bk.signal_day[R])
    out = []
    lanes = [("WEEKLY (earliest of the six)", list(weekly_ids))] + [(s, [s]) for s in weekly_ids]
    for name, ids in lanes:
        day = np.zeros(len(R), np.int64)
        net = np.full(len(R), np.nan)
        for s in ids:
            d, nt = fills[s][0][R], fills[s][1][R]
            better = (d > 0) & ((day == 0) | (d < day))
            day[better], net[better] = d[better], nt[better]
        f = (day > 0) & np.isfinite(net)
        ent = np.asarray(bk.cal[np.clip(bk.i1[R] + day - 1, 0, len(bk.cal) - 1)]).astype("datetime64[D]")
        aft = f & (ent >= np.datetime64(EXPIRY_FROM))
        bef = f & ~aft
        row = {"lane": name}
        for nm, m in (("before", bef), ("after", aft)):
            row[nm + "_trades"] = int(m.sum())
            row[nm + "_net"] = float(net[m].mean()) if m.any() else np.nan
            lo, hi = B_.ci_idx(di[m], net[m]) if m.sum() >= 2 else (np.nan, np.nan)
            row[nm + "_lo"], row[nm + "_hi"] = lo, hi
            ed = pd.DatetimeIndex(ent[m])
            row[nm + "_tuesday_share"] = float((ed.weekday == 1).mean()) if m.any() else np.nan
        if bef.sum() >= 2 and aft.sum() >= 2:
            lo, hi, _ = B_.ci_diff(di[aft], net[aft], di[bef], net[bef])
        else:
            lo, hi = np.nan, np.nan
        row["after_minus_before"] = row["after_net"] - row["before_net"]
        row["diff_lo"], row["diff_hi"] = lo, hi
        out.append(row)
    return pd.DataFrame(out)


# ====================================================================================================== the report
def _p(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "-"
    return ("%+." + str(nd) + "f") % x if sign else ("%." + str(nd) + "f") % x


def _ci(lo, hi, nd=2):
    return "[%s, %s]" % (_p(lo, nd), _p(hi, nd))


def marginals(G):
    out = []
    for k in KNOBS:
        for v in pd.unique(G[k]):
            g = G[G[k] == v]
            ok = g[g["fall"] <= FALL_CAP]
            out.append({"engine": G["engine"].iloc[0], "knob": k, "option": v,
                        "best_a_year": float(ok["a_year"].max()) if len(ok) else np.nan,
                        "median_a_year": float(g["a_year"].median()), "median_fall": float(g["fall"].median())})
    return pd.DataFrame(out)


def write_report(d, info, R):
    L = ["# %s - every knob of the frozen entry tree, searched on 2021-26 and judged walk-forward (%s)" % (
        VERSION, d.name), "",
         "Karan, 22 Nov 2026: *\"How can we make the entire tree- calm and jumpy more profitable?\"* ... *\"dont mind "
         "searching the same history. Infact I'd prefer that.\"* ... *\"Go\"*. Rules: `TREELAB_DECLARATION.json` "
         "sha256 `%s` (declared before any run). Picks: %s. Window: %s .. %s." % (
             info["declaration_sha256"][:16], info["picks"], R["window"][0], R["window"][1]), ""]
    dec = R["decision"]
    L += ["## THE DECISION: **%s**" % dec["verdict"], "",
          "Walk-forward, %s .. %s: each year's trees chosen on the years before it, joined, against the frozen tree on "
          "the same days (both accounts restart their D / ENS split each 1 January). Start day 1." % (
              dec["from"], dec["to"]), "",
          "| account | a year | worst fall |", "|---|---|---|",
          "| the walk-forward trees | %+.1f%% | %.1f%% |" % (dec["wf_a_year"], dec["wf_fall"]),
          "| the frozen tree (50/50) | %+.1f%% | %.1f%% |" % (dec["fz_a_year"], dec["fz_fall"]), "",
          "- Daily gain over the frozen tree: %s bp a day %s (95%%, block bootstrap over the days). Above 0: **%s**" % (
              _p(dec["diff"]), _ci(dec["diff_lo"], dec["diff_hi"]), "yes" if dec["above"] else "no"),
          "- Worst fall no deeper than the frozen tree's: **%s**" % ("yes" if dec["shallower"] else "no"), "",
          "PASS = both. Then TREE v2 below (chosen on all of 2021-26) is a candidate for a second paper book beside the "
          "frozen tree - a new tree with its own freeze date; the frozen tree does not change. FAIL = searching the "
          "history does not beat the frozen tree on days it did not see: keep the frozen tree.", ""]
    L += ["## Each test year (trees chosen on the years before it)", "",
          "| year | chosen on | D book | ENS book | D's share | that year | frozen tree | its worst fall | frozen's |",
          "|---|---|---|---|---:|---:|---:|---:|---:|"]
    for r in R["wf"].to_dict("records"):
        L.append("| %d | %s | %s%s | %s%s | %.0f%% | %+.1f%% | %+.1f%% | %.1f%% | %.1f%% |" % (
            r["year"], r["chosen_on"], r["D_tree"], " (fallback)" if r["D_fallback"] else "", r["ENS_tree"],
            " (fallback)" if r["ENS_fallback"] else "", 100 * r["D_share"], r["year_return_pct"],
            r["frozen_year_return_pct"], r["year_fall_pct"], r["frozen_year_fall_pct"]))
    L += ["", "Tree codes: r = ranks 1-r, p = positions, c = the calm cut-off quantile, then calm entry (first_up = the "
          "first calm pick that opened at or above its close; all_up = every such pick; all = every calm pick), jumpy "
          "entry (all7 / tue6 / n1 / skip), exit (frozen / d4 / o6 = D6 open / d7 / d10), sizing (equal / invvol), "
          "liquidity (none / cap1). The frozen D tree is `r3 p3 c2/3 first_up all7 frozen equal none`; the frozen ENS "
          "tree `r3 p3 c2/3 all all7 frozen equal none`.", ""]
    v2 = R["v2"]
    L += ["## TREE v2 - the trees chosen on all of 2021-26 %s" % (
        "(the candidate: the decision PASSED)" if dec["verdict"] == "PASS" else "(shown only: the decision FAILED)"),
          "",
          "- D book: %s" % v2["D_words"], "- ENS book: %s" % v2["ENS_words"],
          "- D's share of the account: %.0f%%" % (100 * v2["D_share"]), "",
          "| account, 2021-26, the mean of 5 start days | a year | worst fall | Rs 5 L became |", "|---|---|---|---|",
          "| TREE v2 | %+.1f%% | %.1f%% | Rs %.1f L |" % (v2["a_year"], v2["fall"], 5 * v2["end"]),
          "| the frozen tree | %+.1f%% | %.1f%% | Rs %.1f L |" % (R["frozen5"]["a_year"], R["frozen5"]["fall"],
                                                              5 * R["frozen5"]["end"]), "",
          "Searched and judged on the same years: optimistic by construction. The decision above is the honest number.",
          ""]
    L += ["## In-sample: the 6,480 trees of each engine on 2021-26 (start day 1; optimistic)", ""]
    for e in ("D", "ENS"):
        G = R["grid"][e]
        fz = G.iloc[0]
        ok = G[G["fall"] <= FALL_CAP].sort_values("a_year", ascending=False)
        rank_fz = int((ok["a_year"] > fz["a_year"]).sum()) + 1 if fz["fall"] <= FALL_CAP else None
        L += ["### %s book" % e, "",
              "The frozen %s tree: %+.1f%% a year, worst fall %.1f%% (%s of the %d trees with a worst fall at or under "
              "%.0f%%)." % (e, fz["a_year"], fz["fall"], ("rank %d" % rank_fz) if rank_fz else "not among",
                            len(ok), FALL_CAP), "",
              "| # | tree | a year | worst fall | trades a week |", "|---|---|---:|---:|---:|"]
        for i, r in enumerate(ok.head(10).to_dict("records"), 1):
            L.append("| %d | %s | %+.1f%% | %.1f%% | %.2f |" % (i, r["tree"], r["a_year"], r["fall"],
                                                              r["trades_week"]))
        M = R["marg"][e]
        L += ["", "Knob by knob (the best a year with a worst fall at or under %.0f%%, and the median a year, over "
              "every tree with that option):" % FALL_CAP, "",
              "| knob | option | best a year | median a year | median worst fall |", "|---|---|---:|---:|---:|"]
        for r in M.to_dict("records"):
            L.append("| %s | %s | %s | %s | %s |" % (r["knob"], r["option"], _p(r["best_a_year"], 1),
                                                     _p(r["median_a_year"], 1), _p(r["median_fall"], 1, False)))
        L.append("")
    T = R["tuesday"]
    L += ["## The six Tuesday setups before and after %s (NSE's weekly expiry moved to Tuesday that day)" % EXPIRY_FROM,
          "", "Every pooled pick (D and ENS, ranks 1-10), net per trade at the D5 close, by entry day. Shown, not "
          "deciding.", "",
          "| lane | before: trades, net [95%] | after: trades, net [95%] | after minus before [95%] |",
          "|---|---|---|---|"]
    for r in T.to_dict("records"):
        L.append("| %s | %d, %s %s | %d, %s %s | %s %s |" % (
            r["lane"], r["before_trades"], _p(r["before_net"]), _ci(r["before_lo"], r["before_hi"]),
            r["after_trades"], _p(r["after_net"]), _ci(r["after_lo"], r["after_hi"]), _p(r["after_minus_before"]),
            _ci(r["diff_lo"], r["diff_hi"])))
    L += ["", "## Checks", ""] + ["- %s: %s" % (k, v) for k, v in info["checks"].items()]
    L += ["", "## How to read it", "",
          "- A tree is one setting of all 8 knobs for one engine's book; the account adds the D / ENS split.",
          "- The search uses start day 1 (the window's first session); the five-start means are the tree's own "
          "convention and shown for the frozen tree and TREE v2.",
          "- A year and worst fall in the search: from the book's value marked to market each close.",
          "- A D6-open exit sells at the D6 open: the slot is free for that open, and the position is marked at the D5 "
          "close until then.",
          "- Liquidity cap: the trade's rupees (its share of the book x Rs 5 L x the book's growth) against 1% of the "
          "stock's 60-session median daily traded value at the signal day; as the book compounds the cap bites more.",
          "- Everything before the decision line is in-sample: these years built the tree. The walk-forward joins four "
          "years that each tree did not see when it was chosen; the forward paper ledger stays the final judge.", ""]
    (d / "TREELAB.md").write_text("\n".join(L), encoding="utf-8")


# ====================================================================================================== the run
def resolve_inputs(a):
    root = Path(a.root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    if not panel.is_file():
        raise TLError("panel not found: %s" % panel)
    return root, panel


def cmd_run(a, log=LOG):
    t0 = time.time()
    try:
        dp, ddoc = load_declaration()
        if SU.VERSION != NEEDS["setuplab"]:
            raise TLError("needs %s beside this folder (found %s)" % (NEEDS["setuplab"], SU.VERSION))
        root, panel = resolve_inputs(a)
        out = guard_out(a.out, root)
        _, fdoc = SU.load_frozen()
        _, tdoc = SU.load_tree()
        import pyarrow.parquet as pq
        have = {c.lower() for c in pq.read_schema(panel).names}
        fconds = SU.frozen_conds(fdoc)
        ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
        need = [f for f in ffeats + [TURNOVER] if f not in have]
        if need:
            raise TLError("the panel lacks: %s" % ", ".join(need))
        primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
        order = [s for s in SU.TREE_ORDER if s in fconds]
        weekly_ids = [s for s in order if any(f.startswith("w_") for f, _, _ in fconds[s])]
        if len(order) != 7 or "N1" not in order or len(weekly_ids) != 6:
            raise TLError("expected the seven frozen setups (six weekly + N1), found %s" % order)
        bk, miss = load_book(a.data, panel, list(dict.fromkeys(ffeats + [TURNOVER])), log)
    except (TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    log("%s: declaration %s; frozen setups %s; tree %s" % (VERSION, ddoc["sha256"][:16], fdoc["sha256"][:16],
                                                          tdoc["sha256"][:16]))
    fills = replays(bk, fconds, primary)
    etf = SU.tree_etf(bk.symbols, tdoc)
    cuts = {q: cutoffs(bk, v, tdoc) for q, v in QUANT.items()}
    P0 = frozen_picks(bk, fills, order, primary, tdoc, cuts["2/3"])
    try:
        s_ = window_start(bk, cuts["2/3"])
        books, _ = SU.tree_run_books(P0, bk, s_)
        t1 = window_end(bk, books)
    except TLError as e:
        print("REFUSED: %s" % e)
        return 3
    turnover = bk.F[TURNOVER][:, 1] if TURNOVER in bk.F else np.full(bk.n, np.nan)
    ED = Eng(bk, "D", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, turnover)
    EE = Eng(bk, "ENS", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, turnover)
    checks = {"picks": "%d rows (D %d, ENS %d), %d of ranks 1-5 in the window (D %d, ENS %d); signal days %s .. %s" % (
        bk.n, int((bk.engine_arr == "D").sum()), int((bk.engine_arr == "ENS").sum()), len(ED.rows) + len(EE.rows),
        len(ED.rows), len(EE.rows), pd.Timestamp(bk.signal_day.min()).date(), pd.Timestamp(bk.signal_day.max()).date()),
        "missing columns": ", ".join(miss) or "none",
        "median daily traded value known": "%.1f%% of the window's picks" % (
            100 * np.isfinite(np.r_[ED.tv, EE.tv]).mean() if len(ED.tv) + len(EE.tv) else 0)}
    # ---- the gate: this simulator = setuplab's, and the frozen tree = TREE.json's history
    gate = []
    for E, nm, calm in ((ED, "D tree", "first_up"), (EE, "ENS tree", "all")):
        Tt, prow = books[nm]
        mine = E.plan(3, "2/3", calm, "all7", "frozen")
        a1 = np.sort(np.c_[prow[Tt["row"].to_numpy(np.int64)], Tt["ent"], Tt["ex"], Tt["ek"]].astype(np.int64), axis=0)
        a2 = np.sort(np.c_[mine["br"], mine["ent"], mine["ex"], mine["ek"]].astype(np.int64), axis=0)
        same_tr = a1.shape == a2.shape and bool((a1 == a2).all())
        n1 = np.sort(Tt["net"].to_numpy(float))
        n2 = np.sort(mine["net"])
        same_net = len(n1) == len(n2) and bool(np.allclose(n1, n2, rtol=0, atol=1e-9))
        worst = 0.0
        for p_ in range(5):
            eqc1, eqm1, _ = SU.tree_sim(Tt, prow, bk.O, bk.C, bk.i1, s_ + p_, t1)
            eqc2, eqm2, _, _ = sim(mine, bk.O, bk.C, bk.i1, s_ + p_, t1, 3)
            worst = max(worst, float(np.max(np.abs(eqm1 - eqm2))), float(np.max(np.abs(eqc1 - eqc2))))
        gate.append((nm, same_tr, same_net, worst))
    okg = all(g[1] and g[2] and g[3] < 1e-9 for g in gate)
    checks["this simulator vs setuplab's tree_plan and tree_sim (frozen trees, 5 start days)"] = "; ".join(
        "%s: trades %s, nets %s, values within %.1e" % (g[0], "same" if g[1] else "DIFFERENT", "same" if g[2] else
                                                         "DIFFERENT", g[3]) for g in gate)
    if not okg:
        print("REFUSED: this simulator does not reproduce setuplab's frozen tree (%s)" % checks[
            "this simulator vs setuplab's tree_plan and tree_sim (frozen trees, 5 start days)"])
        return 3
    res, _, _ = SU.tree_history(bk, P0, books, s_, t1, reruns=0, log=lambda *x: None)
    window = [str(pd.Timestamp(bk.cal[s_]).date()), str(pd.Timestamp(bk.cal[t1]).date())]
    ref = tdoc.get("history_reference", {})
    fr = {g: {k: float(np.mean([d_[k] for d_ in L])) for k in ("a_year", "fall", "end")} for g, L in res.items()}
    if window == ref.get("window"):
        rec = all(abs(fr[g]["a_year"] - ref[g]["a_year_pct"]) <= SU.TREE_TOL and
                  abs(fr[g]["fall"] - ref[g]["worst_fall_pct"]) <= SU.TREE_TOL for g, _ in SU.TREE_GROUPS
                  if g in ref and g in fr)
        checks["the frozen tree vs TREE.json's history"] = "%s (D tree %+.2f%% a year, worst fall %.2f%%)" % (
            "REPRODUCES" if rec else "DOES NOT REPRODUCE", fr["D tree"]["a_year"], fr["D tree"]["fall"])
        if not rec:
            print("REFUSED: the frozen tree does not reproduce TREE.json's history on its own window (%s)" %
                  checks["the frozen tree vs TREE.json's history"])
            return 3
    else:
        checks["the frozen tree vs TREE.json's history"] = "n/a: window %s .. %s, TREE.json's %s" % (
            window[0], window[1], " .. ".join(ref.get("window", ["?", "?"])))
    years = sorted(set(pd.DatetimeIndex(bk.cal[s_:t1 + 1]).year))
    tests = [y for y in years if y >= years[0] + FIRST_TEST]
    cy = pd.DatetimeIndex(bk.cal[:t1 + 1]).year
    ends = {y: int(np.flatnonzero(cy == y - 1)[-1]) for y in tests}
    if not tests or any(e_ <= s_ for e_ in ends.values()):
        print("REFUSED: the window %s .. %s has no test year (the first is the window's year %d)" % (
            window[0], window[1], FIRST_TEST + 1))
        return 3
    checks["walk-forward"] = "test years %s; each chosen on %s .. the year before" % (
        ", ".join(str(y) for y in tests), window[0])
    for k, v in checks.items():
        log(" %s: %s" % (k, v))
    if a.check_only:
        log("CHECK OK - inputs readable, the simulator reproduces setuplab's frozen tree; nothing searched or written.")
        return 0
    d = SU.new_run_dir(out, "TREELAB")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": ddoc["sha256"], "frozen_sha256": fdoc["sha256"],
                 "tree_sha256": tdoc["sha256"], "watchlist": str(Path(a.data) / "watchlist.parquet")})
    log("the search: %d trees per engine" % len(configs("D")))
    GD = search(ED, bk, s_, t1, ends, log)
    GE = search(EE, bk, s_, t1, ends, log)
    log("the walk-forward")
    WF, rWF, rFZ, days, curves = walk_forward(GD, GE, ED, EE, bk, s_, t1, ends, log)
    x = (np.log1p(rWF) - np.log1p(rFZ)) * 1e4
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    lo, hi = B_.ci_idx(np.arange(len(x)), x)
    vWF, vFZ = np.r_[1.0, np.cumprod(1 + rWF)], np.r_[1.0, np.cumprod(1 + rFZ)]
    yrs = float((days[-1] - bk.cal[ends[tests[0]]]) / np.timedelta64(1, "D")) / 365.25
    fall_wf, fall_fz = worst_fall_of(vWF), worst_fall_of(vFZ)
    verdict, above, shallower = decide(lo, fall_wf, fall_fz)
    dec = {"verdict": verdict, "from": str(pd.Timestamp(days[0]).date()), "to": str(pd.Timestamp(days[-1]).date()),
           "diff": float(x.mean()), "diff_lo": lo, "diff_hi": hi, "above": above, "shallower": shallower,
           "wf_a_year": (vWF[-1] ** (1 / yrs) - 1) * 100, "fz_a_year": (vFZ[-1] ** (1 / yrs) - 1) * 100,
           "wf_fall": fall_wf, "fz_fall": fall_fz}
    log(" THE DECISION: %s - daily gain %s bp %s; worst fall %.1f%% vs the frozen tree's %.1f%%" % (
        verdict, _p(dec["diff"]), _ci(lo, hi), fall_wf, fall_fz))
    # ---- TREE v2: chosen on all of 2021-26 (the same rule)
    cD, cE = configs("D"), configs("ENS")
    iD, fbD = choose(GD, "a_year", "fall")
    iE, fbE = choose(GE, "a_year", "fall")
    oD, pD = five_starts(ED, cD[iD], bk, s_, t1)
    oE, pE = five_starts(EE, cE[iE], bk, s_, t1)
    w2, srows2, fbW = choose_split(pD, pE, bk.cal, s_, t1)
    a2, f2, e2 = account_five(oD, oE, w2, bk, s_, t1)
    fD, pfD = five_starts(ED, cD[0], bk, s_, t1)
    fE, pfE = five_starts(EE, cE[0], bk, s_, t1)
    a0, f0, e0 = account_five(fD, fE, 0.5, bk, s_, t1)
    v2 = {"D": cfg_short(cD[iD]), "ENS": cfg_short(cE[iE]), "D_words": cfg_words(cD[iD], "D") + (
        " (fallback: no tree under the cap)" if fbD else ""), "ENS_words": cfg_words(cE[iE], "ENS") + (
        " (fallback: no tree under the cap)" if fbE else ""), "D_share": w2, "a_year": a2, "fall": f2, "end": e2,
        "D_config": dict(zip(KNOBS, cD[iD])), "ENS_config": dict(zip(KNOBS, cE[iE]))}
    tues = tuesday_check(bk, fills, weekly_ids, etf)
    R = {"window": window, "decision": dec, "wf": WF, "v2": v2, "frozen5": {"a_year": a0, "fall": f0, "end": e0},
         "grid": {"D": GD, "ENS": GE}, "marg": {"D": marginals(GD), "ENS": marginals(GE)}, "tuesday": tues}
    # ---- outputs
    files = []
    GD.to_csv(d / "grid_D.csv", index=False)
    GE.to_csv(d / "grid_ENS.csv", index=False)
    WF.to_csv(d / "walkforward.csv", index=False)
    pd.concat([R["marg"]["D"], R["marg"]["ENS"]]).to_csv(d / "knobs.csv", index=False)
    tues.to_csv(d / "tuesday_expiry.csv", index=False)
    cv = pd.DataFrame({"date": pd.DatetimeIndex(bk.cal[s_:t1 + 1]).date, "frozen_D": pfD, "frozen_ENS": pfE,
                       "v2_D": pD, "v2_ENS": pE})
    cv.to_csv(d / "curves.csv", index=False, float_format="%.6f")
    pd.DataFrame({"date": pd.DatetimeIndex(days).date, "walkforward_return": rWF, "frozen_return": rFZ,
                  "walkforward_value": vWF[1:], "frozen_value": vFZ[1:]}).to_csv(
        d / "walkforward_daily.csv", index=False, float_format="%.8f")
    files += ["grid_D.csv", "grid_ENS.csv", "walkforward.csv", "knobs.csv", "tuesday_expiry.csv", "curves.csv",
              "walkforward_daily.csv"]
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": ddoc["sha256"], "tree_sha256": tdoc["sha256"], "frozen_sha256": fdoc["sha256"],
              "window": window, "decision": {k: v for k, v in dec.items()},
              "walk_forward": WF.to_dict("records"), "tree_v2": v2,
              "frozen_five_starts": {"a_year": a0, "fall": f0, "end": e0}}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "TREELAB_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info = {"version": VERSION, "declaration_sha256": ddoc["sha256"], "picks": checks["picks"],
            "frozen_sha256": fdoc["sha256"], "tree_sha256": tdoc["sha256"], "root": str(root), "panel": str(panel),
            "data": str(a.data), "checks": checks, "decision": verdict}
    write_report(d, info, R)
    (d / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    files += ["TREELAB_RESULT.json", "DECLARATION.json", "TREELAB.md", "RUN.json"]
    SU.write_hashes(d, files)
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "decision": verdict, "diff_bp": dec["diff"], "diff_lo": lo, "diff_hi": hi, "wf_fall": fall_wf,
                 "frozen_fall": fall_fz, "tree_v2": {"D": v2["D"], "ENS": v2["ENS"], "D_share": w2},
                 "minutes": round((time.time() - t0) / 60, 1)})
    log("TREELAB WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    log(" THE DECISION: %s (walk-forward %s .. %s: %+.1f%% a year, worst fall %.1f%%; frozen %+.1f%%, %.1f%%)" % (
        verdict, dec["from"], dec["to"], dec["wf_a_year"], fall_wf, dec["fz_a_year"], fall_fz))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="treelab", description=VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="search every knob of the tree and judge it walk-forward (or --check-only)")
    r.add_argument("--root", required=True, help="CACHE_DAILY_ROOT (panel_oc\\panel.parquet lives under it)")
    r.add_argument("--data", required=True, help="setuplab's watchlist folder (watchlist.parquet, calendar.parquet)")
    r.add_argument("--out", required=True, help="output folder, e.g. C:\\QuantData\\treelab")
    r.add_argument("--panel", default=None, help="default <root>\\panel_oc\\panel.parquet")
    r.add_argument("--check-only", action="store_true", help="inputs and the simulator check; nothing searched")
    a = ap.parse_args(argv)
    return cmd_run(a)


if __name__ == "__main__":
    raise SystemExit(main())
