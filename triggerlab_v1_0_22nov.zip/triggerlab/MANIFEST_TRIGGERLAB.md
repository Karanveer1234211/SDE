# MANIFEST - triggerlab v1.0 (22 Nov 2026)

Folder: `C:\Users\karanvsi\PyCharmMiscProject\triggerlab` (a research folder beside `treelab`, `setuplab` and
`tradelab`). Nothing here goes into `bigmove_deploy`. Writes only under `C:\QuantData\triggerlab`.

| file | sha256 (first 16) | bytes |
|---|---|---|
| `triggerlab.py` | a0342ef93421a11b | 81461 |
| `TRIGGERLAB_DECLARATION.json` | a6851dd8d3a0780b | 10458 |
| `README_TRIGGERLAB.md` | 209b881d93d8d559 | 8601 |
| `tests\test_triggerlab.py` | 506bc278352373b7 | 45320 |
| `MANIFEST_TRIGGERLAB.md` | this file | - |

Needs, read only, as sibling folders (versions checked at every start):
- treelab v1.0 (treelab.py sha16 64ac932f584fade1);
- setuplab v1.1 (setuplab.py sha16 9979d418aecec6de, with FROZEN_SETUPS.json and TREE.json);
- tradelab v1.3.1 (tl_data.py sha16 46ceff88fdadda7f, tl_common.py sha16 ad7e75715da7556a);
- through tradelab's env (env_tradelab.bat): stage_e_execution (the shipped v1.2, as tradelab requires) and intraday_cache.

Declaration: `TRIGGERLAB_DECLARATION.json`, internal sha256 `251a3cff0e14b208...`. It was declared at 13:10 IST on 22 Nov 2026, before any run on real data. Its recorded time was corrected at 18:14 IST (it had said 13:40); the rules are unchanged. It is checked at every start against this code's settings, and an edited file is refused.

Inputs:
- the panel (`%CACHE_DAILY_ROOT%\panel_oc\panel.parquet`: the frozen setups' inputs);
- setuplab's watchlist folder (`C:\QuantData\setuplab\WL_R1_10`);
- the daily cache, through stage E's loader;
- the 3-minute bars (`intraday_cache.store`).

## History
- v1.0 (22 Nov 2026): first build.
  - The tree's picks (D and ENS ranks 1-3), calm and jumpy separately: 18 entry triggers x 960 exits (stop, target, trailing stop, breakeven, time) per engine and lane.
  - Fills: stops and targets settled on the 3-minute bars; gaps fill at the open; locked sales wait for the next unlocked open.
  - Dynamic: each lane uses 1-3 triggers, each with its own exit (borrowed from the lane below 100 entries), or the frozen rule.
  - Judged walk-forward against the frozen tree on the same prices. PASS -> THE STRATEGY is a candidate for a paper book; FAIL -> keep the frozen tree.
  - Reports win %, planned and realised RR, expectancy, profit factor and the break-even win %, in-sample and out of sample.

## Verified (synthetic data only)
`tests\test_triggerlab.py` ends `24 checks, 0 failed` / `VERIFIED (triggerlab v1.0)` on Python 3.13 in both of these (about 250 s each):
- pandas 3.0.5 + numpy 2.5.3;
- pandas 2.3.3 + numpy 2.4.1.

What the checks cover:
- **The books:** the book equals setuplab's tree_sim and treelab's sim (frozen trees, 5 start days, 2 / 3 / 4 positions). The frozen tree on the cache's prices equals treelab's plan; its trades sold on a locked close leave later.
- **Triggers:** every trigger is checked against an independent bar-by-bar replay (485 picks, all 18 triggers).
- **Exits:** every exit is checked against an independent day-by-day, bar-by-bar replay (2,000 entries x 55 exits covering every option). This includes days settled by 3-minute bars, the stop-first rule and locked sales.
- **Hand-built trades:**
  - a gap through the stop;
  - a stop and a target in one day: the bars' order decides, and with no bars the stop counts first;
  - the trailing stop's ratchet, breakeven and the D6 open;
  - a locked close waiting for the next unlocked open;
  - a fill inside the day stopped only by the bars after it;
  - an unknown fill time.
- **The choice:** own exit vs the lane's common exit, the 25% cap's edge, ties, and the first-to-fire merge of 1-3 triggers.
- **The firewall:** every price after a selection period's end is changed and the triggers re-run; all of that period's selection numbers stay the same.
- **Per-trade numbers:** checked by hand.
- **Planted world** (volatile stocks fall, a gap down is followed by a rise):
  - it PASSES (+30.49 bp a day [+21.84, +38.80], worst fall 6.9% vs 18.9%);
  - the jumpy lanes leave the frozen entry;
  - every test year's choice is re-run from the exact grid;
  - the joined days and the decision are rebuilt by hand from the chosen codes.
- **No-edge world** (no drift, no cost) FAILS.
- **Refusals:**
  - an edited declaration;
  - an output folder inside the cache;
  - a panel missing a setup's input;
  - no test year;
  - 5% of the picks' prices off the cache's;
  - 3-minute bars stamped in UTC;
  - no 3-minute folder.

  `--check-only` writes nothing, and every output is hash-checked.

**Mutation test:** 18 deliberate bugs, each in its own copy of triggerlab.py, and every one makes the tests fail. The bugs were:
- the dip limit, the breakout level, the VWAP rule and the opening range;
- the gap fill, the same-bar tie, the trail's start, the breakeven level and the entry-day window;
- the locked close and the book's slot release;
- borrowing, the walk-forward's period, the period's settled trades and the merge's tie;
- the frozen trades' exit, the common exit and the stop's fill price.
