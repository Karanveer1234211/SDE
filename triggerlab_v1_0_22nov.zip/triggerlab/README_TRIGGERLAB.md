# triggerlab v1.0 - entry triggers and exits for the tree's calm and jumpy picks, judged walk-forward

Your ask (22 Nov 2026): *"I want a strategy. On the tree itself. For both calm and jumpy. Which enters on a trigger.
THE TRIGGER NEED TO LOOKED OUT FOR. Rigorously. And exits and after a trigger. Fixed/trailing TP. Fixed/trailing SL.
This should/can be dynamic. And can be different for different events/triggers. It should have RR, win%."* - then
*"Go"* on the plan.

## What it does

The picks are the tree's own: D and ENS ranks 1-3, each one calm or jumpy by the tree's ATR cut-off.

**18 entry triggers**, each watched on D1-D5:

| trigger | what it does |
|---|---|
| OPEN / OPENUP | buy at the D1 open / only if it opens at or above the signal-day close |
| S1 S2 S3 C1 C2 C3 N1 | the frozen setup, bought at its fill day's open |
| ANY7 | the first of the seven frozen setups (the tree's jumpy entry) |
| DIP05 / DIP10 / DIP15 | limit buy 0.5 / 1 / 1.5 ATR under the previous close |
| BRK | buy-stop at the previous session's high |
| GAPREV | after an open 0.5 ATR or more under the previous close: buy-stop at the first 15 minutes' high |
| ORB15 / ORB30 | buy-stop at the first 15 / 30 minutes' high |
| VWAP | buy at the next 3-minute open after a close back above VWAP (it closed below earlier; by 14:30) |

**960 exits for each trigger** - every combination of:

| part | options |
|---|---|
| stop (fixed SL) | none, 0.5 / 1 / 1.5 / 2 ATR under the entry, the previous session's low |
| target (fixed TP) | none, 1 / 1.5 / 2 / 3 R (R = the stop's distance; no stop: 1 ATR) |
| trailing stop | none, 1.5 / 2 / 3 ATR under the highest close, live once a close is 1R up |
| breakeven | off / on (once a close is 1R up, the stop is at least the entry + the 0.35 cost) |
| time exit | the D5 close, the D6 open, the D7 close, the D10 close |

**How fills work** (same as tradelab):
- An open through a level fills at the open.
- When one day touches both the stop and the target, your 3-minute bars decide which came first; without usable bars the stop counts first.
- A sale on a locked lower circuit waits for the next unlocked open (stage E's rule).
- Cost: 0.35 a round trip.

**Dynamic, per lane and per trigger.** Each engine and lane (D calm, D jumpy, ENS calm, ENS jumpy) gets its own trigger(s), and each trigger its own exit.
- A trigger with fewer than 100 trades in the years it is chosen on borrows the lane's common exit.
- A lane can use 1, 2 or 3 triggers; a pick is bought by whichever fills first, and leaves by that trigger's exit.
- The lane can also stay on the frozen tree's own rule.

**Books:** the tree's (Rs 5 L, 3 positions, 1/3 a trade, all busy = skipped, D and ENS 50/50).

## How it is judged (declared before any run - `TRIGGERLAB_DECLARATION.json`, sha256 `251a3cff0e14b208...`)

The same walk-forward as treelab.

**Example.** For 2023, every trigger x exit is scored on 2021-22 only. Suppose jumpy D picks did best with a limit 1 ATR under the previous close, a stop 1.5 ATR below and a 2R target. Then jumpy D picks trade that way in 2023, and 2023's result counts. 2024 is chosen on 2021-23, and so on. The test years are joined and compared day by day with the frozen tree, on the same days and the same prices.

- **PASS** = two things, both:
  - the daily gain over the frozen tree has a 95% interval above 0;
  - the worst fall is no deeper than the frozen tree's.

  Then THE STRATEGY (chosen on all of 2021-26) is a candidate for a paper book beside the frozen tree, with its own freeze date. The frozen tree does not change.
- **FAIL** = keep the frozen tree.

Nothing is re-run with other settings to change a result.

**RR and win % come in two kinds.** Every trigger and exit reports its win %, planned RR, realised RR, expectancy, profit factor and break-even win % (the "How to read it" section of the report defines each).
- In-sample: all years, optimistic.
- Out of sample: the walk-forward's own trades in the test years. This is the one to trust.

**Already known:** stops, trails and profit targets were tested on the plain picks in Oct-Nov and closed. What's new here:
- calm and jumpy separately;
- per trigger, with exits that differ by trigger;
- the 3-minute bars settling which level was hit first.

If they still don't help on the tree, the "Do stops, targets and trails help here?" table will show it.

## Safety gates (it refuses rather than guess)

- **Declaration:** it must be the shipped file (the sha256 is checked).
- **Frozen tree:** the frozen D and ENS books must come out exactly as setuplab's (treelab's gate, re-run here). When the window is TREE.json's own, its history must also reproduce.
- **Prices:** each pick's cache bars must match the watchlist's prices within 0.5%. If more than 2% of picks don't, the run is refused.
- **3-minute bars:** the folder must exist and pass tradelab's layout check (e.g. bars stamped with the wrong time zone are refused).
- **Output folder:** it writes only under `--out`. An output folder inside the cache, triggerlab, treelab, setuplab or tradelab is refused.

## Commands (Windows cmd)

1. Put the zip's `triggerlab` folder next to `treelab` and `setuplab`:
   ```
   tar -xf %USERPROFILE%\Downloads\triggerlab_v1_0_22nov.zip -C C:\Users\karanvsi\PyCharmMiscProject
   ```
   This creates `C:\Users\karanvsi\PyCharmMiscProject\triggerlab\` with:
   - triggerlab.py
   - TRIGGERLAB_DECLARATION.json
   - this README
   - the MANIFEST
   - tests\test_triggerlab.py

   Nothing goes into `bigmove_deploy`. It needs treelab v1.0 (shipped today), setuplab v1.1 and tradelab v1.3.1 beside it.
2. Run the test. It uses synthetic data only and takes about 4-5 minutes:
   ```
   call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
   cd /d C:\Users\karanvsi\PyCharmMiscProject\triggerlab
   python tests\test_triggerlab.py
   ```
   It must end `24 checks, 0 failed` and `VERIFIED (triggerlab v1.0)`.
3. Check the inputs. This reads the bars and re-runs the gates; it searches and writes nothing:
   ```
   python triggerlab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\triggerlab --check-only
   ```
   It must end `CHECK OK`.
   - If it says REFUSED about `stage_e_execution.py`'s SHA, your stage E is not tradelab's shipped v1.2. Send me that line.
4. The run (my guess, not measured on your data: about 10 minutes - reading your bars is most of it):
   ```
   python triggerlab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\triggerlab
   ```
   It writes `C:\QuantData\triggerlab\TRIGGERLAB_<date>_<nnn>\` and a line in `C:\QuantData\triggerlab\triggerlab_ledger.jsonl`.

**Send back:** `TRIGGERLAB.md` (everything is in it). If convenient, also `strategy.csv`, `atlas.csv` and `walkforward.csv`.

## The outputs

| file | what |
|---|---|
| `TRIGGERLAB.md` | the decision; each test year's choice; the out-of-sample trades; THE STRATEGY; every trigger; do stops / targets / trails help; checks |
| `walkforward.csv` | each test year x engine x lane: the choice (code and words), the runners-up, that year's return vs the frozen tree |
| `walkforward_trades.csv` | every trade the walk-forward's choices took in the test years: entry, exit, net, the exit reason |
| `walkforward_daily.csv` | the joined test days: both accounts' daily returns and values |
| `oos.csv` | the out-of-sample per-trade view by engine and lane, against the frozen tree's trades |
| `strategy.csv` | THE STRATEGY's triggers with win %, RR, expectancy, profit factor, break-even win %, vs the open [95%] |
| `atlas.csv` | every engine x lane x trigger: its fill rate, the plain exit (D5 close) and its best exit |
| `exit_families.csv` | each stop / target / trail / breakeven / time option over the cells: best and median |
| `grid.csv`, `grid.parquet` | all 69,120 engine x lane x trigger x exit rows (the parquet is exact) |
| `TRIGGERLAB_RESULT.json` | the numbers above, hashed; `DECLARATION.json` a copy of the rules; `RUN.json`; `outputs.sha256` |

## How to read the codes

`GAPREV[a10/r20/t15/on/c7]` = trigger GAPREV, exit: stop 1 ATR under the entry / target 2R / trailing stop 1.5 ATR / breakeven on / else sell at the D7 close.

| part | codes |
|---|---|
| stop | `none`, `a05`-`a20` (ATRs under the entry), `plow` (the previous session's low) |
| target | `none`, `r10`-`r30` (1-3R) |
| trail | `none`, `t15`-`t30` |
| breakeven | `off`, `on` |
| time | `c5`, `o6`, `c7`, `c10` |

Several triggers joined by `+`: the first to fill buys. `FROZEN` = the frozen tree's own rule.
