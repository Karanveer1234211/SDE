"""
tests for triggerlab v1.0 - synthetic worlds only; nothing real is read, nothing outside a temporary folder is written.

    python tests\\test_triggerlab.py          (from the triggerlab folder, in tradelab's env)

Ends with  VERIFIED (triggerlab v1.0)  or  FAILED.
  u1  the book (book_sim) = setuplab's tree_sim and treelab's sim on the frozen trees: 5 start days, 2 / 3 / 4 positions
  u2  every trigger by an independent pick-by-pick, bar-by-bar replay (400 picks, all 18 triggers)
  u3  every exit by an independent trade-by-trade, day-by-day replay (2,000 entries x 52 exits covering every option)
  u4  hand-built trades: a gap through the stop, a stop and a target in one day settled by the 3-minute bars and,
      without them, the stop first; the trailing stop's ratchet; breakeven; the D6 open; a sale on a locked close
      waiting for the next unlocked open; a fill inside the day stopped only by the bars after it; an unknown fill
      time (a stop counts, a target does not)
  u5  the choice: own exit with N_MIN entries, the lane's common exit below it, the cap (25% counts), ties; the
      structure's first-to-fire merge by hand
  u6  the firewall: every price after a selection period's last session changed (daily and 3-minute, the triggers
      re-run): every selection number of that period stays the same for every cell and exit
  u7  the per-trade numbers (win %, RR, expectancy, profit factor, break-even win %) by hand
  w1  PLANTED world (volatile stocks fall, a gap down is followed by a rise): PASS; the walk-forward leaves the frozen
      jumpy entry; every test year's choice = the best on the years before it (re-run from the exact grid); the joined
      days and the decision re-computed by hand from the chosen codes; outputs hash-checked
  w2  ABSENT world (no drift and no cost - test only: no trigger or exit has an edge): no PASS
  w3  refusals: an edited declaration, an output folder inside the cache, a panel without a setup's input, no test year,
      the cache's prices off the watchlist's, 3-minute bars with the wrong stamps, no 3-minute folder; --check-only
      writes nothing
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import textwrap
import time
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import triggerlab as TG  # noqa: E402

TL, SU, TD, TC = TG.TL, TG.SU, TG.TD, TG.TC
FAILS = []
N_OK = [0]
IST = "Asia/Kolkata"
NB = TG.NB
SUB = 4


class _Quick(Exception):
    pass


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what)


# ---------------------------------------------------------------------------------------------- stand-in modules
STAGE_E = '''
"""TEST STAND-IN for stage_e_execution (load_bars, lower_locked) - NOT the production file."""
from pathlib import Path
import numpy as np
import pandas as pd
CODE_VERSION = "stage_e_execution TEST STAND-IN"
BANDS = (0.02, 0.05, 0.10, 0.20)


class Bars:
    def __init__(self, ts, o, h, l, c, v):
        self.ts, self.o, self.h, self.l, self.c, self.v = ts, o, h, l, c, v


def load_bars(root, syms):
    out = {}
    for s in syms:
        p = Path(root) / f"{s}_daily.parquet"
        if not p.exists():
            continue
        df = pd.read_parquet(p)
        t = pd.to_datetime(df["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        out[s] = Bars(t.values.astype("datetime64[ns]"), *(df[k].to_numpy(float) for k in ("open", "high", "low",
                                                                                              "close", "volume")))
    return out


def band_down(price, prev):
    return any(abs(price - round(prev * (1 - b), 2)) <= 0.011 for b in BANDS)


def lower_locked(b, j, side):
    if j <= 0:
        return False
    prev = b.c[j - 1]
    if side == "close":
        return bool(band_down(b.c[j], prev) and b.c[j] <= b.l[j] * (1 + 1e-9))
    return bool(band_down(b.o[j], prev) and b.o[j] <= b.l[j] * (1 + 1e-9))
'''
INTRADAY = '''
"""TEST STAND-IN for intraday_cache (store, BAR_MIN, path_for) - NOT the production file."""
from pathlib import Path
CODE_VERSION = "intraday_cache TEST STAND-IN"
BAR_MIN = 3


def store(root):
    return Path(root) / "intraday_3m"


def path_for(root, sym):
    return store(root) / f"{sym}_3m.parquet"
'''
DQ = '''
"""TEST STAND-IN for data_quality._paths - NOT the production file."""
from pathlib import Path


def _paths(root, symbol):
    return (Path(root) / f"{symbol}_daily.parquet", Path(root) / f"{symbol}_daily.ok.json")
'''


def use_mods(root):
    d = Path(root) / "_mods"
    d.mkdir(parents=True, exist_ok=True)
    for nm, txt in (("stage_e_execution", STAGE_E), ("intraday_cache", INTRADAY), ("data_quality", DQ)):
        (d / (nm + ".py")).write_text(textwrap.dedent(txt), encoding="utf-8")
        sys.modules.pop(nm, None)
    if str(d) in sys.path:
        sys.path.remove(str(d))
    sys.path.insert(0, str(d))


# ---------------------------------------------------------------------------------------------- the world
FZ = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_wq_44", "d_bb_bw_20"]
DRIFT_GOOD, DRIFT_BAD, BOOST = 0.0005, -0.008, 0.015


def make_world(base: Path, seed: int, mode: str, n_sym=30, per_day=5, start="2019-05-01", end="2025-06-30",
               i3_from="2021-10-01", n_locks=10, last_signal=None, utc_3m=False, no_3m=False):
    """root: <SYM>_daily.parquet (+ NIFTY50), intraday_3m\\<SYM>_3m.parquet (125 bars a session from i3_from, IST
    stamps), panel_oc\\panel.parquet (the frozen setups' inputs), _mods (stand-in production modules); data: setuplab's
    watchlist folder (D and ENS, ranks 1-per_day). The daily bars are the 3-minute bars' open / high / low / close.
    planted: volatile stocks (the top third of daily volatility) drift DRIFT_BAD a session, the rest DRIFT_GOOD; an
    open at least 1 sigma under the previous close starts BOOST a session for that session and the next three.
    absent: no drift. A few sessions are frozen at the lower 5% band (o = h = l = c)."""
    rng = np.random.default_rng(seed)
    root, data = base / "root", base / "data"
    for p in (root / "panel_oc", root / "intraday_3m", data):
        p.mkdir(parents=True, exist_ok=True)
    use_mods(root)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    i3 = int(np.searchsorted(cal, pd.Timestamp(i3_from)))
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]
    sig = rng.uniform(0.010, 0.025, n_sym)
    bad = sig >= np.quantile(sig, 2 / 3)
    locks = {(int(rng.integers(n_sym - 1)), int(rng.integers(i3 + 5, T - 15))) for _ in range(n_locks)}
    O, H, L, C, V = (np.zeros((n_sym, T)) for _ in range(5))
    offs = pd.to_timedelta(9 * 60 + 15 + 3 * np.arange(NB), unit="m")
    for s in range(n_sym):
        prev = 100.0 * np.exp(rng.normal(0, 0.4))
        boost = 0
        b3 = np.zeros((T - i3, NB, 5))
        for t in range(T):
            g = rng.normal(0, 0.5 * sig[s])
            if (s, t) in locks:
                px = round(prev * 0.95, 2)
                O[s, t] = H[s, t] = L[s, t] = C[s, t] = px
                V[s, t] = 1000.0
                if t >= i3:
                    b3[t - i3, :, :4] = px
                    b3[t - i3, :, 4] = 8.0
                prev, boost = px, 0
                continue
            if mode == "planted":
                if g <= -1.0 * sig[s]:
                    boost = 4
                mu = BOOST if boost > 0 else (DRIFT_BAD if bad[s] else DRIFT_GOOD)
                boost = max(boost - 1, 0)
            else:
                mu = 0.0
            op = prev * np.exp(g)
            stp = rng.normal(mu / (NB * SUB), sig[s] / np.sqrt(NB * SUB), NB * SUB)
            path = (op * np.exp(np.cumsum(stp))).reshape(NB, SUB)
            bc = path[:, -1]
            bo = np.r_[op, bc[:-1]]
            bh = np.maximum(bo, path.max(1))
            bl = np.minimum(bo, path.min(1))
            vb = rng.lognormal(8, 0.5, NB)
            O[s, t], H[s, t], L[s, t], C[s, t], V[s, t] = op, bh.max(), bl.min(), bc[-1], vb.sum()
            if t >= i3:
                b3[t - i3, :, 0], b3[t - i3, :, 1], b3[t - i3, :, 2], b3[t - i3, :, 3] = bo, bh, bl, bc
                b3[t - i3, :, 4] = vb
            prev = bc[-1]
        stamps = pd.DatetimeIndex(cal).tz_localize(IST)
        pd.DataFrame({"timestamp": stamps, "open": O[s], "high": H[s], "low": L[s], "close": C[s],
                      "volume": V[s]}).to_parquet(root / ("%s_daily.parquet" % syms[s]), index=False)
        if not no_3m:
            ts = (cal[i3:].values[:, None] + offs.values[None, :]).reshape(-1)
            tsi = pd.DatetimeIndex(ts)
            stamp = tsi if utc_3m else tsi.tz_localize(IST)            # utc_3m: IST clock written as naive UTC
            if utc_3m:
                stamp = (tsi - pd.Timedelta(minutes=330))
            pd.DataFrame({"timestamp": stamp, "open": b3[:, :, 0].ravel(), "high": b3[:, :, 1].ravel(),
                          "low": b3[:, :, 2].ravel(), "close": b3[:, :, 3].ravel(),
                          "volume": b3[:, :, 4].ravel()}).to_parquet(root / "intraday_3m" / ("%s_3m.parquet" % syms[s]),
                                                                      index=False)
    if no_3m:
        shutil.rmtree(root / "intraday_3m", ignore_errors=True)
    nifty = 18000 * np.exp(np.cumsum(rng.normal(0, 0.008, T)))
    pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": nifty, "high": nifty * 1.004,
                  "low": nifty * 0.996, "close": nifty, "volume": np.nan}).to_parquet(root / "NIFTY50_daily.parquet",
                                                                                     index=False)
    # the panel: the frozen setups' inputs (random walks; a weekly series stepping on a week's first session)
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)) * (rng.random((n_sym, T)) < 0.5), axis=1) for f in FZ}
    X["d_bb_pctb_20"] = rng.normal(0.5, 0.5, (n_sym, T))
    wk = cal.to_period("W-FRI").to_numpy()
    fow = np.r_[True, wk[1:] != wk[:-1]]
    X["w_ret_13w"] = np.cumsum(rng.normal(0, 3, (n_sym, T)) * fow[None, :] * (rng.random((n_sym, T)) < 0.5), axis=1)
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(cal, n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the watchlist: D and ENS ranks 1-per_day, from 2020
    atr = np.vstack([SU.atr_simple(H[s], L[s], C[s]) for s in range(n_sym)])
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    tz = T - 12 if last_signal is None else int(np.searchsorted(cal, pd.Timestamp(last_signal)))
    rows = []
    for t in range(t0, tz):
        for eng in ("D", "ENS"):
            for rk, s in enumerate(rng.choice(n_sym, per_day, replace=False), 1):
                e1 = O[s, t + 1]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": C[s, t], "entry": e1, "status": "ok",
                       "net_bp": (C[s, t + 5] / e1 - 1) * 1e4 - 35, "s_atr14": atr[s, t], "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[s, t + k] / e1 - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[s, t + k] / C[s, t + k - 1] - 1
                rows.append(row)
    pd.DataFrame(rows).to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return root, data, {"cal": cal, "bad": bad, "syms": syms, "locks": locks, "i3": i3}


def args(root, data, out, **kw):
    return SimpleNamespace(root=str(root), data=str(data), out=str(out), panel=kw.get("panel"),
                           check_only=kw.get("check_only", False), stage_e_any=True)


def runs(out):
    return sorted(p for p in Path(out).iterdir() if p.is_dir() and re.fullmatch(r"TRIGGERLAB_\d{8}_\d{3}", p.name))


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return len(lines) >= 10 and all(
        hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0] for ln in lines)


@contextmanager
def no_cost():
    """A world without the round-trip cost (test only): setuplab's, treelab's and triggerlab's cost 0; the
    declaration check still sees the shipped constants."""
    keep = (SU.COST, TL.COST, TG.COST, TG.constants)
    shipped = TG.constants()
    SU.COST, TL.COST, TG.COST = 0.0, 0.0, 0.0
    TG.constants = lambda: shipped
    try:
        yield
    finally:
        SU.COST, TL.COST, TG.COST, TG.constants = keep


def setup_world(root, data):
    """What cmd_run builds before the grid."""
    _, fdoc = SU.load_frozen()
    _, tdoc = SU.load_tree()
    fconds = SU.frozen_conds(fdoc)
    primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
    order = [s for s in SU.TREE_ORDER if s in fconds]
    ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
    bk, _ = TL.load_book(data, root / "panel_oc" / "panel.parquet", list(dict.fromkeys(ffeats)), log=lambda *a: None)
    fills = TL.replays(bk, fconds, primary)
    cuts = {q: TL.cutoffs(bk, v, tdoc) for q, v in TL.QUANT.items()}
    P0 = TL.frozen_picks(bk, fills, order, primary, tdoc, cuts["2/3"])
    s_ = TL.window_start(bk, cuts["2/3"])
    books, _ = SU.tree_run_books(P0, bk, s_)
    t1 = TL.window_end(bk, books)
    nan_tv = np.full(bk.n, np.nan)
    ED = TL.Eng(bk, "D", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, nan_tv)
    EE = TL.Eng(bk, "ENS", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, nan_tv)
    use_mods(root)
    mk = TD.Market(root, TD.Production(stage_e_any=True))
    U = TG.Universe(bk, cuts["2/3"], tdoc, s_)
    PA, why = TG.load_paths(U, bk, mk, log=lambda *a: None)
    U.keep(PA.ok)
    setup_days = {s: np.asarray(fills[s][0], np.int64)[U.ubr] for s in TG.SETUPS}
    E = TG.entries(PA, setup_days)
    EN = TG.Entries(PA, E)
    cal = bk.cal
    years = sorted(set(pd.DatetimeIndex(cal[s_:t1 + 1]).year))
    tests = [y for y in years if y >= years[0] + TG.FIRST_TEST]
    cy = pd.DatetimeIndex(cal[:t1 + 1]).year
    ends = {y: int(np.flatnonzero(cy == y - 1)[-1]) for y in tests}
    ctx = TG.Ctx(PA, EN, U, cal, s_, t1)
    for e, Eg, calm in (("D", ED, "first_up"), ("ENS", EE, "all")):
        Tz, _ = TG.frozen_trades(U, PA, bk, Eg, calm, primary)
        for ln in (0, 1):
            ctx.fz_lane[(e, ln)] = TG.lane_of(Tz, ln)
            ctx.fz_lane_path[(e, ln)] = ctx.lane_path(ctx.fz_lane[(e, ln)])
        ctx.fz_book[e] = ctx.lane_path(Tz)
    sel0 = np.flatnonzero(EN.g == TG.TRIGGERS.index("OPEN"))
    o0 = TG.exits(PA, EN, TG.EXITS[0], sel0)
    base_net = np.full(U.nu, np.nan)
    base_net[EN.u[sel0]] = o0["net"]
    return SimpleNamespace(bk=bk, fills=fills, cuts=cuts, s_=s_, t1=t1, ED=ED, EE=EE, U=U, PA=PA, why=why, E=E,
                           EN=EN, cal=cal, tests=tests, ends=ends, ctx=ctx, base_net=base_net,
                           setup_days=setup_days, primary=primary, tdoc=tdoc, books=books)


# ---------------------------------------------------------------------------------------------- reference replays
def ref_entries(PA, setup_days, u):
    """Every trigger on one pick, bar by bar (an independent replay of the declared rules)."""
    none = (0, np.nan, -1)
    out = {g: none for g in TG.TRIGGERS}
    if not PA.ok[u]:
        return out
    O, H, L, C, A = PA.O[u], PA.H[u], PA.L[u], PA.C[u], PA.A[u]
    if np.isfinite(O[1]):
        out["OPEN"] = (1, O[1], -1)
        if O[1] >= C[0]:
            out["OPENUP"] = (1, O[1], -1)
    best = 0
    for s in TG.SETUPS:
        k = int(setup_days[s][u])
        if 1 <= k <= 5 and np.isfinite(O[k]):
            out[s] = (k, O[k], -1)
            if best == 0 or k < best:
                best = k
    if best:
        out["ANY7"] = (best, O[best], -1)
    for g in ("DIP05", "DIP10", "DIP15", "BRK"):
        for j in range(1, 6):
            if g == "BRK":
                lvl = H[j - 1]
                if not (np.isfinite(O[j]) and np.isfinite(H[j]) and np.isfinite(lvl)):
                    continue
                if O[j] >= lvl:
                    out[g] = (j, O[j], -1)
                    break
                if H[j] >= lvl:
                    s_ = NB
                    if PA.us3[u, j]:
                        for b in range(NB):
                            if PA.h3[u, j, b] >= lvl:
                                s_ = b
                                break
                    out[g] = (j, lvl, s_)
                    break
            else:
                lvl = C[j - 1] - TG.DIP_K[g] * A
                if not (np.isfinite(O[j]) and np.isfinite(L[j]) and np.isfinite(lvl)):
                    continue
                if O[j] <= lvl:
                    out[g] = (j, O[j], -1)
                    break
                if L[j] <= lvl:
                    s_ = NB
                    if PA.us3[u, j]:
                        for b in range(NB):
                            if PA.l3[u, j, b] <= lvl:
                                s_ = b
                                break
                    out[g] = (j, lvl, s_)
                    break
    for g in ("GAPREV", "ORB15", "ORB30"):
        mb = TG.OR_BARS[g]
        done = False
        for j in range(1, 6):
            if done or not PA.us3[u, j]:
                continue
            if g == "GAPREV" and not (O[j] <= C[j - 1] - TG.GAP_ATR * A):
                continue
            rng_ = [PA.h3[u, j, b] for b in range(mb) if np.isfinite(PA.h3[u, j, b])]
            if not rng_:
                continue
            lvl = max(rng_)
            for b in range(mb, NB):
                if PA.h3[u, j, b] >= lvl:
                    out[g] = (j, max(float(PA.o3[u, j, b]), lvl), b)
                    done = True
                    break
    done = False
    for j in range(1, 6):
        if done or not PA.us3[u, j]:
            continue
        pv = vv = cnt = stp = 0.0
        seen = False
        for b in range(NB):
            h, lo, c = PA.h3[u, j, b], PA.l3[u, j, b], float(PA.c3[u, j, b])
            if not (np.isfinite(h) and np.isfinite(lo) and np.isfinite(c)):
                continue
            tp = (h + lo + c) / 3
            v = float(PA.v3[u, j, b])
            pv += tp * v
            vv += v
            cnt += 1
            stp += tp
            vw = pv / vv if vv > 0 else stp / cnt
            if seen and c > vw and b <= TG.VWAP_LAST:
                for b2 in range(b + 1, NB):
                    o2 = float(PA.o3[u, j, b2])
                    if np.isfinite(o2) and np.isfinite(PA.h3[u, j, b2]) and np.isfinite(float(PA.c3[u, j, b2])):
                        out["VWAP"] = (j, o2, b2)
                        done = True
                        break
                break
            if c < vw:
                seen = True
    return out


def ref_exit(PA, EN, i, x):
    """One entry under one exit, day by day and bar by bar."""
    stop, target, trail, be, tm = x
    u, d, p0, es, A = int(EN.u[i]), int(EN.d[i]), EN.p0[i], int(EN.es[i]), EN.A[i]
    if stop in TG.STOP_ATR:
        S = p0 - TG.STOP_ATR[stop] * A
    elif stop == "plow":
        pl = PA.L[u, d - 1]
        S = pl if (np.isfinite(pl) and pl < p0) else p0 - A
    else:
        S = -np.inf
    R = p0 - S if np.isfinite(S) else A
    T = p0 + TG.TARGET_R[target] * R if target != "none" else np.inf
    K = TG.TRAIL_ATR.get(trail)
    hc, armed, src = -np.inf, False, 1
    last = TG.TIME_DAY[tm]
    res = None
    amb = ""
    for j in range(d, last + 1):
        if tm == "o6" and j == 6:
            if np.isfinite(PA.O[u, 6]):
                res = (6, PA.O[u, 6], 0, 1)
            break
        o, h, lo, c = PA.O[u, j], PA.H[u, j], PA.L[u, j], PA.C[u, j]
        if not all(np.isfinite([o, h, lo, c])):
            continue
        start = 0
        if j > d:
            if o <= S:
                res = (j, o, 0, 6)
                break
            if o >= T:
                res = (j, o, 0, 7)
                break
            wl, wh = lo, h
        elif es == -1:
            wl, wh = lo, h
        elif es < NB:
            after = [b for b in range(es + 1, NB) if np.isfinite(PA.l3[u, j, b])]
            wl = min([PA.l3[u, j, b] for b in after], default=np.inf)
            wh = max([PA.h3[u, j, b] for b in after], default=-np.inf)
            start = es + 1
        else:
            wl, wh = lo, -np.inf
        hs, ht = wl <= S, wh >= T
        tfirst = False
        if hs and ht:
            if PA.us3[u, j]:
                fs = next((b for b in range(start, NB) if PA.l3[u, j, b] <= S), NB + 1)
                ft = next((b for b in range(start, NB) if PA.h3[u, j, b] >= T), NB + 1)
                tfirst = ft < fs
                amb = "3m"
            else:
                amb = "worst"
        if hs and not tfirst:
            res = (j, S, 1, src + 1)
            break
        if ht:
            res = (j, T, 1, 5)
            break
        if tm != "o6" and j == last:
            res = (j, c, 2, 1)
            break
        hc = max(hc, c)
        if c >= p0 + TG.ARM_R * R:
            armed = True
        if K is not None and armed and hc - K * A > S:
            S, src = hc - K * A, 3
        if be == "on" and armed and p0 * (1 + TG.COST / 100) > S:
            S, src = p0 * (1 + TG.COST / 100), 2
    lock = False
    if res is not None:
        k, px, xt, r = res
        locked = (xt == 0 and PA.lockO[u, k]) or (xt == 1 and r != 5 and PA.frz[u, k]) or (xt == 2 and PA.lockC[u, k])
        if locked:
            lock = True
            res = (int(PA.hon_k[u, k]), PA.hon_px[u, k], 2 if PA.hon_stuck[u, k] else 0, r)
    return res, lock, amb


def toy_paths(n, days=12):
    PA = TG.Paths(n)
    PA.ok[:] = True
    PA.A[:] = 2.0
    return PA


# ---------------------------------------------------------------------------------------------- unit checks
def unit_checks(W):
    bk, s_, t1 = W.bk, W.s_, W.t1
    print("u1: the book = setuplab's tree_sim")
    worst, same = 0.0, True
    for E, calm in ((W.ED, "first_up"), (W.EE, "all")):
        P = E.plan(3, "2/3", calm, "all7", "frozen")
        Tm = {"ent": P["ent"], "ex": P["ex"], "oexit": np.zeros(len(P["ent"]), bool), "net": P["net"], "u": P["br"],
              "i1": bk.i1[P["br"]], "p0": bk.O[P["br"], P["ek"]]}
        for k in (2, 3, 4):
            for p_ in range(5):
                a = TL.sim(P, bk.O, bk.C, bk.i1, s_ + p_, t1, k)
                b = TG.book_sim(Tm, bk.C, s_ + p_, t1, k)
                worst = max(worst, float(np.abs(a[0] - b[0]).max()), float(np.abs(a[1] - b[1]).max()))
                same &= bool((a[2] == b[2]).all())
    check(same and worst < 1e-12, "u1 the frozen D and ENS trees, 5 start days, 2 / 3 / 4 positions: the same trades "
                                  "taken, values within %.1e" % worst)
    ok, n_lock, n_all = True, 0, 0
    for E, calm in ((W.ED, "first_up"), (W.EE, "all")):
        P = E.plan(3, "2/3", calm, "all7", "frozen")
        Tz, dropped = TG.frozen_trades(W.U, W.PA, bk, E, calm, W.primary)
        a = sorted(zip(P["br"].tolist(), P["ent"].tolist(), P["ex"].tolist(), np.round(P["net"], 9).tolist()))
        lk = Tz["lock"]
        b = sorted(zip(W.U.br[Tz["r"]].tolist(), Tz["ent"].tolist(), Tz["ex"].tolist(), np.round(Tz["net"], 9).tolist()))
        bl = sorted(zip(W.U.br[Tz["r"][~lk]].tolist(), Tz["ent"][~lk].tolist(), Tz["ex"][~lk].tolist(),
                        np.round(Tz["net"][~lk], 9).tolist()))
        locked_br = set(W.U.br[Tz["r"][lk]].tolist())
        a_unl = [t for t in a if t[0] not in locked_br]
        ok &= dropped == 0 and len(a) == len(b) and a_unl == bl and all(
            t2[2] > t1[2] for t1, t2 in zip(sorted(t for t in a if t[0] in locked_br),
                                            sorted(t for t in b if t[0] in locked_br)))
        n_lock += int(lk.sum())
        n_all += len(b)
    check(ok and n_lock > 0, "u1 the frozen tree on the cache's prices = treelab's plan (= setuplab's): %d trades, the "
                             "same entries, exits and nets; the %d sold on a locked close leave later" % (n_all, n_lock))

    print("u2: the triggers by hand")
    rng = np.random.default_rng(3)
    PA, E = W.PA, W.E
    us = rng.choice(np.flatnonzero(PA.ok), size=min(400, int(PA.ok.sum())), replace=False)
    for g in TG.TRIGGERS:                                  # and up to 10 fills of every trigger, the rare ones too
        us = np.union1d(us, np.flatnonzero(E[g][0] > 0)[:10])
    bad, n_fill = [], {g: 0 for g in TG.TRIGGERS}
    for u in us:
        ref = ref_entries(PA, W.setup_days, u)
        for g in TG.TRIGGERS:
            d1, p1, s1 = E[g][0][u], E[g][1][u], E[g][2][u]
            d2, p2, s2 = ref[g]
            if d1 != d2 or (d1 and (abs(p1 - p2) > 1e-9 * max(1.0, abs(p2)) or s1 != s2)):
                bad.append((u, g, (d1, p1, s1), (d2, p2, s2)))
            n_fill[g] += int(d1 > 0)
    check(not bad and all(n_fill[g] > 0 for g in TG.TRIGGERS),
          "u2 %d picks x 18 triggers: day, price and 3-minute slot of every fill = the bar-by-bar replay (fills: %s)%s"
          % (len(us), ", ".join("%s %d" % kv for kv in n_fill.items()), "" if not bad else " FIRST BAD %s" % (bad[:2],)))

    print("u3: the exits by hand")
    EN = W.EN
    xs = []
    for i, x in enumerate(TG.EXITS):                      # every option of every knob, in a spread of combinations
        if i % 19 == 0 or x in (("plow", "r20", "t20", "on", "c7"), ("a05", "r10", "none", "off", "o6"),
                                ("none", "none", "t15", "on", "c10"), ("a20", "r30", "t30", "off", "c5")):
            xs.append(x)
    sel = rng.choice(EN.n, size=min(2000, EN.n), replace=False)
    bad, n3, nw, nl = [], 0, 0, 0
    for x in xs:
        o = TG.exits(PA, EN, x, sel)
        for j, i in enumerate(sel):
            res, lock, amb = ref_exit(PA, EN, i, x)
            if res is None:
                good = o["xk"][j] == 99
            else:
                k, px, xt, r = res
                good = (o["xk"][j] == k and o["xt"][j] == xt and o["rsn"][j] == r and bool(o["lock"][j]) == lock and
                        (abs(o["xp"][j] - px) <= 1e-9 * max(1.0, abs(px)) or (np.isnan(px) and np.isnan(o["xp"][j]))))
                n3 += amb == "3m"
                nw += amb == "worst"
                nl += lock
            if not good:
                bad.append((x, int(i), res, (o["xk"][j], o["xp"][j], o["xt"][j], o["rsn"][j], o["lock"][j])))
    covered = {k: sorted(set(x[n] for x in xs)) for n, k in enumerate(("stop", "target", "trail", "be", "time"))}
    check(not bad and n3 > 0 and nw > 0 and nl > 0 and all(len(covered[k]) == len(v) for k, v in zip(
        covered, (TG.STOPS, TG.TARGETS, TG.TRAILS, TG.BES, TG.TIMES))),
          "u3 %d entries x %d exits (every option): exit day, price, kind, reason and the lock wait = the day-by-day "
          "replay (%d days with both levels settled by 3-minute bars, %d stop-first, %d locked sales)%s" % (
              len(sel), len(xs), n3, nw, nl, "" if not bad else " FIRST BAD %s" % (bad[:2],)))

    print("u4: hand-built trades")
    n = 9
    PA = toy_paths(n)
    for u in range(n):
        PA.O[u, :12], PA.H[u, :12], PA.L[u, :12], PA.C[u, :12] = 100.0, 100.5, 99.5, 100.0
    PA.O[0, 2], PA.H[0, 2], PA.L[0, 2], PA.C[0, 2] = 97.0, 97.5, 96.0, 97.0            # gap through the stop
    for u in (1, 2):                                                                     # stop 98 and target 104 both
        PA.O[u, 2], PA.H[u, 2], PA.L[u, 2], PA.C[u, 2] = 101.0, 105.0, 97.0, 99.0
    PA.us3[1, 2] = True
    PA.h3[1, 2, :] = np.r_[np.linspace(101, 105, 20), np.full(105, 100.0)]
    PA.l3[1, 2, :] = np.r_[np.linspace(100.5, 104.5, 20), np.linspace(99, 97, 105)]
    PA.C[3, 1], PA.H[3, 1] = 103.0, 103.2                                                # trail: armed at 103 (R = 2)
    PA.O[3, 2], PA.H[3, 2], PA.L[3, 2], PA.C[3, 2] = 104.0, 107.0, 103.5, 106.0
    PA.O[3, 3], PA.H[3, 3], PA.L[3, 3], PA.C[3, 3] = 105.0, 105.5, 101.5, 103.0
    PA.C[4, 1], PA.H[4, 1] = 102.5, 102.6                                                # breakeven at +1R
    PA.O[4, 2], PA.H[4, 2], PA.L[4, 2], PA.C[4, 2] = 101.0, 101.5, 100.0, 101.0
    PA.O[5, 6] = 103.0                                                                   # the D6 open
    PA.lockC[6, 5], PA.hon_k[6, 5], PA.hon_px[6, 5] = True, 7, 88.0                      # a locked D5 close
    PA.L[7, 1], PA.us3[7, 1] = 97.0, True                                                # a fill at bar 40 (dip at 99)
    PA.l3[7, 1, :], PA.h3[7, 1, :] = 99.6, 100.2
    PA.l3[7, 1, 10] = 97.0                                                               # before the fill: no stop
    PA.l3[7, 1, 60] = 97.5                                                               # after the fill: stop 98
    PA.L[8, 1], PA.H[8, 1] = 97.0, 112.0                                                 # unknown time: stop, no target
    E = {g: (np.zeros(n, np.int64), np.full(n, np.nan), np.full(n, -1, np.int64)) for g in TG.TRIGGERS}
    ed, ep, es = E["OPEN"]
    ed[:7], ep[:7] = 1, 100.0
    ed2, ep2, es2 = E["DIP05"]
    ed2[7], ep2[7], es2[7] = 1, 99.0, 40
    ed2[8], ep2[8], es2[8] = 1, 99.0, NB
    EN = TG.Entries(PA, E)

    def one(u, x, g="OPEN"):
        i = int(EN.idx[g][u])
        o = TG.exits(PA, EN, x, [i])
        return int(o["xk"][0]), round(float(o["xp"][0]), 6), int(o["xt"][0]), int(o["rsn"][0]), bool(o["lock"][0])

    got = [one(0, ("a10", "r20", "none", "off", "c5")), one(1, ("a10", "r20", "none", "off", "c5")),
           one(2, ("a10", "r20", "none", "off", "c5")), one(3, ("none", "none", "t20", "off", "c10")),
           one(4, ("a10", "none", "none", "on", "c10")), one(5, ("none", "none", "none", "off", "o6")),
           one(6, ("none", "none", "none", "off", "c5")), one(7, ("a05", "none", "none", "off", "c5"), "DIP05"),
           one(8, ("a05", "r10", "none", "off", "c5"), "DIP05")]
    want = [(2, 97.0, 0, 6, False), (2, 104.0, 1, 5, False), (2, 98.0, 1, 2, False), (3, 102.0, 1, 4, False),
            (2, 100.35, 1, 3, False), (6, 103.0, 0, 1, False), (7, 88.0, 0, 1, True), (1, 98.0, 1, 2, False),
            (1, 98.0, 1, 2, False)]
    PA.l3[7, 1, 60] = 98.5
    EN = TG.Entries(PA, E)
    got.append(one(7, ("a05", "none", "none", "off", "c5"), "DIP05"))
    want.append((5, 100.0, 2, 1, False))
    check(got == want, "u4 gap through the stop at the open 97; stop and target in one day: the 3-minute bars reach "
                       "104 first -> target, no bars -> stop 98; trailing stop 103 - 4 then 106 - 4 = 102; breakeven "
                       "100.35; the D6 open; a locked D5 close sells at the D7 open (88); a fill at bar 40 is stopped "
                       "by bar 60's 97.5, not by bar 10's 97 (and not at all when bar 60 is 98.5); an unknown fill "
                       "time: the day's low stops it, its high does not reach the target%s" % (
                           "" if got == want else " GOT %s WANT %s" % (got, want)))

    print("u5: the choice")
    rows = []
    spec = {"OPEN": (150, [10.0, 30.0, 30.0], [10.0, 20.0, 20.0]), "DIP05": (50, [5.0, 6.0, 40.0], [30.0, 30.0, 22.0]),
            "BRK": (200, [50.0, 60.0, 70.0], [26.0, 27.0, 30.0]), "ORB15": (120, [12.0, 25.0, 25.0], [25.0, 25.0000001, 40.0])}
    for g, (n_, a_, f_) in spec.items():
        for xi in range(3):
            rows.append({"engine": "D", "lane": "calm", "trigger": g, "xi": xi, "a": a_[xi], "f": f_[xi], "n": n_,
                         "m": 100, "s": {0: 50.0, 1: 20.0, 2: 80.0}[xi]})
    G = pd.DataFrame(rows)
    ranked, xc = TG.choose_lane(G, "D", "calm", ("a", "f", "n", "m", "s"))
    got = [(g, xi, own) for g, xi, own, *_ in ranked]
    check(xc == 2 and got == [("DIP05", 2, False), ("OPEN", 1, True), ("ORB15", 0, True)],
          "u5 the common exit = the best mean per settled trade (exit 2); DIP05 (50 entries) borrows it; OPEN's tie "
          "takes the earlier exit; a worst fall of exactly 25%% counts (ORB15), BRK has none under the cap: %s" % got)
    # the first-to-fire merge, by hand
    ctx, U, EN0 = W.ctx, W.U, W.EN
    spec2 = [("DIP05", 0), ("ORB15", 5), ("BRK", 7)]
    Tm = ctx.struct("D", 1, spec2)
    rows_ = np.flatnonzero((U.eng == "D") & (U.lane == 1))
    want = {}
    for r in rows_:
        best = None
        for k, (g, xi) in enumerate(spec2):
            st = EN0.idx[g][U.u[r]]
            if st < 0:
                continue
            key = (int(EN0.d[st]), int(EN0.es[st]) + 1, k)
            if best is None or key < best[0]:
                best = (key, g)
        if best:
            want[int(r)] = best[1]
    got = {int(r): g for r, g in zip(Tm["r"], Tm["g"])}
    check(got == want and len(got) > 50 and len(set(got.values())) == 3,
          "u5 a structure's first-to-fire merge (DIP05, ORB15, BRK on jumpy D picks): %d picks, each bought by the "
          "trigger that filled first by hand (%s)" % (len(got), {g: list(got.values()).count(g) for g in set(got.values())}))

    print("u6: the firewall")
    y0 = W.tests[0]
    pe = W.ends[y0]
    ends1 = {y0: pe}
    xs6 = [TG.EXITS[i] for i in range(0, len(TG.EXITS), 41)]
    cells = TG.Cells(W.U, W.EN, ends1)
    G1 = TG.run_grid(W.PA, W.EN, cells, W.cal, W.s_, W.t1, ends1, W.base_net, xs6, log=lambda *a: None)
    PA2 = TG.Paths(W.U.nu)
    for k_, v in vars(W.PA).items():
        setattr(PA2, k_, v.copy())
    rng = np.random.default_rng(9)
    kk = np.arange(TG.LOAD_D + 1)[None, :]
    after = (W.U.ui1[:, None] + kk - 1) > pe
    fct = np.where(after, np.exp(rng.normal(0, 0.03, after.shape)), 1.0)
    for nm in ("O", "H", "L", "C"):
        setattr(PA2, nm, getattr(PA2, nm) * fct)
    f3 = fct[:, :TG.LAST_D + 1, None]
    PA2.h3 = PA2.h3 * f3
    PA2.l3 = PA2.l3 * f3
    PA2.o3 = (PA2.o3 * f3[:, :TG.WATCH + 1]).astype(np.float32)
    PA2.c3 = (PA2.c3 * f3[:, :TG.WATCH + 1]).astype(np.float32)
    E2 = TG.entries(PA2, W.setup_days)
    EN2 = TG.Entries(PA2, E2)
    sel0 = np.flatnonzero(EN2.g == TG.TRIGGERS.index("OPEN"))
    o0 = TG.exits(PA2, EN2, TG.EXITS[0], sel0)
    bn2 = np.full(W.U.nu, np.nan)
    bn2[EN2.u[sel0]] = o0["net"]
    G2 = TG.run_grid(PA2, EN2, TG.Cells(W.U, EN2, ends1), W.cal, W.s_, W.t1, ends1, bn2, xs6, log=lambda *a: None)
    cols = [c % (y0 - 1) for c in ("a_year_to_%d", "fall_to_%d", "n_to_%d", "m_to_%d", "s_to_%d")]
    same = all(np.allclose(G1[c].to_numpy(float), G2[c].to_numpy(float), rtol=0, atol=1e-9, equal_nan=True)
               for c in cols)
    moved = not np.allclose(G1["a_year"], G2["a_year"], equal_nan=True)
    check(same and moved, "u6 every price after %s changed and the triggers re-run (%d cells x %d exits): the numbers "
                          "the %d choice uses stay the same, the whole-window numbers move" % (
                              pd.Timestamp(W.cal[pe]).date(), len(cells.list), len(xs6), y0))

    print("u7: the per-trade numbers by hand")
    net = np.array([3.0, -1.0, 2.0, -2.0, 0.0])
    rp = np.array([2.0, 2.0, 1.0, 1.0, 2.0])
    mt = TG.tmetrics(net, rp, np.array([5, 2, 4, 1, 5]), np.array([5, 2, 1, 6, 1]), net - 1.0, np.zeros(5, bool),
                     np.zeros(5, bool), np.zeros(5, bool), 2.0)
    want = {"n": 5, "win_pct": 40.0, "avg_win": 2.5, "avg_loss": -1.0, "payoff": 2.5, "exp_pct": 0.4,
            "exp_r": (1.5 - 0.5 + 2.0 - 2.0 + 0.0) / 5, "pf": 5.0 / 3.0, "be_win_pct": 100 / 3.5, "days_held": 3.4,
            "vs_open": -0.6, "pct_target": 20.0, "pct_stop": 40.0, "pct_time": 40.0}
    check(all(abs(mt[k] - v) < 1e-12 for k, v in want.items()),
          "u7 win %% 40, payoff 2.5, expectancy +0.4%% / +0.2R, profit factor 1.67, break-even win %% 28.6, exits 20 / 40 "
          "/ 40%%: %s" % {k: round(mt[k], 4) for k in want})


# ---------------------------------------------------------------------------------------------- the worlds
def run_world(tmp, name, seed, mode, **kw):
    print("%s world" % name)
    root, data, info = make_world(tmp / name, seed, mode, **kw)
    out = tmp / name / "out"
    if mode == "planted":
        rc = TG.cmd_run(args(root, data, out))
    else:
        with no_cost():
            rc = TG.cmd_run(args(root, data, out))
    d = runs(out)[-1] if out.exists() and runs(out) else None
    return rc, d, root, data, info


def parse_code(code):
    if code == "FROZEN":
        return ("FROZEN", None)
    spec = []
    for part in code.split(" + "):
        g, x = part[:-1].split("[")
        spec.append((g, TG.EXITS.index(tuple(x.split("/")))))
    return ("TOP%d" % len(spec), spec)


def main():
    t0 = time.time()
    tmp = Path(tempfile.mkdtemp(prefix="triggerlab_test_"))
    try:
        rc, d, root, data, info = run_world(tmp, "planted", 5, "planted")
        print("w1: the planted world")
        check(rc == 0 and d is not None and outputs_ok(d), "w1 run returns 0; every output matches outputs.sha256")
        W = setup_world(root, data)
        unit_checks(W)
        print("w1: the planted world's decision")
        if d is not None:
            res = json.loads((d / "TRIGGERLAB_RESULT.json").read_text(encoding="utf-8"))
            dec = res["decision"]
            wf = pd.read_csv(d / "walkforward.csv")
            jumpy = wf[wf["lane"] == "jumpy"]
            check(dec["verdict"] == "PASS" and (jumpy["structure"] != "FROZEN").all() and
                  "## THE DECISION: **PASS**" in (d / "TRIGGERLAB.md").read_text(encoding="utf-8"),
                  "w1 PASS (daily gain %+.2f bp %s, worst fall %.1f%% vs %.1f%%); the jumpy lanes leave the frozen "
                  "entry every year: %s" % (dec["diff"], TG._ci(dec["diff_lo"], dec["diff_hi"]), dec["wf_fall"],
                                            dec["fz_fall"], "; ".join("%d %s %s" % (r.year, r.engine, r.code)
                                                                       for r in jumpy.itertuples())))
            G = pd.read_parquet(d / "grid.parquet")
            check(len(G) == 2 * 2 * len(TG.TRIGGERS) * len(TG.EXITS) and (G.groupby(["engine", "lane", "trigger"])
                                                                          ["xi"].count() == len(TG.EXITS)).all(),
                  "w1 the grid: %d rows (2 engines x 2 lanes x %d triggers x %d exits)" % (
                      len(G), len(TG.TRIGGERS), len(TG.EXITS)))
            # every test year's choice, re-run from the exact grid
            W.ctx.G = G
            same = True
            for r in wf.to_dict("records"):
                y = int(r["year"])
                cols = tuple(c % (y - 1) for c in ("a_year_to_%d", "fall_to_%d", "n_to_%d", "m_to_%d", "s_to_%d"))
                ch = TG.choose_structure(W.ctx, r["engine"], TG.LANES.index(r["lane"]), cols, W.ends[y])[0]
                same &= TG.spec_code(ch) == r["code"]
            check(same, "w1 every test year's engine / lane choice = the best on the years before it, re-run from "
                        "grid.parquet")
            # the joined days by hand from the chosen codes
            daily = pd.read_csv(d / "walkforward_daily.csv")
            cy = pd.DatetimeIndex(W.cal[:W.t1 + 1]).year
            rw, rf = [], []
            for y in W.tests:
                pe, ye = W.ends[y], int(np.flatnonzero(cy == y)[-1])
                v = {}
                for e in TG.ENGINES:
                    parts = []
                    for ln in (0, 1):
                        code = wf[(wf.year == y) & (wf.engine == e) & (wf.lane == TG.LANES[ln])]["code"].iloc[0]
                        parts.append(TG.lane_trades(W.ctx, e, ln, parse_code(code)))
                    v[e] = TG.book_sim(TG.concat_trades(*parts), W.PA.C, W.s_, W.t1)[1]
                rw.append(TL.year_returns(v["D"], v["ENS"], 0.5, W.s_, pe, ye))
                rf.append(TL.year_returns(W.ctx.fz_book["D"], W.ctx.fz_book["ENS"], 0.5, W.s_, pe, ye))
            rw, rf = np.concatenate(rw), np.concatenate(rf)
            gap = max(float(np.abs(rw - daily["walkforward_return"]).max()),
                      float(np.abs(rf - daily["frozen_return"]).max()))
            diff = float(np.mean((np.log1p(rw) - np.log1p(rf)) * 1e4))
            check(gap < 1e-7 and abs(diff - dec["diff"]) < 1e-6 and
                  abs(TL.worst_fall_of(np.r_[1.0, np.cumprod(1 + rw)]) - dec["wf_fall"]) < 1e-6,
                  "w1 the joined days re-built by hand from the chosen codes = walkforward_daily.csv (largest gap %.1e); "
                  "the daily gain and the worst fall = the decision's" % gap)
            st = pd.read_csv(d / "strategy.csv")
            check(len(st) > 0 and {"win_pct", "planned_rr", "payoff", "exp_pct", "exp_r", "pf", "be_win_pct",
                                   "vs_open_lo"} <= set(st.columns),
                  "w1 THE STRATEGY's triggers carry win %%, planned and realised RR, expectancy, profit factor and the "
                  "break-even win %% (%d rows)" % len(st))
        else:
            check(False, "w1 the planted world's run")
        if os.environ.get("TRIGGERLAB_TEST_QUICK") == "1":            # the planted world and the unit checks only
            raise _Quick()
        rc, dA, *_ = run_world(tmp, "absent", 8, "absent")
        print("w2: the absent world")
        if dA is not None:
            decA = json.loads((dA / "TRIGGERLAB_RESULT.json").read_text(encoding="utf-8"))["decision"]
            check(rc == 0 and decA["verdict"] == "FAIL",
                  "w2 no drift, no cost: %s (daily gain %+.2f bp %s, worst fall %.1f%% vs %.1f%%)" % (
                      decA["verdict"], decA["diff"], TG._ci(decA["diff_lo"], decA["diff_hi"]), decA["wf_fall"],
                      decA["fz_fall"]))
        else:
            check(False, "w2 the absent world's run")
        print("w3: refusals")
        out3 = tmp / "planted" / "out_check"
        use_mods(root)
        rc = TG.cmd_run(args(root, data, out3, check_only=True))
        check(rc == 0 and not out3.exists(), "w3 --check-only reads, checks and writes nothing")
        doc = json.loads((TG.HERE / TG.DECL_FILE).read_text(encoding="utf-8"))
        doc["question"] = doc["question"] + " (edited)"
        edited = tmp / "edited_declaration.json"
        edited.write_text(json.dumps(doc, indent=1), encoding="utf-8")
        keep = TG.DECL_FILE
        TG.DECL_FILE = str(edited)                    # HERE / an absolute path = that path: the shipped file untouched
        try:
            rc = TG.cmd_run(args(root, data, tmp / "out_edit"))
        finally:
            TG.DECL_FILE = keep
        check(rc == 3 and not (tmp / "out_edit").exists(), "w3 an edited declaration is refused")
        rc = TG.cmd_run(args(root, data, root / "inside"))
        check(rc == 3, "w3 an output folder inside the cache is refused")
        p2 = tmp / "panel_short.parquet"
        pd.read_parquet(root / "panel_oc" / "panel.parquet").drop(columns=["d_wq_16"]).to_parquet(p2, index=False)
        rc = TG.cmd_run(args(root, data, tmp / "out_p", panel=str(p2)))
        check(rc == 3, "w3 a panel without a frozen setup's input is refused")
        wl = pd.read_parquet(data / "watchlist.parquet")
        data2 = tmp / "data_off"
        data2.mkdir()
        shutil.copy(data / "calendar.parquet", data2 / "calendar.parquet")
        off = wl.sample(frac=0.05, random_state=1).index
        wl.loc[off, "close_3"] = wl.loc[off, "close_3"] + 0.03
        wl.to_parquet(data2 / "watchlist.parquet", index=False)
        rc = TG.cmd_run(args(root, data2, tmp / "out_off"))
        check(rc == 3 and not (tmp / "out_off").exists(), "w3 5% of the picks' prices off the cache's is refused")
        rs, ds, _ = make_world(tmp / "short", 7, "absent", last_signal="2022-06-30")
        rc = TG.cmd_run(args(rs, ds, tmp / "out_short"))
        check(rc == 3 and not (tmp / "out_short").exists(), "w3 a watchlist without a test year is refused")
        ru, du, _ = make_world(tmp / "utc", 7, "absent", utc_3m=True, end="2023-06-30")
        rc = TG.cmd_run(args(ru, du, tmp / "out_utc"))
        check(rc == 3 and not (tmp / "out_utc").exists(), "w3 3-minute bars stamped in UTC without a zone are refused")
        rn, dn, _ = make_world(tmp / "no3", 7, "absent", no_3m=True, end="2023-06-30")
        rc = TG.cmd_run(args(rn, dn, tmp / "out_no3"))
        check(rc == 3, "w3 no 3-minute folder is refused")
    except _Quick:
        print("TRIGGERLAB_TEST_QUICK=1: the absent world and the refusals skipped")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("")
    print("%d checks, %d failed (%.0f s)" % (N_OK[0] + len(FAILS), len(FAILS), time.time() - t0))
    if FAILS:
        print("FAILED")
        for f in FAILS:
            print(" - " + f)
        return 1
    print("VERIFIED (%s)" % TG.VERSION)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
