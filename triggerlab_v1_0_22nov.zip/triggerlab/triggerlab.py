"""
triggerlab.py - triggerlab v1.0: entry triggers and exits (stop, target, trailing stop, breakeven, time) for the
frozen tree's calm and jumpy picks, searched on the 2021-26 history and judged walk-forward.

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\triggerlab
    python tests\\test_triggerlab.py
    python triggerlab.py run --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --out C:\\QuantData\\triggerlab

Karan, 22 Nov 2026: "I want a strategy. On the tree itself. For both calm and jumpy. Which enters on a trigger. THE
TRIGGER NEED TO LOOKED OUT FOR. Rigorously. And exits and after a trigger. Fixed/trailing TP. Fixed/trailing SL. This
should/can be dynamic. And can be different for different events/triggers. It should have RR, win%." ... "Go".

WHAT IT DOES
  The picks are the tree's own: D and ENS ranks 1-3, each calm or jumpy by the tree's ATR cut-off. For every pick it
  replays 18 entry triggers on D1-D5 (buy at the open, the seven frozen setups, dip limits, a breakout above the
  previous high, opening-range breaks, a gap-down reversal, a VWAP reclaim) and 960 exits for each: a stop (none,
  0.5-2 ATR, the previous session's low), a target (none, 1-3R), a trailing stop (none, 1.5-3 ATR under the highest
  close once the trade is up 1R), a move to breakeven at +1R, and a time exit (D5 close, D6 open, D7 close, D10 close).
  Which of a stop and a target came first inside a day is read from the 3-minute bars; without them the stop counts
  first. A gap through a level fills at the open; a sale on a locked lower circuit waits for the first unlocked open.
  Each engine and lane gets its own triggers, each trigger its own exit (a trigger with few trades borrows the lane's
  common exit), and the books are the tree's (Rs 5 L, 3 positions, 1/3 each, all busy = skipped, 0.35 a round trip).

HOW IT IS JUDGED (TRIGGERLAB_DECLARATION.json, declared before any run)
  Walk-forward, as treelab: 2023 is traded with what was chosen on 2021-22, 2024 with 2021-23, and so on; the joined
  test years are compared day by day with the frozen tree on the same days and the same prices.
    PASS = the daily gain has a 95% block-bootstrap interval above 0 AND a worst fall no deeper than the frozen tree's:
           the strategy chosen on all of 2021-26 is a candidate for a forward paper book beside the frozen tree.
    FAIL = keep the frozen tree.
  Every trigger and exit is reported with its win %, planned and realised reward : risk, expectancy, profit factor and
  the win % it needs to break even - in-sample (optimistic) and, for the walk-forward's own trades, out of sample.

Example: on 2021-22, jumpy D picks bought on a limit 1 ATR under the previous close, with a stop 1.5 ATR below and a
2R target, might be the best jumpy D strategy; then that is what jumpy D picks do in 2023, and 2023's result counts.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import heapq
import itertools
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
for _env, _name in (("TREELAB_DIR", "treelab"), ("TRADELAB_DIR", "tradelab")):
    _d = os.environ.get(_env) or str(HERE.parent / _name)
    if _d not in sys.path:
        sys.path.insert(0, _d)
import treelab as TL  # noqa: E402
import tl_common as TC  # noqa: E402
import tl_data as TD  # noqa: E402

SU = TL.SU
VERSION = "triggerlab v1.0"
NEEDS = {"setuplab": "setuplab v1.1", "treelab": "treelab v1.0", "tradelab": "tradelab v1.3.1"}
DECL_FILE = "TRIGGERLAB_DECLARATION.json"
COST = SU.COST                     # points a round trip (0.35)
WATCH = 5                          # entries on D1..D5
LAST_D = 10                        # the latest time exit: the D10 close
LOAD_D = 31                        # daily bars D0..D31 (a locked exit waits up to 20 sessions)
NB = 125                           # 3-minute bars a session; bar k starts 09:15 + 3k
TRIGGERS = ("OPEN", "OPENUP", "S1", "S2", "S3", "C1", "C2", "C3", "N1", "ANY7", "DIP05", "DIP10", "DIP15", "BRK",
            "GAPREV", "ORB15", "ORB30", "VWAP")
SETUPS = ("S1", "S2", "S3", "C1", "C2", "C3", "N1")
DIP_K = {"DIP05": 0.5, "DIP10": 1.0, "DIP15": 1.5}
GAP_ATR = 0.5                      # GAPREV: an open at least this many ATRs under the previous close
OR_BARS = {"ORB15": 5, "ORB30": 10, "GAPREV": 5}
VWAP_LAST = 104                    # a VWAP reclaim counts up to the bar starting 14:27; the buy is the next bar's open
STOPS = ("none", "a05", "a10", "a15", "a20", "plow")
STOP_ATR = {"a05": 0.5, "a10": 1.0, "a15": 1.5, "a20": 2.0}
TARGETS = ("none", "r10", "r15", "r20", "r30")
TARGET_R = {"r10": 1.0, "r15": 1.5, "r20": 2.0, "r30": 3.0}
TRAILS = ("none", "t15", "t20", "t30")
TRAIL_ATR = {"t15": 1.5, "t20": 2.0, "t30": 3.0}
BES = ("off", "on")
TIMES = ("c5", "o6", "c7", "c10")
TIME_DAY = {"c5": 5, "o6": 6, "c7": 7, "c10": 10}
EXITS = list(itertools.product(STOPS, TARGETS, TRAILS, BES, TIMES))     # the plain exit (D5 close) first
ARM_R = 1.0                        # the trailing stop and the breakeven move start at a close of entry + 1R
POSITIONS = 3                      # the tree's books
SPLIT = 0.5                        # D's share of the account (the tree's)
RANKS = 3
ENGINES = ("D", "ENS")
LANES = ("calm", "jumpy")
FALL_CAP = 25.0
FIRST_TEST = 2
N_MIN = 100                        # entries a trigger needs in the selection years to choose its own exit
STRUCTS = ("FROZEN", "TOP1", "TOP2", "TOP3")
PRICE_TOL = 0.005                  # the cache's bars against the watchlist's prices
MISMATCH_MAX = 0.02                # more of the picks off than this: refused
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
REASON = {0: "pending", 1: "time", 2: "stop", 3: "breakeven stop", 4: "trailing stop", 5: "target",
          6: "stop, gap at the open", 7: "target, gap at the open"}
FAR = 10 ** 6                      # the calendar index of an exit that never came (pending)
LOG = TL.LOG


class TGError(Exception):
    pass


def constants():
    return {"triggers": list(TRIGGERS), "dip_k": DIP_K, "gap_atr": GAP_ATR, "or_bars": OR_BARS, "vwap_last": VWAP_LAST,
            "stops": list(STOPS), "stop_atr": STOP_ATR, "targets": list(TARGETS), "target_r": TARGET_R,
            "trails": list(TRAILS), "trail_atr": TRAIL_ATR, "breakeven": list(BES), "times": list(TIMES),
            "time_day": TIME_DAY, "arm_r": ARM_R, "watch": WATCH, "last_d": LAST_D, "load_d": LOAD_D,
            "positions": POSITIONS, "split": SPLIT, "ranks": RANKS, "fall_cap": FALL_CAP, "first_test": FIRST_TEST,
            "n_min": N_MIN, "structures": list(STRUCTS), "price_tol": PRICE_TOL, "mismatch_max": MISMATCH_MAX,
            "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED], "cost_pp": COST, "exits": len(EXITS)}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise TGError("no declaration at %s (it ships beside triggerlab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise TGError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise TGError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(),
              Path(SU.__file__).resolve().parent, Path(TL.__file__).resolve().parent,
              Path(TD.__file__).resolve().parent):
        if o == b or b in o.parents:
            raise TGError("--out %s is inside %s - outputs go under C:\\QuantData\\triggerlab" % (o, b))
    return o


def ledger(out, rec):
    Path(out).mkdir(parents=True, exist_ok=True)
    with open(Path(out) / "triggerlab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def exit_words(x):
    s, t, tr, be, tm = x
    w = []
    w.append({"none": "no stop", "plow": "stop at the previous session's low"}.get(
        s, "stop %g ATR below the entry" % STOP_ATR.get(s, 0)))
    w.append("no target" if t == "none" else "target %gR" % TARGET_R[t])
    if tr != "none":
        w.append("trailing stop %g ATR under the highest close from +1R" % TRAIL_ATR[tr])
    if be == "on":
        w.append("stop to breakeven at +1R")
    w.append({"c5": "else sell at the D5 close", "o6": "else sell at the D6 open", "c7": "else sell at the D7 close",
              "c10": "else sell at the D10 close"}[tm])
    return ", ".join(w)


def exit_code(x):
    return "%s/%s/%s/%s/%s" % x


TRIGGER_WORDS = {
    "OPEN": "buy at the D1 open", "OPENUP": "buy at the D1 open if it opens at or above the signal close",
    "S1": "frozen setup S1", "S2": "frozen setup S2", "S3": "frozen setup S3", "C1": "frozen setup C1",
    "C2": "frozen setup C2", "C3": "frozen setup C3", "N1": "frozen setup N1",
    "ANY7": "the first of the seven frozen setups (the tree's jumpy entry)",
    "DIP05": "limit buy 0.5 ATR under the previous close (D1-D5)",
    "DIP10": "limit buy 1 ATR under the previous close (D1-D5)",
    "DIP15": "limit buy 1.5 ATR under the previous close (D1-D5)",
    "BRK": "buy-stop at the previous session's high (D1-D5)",
    "GAPREV": "after an open 0.5 ATR or more under the previous close: buy-stop at the first 15 minutes' high",
    "ORB15": "buy-stop at the first 15 minutes' high (D1-D5)", "ORB30": "buy-stop at the first 30 minutes' high (D1-D5)",
    "VWAP": "buy at the next 3-minute open after a close back above the VWAP (it closed below earlier; by 14:30)",
    "FROZEN": "the frozen tree's own entry and exit"}


# ====================================================================================================== the picks
class Universe:
    """The tree's picks that triggerlab trades: D and ENS ranks 1-3, complete (setuplab's rule), not ETFs, signal day
    in the window, with a cut-off and an ATR. One row per engine pick; u = its distinct (symbol, signal day)."""

    def __init__(self, bk, cuts23, tdoc, s_):
        comp = SU.tree_complete(bk)
        etf = SU.tree_etf(bk.symbols, tdoc)
        sday = np.asarray(bk.signal_day).astype("datetime64[D]")
        yrs = pd.DatetimeIndex(bk.signal_day).year.to_numpy()
        cut = np.array([cuts23.get(int(y), np.nan) for y in yrs])
        atr = np.asarray(bk.atr, float)
        base = np.isin(bk.engine_arr, ENGINES) & (bk.rank <= RANKS) & comp & ~etf & \
            (sday >= np.asarray(bk.cal[s_]).astype("datetime64[D]")) & np.isfinite(cut)
        with np.errstate(invalid="ignore"):
            m = base & np.isfinite(atr) & (atr > 0)
        self.no_atr = int((base & ~m).sum())
        r = np.flatnonzero(m)
        self.br = r                                              # Book row of each engine pick
        self.eng = bk.engine_arr[r]
        self.rank = bk.rank[r]
        self.sym = bk.symbols[r]
        self.tid = bk.ids[r]
        self.sday = sday[r]
        self.i1 = bk.i1[r]
        with np.errstate(invalid="ignore"):
            self.lane = (atr[r] > cut[r]).astype(np.int64)        # 0 calm (ATR at or under the cut-off), 1 jumpy
        key = np.char.add(np.char.add(self.sym.astype(str), "|"), self.sday.astype(str))
        uk, first, self.u = np.unique(key, return_index=True, return_inverse=True)
        self.nu = len(uk)
        self.ubr = r[first]                                      # a Book row for each distinct pick
        self.usym = self.sym[first]
        self.usday = self.sday[first]
        self.ui1 = self.i1[first]
        self.n = len(r)

    def keep(self, ok_u):
        """Drop the picks whose prices could not be matched (ok_u per distinct pick)."""
        k = ok_u[self.u]
        for nm in ("br", "eng", "rank", "sym", "tid", "sday", "i1", "lane", "u"):
            setattr(self, nm, getattr(self, nm)[k])
        self.n = int(k.sum())


class Paths:
    """Per distinct pick: daily bars D0..LOAD_D on the watchlist's prices (column k = Dk), the lower-circuit locks of
    D1..D10 and where a locked sale goes, and the 3-minute bars of D1..D10 (opens, closes and volumes of D1..D5)."""

    def __init__(self, nu):
        sh = (nu, LOAD_D + 1)
        self.O, self.H, self.L, self.C = (np.full(sh, np.nan) for _ in range(4))
        self.lockO, self.lockC, self.frz = (np.zeros((nu, LAST_D + 1), bool) for _ in range(3))
        self.hon_k = np.full((nu, LAST_D + 1), 99, np.int64)
        self.hon_px = np.full((nu, LAST_D + 1), np.nan)
        self.hon_stuck = np.zeros((nu, LAST_D + 1), bool)
        self.us3 = np.zeros((nu, LAST_D + 1), bool)
        self.h3 = np.full((nu, LAST_D + 1, NB), np.nan)
        self.l3 = np.full((nu, LAST_D + 1, NB), np.nan)
        self.o3 = np.full((nu, WATCH + 1, NB), np.nan, dtype=np.float32)
        self.c3 = np.full((nu, WATCH + 1, NB), np.nan, dtype=np.float32)
        self.v3 = np.zeros((nu, WATCH + 1, NB), dtype=np.float32)
        self.A = np.full(nu, np.nan)                             # ATR in rupees: s_atr14 x the signal close
        self.ok = np.zeros(nu, bool)


def load_paths(U, bk, mk, log=LOG):
    """Daily bars through tradelab's Market (stage E's loader and lock rule) and 3-minute bars through its
    IntradayStore (its usability rule), scaled so the D1 open is the watchlist's entry price; a pick whose cache
    bars do not match the watchlist's prices within PRICE_TOL is dropped (counted)."""
    PA = Paths(U.nu)
    PA.A = np.asarray(bk.atr, float)[U.ubr] * bk.sc[U.ubr]
    why = {}
    store = mk.intraday
    order = np.argsort(U.usym, kind="mergesort")
    syms, starts = np.unique(U.usym[order], return_index=True)
    bounds = list(starts) + [len(order)]
    t0 = time.time()
    for si, sym in enumerate(syms):
        us = order[bounds[si]:bounds[si + 1]]
        ds = mk.series(str(sym))
        if ds is None:
            why["no daily bars in the cache"] = why.get("no daily bars in the cache", 0) + len(us)
            continue
        days3, want = [], []
        for u in us:
            i0 = ds.idx(U.usday[u])
            if i0 < 0 or i0 + 9 >= len(ds):
                why["signal day or D1-D9 not in the cache"] = why.get("signal day or D1-D9 not in the cache", 0) + 1
                continue
            br = U.ubr[u]
            n_av = min(LOAD_D, len(ds) - 1 - i0)
            o1 = ds.o[i0 + 1]
            if not (np.isfinite(o1) and o1 > 0 and np.isfinite(bk.O[br, 1])):
                why["no D1 open"] = why.get("no D1 open", 0) + 1
                continue
            f = bk.O[br, 1] / o1
            if np.datetime64(ds.dates[i0 + 1], "D") != np.datetime64(bk.cal[U.ui1[u]], "D"):
                why["D1 is not the watchlist's entry day"] = why.get("D1 is not the watchlist's entry day", 0) + 1
                continue
            seg = slice(i0, i0 + n_av + 1)
            o_, h_, l_, c_ = (f * np.asarray(a[seg], float) for a in (ds.o, ds.h, ds.l, ds.c))
            ref = bk.C[br, 1:]
            kk = np.flatnonzero(np.isfinite(ref)) + 1
            kk = kk[kk <= n_av]
            with np.errstate(invalid="ignore", divide="ignore"):
                bad = (np.abs(c_[kk] / bk.C[br, kk] - 1) > PRICE_TOL).any() or (
                    np.abs(o_[2:6] / bk.O[br, 2:6] - 1) > PRICE_TOL).any()
            if bad:
                why["prices off the watchlist's by more than 0.5%"] = why.get(
                    "prices off the watchlist's by more than 0.5%", 0) + 1
                continue
            PA.O[u, :n_av + 1], PA.H[u, :n_av + 1], PA.L[u, :n_av + 1], PA.C[u, :n_av + 1] = o_, h_, l_, c_
            PA.ok[u] = True
            for k in range(1, min(LAST_D, n_av) + 1):
                i = i0 + k
                lo_, lc_ = ds.locked(i, "open"), ds.locked(i, "close")
                fz = ds.frozen(i)
                PA.lockO[u, k], PA.lockC[u, k], PA.frz[u, k] = lo_, lc_, fz
                if lo_ or lc_ or fz:
                    pos, st = ds.honest_open_after(i)
                    if st == "ok" and pos - i0 <= LOAD_D:
                        PA.hon_k[u, k], PA.hon_px[u, k] = pos - i0, f * ds.o[pos]
                    elif st == "stuck" and pos - i0 <= LOAD_D:
                        PA.hon_k[u, k], PA.hon_px[u, k], PA.hon_stuck[u, k] = pos - i0, f * ds.c[pos], True
            for k in range(1, min(LAST_D, n_av) + 1):
                days3.append(np.datetime64(ds.dates[i0 + k], "D"))
                want.append((u, k, f))
        if want:
            sess = store.sessions(str(sym), days3, ds)
            for (u, k, f), day in zip(want, days3):
                s = sess.get(day)
                if s is None or not s.usable:
                    continue
                PA.us3[u, k] = True
                PA.h3[u, k, s.slot], PA.l3[u, k, s.slot] = f * s.h, f * s.l
                if k <= WATCH:
                    PA.o3[u, k, s.slot], PA.c3[u, k, s.slot] = f * s.o, f * s.c
                    PA.v3[u, k, s.slot] = s.v
        if (si + 1) % 200 == 0:
            log(" bars: %d of %d stocks (%.0f s)" % (si + 1, len(syms), time.time() - t0))
    return PA, why


# ====================================================================================================== the entries
def _first(mask, start=0):
    """First True column at or after `start` per row; -1 when none."""
    if mask.shape[1] == 0:
        return np.full(mask.shape[0], -1)
    m = mask.copy()
    if start:
        m[:, :start] = False
    has = m.any(1)
    return np.where(has, m.argmax(1), -1)


def entries(PA, setup_days):
    """Every trigger on every distinct pick: (D-day 1..5 or 0, fill price, fill slot: -1 = at the open, 0..124 = the
    3-minute bar, 125 = inside the day at an unknown time). setup_days: {setup: fill day per distinct pick}."""
    nu = PA.O.shape[0]
    E = {}

    def new():
        return np.zeros(nu, np.int64), np.full(nu, np.nan), np.full(nu, -1, np.int64)

    ok = PA.ok
    # at the D1 open
    ed, ep, es = new()
    m = ok & np.isfinite(PA.O[:, 1])
    ed[m], ep[m] = 1, PA.O[m, 1]
    E["OPEN"] = (ed, ep, es)
    ed, ep, es = new()
    with np.errstate(invalid="ignore"):
        m = ok & np.isfinite(PA.O[:, 1]) & (PA.O[:, 1] >= PA.C[:, 0])
    ed[m], ep[m] = 1, PA.O[m, 1]
    E["OPENUP"] = (ed, ep, es)
    # the frozen setups: the open of their fill day
    best_d = np.zeros(nu, np.int64)
    for s in SETUPS:
        ed, ep, es = new()
        k = np.asarray(setup_days[s], np.int64)
        m = ok & (k >= 1) & (k <= WATCH)
        px = np.where(m, PA.O[np.arange(nu), np.clip(k, 0, LOAD_D)], np.nan)
        m &= np.isfinite(px)
        ed[m], ep[m] = k[m], px[m]
        E[s] = (ed, ep, es)
        better = m & ((best_d == 0) | (k < best_d))
        best_d[better] = k[better]
    ed, ep, es = new()
    m = best_d > 0
    ed[m], ep[m] = best_d[m], PA.O[np.flatnonzero(m), best_d[m]]
    E["ANY7"] = (ed, ep, es)
    # limits under the previous close / buy-stops at the previous high
    for g in ("DIP05", "DIP10", "DIP15", "BRK"):
        ed, ep, es = new()
        for j in range(1, WATCH + 1):
            todo = ok & (ed == 0)
            o, h, lo = PA.O[:, j], PA.H[:, j], PA.L[:, j]
            with np.errstate(invalid="ignore"):
                if g == "BRK":
                    lvl = PA.H[:, j - 1]
                    can = todo & np.isfinite(o) & np.isfinite(h) & np.isfinite(lvl)
                    gap = can & (o >= lvl)
                    intr = can & ~gap & (h >= lvl)
                else:
                    lvl = PA.C[:, j - 1] - DIP_K[g] * PA.A
                    can = todo & np.isfinite(o) & np.isfinite(lo) & np.isfinite(lvl)
                    gap = can & (o <= lvl)
                    intr = can & ~gap & (lo <= lvl)
            ed[gap], ep[gap], es[gap] = j, o[gap], -1
            ix = np.flatnonzero(intr)
            ed[ix], ep[ix], es[ix] = j, lvl[ix], NB
            us = ix[PA.us3[ix, j]]
            if len(us):
                with np.errstate(invalid="ignore"):
                    mm = (PA.h3[us, j, :] >= lvl[us, None]) if g == "BRK" else (PA.l3[us, j, :] <= lvl[us, None])
                f = _first(mm)
                es[us] = np.where(f >= 0, f, NB)
        E[g] = (ed, ep, es)
    # opening-range breaks (GAPREV: only after a gap down)
    for g in ("GAPREV", "ORB15", "ORB30"):
        ed, ep, es = new()
        mb = OR_BARS[g]
        for j in range(1, WATCH + 1):
            todo = ok & (ed == 0) & PA.us3[:, j]
            if g == "GAPREV":
                with np.errstate(invalid="ignore"):
                    todo &= PA.O[:, j] <= PA.C[:, j - 1] - GAP_ATR * PA.A
            ix = np.flatnonzero(todo)
            if not len(ix):
                continue
            h = PA.h3[ix, j, :]
            with np.errstate(all="ignore"):
                lvl = np.nanmax(np.where(np.isfinite(h[:, :mb]), h[:, :mb], -np.inf), axis=1)
                hit = h >= lvl[:, None]
            f = _first(hit, mb)
            good = (f >= 0) & np.isfinite(lvl)
            ix, f, lvl = ix[good], f[good], lvl[good]
            px = np.maximum(PA.o3[ix, j, f].astype(float), lvl)
            ed[ix], ep[ix], es[ix] = j, px, f
        E[g] = (ed, ep, es)
    # VWAP reclaim
    ed, ep, es = new()
    slots = np.arange(NB)
    for j in range(1, WATCH + 1):
        ix = np.flatnonzero(ok & (ed == 0) & PA.us3[:, j])
        if not len(ix):
            continue
        h, lo = PA.h3[ix, j, :], PA.l3[ix, j, :]
        c = PA.c3[ix, j, :].astype(float)
        o = PA.o3[ix, j, :].astype(float)
        v = np.nan_to_num(PA.v3[ix, j, :].astype(float))
        pres = np.isfinite(c) & np.isfinite(h) & np.isfinite(lo)
        tp = np.where(pres, (h + lo + c) / 3.0, 0.0)
        vv = np.where(pres, v, 0.0)
        cv, cpv = np.cumsum(vv, 1), np.cumsum(tp * vv, 1)
        cn, ctp = np.cumsum(pres, 1), np.cumsum(tp, 1)
        with np.errstate(invalid="ignore", divide="ignore"):
            vw = np.where(cv > 0, cpv / np.where(cv > 0, cv, 1.0), ctp / np.maximum(cn, 1))
            below = pres & (c < vw)
            seen = np.zeros_like(below)
            seen[:, 1:] = np.maximum.accumulate(below, axis=1)[:, :-1]
            rec = pres & (c > vw) & seen & (slots[None, :] <= VWAP_LAST)
        m = _first(rec)
        has = m >= 0
        nxt = pres & np.isfinite(o) & (slots[None, :] > np.where(has, m, NB)[:, None])
        s = _first(nxt)
        good = np.flatnonzero(has & (s >= 0))
        ix, s = ix[good], s[good]
        ed[ix], ep[ix], es[ix] = j, o[good, s], s
    E["VWAP"] = (ed, ep, es)
    for g in TRIGGERS:
        ed, ep, es = E[g]
        bad = (ed > 0) & ~(np.isfinite(ep) & (ep > 0))
        ed[bad] = 0
    return E


class Entries:
    """Every filled (trigger, distinct pick), stacked; with what the exits need."""

    def __init__(self, PA, E):
        gi, uu, dd, pp, ss = [], [], [], [], []
        self.idx = {}
        off = 0
        for k, g in enumerate(TRIGGERS):
            ed, ep, es = E[g]
            u = np.flatnonzero(ed > 0)
            gi.append(np.full(len(u), k))
            uu.append(u)
            dd.append(ed[u])
            pp.append(ep[u])
            ss.append(es[u])
            m = np.full(len(ed), -1, np.int64)
            m[u] = off + np.arange(len(u))
            self.idx[g] = m
            off += len(u)
        self.g, self.u, self.d = np.concatenate(gi), np.concatenate(uu), np.concatenate(dd)
        self.p0, self.es = np.concatenate(pp), np.concatenate(ss)
        self.n = len(self.u)
        self.A = PA.A[self.u]
        self.plow = PA.L[self.u, self.d - 1]
        # the entry day's range after the fill: the whole day for an open fill, the bars after the fill bar for a
        # known 3-minute fill, and for an unknown time the day's low (a stop counts as hit) and no high (no target)
        wl = PA.L[self.u, self.d].copy()
        wh = PA.H[self.u, self.d].copy()
        known = (self.es >= 0) & (self.es < NB)
        ix = np.flatnonzero(known)
        if len(ix):
            after = np.arange(NB)[None, :] > self.es[ix, None]
            lo, hi = PA.l3[self.u[ix], self.d[ix], :], PA.h3[self.u[ix], self.d[ix], :]
            with np.errstate(all="ignore"):
                wl[ix] = np.nanmin(np.where(after & np.isfinite(lo), lo, np.inf), axis=1)
                wh[ix] = np.nanmax(np.where(after & np.isfinite(hi), hi, -np.inf), axis=1)
        unk = self.es == NB
        wh[unk] = -np.inf
        self.wl, self.wh = wl, wh


# ====================================================================================================== the exits
def exits(PA, EN, x, sel=None):
    """The entries (all, or the stacked indices `sel`) under one exit x = (stop, target, trail, breakeven, time).
    Day by day from the entry: an open through the stop / target sells at the open; inside the day a stop sells at the
    stop and a target at the target - when one day reaches both, the 3-minute bars say which came first (a tie, or no
    usable bars: the stop); at each close the trailing stop and the breakeven move are set for the next day; the time
    exit sells at its close (or at the D6 open). A sale on a lower-locked open / close or a frozen bar waits for the
    first unlocked open (stage E's rule). -> dict of arrays: xk (exit D-day; 99 = pending), xp, xt (0 open, 1 inside
    the day, 2 close), rsn, net (%), rpct (R as % of the entry), held (sessions in the position), lock, amb3, ambw."""
    stop, target, trail, be, tm = x
    ix = np.arange(EN.n) if sel is None else np.asarray(sel, np.int64)
    u, d, p0, es, A = EN.u[ix], EN.d[ix], EN.p0[ix], EN.es[ix], EN.A[ix]
    wl, wh = EN.wl[ix], EN.wh[ix]
    n = len(ix)
    with np.errstate(invalid="ignore"):
        if stop in STOP_ATR:
            S = p0 - STOP_ATR[stop] * A
        elif stop == "plow":
            pl = EN.plow[ix]
            S = np.where(np.isfinite(pl) & (pl < p0), pl, p0 - A)
        else:
            S = np.full(n, -np.inf)
    R = np.where(np.isfinite(S), p0 - S, A)
    T = p0 + TARGET_R[target] * R if target != "none" else np.full(n, np.inf)
    K = TRAIL_ATR.get(trail)
    src = np.ones(n, np.int64)
    hc = np.full(n, -np.inf)
    armed = np.zeros(n, bool)
    live = np.ones(n, bool)
    xk = np.full(n, 99, np.int64)
    xp = np.full(n, np.nan)
    xt = np.full(n, -1, np.int64)
    rsn = np.zeros(n, np.int64)
    amb3 = np.zeros(n, bool)
    ambw = np.zeros(n, bool)
    last = TIME_DAY[tm]
    slots = np.arange(NB)
    for j in range(1, last + 1):
        act = live & (d <= j)
        if not act.any():
            continue
        if tm == "o6" and j == 6:
            o = PA.O[u, 6]
            m = act & np.isfinite(o)
            xk[m], xp[m], xt[m], rsn[m] = 6, o[m], 0, 1
            live &= ~m
            break
        later = act & (d < j)
        o, h, lo, c = PA.O[u, j], PA.H[u, j], PA.L[u, j], PA.C[u, j]
        has = np.isfinite(o) & np.isfinite(h) & np.isfinite(lo) & np.isfinite(c)
        with np.errstate(invalid="ignore"):
            gs = later & has & (o <= S)
            gt = later & has & ~gs & (o >= T)
        for m, r in ((gs, 6), (gt, 7)):
            xk[m], xp[m], xt[m], rsn[m] = j, o[m], 0, r
        live &= ~(gs | gt)
        rem = act & has & live
        ent = rem & (d == j)
        wlo = np.where(ent, wl, lo)
        whi = np.where(ent, wh, h)
        with np.errstate(invalid="ignore"):
            hs = rem & (wlo <= S)
            ht = rem & (whi >= T)
        tf = np.zeros(n, bool)
        both = np.flatnonzero(hs & ht)
        if len(both):
            ok3 = PA.us3[u[both], j]
            b3 = both[ok3]
            if len(b3):
                st = np.where((d[b3] == j) & (es[b3] >= 0) & (es[b3] < NB), es[b3] + 1, 0)
                valid = slots[None, :] >= st[:, None]
                with np.errstate(invalid="ignore"):
                    fs = _first(valid & (PA.l3[u[b3], j, :] <= S[b3, None]))
                    ft = _first(valid & (PA.h3[u[b3], j, :] >= T[b3, None]))
                fs = np.where(fs < 0, NB + 1, fs)
                ft = np.where(ft < 0, NB + 1, ft)
                tf[b3] = ft < fs
                amb3[b3] = True
            ambw[both[~ok3]] = True
        sx = hs & ~tf
        tx = ht & ~sx
        xk[sx], xp[sx], xt[sx], rsn[sx] = j, S[sx], 1, src[sx] + 1
        xk[tx], xp[tx], xt[tx], rsn[tx] = j, T[tx], 1, 5
        live &= ~(sx | tx)
        rem2 = rem & live
        if tm != "o6" and j == last:
            xk[rem2], xp[rem2], xt[rem2], rsn[rem2] = j, c[rem2], 2, 1
            live &= ~rem2
            continue
        hc = np.where(rem2, np.maximum(hc, c), hc)
        with np.errstate(invalid="ignore"):
            armed |= rem2 & (c >= p0 + ARM_R * R)
        if K is not None:
            ns = hc - K * A
            with np.errstate(invalid="ignore"):
                up = rem2 & armed & (ns > S)
            S = np.where(up, ns, S)
            src = np.where(up, 3, src)
        if be == "on":
            bl = p0 * (1 + COST / 100.0)
            up = rem2 & armed & (bl > S)
            S = np.where(up, bl, S)
            src = np.where(up, 2, src)
    # a sale the lower circuit blocks waits for the first unlocked open
    done = xk <= LAST_D
    kx = np.clip(xk, 0, LAST_D)
    lk = done & (((xt == 0) & PA.lockO[u, kx]) | ((xt == 1) & (rsn != 5) & PA.frz[u, kx]) |
                 ((xt == 2) & PA.lockC[u, kx]))
    if lk.any():
        hk, hp, hs_ = PA.hon_k[u[lk], kx[lk]], PA.hon_px[u[lk], kx[lk]], PA.hon_stuck[u[lk], kx[lk]]
        xk[lk], xp[lk], xt[lk] = hk, hp, np.where(hs_, 2, 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        net = np.where(xk < 99, (xp / p0 - 1) * 100 - COST, np.nan)
        rpct = R / p0 * 100
    held = np.where(xk < 99, np.where(xt == 0, xk - d, xk - d + 1), -1)
    return {"xk": xk, "xp": xp, "xt": xt, "rsn": rsn, "net": net, "rpct": rpct, "held": held, "lock": lk,
            "amb3": amb3, "ambw": ambw}


def tmetrics(net, rpct, held, rsn, vs, lock, amb3, ambw, planned):
    """Per-trade view of settled trades: win % (net > 0), average win / loss, realised reward : risk (payoff), the
    planned one (target / stop distance), expectancy in % and in R, profit factor, the win % the payoff needs to break
    even (1 / (1 + payoff)), days held, the share of each exit, and the mean gain over the same picks bought at the
    D1 open and sold at the D5 close."""
    n = len(net)
    out = {"n": n}
    if n == 0:
        for k in ("win_pct", "avg_win", "avg_loss", "payoff", "planned_rr", "exp_pct", "exp_r", "pf", "be_win_pct",
                  "days_held", "vs_open", "pct_target", "pct_stop", "pct_be", "pct_trail", "pct_time", "pct_locked",
                  "amb_3m", "amb_stop_first"):
            out[k] = np.nan
        return out
    w = net > 0
    aw = float(net[w].mean()) if w.any() else np.nan
    al = float(net[~w].mean()) if (~w).any() else np.nan
    sl = float(net[~w].sum())
    payoff = aw / abs(al) if (np.isfinite(aw) and np.isfinite(al) and al < 0) else np.nan
    with np.errstate(invalid="ignore", divide="ignore"):
        er = net / rpct
    out.update({"win_pct": 100 * float(w.mean()), "avg_win": aw, "avg_loss": al, "payoff": payoff,
                "planned_rr": planned, "exp_pct": float(net.mean()),
                "exp_r": float(np.nanmean(er)) if np.isfinite(er).any() else np.nan,
                "pf": float(net[w].sum()) / abs(sl) if sl < 0 else np.nan,
                "be_win_pct": 100 / (1 + payoff) if np.isfinite(payoff) else np.nan,
                "days_held": float(held.mean()),
                "vs_open": float(np.nanmean(vs)) if np.isfinite(vs).any() else np.nan,
                "pct_target": 100 * float(np.isin(rsn, (5, 7)).mean()), "pct_stop": 100 * float(np.isin(rsn, (2, 6)).mean()),
                "pct_be": 100 * float((rsn == 3).mean()), "pct_trail": 100 * float((rsn == 4).mean()),
                "pct_time": 100 * float((rsn == 1).mean()), "pct_locked": 100 * float(lock.mean()),
                "amb_3m": int(amb3.sum()), "amb_stop_first": int(ambw.sum())})
    return out


# ====================================================================================================== the books
def book_sim(T, C, s0, t1, k=POSITIONS):
    """treelab's book (= setuplab's tree_sim) with explicit entry prices: T = arrays in setuplab's order (entry, rank,
    symbol, trade id): ent / ex (calendar), oexit (sold at an open: the position is free for that open), net (%),
    u (row of C), i1 (calendar index of the pick's D1), p0 (entry price). Each entry gets 1/k of the book's closed
    value, all positions busy = skipped, open positions marked at each close. -> (closed, marked, taken, sizes)."""
    ent, ex, net = T["ent"], T["ex"], T["net"]
    key = ex - 0.5 * T["oexit"]
    keep = np.flatnonzero((ent >= s0) & (ent <= t1))
    nd = t1 - s0 + 1
    sizes = np.zeros(len(ent))
    taken = np.zeros(len(ent), bool)
    heap, realized = [], 0.0
    for j in keep:
        t = ent[j]
        while heap and heap[0][0] < t:
            _, jj = heapq.heappop(heap)
            realized += sizes[jj] * net[jj] / 100
        if len(heap) < k:
            size = (1.0 + realized) / k
            if size > 0:
                sizes[j] = size
                taken[j] = True
                heapq.heappush(heap, (key[j], j))
    tk = np.flatnonzero(taken)
    exd = ex[tk] - s0
    inside = exd <= nd - 1
    pnl = sizes[tk][inside] * net[tk][inside] / 100
    eqc = 1.0 + np.cumsum(np.bincount(exd[inside], weights=pnl, minlength=nd)[:nd])
    eqm = eqc.copy()
    lens = np.minimum(ex[tk], t1 + 1) - ent[tk]
    has = lens > 0
    if has.any():
        tk2, L = tk[has], lens[has]
        rep = np.repeat(np.arange(len(tk2)), L)
        off = np.arange(L.sum()) - np.repeat(np.cumsum(L) - L, L)
        t = ent[tk2][rep] + off
        uu = T["u"][tk2][rep]
        kk = t - T["i1"][tk2][rep] + 1
        pin = T["p0"][tk2][rep]
        okk = (kk >= 1) & (kk <= C.shape[1] - 1)
        c_ = np.where(okk, C[uu, np.clip(kk, 1, C.shape[1] - 1)], np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            good = np.isfinite(c_) & np.isfinite(pin) & (pin > 0)
            val = np.where(good, sizes[tk2][rep] * (c_ / pin - 1), 0.0)
        np.add.at(eqm, t - s0, val)
    return np.maximum(eqc, 0.0), np.maximum(eqm, 0.0), taken, sizes


def sort_trades(T):
    o = np.lexsort((T["tid"], T["sym"], T["rank"], T["ent"]))
    return {k: v[o] for k, v in T.items()}


def concat_trades(*Ts):
    keys = Ts[0].keys()
    return sort_trades({k: np.concatenate([t[k] for t in Ts]) for k in keys})


def trade_set(U, EN, rows, st, out, pos, g, xi):
    """Trades of engine picks `rows` entered by stacked entries `st` with outcomes `out` (aligned by `pos`)."""
    p = pos[st]
    xk = out["xk"][p]
    i1 = U.i1[rows]
    return {"r": rows, "g": np.full(len(rows), g, dtype=object), "xi": np.full(len(rows), xi),
            "ent": i1 + EN.d[st] - 1, "ex": np.where(xk < 99, i1 + xk - 1, FAR), "oexit": out["xt"][p] == 0,
            "net": out["net"][p], "u": EN.u[st], "i1": i1, "p0": EN.p0[st], "rpct": out["rpct"][p],
            "held": out["held"][p], "rsn": out["rsn"][p], "lock": out["lock"][p], "amb3": out["amb3"][p],
            "ambw": out["ambw"][p], "d": EN.d[st], "sday": U.sday[rows], "rank": U.rank[rows], "sym": U.sym[rows],
            "tid": U.tid[rows], "lane": U.lane[rows], "eng": U.eng[rows]}


def frozen_trades(U, PA, bk, E_eng, calm_rule, primary):
    """The frozen tree's trades of one engine (treelab's plan = setuplab's) on the cache's prices, with the same
    honest sale as every other exit: buy at the fill day's open, sell at the D5 close (N1: 4 sessions after entry)."""
    P = E_eng.plan(RANKS, "2/3", calm_rule, "all7", "frozen")
    where = {int(b): i for i, b in enumerate(U.br)}
    r = np.array([where.get(int(b), -1) for b in P["br"]], np.int64)
    dropped = int((r < 0).sum())
    keep = r >= 0
    r = r[keep]
    ek = P["ek"][keep]
    how = P["how"][keep]
    u = U.u[r]
    x = np.array([ek_ + 4 if primary.get(h_) == "fresh" else 5 for ek_, h_ in zip(ek, how)], np.int64)
    p0 = PA.O[u, ek]
    xp = PA.C[u, x]
    xt = np.full(len(r), 2)
    lk = PA.lockC[u, np.clip(x, 0, LAST_D)]
    xk = x.copy()
    if lk.any():
        xk[lk], xp[lk] = PA.hon_k[u[lk], x[lk]], PA.hon_px[u[lk], x[lk]]
        xt[lk] = np.where(PA.hon_stuck[u[lk], x[lk]], 2, 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        net = np.where(xk < 99, (xp / p0 - 1) * 100 - COST, np.nan)
    i1 = U.i1[r]
    T = {"r": r, "g": np.array(["FROZEN:" + str(h_) for h_ in how], dtype=object), "xi": np.full(len(r), -1),
         "ent": i1 + ek - 1, "ex": np.where(xk < 99, i1 + xk - 1, FAR), "oexit": xt == 0, "net": net, "u": u,
         "i1": i1, "p0": p0, "rpct": PA.A[u] / p0 * 100, "held": np.where(xt == 0, xk - ek, xk - ek + 1),
         "rsn": np.ones(len(r), np.int64), "lock": lk, "amb3": np.zeros(len(r), bool),
         "ambw": np.zeros(len(r), bool), "d": ek, "sday": U.sday[r], "rank": U.rank[r], "sym": U.sym[r],
         "tid": U.tid[r], "lane": U.lane[r], "eng": U.eng[r]}
    return sort_trades(T), dropped


def lane_of(T, lane):
    m = T["lane"] == lane
    return {k: v[m] for k, v in T.items()}


# ====================================================================================================== the grid
class Cells:
    """Each (engine, lane, trigger): its engine picks and stacked entries in setuplab's order."""

    def __init__(self, U, EN, ends):
        self.list = []
        for e in ENGINES:
            for ln in (0, 1):
                rows_all = np.flatnonzero((U.eng == e) & (U.lane == ln))
                for g in TRIGGERS:
                    st = EN.idx[g][U.u[rows_all]]
                    keep = st >= 0
                    rows, st = rows_all[keep], st[keep]
                    ent = U.i1[rows] + EN.d[st] - 1
                    o = np.lexsort((U.tid[rows], U.sym[rows], U.rank[rows], ent))
                    rows, st, ent = rows[o], st[o], ent[o]
                    self.list.append({"engine": e, "lane": LANES[ln], "ln": ln, "trigger": g, "rows": rows, "st": st,
                                      "ent": ent, "i1": U.i1[rows], "u": EN.u[st], "p0": EN.p0[st],
                                      "picks": len(rows_all),
                                      "n_to": {y: int((ent <= pe).sum()) for y, pe in ends.items()}})


GRID_COLS = ["a_year", "fall", "end", "trades_week", "entries", "settled", "n", "win_pct", "avg_win", "avg_loss",
             "payoff", "planned_rr", "exp_pct", "exp_r", "pf", "be_win_pct", "days_held", "vs_open", "pct_target",
             "pct_stop", "pct_be", "pct_trail", "pct_time", "pct_locked", "amb_3m", "amb_stop_first", "sum_net"]


def planned_rr(x):
    return TARGET_R[x[1]] if x[1] != "none" else np.nan


def run_grid(PA, EN, cells, cal, s_, t1, ends, base_net, exits_list=None, log=LOG):
    """Every cell under every exit: its 3-position book from the window's first session (a year and worst fall,
    marked to market, over the window and to the end of each selection period) and its per-trade view."""
    xs = EXITS if exits_list is None else exits_list
    nc, nx = len(cells.list), len(xs)
    cols = GRID_COLS + ["a_year_to_%d" % (y - 1) for y in ends] + ["fall_to_%d" % (y - 1) for y in ends] + \
        ["n_to_%d" % (y - 1) for y in ends] + ["m_to_%d" % (y - 1) for y in ends] + ["s_to_%d" % (y - 1) for y in ends]
    A = {c: np.full(nc * nx, np.nan) for c in cols}
    yrs = float((cal[t1] - cal[s_]) / np.timedelta64(1, "D")) / 365.25
    t0 = time.time()
    for xi, x in enumerate(xs):
        out = exits(PA, EN, x)
        for ci, c in enumerate(cells.list):
            i = ci * nx + xi
            st = c["st"]
            xk = out["xk"][st]
            ex = np.where(xk < 99, c["i1"] + xk - 1, FAR)
            net = out["net"][st]
            T = {"ent": c["ent"], "ex": ex, "oexit": out["xt"][st] == 0, "net": net, "u": c["u"], "i1": c["i1"],
                 "p0": c["p0"]}
            eqc, eqm, taken, _ = book_sim(T, PA.C, s_, t1)
            A["a_year"][i], A["fall"][i] = TL.path_stats(eqm, cal, s_, t1)
            A["end"][i] = eqm[-1]
            A["trades_week"][i] = taken.sum() / (yrs * 52.18)
            A["entries"][i] = len(st)
            for y, pe in ends.items():
                a2, f2 = TL.path_stats(eqm, cal, s_, pe)
                A["a_year_to_%d" % (y - 1)][i], A["fall_to_%d" % (y - 1)][i] = a2, f2
                A["n_to_%d" % (y - 1)][i] = c["n_to"][y]
                sm = ex <= pe
                A["m_to_%d" % (y - 1)][i] = int(sm.sum())
                A["s_to_%d" % (y - 1)][i] = float(net[sm].sum()) if sm.any() else 0.0
            sm = ex <= t1
            A["settled"][i] = int(sm.sum())
            A["sum_net"][i] = float(net[sm].sum()) if sm.any() else 0.0
            mt = tmetrics(net[sm], out["rpct"][st][sm], out["held"][st][sm], out["rsn"][st][sm],
                          net[sm] - base_net[c["u"][sm]], out["lock"][st][sm], out["amb3"][st][sm],
                          out["ambw"][st][sm], planned_rr(x))
            for k, v in mt.items():
                if k in A:
                    A[k][i] = v
        if (xi + 1) % 96 == 0:
            log(" exits: %d of %d (%.0f s)" % (xi + 1, nx, time.time() - t0))
    G = pd.DataFrame({"engine": np.repeat([c["engine"] for c in cells.list], nx),
                      "lane": np.repeat([c["lane"] for c in cells.list], nx),
                      "trigger": np.repeat([c["trigger"] for c in cells.list], nx),
                      "xi": np.tile(np.arange(nx), nc),
                      "stop": np.tile([x[0] for x in xs], nc), "target": np.tile([x[1] for x in xs], nc),
                      "trail": np.tile([x[2] for x in xs], nc), "breakeven": np.tile([x[3] for x in xs], nc),
                      "time_exit": np.tile([x[4] for x in xs], nc), "picks": np.repeat([c["picks"] for c in cells.list], nx)})
    for c in cols:
        G[c] = A[c]
    return G


# ====================================================================================================== the choice
class Ctx:
    """What the choice and the books need, with each (trigger, exit)'s outcomes computed once."""

    def __init__(self, PA, EN, U, cal, s_, t1, G=None):
        self.PA, self.EN, self.U, self.cal, self.s_, self.t1, self.G = PA, EN, U, cal, s_, t1, G
        self.outs = {}
        self.fz_lane, self.fz_lane_path, self.fz_book = {}, {}, {}

    def out(self, g, xi):
        key = (g, int(xi))
        if key not in self.outs:
            sel = np.flatnonzero(self.EN.g == TRIGGERS.index(g))
            o = exits(self.PA, self.EN, EXITS[int(xi)], sel)
            pos = np.full(self.EN.n, -1, np.int64)
            pos[sel] = np.arange(len(sel))
            self.outs[key] = (o, pos)
        return self.outs[key]

    def struct(self, e, ln, spec):
        """A lane's trades under a list of (trigger, exit) in priority order: each pick is bought by the trigger that
        fills first (the day, then the 3-minute bar: an open fill first, an unknown time last; a tie: the earlier
        trigger in the list) and leaves by that trigger's exit."""
        U, EN = self.U, self.EN
        rows = np.flatnonzero((U.eng == e) & (U.lane == ln))
        bkey = np.full(len(rows), np.inf)
        bst = np.full(len(rows), -1, np.int64)
        bg = np.full(len(rows), -1, np.int64)
        for k, (g, xi) in enumerate(spec):
            st = EN.idx[g][U.u[rows]]
            has = st >= 0
            sti = np.where(has, st, 0)
            key = np.where(has, EN.d[sti] * 1000.0 + EN.es[sti] + 1, np.inf)
            better = has & (key < bkey)
            bkey[better], bst[better], bg[better] = key[better], st[better], k
        parts = []
        for k, (g, xi) in enumerate(spec):
            m = bg == k
            o, pos = self.out(g, xi)
            parts.append(trade_set(U, EN, rows[m], bst[m], o, pos, g, xi))
        return concat_trades(*parts)

    def lane_path(self, T):
        return book_sim(T, self.PA.C, self.s_, self.t1)[1]


def choose_lane(G, e, lane, cols):
    """Each trigger's exit on the selection period: with N_MIN entries or more, its own (the highest a year at a worst
    fall of 25% or less; a tie: the earlier exit); with fewer, the lane's common exit (the highest mean net per
    settled trade over all the lane's triggers). Triggers ranked by that a year (eligible: worst fall at or under the
    cap). -> ranked [(trigger, exit, own, a year, worst fall, entries)], the common exit."""
    ycol, fcol, ncol, mcol, scol = cols
    Gl = G[(G["engine"] == e) & (G["lane"] == lane)]
    pooled = Gl.groupby("xi", sort=True)[[mcol, scol]].sum()
    with np.errstate(invalid="ignore", divide="ignore"):
        mean = np.where(pooled[mcol].to_numpy(float) > 0, pooled[scol].to_numpy(float) /
                        np.maximum(pooled[mcol].to_numpy(float), 1), -np.inf)
    xc = int(pooled.index[np.flatnonzero(mean == mean.max())[0]]) if len(mean) and np.isfinite(mean.max()) else 0
    ranked = []
    for g in TRIGGERS:
        Gg = Gl[Gl["trigger"] == g]
        if not len(Gg):
            continue
        n = int(Gg[ncol].iloc[0])
        a = np.nan_to_num(Gg[ycol].to_numpy(float), nan=-np.inf)
        f = Gg[fcol].to_numpy(float)
        xis = Gg["xi"].to_numpy()
        with np.errstate(invalid="ignore"):
            ok = f <= FALL_CAP
        if n >= N_MIN:
            if not ok.any():
                continue
            aa = np.where(ok, a, -np.inf)
            j = int(np.flatnonzero(aa == aa.max())[0])
            own = True
        elif n > 0:
            jj = np.flatnonzero(xis == xc)
            if not len(jj) or not ok[jj[0]]:
                continue
            j, own = int(jj[0]), False
        else:
            continue
        ranked.append((g, int(xis[j]), own, float(a[j]), float(f[j]), n))
    ranked.sort(key=lambda t: (-t[3], TRIGGERS.index(t[0])))
    return ranked, xc


def choose_structure(ctx, e, ln, cols, pe):
    """The lane's structure: the frozen tree's own, or the top 1, 2 or 3 ranked triggers each with its exit - the
    highest a year at a worst fall of 25% or less on the selection period (a tie: that order); none: the frozen."""
    ranked, xc = choose_lane(ctx.G, e, LANES[ln], cols)
    cands = []
    a, f = TL.path_stats(ctx.fz_lane_path[(e, ln)], ctx.cal, ctx.s_, pe)
    cands.append(("FROZEN", None, a, f))
    for k in (1, 2, 3):
        if len(ranked) >= k:
            spec = [(g, xi) for g, xi, *_ in ranked[:k]]
            a, f = TL.path_stats(ctx.lane_path(ctx.struct(e, ln, spec)), ctx.cal, ctx.s_, pe)
            cands.append(("TOP%d" % k, spec, a, f))
    best = None
    for c in cands:
        if np.isfinite(c[3]) and c[3] <= FALL_CAP and np.isfinite(c[2]) and (best is None or c[2] > best[2]):
            best = c
    fallback = best is None
    return (cands[0] if fallback else best), cands, ranked, xc, fallback


def lane_trades(ctx, e, ln, choice):
    return ctx.fz_lane[(e, ln)] if choice[0] == "FROZEN" else ctx.struct(e, ln, choice[1])


def spec_words(choice, own=None):
    """The structure in words; own = {trigger: False} marks an exit borrowed from the lane (under N_MIN entries)."""
    if choice[0] == "FROZEN":
        return TRIGGER_WORDS["FROZEN"]
    own = own or {}
    return " | ".join("%s: %s; %s%s" % (g, TRIGGER_WORDS[g], exit_words(EXITS[xi]), "" if own.get(g, True) else
                                        " (the lane's common exit: under %d entries)" % N_MIN)
                      for g, xi in choice[1])


def spec_code(choice):
    if choice[0] == "FROZEN":
        return "FROZEN"
    return " + ".join("%s[%s]" % (g, exit_code(EXITS[xi])) for g, xi in choice[1])


def walk_forward(ctx, tests, ends, log=LOG):
    rows, rWF, rFZ, days, wf_trades = [], [], [], [], []
    cal, s_, t1 = ctx.cal, ctx.s_, ctx.t1
    cy = pd.DatetimeIndex(cal[:t1 + 1]).year
    for y in tests:
        pe = ends[y]
        ye = int(np.flatnonzero(cy == y)[-1])
        cols = tuple(c % (y - 1) for c in ("a_year_to_%d", "fall_to_%d", "n_to_%d", "m_to_%d", "s_to_%d"))
        books = {}
        for e in ENGINES:
            parts = []
            for ln in (0, 1):
                ch, cands, ranked, xc, fb = choose_structure(ctx, e, ln, cols, pe)
                T = lane_trades(ctx, e, ln, ch)
                parts.append(T)
                m = (T["ent"] > pe) & (T["ent"] <= ye)
                wf_trades.append(pd.DataFrame({"year": y, "engine": e, "lane": LANES[ln], "structure": ch[0],
                                               "trigger": T["g"][m], "exit": [exit_code(EXITS[i]) if i >= 0 else
                                                                               "frozen" for i in T["xi"][m]],
                                               "trade_id": T["tid"][m], "symbol": T["sym"][m],
                                               "signal_day": pd.DatetimeIndex(T["sday"][m]).date,
                                               "entry_day": pd.DatetimeIndex(cal[T["ent"][m]]).date,
                                               "exit_day": [pd.Timestamp(cal[i]).date() if i < len(cal) else None
                                                            for i in T["ex"][m]],
                                               "entry_price": T["p0"][m], "net_pct": T["net"][m],
                                               "r_pct": T["rpct"][m], "reason": [REASON.get(int(r_), "?") for r_ in
                                                                                  T["rsn"][m]],
                                               "waited_for_unlocked_open": T["lock"][m]}))
                rows.append({"year": y, "engine": e, "lane": LANES[ln], "chosen_on": "%s .. %s" % (
                    pd.Timestamp(cal[s_]).date(), pd.Timestamp(cal[pe]).date()), "structure": ch[0],
                    "code": spec_code(ch), "words": spec_words(ch, {g: own for g, _x, own, *_r in ranked}),
                    "sel_a_year": ch[2], "sel_fall": ch[3],
                    "fallback": fb, "common_exit": exit_code(EXITS[xc]),
                    "ranked": "; ".join("%s %s%s %+.1f%%/%.1f%%" % (g, exit_code(EXITS[xi]), "" if own else " (borrowed)",
                                                                       a_, f_) for g, xi, own, a_, f_, _n in ranked[:5]),
                    "candidates": "; ".join("%s %+.1f%%/%.1f%%" % (c[0], c[2], c[3]) for c in cands)})
            books[e] = book_sim(concat_trades(*parts), ctx.PA.C, s_, t1)[1]
        rw = TL.year_returns(books["D"], books["ENS"], SPLIT, s_, pe, ye)
        rf = TL.year_returns(ctx.fz_book["D"], ctx.fz_book["ENS"], SPLIT, s_, pe, ye)
        rWF.append(rw)
        rFZ.append(rf)
        days.append(cal[pe + 1: ye + 1])
        for r in rows[-4:]:
            r["year_return_pct"] = float((np.prod(1 + rw) - 1) * 100)
            r["frozen_year_return_pct"] = float((np.prod(1 + rf) - 1) * 100)
        log(" walk-forward %d: %s -> %+.1f%% (frozen %+.1f%%)" % (y, " | ".join(
            "%s %s %s" % (r["engine"], r["lane"], r["code"]) for r in rows[-4:]), rows[-1]["year_return_pct"],
            rows[-1]["frozen_year_return_pct"]))
    return pd.DataFrame(rows), np.concatenate(rWF), np.concatenate(rFZ), np.concatenate(days), \
        (pd.concat(wf_trades, ignore_index=True) if wf_trades else pd.DataFrame())


def per_trigger(T, t1, base_net, B, by="g", order=None):
    """tmetrics per trigger (or per group `by`) of a set of trades, with the 95% interval of the gain over the same
    picks bought at the D1 open and sold at the D5 close (setuplab's Boot over signal days)."""
    out = []
    keys = list(order) if order is not None else list(dict.fromkeys(T[by].tolist()))
    for g in keys:
        m = (T[by] == g) & (T["ex"] <= t1)
        vs = T["net"][m] - base_net[T["u"][m]]
        xi = int(T["xi"][m][0]) if m.any() else -1
        mt = tmetrics(T["net"][m], T["rpct"][m], T["held"][m], T["rsn"][m], vs, T["lock"][m], T["amb3"][m],
                      T["ambw"][m], planned_rr(EXITS[xi]) if (xi >= 0 and by == "g") else np.nan)
        ok = np.isfinite(vs)
        if ok.sum() >= 2:
            lo, hi = B.ci_idx(B.index(T["sday"][m][ok]), vs[ok])
        else:
            lo, hi = np.nan, np.nan
        mt.update({"trigger": g, "exit": (exit_code(EXITS[xi]) if xi >= 0 else "frozen") if by == "g" else "mixed",
                   "vs_open_lo": lo,
                   "vs_open_hi": hi})
        out.append(mt)
    return out


# ====================================================================================================== the report
def _p(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "-"
    return ("%+." + str(nd) + "f") % x if sign else ("%." + str(nd) + "f") % x


def _ci(lo, hi, nd=2):
    return "[%s, %s]" % (_p(lo, nd), _p(hi, nd))


def exit_families(G):
    """In-sample: each exit option over the cells with N_MIN entries or more."""
    g0 = G[G["entries"] >= N_MIN]
    out = []
    for knob in ("stop", "target", "trail", "breakeven", "time_exit"):
        for v in pd.unique(g0[knob]):
            g = g0[g0[knob] == v]
            ok = g[g["fall"] <= FALL_CAP]
            out.append({"knob": knob, "option": v, "cells": len(g),
                        "best_a_year": float(ok["a_year"].max()) if len(ok) else np.nan,
                        "median_a_year": float(g["a_year"].median()), "median_fall": float(g["fall"].median()),
                        "median_win_pct": float(g["win_pct"].median()), "median_exp_pct": float(g["exp_pct"].median()),
                        "median_payoff": float(g["payoff"].median())})
    return pd.DataFrame(out)


def atlas(G):
    """In-sample: each engine, lane and trigger with the plain exit (D5 close) and its best exit."""
    out = []
    for (e, ln, g), Gg in G.groupby(["engine", "lane", "trigger"], sort=False):
        p = Gg[Gg["xi"] == 0].iloc[0]
        ok = Gg[Gg["fall"] <= FALL_CAP]
        b = ok.loc[ok["a_year"].idxmax()] if len(ok) and ok["a_year"].notna().any() else None
        r = {"engine": e, "lane": ln, "trigger": g, "entries": int(p["entries"]), "picks": int(p["picks"]),
             "fill_pct": 100 * p["entries"] / max(p["picks"], 1), "plain_win_pct": p["win_pct"],
             "plain_payoff": p["payoff"], "plain_exp_pct": p["exp_pct"], "plain_a_year": p["a_year"],
             "plain_fall": p["fall"], "plain_vs_open": p["vs_open"]}
        if b is not None:
            r.update({"best_exit": exit_code(EXITS[int(b["xi"])]), "best_win_pct": b["win_pct"],
                      "best_planned_rr": b["planned_rr"], "best_payoff": b["payoff"], "best_exp_pct": b["exp_pct"],
                      "best_exp_r": b["exp_r"], "best_pf": b["pf"], "best_be_win_pct": b["be_win_pct"],
                      "best_a_year": b["a_year"], "best_fall": b["fall"], "best_vs_open": b["vs_open"]})
        out.append(r)
    return pd.DataFrame(out)


def trade_table(rows, title_cols=("trigger", "exit")):
    L = ["| %s | trades | win %% | planned RR | realised RR | expectancy | in R | profit factor | win %% to break "
         "even | days held | target / stop / trail / BE / time %% | vs the same picks at the open [95%%] |" %
         " | ".join(title_cols),
         "|" + "---|" * (len(title_cols) + 11)]
    for r in rows:
        L.append("| %s | %d | %s | %s | %s | %s%% | %s | %s | %s | %s | %s | %s %s |" % (
            " | ".join(str(r.get(c, "")) for c in title_cols), r["n"], _p(r["win_pct"], 1, False),
            _p(r["planned_rr"], 1, False), _p(r["payoff"], 2, False), _p(r["exp_pct"]), _p(r["exp_r"]),
            _p(r["pf"], 2, False), _p(r["be_win_pct"], 1, False), _p(r["days_held"], 1, False),
            "/".join(_p(r[k], 0, False) for k in ("pct_target", "pct_stop", "pct_trail", "pct_be", "pct_time")),
            _p(r["vs_open"]), _ci(r.get("vs_open_lo", np.nan), r.get("vs_open_hi", np.nan))))
    return L


def write_report(d, info, R):
    dec = R["decision"]
    L = ["# %s - entry triggers and exits for the tree's calm and jumpy picks, judged walk-forward (%s)" % (
        VERSION, d.name), "",
         "Karan, 22 Nov 2026: *\"I want a strategy. On the tree itself. For both calm and jumpy. Which enters on a "
         "trigger ... Fixed/trailing TP. Fixed/trailing SL ... It should have RR, win%%.\"* ... *\"Go\"*. Rules: "
         "`TRIGGERLAB_DECLARATION.json` sha256 `%s` (declared before any run). Picks: %s. Window: %s .. %s." % (
             info["declaration_sha256"][:16], info["picks"], R["window"][0], R["window"][1]), ""]
    L += ["## THE DECISION: **%s**" % dec["verdict"], "",
          "Walk-forward, %s .. %s: each year's triggers and exits chosen on the years before it, joined, against the "
          "frozen tree on the same days and the same prices (both accounts: D and ENS 50/50, the split restarted each "
          "1 January). Start day 1." % (dec["from"], dec["to"]), "",
          "| account | a year | worst fall |", "|---|---|---|",
          "| the walk-forward | %+.1f%% | %.1f%% |" % (dec["wf_a_year"], dec["wf_fall"]),
          "| the frozen tree | %+.1f%% | %.1f%% |" % (dec["fz_a_year"], dec["fz_fall"]), "",
          "- Daily gain over the frozen tree: %s bp a day %s (95%%, block bootstrap over the days). Above 0: **%s**" % (
              _p(dec["diff"]), _ci(dec["diff_lo"], dec["diff_hi"]), "yes" if dec["above"] else "no"),
          "- Worst fall no deeper than the frozen tree's: **%s**" % ("yes" if dec["shallower"] else "no"), "",
          "PASS = both: THE STRATEGY below is a candidate for a forward paper book beside the frozen tree (its own "
          "freeze date; the frozen tree does not change). FAIL = triggers and exits searched on the history do not beat "
          "the frozen tree on days they did not see: keep the frozen tree.", ""]
    L += ["## Each test year (chosen on the years before it)", "",
          "| year | engine | lane | chosen | that year | frozen |", "|---|---|---|---|---:|---:|"]
    for r in R["wf"].to_dict("records"):
        L.append("| %d | %s | %s | %s%s | %+.1f%% | %+.1f%% |" % (
            r["year"], r["engine"], r["lane"], r["code"], " (fallback)" if r["fallback"] else "",
            r["year_return_pct"], r["frozen_year_return_pct"]))
    L += ["", "The year's return is the whole account's (both engines, both lanes); `walkforward.csv` has each "
          "choice in words and the runners-up. Code: TRIGGER[stop/target/trail/breakeven/time] - stop none, a05-a20 "
          "(ATRs under the entry) or plow (the previous session's low); target none or r10-r30 (1-3R); trail none or "
          "t15-t30 (ATRs under the highest close, from +1R); breakeven off / on (+1R); time c5 / o6 / c7 / c10 (D5 "
          "close, D6 open, D7 close, D10 close). Several triggers: the first to fill buys.", ""]
    L += ["## What the walk-forward's own trades did (out of sample)", "",
          "Every trade the chosen triggers took in the test years (before the 3-position limit), against the frozen "
          "tree's trades in the same lanes and years.", ""]
    L += trade_table(R["oos"], ("engine", "lane", "trades of"))
    L += ["", "## THE STRATEGY - chosen on all of %s .. %s (in-sample: optimistic)" % tuple(R["window"]), ""]
    for (e, ln), ch in R["strategy"].items():
        L += ["### %s %s: %s%s" % (e, ln, ch["structure"], " (fallback: nothing under the cap)" if ch["fallback"]
                                       else ""), "", "- " + ch["words"].replace(" | ", "\n- "), ""]
        L += trade_table(ch["triggers"])
        L.append("")
    s5 = R["strategy_account"]
    L += ["| account, start day 1 | a year | worst fall |", "|---|---|---|",
          "| THE STRATEGY | %+.1f%% | %.1f%% |" % (s5["a_year"], s5["fall"]),
          "| the frozen tree | %+.1f%% | %.1f%% |" % (s5["fz_a_year"], s5["fz_fall"]), ""]
    L += ["## Every trigger, 2021-26 (in-sample)", "",
          "Each engine and lane: the trigger's entries (fill % of the lane's picks), its numbers with the plain exit "
          "(sell at the D5 close) and with its best exit (the highest a year at a worst fall of 25% or less).", "",
          "| engine | lane | trigger | entries (fill %) | plain: win % / RR / expectancy / a year | best exit | win % | "
          "planned RR | realised RR | expectancy | profit factor | a year | worst fall |",
          "|---|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in R["atlas"].to_dict("records"):
        L.append("| %s | %s | %s | %d (%.0f%%) | %s / %s / %s%% / %s%% | %s | %s | %s | %s | %s%% | %s | %s%% | %s%% |" % (
            r["engine"], r["lane"], r["trigger"], r["entries"], r["fill_pct"], _p(r["plain_win_pct"], 1, False),
            _p(r["plain_payoff"], 2, False), _p(r["plain_exp_pct"]), _p(r["plain_a_year"], 1),
            r.get("best_exit", "-"), _p(r.get("best_win_pct", np.nan), 1, False),
            _p(r.get("best_planned_rr", np.nan), 1, False), _p(r.get("best_payoff", np.nan), 2, False),
            _p(r.get("best_exp_pct", np.nan)), _p(r.get("best_pf", np.nan), 2, False),
            _p(r.get("best_a_year", np.nan), 1), _p(r.get("best_fall", np.nan), 1, False)))
    L += ["", "## Do stops, targets and trails help here? (in-sample)", "",
          "Over every engine / lane / trigger with %d entries or more: each exit option's best a year (worst fall at or "
          "under 25%%), median a year, median worst fall, median win %% and median expectancy per trade." % N_MIN, "",
          "| knob | option | best a year | median a year | median worst fall | median win % | median expectancy |",
          "|---|---|---:|---:|---:|---:|---:|"]
    for r in R["families"].to_dict("records"):
        L.append("| %s | %s | %s%% | %s%% | %s%% | %s | %s%% |" % (
            r["knob"], r["option"], _p(r["best_a_year"], 1), _p(r["median_a_year"], 1),
            _p(r["median_fall"], 1, False), _p(r["median_win_pct"], 1, False), _p(r["median_exp_pct"])))
    L += ["", "## Checks", ""] + ["- %s: %s" % (k, v) for k, v in info["checks"].items()]
    L += ["", "## How to read it", "",
          "- R = the stop's distance from the entry (no stop: 1 ATR). Planned RR = the target's distance / R. Realised "
          "RR (payoff) = the average winning trade / the average losing trade. Win % = trades that made money after "
          "the 0.35 cost. Win % to break even = 1 / (1 + realised RR): a win % above it makes money.",
          "- Expectancy = the average net per trade (% of the trade; in R: per unit of risk). Profit factor = the "
          "winners' total / the losers' total.",
          "- A year and worst fall: the 3-position book (Rs 5 L, 1/3 a trade, all busy = skipped) marked to market at "
          "each close, from the window's first session.",
          "- Inside a day a stop and a target are settled by the 3-minute bars when both were reached; without usable "
          "bars the stop counts first. A trade bought inside a day can be stopped later that day only by the bars "
          "after its fill (no bars: a stop counts if the day's low reached it, a target does not).",
          "- The frozen tree here is the frozen rule on the same cache prices and the same honest sale; the Checks "
          "compare it with setuplab's own history.",
          "- Only THE DECISION is judged on days the choice did not see; everything marked in-sample is optimistic. The "
          "forward paper ledger stays the final judge.", ""]
    (d / "TRIGGERLAB.md").write_text("\n".join(L), encoding="utf-8")


# ====================================================================================================== the run
def frozen_gate(bk, books, ED, EE, s_, t1, tdoc, P0):
    """treelab's gate (its plan and book = setuplab's tree_plan and tree_sim) and this tool's book_sim on the same
    trades; TREE.json's history when the window is its own. -> (checks, ok)."""
    checks, ok = {}, True
    gate = []
    for E, nm, calm in ((ED, "D tree", "first_up"), (EE, "ENS tree", "all")):
        Tt, prow = books[nm]
        mine = E.plan(3, "2/3", calm, "all7", "frozen")
        a1 = np.sort(np.c_[prow[Tt["row"].to_numpy(np.int64)], Tt["ent"], Tt["ex"], Tt["ek"]].astype(np.int64), axis=0)
        a2 = np.sort(np.c_[mine["br"], mine["ent"], mine["ex"], mine["ek"]].astype(np.int64), axis=0)
        same = a1.shape == a2.shape and bool((a1 == a2).all()) and bool(np.allclose(
            np.sort(Tt["net"].to_numpy(float)), np.sort(mine["net"]), rtol=0, atol=1e-9))
        Tm = {"ent": mine["ent"], "ex": mine["ex"], "oexit": np.zeros(len(mine["ent"]), bool), "net": mine["net"],
              "u": mine["br"], "i1": bk.i1[mine["br"]], "p0": bk.O[mine["br"], mine["ek"]]}
        worst = 0.0
        for p_ in range(5):
            eqc1, eqm1, _ = SU.tree_sim(Tt, prow, bk.O, bk.C, bk.i1, s_ + p_, t1)
            eqc2, eqm2, _, _ = book_sim(Tm, bk.C, s_ + p_, t1)
            worst = max(worst, float(np.max(np.abs(eqm1 - eqm2))), float(np.max(np.abs(eqc1 - eqc2))))
        gate.append((nm, same, worst))
        ok &= same and worst < 1e-9
    checks["this book vs setuplab's tree_plan and tree_sim (frozen trees, 5 start days)"] = "; ".join(
        "%s: trades %s, values within %.1e" % (g[0], "same" if g[1] else "DIFFERENT", g[2]) for g in gate)
    res, _, _ = SU.tree_history(bk, P0, books, s_, t1, reruns=0, log=lambda *x: None)
    window = [str(pd.Timestamp(bk.cal[s_]).date()), str(pd.Timestamp(bk.cal[t1]).date())]
    ref = tdoc.get("history_reference", {})
    fr = {g: {k: float(np.mean([d_[k] for d_ in L])) for k in ("a_year", "fall", "end")} for g, L in res.items()}
    if window == ref.get("window"):
        rec = all(abs(fr[g]["a_year"] - ref[g]["a_year_pct"]) <= SU.TREE_TOL and
                  abs(fr[g]["fall"] - ref[g]["worst_fall_pct"]) <= SU.TREE_TOL for g, _ in SU.TREE_GROUPS
                  if g in ref and g in fr)
        checks["the frozen tree vs TREE.json's history"] = "%s (D tree %+.2f%% a year, worst fall %.2f%%)" % (
            "REPRODUCES" if rec else "DOES NOT REPRODUCE", fr["D tree"]["a_year"], fr["D tree"]["fall"])
        ok &= rec
    else:
        checks["the frozen tree vs TREE.json's history"] = "n/a: window %s .. %s, TREE.json's %s" % (
            window[0], window[1], " .. ".join(ref.get("window", ["?", "?"])))
    return checks, ok, window, fr


def resolve_inputs(a):
    root = Path(a.root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    if not panel.is_file():
        raise TGError("panel not found: %s" % panel)
    return root, panel


def cmd_run(a, log=LOG):
    t0 = time.time()
    try:
        dp, ddoc = load_declaration()
        found = {"setuplab": SU.VERSION, "treelab": TL.VERSION, "tradelab": TC.VERSION}
        bad = ["%s (found %s)" % (v, found[k]) for k, v in NEEDS.items() if found[k] != v]
        if bad:
            raise TGError("needs %s beside this folder" % ", ".join(bad))
        root, panel = resolve_inputs(a)
        out = guard_out(a.out, root)
        _, fdoc = SU.load_frozen()
        _, tdoc = SU.load_tree()
        import pyarrow.parquet as pq
        have = {c.lower() for c in pq.read_schema(panel).names}
        fconds = SU.frozen_conds(fdoc)
        ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
        need = [f for f in ffeats if f not in have]
        if need:
            raise TGError("the panel lacks: %s" % ", ".join(need))
        primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
        order = [s for s in SU.TREE_ORDER if s in fconds]
        if tuple(order) != SETUPS:
            raise TGError("expected the seven frozen setups %s, found %s" % (list(SETUPS), order))
        bk, miss = TL.load_book(a.data, panel, list(dict.fromkeys(ffeats)), log)
        prod = TD.Production(stage_e_any=bool(getattr(a, "stage_e_any", False)))
        mk = TD.Market(root, prod)
        _ = mk.intraday
    except (TGError, TL.TLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    log("%s: declaration %s; frozen setups %s; tree %s" % (VERSION, ddoc["sha256"][:16], fdoc["sha256"][:16],
                                                          tdoc["sha256"][:16]))
    fills = TL.replays(bk, fconds, primary)
    cuts = {q: TL.cutoffs(bk, v, tdoc) for q, v in TL.QUANT.items()}
    P0 = TL.frozen_picks(bk, fills, order, primary, tdoc, cuts["2/3"])
    try:
        s_ = TL.window_start(bk, cuts["2/3"])
        books, _ = SU.tree_run_books(P0, bk, s_)
        t1 = TL.window_end(bk, books)
    except TL.TLError as e:
        print("REFUSED: %s" % e)
        return 3
    nan_tv = np.full(bk.n, np.nan)
    ED = TL.Eng(bk, "D", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, nan_tv)
    EE = TL.Eng(bk, "ENS", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, nan_tv)
    checks, ok, window, fr = frozen_gate(bk, books, ED, EE, s_, t1, tdoc, P0)
    if not ok:
        print("REFUSED: the frozen tree is not reproduced (%s)" % "; ".join("%s: %s" % kv for kv in checks.items()))
        return 3
    cal = bk.cal
    years = sorted(set(pd.DatetimeIndex(cal[s_:t1 + 1]).year))
    tests = [y for y in years if y >= years[0] + FIRST_TEST]
    cy = pd.DatetimeIndex(cal[:t1 + 1]).year
    ends = {y: int(np.flatnonzero(cy == y - 1)[-1]) for y in tests}
    if not tests or any(e_ <= s_ for e_ in ends.values()):
        print("REFUSED: the window %s .. %s has no test year (the first is the window's year %d)" % (
            window[0], window[1], FIRST_TEST + 1))
        return 3
    # ---- the picks and their bars
    U = Universe(bk, cuts["2/3"], tdoc, s_)
    log(" picks: %d engine picks (%d distinct) of D and ENS ranks 1-%d in the window" % (U.n, U.nu, RANKS))
    try:
        PA, why = load_paths(U, bk, mk, log)
        lay = mk.intraday.layout_check()
    except (TC.StopRun, TC.TLError) as e:
        print("REFUSED: %s" % e)
        return 3
    off = int((~PA.ok).sum())
    if U.nu == 0 or off > MISMATCH_MAX * U.nu:
        print("REFUSED: %d of %d picks could not be matched to the cache's bars (%s) - more than %.0f%%" % (
            off, U.nu, why, 100 * MISMATCH_MAX))
        return 3
    n_before = U.n
    U.keep(PA.ok)
    checks["picks"] = "%d engine picks (%d distinct) in the window; %d dropped (prices not matched: %s); %d without " \
                      "an ATR left out" % (U.n, int(PA.ok.sum()), n_before - U.n, why or "none", U.no_atr)
    checks["3-minute bars"] = "%d sessions asked, %d with bars, %d usable (%s)" % (
        lay["asked"], lay["with_bars"], lay["usable"], lay["reasons"] or "no problems")
    u3 = PA.us3[:, 1:LAST_D + 1]
    yu = pd.DatetimeIndex(U.usday).year.to_numpy()
    checks["3-minute coverage (usable share of D1-D10 sessions)"] = ", ".join(
        "%d %.0f%%" % (yv, 100 * u3[(yu == yv) & PA.ok].mean()) for yv in sorted(set(yu)))
    setup_days = {s: np.asarray(fills[s][0], np.int64)[U.ubr] for s in SETUPS}
    E = entries(PA, setup_days)
    EN = Entries(PA, E)
    checks["entries"] = ", ".join("%s %d" % (g, int((E[g][0] > 0).sum())) for g in TRIGGERS)
    # ---- the frozen tree on the cache's prices
    ctx = Ctx(PA, EN, U, cal, s_, t1)
    dropped = 0
    for e, Eg, calm in (("D", ED, "first_up"), ("ENS", EE, "all")):
        T, dr = frozen_trades(U, PA, bk, Eg, calm, primary)
        dropped += dr
        for ln in (0, 1):
            ctx.fz_lane[(e, ln)] = lane_of(T, ln)
            ctx.fz_lane_path[(e, ln)] = ctx.lane_path(ctx.fz_lane[(e, ln)])
        ctx.fz_book[e] = ctx.lane_path(T)
    fzv = SPLIT * ctx.fz_book["D"] + (1 - SPLIT) * ctx.fz_book["ENS"]
    fa, ff = TL.path_stats(fzv, cal, s_, t1)
    bD = TL.sim(ED.plan(3, "2/3", "first_up", "all7", "frozen"), bk.O, bk.C, bk.i1, s_, t1, 3)[1]
    bE = TL.sim(EE.plan(3, "2/3", "all", "all7", "frozen"), bk.O, bk.C, bk.i1, s_, t1, 3)[1]
    ba, bf = TL.path_stats(SPLIT * bD + (1 - SPLIT) * bE, cal, s_, t1)
    checks["the frozen tree on the cache's prices (honest sale) vs setuplab's (watchlist prices)"] = \
        "%+.2f%% a year, worst fall %.2f%% vs %+.2f%%, %.2f%% (start day 1; %d frozen trades on unmatched picks left " \
        "out)" % (fa, ff, ba, bf, dropped)
    checks["walk-forward"] = "test years %s; each chosen on %s .. the year before" % (
        ", ".join(str(y) for y in tests), window[0])
    for k, v in checks.items():
        log(" %s: %s" % (k, v))
    if a.check_only:
        log("CHECK OK - inputs readable, the frozen tree reproduced, the bars matched; nothing searched or written.")
        return 0
    d = SU.new_run_dir(out, "TRIGGERLAB")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": ddoc["sha256"], "frozen_sha256": fdoc["sha256"],
                 "tree_sha256": tdoc["sha256"], "watchlist": str(Path(a.data) / "watchlist.parquet")})
    # ---- the grid: every trigger x exit for every engine and lane
    sel0 = np.flatnonzero(EN.g == TRIGGERS.index("OPEN"))
    o0 = exits(PA, EN, EXITS[0], sel0)
    base_net = np.full(U.nu, np.nan)
    base_net[EN.u[sel0]] = o0["net"]
    cells = Cells(U, EN, ends)
    log("the grid: %d triggers x %d exits x 2 engines x 2 lanes" % (len(TRIGGERS), len(EXITS)))
    G = run_grid(PA, EN, cells, cal, s_, t1, ends, base_net, log=log)
    ctx.G = G
    log("the walk-forward")
    WF, rWF, rFZ, days, WT = walk_forward(ctx, tests, ends, log)
    x = (np.log1p(rWF) - np.log1p(rFZ)) * 1e4
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    lo, hi = B_.ci_idx(np.arange(len(x)), x)
    vWF, vFZ = np.r_[1.0, np.cumprod(1 + rWF)], np.r_[1.0, np.cumprod(1 + rFZ)]
    yrs = float((days[-1] - cal[ends[tests[0]]]) / np.timedelta64(1, "D")) / 365.25
    fall_wf, fall_fz = TL.worst_fall_of(vWF), TL.worst_fall_of(vFZ)
    verdict, above, shallower = TL.decide(lo, fall_wf, fall_fz)
    dec = {"verdict": verdict, "from": str(pd.Timestamp(days[0]).date()), "to": str(pd.Timestamp(days[-1]).date()),
           "diff": float(x.mean()), "diff_lo": lo, "diff_hi": hi, "above": above, "shallower": shallower,
           "wf_a_year": (vWF[-1] ** (1 / yrs) - 1) * 100, "fz_a_year": (vFZ[-1] ** (1 / yrs) - 1) * 100,
           "wf_fall": fall_wf, "fz_fall": fall_fz}
    log(" THE DECISION: %s - daily gain %s bp %s; worst fall %.1f%% vs the frozen tree's %.1f%%" % (
        verdict, _p(dec["diff"]), _ci(lo, hi), fall_wf, fall_fz))
    # ---- the out-of-sample per-trade view
    Bd = SU.Boot(U.sday, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    oos = []
    for e in ENGINES:
        for ln in (0, 1):
            parts = []
            for y in tests:
                ch = choose_structure(ctx, e, ln, tuple(c % (y - 1) for c in (
                    "a_year_to_%d", "fall_to_%d", "n_to_%d", "m_to_%d", "s_to_%d")), ends[y])[0]
                T = lane_trades(ctx, e, ln, ch)
                ye = int(np.flatnonzero(cy == y)[-1])
                m = (T["ent"] > ends[y]) & (T["ent"] <= ye)
                parts.append({k: v[m] for k, v in T.items()})
            Tw = concat_trades(*parts)
            Tw["who"] = np.full(len(Tw["ent"]), "walk-forward", dtype=object)
            fz = ctx.fz_lane[(e, ln)]
            mf = np.zeros(len(fz["ent"]), bool)
            for y in tests:
                ye = int(np.flatnonzero(cy == y)[-1])
                mf |= (fz["ent"] > ends[y]) & (fz["ent"] <= ye)
            Tf = {k: v[mf] for k, v in fz.items()}
            Tf["who"] = np.full(int(mf.sum()), "frozen tree", dtype=object)
            for r in per_trigger(concat_trades(Tw, Tf), t1, base_net, Bd, by="who",
                                 order=("walk-forward", "frozen tree")):
                r.update({"engine": e, "lane": LANES[ln], "trades of": r["trigger"]})
                oos.append(r)
    # ---- THE STRATEGY: chosen on the whole window
    strategy, parts_e = {}, {e: [] for e in ENGINES}
    for e in ENGINES:
        for ln in (0, 1):
            ch, cands, ranked, xc, fb = choose_structure(ctx, e, ln, ("a_year", "fall", "entries", "settled",
                                                                      "sum_net"), t1)
            T = lane_trades(ctx, e, ln, ch)
            parts_e[e].append(T)
            strategy[(e, LANES[ln])] = {"structure": ch[0], "code": spec_code(ch),
                                         "words": spec_words(ch, {g: own for g, _x, own, *_r in ranked}),
                                         "fallback": fb, "a_year": ch[2], "fall": ch[3],
                                         "triggers": per_trigger(T, t1, base_net, Bd)}
    sD = ctx.lane_path(concat_trades(*parts_e["D"]))
    sE = ctx.lane_path(concat_trades(*parts_e["ENS"]))
    sa, sf = TL.path_stats(SPLIT * sD + (1 - SPLIT) * sE, cal, s_, t1)
    s_acc = {"a_year": sa, "fall": sf, "fz_a_year": fa, "fz_fall": ff}
    AT, FA = atlas(G), exit_families(G)
    R = {"window": window, "decision": dec, "wf": WF, "oos": oos, "strategy": strategy, "strategy_account": s_acc,
         "atlas": AT, "families": FA}
    # ---- outputs
    files = ["grid.csv", "grid.parquet", "atlas.csv", "exit_families.csv", "walkforward.csv",
             "walkforward_trades.csv", "walkforward_daily.csv", "strategy.csv", "oos.csv"]
    G.to_csv(d / "grid.csv", index=False, float_format="%.6g")
    G.to_parquet(d / "grid.parquet", index=False)
    AT.to_csv(d / "atlas.csv", index=False)
    FA.to_csv(d / "exit_families.csv", index=False)
    WF.to_csv(d / "walkforward.csv", index=False)
    WT.to_csv(d / "walkforward_trades.csv", index=False)
    pd.DataFrame({"date": pd.DatetimeIndex(days).date, "walkforward_return": rWF, "frozen_return": rFZ,
                  "walkforward_value": vWF[1:], "frozen_value": vFZ[1:]}).to_csv(
        d / "walkforward_daily.csv", index=False, float_format="%.8f")
    pd.DataFrame([dict(r, engine=k[0], lane=k[1], structure=v["structure"], code=v["code"]) for k, v in
                  strategy.items() for r in v["triggers"]]).to_csv(d / "strategy.csv", index=False)
    pd.DataFrame(oos).to_csv(d / "oos.csv", index=False)
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": ddoc["sha256"], "tree_sha256": tdoc["sha256"], "frozen_sha256": fdoc["sha256"],
              "window": window, "decision": dec, "walk_forward": WF.to_dict("records"),
              "strategy": {"%s %s" % k: {kk: vv for kk, vv in v.items() if kk != "triggers"} for k, v in
                           strategy.items()}, "strategy_account": s_acc}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "TRIGGERLAB_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info = {"version": VERSION, "declaration_sha256": ddoc["sha256"], "picks": checks["picks"],
            "frozen_sha256": fdoc["sha256"], "tree_sha256": tdoc["sha256"], "root": str(root), "panel": str(panel),
            "data": str(a.data), "checks": checks, "decision": verdict, "missing_columns": miss}
    write_report(d, info, R)
    (d / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    files += ["TRIGGERLAB_RESULT.json", "DECLARATION.json", "TRIGGERLAB.md", "RUN.json"]
    SU.write_hashes(d, files)
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "decision": verdict, "diff_bp": dec["diff"], "diff_lo": lo, "diff_hi": hi, "wf_fall": fall_wf,
                 "frozen_fall": fall_fz, "strategy": {"%s %s" % k: v["code"] for k, v in strategy.items()},
                 "minutes": round((time.time() - t0) / 60, 1)})
    log("TRIGGERLAB WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    log(" THE DECISION: %s (walk-forward %s .. %s: %+.1f%% a year, worst fall %.1f%%; frozen %+.1f%%, %.1f%%)" % (
        verdict, dec["from"], dec["to"], dec["wf_a_year"], fall_wf, dec["fz_a_year"], fall_fz))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="triggerlab", description=VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="search triggers and exits on the tree's picks and judge them walk-forward")
    r.add_argument("--root", required=True, help="CACHE_DAILY_ROOT (the daily cache, intraday_3m, panel_oc)")
    r.add_argument("--data", required=True, help="setuplab's watchlist folder (watchlist.parquet, calendar.parquet)")
    r.add_argument("--out", required=True, help="output folder, e.g. C:\\QuantData\\triggerlab")
    r.add_argument("--panel", default=None, help="default <root>\\panel_oc\\panel.parquet")
    r.add_argument("--check-only", action="store_true", help="inputs, the gates and the bars; nothing searched")
    r.add_argument("--stage-e-any", action="store_true", help="accept a stage_e_execution that is not tradelab's "
                                                               "shipped v1.2 (as tradelab's own flag)")
    a = ap.parse_args(argv)
    return cmd_run(a)


if __name__ == "__main__":
    raise SystemExit(main())
