# vollab v1.0 - volatility forecasts applied to the frozen tree

Your ask (22 Nov 2026), on the research report: *"Apply it to the tree"* - then *"Go"* on the plan.

## Stage A - which forecast of a pick's 5-session variance is best? (no trading)

**Sample:** every eligible stock-day in the panel from July 2021 (ETFs out). It is also reported on the tree's own
picks (D and ENS ranks 1-3).

**Target:** the variance actually borne from the D1 open to the D5 close.
- H = RV(D1) + the sum over D2..D5 of (overnight return^2 + RV).
- RV is the sum of squared 15-minute returns built from your 3-minute bars, from the 09:15 open. The overnight move is
  never inside RV.

**Seven forecasts:**

| model | what |
|---|---|
| M0 | ATR14%^2 - today's (setuplab's simple ATR, the tree's s_atr14) |
| M1 | 20-day close-to-close variance |
| M2 | 20-day Yang-Zhang |
| M3 | pooled log-HAR(1,5,22) on total variance (overnight^2 + RV) |
| M4 | HAR-CJ: continuous and jump parts apart |
| M5 | HARQ: less weight on yesterday when yesterday was measured badly |
| M6 | pooled GARCH(1,1) on daily returns |

Each is scaled by its own constant from the training window (kappa = mean of H / forecast). That puts every model in
the same units, so the race is about information, not units.

**Walk-forward:** every model is refit at each month's start on rows whose D5 is at least 5 sessions before the month
(the embargo). The month's forecasts use only data up to each row's own day. Test months start once there are 250
training days.

**Judged by QLIKE** (the loss that stays fair when the target is noisy), with a 95% day-block bootstrap.
- **REPLACE ATR14** with the best model if its QLIKE gain over ATR14 has an interval above 0;
- otherwise **KEEP ATR14**.

The choice only decides which forecast stage B uses. The tree's calm/jumpy cut-off stays ATR14's.

## Stage B - does the forecast make the tree's books better? (3 fixed mappings, no tuning)

The tree's own books: D and ENS, 3 positions each, 1/3 a slot, 0.35 a round trip, triggerlab's frozen trades on the
cache's prices with the honest sale on locked circuits, D/ENS 50/50 restarted each January. The period runs from the
6th session of stage A's first test month.

- **S - sizing.** Each entry is x clip(rho / sigma5, 1/2, 3/2), i.e. 1/6 to 1/2 of the book. rho is set so the
  average multiplier over the engine's previous 250 sessions of trades is exactly 1. Same gross exposure; the risk
  moves from jumpy picks to calm ones.
- **T - probability target.** A pick gets +5% if a driftless stock with its sigma5 would touch +5% with a 50%+
  chance (sigma5 >= 7.41%), else +3% if sigma5 >= 4.45%, else no target. No new stop: the catastrophe stop is
  declared OFF.
- **R - risk state.** The book holds at most 2 positions after a close where NIFTY is risky:
  - its 24-month return < 0 AND its 126-day variance is above the 80th percentile of all earlier values; or
  - its 5-day HAR forecast is above the 80th percentile of all earlier forecasts.

**Example:** a pick with sigma5 = 8% gets a +5% target (a driftless stock touches +5% with odds
2(1 - Phi(5/8)) = 53%). Under S, if the typical recent pick's sigma5 is 5.3%, it gets about 2/3 of a normal slot.

**Verdicts** (declared; Holm over S, T and R):
- **S and R - ADOPTED** if all three hold:
  - daily-return variance falls against the frozen book cut to the same average exposure (interval under 1);
  - the mean costs no more than 3 bp a day (95% lower bound);
  - the worst fall is no deeper.
- **T - ADOPTED** if its mean daily gain is above 0 (Holm p <= 0.025).

Adopted = a candidate for a forward paper shadow book beside the frozen tree, judged at its own month 6 and month 12.
The frozen tree doesn't change. Nothing is re-run with other settings.

**Amended before any real run (22:05 IST):** the variance ratio is taken at matched exposure. The report's raw ratio
rewards any exposure cut: a switch flagging at random would pass whenever the mean cost stays inside 3 bp. The raw
ratio is still shown.

**Also shown:** S+T+R together; each variant's a year, worst fall, CVaR, exposure and trades; and the touch
calibration - predicted +3% / +5% touch chances vs what each pick's D1-D5 high did, by decile (the ledger's +/-5
point band).

## Run

```
call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
cd /d C:\Users\karanvsi\PyCharmMiscProject\vollab
python tests\test_vollab.py
python vollab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\vollab --check-only
python vollab.py run --root %CACHE_DAILY_ROOT% --data C:\QuantData\setuplab\WL_R1_10 --out C:\QuantData\vollab
```

It reads every eligible stock's 3-minute file once and prints progress every 100 stocks and at every monthly refit.

## What it writes (`C:\QuantData\vollab\VOLLAB_<date>_<nnn>\`)

- `VOLLAB.md` - the verdicts first
- `forecast_race.csv`, `forecast_race_picks.csv`, `forecast_race_measures.csv`, `refits.csv` - stage A
- `pick_forecasts.csv` - every tree pick's sigma5 from each model and the realised root of H
- `stageB.csv`, `stageB_daily.csv`, `stageB_trades.csv`, `touch_calibration.csv` - stage B
- `VOLLAB_RESULT.json`, `DECLARATION.json`, `RUN.json`, `outputs.sha256`; a line per run in `vollab_ledger.jsonl`

## Safety gates (it refuses rather than guess)

- the declaration must be the shipped file;
- the frozen tree must reproduce (triggerlab's gate);
- each pick's cache bars must match the watchlist's prices within 0.5% (more than 2% off: refused);
- the 3-minute layout check (fewer than half of the sessions with bars usable: refused);
- no month with 250 training days: refused;
- `--out` may not be inside the cache or a tool folder.

## Limits

- Decision A picks the forecast by its accuracy over the same months stage B then trades. That is an accuracy choice,
  not a money choice.
- The 3-minute era is about four years.
- A pick without a forecast (an ineligible or unusable signal day) keeps weight 1 and gets no target.
