"""
tests for vollab v1.0 - synthetic worlds only (tests/vl_world.py); nothing real is read, nothing outside a temporary
folder is written.

    python tests\\test_vollab.py          (from the vollab folder, in tradelab's env)

Ends with  VERIFIED (vollab v1.0)  or  FAILED.
  u1  the 3-minute measures (RV15, RV15sub, RV3, BV, RQ) = an independent bar-by-bar loop on 40 sessions (missing bars
      take the last close)
  u2  the usability rule = tradelab's IntradayStore._judge session by session (the planted unusable sessions too)
  u3  the target H, the daily models (ATR14, 20-day close-to-close, Yang-Zhang) and the HAR averages (with their
      minimum counts) = independent loops at 60 stock-days
  u4  GARCH: the filter and the 5-session forecast = explicit loops; the pooled fit recovers a simulated (0.08, 0.90)
  u5  the firewall: every price after a session changed (daily and 3-minute): every forecast of every model before it
      stays the same; every refit's training rows end 5 sessions before the month (the embargo)
  u6  stage A's numbers: QLIKE and the gain's interval = an explicit loop over the resampled days; decision A (REPLACE
      only with an interval above 0, KEEP otherwise, KEEP when ATR14 is best)
  u7  the book = triggerlab's book_sim (no multiplier, cap 3; 5 start days) and = a hand-written loop with multipliers
      and a cap; the account's yearly restart by hand
  u8  S's multipliers (mean 1 over the reference, the clip, 1 without 30 references); T's exits on hand-built paths
      (an entry-day touch, a gap above the level, a later touch, none, N1's own window); R's flags by loop (504-session
      return, 126-session variance, expanding 80th percentiles, NIFTY's HAR refit); the matched variance ratio and the
      touch table by hand
  w1  PLANTED world (clustered, stock-specific volatility): stage A REPLACES ATR14 with a HAR model; S ADOPTED, T and R
      not; every trade in the period has a forecast; the outputs hash-checked
  w2  PLANTED_T (pump-and-dumps a target catches): T ADOPTED
  w3  PLANTED_R (market crises with jumpy aftermaths): R ADOPTED
  w4  ABSENT (one volatility, no pumps, no crises): S, T and R NOT ADOPTED
  w5  refusals: an edited declaration, --out inside the cache, no eligibility column, too little 3-minute history,
      3-minute bars stamped wrong; --check-only writes nothing
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import os
import re
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import vollab as VL  # noqa: E402
import vl_world as VW  # noqa: E402

TG, TL, SU, TD, TC = VL.TG, VL.TL, VL.SU, VL.TD, VL.TC
FAILS = []
N_OK = [0]
SEED = 27


def check(cond, what):
    if cond:
        N_OK[0] += 1
        print("  ok   " + what)
    else:
        FAILS.append(what)
        print("  FAIL " + what, flush=True)
        if os.environ.get("VOLLAB_TEST_STOP"):          # mutation runs: the first failure is enough
            raise SystemExit(1)


def same(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


def run(root, data, out, extra=()):
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = VL.main(["run", "--root", str(root), "--data", str(data), "--out", str(out), "--stage-e-any"] +
                     list(extra))
    return rc, buf.getvalue()


def runs(out):
    return sorted(p for p in Path(out).iterdir() if p.is_dir() and re.fullmatch(r"VOLLAB_\d{8}_\d{3}", p.name)) \
        if Path(out).exists() else []


def outputs_ok(d):
    lines = (d / "outputs.sha256").read_text(encoding="utf-8").splitlines()
    return len(lines) >= 10 and all(
        hashlib.sha256((d / ln.split("  ", 1)[1]).read_bytes()).hexdigest() == ln.split("  ", 1)[0] for ln in lines)


def stage_a_parts(root):
    VW.use_mods(root)
    mk = TD.Market(root, TD.Production(stage_e_any=True))
    cal = np.asarray(mk.cal).astype("datetime64[D]")
    rows, _, _ = VL.read_universe(root / "panel_oc" / "panel.parquet", VW.ELIG, root, cal)
    R, Rm, cnt = VL.build_rows(mk, cal, rows, log=lambda *a: None)
    return mk, cal, rows, R, Rm, cnt


# ---------------------------------------------------------------------------------------------- references
def ref_measures(B, day):
    m = B["day"] == day
    sl, o, c = B["slot"][m], B["o"][m], B["c"][m]
    p = [o[sl == 0][0]]
    for k in range(1, VL.NB + 1):
        have = [c[i] for i in range(len(sl)) if sl[i] <= k - 1]
        p.append(have[-1])
    lp = [math.log(x) for x in p]
    r3 = [lp[k] - lp[k - 1] for k in range(1, 126)]
    g0 = [lp[5 * j] for j in range(26)]
    r15 = [g0[j] - g0[j - 1] for j in range(1, 26)]
    sub = 0.0
    for g in range(5):
        pts = [0] + [x for x in range(g, 126, 5) if x > 0] + ([125] if (125 - g) % 5 else [])
        pts = sorted(set(pts))
        sub += sum((lp[pts[i]] - lp[pts[i - 1]]) ** 2 for i in range(1, len(pts)))
    return {"RV3": sum(x * x for x in r3), "RV15": sum(x * x for x in r15), "RVsub": sub / 5,
            "BV": math.pi / 2 * sum(abs(r15[j]) * abs(r15[j - 1]) for j in range(1, 25)),
            "RQ": 25 / 3 * sum(x ** 4 for x in r15)}


def ref_row(ds_arr, M, t):
    """The target, daily models and HAR averages at calendar index t from per-day arrays (loops)."""
    O, H, L, C, A = ds_arr
    U = M

    def ron(d):
        return math.log(O[d] / C[d - 1]) if (np.isfinite(O[d]) and np.isfinite(C[d - 1])) else np.nan

    def usable(d):
        return np.isfinite(U["RV15"][d]) and np.isfinite(C[d])

    def usetv(d):
        return usable(d) and np.isfinite(ron(d))
    out = {}
    nc = len(C)
    if t + 5 < nc and usable(t + 1) and all(usetv(d) for d in range(t + 2, t + 6)):
        out["H"] = U["RVsub"][t + 1] + sum(ron(d) ** 2 + U["RVsub"][d] for d in range(t + 2, t + 6))
    else:
        out["H"] = np.nan
    out["f0"] = 5 * A[t] ** 2
    rr = [math.log(C[d] / C[d - 1]) ** 2 for d in range(t - 19, t + 1) if np.isfinite(C[d]) and np.isfinite(C[d - 1])]
    out["f1"] = 5 * np.mean(rr) if len(rr) >= 18 else np.nan
    on_, oc_, rs_ = [], [], []
    for d in range(t - 19, t + 1):
        r_ = ron(d)
        if np.isfinite(r_) and np.isfinite(C[d]) and np.isfinite(O[d]):
            on_.append(r_)
            oc_.append(math.log(C[d] / O[d]))
            rs_.append(math.log(H[d] / C[d]) * math.log(H[d] / O[d]) + math.log(L[d] / C[d]) * math.log(L[d] / O[d]))
    n = len(on_)
    if n >= 18:
        k = 0.34 / (1.34 + (n + 1) / (n - 1))
        out["f2"] = 5 * (np.var(on_, ddof=1) + k * np.var(oc_, ddof=1) + (1 - k) * np.mean(rs_))
    else:
        out["f2"] = np.nan

    def tv(d):
        return ron(d) ** 2 + U["RV15"][d] if usetv(d) else np.nan
    v5 = [tv(d) for d in range(t - 4, t + 1)]
    v22 = [tv(d) for d in range(t - 21, t + 1)]
    f5 = [x for x in v5 if np.isfinite(x)]
    f22 = [x for x in v22 if np.isfinite(x)]
    out["TV1"] = tv(t)
    out["TV5"] = np.mean(f5) if len(f5) >= 4 else np.nan
    out["TV22"] = np.mean(f22) if len(f22) >= 18 else np.nan
    return out


# ---------------------------------------------------------------------------------------------- unit checks
def unit_a(tmp):
    print("unit checks: stage A")
    root, data, W = VW.make_world(tmp / "ua", SEED, "planted", SU=SU)
    mk, cal, rows, R, Rm, cnt = stage_a_parts(root)
    cal_pos = {d: i for i, d in enumerate(cal.tolist())}
    rng = np.random.default_rng(1)
    sym = "S004"
    ds = mk.series(sym)
    O, H, L, C, A = VL.daily_on_cal(ds, cal)
    B = VL.read_3m(mk.intraday.path(sym))
    days, us, reason, ci, has_d = VL.judge(B, O, H, L, C, cal_pos)
    keep = days[us]
    M3 = VL.measures(B, keep)
    nbar = np.array([(B["day"] == d_).sum() for d_ in keep])
    thin = np.flatnonzero(nbar < VL.NB)
    pick = np.r_[rng.choice(len(keep), 20, replace=False), thin[:20]]
    bad = []
    for j in pick:
        ref = ref_measures(B, keep[j])
        for k, v in ref.items():
            if not same(M3[k][j], v, 1e-9):
                bad.append((str(keep[j]), k, M3[k][j], v))
    check(not bad and len(thin) >= 15, "u1 the 3-minute measures = the bar-by-bar loop on 40 sessions (%d with bars "
                                       "missing) %s" % (min(len(thin), 20), bad[:2] if bad else ""))
    # u2 the usability rule against tradelab's own
    sess = mk.intraday.sessions(sym, list(days), ds)
    mine = {d.item() if hasattr(d, "item") else d: (bool(u), int(r)) for d, u, r in zip(days, us, reason)}
    diff = []
    for d, s in sess.items():
        ok, why = TD.IntradayStore._judge(s, ds)
        u_, r_ = mine[np.datetime64(d, "D").item()]
        if ok != u_ or (not ok and VL.REASONS[r_] != why):
            diff.append((str(d), ok, why, u_, r_))
    n_bad = int((~us).sum())
    check(not diff and n_bad >= 12 and len(sess) == len(days),
          "u2 the usability rule = tradelab's IntradayStore._judge on %d sessions (%d unusable, planted) %s" % (
              len(days), n_bad, diff[:2] if diff else ""))
    # u3 the target, the daily models, the HAR averages
    si = int(np.flatnonzero(R["syms"] == sym)[0])
    Mc = {k: np.full(len(cal), np.nan) for k in M3}
    for k in M3:
        Mc[k][ci[us]] = M3[k]
    rws = np.flatnonzero(R["si"] == si)
    bad = []
    for i in rng.choice(rws, 60, replace=False):
        t = int(R["t"][i])
        ref = ref_row((O, H, L, C, A), Mc, t)
        for k, v in ref.items():
            if not same(R[k][i], v, 1e-8):
                bad.append((str(cal[t]), k, R[k][i], v))
    check(not bad, "u3 the target, ATR14, the 20-day close-to-close, Yang-Zhang and the HAR averages = loops at 60 "
                   "stock-days %s" % (bad[:2] if bad else ""))
    # u4 GARCH
    g = np.random.default_rng(5)
    nc, ns = 400, 3
    X = g.normal(0, 0.02, (nc, ns))
    X[g.random((nc, ns)) < 0.05] = np.nan
    v = np.array([4e-4, 3e-4, 5e-4])
    a, b = 0.07, 0.9
    S2 = VL.garch_filter(np.where(np.isfinite(X), X ** 2, 0), np.isfinite(X), v, a, b)
    ref = np.zeros((nc, ns))
    for j in range(ns):
        s2 = v[j]
        for t in range(nc):
            r2 = X[t, j] ** 2 if np.isfinite(X[t, j]) else s2
            s2 = v[j] * (1 - a - b) + a * r2 + b * s2
            ref[t, j] = s2
    Fg = VL.garch_forecast(X, nc - 1, (a, b), v)
    refF = np.array([[sum(v[j] + (a + b) ** (k - 1) * (ref[t, j] - v[j]) for k in range(1, 6)) for j in range(ns)]
                     for t in range(nc)])
    check(same(S2, ref, 1e-12) and same(Fg, refF, 1e-12), "u4a GARCH's filter and 5-session forecast = loops")
    T_, N_ = 2000, 30
    e = g.normal(size=(T_, N_))
    vv = g.uniform(1e-4, 9e-4, N_)
    s2 = vv.copy()
    Y = np.zeros((T_, N_))
    for t in range(T_):
        Y[t] = np.sqrt(s2) * e[t]
        s2 = vv * (1 - 0.98) + 0.08 * Y[t] ** 2 + 0.90 * s2
    ab, vfit, nfev = VL.garch_fit(Y, T_ - 1, VL.GARCH_START)
    check(abs(ab[0] - 0.08) < 0.03 and abs(ab[1] - 0.90) < 0.04, "u4b the pooled GARCH fit recovers a simulated "
                                                                 "(0.08, 0.90): (%.3f, %.3f), %d evaluations" % (
                                                                     ab[0], ab[1], nfev))
    # u5 the firewall
    WF = VL.WalkForward(R, Rm, cal, log=lambda *a: None)
    months = WF.months()
    F1 = {k: v.copy() for k, v in WF.run(months).items()}
    emb = all(pd.Timestamp(f["cutoff"]) <= pd.Timestamp(cal[int(np.searchsorted(cal, np.datetime64(f["month"] + "-01")))
                                                               - 1 - VL.EMBARGO]) for f in WF.fits)
    tr_ok = True
    for f in WF.fits:
        fs = int(np.searchsorted(cal, np.datetime64(f["month"] + "-01")))
        tr = WF.E & (WF.d5 <= fs - 1 - VL.EMBARGO)
        tr_ok &= int(tr.sum()) == f["train_rows"] and int((R["t"][tr] + 5).max()) <= fs - 6
    kap_ok = True
    for f in WF.fits:
        te = WF.row_mon == np.datetime64(f["month"], "M").astype(np.int64)
        for j in range(3):
            m = "M%d" % j
            ok_ = te & WF.okd[m]
            kap_ok &= same(F1[m][ok_], f["kappa_" + m] * R["f%d" % j][ok_], 1e-12)
        X3, ok3 = VL.har_X(R, "M3")
        o3 = te & ok3
        kap_ok &= same(F1["M3"][o3], f["kappa_M3"] * np.exp(X3[o3] @ np.array(f["coef_M3"])), 1e-9)
    check(kap_ok, "u5a every forecast = its month's kappa x the raw forecast (M0-M2; M3 from its recorded fit)")
    X_day = cal[int(np.searchsorted(cal, np.datetime64("2024-03-01")))]
    root2 = tmp / "ua2" / "root"
    shutil.copytree(root, root2)
    gg = np.random.default_rng(9)
    for p in list(root2.glob("*_daily.parquet")):
        df = pd.read_parquet(p)
        t = pd.to_datetime(df["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
        m = (t >= pd.Timestamp(X_day)).to_numpy()
        f = np.exp(gg.normal(0, 0.05, m.sum()))
        for k in ("open", "high", "low", "close"):
            df.loc[m, k] = df.loc[m, k].to_numpy() * f
        df.to_parquet(p, index=False)
        p3 = root2 / "intraday_3m" / (p.name.replace("_daily", "_3m"))
        if p3.exists():
            d3 = pd.read_parquet(p3)
            t3 = pd.to_datetime(d3["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None).dt.normalize()
            day_f = pd.Series(f, index=t[m].to_numpy())
            fac = t3.map(day_f).fillna(1.0).to_numpy()
            for k in ("open", "high", "low", "close"):
                d3[k] = d3[k].to_numpy() * fac
            d3.to_parquet(p3, index=False)
    mk2, cal2, rows2, R2, Rm2, _ = stage_a_parts(root2)
    WF2 = VL.WalkForward(R2, Rm2, cal2, log=lambda *a: None)
    F2 = WF2.run(WF2.months())
    before = R["t"] < int(np.searchsorted(cal, X_day))
    after = ~before
    unchanged = all(same(F1[k][before], F2[k][before], 1e-12) for k in VL.MODELS + VL.INFO_MODELS)
    moved = any(not same(F1[k][after], F2[k][after], 1e-6) for k in VL.MODELS)
    check(unchanged and moved and emb and tr_ok and WF2.months() == months,
          "u5 the firewall: prices changed from %s on: every forecast before it unchanged (7 models + 2), later ones "
          "move; each refit's training rows end 5 sessions before its month" % X_day)
    # u6 stage A's numbers and decision A
    test = WF.E & np.isin(WF.row_mon, months)
    for m in VL.MODELS:
        test &= np.isfinite(F1[m]) & (F1[m] > 0)
    ti = np.flatnonzero(test)
    rows_ = VL.race_table(R["H"][ti], {m: F1[m][ti] for m in VL.MODELS}, R["t"][ti], cal, VL.MODELS)
    days_, di = np.unique(R["t"][ti], return_inverse=True)
    B_ = SU.Boot(days_, B=VL.BOOT_B, block=VL.BOOT_BLOCK, seed=VL.BOOT_SEED)
    q0, q3 = VL.qlike(R["H"][ti], F1["M0"][ti]), VL.qlike(R["H"][ti], F1["M3"][ti])
    gain = q0 - q3
    sums = np.bincount(di, gain, len(days_))
    cnts = np.bincount(di, minlength=len(days_))
    ms = np.array([sums[ix].sum() / cnts[ix].sum() for ix in B_.ix[:400]])
    r3 = next(r for r in rows_ if r["model"] == "M3")
    M_ = SU.Boot(days_, B=400, block=VL.BOOT_BLOCK, seed=VL.BOOT_SEED)
    g_est, g_lo, g_hi, _ = VL.boot_mean(M_, di, gain)
    check(same(r3["qlike"], q3.mean()) and same(r3["gain_vs_M0"], gain.mean()) and
          same([g_lo, g_hi], np.percentile(ms, [2.5, 97.5]), 1e-9),
          "u6a QLIKE and the gain's interval = an explicit loop over the resampled days")
    base = {"what": "", "rows": 10, "days": 5, "gain_lo": 0.01, "gain_hi": 0.02}
    t1_ = [dict(base, model="M0", qlike=0.5, gain_vs_M0=0.0)] + [dict(base, model=m, qlike=0.6, gain_vs_M0=-0.1)
                                                                 for m in VL.MODELS[1:]]
    t1_[3] = dict(base, model="M3", qlike=0.4, gain_vs_M0=0.1, gain_lo=0.02)
    d1 = VL.decide_A(t1_)
    t2_ = [dict(r) for r in t1_]
    t2_[3]["gain_lo"] = -0.01
    d2 = VL.decide_A(t2_)
    t3_ = [dict(base, model="M0", qlike=0.3, gain_vs_M0=0.0)] + [dict(base, model=m, qlike=0.35, gain_vs_M0=-0.05,
                                                                      gain_lo=-0.07) for m in VL.MODELS[1:]]
    d3 = VL.decide_A(t3_)
    check(d1["replace"] and d1["chosen"] == "M3" and not d2["replace"] and d2["chosen"] == "M0" and
          not d3["replace"] and d3["chosen"] == "M0",
          "u6b decision A: REPLACE with the best only when its gain's interval is above 0; KEEP otherwise")
    return root, data, W


def unit_b(tmp):
    print("unit checks: stage B")
    root, data, W = VW.make_world(tmp / "ub", SEED, "planted_R", SU=SU)
    VW.use_mods(root)
    a = SimpleNamespace(data=str(data))
    TS = VL.tree_setup(a, root, root / "panel_oc" / "panel.parquet", lambda *x: None)
    mk = TD.Market(root, TD.Production(stage_e_any=True))
    U = TG.Universe(TS["bk"], TS["cuts"]["2/3"], TS["tdoc"], TS["s_"])
    PA, _ = TG.load_paths(U, TS["bk"], VL._DailyOnly(mk), log=lambda *x: None)
    U.keep(PA.ok)
    bk, t1 = TS["bk"], TS["t1"]
    T, _ = TG.frozen_trades(U, PA, bk, TS["ED"], "first_up", TS["primary"])
    # u7 the book
    worst = 0.0
    for p_ in range(5):
        a1 = TG.book_sim(T, PA.C, TS["s_"] + p_, t1)
        a2 = VL.book_sim2(T, PA.C, TS["s_"] + p_, t1)
        worst = max(worst, float(np.max(np.abs(a1[1] - a2[1]))), float(np.max(np.abs(a1[0] - a2[0]))))
        worst = max(worst, float(np.abs(a1[3] - a2[3]).max()))
    check(worst == 0.0, "u7a book_sim2 without multipliers or a cap = triggerlab's book_sim exactly (5 start days)")
    rng = np.random.default_rng(4)
    mult = rng.uniform(0.5, 1.5, len(T["ent"]))
    cap = rng.choice([2, 3], len(bk.cal))
    s0 = TS["s_"]
    eqc, eqm, taken, sizes, expo = VL.book_sim2(T, PA.C, s0, t1, mult=mult, cap=cap)
    # the hand loop
    open_, realized = [], 0.0
    tk2, sz2 = np.zeros(len(T["ent"]), bool), np.zeros(len(T["ent"]))
    for j in range(len(T["ent"])):
        t = T["ent"][j]
        if t < s0 or t > t1:
            continue
        still = []
        for (k_, jj) in sorted(open_):
            if k_ < t:
                realized += sz2[jj] * T["net"][jj] / 100
            else:
                still.append((k_, jj))
        open_ = still
        if len(open_) < cap[t]:
            sz2[j] = (1 + realized) / 3 * mult[j]
            tk2[j] = True
            open_.append((T["ex"][j] - 0.5 * T["oexit"][j], j))
    check(np.array_equal(taken, tk2) and same(sizes, sz2, 1e-12),
          "u7b with multipliers and a per-session cap: the same entries and sizes as a hand-written loop")
    cal = bk.cal
    vD = np.cumprod(1 + rng.normal(0, 0.01, 300))
    vE = np.cumprod(1 + rng.normal(0, 0.01, 300))
    p0 = int(np.searchsorted(cal, np.datetime64("2023-11-01")))
    r = VL.account_returns(vD, vE, cal, p0, p0 + 299)
    ref, yrs = [], pd.DatetimeIndex(cal[p0:p0 + 300]).year
    aD, aE, prevA = 1.0, 1.0, None
    for i in range(300):
        if i == 0 or yrs[i] != yrs[i - 1]:
            aD = 1.0 if i == 0 else vD[i - 1]
            aE = 1.0 if i == 0 else vE[i - 1]
            prevA = 1.0
        A_ = 0.5 * vD[i] / aD + 0.5 * vE[i] / aE
        ref.append(A_ / prevA - 1)
        prevA = A_
    check(same(r, ref, 1e-12), "u7c the account's daily returns with the split restarted each 1 January, by hand")
    # u8 S
    sig = np.where(rng.random(len(T["ent"])) < 0.9, rng.uniform(0.03, 0.12, len(T["ent"])), np.nan)
    m, rho = VL.s_multipliers(T, sig)
    okm, n_ref = True, 0
    for j in rng.choice(len(T["ent"]), 200, replace=False):
        e_ = T["eng"][j]
        ref_m = (T["eng"] == e_) & np.isfinite(sig) & (T["ent"] >= T["ent"][j] - 250) & (T["ent"] < T["ent"][j])
        if ref_m.sum() >= 30:
            n_ref += 1
            okm &= abs(np.mean(np.clip(rho[j] / sig[ref_m], 0.5, 1.5)) - 1) < 1e-9
            want = np.clip(rho[j] / sig[j], 0.5, 1.5) if np.isfinite(sig[j]) else 1.0
            okm &= abs(m[j] - want) < 1e-12
        else:
            okm &= m[j] == 1.0 and np.isnan(rho[j])
    check(okm and n_ref > 100 and m.min() >= 0.5 and m.max() <= 1.5,
          "u8a S: the multipliers average exactly 1 over each trade's reference (%d checked), clipped to 1/2-3/2, 1 "
          "without 30 references or a forecast" % n_ref)
    # T on hand-built paths
    PAt = SimpleNamespace(O=np.full((5, 32), 100.0), H=np.full((5, 32), 101.0))
    PAt.H[0, 1] = 103.5                                  # entry day touch (+3%)
    PAt.O[1, 3], PAt.H[1, 3] = 104.0, 104.5              # a gap above +3% on D3
    PAt.H[2, 4] = 105.2                                  # +5% touched on D4
    PAt.H[3, 6] = 110.0                                  # after the D5 exit: never
    PAt.H[4, 5] = 103.2                                  # N1 entered on D2: window D2..D6
    Tt = {"u": np.arange(5), "d": np.array([1, 1, 1, 1, 2]), "p0": np.full(5, 100.0), "i1": np.full(5, 10),
          "ent": np.array([10, 10, 10, 10, 11]), "ex": np.array([14, 14, 14, 14, 15]), "oexit": np.zeros(5, bool),
          "net": np.full(5, 0.65), "g": np.array(["FROZEN:open", "FROZEN:S1", "FROZEN:open", "FROZEN:open",
                                                  "FROZEN:N1"], dtype=object)}
    lvl = np.array([3.0, 3.0, 5.0, 3.0, 3.0])
    T2 = VL.t_trades(Tt, PAt, lvl, {"N1": "fresh", "S1": "original_d5"})
    want_net = np.array([3 - 0.35, 4 - 0.35, 5 - 0.35, 0.65, 3 - 0.35])
    want_ex = np.array([10, 12, 13, 14, 14])
    check(same(T2["net"], want_net, 1e-9) and np.array_equal(T2["ex"], want_ex) and
          list(T2["t_hit"]) == [True, True, True, False, True],
          "u8b T: an entry-day touch sells at the level, a gap above it at the open, a later touch at the level, none "
          "keeps the frozen exit, N1's window runs to its own exit")
    lv = VL.t_levels(np.array([0.08, 0.0742, 0.0740, 0.0445, 0.0444, np.nan]))
    check(same(lv, [5, 5, 3, 3, np.nan, np.nan]), "u8c T's levels: +5%% from sigma5 %.3f%%, +3%% from %.3f%%" % (
        5 / VL.Z75, 3 / VL.Z75))
    # R's flags by loop
    ds = mk.series("NIFTY50")
    calm = np.asarray(mk.cal).astype("datetime64[D]")
    flag, fA, fB, Fh, pv, pf = VL.nifty_state(ds, calm)
    O, H, L, C, _ = VL.daily_on_cal(ds, calm)
    lr = np.r_[np.nan, np.log(C[1:] / C[:-1])]
    v126 = np.array([np.mean(lr[t - 125:t + 1] ** 2) if t >= 126 else np.nan for t in range(len(C))])
    okA = True
    for t in rng.choice(np.arange(700, len(C)), 60, replace=False):
        prev = v126[:t][np.isfinite(v126[:t])]
        pct = np.percentile(prev, 80) if len(prev) >= 250 else np.nan
        ret = math.log(C[t] / C[t - 504])
        okA &= bool(fA[t]) == bool(ret < 0 and np.isfinite(pct) and v126[t] > pct) and same(pv[t], pct, 1e-12)
    mon = calm.astype("datetime64[M]").astype(np.int64)
    Mx = int(mon[int(np.searchsorted(calm, np.datetime64("2024-07-01")))])
    f = int(np.searchsorted(mon, Mx))
    c = f - 1 - VL.EMBARGO
    TV = np.log(O / np.r_[np.nan, C[:-1]]) ** 2 + 0.5 * np.log(H / L) ** 2 - (2 * math.log(2) - 1) * np.log(C / O) ** 2
    rows_x, rows_y = [], []
    for t in range(22, c - 4):
        h = sum(TV[t + k] for k in range(1, 6))
        x = [1, math.log(TV[t]), math.log(np.mean(TV[t - 4:t + 1])), math.log(np.mean(TV[t - 21:t + 1]))]
        if np.isfinite(h) and np.all(np.isfinite(x)):
            rows_x.append(x)
            rows_y.append(math.log(h))
    bb = np.linalg.lstsq(np.array(rows_x), np.array(rows_y), rcond=None)[0]
    te = np.flatnonzero(mon == Mx)
    refF = np.exp(np.array([[1, math.log(TV[t]), math.log(np.mean(TV[t - 4:t + 1])),
                             math.log(np.mean(TV[t - 21:t + 1]))] for t in te]) @ bb)
    okB = True
    for t in te:
        prev = Fh[:t][np.isfinite(Fh[:t])]
        pct = np.percentile(prev, 80) if len(prev) >= 250 else np.nan
        okB &= bool(fB[t]) == bool(np.isfinite(pct) and Fh[t] > pct) and same(pf[t], pct, 1e-12)
    check(okA and okB and same(Fh[te], refF, 1e-9) and np.array_equal(flag, fA | fB),
          "u8d R: the bear-and-volatile flag and the HAR flag by loop (504-session return, 126-session variance, "
          "expanding 80th percentiles of earlier values, NIFTY's log-HAR refit for %s)" % np.datetime64(Mx, "M"))
    fl = rng.random(300) < 0.3
    cp = VL.r_cap(fl)
    check(cp[0] == 3 and all(cp[e] == (2 if fl[e - 1] else 3) for e in range(1, 300)),
          "u8g R's cap: 2 positions for an entry after a flagged close (the close before it), else 3")
    fz_ = {"fall": 20.0}
    base = {"p_var": 0.001, "p_mean": 0.5, "diff_lo": -1.0, "fall": 18.0}
    rws = {"S": dict(base), "T": dict(base, p_mean=0.002), "R": dict(base)}
    VL.decide_B(rws, fz_)
    v1 = {k: rws[k]["verdict"] for k in rws}
    h1 = [rws[k]["p_holm"] for k in ("S", "T", "R")]
    rws = {"S": dict(base, diff_lo=-3.2), "T": dict(base, p_mean=0.012), "R": dict(base, fall=20.5)}
    VL.decide_B(rws, fz_)
    v2 = {k: rws[k]["verdict"] for k in rws}
    rws = {"S": dict(base, p_var=0.02), "T": dict(base, p_mean=0.009), "R": dict(base, p_var=0.3)}
    VL.decide_B(rws, fz_)
    v3 = {k: rws[k]["verdict"] for k in rws}
    check(v1 == {"S": "ADOPTED", "T": "ADOPTED", "R": "ADOPTED"} and same(h1, [0.003, 0.003, 0.003]) and
          v2 == {"S": "NOT ADOPTED", "T": "ADOPTED", "R": "NOT ADOPTED"} and
          v3 == {"S": "NOT ADOPTED", "T": "NOT ADOPTED", "R": "NOT ADOPTED"},
          "u8h decision B: Holm over S, T, R (T's p 0.009 becomes 0.027: not adopted); S and R also need the 3 bp "
          "margin and no deeper fall; T only its Holm p")
    # the matched variance ratio and the touch table
    rv, rf = rng.normal(0, 0.008, 400), rng.normal(0, 0.01, 400)
    B_ = SU.Boot(np.arange(400), B=300, block=10, seed=7)
    vr, lo, hi, p = VL.variance_test(B_, rv, rf, 0.9)
    st = [np.var(rv[ix], ddof=1) / (0.81 * np.var(rf[ix], ddof=1)) for ix in B_.ix]
    sd = np.std(np.log(st), ddof=1)
    check(same(vr, np.var(rv, ddof=1) / (0.81 * np.var(rf, ddof=1)), 1e-12) and
          same([lo, hi], np.percentile(st, [2.5, 97.5]), 1e-9) and same(p, 1 - VL.phi(-math.log(vr) / sd), 1e-9),
          "u8e the matched variance ratio, its interval and p = an explicit loop over the resamples")
    sg = rng.uniform(0.02, 0.1, 500)
    O1 = np.full(500, 100.0)
    Hm = 100 * np.exp(np.abs(rng.normal(0, 1, 500)) * sg)
    tab = pd.DataFrame(VL.touch_table(sg, O1, Hm))
    P3 = 2 * (1 - np.array([VL.phi(3 / (x * 100)) for x in sg]))
    q = pd.qcut(pd.Series(P3), 10, labels=False)
    r0 = tab[(tab["level_pct"] == 3) & (tab["decile"] == 1)].iloc[0]
    m0 = (q == 0).to_numpy()
    check(len(tab) == 20 and same(r0["predicted_pct"], 100 * P3[m0].mean()) and
          same(r0["reached_pct"], 100 * np.mean(Hm[m0] >= 103)) and r0["picks"] == m0.sum(),
          "u8f the touch table by hand (deciles of the predicted chance, reached share)")


# ---------------------------------------------------------------------------------------------- worlds
def world(tmp, kind, want, extra_checks=None):
    print("%s world" % kind)
    root, data, W = VW.make_world(tmp / kind, SEED, kind, SU=SU)
    out = tmp / (kind + "_out")
    rc, log = run(root, data, out)
    R = runs(out)
    ok = rc == 0 and len(R) == 1
    if not ok:
        check(False, "%s runs (rc %s) %s" % (kind, rc, log[-2500:]))
        return None
    d = R[0]
    res = json.loads((d / "VOLLAB_RESULT.json").read_text(encoding="utf-8"))
    got = {k: res["stage_B"]["variants"][k]["verdict"] for k in ("S", "T", "R")}
    check(got == want, "%s: stage B %s (wanted %s)" % (kind, got, want))
    if extra_checks:
        extra_checks(d, res, root, data, W)
    return d, res, root, data


def planted_checks(d, res, root, data, W):
    a = res["stage_A"]["decision"]
    check(a["replace"] and a["chosen"] in ("M3", "M4", "M5"),
          "w1a PLANTED: stage A %s (best %s)" % (a["verdict"], a["best"]))
    tr = pd.read_csv(d / "stageB_trades.csv")
    fits = pd.read_csv(d / "refits.csv")
    cal = pd.read_parquet(data / "calendar.parquet")["date"].to_numpy().astype("datetime64[D]")
    first = int(np.searchsorted(cal, np.datetime64(fits["month"].iloc[0] + "-01")))
    pf = pd.read_csv(d / "pick_forecasts.csv")
    key = dict(zip(zip(pf["symbol"], pf["signal_day"].astype(str)), pf["sigma5_%s_pct" % a["chosen"]]))
    want = np.array([key.get((s_, str(d_)), np.nan) for s_, d_ in zip(tr["symbol"], tr["signal_day"])])
    share = float(tr["sigma5_pct"].notna().mean())
    check(len(tr) > 100 and share >= 0.9 and same(tr["sigma5_pct"].to_numpy(float), want, 1e-4) and
          pd.Timestamp(res["stage_B"]["from"]) == pd.Timestamp(cal[first + VL.B_OFFSET]),
          "w1b stage B starts at the first test month's 6th session; each of its %d trades carries its pick's stage-A "
          "forecast (%.1f%% have one; the rest are ineligible or unusable signal days)" % (len(tr), 100 * share))
    check(outputs_ok(d) and (d / "VOLLAB.md").read_text(encoding="utf-8").startswith("# vollab v1.0") and
          SU.frozen_hash(res) == res["sha256"], "w1c the outputs are hash-checked; the result carries its own sha256")
    sb = pd.read_csv(d / "stageB.csv").set_index("book")
    dl = pd.read_csv(d / "stageB_daily.csv")
    okv = True
    for v in ("S", "T", "R"):
        c = sb.loc[v, "exposure"] / sb.loc["frozen", "exposure"]
        okv &= same(sb.loc[v, "vr"], np.var(dl["r_" + v], ddof=1) / (c * c * np.var(dl["r_frozen"], ddof=1)), 1e-6)
    ph = VL.holm([sb.loc["S", "p_var"], sb.loc["T", "p_mean"], sb.loc["R", "p_var"]])
    check(okv and same(sb.loc[["S", "T", "R"], "p_holm"].to_numpy(float), ph, 1e-9),
          "w1e the reported variance ratios = var(variant) / var(c x frozen) from the daily returns; the Holm p's by "
          "hand")
    L = (d.parent / "vollab_ledger.jsonl").read_text(encoding="utf-8").splitlines()
    check(len(L) == 2 and json.loads(L[1])["stage_A"] == a["verdict"], "w1d the ledger has the run's start and end")


def refusals(tmp, root, data):
    print("refusals")
    out = tmp / "r_out"
    good = (VL.HERE / VL.DECL_FILE).read_text(encoding="utf-8")
    try:
        doc = json.loads(good)
        doc["stage_B"]["T"] = doc["stage_B"]["T"].replace("+5%", "+4%")
        (VL.HERE / VL.DECL_FILE).write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
        rc, log = run(root, data, out)
        check(rc == 3 and "changed after it was declared" in log, "w5a an edited declaration is refused")
    finally:
        (VL.HERE / VL.DECL_FILE).write_text(good, encoding="utf-8")
    rc, log = run(root, data, out, ["--check-only"])
    check(rc == 0 and "CHECK OK" in log and not runs(out), "w5b --check-only checks and writes no run")
    rc, log = run(root, data, root / "x")
    check(rc == 3 and "inside" in log, "w5c --out inside the cache is refused")
    VW.use_mods(root, with_sb=False)
    try:
        rc, log = run(root, data, out)
        check(rc == 3 and "ELIG_COL" in log, "w5d no stage_b_screen and no --elig-col is refused")
    finally:
        VW.use_mods(root)
    root2, data2, _ = VW.make_world(tmp / "short", SEED, "absent", n_sym=8, i3_from="2025-01-01", SU=SU)
    rc, log = run(root2, data2, tmp / "short_out")
    check(rc == 3 and "training days" in log, "w5e too little 3-minute history (from 2025) is refused")
    d3 = root2 / "intraday_3m"
    for p in d3.glob("*_3m.parquet"):
        df = pd.read_parquet(p)
        df["timestamp"] = pd.to_datetime(df["timestamp"]) + pd.Timedelta(minutes=3)    # stamped at the bar's end
        df.to_parquet(p, index=False)
    rc, log = run(root2, data2, tmp / "short_out")
    check(rc == 3 and "layout check" in log, "w5f 3-minute bars stamped at their end are refused (the layout check)")
    check(not runs(out) and not runs(tmp / "short_out"), "w5g no refused run wrote a run folder")


def main():
    print("%s self-test (pandas %s, numpy %s)" % (VL.VERSION, pd.__version__, np.__version__))
    tmp = Path(tempfile.mkdtemp(prefix="vollab_test_"))
    try:
        p, doc = VL.load_declaration()
        check(doc["tool"] == VL.VERSION and doc["constants"] == json.loads(json.dumps(VL.constants())),
              "u0 the declaration is this version's, unchanged (%s)" % doc["sha256"][:16])
        unit_a(tmp)
        unit_b(tmp)
        w = world(tmp, "planted", {"S": "ADOPTED", "T": "NOT ADOPTED", "R": "NOT ADOPTED"}, planted_checks)
        world(tmp, "planted_T", {"S": "NOT ADOPTED", "T": "ADOPTED", "R": "NOT ADOPTED"})
        world(tmp, "planted_R", {"S": "ADOPTED", "T": "NOT ADOPTED", "R": "ADOPTED"})
        world(tmp, "absent", {"S": "NOT ADOPTED", "T": "NOT ADOPTED", "R": "NOT ADOPTED"})
        if w:
            refusals(tmp, w[2], w[3])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print("FAILED: %d of %d checks" % (len(FAILS), len(FAILS) + N_OK[0]))
        for f in FAILS:
            print("   - " + f)
        return 1
    print("VERIFIED (%s) - %d checks" % (VL.VERSION, N_OK[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
