"""
tests/vl_world.py - synthetic worlds for vollab's tests (nothing here ships to production).

make_world(base, seed, mode) writes:
  root: <SYM>_daily.parquet (+ NIFTY50), intraday_3m\\<SYM>_3m.parquet (125 bars a session from i3_from, IST stamps,
        a few unusable sessions and 20 usable ones with 5 bars missing planted per stock), panel_oc\\panel.parquet (the frozen setups' inputs and the eligibility
        column), _mods (stand-in production modules: stage_e_execution, intraday_cache, data_quality, stage_b_screen)
  data: setuplab's watchlist folder (D and ENS ranks 1-per_day from 2020).
  planted:   idiosyncratic log-volatility AR(1) (phi 0.97, sd 0.15, a level per stock from 0.4% to 3% a day) -
             volatility clusters and differs by stock, so the 3-minute HAR models beat ATR14 and S's sizing evens the
             risk out.
  planted_T: 2.2% a day for every stock (every trade gets a +3% target) and intraday pump-and-dumps (+6% for 10
             bars, back by the close) on 15% of stock-days: a target catches them, the D5 close never sees them.
  planted_R: 0.8% a day for every stock, a market rising 0.08% a day, and two crises (80 sessions: -0.4% a day, 4%
             sd; after them the market's sd decays back to 0.8% by 5% a day, flat while above 1.2%) that NIFTY and
             every stock share: a cut in exposure while NIFTY is risky lowers the risk more than a plain cut.
  absent:    2% a day for every stock, no pump-and-dumps, no crises (NIFTY a plain random walk).
The daily bars are the 3-minute bars' open / high / low / close (from i3_from; before it the same path, unsaved).
"""
from __future__ import annotations

import importlib
import sys
import textwrap
from pathlib import Path

import numpy as np
import pandas as pd

IST = "Asia/Kolkata"
NB = 125
SUB = 4
ELIG = "label_buyable_o1"
FZ = ["d_wq_16", "d_mdi14_diff5", "d_wq_40", "d_mdi14", "d_ema20_angle_deg", "d_wq_44", "d_bb_bw_20"]
KINDS = {
    "planted": {"levels": (0.004, 0.03), "const": None, "pump": 0.0, "crises": (), "mu": 0.0004},
    "planted_T": {"levels": None, "const": 0.022, "pump": 0.15, "crises": (), "mu": 0.0004},
    "planted_R": {"levels": None, "const": 0.008, "pump": 0.0, "crises": (("2023-03-01", 80), ("2024-06-03", 80)),
                  "mu": 0.0008},
    "absent": {"levels": None, "const": 0.02, "pump": 0.0, "crises": (), "mu": 0.0004},
}
PUMP = 1.06

STAGE_E = '''
"""TEST STAND-IN for stage_e_execution (load_bars, lower_locked) - NOT the production file."""
from pathlib import Path
import numpy as np
import pandas as pd
CODE_VERSION = "stage_e_execution TEST STAND-IN"
BANDS = (0.02, 0.05, 0.10, 0.20)


class Bars:
    def __init__(self, ts, o, h, l, c, v):
        self.ts, self.o, self.h, self.l, self.c, self.v = ts, o, h, l, c, v


def load_bars(root, syms):
    out = {}
    for s in syms:
        p = Path(root) / f"{s}_daily.parquet"
        if not p.exists():
            continue
        df = pd.read_parquet(p)
        t = pd.to_datetime(df["timestamp"]).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
        out[s] = Bars(t.values.astype("datetime64[ns]"), *(df[k].to_numpy(float) for k in ("open", "high", "low",
                                                                                              "close", "volume")))
    return out


def band_down(price, prev):
    return any(abs(price - round(prev * (1 - b), 2)) <= 0.011 for b in BANDS)


def lower_locked(b, j, side):
    if j <= 0:
        return False
    prev = b.c[j - 1]
    if side == "close":
        return bool(band_down(b.c[j], prev) and b.c[j] <= b.l[j] * (1 + 1e-9))
    return bool(band_down(b.o[j], prev) and b.o[j] <= b.l[j] * (1 + 1e-9))
'''
INTRADAY = '''
"""TEST STAND-IN for intraday_cache (store, BAR_MIN, path_for) - NOT the production file."""
from pathlib import Path
CODE_VERSION = "intraday_cache TEST STAND-IN"
BAR_MIN = 3


def store(root):
    return Path(root) / "intraday_3m"


def path_for(root, sym):
    return store(root) / f"{sym}_3m.parquet"
'''
DQ = '''
"""TEST STAND-IN for data_quality._paths - NOT the production file."""
from pathlib import Path


def _paths(root, symbol):
    return (Path(root) / f"{symbol}_daily.parquet", Path(root) / f"{symbol}_daily.ok.json")
'''
SB = '''
"""TEST STAND-IN for stage_b_screen (ELIG_COL) - NOT the production file."""
ELIG_COL = "label_buyable_o1"
'''


def use_mods(root, with_sb=True):
    d = Path(root) / "_mods"
    d.mkdir(parents=True, exist_ok=True)
    mods = {"stage_e_execution": STAGE_E, "intraday_cache": INTRADAY, "data_quality": DQ}
    if with_sb:
        mods["stage_b_screen"] = SB
    for nm in ("stage_e_execution", "intraday_cache", "data_quality", "stage_b_screen"):
        (d / (nm + ".py")).unlink(missing_ok=True)
        sys.modules.pop(nm, None)
    for nm, txt in mods.items():
        (d / (nm + ".py")).write_text(textwrap.dedent(txt), encoding="utf-8")
    sys.path[:] = [x for x in sys.path if not x.endswith("_mods")]
    sys.path.insert(0, str(d))
    importlib.invalidate_caches()


def make_world(base: Path, seed: int, mode: str, n_sym=24, per_day=5, start="2019-05-01", end="2025-12-31",
               i3_from="2021-10-01", n_locks=6, SU=None):
    rng = np.random.default_rng(seed)
    rng_thin = np.random.default_rng(seed + 1000)          # its own stream: the paths stay the same
    root, data = base / "root", base / "data"
    for p in (root / "panel_oc", root / "intraday_3m", data):
        p.mkdir(parents=True, exist_ok=True)
    use_mods(root)
    cal = pd.bdate_range(start, end)
    T = len(cal)
    i3 = int(np.searchsorted(cal, pd.Timestamp(i3_from)))
    syms = ["S%03d" % i for i in range(n_sym - 1)] + ["LIQUIDBEES"]
    K = KINDS[mode]
    # the market factor (overnight + intraday), crises in planted_R
    mu_m = np.full(T, K["mu"])
    sd_m = np.full(T, 0.008)
    crisis = np.zeros(T, bool)
    for d0, n in K["crises"]:
        k = int(np.searchsorted(cal, pd.Timestamp(d0)))
        crisis[k:k + n] = True
        after = np.arange(k + n, T)                               # the market stays jumpy after a crisis, slowly
        sd_m[after] = np.maximum(sd_m[after], 0.008 + 0.032 * 0.95 ** (after - (k + n)))
        mu_m[after[sd_m[after] > 0.012]] = 0.0
    mu_m[crisis], sd_m[crisis] = -0.004, 0.04
    m_on = rng.normal(0.3 * mu_m, np.sqrt(0.3) * sd_m)
    m_id = rng.normal(0.7 * mu_m, np.sqrt(0.7) * sd_m)
    beta = rng.uniform(0.8, 1.2, n_sym)
    # idiosyncratic volatility
    if K["levels"] is not None:
        lev = np.log(rng.uniform(K["levels"][0], K["levels"][1], n_sym))
        ls = np.zeros((n_sym, T))
        ls[:, 0] = lev
        eta = rng.normal(0, 0.15, (n_sym, T))
        for t in range(1, T):
            ls[:, t] = lev + 0.97 * (ls[:, t - 1] - lev) + eta[:, t]
        sig = np.exp(ls)
    else:
        sig = np.full((n_sym, T), K["const"])
    locks = {(int(rng.integers(n_sym - 1)), int(rng.integers(i3 + 5, T - 15))) for _ in range(n_locks)}
    O, H, L, C, V = (np.zeros((n_sym, T)) for _ in range(5))
    offs = pd.to_timedelta(9 * 60 + 15 + 3 * np.arange(NB), unit="m")
    pumps = np.zeros((n_sym, T), bool)
    bad3 = {}
    for s in range(n_sym):
        prev = 100.0 * np.exp(rng.normal(0, 0.4))
        b3 = np.zeros((T - i3, NB, 5))
        for t in range(T):
            if (s, t) in locks:
                px = round(prev * 0.95, 2)
                O[s, t] = H[s, t] = L[s, t] = C[s, t] = px
                V[s, t] = 1000.0
                if t >= i3:
                    b3[t - i3, :, :4] = px
                    b3[t - i3, :, 4] = 8.0
                prev = px
                continue
            sv = sig[s, t]
            g = beta[s] * m_on[t] + rng.normal(0, np.sqrt(0.3) * sv)
            op = prev * np.exp(g)
            drift = beta[s] * m_id[t]
            stp = rng.normal(drift / (NB * SUB), np.sqrt(0.7) * sv / np.sqrt(NB * SUB), NB * SUB)
            path = op * np.exp(np.cumsum(stp))
            if K["pump"] > 0 and rng.random() < K["pump"] and t >= 2:
                k0 = int(rng.integers(5 * SUB, (NB - 20) * SUB))
                path[k0:k0 + 10 * SUB] *= PUMP
                pumps[s, t] = True
            path = path.reshape(NB, SUB)
            bc = path[:, -1]
            bo = np.r_[op, bc[:-1]]
            bh = np.maximum(bo, path.max(1))
            bl = np.minimum(bo, path.min(1))
            vb = rng.lognormal(8, 0.5, NB)
            O[s, t], H[s, t], L[s, t], C[s, t], V[s, t] = op, bh.max(), bl.min(), bc[-1], vb.sum()
            if t >= i3:
                b3[t - i3, :, 0], b3[t - i3, :, 1], b3[t - i3, :, 2], b3[t - i3, :, 3] = bo, bh, bl, bc
                b3[t - i3, :, 4] = vb
            prev = bc[-1]
        stamps = pd.DatetimeIndex(cal).tz_localize(IST)
        pd.DataFrame({"timestamp": stamps, "open": O[s], "high": H[s], "low": L[s], "close": C[s],
                      "volume": V[s]}).to_parquet(root / ("%s_daily.parquet" % syms[s]), index=False)
        # planted unusable sessions: a third of the bars gone, no 09:15 bar, an open off the daily bar
        keep = np.ones((T - i3, NB), bool)
        days_bad = rng.choice(np.arange(T - i3), 12, replace=False)
        for j, dbad in enumerate(days_bad):
            if j % 3 == 0:
                keep[dbad, rng.choice(NB, 40, replace=False)] = False
            elif j % 3 == 1:
                keep[dbad, 0] = False
            else:
                b3[dbad, 0, 0] *= 1.02
        bad3[syms[s]] = days_bad
        thin = rng_thin.choice(np.setdiff1d(np.arange(T - i3), days_bad), 20, replace=False)
        for dthin in thin:                                     # usable sessions with 5 bars missing
            keep[dthin, rng_thin.choice(np.arange(1, NB), 5, replace=False)] = False
        ts = (cal[i3:].values[:, None] + offs.values[None, :]).reshape(-1)
        stamp = pd.DatetimeIndex(ts).tz_localize(IST)
        kk = keep.ravel()
        pd.DataFrame({"timestamp": stamp[kk], "open": b3[:, :, 0].ravel()[kk], "high": b3[:, :, 1].ravel()[kk],
                      "low": b3[:, :, 2].ravel()[kk], "close": b3[:, :, 3].ravel()[kk],
                      "volume": b3[:, :, 4].ravel()[kk]}).to_parquet(root / "intraday_3m" / ("%s_3m.parquet" % syms[s]),
                                                                     index=False)
    nifty_c = 18000 * np.exp(np.cumsum(m_on + m_id))
    nifty_o = np.r_[18000, nifty_c[:-1]] * np.exp(m_on)
    hi = np.maximum(nifty_o, nifty_c) * np.exp(np.abs(rng.normal(0, 0.3 * sd_m)))
    lo = np.minimum(nifty_o, nifty_c) * np.exp(-np.abs(rng.normal(0, 0.3 * sd_m)))
    pd.DataFrame({"timestamp": pd.DatetimeIndex(cal).tz_localize(IST), "open": nifty_o, "high": hi, "low": lo,
                  "close": nifty_c, "volume": np.nan}).to_parquet(root / "NIFTY50_daily.parquet", index=False)
    # the panel: the frozen setups' inputs and the eligibility column
    X = {f: np.cumsum(rng.normal(0, 1, (n_sym, T)) * (rng.random((n_sym, T)) < 0.5), axis=1) for f in FZ}
    X["d_bb_pctb_20"] = rng.normal(0.5, 0.5, (n_sym, T))
    wk = cal.to_period("W-FRI").to_numpy()
    fow = np.r_[True, wk[1:] != wk[:-1]]
    X["w_ret_13w"] = np.cumsum(rng.normal(0, 3, (n_sym, T)) * fow[None, :] * (rng.random((n_sym, T)) < 0.5), axis=1)
    X[ELIG] = (rng.random((n_sym, T)) > 0.03).astype(float)
    P = pd.DataFrame({"symbol": np.repeat(syms, T), "timestamp": np.tile(pd.DatetimeIndex(cal).tz_localize(IST), n_sym)})
    for f, v in X.items():
        P[f] = v.ravel()
    P.to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the watchlist: D and ENS ranks 1-per_day, from 2020
    atr = np.vstack([SU.atr_simple(H[s], L[s], C[s]) for s in range(n_sym)])
    t0 = int(np.searchsorted(cal, pd.Timestamp("2020-01-01")))
    rows = []
    for t in range(t0, T - 12):
        for eng in ("D", "ENS"):
            for rk, s in enumerate(rng.choice(n_sym, per_day, replace=False), 1):
                e1 = O[s, t + 1]
                row = {"trade_id": "%s-%s-%d" % (eng, cal[t].strftime("%Y%m%d"), rk), "engine": eng, "rank": rk,
                       "symbol": syms[s], "signal_day": cal[t], "entry_day": str(cal[t + 1].date()),
                       "signal_close": C[s, t], "entry": e1, "status": "ok",
                       "net_bp": (C[s, t + 5] / e1 - 1) * 1e4 - 35, "s_atr14": atr[s, t], "pre_state": "S07"}
                for k in range(1, 11):
                    row["close_%d" % k] = C[s, t + k] / e1 - 1
                    row["overnight_%d" % k] = 0.0 if k == 1 else O[s, t + k] / C[s, t + k - 1] - 1
                rows.append(row)
    pd.DataFrame(rows).to_parquet(data / "watchlist.parquet", index=False)
    pd.DataFrame({"date": cal}).to_parquet(data / "calendar.parquet", index=False)
    return root, data, {"cal": cal, "syms": syms, "sig": sig, "i3": i3, "O": O, "H": H, "L": L, "C": C,
                        "pumps": pumps, "crisis": crisis, "locks": locks, "bad3": bad3}
