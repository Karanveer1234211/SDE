"""
vollab.py - vollab v1.0: volatility forecasts applied to the frozen tree. Stage A races seven forecasts of a stock's
5-session variance (the D1 open to the D5 close, measured with the 3-minute bars) against ATR14; stage B tests the
research report's three fixed ways a forecast could improve the tree's books: sizing (S), a probability target (T) and a
market-state switch (R).

    call C:\\Users\\karanvsi\\PyCharmMiscProject\\tradelab\\env_tradelab.bat
    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\vollab
    python tests\\test_vollab.py
    python vollab.py run --root %CACHE_DAILY_ROOT% --data C:\\QuantData\\setuplab\\WL_R1_10 --out C:\\QuantData\\vollab

Karan, 22 Nov 2026, on the research report: "Apply it to the tree" ... "Go".

STAGE A (no trading)
  Every eligible stock-day of the panel (ETFs out) from mid-2021. Target: H = RV(D1) + the sum over D2..D5 of
  (overnight return^2 + RV), the variance actually borne from the D1 open to the D5 close, RV from 15-minute returns
  built out of the 3-minute bars. The models, each scaled by its own training-window constant (kappa = mean H / f):
      M0 ATR14%^2 (today's)   M1 20-day close-to-close   M2 20-day Yang-Zhang   M3 pooled log-HAR(1,5,22) on TV
      M4 HAR-CJ (jumps apart) M5 HARQ (measurement error) M6 pooled GARCH(1,1)
  Refit at each month's start on rows whose D5 is 5+ sessions before it; judged by QLIKE (95% day-block bootstrap).
    REPLACE ATR14 = the best model's QLIKE gain over M0 has an interval above 0; else KEEP ATR14.

STAGE B (the frozen tree's books, the chosen forecast sigma5 of each pick)
  S  each entry's size x clip(rho / sigma5, 1/2, 3/2), rho keeping the average size the frozen one
  T  a +5% target when P(touch +5%) >= 0.5, else +3% when P(touch +3%) >= 0.5 (driftless touch odds from sigma5)
  R  at most 2 positions after a close where NIFTY is in a declared risk state
  S and R are ADOPTED when the daily-return variance falls against the frozen book cut to the same average exposure
  (interval under 1, Holm over S/T/R), the mean costs no more than 3 bp a day and the worst fall is no deeper; T when
  its mean gain's Holm-adjusted p <= 0.025.

Example: a pick whose forecast sigma5 is 8% gets a +5% target (a driftless stock touches +5% with odds 2(1 - Phi(5/8))
= 53%); under S it gets about 2/3 of a normal slot if the typical pick's sigma5 is 5.3%.

Writes only under --out: VOLLAB_<date>_<nnn>\\ (VOLLAB.md first) and a line per run in vollab_ledger.jsonl.
Research only: nothing in production, the paper test or the frozen tree changes.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import heapq
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
_d = os.environ.get("TRIGGERLAB_DIR") or str(HERE.parent / "triggerlab")
if _d not in sys.path:
    sys.path.insert(0, _d)
import triggerlab as TG  # noqa: E402

TL, SU, TD, TC = TG.TL, TG.SU, TG.TD, TG.TC
VERSION = "vollab v1.0"
NEEDS = {"setuplab": "setuplab v1.1", "treelab": "treelab v1.0", "triggerlab": "triggerlab v1.0",
         "tradelab": "tradelab v1.3.1"}
DECL_FILE = "VOLLAB_DECLARATION.json"
NB = 125                           # 3-minute bars a session (bar k starts 09:15 + 3k)
GRID = 5                           # 3-minute bars in a 15-minute return
NRET = NB // GRID                  # 25 fifteen-minute returns
HOLD = 5                           # the target's sessions D1..D5
UNIVERSE_FROM = "2021-07-01"
USABLE_MIN = int(math.ceil(TD.USABLE_SHARE * NB))      # 100 bars (tradelab: >= 80% of 125)
PRICE_TOL = TD.PRICE_TOL                               # 0.5%
TV5_MIN, TV22_MIN = 4, 18
CC_N, CC_MIN = 20, 18
YZ_N, YZ_MIN = 20, 18
GARCH_MIN = 250
GARCH_A, GARCH_B, GARCH_P = (0.001, 0.5), (0.0, 0.998), 0.999
GARCH_START = (0.05, 0.90)
EMBARGO = 5
MIN_TRAIN_DAYS = 250
MODELS = ("M0", "M1", "M2", "M3", "M4", "M5", "M6")
INFO_MODELS = ("M3sub", "M3raw")
WORDS = {"M0": "ATR14%^2 (today's)", "M1": "20-day close-to-close", "M2": "20-day Yang-Zhang",
         "M3": "pooled log-HAR(1,5,22) on TV", "M4": "HAR-CJ (continuous and jump apart)",
         "M5": "HARQ (weight on yesterday cut when it was measured badly)", "M6": "pooled GARCH(1,1)",
         "M3sub": "M3 on the subsampled RV", "M3raw": "M3 on the raw 3-minute RV"}
POSITIONS = 3
SPLIT = 0.5
COST = SU.COST
S_CLIP = (0.5, 1.5)
S_REF, S_REF_MIN = 250, 30
T_LEVELS = (5.0, 3.0)
T_PROB = 0.5
Z75 = 0.6744897501960817           # Phi^-1(0.75): P = 2(1 - Phi(k / sigma)) >= 0.5  <=>  sigma >= k / Z75
CAT_STOP = "off"
R_POS = 2
R_RET, R_VAR, R_PCT, R_PCT_MIN = 504, 126, 0.8, 250
NON_INF = -3.0                     # bp a day
ALPHA1 = 0.025
B_OFFSET = 5
CAL_DEC, CAL_BAND = 10, 5.0
BOOT_B, BOOT_BLOCK, BOOT_SEED = 2000, 10, 7
LOG = TL.LOG


class VLError(Exception):
    pass


def constants():
    return {"bars": NB, "grid": GRID, "hold": HOLD, "universe_from": UNIVERSE_FROM, "usable_min": USABLE_MIN,
            "price_tol": PRICE_TOL, "tv5_min": TV5_MIN, "tv22_min": TV22_MIN, "cc": [CC_N, CC_MIN],
            "yz": [YZ_N, YZ_MIN], "garch_min": GARCH_MIN, "garch_a": list(GARCH_A), "garch_b": list(GARCH_B),
            "garch_p": GARCH_P, "garch_start": list(GARCH_START), "embargo": EMBARGO, "min_train_days": MIN_TRAIN_DAYS,
            "models": list(MODELS), "info_models": list(INFO_MODELS), "positions": POSITIONS, "split": SPLIT,
            "cost_pp": COST, "s_clip": list(S_CLIP), "s_ref": [S_REF, S_REF_MIN], "t_levels": list(T_LEVELS),
            "t_prob": T_PROB, "z75": Z75, "catastrophe_stop": CAT_STOP, "r_positions": R_POS,
            "r_state": [R_RET, R_VAR, R_PCT, R_PCT_MIN], "non_inferiority_bp": NON_INF, "alpha_one_sided": ALPHA1,
            "b_offset": B_OFFSET, "calibration": [CAL_DEC, CAL_BAND], "boot": [BOOT_B, BOOT_BLOCK, BOOT_SEED]}


def load_declaration(path=None):
    p = Path(path) if path else HERE / DECL_FILE
    if not p.is_file():
        raise VLError("no declaration at %s (it ships beside vollab.py)" % p)
    doc = json.loads(p.read_text(encoding="utf-8"))
    if doc.get("sha256") != SU.frozen_hash(doc):
        raise VLError("%s was changed after it was declared (its sha256 does not match) - restore the shipped file" % p)
    if doc.get("constants") != json.loads(json.dumps(constants())):
        raise VLError("%s does not match this code's settings - restore the shipped files" % p)
    return p, doc


def guard_out(out, root):
    o = Path(out).resolve()
    for b in (Path(root).resolve(), HERE.resolve(), (HERE.parent / "bigmove_deploy").resolve(),
              Path(SU.__file__).resolve().parent, Path(TL.__file__).resolve().parent,
              Path(TG.__file__).resolve().parent, Path(TD.__file__).resolve().parent):
        if o == b or b in o.parents:
            raise VLError("--out %s is inside %s - outputs go under C:\\QuantData\\vollab" % (o, b))
    return o


def ledger(out, rec):
    with open(Path(out) / "vollab_ledger.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def elig_column(arg):
    if arg:
        return arg
    try:
        import stage_b_screen as SB
        return str(SB.ELIG_COL)
    except Exception as e:  # noqa: BLE001
        raise VLError("cannot read stage_b_screen.ELIG_COL (start with env_tradelab.bat, or pass --elig-col): %s: %s"
                      % (type(e).__name__, e))


def phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def phi_arr(z):
    from math import erf, sqrt
    v = np.vectorize(lambda x: 0.5 * (1.0 + erf(x / sqrt(2.0))) if np.isfinite(x) else np.nan, otypes=[float])
    return v(np.asarray(z, float))


def to_days(s):
    t = pd.to_datetime(pd.Series(s))
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t.dt.normalize().to_numpy().astype("datetime64[D]")


def holm(p):
    p = np.asarray(p, float)
    fin = np.flatnonzero(np.isfinite(p))
    m = len(fin)
    adj = np.full(len(p), np.nan)
    order = fin[np.argsort(p[fin], kind="mergesort")]
    run = 0.0
    for i, j in enumerate(order):
        run = max(run, min(1.0, (m - i) * p[j]))
        adj[j] = run
    return adj


# ====================================================================================================== 3-minute bars
REASONS = ("under 80% of bars", "no 09:15 bar", "missing prices", "no daily bar that day",
           "first open off the daily bar by > 0.5%", "first high off the daily bar by > 0.5%",
           "first low off the daily bar by > 0.5%")


def read_3m(path):
    """One <SYMBOL>_3m.parquet as tradelab's IntradayStore._split reads it: IST clock, bars on the 09:15 + 3k grid,
    the last of duplicated (day, slot) -> (day, slot, o, h, l, c) sorted by day and slot, or None."""
    p = Path(path)
    if not p.exists():
        return None
    try:
        df = pd.read_parquet(p, columns=["timestamp", "open", "high", "low", "close"])
    except Exception:  # noqa: BLE001
        return None
    ts = pd.to_datetime(df["timestamp"])
    if getattr(ts.dt, "tz", None) is not None:
        ts = ts.dt.tz_convert(TC.IST).dt.tz_localize(None)
    t = ts.to_numpy(dtype="datetime64[ns]")
    day = t.astype("datetime64[D]")
    mins = (t - day.astype("datetime64[ns]")).astype("timedelta64[s]").astype(np.int64) / 60.0 - TC.SESSION_START_MIN
    slot = mins / TD.BAR_MIN
    ok = (slot >= -1e-9) & (slot <= NB - 1 + 1e-9) & (np.abs(slot - np.round(slot)) < 1e-6)
    F = pd.DataFrame({"day": day[ok], "slot": np.round(slot[ok]).astype(np.int64)})
    for k, nm in (("o", "open"), ("h", "high"), ("l", "low"), ("c", "close")):
        F[k] = pd.to_numeric(df[nm], errors="coerce").to_numpy(float)[ok]
    F = F.sort_values(["day", "slot"], kind="mergesort").drop_duplicates(["day", "slot"], keep="last")
    out = {k: F[k].to_numpy() for k in ("day", "slot", "o", "h", "l", "c")}
    out["day"] = np.asarray(out["day"]).astype("datetime64[D]")
    out["slot"] = np.asarray(out["slot"]).astype(np.int64)
    return out


def judge(B, dO, dH, dL, dC, cal_pos):
    """tradelab's IntradayStore._judge for every day of B at once. dO / dH / dL / dC: the stock's daily bars on the
    calendar (NaN = no bar); cal_pos: {day: calendar index}. -> (days, usable mask, reason index (-1 usable),
    calendar index (-1 none), the stock has a daily bar that day)."""
    day = B["day"]
    days, start = np.unique(day, return_index=True)
    di = np.repeat(np.arange(len(days)), np.diff(np.r_[start, len(day)]))
    n = np.bincount(di, minlength=len(days))
    first_slot = B["slot"][start]
    fin = np.isfinite(B["o"]) & np.isfinite(B["h"]) & np.isfinite(B["l"]) & np.isfinite(B["c"])
    allfin = np.bincount(di, weights=(~fin).astype(float), minlength=len(days)) == 0
    hmax = np.full(len(days), np.nan)
    lmin = np.full(len(days), np.nan)
    np.fmax.at(hmax, di, B["h"])
    np.fmin.at(lmin, di, B["l"])
    o0 = B["o"][start]
    ci = np.array([cal_pos.get(d, -1) for d in days.tolist()], np.int64)
    has_d = (ci >= 0) & np.isfinite(dC[np.maximum(ci, 0)])
    reason = np.full(len(days), -1, np.int64)
    with np.errstate(invalid="ignore", divide="ignore"):
        def off(got, ref):
            r = np.where(has_d, ref[np.maximum(ci, 0)], np.nan)
            return ~(np.isfinite(r) & (r > 0) & (np.abs(got / r - 1) <= PRICE_TOL))
        conds = (n < USABLE_MIN, first_slot != 0, ~allfin, ~has_d, off(o0, dO), off(hmax, dH), off(lmin, dL))
    for k, c in enumerate(conds):
        reason[(reason < 0) & c] = k
    return days, reason < 0, reason, ci, has_d


def measures(B, keep_days):
    """Per usable day (keep_days, sorted): RV15, RV15sub, RV3, BV, RQ from the 126-point price path (p[0] = the 09:15
    open, p[k] = the close of bar k-1, a missing bar the last close before it)."""
    day = B["day"]
    m = np.isin(day, keep_days)
    d, sl = day[m], B["slot"][m]
    ui = np.searchsorted(keep_days, d)
    n = len(keep_days)
    P = np.full((n, NB + 1), np.nan)
    P[ui, sl + 1] = B["c"][m]
    z = sl == 0
    P[ui[z], 0] = B["o"][m][z]
    P[~(P > 0)] = np.nan
    idx = np.where(np.isfinite(P), np.arange(NB + 1)[None, :], 0)
    np.maximum.accumulate(idx, axis=1, out=idx)
    P = P[np.arange(n)[:, None], idx]
    with np.errstate(invalid="ignore", divide="ignore"):
        lp = np.log(P)
        r3 = np.diff(lp, axis=1)
        r15 = np.diff(lp[:, ::GRID], axis=1)
        out = {"RV3": (r3 ** 2).sum(1), "RV15": (r15 ** 2).sum(1),
               "BV": (np.pi / 2) * (np.abs(r15[:, 1:]) * np.abs(r15[:, :-1])).sum(1),
               "RQ": (NRET / 3.0) * (r15 ** 4).sum(1)}
        sub = np.zeros(n)
        for g in range(GRID):
            pts = sorted(set([0] + list(range(g, NB + 1, GRID)) + [NB]))
            sub += (np.diff(lp[:, pts], axis=1) ** 2).sum(1)
        out["RVsub"] = sub / GRID
    bad = ~np.isfinite(lp).all(1)
    for k in out:
        out[k][bad] = np.nan
    return out


# ====================================================================================================== stock arrays
def daily_on_cal(ds, cal):
    """A DailySeries' o / h / l / c on the calendar (NaN where the stock has no bar) and its own-bar ATR14%."""
    nc = len(cal)
    O, H, L, C, A = (np.full(nc, np.nan) for _ in range(5))
    if ds is None or not len(ds):
        return O, H, L, C, A
    d = np.asarray(ds.dates).astype("datetime64[D]")
    pos = np.searchsorted(cal, d)
    ok = pos < nc
    ok[ok] = cal[pos[ok]] == d[ok]
    o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
    atr = SU.atr_simple(h, l, c)
    O[pos[ok]], H[pos[ok]], L[pos[ok]], C[pos[ok]], A[pos[ok]] = o[ok], h[ok], l[ok], c[ok], atr[ok]
    return O, H, L, C, A


def roll(x, n, mn, how="mean"):
    s = pd.Series(x).rolling(n, min_periods=mn)
    return (s.mean() if how == "mean" else s.var(ddof=1) if how == "var" else s.count()).to_numpy(float)


def stock_arrays(O, H, L, C, A, M3, cal_idx_usable):
    """Everything a stock needs on the calendar: the daily models' raw forecasts, the HAR inputs, the target and the
    daily close-to-close log return. M3 = measures of the usable days, at calendar indices cal_idx_usable."""
    nc = len(C)
    with np.errstate(invalid="ignore", divide="ignore"):
        Cp = np.r_[np.nan, C[:-1]]
        ron = np.log(O / Cp)
        rcc = np.log(C / Cp)
        rs = np.log(H / C) * np.log(H / O) + np.log(L / C) * np.log(L / O)
        oc = np.log(C / O)
    out = {"rcc": rcc}
    out["f0"] = HOLD * A ** 2
    out["f1"] = HOLD * roll(rcc ** 2, CC_N, CC_MIN)
    v = np.isfinite(ron) & np.isfinite(oc) & np.isfinite(rs)
    on_, oc_, rs_ = (np.where(v, x, np.nan) for x in (ron, oc, rs))
    nn = roll(np.where(v, 1.0, np.nan), YZ_N, YZ_MIN, "count")
    with np.errstate(invalid="ignore", divide="ignore"):
        k = 0.34 / (1.34 + (nn + 1) / (nn - 1))
        yz = roll(on_, YZ_N, YZ_MIN, "var") + k * roll(oc_, YZ_N, YZ_MIN, "var") + (1 - k) * roll(rs_, YZ_N, YZ_MIN)
    yz[~(nn >= YZ_MIN)] = np.nan
    out["f2"] = HOLD * yz
    U = {k_: np.full(nc, np.nan) for k_ in ("RV15", "RVsub", "RV3", "BV", "RQ")}
    for k_ in U:
        U[k_][cal_idx_usable] = M3[k_]
    use3 = np.isfinite(U["RV15"]) & np.isfinite(U["RVsub"]) & np.isfinite(U["BV"]) & np.isfinite(C)
    ON = ron ** 2
    usetv = use3 & np.isfinite(ON)
    with np.errstate(invalid="ignore", divide="ignore"):
        TV = np.where(usetv, ON + U["RV15"], np.nan)
        TVs = np.where(usetv, ON + U["RVsub"], np.nan)
        TVr = np.where(usetv & np.isfinite(U["RV3"]), ON + U["RV3"], np.nan)
        CV = np.where(usetv, ON + U["BV"], np.nan)
        J = np.where(usetv, np.maximum(U["RV15"] - U["BV"], 0.0), np.nan)
        q = np.where(usetv, np.sqrt(U["RQ"]) / U["RV15"], np.nan)
        for nm, x in (("TV", TV), ("TVs", TVs), ("TVr", TVr), ("CV", CV), ("J", J)):
            out[nm + "1"] = x
            out[nm + "5"] = roll(x, 5, TV5_MIN)
            out[nm + "22"] = roll(x, 22, TV22_MIN)
        out["q"] = q
        # the target: RVsub of D1 + the sum over D2..D5 of (overnight^2 + RVsub)
        part = np.where(usetv, ON + U["RVsub"], np.nan)
        d1 = np.where(use3, U["RVsub"], np.nan)
        Hs = np.full(nc, np.nan)
        if nc > HOLD:
            acc = d1[1:nc - HOLD + 1].copy()
            for k_ in range(2, HOLD + 1):
                acc = acc + part[k_:nc - HOLD + k_]
            Hs[:nc - HOLD] = acc
    out["H"] = Hs
    out["use3"] = use3
    return out


ROWCOLS = ("H", "f0", "f1", "f2", "TV1", "TV5", "TV22", "TVs1", "TVs5", "TVs22", "TVr1", "TVr5", "TVr22",
           "CV1", "CV5", "CV22", "J1", "J5", "J22", "q")


def build_rows(mk, cal, rows_by_sym, log=LOG):
    """Stage A's rows: for each stock its universe days (calendar indices) with every model input and the target;
    the daily return matrix (calendar x stocks) for GARCH; the 3-minute counts."""
    syms = sorted(rows_by_sym)
    cal_pos = {d: i for i, d in enumerate(cal.tolist())}
    store = mk.intraday
    nc = len(cal)
    Rm = np.full((nc, len(syms)), np.nan)
    parts = {k: [] for k in ROWCOLS}
    si_l, t_l = [], []
    cnt = {"asked": 0, "with_bars": 0, "usable": 0, "reasons": {}}
    t0 = time.time()
    for i in range(0, len(syms), 200):
        mk.load([str(s) for s in syms[i:i + 200]])
    log(" stage A: daily bars of %d stocks read (%.0f s)" % (len(syms), time.time() - t0))
    for s_i, sym in enumerate(syms):
        ds = mk.series(str(sym))
        O, H, L, C, A = daily_on_cal(ds, cal)
        tt = np.asarray(rows_by_sym[sym], np.int64)
        cnt["asked"] += int(np.isfinite(C).sum())
        B = read_3m(store.path(str(sym)))
        M3, cu = {k: np.zeros(0) for k in ("RV15", "RVsub", "RV3", "BV", "RQ")}, np.zeros(0, np.int64)
        if B is not None and len(B["day"]):
            days, us, reason, ci, has_d = judge(B, O, H, L, C, cal_pos)
            cnt["with_bars"] += int(has_d.sum())
            cnt["usable"] += int(us.sum())
            for k, nm in enumerate(REASONS):
                n_ = int(((reason == k) & has_d).sum())
                if n_:
                    cnt["reasons"][nm] = cnt["reasons"].get(nm, 0) + n_
            keep = days[us]
            if len(keep):
                M3 = measures(B, keep)
                cu = ci[us]
        S = stock_arrays(O, H, L, C, A, M3, cu)
        Rm[:, s_i] = S["rcc"]
        si_l.append(np.full(len(tt), s_i, np.int64))
        t_l.append(tt)
        for k in ROWCOLS:
            parts[k].append(S[k][tt])
        if (s_i + 1) % 100 == 0:
            log(" stage A: %d of %d stocks (%.0f s)" % (s_i + 1, len(syms), time.time() - t0))
    R = {k: np.concatenate(v) if v else np.zeros(0) for k, v in parts.items()}
    R["si"] = np.concatenate(si_l) if si_l else np.zeros(0, np.int64)
    R["t"] = np.concatenate(t_l) if t_l else np.zeros(0, np.int64)
    R["syms"] = np.array(syms)
    return R, Rm, cnt


# ====================================================================================================== the models
def har_X(R, kind, qmean=0.0):
    """Regressors of the HAR models (rows x k) and the rows where every one is finite and positive where logged."""
    with np.errstate(invalid="ignore", divide="ignore"):
        if kind in ("M3", "M3sub", "M3raw"):
            p = {"M3": "TV", "M3sub": "TVs", "M3raw": "TVr"}[kind]
            X = np.column_stack([np.ones(len(R["t"])), np.log(R[p + "1"]), np.log(R[p + "5"]), np.log(R[p + "22"])])
        elif kind == "M4":
            cols = [np.ones(len(R["t"]))]
            for h in ("1", "5", "22"):
                cols.append(np.log(R["CV" + h]))
            for h in ("1", "5", "22"):
                cols.append(np.log1p(R["J" + h] / R["CV" + h]))
            X = np.column_stack(cols)
        elif kind == "M5":
            l1 = np.log(R["TV1"])
            X = np.column_stack([np.ones(len(R["t"])), l1, (R["q"] - qmean) * l1, np.log(R["TV5"]),
                                 np.log(R["TV22"])])
        else:
            raise VLError("no HAR model %s" % kind)
    return X, np.isfinite(X).all(1)


def garch_filter(R2, valid, v, a, b):
    """sigma2(t+1 | t) for every calendar day t (rows) and stock (columns): starts at v, w = v (1 - a - b), a missing
    return carries w + (a + b) sigma2."""
    nc, ns = R2.shape
    w = v * (1.0 - a - b)
    s2 = v.copy()
    out = np.empty((nc, ns))
    for t in range(nc):
        s2 = w + a * np.where(valid[t], R2[t], s2) + b * s2
        out[t] = s2
    return out


def garch_negll(params, R2, valid, v, use):
    a, b = params
    if not (GARCH_A[0] <= a <= GARCH_A[1] and GARCH_B[0] <= b <= GARCH_B[1] and a + b <= GARCH_P):
        return 1e300
    w = v * (1.0 - a - b)
    s2 = v.copy()
    tot = 0.0
    with np.errstate(invalid="ignore", divide="ignore"):
        for t in range(R2.shape[0]):
            m = valid[t] & use
            tot += float(np.sum(np.where(m, np.log(s2) + R2[t] / s2, 0.0)))
            s2 = w + a * np.where(valid[t], R2[t], s2) + b * s2
    return 0.5 * tot


def garch_fit(Rm, c, start):
    """(a, b) maximising the pooled Gaussian likelihood of returns up to calendar index c (stocks with GARCH_MIN
    returns there); the variance targets v (NaN for a stock without them)."""
    from scipy.optimize import minimize
    X = Rm[:c + 1]
    valid = np.isfinite(X)
    R2 = np.where(valid, X ** 2, 0.0)
    nv = valid.sum(0)
    with np.errstate(invalid="ignore", divide="ignore"):
        v = np.where(nv >= GARCH_MIN, R2.sum(0) / np.maximum(nv, 1), np.nan)
    use = np.isfinite(v) & (v > 0)
    vv = np.where(use, v, 1.0)
    if not use.any():
        return np.array(start, float), v, 0
    res = minimize(garch_negll, np.array(start, float), args=(R2, valid, vv, use), method="Nelder-Mead",
                   options={"xatol": 1e-4, "fatol": 1e-3, "maxiter": 400})
    ab = np.array(res.x, float)
    if garch_negll(ab, R2, valid, vv, use) >= 1e299:
        ab = np.array(start, float)
    return ab, np.where(use, v, np.nan), int(res.nfev)


def garch_forecast(Rm, upto, ab, v):
    """The 5-session forecast at every calendar day 0..upto for every stock: sum over k of v + p^(k-1)(s2 - v)."""
    a, b = ab
    X = Rm[:upto + 1]
    valid = np.isfinite(X)
    R2 = np.where(valid, X ** 2, 0.0)
    vv = np.where(np.isfinite(v), v, 1.0)
    S2 = garch_filter(R2, valid, vv, a, b)
    p = a + b
    geo = HOLD if abs(1 - p) < 1e-12 else (1 - p ** HOLD) / (1 - p)
    F = HOLD * vv[None, :] + (S2 - vv[None, :]) * geo
    F[:, ~np.isfinite(v)] = np.nan
    return F


class WalkForward:
    """Stage A's monthly refits: every model's calibrated forecast for every row of every test month."""

    def __init__(self, R, Rm, cal, log=LOG):
        self.R, self.Rm, self.cal, self.log = R, Rm, cal, log
        n = len(R["t"])
        self.n = n
        self.mon = cal.astype("datetime64[M]").astype(np.int64)
        self.row_mon = self.mon[R["t"]]
        self.d5 = R["t"] + HOLD
        self.H = R["H"]
        self.Xs = {k: har_X(R, k) for k in ("M3", "M4", "M3sub", "M3raw")}
        X5, ok5 = har_X(R, "M5")
        self.ok5 = ok5
        okd = {}
        for j, f in enumerate(("f0", "f1", "f2")):
            okd["M%d" % j] = np.isfinite(R[f]) & (R[f] > 0)
        self.okd = okd
        self.has_H = np.isfinite(self.H) & (self.H > 0)
        self.E = self.has_H & okd["M0"] & okd["M1"] & okd["M2"] & self.Xs["M3"][1] & self.Xs["M4"][1] & ok5
        self.F = {m: np.full(n, np.nan) for m in MODELS + INFO_MODELS}
        self.fits = []

    def cutoff(self, M):
        f = int(np.searchsorted(self.mon, M))
        return f, f - 1 - EMBARGO

    def months(self):
        Ms = np.unique(self.row_mon)
        out = []
        for M in Ms:
            f, c = self.cutoff(M)
            if c < 0:
                continue
            tr = self.E & (self.d5 <= c)
            if len(np.unique(self.R["t"][tr])) >= MIN_TRAIN_DAYS:
                out.append(int(M))
        if not out:
            return []
        return [int(M) for M in Ms if M >= out[0]]

    def run(self, months, garch_on=True):
        R, E, H = self.R, self.E, self.H
        ab = np.array(GARCH_START, float)
        t0 = time.time()
        for i, M in enumerate(months):
            f, c = self.cutoff(M)
            tr = E & (self.d5 <= c)
            te = self.row_mon == M
            last = int(np.flatnonzero(self.mon == M)[-1])
            rec = {"month": str(np.datetime64(int(M), "M")), "cutoff": str(self.cal[c]), "train_rows": int(tr.sum()),
                   "train_days": int(len(np.unique(R["t"][tr]))), "test_rows": int(te.sum())}
            # the daily models
            for j in range(3):
                m = "M%d" % j
                raw = R["f%d" % j]
                k_ = float(np.mean(H[tr] / raw[tr]))
                ok = te & self.okd[m]
                self.F[m][ok] = k_ * raw[ok]
                rec["kappa_" + m] = k_
            # the HAR family
            for m in ("M3", "M4", "M5", "M3sub", "M3raw"):
                if m == "M5":
                    qm = float(np.mean(R["q"][tr]))
                    X, okx = har_X(R, "M5", qm)
                    rec["qmean"] = qm
                else:
                    X, okx = self.Xs[m]
                trm = tr & okx
                if trm.sum() < X.shape[1] + 10:
                    continue
                b = np.linalg.lstsq(X[trm], np.log(H[trm]), rcond=None)[0]
                fit_tr = np.exp(X[tr & okx] @ b)
                k_ = float(np.mean(H[tr & okx] / fit_tr))
                ok = te & okx
                self.F[m][ok] = k_ * np.exp(X[ok] @ b)
                rec["coef_" + m] = [float(x) for x in b]
                rec["kappa_" + m] = k_
            # GARCH
            if garch_on:
                ab, v, nfev = garch_fit(self.Rm, c, ab)
                Fg = garch_forecast(self.Rm, last, ab, v)
                raw_tr = Fg[R["t"][tr], R["si"][tr]]
                okt = np.isfinite(raw_tr) & (raw_tr > 0)
                k_ = float(np.mean(H[tr][okt] / raw_tr[okt])) if okt.any() else np.nan
                idx = np.flatnonzero(te)
                raw = Fg[R["t"][idx], R["si"][idx]]
                good = np.isfinite(raw) & (raw > 0)
                self.F["M6"][idx[good]] = k_ * raw[good]
                rec.update({"garch_a": float(ab[0]), "garch_b": float(ab[1]), "garch_evals": nfev, "kappa_M6": k_})
            self.fits.append(rec)
            self.log(" stage A refit %s: %d training rows (%d days), %d rows to forecast; GARCH a %.3f b %.3f "
                     "(%.0f s)" % (rec["month"], rec["train_rows"], rec["train_days"], rec["test_rows"],
                                   rec.get("garch_a", np.nan), rec.get("garch_b", np.nan), time.time() - t0))
        return self.F


# ====================================================================================================== stage A judged
def qlike(H, F):
    with np.errstate(invalid="ignore", divide="ignore"):
        r = H / F
        return r - np.log(r) - 1.0


def boot_mean(B_, di, x):
    n = B_.M.shape[1]
    s = np.bincount(di, weights=x, minlength=n)
    c = np.bincount(di, minlength=n).astype(float)
    S, Cn = B_.M @ s, B_.M @ c
    with np.errstate(invalid="ignore", divide="ignore"):
        m = S / np.where(Cn > 0, Cn, np.nan)
    est = float(s.sum() / c.sum()) if c.sum() > 0 else np.nan
    if not np.isfinite(m).any():
        return est, np.nan, np.nan, np.nan
    lo, hi = np.nanpercentile(m, [2.5, 97.5])
    return est, float(lo), float(hi), float(np.nanstd(m, ddof=1))


def boot_ols(B_, di, y, X):
    n = B_.M.shape[1]
    k = X.shape[1]
    XX = np.zeros((n, k * k))
    Xy = np.zeros((n, k))
    np.add.at(XX, di, (X[:, :, None] * X[:, None, :]).reshape(len(y), k * k))
    np.add.at(Xy, di, X * y[:, None])
    beta = np.linalg.lstsq(XX.sum(0).reshape(k, k), Xy.sum(0), rcond=None)[0]
    A = (B_.M @ XX).reshape(-1, k, k)
    b = B_.M @ Xy
    try:
        betas = np.linalg.solve(A, b[..., None])[..., 0]
    except np.linalg.LinAlgError:
        betas = np.stack([np.linalg.lstsq(A[i], b[i], rcond=None)[0] for i in range(len(A))])
    return beta, betas


def race_table(H, F, t, cal, names, base="M0"):
    """Every model on the rows given: mean QLIKE with its interval, the gain over `base`, MSE, Mincer-Zarnowitz."""
    days, di = np.unique(t, return_inverse=True)
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    Q = {m: qlike(H, F[m]) for m in names}
    rows = []
    Hp = H * 1e4
    for m in names:
        q = Q[m]
        est, lo, hi, _ = boot_mean(B_, di, q)
        g, glo, ghi, gsd = boot_mean(B_, di, Q[base] - q) if m != base else (0.0, 0.0, 0.0, 0.0)
        Fp = F[m] * 1e4
        beta, betas = boot_ols(B_, di, Hp, np.column_stack([np.ones(len(Hp)), Fp]))
        blo, bhi = np.percentile(betas[:, 1], [2.5, 97.5])
        row = {"model": m, "what": WORDS[m], "rows": int(len(H)), "days": int(len(days)), "qlike": est,
               "qlike_lo": lo, "qlike_hi": hi, "gain_vs_" + base: g, "gain_lo": glo, "gain_hi": ghi,
               "mse": float(np.mean((Hp - Fp) ** 2)), "mz_a": float(beta[0]), "mz_b": float(beta[1]),
               "mz_b_lo": float(blo), "mz_b_hi": float(bhi), "mean_H_pct2": float(Hp.mean()),
               "mean_F_pct2": float(Fp.mean())}
        yrs = pd.DatetimeIndex(cal[t]).year
        for y in sorted(set(yrs)):
            row["qlike_%d" % y] = float(np.mean(q[yrs == y]))
        rows.append(row)
    return rows


def decide_A(rows):
    T = {r["model"]: r for r in rows}
    cand = [m for m in MODELS[1:] if m in T and np.isfinite(T[m]["qlike"])]
    best = min(cand, key=lambda m: (T[m]["qlike"], MODELS.index(m))) if cand else None
    rep = bool(best is not None and np.isfinite(T[best]["gain_lo"]) and T[best]["gain_lo"] > 0)
    return {"verdict": "REPLACE ATR14 with %s" % best if rep else "KEEP ATR14", "best": best,
            "chosen": best if rep else "M0", "replace": rep}


# ====================================================================================================== stage B
class _NoBars:
    def sessions(self, sym, days, ds):
        return {}


class _DailyOnly:
    """tradelab's Market for triggerlab's load_paths without its 3-minute part: stage B reads daily bars only."""

    def __init__(self, mk):
        self.mk = mk
        self.intraday = _NoBars()

    def series(self, sym):
        return self.mk.series(sym)


def book_sim2(T, C, s0, t1, k=POSITIONS, mult=None, cap=None):
    """triggerlab's book_sim with a size multiplier per trade (mult) and a cap on open positions per entry session
    (cap[calendar index]); each entry 1/k of the closed value x its multiplier. -> (closed, marked, taken, sizes,
    exposure at each close)."""
    ent, ex, net = T["ent"], T["ex"], T["net"]
    key = ex - 0.5 * T["oexit"]
    keep = np.flatnonzero((ent >= s0) & (ent <= t1))
    nd = t1 - s0 + 1
    sizes = np.zeros(len(ent))
    taken = np.zeros(len(ent), bool)
    heap, realized = [], 0.0
    for j in keep:
        t = ent[j]
        while heap and heap[0][0] < t:
            _, jj = heapq.heappop(heap)
            realized += sizes[jj] * net[jj] / 100
        kk = k if cap is None else int(cap[t])
        if len(heap) < kk:
            size = (1.0 + realized) / k
            if mult is not None:
                size *= mult[j]
            if size > 0:
                sizes[j] = size
                taken[j] = True
                heapq.heappush(heap, (key[j], j))
    tk = np.flatnonzero(taken)
    exd = ex[tk] - s0
    inside = exd <= nd - 1
    pnl = sizes[tk][inside] * net[tk][inside] / 100
    eqc = 1.0 + np.cumsum(np.bincount(exd[inside], weights=pnl, minlength=nd)[:nd])
    eqm = eqc.copy()
    expo = np.zeros(nd)
    lens = np.minimum(ex[tk], t1 + 1) - ent[tk]
    has = lens > 0
    if has.any():
        tk2, L = tk[has], lens[has]
        rep = np.repeat(np.arange(len(tk2)), L)
        off = np.arange(L.sum()) - np.repeat(np.cumsum(L) - L, L)
        t = ent[tk2][rep] + off
        uu = T["u"][tk2][rep]
        kk = t - T["i1"][tk2][rep] + 1
        pin = T["p0"][tk2][rep]
        okk = (kk >= 1) & (kk <= C.shape[1] - 1)
        c_ = np.where(okk, C[uu, np.clip(kk, 1, C.shape[1] - 1)], np.nan)
        with np.errstate(invalid="ignore", divide="ignore"):
            good = np.isfinite(c_) & np.isfinite(pin) & (pin > 0)
            val = np.where(good, sizes[tk2][rep] * (c_ / pin - 1), 0.0)
        np.add.at(eqm, t - s0, val)
        np.add.at(expo, t - s0, sizes[tk2][rep])
    with np.errstate(invalid="ignore", divide="ignore"):
        expo = np.where(eqc > 0, expo / eqc, 0.0)
    return np.maximum(eqc, 0.0), np.maximum(eqm, 0.0), taken, sizes, expo


def account_returns(vD, vE, cal, p0, t1, w=SPLIT):
    """Daily returns of an account w : 1-w between two books (marked values at the closes p0..t1, each 1.0 before
    p0), the split restarted at each 1 January (treelab's year_returns)."""
    vD = np.r_[1.0, np.asarray(vD, float)]
    vE = np.r_[1.0, np.asarray(vE, float)]
    yrs = pd.DatetimeIndex(cal[p0:t1 + 1]).year.to_numpy()
    out = np.zeros(t1 - p0 + 1)
    starts = np.r_[0, np.flatnonzero(yrs[1:] != yrs[:-1]) + 1]
    ends = np.r_[starts[1:], len(yrs)]
    for a, b in zip(starts, ends):
        def rel(v):
            seg = v[a: b + 1]
            return seg / seg[0] if seg[0] > 0 else np.ones(len(seg))
        v = w * rel(vD) + (1 - w) * rel(vE)
        with np.errstate(invalid="ignore", divide="ignore"):
            out[a:b] = np.where(v[:-1] > 0, v[1:] / v[:-1] - 1, 0.0)
    return out


def s_multipliers(T, sig, ref=S_REF, ref_min=S_REF_MIN):
    """S: x clip(rho / sigma5, 1/2, 3/2) per trade, rho making the mean multiplier 1 over the same engine's trades
    with a sigma5 entered in the `ref` sessions before (at least ref_min; fewer, or no sigma5: 1)."""
    m = np.ones(len(T["ent"]))
    rho_out = np.full(len(T["ent"]), np.nan)
    for e in np.unique(T["eng"]):
        idx = np.flatnonzero(T["eng"] == e)
        ent = T["ent"][idx]
        s = sig[idx]
        has = np.isfinite(s) & (s > 0)
        cache = {}
        for jj, j in enumerate(idx):
            t = int(ent[jj])
            if t not in cache:
                ref_m = has & (ent >= t - ref) & (ent < t)
                r = s[ref_m]
                cache[t] = solve_rho(r) if len(r) >= ref_min else np.nan
            rho = cache[t]
            rho_out[j] = rho
            if np.isfinite(rho) and has[jj]:
                m[j] = float(np.clip(rho / s[jj], S_CLIP[0], S_CLIP[1]))
    return m, rho_out


def solve_rho(r):
    """rho with mean clip(rho / r, lo, hi) = 1 (bisection; the mean rises with rho from lo to hi)."""
    lo_, hi_ = S_CLIP
    a, b = lo_ * float(np.min(r)), hi_ * float(np.max(r))
    for _ in range(100):
        mid = 0.5 * (a + b)
        if np.mean(np.clip(mid / r, lo_, hi_)) < 1.0:
            a = mid
        else:
            b = mid
    return 0.5 * (a + b)


def t_levels(sig):
    """T's target (percent) per trade: 5 when sigma5 >= 5 / Z75, else 3 when sigma5 >= 3 / Z75, else NaN."""
    lvl = np.full(len(sig), np.nan)
    with np.errstate(invalid="ignore"):
        for k in sorted(T_LEVELS):
            lvl[sig * 100 >= k / Z75] = k
    return lvl


def t_trades(T, PA, lvl, primary):
    """The frozen trades with T's targets: from the entry day to the frozen exit's day, an entry-day high at the level
    sells at the level; later an open at or above it sells at the open, else a high at or above it at the level."""
    T2 = {k: v.copy() for k, v in T.items()}
    n = len(T["ent"])
    hit = np.zeros(n, bool)
    how = T["g"]
    x_plan = np.array([d_ + 4 if primary.get(str(g_).split(":", 1)[-1]) == "fresh" else 5
                       for d_, g_ in zip(T["d"], how)], np.int64)
    u, d, p0 = T["u"], T["d"], T["p0"]
    has = np.isfinite(lvl)
    L = p0 * (1 + np.where(has, lvl, 0.0) / 100.0)
    done = ~has
    xp = np.full(n, np.nan)
    xk = np.full(n, -1, np.int64)
    for off in range(0, TG.LAST_D):
        j = d + off
        live = ~done & (j <= x_plan)
        if not live.any():
            break
        jj = np.clip(j, 0, PA.O.shape[1] - 1)
        o = PA.O[u, jj]
        h = PA.H[u, jj]
        with np.errstate(invalid="ignore"):
            gap = live & (off > 0) & (o >= L)
            touch = live & ~gap & (h >= L)
        xp[gap], xk[gap] = o[gap], j[gap]
        xp[touch], xk[touch] = L[touch], j[touch]
        newly = gap | touch
        hit |= newly
        done |= newly
    with np.errstate(invalid="ignore", divide="ignore"):
        T2["net"] = np.where(hit, (xp / p0 - 1) * 100 - COST, T["net"])
    T2["ex"] = np.where(hit, T["i1"] + xk - 1, T["ex"])
    T2["oexit"] = np.where(hit, False, T["oexit"])
    T2["t_hit"] = hit
    T2["t_level"] = lvl
    return T2


def r_cap(flag_bk):
    """R's cap on open positions for an entry at each session's open: 2 after a flagged close, else 3."""
    return np.where(np.r_[False, np.asarray(flag_bk, bool)[:-1]], R_POS, POSITIONS)


def decide_B(rows, fz):
    """Holm over S (matched variance ratio < 1), T (mean > 0) and R (matched variance ratio < 1), then the declared
    rule. rows: {variant: its numbers (p_var, p_mean, diff_lo, fall)}; fz: the frozen book's numbers."""
    keys = ["S", "T", "R"]
    adj = holm([rows[k]["p_mean"] if k == "T" else rows[k]["p_var"] for k in keys])
    for k, pa in zip(keys, adj):
        row = rows[k]
        row["p_holm"] = float(pa)
        if k == "T":
            ok = bool(np.isfinite(pa) and pa <= ALPHA1)
        else:
            ok = bool(np.isfinite(pa) and pa <= ALPHA1 and np.isfinite(row["diff_lo"]) and row["diff_lo"] > NON_INF
                      and row["fall"] <= fz["fall"])
        row["verdict"] = "ADOPTED" if ok else "NOT ADOPTED"
    return rows


def nifty_state(ds, cal):
    """R's flag at each calendar close from NIFTY50's daily bars; also its parts (A: bear and volatile, B: the HAR
    forecast high)."""
    O, H, L, C, _ = daily_on_cal(ds, cal)
    nc = len(cal)
    with np.errstate(invalid="ignore", divide="ignore"):
        Cp = np.r_[np.nan, C[:-1]]
        lr = np.log(C / Cp)
        ron = np.log(O / Cp)
        gk = 0.5 * np.log(H / L) ** 2 - (2 * np.log(2) - 1) * np.log(C / O) ** 2
    v126 = pd.Series(lr ** 2).rolling(R_VAR, min_periods=R_VAR).mean()
    pv = v126.expanding(min_periods=R_PCT_MIN).quantile(R_PCT).shift(1).to_numpy(float)
    ret = np.full(nc, np.nan)
    with np.errstate(invalid="ignore", divide="ignore"):
        ret[R_RET:] = np.log(C[R_RET:] / C[:-R_RET])
    v126 = v126.to_numpy(float)
    with np.errstate(invalid="ignore"):
        A = (ret < 0) & (v126 > pv)
    TV = ron ** 2 + gk
    TV5 = pd.Series(TV).rolling(5, min_periods=5).mean().to_numpy(float)
    TV22 = pd.Series(TV).rolling(22, min_periods=22).mean().to_numpy(float)
    Hn = np.full(nc, np.nan)
    acc = np.zeros(nc - HOLD)
    for k in range(1, HOLD + 1):
        acc = acc + TV[k:nc - HOLD + k]
    Hn[:nc - HOLD] = acc
    with np.errstate(invalid="ignore", divide="ignore"):
        X = np.column_stack([np.ones(nc), np.log(TV), np.log(TV5), np.log(TV22)])
        y = np.log(Hn)
    okx = np.isfinite(X).all(1)
    oky = okx & np.isfinite(y)
    mon = cal.astype("datetime64[M]").astype(np.int64)
    Fh = np.full(nc, np.nan)
    started = False
    for M in np.unique(mon):
        f = int(np.searchsorted(mon, M))
        c = f - 1 - EMBARGO
        if c < 0:
            continue
        tr = oky & (np.arange(nc) + HOLD <= c)
        if not started and tr.sum() < MIN_TRAIN_DAYS:
            continue
        started = True
        b = np.linalg.lstsq(X[tr], y[tr], rcond=None)[0]
        te = (mon == M) & okx
        Fh[te] = np.exp(X[te] @ b)
    pf = pd.Series(Fh).expanding(min_periods=R_PCT_MIN).quantile(R_PCT).shift(1).to_numpy(float)
    with np.errstate(invalid="ignore"):
        B = Fh > pf
    return A | B, A, B, Fh, pv, pf


def variance_test(B_, rv, rf, c=1.0):
    """The variance ratio at matched exposure, var(rv) / var(c x rf) (c = the variant's mean gross exposure / the
    frozen book's), its 95% interval from the same day draws and the one-sided p of ratio < 1."""
    n = len(rv)
    M = B_.M

    def bvar(r):
        S1, S2 = M @ r, M @ (r * r)
        return (S2 - S1 * S1 / n) / (n - 1)
    vf = float(np.var(rf, ddof=1))
    if not (vf > 0 and c > 0):
        return np.nan, np.nan, np.nan, np.nan
    vr = float(np.var(rv, ddof=1) / (c * c * vf))
    with np.errstate(invalid="ignore", divide="ignore"):
        st = bvar(rv) / (c * c * bvar(rf))
    lo, hi = np.nanpercentile(st, [2.5, 97.5])
    sd = float(np.nanstd(np.log(st), ddof=1))
    p = (1.0 - phi(-math.log(vr) / sd)) if (sd > 0 and vr > 0) else np.nan
    return vr, float(lo), float(hi), p


def path_numbers(r, cal_days):
    v = np.r_[1.0, np.cumprod(1 + r)]
    yrs = float((cal_days[-1] - cal_days[0]) / np.timedelta64(1, "D")) / 365.25 if len(cal_days) > 1 else 0
    ay = (v[-1] ** (1 / yrs) - 1) * 100 if (v[-1] > 0 and yrs > 0) else np.nan
    q = np.sort(r)
    k = max(1, int(math.ceil(0.05 * len(q))))
    return {"a_year": float(ay), "fall": TL.worst_fall_of(v), "cvar5": float(100 * q[:k].mean()),
            "sd_daily": float(100 * np.std(r, ddof=1))}


def touch_table(sig, O1, Hmax, levels=(3.0, 5.0)):
    rows = []
    for k in levels:
        with np.errstate(invalid="ignore", divide="ignore"):
            P = 2 * (1 - phi_arr(k / (sig * 100)))
            hit = Hmax >= O1 * (1 + k / 100)
        ok = np.isfinite(P) & np.isfinite(Hmax) & np.isfinite(O1)
        if ok.sum() < CAL_DEC:
            continue
        P, hit = P[ok], hit[ok].astype(float)
        q = pd.qcut(pd.Series(P), CAL_DEC, labels=False, duplicates="drop").to_numpy()
        for g in np.unique(q):
            m = q == g
            pr, re = 100 * P[m].mean(), 100 * hit[m].mean()
            rows.append({"level_pct": k, "decile": int(g) + 1, "picks": int(m.sum()), "predicted_pct": pr,
                         "reached_pct": re, "diff_points": re - pr, "within_band": bool(abs(re - pr) <= CAL_BAND)})
    return rows


# ====================================================================================================== report
def _p(x, nd=2, sign=True):
    if x is None or not np.isfinite(x):
        return "n/a"
    return ("%+.*f" if sign else "%.*f") % (nd, x)


def _ci(lo, hi, nd=2):
    if lo is None or hi is None or not (np.isfinite(lo) and np.isfinite(hi)):
        return "[n/a]"
    return "[%+.*f, %+.*f]" % (nd, lo, nd, hi)


def write_report(d, info, res):
    A, B = res["A"], res["B"]
    L = ["# vollab v1.0 - volatility forecasts on the frozen tree", "",
         "Run %s, %s. Declaration %s." % (d.name, info["made"], info["declaration_sha256"][:16]), "",
         "## The verdicts", "",
         "**Stage A: %s.** Best challenger %s (%s): mean QLIKE gain over ATR14 %s %s on %d stock-days (%d test days, "
         "%s .. %s); REPLACE needs the interval above 0." % (
             A["decision"]["verdict"], A["decision"]["best"], WORDS.get(A["decision"]["best"], ""),
             _p(A["best_row"]["gain_vs_M0"], 4), _ci(A["best_row"]["gain_lo"], A["best_row"]["gain_hi"], 4),
             A["best_row"]["rows"], A["best_row"]["days"], A["from"], A["to"]), ""]
    if B:
        L.append("**Stage B** (forecast %s, %s .. %s, %d days):" % (B["chosen"], B["from"], B["to"], B["days"]))
        L.append("")
        for v in ("S", "T", "R"):
            r = B["variants"][v]
            L.append("- %s: **%s** - mean %s bp a day %s; variance ratio at matched exposure %.3f %s (raw %.3f, "
                     "exposure x%.3f); Holm p %s; worst fall %.1f%% vs %.1f%%." % (
                         v, r["verdict"], _p(r["diff"]), _ci(r["diff_lo"], r["diff_hi"]), r["vr"],
                         _ci(r["vr_lo"], r["vr_hi"], 3), r["vr_raw"], r["exposure_ratio"], _p(r["p_holm"], 4, False),
                         r["fall"], B["frozen"]["fall"]))
        L.append("")
    L += ["What the verdicts mean (declared): stage A only chooses stage B's forecast; the tree's ATR cut-off does not "
          "change. An ADOPTED mapping is a candidate for a forward paper shadow book beside the frozen tree, judged at "
          "its own month 6 and month 12; NOT ADOPTED ones may stay as shadow books for the ledger's calibration. "
          "Nothing is re-run with other settings.", ""]
    L += ["## Stage A - the forecast race (every eligible stock-day, test months)", "",
          "| model | what | QLIKE | 95% | gain vs ATR14 | 95% | MSE (%%^2)^2 | MZ a | MZ b | 95% |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in A["universe"]:
        L.append("| %s | %s | %.4f | %s | %s | %s | %.3g | %.3g | %.3f | %s |" % (
            r["model"], r["what"], r["qlike"], _ci(r["qlike_lo"], r["qlike_hi"], 4), _p(r["gain_vs_M0"], 4),
            _ci(r["gain_lo"], r["gain_hi"], 4), r["mse"], r["mz_a"], r["mz_b"], _ci(r["mz_b_lo"], r["mz_b_hi"], 3)))
    if A["picks"]:
        L += ["", "On the tree's picks (D and ENS ranks 1-3; shown):", "",
              "| model | rows | QLIKE | gain vs ATR14 | 95% | MZ b |", "|---|---|---|---|---|---|"]
        for r in A["picks"]:
            L.append("| %s | %d | %.4f | %s | %s | %.3f |" % (r["model"], r["rows"], r["qlike"], _p(r["gain_vs_M0"], 4),
                                                            _ci(r["gain_lo"], r["gain_hi"], 4), r["mz_b"]))
    if A["info"]:
        L += ["", "The RV measure behind M3 (shown): gain over M3 (positive = better than RV15):", ""]
        for r in A["info"]:
            if r["model"] != "M3":
                L.append("- %s: %s %s" % (r["model"], _p(r["gain_vs_M3"], 4), _ci(r["gain_lo"], r["gain_hi"], 4)))
    if B:
        L += ["", "## Stage B - the books (account D and ENS 50/50)", "",
              "| book | a year | worst fall | 5% CVaR (daily) | sd (daily) | mean exposure | trades |",
              "|---|---|---|---|---|---|---|"]
        for nm, r in [("frozen", B["frozen"])] + [(k, B["variants"][k]) for k in ("S", "T", "R", "STR")]:
            L.append("| %s | %s%% | %.1f%% | %.2f%% | %.2f%% | %.2f | %d |" % (
                nm, _p(r["a_year"], 1), r["fall"], r["cvar5"], r["sd_daily"], r["exposure"], r["trades"]))
        L += ["", "T: %d of %d trades got a target, %d reached it. S: multipliers %s. R: %.1f%% of the period's "
              "closes flagged." % (B["t_set"], B["t_trades"], B["t_hit"], B["s_mult"], B["r_flagged_pct"]), ""]
        if B["touch"]:
            L += ["Touch calibration (shown; the ledger's band is +/-5 points per decile):", "",
                  "| level | decile | picks | predicted | reached | within 5 |", "|---|---|---|---|---|---|"]
            for r in B["touch"]:
                L.append("| +%.0f%% | %d | %d | %.1f%% | %.1f%% | %s |" % (r["level_pct"], r["decile"], r["picks"],
                                                                        r["predicted_pct"], r["reached_pct"],
                                                                        "yes" if r["within_band"] else "no"))
    L += ["", "## Checks", ""] + ["- %s: %s" % (k, v) for k, v in info["checks"].items()]
    (d / "VOLLAB.md").write_text("\n".join(L) + "\n", encoding="utf-8")


# ====================================================================================================== run
def resolve_inputs(a):
    root = Path(a.root)
    panel = Path(a.panel) if a.panel else root / "panel_oc" / "panel.parquet"
    if not panel.is_file():
        raise VLError("panel not found: %s" % panel)
    return root, panel


def read_universe(panel, elig, root, cal):
    """Stage A's universe: eligible, not ETFs, from UNIVERSE_FROM, on the calendar -> {symbol: calendar indices}."""
    import pyarrow.parquet as pq
    names = pq.read_schema(panel).names
    low = {c.lower(): c for c in names}
    dk = low.get("timestamp") or low.get("date")
    if "symbol" not in low or not dk:
        raise VLError("the panel needs symbol and timestamp columns")
    if elig.lower() not in low:
        raise VLError("the panel has no eligibility column %s" % elig)
    T = pq.read_table(panel, columns=[low["symbol"], dk, low[elig.lower()]]).to_pandas()
    day = to_days(T[dk])
    sym = T[low["symbol"]].astype(str).str.strip().str.upper().to_numpy()
    el = pd.to_numeric(T[low[elig.lower()]], errors="coerce").to_numpy(float)
    m = (el == 1) & (day >= np.datetime64(UNIVERSE_FROM))
    day, sym = day[m], sym[m]
    _, tdoc = SU.load_tree()
    us = np.unique(sym)
    etf_u = SU.tree_etf(us, tdoc, SU.etf_list(root))
    etf = etf_u[np.searchsorted(us, sym)] if len(sym) else np.zeros(0, bool)
    day, sym = day[~etf], sym[~etf]
    pos = np.searchsorted(cal, day)
    ok = pos < len(cal)
    ok[ok] = cal[pos[ok]] == day[ok]
    out = {}
    for s, t in zip(sym[ok], pos[ok]):
        out.setdefault(s, []).append(int(t))
    return {s: sorted(set(v)) for s, v in out.items()}, int((~ok).sum()), int(etf.sum())


def tree_setup(a, root, panel, log):
    """triggerlab's preparation up to the frozen trades: the book, the frozen tree's gate, the picks and their daily
    bars (honest sale)."""
    _, fdoc = SU.load_frozen()
    _, tdoc = SU.load_tree()
    import pyarrow.parquet as pq
    have = {c.lower() for c in pq.read_schema(panel).names}
    fconds = SU.frozen_conds(fdoc)
    ffeats = [f.lower() for f in SU.frozen_features(fdoc)]
    need = [f for f in ffeats if f not in have]
    if need:
        raise VLError("the panel lacks: %s" % ", ".join(need))
    primary = {s["id"]: s["primary_exit"] for s in fdoc["setups"]}
    order = [s for s in SU.TREE_ORDER if s in fconds]
    if tuple(order) != TG.SETUPS:
        raise VLError("expected the seven frozen setups %s, found %s" % (list(TG.SETUPS), order))
    bk, miss = TL.load_book(a.data, panel, list(dict.fromkeys(ffeats)), log)
    fills = TL.replays(bk, fconds, primary)
    cuts = {q: TL.cutoffs(bk, v, tdoc) for q, v in TL.QUANT.items()}
    P0 = TL.frozen_picks(bk, fills, order, primary, tdoc, cuts["2/3"])
    s_ = TL.window_start(bk, cuts["2/3"])
    books, _ = SU.tree_run_books(P0, bk, s_)
    t1 = TL.window_end(bk, books)
    nan_tv = np.full(bk.n, np.nan)
    ED = TL.Eng(bk, "D", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, nan_tv)
    EE = TL.Eng(bk, "ENS", s_, cuts, cuts["2/3"], fills, order, primary, tdoc, nan_tv)
    checks, ok, window, fr = TG.frozen_gate(bk, books, ED, EE, s_, t1, tdoc, P0)
    if not ok:
        raise VLError("the frozen tree is not reproduced (%s)" % "; ".join("%s: %s" % kv for kv in checks.items()))
    return {"fdoc": fdoc, "tdoc": tdoc, "bk": bk, "fills": fills, "cuts": cuts, "s_": s_, "t1": t1, "ED": ED,
            "EE": EE, "primary": primary, "checks": checks, "window": window, "missing_cols": miss}


def stage_b(TS, PA, U, sig_u, flag_bk, p0, log=LOG):
    """The frozen books and S, T, R (and all three) from p0 to the end of the frozen trades."""
    bk, t1, primary = TS["bk"], TS["t1"], TS["primary"]
    cal = bk.cal
    Ts = {}
    for e, Eg, calm in (("D", TS["ED"], "first_up"), ("ENS", TS["EE"], "all")):
        T, _ = TG.frozen_trades(U, PA, bk, Eg, calm, primary)
        T["sig"] = sig_u[T["u"]]
        Ts[e] = T
    cap = r_cap(flag_bk)
    books, extra = {}, {}
    for e in ("D", "ENS"):
        T = Ts[e]
        mS, rho = s_multipliers(T, T["sig"])
        lvl = t_levels(T["sig"])
        Tt = t_trades(T, PA, lvl, primary)
        extra[e] = {"mS": mS, "rho": rho, "lvl": lvl, "Tt": Tt}
        books[(e, "frozen")] = book_sim2(T, PA.C, p0, t1)
        books[(e, "S")] = book_sim2(T, PA.C, p0, t1, mult=mS)
        books[(e, "T")] = book_sim2(Tt, PA.C, p0, t1)
        books[(e, "R")] = book_sim2(T, PA.C, p0, t1, cap=cap)
        books[(e, "STR")] = book_sim2(Tt, PA.C, p0, t1, mult=mS, cap=cap)
    days = cal[p0:t1 + 1]
    r = {v: account_returns(books[("D", v)][1], books[("ENS", v)][1], cal, p0, t1)
         for v in ("frozen", "S", "T", "R", "STR")}
    B_ = SU.Boot(days, B=BOOT_B, block=BOOT_BLOCK, seed=BOOT_SEED)
    di = np.arange(len(days))
    fz = path_numbers(r["frozen"], days)
    fz["exposure"] = float(np.mean(0.5 * books[("D", "frozen")][4] + 0.5 * books[("ENS", "frozen")][4]))
    fz["trades"] = int(books[("D", "frozen")][2].sum() + books[("ENS", "frozen")][2].sum())
    out = {"frozen": fz, "variants": {}}
    for v in ("S", "T", "R", "STR"):
        x = (np.log1p(r[v]) - np.log1p(r["frozen"])) * 1e4
        est, lo, hi, sd = boot_mean(B_, di, x)
        expo = float(np.mean(0.5 * books[("D", v)][4] + 0.5 * books[("ENS", v)][4]))
        c = expo / fz["exposure"] if fz["exposure"] > 0 else np.nan
        vr, vlo, vhi, pv = variance_test(B_, r[v], r["frozen"], c)
        raw = float(np.var(r[v], ddof=1) / np.var(r["frozen"], ddof=1))
        pm = (1.0 - phi(est / sd)) if (np.isfinite(sd) and sd > 0) else np.nan
        row = path_numbers(r[v], days)
        row.update({"diff": est, "diff_lo": lo, "diff_hi": hi, "vr": vr, "vr_lo": vlo, "vr_hi": vhi, "p_var": pv,
                    "vr_raw": raw, "exposure_ratio": c, "p_mean": pm, "exposure": expo,
                    "trades": int(books[("D", v)][2].sum() + books[("ENS", v)][2].sum())})
        yrs = pd.DatetimeIndex(days).year.to_numpy()
        for y in sorted(set(yrs)):
            row["year_%d" % y] = float((np.prod(1 + r[v][yrs == y]) - 1) * 100)
            fz["year_%d" % y] = float((np.prod(1 + r["frozen"][yrs == y]) - 1) * 100)
        out["variants"][v] = row
    decide_B(out["variants"], fz)
    out["variants"]["STR"]["p_holm"] = np.nan
    out["variants"]["STR"]["verdict"] = "shown only"
    tt = sum(int(np.isfinite(extra[e]["lvl"][(Ts[e]["ent"] >= p0) & (Ts[e]["ent"] <= t1)]).sum()) for e in extra)
    th = sum(int(extra[e]["Tt"]["t_hit"][(Ts[e]["ent"] >= p0) & (Ts[e]["ent"] <= t1)].sum()) for e in extra)
    nt = sum(int(((Ts[e]["ent"] >= p0) & (Ts[e]["ent"] <= t1)).sum()) for e in extra)
    mm = np.concatenate([extra[e]["mS"][(Ts[e]["ent"] >= p0) & (Ts[e]["ent"] <= t1)] for e in extra])
    out.update({"t_set": tt, "t_hit": th, "t_trades": nt,
                "s_mult": "median %.2f, 10th-90th percentile %.2f-%.2f, at 1/2: %.0f%%, at 3/2: %.0f%%" % (
                    np.median(mm), np.percentile(mm, 10), np.percentile(mm, 90), 100 * np.mean(mm <= S_CLIP[0]),
                    100 * np.mean(mm >= S_CLIP[1])) if len(mm) else "none",
                "r_flagged_pct": float(100 * np.mean(flag_bk[p0:t1 + 1])), "days": int(len(days)),
                "from": str(pd.Timestamp(days[0]).date()), "to": str(pd.Timestamp(days[-1]).date())})
    return out, r, Ts, extra, books


def cmd_run(a, log=LOG):
    t0 = time.time()
    try:
        dp, ddoc = load_declaration()
        found = {"setuplab": SU.VERSION, "treelab": TL.VERSION, "triggerlab": TG.VERSION, "tradelab": TC.VERSION}
        bad = ["%s (found %s)" % (v, found[k]) for k, v in NEEDS.items() if found[k] != v]
        if bad:
            raise VLError("needs %s beside this folder" % ", ".join(bad))
        root, panel = resolve_inputs(a)
        out = guard_out(a.out, root)
        elig = elig_column(getattr(a, "elig_col", None))
        TS = tree_setup(a, root, panel, log)
        prod = TD.Production(stage_e_any=bool(getattr(a, "stage_e_any", False)))
        mk = TD.Market(root, prod)
        _ = mk.intraday
        cal = np.asarray(mk.cal).astype("datetime64[D]")
        rows_by_sym, off_cal, n_etf = read_universe(panel, elig, root, cal)
        if not rows_by_sym:
            raise VLError("no eligible stock-day from %s in the panel" % UNIVERSE_FROM)
    except (VLError, TG.TGError, TL.TLError, TC.TLError, ValueError) as e:
        print("REFUSED: %s" % e)
        return 3
    bk = TS["bk"]
    checks = dict(TS["checks"])
    log("%s: declaration %s" % (VERSION, ddoc["sha256"][:16]))
    # ---- the tree's picks and their daily bars (stage B)
    U = TG.Universe(bk, TS["cuts"]["2/3"], TS["tdoc"], TS["s_"])
    try:
        PA, why = TG.load_paths(U, bk, _DailyOnly(mk), log)
    except (TC.StopRun, TC.TLError) as e:
        print("REFUSED: %s" % e)
        return 3
    off = int((~PA.ok).sum())
    if U.nu == 0 or off > TG.MISMATCH_MAX * U.nu:
        print("REFUSED: %d of %d picks could not be matched to the cache's bars (%s)" % (off, U.nu, why))
        return 3
    n_before = U.n
    U.keep(PA.ok)
    checks["picks"] = "%d engine picks (%d distinct) of D and ENS ranks 1-3; %d dropped (prices not matched: %s)" % (
        U.n, int(PA.ok.sum()), n_before - U.n, why or "none")
    nrows = sum(len(v) for v in rows_by_sym.values())
    checks["stage A universe"] = "%d stock-days of %d stocks from %s (%d ETF rows out, %d off the calendar)" % (
        nrows, len(rows_by_sym), UNIVERSE_FROM, n_etf, off_cal)
    for k, v in checks.items():
        log(" %s: %s" % (k, v))
    if a.check_only:
        sample = sorted(rows_by_sym)[:5]
        B = None
        for s in sample:
            B = read_3m(mk.intraday.path(str(s)))
            if B is not None:
                break
        log("CHECK OK - inputs readable, the frozen tree reproduced, the picks matched; a 3-minute file %s; nothing "
            "computed or written." % ("read" if B is not None else "NOT FOUND for the first stocks"))
        return 0
    # ---- stage A
    log("stage A: the measures of %d stocks" % len(rows_by_sym))
    R, Rm, cnt = build_rows(mk, cal, rows_by_sym, log)
    if cnt["with_bars"] >= 20 and cnt["usable"] < 0.5 * cnt["with_bars"]:
        print("REFUSED: 3-minute layout check: only %d of %d sessions with bars are usable (%s)" % (
            cnt["usable"], cnt["with_bars"], cnt["reasons"]))
        return 3
    checks["3-minute bars"] = "%d stock-sessions with a daily bar, %d with 3-minute bars, %d usable (%s)" % (
        cnt["asked"], cnt["with_bars"], cnt["usable"], cnt["reasons"] or "no problems")
    WF = WalkForward(R, Rm, cal, log)
    months = WF.months()
    if not months:
        print("REFUSED: no month has %d training days with targets (the 3-minute history is too short)" %
              MIN_TRAIN_DAYS)
        return 3
    d = SU.new_run_dir(out, "VOLLAB")
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "start", "run": d.name,
                 "tool": VERSION, "declaration_sha256": ddoc["sha256"], "watchlist": str(Path(a.data))})
    F = WF.run(months)
    test = WF.E & np.isin(WF.row_mon, months)
    for m in MODELS:
        test &= np.isfinite(F[m]) & (F[m] > 0)
    if test.sum() < 100:
        print("REFUSED: only %d test rows have every forecast and a target" % int(test.sum()))
        return 3
    ti = np.flatnonzero(test)
    Fsub = {m: F[m][ti] for m in MODELS}
    uni = race_table(R["H"][ti], Fsub, R["t"][ti], cal, MODELS)
    decA = decide_A(uni)
    info_rows = []
    infm = test & np.isfinite(F["M3sub"]) & np.isfinite(F["M3raw"])
    if infm.sum() >= 100:
        ii = np.flatnonzero(infm)
        info_rows = race_table(R["H"][ii], {m: F[m][ii] for m in ("M3",) + INFO_MODELS}, R["t"][ii], cal,
                               ("M3",) + INFO_MODELS, base="M3")
    # the tree's picks among the rows
    rowkey = pd.Series(np.arange(len(R["t"])), index=pd.MultiIndex.from_arrays(
        [R["syms"][R["si"]], R["t"]]))
    usd = np.asarray(U.usday).astype("datetime64[D]")
    upos = np.minimum(np.searchsorted(cal, usd), len(cal) - 1)
    upos = np.where(cal[upos] == usd, upos, -1)
    keyu = pd.MultiIndex.from_arrays([np.asarray(U.usym).astype(str), upos])
    hitu = rowkey.reindex(keyu).to_numpy()
    ru = np.where(np.isfinite(hitu), hitu, -1).astype(np.int64)
    pk = np.zeros(len(R["t"]), bool)
    pk[ru[ru >= 0]] = True
    pk &= test
    picks_rows = []
    if pk.sum() >= 100:
        pi = np.flatnonzero(pk)
        picks_rows = race_table(R["H"][pi], {m: F[m][pi] for m in MODELS}, R["t"][pi], cal, MODELS)
    tdays = R["t"][ti]
    resA = {"universe": uni, "picks": picks_rows, "info": info_rows, "decision": decA,
            "best_row": next(r for r in uni if r["model"] == (decA["best"] or "M0")),
            "from": str(cal[tdays.min()]), "to": str(cal[tdays.max()]), "fits": WF.fits}
    log(" STAGE A: %s (best %s, gain %s %s)" % (decA["verdict"], decA["best"], _p(resA["best_row"]["gain_vs_M0"], 4),
                                               _ci(resA["best_row"]["gain_lo"], resA["best_row"]["gain_hi"], 4)))
    # ---- stage B
    ch = decA["chosen"]
    Fc = F[ch]
    sig_u = np.full(U.nu, np.nan)
    good = (ru >= 0)
    fc = np.where(good, Fc[np.maximum(ru, 0)], np.nan)
    with np.errstate(invalid="ignore"):
        sig_u = np.where(np.isfinite(fc) & (fc > 0), np.sqrt(fc), np.nan)
    first_test = int(np.searchsorted(cal, np.datetime64(np.datetime64(int(months[0]), "M"), "D")))
    p0 = int(np.searchsorted(bk.cal, np.datetime64(cal[first_test]))) + B_OFFSET
    flag, fA, fB, Fn, _, _ = nifty_state(mk.series("NIFTY50"), cal)
    bpos = np.searchsorted(cal, np.asarray(bk.cal).astype("datetime64[D]"))
    bpos_ok = (bpos < len(cal))
    bpos_ok[bpos_ok] = cal[bpos[bpos_ok]] == np.asarray(bk.cal).astype("datetime64[D]")[bpos_ok]
    flag_bk = np.where(bpos_ok, flag[np.minimum(bpos, len(cal) - 1)], False)
    resB = None
    if p0 < TS["t1"]:
        resB, rB, Ts, extra, books = stage_b(TS, PA, U, sig_u, flag_bk, p0, log)
        resB["chosen"] = ch
        with np.errstate(invalid="ignore"):
            hmax = np.nanmax(PA.H[:, 1:HOLD + 1], axis=1)
        inper = np.isfinite(sig_u)
        resB["touch"] = touch_table(sig_u[inper], PA.O[inper, 1], hmax[inper])
        for v in ("S", "T", "R"):
            r_ = resB["variants"][v]
            log(" STAGE B %s: %s (mean %s bp a day %s, variance ratio %.3f %s, Holm p %s)" % (
                v, r_["verdict"], _p(r_["diff"]), _ci(r_["diff_lo"], r_["diff_hi"]), r_["vr"],
                _ci(r_["vr_lo"], r_["vr_hi"], 3), _p(r_["p_holm"], 4, False)))
    checks["stage B period"] = ("%s .. %s" % (resB["from"], resB["to"])) if resB else \
        "none: the first test month starts after the frozen trades end"
    # ---- outputs
    files = []
    pd.DataFrame(uni).to_csv(d / "forecast_race.csv", index=False)
    pd.DataFrame(picks_rows).to_csv(d / "forecast_race_picks.csv", index=False)
    pd.DataFrame(info_rows).to_csv(d / "forecast_race_measures.csv", index=False)
    pd.DataFrame(WF.fits).to_csv(d / "refits.csv", index=False)
    files += ["forecast_race.csv", "forecast_race_picks.csv", "forecast_race_measures.csv", "refits.csv"]
    pf = pd.DataFrame({"symbol": np.asarray(U.usym).astype(str), "signal_day": pd.DatetimeIndex(U.usday).date,
                       "row_found": ru >= 0})
    for m in MODELS:
        pf["sigma5_%s_pct" % m] = np.where(ru >= 0, 100 * np.sqrt(np.where(ru >= 0, F[m][np.maximum(ru, 0)], np.nan)),
                                           np.nan)
    pf["realised_sqrtH_pct"] = np.where(ru >= 0, 100 * np.sqrt(np.where(ru >= 0, R["H"][np.maximum(ru, 0)], np.nan)),
                                        np.nan)
    pf.to_csv(d / "pick_forecasts.csv", index=False, float_format="%.5g")
    files.append("pick_forecasts.csv")
    if resB is not None:
        rows = [dict(book="frozen", **resB["frozen"])] + [dict(book=k, **v) for k, v in resB["variants"].items()]
        pd.DataFrame(rows).to_csv(d / "stageB.csv", index=False)
        days = bk.cal[p0:TS["t1"] + 1]
        pd.DataFrame({"date": pd.DatetimeIndex(days).date, **{"r_" + k: v for k, v in rB.items()},
                      "flagged": flag_bk[p0:TS["t1"] + 1]}).to_csv(d / "stageB_daily.csv", index=False,
                                                                     float_format="%.8f")
        tr_rows = []
        for e in ("D", "ENS"):
            T = Ts[e]
            Tt = extra[e]["Tt"]
            m_ = (T["ent"] >= p0) & (T["ent"] <= TS["t1"])
            tr_rows.append(pd.DataFrame({
                "engine": e, "trade_id": T["tid"][m_], "symbol": T["sym"][m_],
                "signal_day": pd.DatetimeIndex(T["sday"][m_]).date, "entry_day": pd.DatetimeIndex(bk.cal[T["ent"][m_]]).date,
                "lane": np.where(T["lane"][m_] == 1, "jumpy", "calm"), "sigma5_pct": 100 * T["sig"][m_],
                "s_multiplier": extra[e]["mS"][m_], "t_target_pct": extra[e]["lvl"][m_],
                "t_reached": Tt["t_hit"][m_], "net_frozen": T["net"][m_], "net_T": Tt["net"][m_],
                "taken_frozen": books[(e, "frozen")][2][m_], "taken_R": books[(e, "R")][2][m_],
                "cap_R": r_cap(flag_bk)[T["ent"][m_]]}))
        pd.concat(tr_rows, ignore_index=True).to_csv(d / "stageB_trades.csv", index=False, float_format="%.6g")
        pd.DataFrame(resB["touch"]).to_csv(d / "touch_calibration.csv", index=False)
        files += ["stageB.csv", "stageB_daily.csv", "stageB_trades.csv", "touch_calibration.csv"]
    result = {"tool": VERSION, "made": _dt.datetime.now().isoformat(timespec="seconds"),
              "declaration_sha256": ddoc["sha256"], "stage_A": {"decision": decA, "best_row": resA["best_row"],
                                                                "from": resA["from"], "to": resA["to"]},
              "stage_B": ({k: v for k, v in resB.items() if k != "touch"} if resB else None)}
    result = json.loads(json.dumps(result, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    result["sha256"] = SU.frozen_hash(result)
    (d / "VOLLAB_RESULT.json").write_text(json.dumps(result, indent=1), encoding="utf-8")
    (d / "DECLARATION.json").write_text(dp.read_text(encoding="utf-8"), encoding="utf-8")
    checks["time"] = "%.1f minutes" % ((time.time() - t0) / 60)
    info = {"version": VERSION, "made": result["made"], "declaration_sha256": ddoc["sha256"], "checks": checks,
            "root": str(root), "panel": str(panel), "data": str(a.data), "elig_col": elig,
            "missing_columns": TS["missing_cols"]}
    write_report(d, info, {"A": resA, "B": resB})
    (d / "RUN.json").write_text(json.dumps(info, indent=1, default=str), encoding="utf-8")
    files += ["VOLLAB_RESULT.json", "DECLARATION.json", "VOLLAB.md", "RUN.json"]
    SU.write_hashes(d, files)
    ledger(out, {"at": _dt.datetime.now().isoformat(timespec="seconds"), "event": "end", "run": d.name,
                 "stage_A": decA["verdict"],
                 "stage_B": {k: v["verdict"] for k, v in resB["variants"].items()} if resB else None,
                 "minutes": round((time.time() - t0) / 60, 1)})
    log("VOLLAB WRITTEN %s (%.1f minutes)" % (d, (time.time() - t0) / 60))
    log(" STAGE A: %s" % decA["verdict"])
    if resB:
        log(" STAGE B: %s" % ", ".join("%s %s" % (k, resB["variants"][k]["verdict"]) for k in ("S", "T", "R")))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="vollab", description=VERSION)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="stage A and stage B (VOLLAB_DECLARATION.json)")
    r.add_argument("--root", required=True, help="the cache root (%%CACHE_DAILY_ROOT%%)")
    r.add_argument("--data", required=True, help="setuplab's watchlist folder (C:\\QuantData\\setuplab\\WL_R1_10)")
    r.add_argument("--out", required=True, help="the output folder (C:\\QuantData\\vollab)")
    r.add_argument("--panel", help="panel_oc's panel.parquet (default: <root>\\panel_oc\\panel.parquet)")
    r.add_argument("--elig-col", dest="elig_col", help="the panel's eligibility column (default: stage_b_screen's)")
    r.add_argument("--check-only", action="store_true", help="check the inputs, write nothing")
    r.add_argument("--stage-e-any", dest="stage_e_any", action="store_true",
                   help="accept a stage_e_execution.py that is not the shipped v1.2")
    a = ap.parse_args(argv)
    if a.cmd == "run":
        return cmd_run(a)
    return 2


if __name__ == "__main__":
    sys.exit(main())
