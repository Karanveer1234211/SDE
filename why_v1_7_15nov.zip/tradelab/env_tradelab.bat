@echo off
rem env_tradelab.bat - tradelab v1.3.1 + setups add-on v1.0 + why add-on v1.0: start a tradelab session in cmd.
rem   call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
rem Reads production (cache, pick_meta run, panel, 3-minute bars, stage E / intraday_cache code) READ ONLY.
rem Writes only under TRADELAB_OUT. Edit the paths below if your folders differ.
rem SETUPLAB_DIR / SETUPLAB_OUT: setuplab (the frozen setups); tradelab reads its tags and scans from SETUPLAB_OUT.
rem WHYLAB_DIR / WHYLAB_OUT: whylab; the watch page and the journal read why each pick was picked from WHYLAB_OUT
rem (keep WHYLAB_OUT the same as in whylab\env_whylab.bat).
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "TRADELAB_OUT=C:\QuantData\tradelab"
set "SETUPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\setuplab"
set "SETUPLAB_OUT=C:\QuantData\setuplab"
set "WHYLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\whylab"
set "WHYLAB_OUT=C:\QuantData\whylab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%TRADELAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%TRADELAB_OUT%" mkdir "%TRADELAB_OUT%"
cd /d "%TRADELAB_DIR%"
echo tradelab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   TRADELAB_OUT=%TRADELAB_OUT%   SETUPLAB_OUT=%SETUPLAB_OUT%   WHYLAB_OUT=%WHYLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_tradelab.bat
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
