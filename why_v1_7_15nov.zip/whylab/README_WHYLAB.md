# whylab v1.7 — the 14 Nov claims, what D relies on, why each pick was picked, what triggered its move, which entry suits each kind, whether one change inside the tree beats it, and the why of every pick the paper test records

**Question (Karan, 14 Nov 2026).** 20:14: "Let's try to understand in detail what the model REALLY relies on? And what drives the momentum after the stock is picked by the model?" 20:22, after Claude's answer: "No no no. No assumptions. Lets test on pc and come to a concerete sure shot valuable reliable conclusion."

**What it does.** Every claim Claude made at 20:14 is checked on every pick of the frozen engines, against every other stock of the same day. Every measure, threshold and rule is fixed in **`WHY_DECLARATION.json`** (14 Nov 2026, before any run on real data). `whylab.py` refuses any other version of that file.

**The picks.** Every pick in setuplab's newest TREE run: D and ENS, ranks 1–10, 2020-01-16 to 2026-09-15, ETFs out. Verdicts use ranks 1–3, the traded book. Ranks 1–10 are shown beside them without a verdict. Calm and jumpy picks use the tree's own lanes.

**"Every other stock that day".** Every symbol in `panel_oc` on the signal day (the engines' candidate list), ETFs out.

**The outcome.** Buy at the D1 open, sell at the D5 close, 0.35 points of costs. This is the tree's own D1 net, and the run checks that it gives the same number on at least 99% of picks before judging anything. The pick's **own move** is its return from the D1 open minus the average stock's return over the same days.

**How a claim becomes TRUE.** Each claim is judged in four cells: D and ENS, each in 2020–23 and in 2024–26. Every cell has a 95% interval (blocks of 10 signal days, 2,000 resamples). TRUE needs the claim in all four.

| # | Claim | What is measured |
|---|---|---|
| 1 | Picks come after a hard fall | Share of picks in the day's bottom 20% by 5-day return (chance is 20%). The same for RSI 7, 20-day position, 20- and 60-day return. |
| 2 | Picks are the most volatile stocks | Share in the day's top 20% by ATR % |
| 3 | A simple rule could do the model's job | R1 = the 3 stocks with the biggest 5-day fall in ATRs, R2 = the 3 with the lowest RSI 7, vs the engine's ranks 1–3, same days, paired |
| 4 | The gain is the model's choice, not only the type of stock | Each pick vs its 10 look-alikes: unpicked stocks of the same day nearest in 5-day return and ATR % |
| 5 | It is a rebound: a bigger fall, a bigger gain | Own move to D5 of the most-fallen third of picks minus the least-fallen third. The same for all stocks is shown beside it. |
| 6 | It is fast | Own move from the D1 open to the D2 close, and from the D2 close to the D5 close |
| 7 | It fades after D5 | Own move from the D5 close to the D10 close (and to the D6 open) |
| 8 | It comes with a volume burst | D1–D3 volume vs the stock's own 20-day average, and vs the look-alikes' |
| 9 | Closing near the 20-day low warns of a further fall first | Share touching −8% under the D1 open by D5: the third closest to the 20-day low minus the farthest |
| 10 | News or results drive the move | **Not tested.** The pipeline has no announcement data, and nothing stands in for it. |

The report also shows what the picks look like on the signal day (15 measures, as percentiles of the day), the average path D1–D10, and **12 example picks drawn at random** (seed 7) rather than chosen.

## Part K (v1.1, `model`) — what D itself relies on

The rules are fixed in **`WHY_K_DECLARATION.json`** (15 Nov 2026 00:20 IST, before any K run). It keeps the 14 Nov `model_part` and records two amendments made after reading D's frozen files, and before any K code ran on them:
- **Corrected input groups.** The 14 Nov name patterns misfiled 19 of D's 205 inputs: "dow" matched drawdown and downside, the day dummies and `Comb_` flags fell into "market", and a few volume names matched nothing.
- **D only.** ENS's C half would need its own folds and feature store.

What `model` does:
1. **Checks the frozen files.** Production's `stage_d_gate.py`, the D run's `stage_d.json` and `preds.parquet` must all have the sha256s that `panel_oc\frozen\FROZEN_ENGINES.json` records.
2. **Rebuilds D's 5 folds** for `label_oc_5` with stage D's own recipe: `stage_d_gate.CFG` and `make_label`, `stage_b_screen._read_col`, the same rows, the same 400,000-row samples and the same seeds.
3. **Gate.** The rebuilt scores must reproduce the frozen `preds.parquet`: the same top 3 on at least 99% of days and a median daily rank correlation of at least 0.999. If not, nothing else runs and the report says why.
4. **Knock-outs.** D's 205 inputs fall into 10 groups. For one group at a time, on every test day:
   - inputs that differ between stocks are shuffled across that day's stocks;
   - inputs that are the same for every stock that day are shuffled across days.

   This is repeated 3 times. The same fitted models re-pick the top 3 (ETFs out).
5. **Verdict.** D **RELIES ON** a group when scrambling it costs money: the 95% interval of the change in top-3 net per trade (D1 open to D5 close, after 0.35 points of costs) is below 0. Groups are ranked by the money lost. Raw price levels get their own line.

## Part P (v1.2, `explain` and `today`) — why each pick was picked

**Question (Karan, 15 Nov 2026).** 00:31: "Is it possible to know directly from the model - why that stock is picked? ... In that way we have setups or plans for such categories?" 00:43: "Yes build, also we need to be confident when we categorize why the stock was picked. Remember there can be transitions happening within."

The rules are fixed in **`WHY_P_DECLARATION.json`** (15 Nov 2026 01:00 IST, before any P run, and before part K's result was seen).

What `explain` does:
1. **Rebuilds D** exactly as part K does: the same checks and the same gate. If the rebuild isn't the frozen D, nothing else runs.
2. **Splits every pick's score** (the top 3 a day, ETFs out, 2020-26) into how much each of D's 205 inputs pushed it above the average of **100 other stocks of the same day**. The method is shap 0.54.1, "interventional".
   - The pushes add up to the pick's score minus that average. Every explanation is checked against scikit-learn's own predictions.
   - **v1.2.1:** shap's code holds each split point as a 32-bit number. Very rarely, that sends a stock down the other branch from D's real model. The check caught this on the first real run (P_20261115_001 stopped, gap 3.66e-06). whylab now rounds every split point down to 32 bits, so every stock takes exactly D's branch. The test plants that exact case.
   - Inputs that are the same for every stock that day (market, calendar) push exactly 0. They can't say why this stock beat the others.
3. **Adds the pushes up by part K's 10 groups.** The biggest group is the pick's **reason**.
4. **Confidence.** Two more versions of D for the same fold are trained on resampled history. Each explains the pick against its own random 100 stocks. **CONFIDENT** = all three name the same reason; otherwise **MIXED**. A CONFIDENT reason holds no matter which equally good version of D, and which other stocks, you ask.
5. **Transitions.** The same model explains the pick again at the D1-D5 closes. The reason is **STILL THERE** while its group still pushes the stock above that day's average stock, and **GONE** once it doesn't.
6. **Outcomes** come from the bars, as in the claims part, and must give the tree's D1 net on 99% of picks.
7. **Four tests**, rules fixed in advance:
   - **T1:** does a category earn differently from the other picks?
   - **T2:** does a category deserve its own holding period? It is chosen on 2020-23 and judged on 2024-26, by edge a day after costs.
   - **T3:** when the reason is gone, does selling at the next open save money?
   - **T4:** when the reason is still there at D5, does holding to D10 beat putting the money in a new pick?

What `today` does:
- Takes the production D.pkl's top 3 for the newest session of the live panel, each with its reasons, category and confidence.
- Lists the last 5 sessions' picks (still held), each marked by whether its reason is still there at the newest close.
- On first use, it builds two check versions of D.pkl. That happens only after the same code reproduces D.pkl exactly.

It is research only: the paper test's plan is unchanged.

## Part T (v1.4, `triggers`) — what triggered each pick's move, in its own indicators

**Question (Karan, 15 Nov 2026).**
- 11:10: "CHECK FOR EACH OF THE MODEL's PICKS THEIR INDICATORS AND WHAT TRIGGERED THE MOVEMENT WRT TO THOSE INDICATORS".
- 11:16: "Ok for all, Daily bars for now".
- 11:21: each kind of pick has its own set of indicators, so measure it accordingly.

The rules are fixed in **`WHY_T_DECLARATION.json`** (12:17 IST, before any T run). It replaces v1.3's declaration of 11:27, which was never run. Karan forwarded a review at 12:00; checking it against the code and part P's real run found seven faults. They are listed in the declaration and in the MANIFEST.

What `triggers` does:
1. **Reads part P's finished run** (the newest one, P_20261115_002; the stopped P_20261115_001 is skipped). That gives every pick, its kind, and the inputs D used for it. Nothing is re-explained.
2. **Turns each pick's inputs into the readable indicators behind them:** EMA-20 slope, RSI-14, MACD, ADX/DI, Bollinger, 52-week range, 20-day range, 4/13-week momentum, volume, ATR/volatility, candle.
   - Inputs that no chart can show are listed and left out: WorldQuant formulas, market series, calendar, flags, codes, run and days-since counts.
   - **This is a translation, not D's exact inputs.** On P_20261115_002, D's push over the 24,825 top-5 inputs splits into:
     - 62.2% the stock's own daily inputs;
     - 24.7% cross-sectional (X_) or weekly (W_) inputs, which are followed through the stock's own daily indicator;
     - 13.1% left out, of which 10.0% is WorldQuant.
   - The report shows this split for every kind.
3. **Follows each indicator's triggers on the stock's own daily bars** from the signal day to D10.
   - D1–D10 must be the market's next 10 sessions. A pick missing a session is left out and counted.
   - Examples: "RSI-14 crosses above 30", "13-week return crosses above 0", "new 52-week closing low", "close above the previous 20-day high".
   - Every trigger uses only that close and earlier, with TradingView's definitions, so anything found can go on a chart.
4. **The move** = the first close at or above the D1 open + 1 ATR (setuplab's simple 14-day ATR, at the signal day).
5. **Keeps the kinds apart:**
   - Every CONFIDENT kind is measured on its own, and MIXED picks are split by their two reasons.
   - A trigger is measured only on the picks of that kind whose own indicators include it.
   - Two yardsticks are shown for every pick: close above yesterday's high, and volume at 1.5× its 20-day average.
6. **Two measures per trigger:**
   - **Fired before the move (shown).** Picks that moved are compared with picks that didn't, over the same days after the pick. On a random test world this measure shows the yardstick "close above yesterday's high" about 36–40 points more often before moves, with no trigger at all, because the move itself has begun. So it is never the verdict.
   - **The verdict.** At each close D1–D7 before the move, did the move come within the next 3 closes more often after the trigger fired?
     - It is compared with closes where the trigger could have fired but didn't. For a crossing, that means the line was below at the close before.
     - The comparison is made **at the same close after the pick and the same distance from the target**.
     - **TRIGGER** needs the 95% interval above 0 in 2020-23 and in 2024-26, and it must survive the many-tests check. That check is Benjamini–Hochberg over every judged test of the run, at most 5% false discoveries, on the weaker period's p.
     - **MAY BE CHANCE**: both periods passed but the check didn't.
     - A trigger needs 100 matched firings in each period.
   - **FALLS TOO** marks a trigger that also makes a 1-ATR fall more likely in both periods: a bigger move either way, not a rise.
7. **What a TRIGGER means:** a historical link worth testing as an entry, not a tested entry. Nothing here measures next-open fills, costs, exits, MFE/MAE or missed winners. That would be its own declared test.

**Outputs** (`C:\QuantData\whylab\triggers\T_<date>_<nnn>\`):
- `TREPORT.md`: the triggers found, the checks and test counts, then one table per kind with its push split.
- `picks.csv`: for every pick:
  - its own indicators and left-out inputs;
  - why it was left out, if it was;
  - its ATR and target;
  - whether and when it moved.
- `paths.csv`: every pick's open, high, low, close and readable indicator values at every close D0–D10.
- `firings.csv`: each of its triggers, when it first fired after the pick, and whether that was before the move.
- `triggers.csv`: every kind × trigger row with both periods, its p and q, and the verdict.
- `translation.csv`: every input, its readable indicator, how it is followed, and its push.
- `coverage.csv`: the push split per kind.
- `gate.csv`.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- A ledger line.

**Gate:** the bars must give part P's D1-D5 move on 99% of picks, otherwise nothing is measured. A pick left out counts as not equal.

## Part C (v1.5, `choices`) — which entry suits each kind of pick, inside the frozen tree

**Question (Karan, 15 Nov 2026).**
- 13:20: "claude knows the model, it knows the why, but it just doesnt want to find when".
- 13:41: "Can you better this? Also, this to compared apple to apple with tree".
- 13:57: "Yes build, be quick smart and fast about it".

The rules are fixed in **`WHY_C_DECLARATION.json`** (14:06 IST, before any C run).

What `choices` does, in plain words:
1. **Rebuilds the frozen entry tree's D book** with setuplab's own code, from the newest TREE run on your PC (its watchlist and TAGS run). It must give that run's own numbers exactly, and the run must say "reconciled", or nothing is compared.
2. **Gives every D pick its kind** from part P (trend, position, volatility, returns, or a MIXED pair).
3. **Changes one thing at a time.** For one kind, every pick of that kind is bought one of three ways; every other pick keeps exactly the tree's own decision:
   - **open**: buy at the D1 open, sell at the D5 close (don't wait);
   - **frozen**: only through the frozen setups S1–N1, any lane (buy weakness);
   - **confirm**: only through the kind's confirmation rule (wait for confirmation). The rules:
     - trend: dip and reclaim;
     - position: breakout retest;
     - volatility: compression to expansion;
     - returns: runner pullback reclaim;
     - a MIXED pick uses its top reason's rule.
4. **Runs the same Rs 5 L book** (3 positions, the same five start days, exits and 0.35 pp) for each of the 24 variants, and compares each with the frozen tree day by day.
5. **The verdict:**
   - **BEATS THE TREE** needs four things:
     - its book grows faster than the tree's in 2021-23 and in 2024-26 (95% intervals above 0);
     - it survives the many-tests check (Benjamini–Hochberg, 5%);
     - its worst fall is no deeper;
     - the kind has 100+ picks in each period, otherwise it is TOO FEW.
   - **WORSE THAN THE TREE** is the mirror.
   - **Everything is in-sample.** A winner is only a candidate for a new tree with its own freeze date, judged by the forward paper test.

Example: in the variant "position, open", every position pick is bought at its D1 open (if one of the 3 slots is free); every other pick is bought, waited for or skipped exactly as the frozen tree does. Both books start with Rs 5 L on the same days. If the variant's book grows faster in both periods, passes the many-tests check and falls no deeper, position picks are better bought without waiting.

**Outputs** (`C:\QuantData\whylab\choices\C_<date>_<nnn>\`):
- `CREPORT.md`: the checks, the 24 verdicts beside the frozen tree and the baseline, then each kind's picks under each choice.
- `variants.csv`: each variant's book and comparison.
- `groups.csv`: for each kind and choice:
  - trades and net per trade;
  - net per pick, with skipped picks counted as 0;
  - missed winners;
  - best and worst close after entry.
- `picks.csv`: each D pick:
  - its kind, lane and the tree's action;
  - its open, frozen-setup and confirmation trades;
  - whether its bars match the watchlist.
- `daily.csv`: each variant's daily difference from the tree.
- `gate.csv`, `run.json`, `DECLARATION.json`, `outputs.sha256`.
- A ledger line.

## Part M (v1.6, `modify`) — one change at a time inside the frozen tree, for one kind of pick

**Question (Karan, 15 Nov 2026).**
- 14:57, the proposal he pasted: "What remains untested is whether specific changes inside the existing setups add value ... change one condition at a time ... Every other pick follows the frozen tree ... including trades displaced by the change ... with a declared multiple-testing correction", and "exits by kind (position picks were still climbing at D10); sizing; which picks to skip; anything finer than the kind."
- His answers to Claude's two questions: weekly persistence "Include it anyway"; scope "Everything now".

The rules are fixed in **`WHY_M_DECLARATION.json`** (15:12 IST, before any M run).

What `modify` does, in plain words:
1. **Rebuilds the frozen tree's D book** exactly as part C does, with the same gate.
2. **Re-tags the seven frozen setups** with setuplab's own code on the panel your TAGS run used. It must give every fill and net of that TAGS run exactly, or nothing is compared. That is what makes it safe to change a setup's dip or its weekly condition.
3. **Changes one rule for one kind**, then applies the tree's rules again to all D picks, so a pick of another kind can take the slot or the open buy the change frees. The kinds are the four with 100+ picks in each period: trend, position, returns, MIXED returns + trend. The 68 changes:
   - **A, setup eligibility (28):** the kind may not use one of S1–N1; it takes its next earliest fill.
   - **B, dip depth (12):** every setup's dip half as deep, 1.5× as deep, or gone (S2 and C3 have none).
   - **C, weekly persistence (4):** the bad-week reading counts until the next weekly reading, not only on the session it is posted.
   - **D, exit (4):** sold at the D10 close instead of D5.
   - **E, size (8):** 1/2 or 1/6 of the book instead of 1/3. A 1/2 trade takes one and a half of the 3 slots, a 1/6 trade half of one.
   - **F, skip (4):** never traded.
   - **G, lane (8):** the kind's calm picks go through the setups only, or its jumpy picks are treated as calm.
4. **The same Rs 5 L book and verdicts as part C.** The many-tests check runs within each family. A change judged on fewer than 100 picks in a period is TOO FEW; for G, only the kind's picks in that lane count. A change that leaves every planned trade as it was is CHANGES NOTHING.

Example: in "D | position | sold at the D10 close", every position trade is held to its D10 close. That slot stays busy five more days, so some later picks find no free slot, and those lost trades count against the change. If the book still grows faster in 2021-23 and in 2024-26, passes the check within family D and falls no deeper, it BEATS THE TREE. That makes it a candidate for its own forward test; the frozen tree stays the benchmark.

**Outputs** (`C:\QuantData\whylab\modify\M_<date>_<nnn>\`):
- `MREPORT.md`: the result, the checks, then one table per family beside the frozen tree and the baseline.
- `variants.csv`: each change's book and comparison, with the picks it changes.
- `fills.csv`: each setup's fills under the frozen rules, each dip depth and the lasting bad-week reading.
- `daily.csv`: each change's daily difference from the tree.
- `gate.csv`, `run.json`, `DECLARATION.json`, `outputs.sha256`.
- A ledger line.

## Part R (v1.7, `why`) — the why of every pick the paper test records, written down before the next open

**Question (Karan, 15 Nov 2026).**
- 17:57: "New column added in watchlists or tags like calm/jumpy, which answers why? With exact numbers. And the same to be included everywhere else, wherever we talk about trades. Show before finalising."
- 18:16: "every rank including ens", with the guidance he pasted: show the leading reason and the top three actual feature values, with the lead and the contributions inside the details; include the inputs that worked against the pick; use it to understand a pick, review a losing trade, monitor the model and keep a research record; "They should help explain the trade—not become another set of numbers you feel obliged to act on."
- 18:17, the research-scope note: "Explain ENS's own selections first; don't assign D's reasons to ENS."

**This is a record, not a test.** No verdict and no money. Nothing in it changes what is traded. The rules are fixed in **`WHY_R_DECLARATION.json`** (15 Nov 2026 18:50 IST).

What `why` does, in plain words:
1. **Reads the paper test's own ledger** (production's `paper_pipeline.read_ledger`, its hash chain checked) and takes every D and ENS pick of ranks 1–10.
2. **Loads the frozen models the paper test uses**, through production's `production_models.load_verified`: D.pkl and C.pkl, their SHA-256 checked.
3. **The gate.** It recomputes every recorded score from panel_live with those models, the same formula as `paper_pipeline.score_day`. Each must equal the ledger's number exactly. Otherwise tonight's record stops with nothing written; an earlier session is left out and listed.
4. **Explains each pick by its own model.**
   - D: D.pkl, part P's method (TreeSHAP against 100 other stocks of the session, D.pkl and two check versions, part K's groups).
   - ENS: its score is `0.5 x D's percentile rank + 0.5 x C's percentile rank`. Each half is explained by its own model: D's half by D.pkl, C's half by C.pkl with the stage C declaration's own groups. D's reasons are never given as ENS's.
   - Per pick it writes the leading reason, CONFIDENT or MIXED, the lead (the score above the average of the 100, in points), every group's push, and the 3 inputs that pushed the score up and the 3 that pushed it down, each with its value and its place among the session's stocks.
5. **Records it before the next open.** Each why goes into `C:\QuantData\whylab\why\why_ledger.jsonl`: append only, every line chained to the one before by SHA-256, with the time it was written. ON TIME means written before 09:00 of the next weekday (production's `entry_deadline`); LATE means written after. A why is never rewritten. `--catch-up` fills every recorded session still without one, each LATE.
6. **Tonight's page** (`why\WHY_<date>.md` and `.csv`, read by tradelab's watch page):
   - every pick's why;
   - the picks still held (ranks 1–3 of the last 5 sessions): their reason group's push at tonight's close, STILL THERE or GONE;
   - the **monitor**: each leading reason's share of ranks 1–3 over the last 20 recorded sessions, beside part P's 2020–26 share (`why_monitor.csv`).

Example: D's #1 on 15 Sep 2026 was SSWL. Part P's run explains it as "returns, reversal and oscillators (CONFIDENT)": lead +3.02 points, that group +1.48 (49%), top inputs `D_WQ_29 = 0.9975 (top 0.8%, +0.44)`, `D_intraday_ret_pct = -8.378 (bottom 1.9%, +0.30)` and `W_ret_13w = 60.02 (top 2.3%, +0.20)`. From tonight on, every pick gets the same lines from D.pkl itself, written before the next open.

**What it does not cover.** D's ranks 4–10 and every ENS pick before the paper test (30 Sep) have no why. Part P explained D's ranks 1–3 only. Explaining those needs its own history run, which is not built.

## Install and run

Unzip into `C:\Users\karanvsi\PyCharmMiscProject`. v1.7 replaces the files in the `whylab` folder and adds `WHY_R_DECLARATION.json`; tradelab's why add-on v1.0 comes in the same zip. Part P needs one new library, shap 0.54.1. It has a ready-built Windows version and does not change numpy, pandas or scikit-learn (checked on your versions).

```
cd /d C:\Users\karanvsi\PyCharmMiscProject
tar -xf "%USERPROFILE%\Downloads\why_v1_7_15nov.zip"
call whylab\env_whylab.bat
python tests\test_whylab.py
python whylab.py check
python whylab.py why --root %CACHE_DAILY_ROOT% --catch-up
```

- **The test** must end `VERIFIED (whylab v1.7)`.
- **`check`** must list seven declarations as OK.
- **`why`** needs no new library. The first run with `--catch-up` builds C.pkl's two check versions once (D's were built by `today`) and fills every paper-test session since 30 Sep, each marked LATE. After that, `run_tonight.bat` runs it every night as its step 4. Most of its time goes on rebuilding C's inputs on panel_live with production's `stage_c_features` (a few minutes, an estimate).
- **`modify`** (v1.6) already ran as M_20261115_001.
- **`modify`** reads the same TREE run, watchlist, TAGS run and part P run as `choices`, plus the panel named in the TAGS run's `TAGS.json` (read only). Most of its time goes on reading that panel: a few minutes, an estimate. If it stops at the re-tag gate, the panel changed since the TAGS run: run setuplab's `tag` and `tree` again, then `modify`.
- **`choices`** reads setuplab's newest TREE run under `SETUPLAB_OUT` (set by `env_whylab.bat`), which must say reconciled. It also reads the watchlist and TAGS run that the TREE run names, and part P's run. It needs no new library.
- **`triggers`** needs no new library. It takes a few minutes, mostly reading the bars; that is an estimate.
- **If you already ran v1.3's `triggers`**, v1.4 refuses until you add `--rerun-reason "v1.4: the review's fixes"`; the ledger keeps both runs.
- **First-time installs** of part P need `python -m pip install shap==0.54.1` once. For `explain`, check that pip's "Successfully installed" line lists no numpy, pandas or scikit-learn.
- **Already done:** `explain` ran as P_20261115_002 and `choices` as C_20261115_001. If either ever runs again, it needs `--rerun-reason`.

**`explain`** prints:
- what it loaded;
- the 5 folds and the gate;
- the check versions;
- progress of the explanations every 10%;
- the outcome gate;
- then a `RESULT:` line and `DONE`.

Expect about 20-25 minutes and about 3 GB. That is an estimate from part K's measured 1,624 s and the explanation speed timed here.

**`today`** takes about 4-5 minutes the first time, while it builds the check versions, and well under a minute after that. It finds the live panel through production's `paper_pipeline.paths`; if that fails, pass `--live <the live panel.parquet>`.

**Second runs:**
- `run` (the claims) and `model` (part K) already ran under their declarations, so a second run is refused.
- `explain` is refused the same way after its first run.
- Each of these runs again only with `--rerun-reason "<a verified bug>"`, which goes into the ledger.

**Part P outputs** (`C:\QuantData\whylab\explain\P_<date>_<nnn>\`):
- `PREPORT.md`: the checks, how sure the reasons are, the categories with T1/T2, the transitions with T3/T4, the latest picks with their top inputs, and the groups.
- `picks.csv`: every pick with its pushes by group, each version's reason, its category, its status at D1-D5, and its outcomes.
- `reasons.csv`: each pick's top 5 inputs, with value, percentile that day and push.
- `categories.csv`, `transitions.csv`, `tests.csv`, `gate.csv`.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- A ledger line.

**`today` outputs:** `C:\QuantData\whylab\today\TODAY_<session>.md` and `.csv`; the check versions in `today\checks\`.

**`why` outputs:** `C:\QuantData\whylab\why\why_ledger.jsonl` (the record), `WHY_<session>.md` and `.csv` (tonight's picks, the picks still held), a `WHY_<session>.csv` for each caught-up session, and `why_monitor.csv`.

**Part K outputs** (`C:\QuantData\whylab\model\K_<date>_<nnn>\`):
- `KREPORT.md`: the gate, the groups ranked by money lost, the raw-price-level line, and every input with its group.
- `families.csv`, `inputs.csv`, `gate.csv`, `folds.csv`.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- A ledger line.

If the gate fails, it prints `STOPPED:` and the report says why.

**Outputs** (`C:\QuantData\whylab\runs\WHY_<date>_<nnn>\`):
- `REPORT.md`: the verdicts first, then each claim cell by cell, the rules, the signal-day profile, the path, the examples and the data checks.
- `claims.csv`: every cell of every claim, for all, calm, jumpy and ranks 1–10.
- `profile.csv`, `path.csv`, `rules.csv`, `examples.csv`.
- `picks.parquet`: every pick with every measure and outcome.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- One line per run in `C:\QuantData\whylab\whylab_ledger.jsonl`.

**Reads only:** setuplab's newest TREE run (hash-checked), `panel_oc` (timestamp and symbol only), every universe stock's daily bars through tradelab's loader (production's stage E), setuplab's `TREE.json` ETF names, and NSE's ETF list when present. **Writes only** under `WHYLAB_OUT`.

**If the run stops** with `STOPPED:` (the gate), nothing is written. Send the screen: it means the bars here and the tree's prices disagree on more than 1% of picks.

## Tests (`tests\test_whylab.py`, 80 checks)

- **By hand:**
  - every measure and outcome against an independent loop, including a suspended session;
  - the day frame (percentiles, ETFs out, the market's mean, the excess);
  - the look-alike controls;
  - the rules' daily top 3 (ties by symbol, a missing outcome left out);
  - every claim's rule on made-up pick tables where the claim is planted, absent, reversed, or explained by the type.
- **Whole runs on synthetic caches** in the real layouts (daily bars, NIFTY50, panel_oc, a setuplab TREE run, tradelab's production stand-ins):
  - **PLANTED**: one-day crashes, a D1–D2 rebound on 3× volume, flat to D5, a fade over D6–D10; half close at their low and dip 10% on D1. Claims 1, 5–9 come out TRUE, and R1 (the engines' own rule) matches the model.
  - **FALLEN**: the same picks with nothing after. Claim 1 is TRUE and no after-the-pick claim is.
  - **RANDOM**: nothing is TRUE.
- **Each cell's picks by hand:** the period split, lanes, ranks and ETFs, and the 12 examples equal the declared draw.
- **The gate:** a tree whose D1 net is off on 2% of picks stops the run, and nothing is written.
- **Guards:** outputs and their hashes, the ledger, the rerun guard, and refusals (output inside the cache, no `--root`, no setuplab output).
- **Part K, on a synthetic panel_oc with stand-in production modules:**
  - stage D's fold loop written out independently makes the "frozen" `preds.parquet`, and the rebuild must reproduce it exactly;
  - an outcome that follows one input makes D **RELY ON** that input's group, the largest loss;
  - one knock-out is recomputed by hand: picks replaced, money and the top 3's own net, day by day;
  - the input groups come out right (including the amended cases), and the scramble keeps each day's values;
  - frozen scores that don't reproduce on 5% of days stop part K;
  - it refuses before anything runs on a changed `stage_d_gate.py`, a changed config, or a changed `preds.parquet`.
- **Part P:**
  - every push equals the Shapley value computed from its definition (all subsets of inputs), to within shap's own rounding (1e-7);
  - the failure from Karan's PC, planted: a split point halfway between two neighbouring 32-bit values. Raw shap misses the model there by about 1; whylab's explainer adds up exactly;
  - the pushes add up, day-constant inputs push 0, and an explanation that doesn't add up stops the run;
  - the comparison draw, and the check versions' bootstrap draw, are rebuilt by hand;
  - T1-T4 are recomputed by hand on a made-up pick table, intervals included;
  - the D2-D5 opens are computed by hand.
- **Part P on synthetic worlds:**
  - **PLANTED**: an RSI-7 jump that is gone the next day (a 9% D1 jump, then a give-back), and ATR % high for 11 days while the stock climbs. The reasons come out CONFIDENT and correct (99.8%). The RSI-7 picks' reason is GONE at D1 and the ATR picks' is STILL THERE. T3 = EXIT EARLY, and the returns category's best hold = D1. One pick's pushes are recomputed by hand.
  - **NULL**: nothing planted; only 12.6% of picks come out CONFIDENT.
  - The outcome gate stops the run on a tree that is 2% off, and a wrong shap or a changed declaration is refused.
- **today:**
  - its picks equal D.pkl's top 3, with an ETF that D ranks first left out;
  - a held pick's status is recomputed by hand;
  - the check versions are built once and reused;
  - it refuses a changed D.pkl, a different scikit-learn, a changed check version, or a recipe that doesn't reproduce D.pkl;
  - the live reader handles IST or naive timestamps.
- **Part T, by hand:**
  - every trigger, where it could fire, and every indicator value, recomputed with plain loops:
    - TradingView-style seeded EMA, Wilder RSI and DMI, MACD;
    - Bollinger with the population SD;
    - ROC 20 and 65;
    - 52-week high and low, 13-week high, 20-day high (a high or low exactly 252 or 65 closes back still counts);
    - OBV, and ATR equal to setuplab's;
  - all 135 real input names of P_20261115_002 checked one by one against a reviewed table, and how each is followed;
  - both measures recomputed: the verdict cell by cell (same close, same distance), its interval and p, then the many-tests check on made-up rows (Benjamini–Hochberg, the weaker period, opposite periods, TOO FEW, MAY BE CHANCE, FALLS TOO).
- **Part T, the two confounds on made-up picks:**
  - **Early firing:** moves come early and a trigger fires mostly early but says nothing. The old pooled comparison shows a gain; v1.4 finds nothing. A trigger that really helps is found.
  - **Firing state:** a crossing fires only out of a state that itself speeds the move. Compared with every close, it shows +11 to +13 points; compared with closes where it could have fired, nothing. A crossing that really helps is found.
- **Part T on synthetic worlds:**
  - **PLANTED:**
    - Trend picks get a flat day on 3× volume and then climb; calm picks get a wide-range day with the close unchanged and then climb. Neither day moves the distance to the target.
    - Each kind finds its own planted trigger through the many-tests check, and is never measured on the other's indicators.
    - The MIXED pair keeps its own name and indicators.
    - Every pick's move day is recomputed from `paths.csv`.
    - A pick whose stock lost its D3 bar is left out as "calendar".
    - The push split is recomputed by hand.
  - **NULL** (random walks): no TRIGGER anywhere, while "fired before the move" falsely favours the yardstick by more than 10 points in both periods.
  - The gate stops the run on part P numbers 2% off. It refuses part P outputs changed after their run, a changed declaration, and a second run, including after a v1.3 run, without `--rerun-reason`.
- **Part C, by hand:**
  - the four confirmation rules on made-up bars:
    - each fires on its planted day;
    - none fires when its signal-day condition fails, from the middle of the range, or on a range under one ATR;
    - the range position and the weekly 13-week return are recomputed;
  - routing: the kind's picks get the new trade and every other pick keeps its tree trade;
  - a book over the five start days;
  - the comparison, its interval and p, and the verdicts.
- **Part C on synthetic tree worlds**, built with setuplab's own watchlist builder and its own tree command:
  - the rebuild gives the TREE run's numbers exactly;
  - **PLANTED:** position picks climb without dipping, so open BEATS and frozen is WORSE; trend picks sink first, so open is WORSE and frozen BEATS; random kinds neither; a kind with under 100 picks in a period is TOO FEW;
  - picks whose cache bars differ from the watchlist are flagged and get no confirmation fill;
  - **NULL:** nothing beats or loses to the tree;
  - **stops:**
    - the rebuild is 0.01 off;
    - the TREE run is not reconciled;
    - 3% of picks have no kind;
    - a second run without `--rerun-reason`;
    - a changed declaration.
- **Part M, by hand:**
  - each family's trades on a made-up window: a setup taken away (the next earliest fill), never traded (the day's open buy goes to the next calm pick that opened up), calm to setups and jumpy as calm (the tree's rules applied again), the D10 close (a missing D10 close keeps the tree's exit), the size;
  - the size book: a 1/2 trade leaves no room for a third trade, 1/6 + 1/2 + 1/3 fill the book, and at 1/3 everywhere it is setuplab's tree_sim bit for bit;
  - the dips scaled or removed and the bad-week condition swapped, on the frozen setups; the last published weekly change; the verdicts with the check within each family.
- **Part M on synthetic worlds**, with a feature panel and setuplab's own `tag` and `tree` commands:
  - the gate: the rebuild, the first setups, the re-tag (every fill and net), the weekly read and the size book all match exactly;
  - **PLANTED:** position held to D10 BEATS and never trading it is WORSE; for trend picks the lasting bad-week reading BEATS (their dip comes mid-week); taking away N1, which never fills, CHANGES NOTHING; the lane family is judged on the lane's picks;
  - **NULL**, on three seeds: nothing beats or loses to the tree; this panel carries its own change column, which both readers must use;
  - **stops:** one status and one net changed in the TAGS run (before the window, so the tree still matches) stop it at the re-tag gate; a change of 1e-6 in the weekly read is caught; a missing panel, a changed declaration and a second run are refused.
- **Part R on synthetic worlds**, with stand-ins of production's paper_pipeline, production_models, stage_c_features and stage_c_screen, and D.pkl and C.pkl trained by production's recipe:
  - every pick the paper ledger recorded (D and ENS, ranks 1–10) is explained, after both models' check versions reproduce D.pkl and C.pkl;
  - one session by hand: a D pick's lead, its group pushes, its reason and its top inputs (value and place) are shap by hand against the same 100 stocks; an ENS pick is `0.5 x D's percentile rank + 0.5 x C's` exactly, and each half is its own model by hand;
  - **PLANTED:** D picks on an RSI-7 jump give 'returns' as D's reason; ENS picks with C's reversal input planted give C's own group for the C half; a C half never names one of D's groups;
  - with more than 100 stocks each version draws its own 100: a D pick's three versions, an ENS pick's C half and a held pick at tonight's close by hand on those draws;
  - tonight ON TIME, caught-up sessions LATE; the held picks' STILL THERE / GONE by hand; the monitor's shares, sessions and picks by hand; the page's text formatted independently;
  - every WHY file carries the columns tradelab's watch page reads; `--catch-up` writes each caught-up session's file;
  - **stops:** a recorded score 1e-9 off stops tonight's record (nothing written) and leaves an earlier session out; an edited ledger line, a changed C.pkl, a PRODUCTION.json without C and a changed declaration are refused.
- **Planted bugs:** 167 of them, each caught (see MANIFEST).
