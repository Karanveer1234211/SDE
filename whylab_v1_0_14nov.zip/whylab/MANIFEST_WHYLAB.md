# MANIFEST - whylab v1.0 (14 Nov 2026)

New research tool in its own folder beside tradelab and setuplab. Nothing in `bigmove_deploy`, tradelab or setuplab changes; production is read only.

| file | what | sha256 (first 16) |
|---|---|---|
| `whylab\whylab.py` | the tool: `check`, `run` | 0b549f4623ffa6f9 |
| `whylab\WHY_DECLARATION.json` | every measure and rule, fixed 14 Nov 2026 20:45 IST before any run; pinned in whylab.py | e3967dd85a42d063 |
| `whylab\tests\test_whylab.py` | self-test, 19 checks | cb3197d3563cab0e |
| `whylab\env_whylab.bat` | session: env_daily.bat, PYTHONPATH (whylab, tradelab, setuplab, production read only), WHYLAB_OUT, SETUPLAB_OUT (CRLF; labels unique) | 7f39cd3f02e710ff |
| `whylab\README_WHYLAB.md` | what it does, how to run it | 8f810d3348956e1b |
| `whylab\MANIFEST_WHYLAB.md` | this file | - |

**Uses unchanged (versions checked at start):**
- setuplab v1.1: Boot, atr_simple, TREE.json and its ETF rule, run folders, hashes.
- tradelab: tl_setups v1.7 (the tree run loader, sde_series), tl_data (production's stage E bar loader, the NIFTY50 calendar, panel_oc), tl_common.
- Production's `stage_e_execution.py`: tradelab refuses any version but the shipped v1.2 unless `--stage-e-any` is given.

**Writes only:** `C:\QuantData\whylab\runs\WHY_<date>_<nnn>\` and `C:\QuantData\whylab\whylab_ledger.jsonl`.

**Verified 14 Nov 2026:** `VERIFIED (whylab v1.0)`, 19 checks, 0 failed, on pandas 2.3.3 / numpy 2.4.1 (Karan's) and on pandas 3.0.5 / numpy 2.5.3. Test time is about 1 minute.

**Scale (measured here):** 702 symbols x 1,408 signal days (985,000 stock-days) ran in 29 s with a peak of 939 MB of memory. The real run, about 1,455 symbols x 1,655 days, is estimated at 3-10 minutes and about 1.5 GB. That figure is an inference, not a measurement on Karan's PC.

**Planted bugs, each caught by the self-test (26 of 26):**
- **Measures and outcomes:**
  - a 4-day "5-day" return;
  - RSI smoothing 1/14;
  - the 20-day low taken from highs;
  - no next-session rule for D1;
  - D1 open = the signal-day open;
  - a −5% dip threshold;
  - the volume window shifted a day.
- **Universe and matching:**
  - ETFs in the percentiles;
  - the market mean including ETFs;
  - picked stocks used as look-alikes;
  - 9 look-alikes instead of 10.
- **Claim rules:**
  - claim 1 cut at 25%;
  - claim 5 thirds swapped;
  - claim 6 FAST needing a further rise;
  - claim 7 sign flipped;
  - claim 9 on RSI;
  - TRUE given by one cell instead of four;
  - R1 picking the biggest rises;
  - claim 3 cells swapped.
- **Gate, populations and guards:**
  - a gate tolerance of 1 point;
  - the period split in 2023;
  - NO ATR picks not counted as jumpy;
  - another example seed;
  - the output guard off;
  - the rerun guard off;
  - ranks 1-4 judged.

**Fixed while building (synthetic data only, before any real run):**
- pandas 3 read-only arrays.
- The volume burst ignored the D1 next-session rule.
- Percentiles stored as float32 put picks at exactly the 20% boundary on the wrong side of the claim 1 cut; they are float64 now.
- The memory use was cut by passing only the needed columns.
- Test worlds were redesigned three times:
  - Event drift made the market fall.
  - A compensating drift made non-event days rise.
  - Both are now drift-neutral one-day crashes.

  Each time the tool reported the world correctly ("BUILDS TO D5"); the world was wrong, not the tool.

**Not in v1.0:** part K, what D itself relies on. It needs D's stage D script and `stage_d.json`. Its rules are fixed in the declaration's `model_part`, and it will ship as a separate command with its own declaration once the files are in.
