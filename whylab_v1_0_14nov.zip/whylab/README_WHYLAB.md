# whylab v1.0 — are the 14 Nov claims about the model's picks true?

**Question (Karan, 14 Nov 2026).** 20:14: "Let's try to understand in detail what the model REALLY relies on? And what drives the momentum after the stock is picked by the model?" 20:22, after Claude's answer: "No no no. No assumptions. Lets test on pc and come to a concerete sure shot valuable reliable conclusion."

**What it does.** Every claim Claude made at 20:14 is checked on every pick of the frozen engines, against every other stock of the same day. Every measure, threshold and rule is fixed in **`WHY_DECLARATION.json`** (14 Nov 2026, before any run on real data). `whylab.py` refuses any other version of that file.

**The picks.** Every pick in setuplab's newest TREE run: D and ENS, ranks 1–10, 2020-01-16 to 2026-09-15, ETFs out. Verdicts use ranks 1–3, the traded book. Ranks 1–10 are shown beside them without a verdict. Calm and jumpy picks use the tree's own lanes.

**"Every other stock that day".** Every symbol in `panel_oc` on the signal day (the engines' candidate list), ETFs out.

**The outcome.** Buy at the D1 open, sell at the D5 close, 0.35 points of costs. This is the tree's own D1 net, and the run checks that it gives the same number on at least 99% of picks before judging anything. The pick's **own move** is its return from the D1 open minus the average stock's return over the same days.

**How a claim becomes TRUE.** Each claim is judged in four cells: D and ENS, each in 2020–23 and in 2024–26. Every cell has a 95% interval (blocks of 10 signal days, 2,000 resamples). TRUE needs the claim in all four.

| # | Claim | What is measured |
|---|---|---|
| 1 | Picks come after a hard fall | Share of picks in the day's bottom 20% by 5-day return (chance is 20%). The same for RSI 7, 20-day position, 20- and 60-day return. |
| 2 | Picks are the most volatile stocks | Share in the day's top 20% by ATR % |
| 3 | A simple rule could do the model's job | R1 = the 3 stocks with the biggest 5-day fall in ATRs, R2 = the 3 with the lowest RSI 7, vs the engine's ranks 1–3, same days, paired |
| 4 | The gain is the model's choice, not only the type of stock | Each pick vs its 10 look-alikes: unpicked stocks of the same day nearest in 5-day return and ATR % |
| 5 | It is a rebound: a bigger fall, a bigger gain | Own move to D5 of the most-fallen third of picks minus the least-fallen third. The same for all stocks is shown beside it. |
| 6 | It is fast | Own move from the D1 open to the D2 close, and from the D2 close to the D5 close |
| 7 | It fades after D5 | Own move from the D5 close to the D10 close (and to the D6 open) |
| 8 | It comes with a volume burst | D1–D3 volume vs the stock's own 20-day average, and vs the look-alikes' |
| 9 | Closing near the 20-day low warns of a further fall first | Share touching −8% under the D1 open by D5: the third closest to the 20-day low minus the farthest |
| 10 | News or results drive the move | **Not tested.** The pipeline has no announcement data, and nothing stands in for it. |

The report also shows what the picks look like on the signal day (15 measures, as percentiles of the day), the average path D1–D10, and **12 example picks drawn at random** (seed 7) rather than chosen.

**Part K — what D itself relies on — is not in v1.0.** It needs D's own training code (stage D's script and `stage_d.json`). With them, D's 5 folds are rebuilt, the rebuild must reproduce the frozen scores, and then one group of inputs at a time is scrambled to count the picks and money lost. The rules are already fixed in the declaration's `model_part`.

## Install and run

Unzip into `C:\Users\karanvsi\PyCharmMiscProject`. This adds a new `whylab` folder beside tradelab and setuplab; nothing else changes.

```
cd /d C:\Users\karanvsi\PyCharmMiscProject
tar -xf "%USERPROFILE%\Downloads\whylab_v1_0_14nov.zip"
call whylab\env_whylab.bat
python tests\test_whylab.py
python whylab.py check
python whylab.py run --root %CACHE_DAILY_ROOT%
```

The test must end `VERIFIED (whylab v1.0)`. The run prints progress every 100 symbols, then a `RESULT:` line and `DONE`. A second run is refused unless `--rerun-reason "<a verified bug>"` is given, and the ledger records the reason.

**Outputs** (`C:\QuantData\whylab\runs\WHY_<date>_<nnn>\`):
- `REPORT.md`: the verdicts first, then each claim cell by cell, the rules, the signal-day profile, the path, the examples and the data checks.
- `claims.csv`: every cell of every claim, for all, calm, jumpy and ranks 1–10.
- `profile.csv`, `path.csv`, `rules.csv`, `examples.csv`.
- `picks.parquet`: every pick with every measure and outcome.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- One line per run in `C:\QuantData\whylab\whylab_ledger.jsonl`.

**Reads only:** setuplab's newest TREE run (hash-checked), `panel_oc` (timestamp and symbol only), every universe stock's daily bars through tradelab's loader (production's stage E), setuplab's `TREE.json` ETF names, and NSE's ETF list when present. **Writes only** under `WHYLAB_OUT`.

**If the run stops** with `STOPPED:` (the gate), nothing is written. Send the screen: it means the bars here and the tree's prices disagree on more than 1% of picks.

## Tests (`tests\test_whylab.py`, 19 checks)

- **By hand:**
  - every measure and outcome against an independent loop, including a suspended session;
  - the day frame (percentiles, ETFs out, the market's mean, the excess);
  - the look-alike controls;
  - the rules' daily top 3 (ties by symbol, a missing outcome left out);
  - every claim's rule on made-up pick tables where the claim is planted, absent, reversed, or explained by the type.
- **Whole runs on synthetic caches** in the real layouts (daily bars, NIFTY50, panel_oc, a setuplab TREE run, tradelab's production stand-ins):
  - **PLANTED**: one-day crashes, a D1–D2 rebound on 3× volume, flat to D5, a fade over D6–D10; half close at their low and dip 10% on D1. Claims 1, 5–9 come out TRUE, and R1 (the engines' own rule) matches the model.
  - **FALLEN**: the same picks with nothing after. Claim 1 is TRUE and no after-the-pick claim is.
  - **RANDOM**: nothing is TRUE.
- **Each cell's picks by hand:** the period split, lanes, ranks and ETFs, and the 12 examples equal the declared draw.
- **The gate:** a tree whose D1 net is off on 2% of picks stops the run, and nothing is written.
- **Guards:** outputs and their hashes, the ledger, the rerun guard, and refusals (output inside the cache, no `--root`, no setuplab output).
- **Planted bugs:** 26 of them, each caught (see MANIFEST).
