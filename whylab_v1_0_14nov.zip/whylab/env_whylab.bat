@echo off
rem env_whylab.bat - whylab v1.0 (are Claude's 14 Nov claims about the model's picks true?): start a session.
rem   call C:\Users\karanvsi\PyCharmMiscProject\whylab\env_whylab.bat
rem Reads production (the daily cache through stage E's loader, panel_oc) and setuplab's newest TREE run READ ONLY,
rem through tradelab and setuplab (their code used unchanged). Writes only under WHYLAB_OUT.
set "BIGMOVE_DIR=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy"
set "TRADELAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\tradelab"
set "SETUPLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\setuplab"
set "SETUPLAB_OUT=C:\QuantData\setuplab"
set "WHYLAB_DIR=C:\Users\karanvsi\PyCharmMiscProject\whylab"
set "WHYLAB_OUT=C:\QuantData\whylab"
if not exist "%BIGMOVE_DIR%\env_daily.bat" goto :no_env
if not exist "%TRADELAB_DIR%\tl_data.py" goto :no_tradelab
if not exist "%SETUPLAB_DIR%\setuplab.py" goto :no_setuplab
call "%BIGMOVE_DIR%\env_daily.bat"
if "%CACHE_DAILY_ROOT%"=="" goto :no_root
set "PYTHONPATH=%WHYLAB_DIR%;%TRADELAB_DIR%;%SETUPLAB_DIR%;%BIGMOVE_DIR%\open_close;%BIGMOVE_DIR%"
if not exist "%WHYLAB_OUT%" mkdir "%WHYLAB_OUT%"
cd /d "%WHYLAB_DIR%"
echo whylab ready: CACHE_DAILY_ROOT=%CACHE_DAILY_ROOT%   SETUPLAB_OUT=%SETUPLAB_OUT%   WHYLAB_OUT=%WHYLAB_OUT%
goto :eof
:no_env
echo ERROR: %BIGMOVE_DIR%\env_daily.bat not found - edit BIGMOVE_DIR at the top of env_whylab.bat
exit /b 1
:no_tradelab
echo ERROR: %TRADELAB_DIR%\tl_data.py not found - whylab reads the bars through tradelab's tl_data (edit TRADELAB_DIR)
exit /b 1
:no_setuplab
echo ERROR: %SETUPLAB_DIR%\setuplab.py not found - whylab uses setuplab's bootstrap, ATR and ETF rule (edit SETUPLAB_DIR)
exit /b 1
:no_root
echo ERROR: env_daily.bat ran but CACHE_DAILY_ROOT is empty
exit /b 1
