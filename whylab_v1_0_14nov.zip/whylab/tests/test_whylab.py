"""
tests/test_whylab.py - whylab v1.0 self-test.

    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\whylab
    python tests\\test_whylab.py

By hand: every measure and outcome against an independent loop (with a suspended session); the look-alike controls;
the rules' daily top 3 (ties by symbol), their overlap and means; every claim's cell and verdict on made-up pick tables
where the claim is planted, absent or reversed. Then whole runs on synthetic caches in the real file layouts (daily
bars, NIFTY50, panel_oc, a setuplab TREE run; tradelab's production stand-ins):
  PLANTED - stocks crash over 5 days, rebound on D1-D2 with 3x volume, sit still to D5, give back on D6-D10; half
            close the crash at their low and dip 10% on D1; the engines pick the biggest falls in ATRs
  FALLEN  - the same picks by fall, but no rebound, no volume, no dip: the after-the-pick claims must not hold
  RANDOM  - random picks, nothing planted: the signal-day claims must not hold either
and the gate (a tree whose D1 net is off on 2% of picks stops the run, nothing written), outputs and their hashes,
the ledger and the rerun guard, and the refusals. Ends 'VERIFIED (whylab v1.0)' when every check passes; exit 1
otherwise.
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
for _v in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "WHYLAB_OUT", "SETUPLAB_OUT"):
    os.environ.pop(_v, None)
import tl_data as TD  # noqa: E402
sys.path.insert(0, str(Path(TD.__file__).resolve().parent / "tests"))
import tl_world as W  # noqa: E402
import whylab as WY  # noqa: E402

SL = WY.libs()
RESULTS = []
IST = "Asia/Kolkata"


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(("  ok   " if ok else "  FAIL ") + name + ("" if ok else f"\n         {str(detail)[:900]}"), flush=True)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = fn(*a, **k)
    return rc, buf.getvalue()


def close(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


# ---------------------------------------------------------------------------------------------------- by hand
def hand_measures(o, h, l, c, v, dates, cal):
    """An independent loop for every measure and outcome (the declaration's words, written out)."""
    n = len(c)
    M = {k: np.full(n, np.nan) for k in WY.MEASURES + WY.OUT_COLS}
    ag = al = None
    rsi = np.full(n, np.nan)
    for t in range(1, n):
        d = c[t] - c[t - 1]
        g_, l_ = max(d, 0.0), max(-d, 0.0)
        ag = g_ if ag is None else ag + (g_ - ag) / 7
        al = l_ if al is None else al + (l_ - al) / 7
        rsi[t] = 100 - 100 / (1 + ag / al) if al > 0 else (100.0 if ag > 0 else 50.0)
    calpos = {d: i for i, d in enumerate(cal)}
    for t in range(n):
        for k in (1, 5, 20, 60):
            if t >= k:
                M[f"ret{k}"][t] = c[t] / c[t - k] - 1
        if t >= WY.RSI_SKIP:
            M["rsi7"][t] = rsi[t]
        if t >= 19:
            lo, hi = min(l[t - 19:t + 1]), max(h[t - 19:t + 1])
            M["pos20"][t] = (c[t] - lo) / (hi - lo) if hi > lo else np.nan
            M["value20"][t] = float(np.median(c[t - 19:t + 1] * v[t - 19:t + 1]))
        if t >= 251:
            M["lo52"][t] = c[t] / min(l[t - 251:t + 1]) - 1
            M["hi52"][t] = c[t] / max(h[t - 251:t + 1]) - 1
        if t >= 14:
            tr = [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(t - 13, t + 1)]
            M["atrp"][t] = np.mean(tr) / c[t]
        if t >= 20:
            M["vol20"][t] = float(np.std([c[i] / c[i - 1] - 1 for i in range(t - 19, t + 1)], ddof=1))
            M["vratio"][t] = v[t] / np.mean(v[t - 20:t])
        M["price"][t] = c[t]
        for nn in (3, 10):
            if t >= nn:
                den = sum(abs(c[i] - c[i - 1]) for i in range(t - nn + 1, t + 1))
                M[f"sde{nn}"][t] = max(-1.0, min(1.0, (c[t] - c[t - nn]) / den)) if den > 1e-12 else np.nan
        # outcomes
        ci = calpos.get(dates[t])
        if t + 1 < n and ci is not None and ci + 1 < len(cal) and dates[t + 1] == cal[ci + 1]:
            o1 = o[t + 1]
            for k in range(1, 11):
                if t + k < n:
                    M[f"r{k}"][t] = (c[t + k] / o1 - 1) * 100
            if t + 6 < n:
                M["open6"][t] = (o[t + 6] / o1 - 1) * 100
            if t + 5 < n:
                M["dn8"][t] = float(min(l[t + 1:t + 6]) / o1 - 1 <= -0.08)
            if t >= 20 and t + 3 < n:
                va = np.mean(v[t - 20:t])
                M["vb"][t] = np.mean([np.log(v[t + k] / va) for k in (1, 2, 3)])
    return M


class DS:
    def __init__(self, dates, o, h, l, c, v):
        self.dates, self.o, self.h, self.l, self.c, self.v = dates, o, h, l, c, v


def t1_declaration():
    d, sha = WY.load_decl()
    rc, out = quiet(WY.main, ["check"])
    tmp = Path(tempfile.mkdtemp(prefix="whylab_decl_"))
    try:
        bad = tmp / "WHY_DECLARATION.json"
        bad.write_bytes(WY.DECL_FILE.read_bytes().replace(b"35", b"36", 1))
        try:
            WY.load_decl(bad)
            refused = False
        except WY.WHError:
            refused = True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    check("t1 the declaration is the pinned one (claims 1-10, the gate, the model part's rules); a changed copy is "
          "refused; 'check' runs", sha == WY.DECL_SHA and len(d["claims"]) == 10 and refused and rc == 0 and
          "OK" in out and "gate" in d and "families" in d["model_part"], (sha[:16], rc, out))


def t2_measures():
    rng = np.random.default_rng(3)
    cal = np.arange(np.datetime64("2021-01-01"), np.datetime64("2022-06-30")).astype("datetime64[D]")
    cal = cal[np.isin((cal.astype("datetime64[D]").view("int64") - 4) % 7, [0, 1, 2, 3, 4])]   # Mon-Fri
    n = len(cal)
    keep = np.ones(n, bool)
    keep[300] = False                                   # suspended one session: bar 299's D1 is not the next session
    dates = cal[keep]
    m = len(dates)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, m)))
    o = np.r_[100, c[:-1]] * np.exp(rng.normal(0, 0.005, m))
    h = np.fmax(o, c) * np.exp(np.abs(rng.normal(0, 0.01, m)))
    l = np.fmin(o, c) * np.exp(-np.abs(rng.normal(0, 0.01, m)))
    l[200] = o[200] * 0.85                              # a deep low inside D1..D5 of bars 195..199
    v = rng.lognormal(10, 0.5, m)
    F = WY.stock_arrays(SL, DS(dates, o, h, l, c, v), cal)
    H = hand_measures(o, h, l, c, v, list(dates), list(cal))
    bad = [k for k in WY.MEASURES + WY.OUT_COLS if not close(F[k], H[k], 1e-9)]
    sus = int(np.searchsorted(dates, cal[299]))
    check("t2 every measure and outcome = an independent loop (RSI 7, 20-day position, 52-week distances, simple ATR, "
          "volatility, volume ratio, rupees traded, SDE, D1..D10, D6 open, the -8% dip, D1-D3 volume); a session "
          "after a suspension has no outcome", not bad and np.isnan(F["r5"][sus]) and np.isfinite(F["r5"][sus - 1])
          and F["dn8"][196] == 1.0 and np.isnan(F["rsi7"][WY.RSI_SKIP - 1]) and np.isfinite(F["rsi7"][WY.RSI_SKIP]),
          {k: (np.nanmax(np.abs(F[k] - H[k])) if np.isfinite(F[k] - H[k]).any() else "all nan") for k in bad})


def t3_controls():
    d = np.datetime64("2023-05-02")
    syms = [f"A{i:02d}" for i in range(30)]
    rng = np.random.default_rng(4)
    T = pd.DataFrame({"day": pd.to_datetime([d] * 30), "symbol": syms, "etf": False,
                      "p_ret5": rng.uniform(0, 1, 30), "p_atrp": rng.uniform(0, 1, 30), "r5": rng.normal(0, 3, 30),
                      "vb": rng.normal(0, 1, 30), "picked": False})
    T.loc[[3, 7], "picked"] = True
    T.loc[11, "r5"] = np.nan                             # no outcome: never a control
    T.loc[12, ["p_ret5", "p_atrp"]] = [T.loc[3, "p_ret5"], T.loc[3, "p_atrp"]]   # a twin of pick 3 (distance 0)
    T.loc[13, ["p_ret5", "p_atrp"]] = [T.loc[3, "p_ret5"], T.loc[3, "p_atrp"]]   # and another: ties by symbol
    C = WY.controls(T, log=lambda *a: None).set_index("symbol")
    ok = True
    for q in (3, 7):
        cand = T[(~T.picked) & T.r5.notna()]
        dist = np.sqrt((cand.p_ret5 - T.p_ret5[q]) ** 2 + (cand.p_atrp - T.p_atrp[q]) ** 2)
        nn = cand.assign(dd=dist).sort_values(["dd", "symbol"]).head(10)
        r = C.loc[syms[q]]
        ok &= abs(r.c_r5 - nn.r5.mean()) < 1e-12 and abs(r.c_vb - nn.vb.mean()) < 1e-12 and r.c_n == 10 and \
            abs(r.c_dist - nn.dd.mean()) < 1e-12
    check("t3 look-alike controls = the 10 nearest unpicked stocks of the day in (5-day return, ATR %) percentile, "
          "with an outcome, ties by symbol (by hand)", ok and len(C) == 2, C)


def t3b_day_frame():
    d1, d2 = pd.Timestamp("2023-01-02"), pd.Timestamp("2024-02-05")
    rng = np.random.default_rng(9)
    rows = []
    for d in (d1, d2):
        for i in range(8):
            r = {"day": d, "symbol": ("NIFTYBEES" if i == 7 else f"C{i}")}
            for m in WY.MEASURES:
                r[m] = float(rng.normal())
            for k in WY.OUT_COLS:
                r[k] = float(rng.normal())
            rows.append(r)
    T = pd.DataFrame(rows)
    T.loc[2, "ret5"] = np.nan
    P = pd.DataFrame({"day": [d1], "symbol": ["C3"]})
    T2, Ud, info = WY.day_frame(SL, T, P, Path(tempfile.gettempdir()) / "no_such_cache")
    ok = info["etf_rows"] == 2 and T2["picked"].sum() == 1
    for d in (d1, d2):
        G = T2[(T2.day == d) & ~T2.etf]
        for m in ("ret5", "atrp"):
            v = G[m].to_numpy(float)
            fin = np.isfinite(v)
            want = pd.Series(v[fin]).rank(pct=True).to_numpy()
            ok &= np.allclose(G[f"p_{m}"].to_numpy(float)[fin], want, atol=1e-6) and \
                bool(np.isnan(G[f"p_{m}"].to_numpy(float)[~fin]).all())
        u5 = G["r5"].mean()
        ok &= abs(Ud.set_index("day").loc[d, "u_r5"] - u5) < 1e-12 and \
            np.allclose(G["x_r5"], G["r5"] - u5, atol=1e-12) and bool(T2[(T2.day == d) & T2.etf][f"p_ret5"].isna().all())
    check("t3b the day frame by hand: percentiles among the day's stocks (ETFs out, a blank value stays blank), the "
          "day's mean outcome over the universe, the excess, the pick flags", ok, info)


def t4_rules():
    d1, d2 = pd.Timestamp("2023-01-02"), pd.Timestamp("2024-03-04")
    rows = []
    for d, off in ((d1, 0.0), (d2, 1.0)):
        for i in range(12):
            rows.append({"day": d, "symbol": f"B{i:02d}", "etf": i == 0, "ret5": -0.01 * (12 - i), "atrp": 0.02,
                         "rsi7": 50 - i if i != 5 else 10.0, "net5": float(i) + off, "value20": 1e7 * (i + 1)})
    T = pd.DataFrame(rows)
    T.loc[(T.day == d1) & (T.symbol == "B02"), "ret5"] = -0.11            # ties B01 at -0.11: symbol order wins
    T.loc[(T.day == d2) & (T.symbol == "B03"), "net5"] = np.nan          # chosen by R1 but no outcome: left out
    Q = pd.DataFrame({"day": [d1, d1, d1, d2], "engine": ["D", "D", "ENS", "D"], "rank": [1, 2, 1, 1],
                      "symbol": ["B05", "B09", "B01", "B11"], "etf": False, "net5": [5.0, 9.0, 1.0, 12.0],
                      "value20": [6e7, 1e8, 2e7, 1.2e8]})
    R = WY.rules_daily(T, Q).set_index("day")
    r1 = R.loc[d1]
    ok = (abs(r1["R1"] - np.mean([1.0, 2.0, 3.0])) < 1e-12 and abs(r1["R2"] - np.mean([5.0, 11.0, 10.0])) < 1e-12 and
          abs(r1["D"] - 7.0) < 1e-12 and abs(r1["ENS"] - 1.0) < 1e-12 and abs(r1["all"] - np.mean(range(1, 12))) < 1e-12
          and abs(r1["D_in_R2_top10"] - 1.0) < 1e-12 and abs(r1["ENS_in_R1_top10"] - 1.0) < 1e-12 and
          abs(R.loc[d2, "R1"] - np.mean([2.0, 3.0])) < 1e-12 and np.isnan(R.loc[d2, "ENS"]))
    check("t4 the rules' top 3 a day by hand (R1 lowest 5-day fall in ATRs, R2 lowest RSI 7; ETFs out, ties by symbol, "
          "a chosen stock without an outcome left out), the model's ranks 1-3, everything, the top-10 overlap", ok, R.T)


def make_Q(kind, seed=5, n1=700, n2=300):
    """A made-up pick table: 3 picks a day per engine; each claim planted ('planted'), absent, reversed ('reverse')
    or with the type explaining the gain ('type')."""
    rng = np.random.default_rng(seed)
    days = pd.bdate_range("2020-01-01", periods=n1).append(pd.bdate_range("2024-01-01", periods=n2))
    rows = []
    for e in WY.ENGINES:
        for t, d in enumerate(days):
            for rk in (1, 2, 3):
                rows.append((e, rk, d))
    Q = pd.DataFrame(rows, columns=["engine", "rank", "day"])
    n = len(Q)
    Q["etf"] = False
    Q["lane"] = np.where(rng.random(n) < 0.5, "CALM", "JUMPY")
    Q["period"] = np.where(Q["day"] < pd.Timestamp("2024-01-01"), "P1", "P2")
    u = rng.uniform(0, 1, n)
    if kind in ("planted", "type", "reverse"):
        Q["p_ret5"] = 0.15 * u
        Q["p_atrp"] = 0.85 + 0.15 * rng.uniform(0, 1, n)
    else:
        Q["p_ret5"] = u
        Q["p_atrp"] = rng.uniform(0, 1, n)
    for nm in ("rsi7", "pos20", "ret20", "ret60"):
        Q[f"p_{nm}"] = rng.uniform(0, 1, n)
    eps = lambda s=1.0: rng.normal(0, s, n)                                    # noqa: E731
    Q["pos20"] = rng.uniform(0, 1, n)
    Q["rsi7"] = rng.uniform(10, 60, n)
    Q["sde3"] = rng.uniform(-1, 1, n)
    Q["u_r5"] = eps(0.5)
    if kind == "planted":
        Q["x_r2"] = 2 + eps()
        Q["x_r5"] = Q["x_r2"] - 20 * Q["p_ret5"] + 1.5 + eps(0.3)
        Q["x_r10"] = Q["x_r5"] - 1 + eps()
        Q["vb"], Q["c_vb"] = 1 + eps(0.5), 0.2 + eps(0.5)
        Q["dn8"] = (rng.random(n) < np.where(Q["pos20"] < 1 / 3, 0.6, 0.1)).astype(float)
    elif kind == "reverse":
        Q["x_r2"] = eps()
        Q["x_r5"] = Q["x_r2"] + 2 + 20 * Q["p_ret5"] + eps(0.3)
        Q["x_r10"] = Q["x_r5"] + 1 + eps()
        Q["vb"], Q["c_vb"] = -0.5 + eps(0.5), eps(0.5)
        Q["dn8"] = (rng.random(n) < np.where(Q["pos20"] < 1 / 3, 0.1, 0.6)).astype(float)
    else:
        Q["x_r2"] = eps()
        Q["x_r5"] = Q["x_r2"] + eps() + (1.5 if kind == "type" else 0.0)
        Q["x_r10"] = Q["x_r5"] + eps()
        Q["vb"], Q["c_vb"] = eps(0.5), eps(0.5)
        Q["dn8"] = (rng.random(n) < 0.2).astype(float)
    Q["x_open6"] = Q["x_r5"] + eps(0.5)
    Q["r5"] = Q["x_r5"] + Q["u_r5"]
    if kind == "planted":
        Q["c_r5"] = Q["r5"] - 1.5 + eps()
    elif kind == "reverse":
        Q["c_r5"] = Q["r5"] + 1.5 + eps()
    elif kind == "type":
        Q["c_r5"] = Q["r5"].copy()                    # the look-alikes do exactly as well
    else:
        Q["c_r5"] = Q["u_r5"] + eps(2.0)
    return Q


def t5_claim_logic():
    S = WY.Stat(SL, make_Q("absent")["day"].to_numpy())
    got = {}
    for kind in ("planted", "absent", "reverse", "type"):
        C = WY.claim_cells(S, make_Q(kind), "ALL", 3)
        got[kind] = {cid: WY.verdict(cid, c) for cid, c in C.items()}
    want = {"planted": {1: "TRUE", 2: "TRUE", 4: "MODEL ADDS", 5: "TRUE", 6: "TRUE", 7: "TRUE", 8: "TRUE", 9: "TRUE"},
            "absent": {1: "FALSE", 2: "FALSE", 5: "NOT RELIABLE", 6: "MIXED", 7: "NOT RELIABLE", 8: "NOT SHOWN",
                       9: "NOT RELIABLE"},
            "reverse": {4: "MODEL WORSE", 5: "MOMENTUM", 6: "BUILDS TO D5", 7: "KEEPS GOING", 8: "NOT SHOWN",
                        9: "NOT RELIABLE"},
            "type": {4: "TYPE EXPLAINS"}}
    bad = {k: {c: (got[k][c], v) for c, v in w.items() if got[k][c] != v} for k, w in want.items()}
    bad = {k: v for k, v in bad.items() if v}
    check("t5 every claim's rule on made-up pick tables: planted -> TRUE (and the model adds), absent -> not shown, "
          "reversed -> MOMENTUM / BUILDS TO D5 / KEEPS GOING / MODEL WORSE, look-alikes as good -> TYPE EXPLAINS",
          not bad and got["absent"][4] not in ("MODEL ADDS", "MODEL WORSE"), bad or got)
    # a MOST / MORE THAN CHANCE / NO ladder for claim 1 by hand
    Q = make_Q("absent")
    Q["p_ret5"] = np.where(np.random.default_rng(1).random(len(Q)) < 0.35, 0.1, 0.6)
    c = WY.claim_cells(S, Q, "ALL", 3)[1]
    m = WY.mask_of(Q, "D", "P1")
    share = 100 * np.mean(Q.loc[m, "p_ret5"] <= 0.2)
    check("t5b claim 1 by hand: 35% of picks in the bottom 20% -> MORE THAN CHANCE in each cell -> PARTLY; the share "
          "is the plain share", WY.verdict(1, c) == "PARTLY" and abs(c[("D", "P1")]["stat"] - share) < 1e-9 and
          c[("D", "P1")]["lo"] < share < c[("D", "P1")]["hi"], c[("D", "P1")])


def t6_claim3_logic():
    rng = np.random.default_rng(8)
    days = pd.bdate_range("2020-01-01", periods=700).append(pd.bdate_range("2024-01-01", periods=300))
    base = rng.normal(0, 2, len(days))
    R = pd.DataFrame({"day": days, "period": np.where(days < pd.Timestamp("2024-01-01"), "P1", "P2"), "all": base})
    for k in ("D", "ENS", "R1", "R2"):
        for c in ("_value20",):
            R[k + c] = 1e7
    for e in WY.ENGINES:
        for rk in WY.RULES:
            R[f"{e}_in_{rk}_top10"] = 0.5
    R["D"] = base + 1.0 + rng.normal(0, 1, len(days))
    R["ENS"] = base + 1.0 + rng.normal(0, 1, len(days))
    R["R1"] = base + 1.0 + rng.normal(0, 1, len(days))            # as good as the model
    R["R2"] = base + rng.normal(0, 1, len(days))                  # no edge: the model is better
    S = WY.Stat(SL, days.to_numpy())
    a = WY.claim3(S, R)
    R2 = R.copy()
    R2["R1"] = base + rng.normal(0, 1, len(days))
    R2["D"] = R2["ENS"] = base + rng.normal(0, 1, len(days))      # nothing has an edge
    b = WY.claim3(S, R2)
    check("t6 claim 3's rule: a rule as good as the model with an edge -> MATCHES THE MODEL; a rule without one -> "
          "MODEL BETTER; no edge anywhere -> MIXED (RULE HAS NO EDGE)", a["R1"]["verdict"] == "MATCHES THE MODEL" and
          a["R2"]["verdict"] == "MODEL BETTER" and b["R1"]["verdict"] == "MIXED" and
          all(v["cell"] == "RULE HAS NO EDGE" for k, v in b["R1"]["cells"].items() if k[1] != "ALL"),
          (a["R1"]["verdict"], a["R2"]["verdict"], b["R1"]["verdict"]))


# ---------------------------------------------------------------------------------------------------- worlds
def hand_atr(h, l, c):
    tr = np.full(len(c), np.nan)
    tr[1:] = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    return pd.Series(tr).rolling(14, min_periods=14).mean().to_numpy() / c


def make_world(root: Path, kind: str, seed: int, n_stocks: int = 90, bad_net: float = 0.0) -> dict:
    """Daily bars + NIFTY50 + panel_oc + a setuplab TREE run. kind: planted / fallen / random (module docstring)."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-01-01", "2025-06-30")
    cal = cal[~((cal.month == 1) & (cal.day == 26))]
    n = len(cal)
    W.write_mods(root)
    W.use_mods(root)
    S = n_stocks
    sig = rng.uniform(0.012, 0.04, S)
    lr = rng.normal(0, 1, (S, n)) * sig[:, None]
    vm = rng.lognormal(0, 0.3, (S, n))
    ev = np.zeros((S, n), bool)
    atlow = np.zeros((S, n), bool)
    if kind == "planted":                     # one-day crashes, so the freshest falls lead each day's ranking
        add = np.zeros((S, n))
        for s in range(S):
            t = 30
            while t < n - 12:
                if rng.random() < 0.12:
                    dep = rng.uniform(1.0, 1.5)
                    add[s, t] += -10.0 * dep * sig[s]
                    add[s, t + 1:t + 3] += 6.5 * dep * sig[s]
                    add[s, t + 6:t + 11] += -0.6 * dep * sig[s]
                    vm[s, t + 1:t + 4] *= 3.0
                    ev[s, t] = True
                    atlow[s, t] = rng.random() < 0.5
                    t += 11
                else:
                    t += 1
        lr += add                              # each event nets to zero: -10 + 2 x 6.5 - 5 x 0.6 (no drift added)
    C = 100 * np.exp(np.cumsum(lr, axis=1))
    O = np.concatenate([np.full((S, 1), 100.0), C[:, :-1]], axis=1) * np.exp(rng.normal(0, 0.2, (S, n)) * sig[:, None])
    Hh = np.fmax(O, C) * np.exp(np.abs(rng.normal(0, 0.5, (S, n))) * sig[:, None])
    Ll = np.fmin(O, C) * np.exp(-np.abs(rng.normal(0, 0.5, (S, n))) * sig[:, None])
    for s, t in zip(*np.nonzero(ev)):
        if atlow[s, t]:                        # closes at its low, then dips 10% under the D1 open
            O[s, t] = max(O[s, t], C[s, t] * 1.01)
            Hh[s, t] = max(Hh[s, t], O[s, t])
            Ll[s, t] = C[s, t]
            Ll[s, t + 1] = min(Ll[s, t + 1], O[s, t + 1] * 0.90)
        else:                                  # closes well off its low
            Ll[s, t] = min(Ll[s, t], C[s, t] * np.exp(-1.5 * sig[s]))
    V = rng.lognormal(12, 0.6, S)[:, None] * vm
    syms = [f"S{i:03d}" for i in range(S)]
    daily = {}
    gone = {"S005": 400, "S017": 900}                     # suspended sessions (no bar)
    for i, s in enumerate(syms):
        df = pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": O[i], "high": Hh[i], "low": Ll[i], "close": C[i],
                           "volume": V[i]})
        if s in gone:
            df = df.drop(index=gone[s]).reset_index(drop=True)
        daily[s] = df
        df.to_parquet(root / f"{s}_daily.parquet", index=False)
    for e_, sg in (("NIFTYBEES", 0.006), ("GOLDBEES", 0.005)):
        c = 100 * np.exp(np.cumsum(rng.normal(0, sg, n)))
        o = np.r_[100, c[:-1]]
        daily[e_] = pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": o, "high": np.fmax(o, c) * 1.002,
                                  "low": np.fmin(o, c) * 0.998, "close": c, "volume": 1e6})
        daily[e_].to_parquet(root / f"{e_}_daily.parquet", index=False)
    c = 18000 * np.exp(np.cumsum(rng.normal(0, 0.009, n)))
    pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": c, "high": c * 1.004, "low": c * 0.996, "close": c,
                  "volume": 1e6}).to_parquet(root / "NIFTY50_daily.parquet", index=False)
    allsyms = syms + ["NIFTYBEES", "GOLDBEES"]
    (root / "panel_oc").mkdir(exist_ok=True)
    pd.DataFrame({"timestamp": np.tile(cal.tz_localize(IST), len(allsyms)), "symbol": np.repeat(allsyms, n),
                  "D_rsi14": 50.0}).to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the engines' picks (independent hand formulas: 5-day return over the simple ATR)
    calD = cal.values.astype("datetime64[D]")
    pos = {s: {d: i for i, d in enumerate(daily[s]["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).values
                                         .astype("datetime64[D]"))} for s in allsyms}
    arr = {s: {k: daily[s][k].to_numpy(float) for k in ("open", "high", "low", "close")} for s in allsyms}
    for s in allsyms:
        a = arr[s]
        a["atr"] = hand_atr(a["high"], a["low"], a["close"])
        r5 = np.full(len(a["close"]), np.nan)
        r5[5:] = a["close"][5:] / a["close"][:-5] - 1
        a["sc"] = r5 / a["atr"]
    t_first = int(np.searchsorted(cal, pd.Timestamp("2020-01-16")))
    sidx = {s: i for i, s in enumerate(syms)}
    rows = []
    for t in range(t_first, n - 11):
        d = calD[t]
        cands = []
        for s in syms:
            i = pos[s].get(d)
            if i is not None and np.isfinite(arr[s]["sc"][i]):
                cands.append((s, i, arr[s]["sc"][i]))
        if kind == "random":
            noise_d, noise_e = rng.normal(0, 1, len(cands)), rng.normal(0, 1, len(cands))
            sd = noise_d
            se = noise_e
        else:                                  # the biggest 5-day falls in ATRs (R1) with a little noise
            sc = np.array([x[2] for x in cands])
            sd = -sc + 0.05 * rng.normal(0, 1, len(cands))
            se = -sc + 0.2 * rng.normal(0, 1, len(cands))
        for e_, sv in (("D", sd), ("ENS", se)):
            order = np.argsort(-sv, kind="stable")[:10]
            lst = [cands[j][0] for j in order]
            if e_ == "D" and rng.random() < 0.03:
                lst = lst[:2] + ["NIFTYBEES"] + lst[2:9]
            for rk, s in enumerate(lst, 1):
                i = pos[s].get(d)
                a = arr[s]
                ok = (i is not None and i + 5 < len(a["close"]) and
                      calD[t + 1] == daily[s]["timestamp"].iloc[i + 1].tz_convert(IST).tz_localize(None).to_datetime64()
                      .astype("datetime64[D]"))
                net = (a["close"][i + 5] / a["open"][i + 1] - 1) * 100 - 0.35 if ok else np.nan
                rows.append({"trade_id": f"{e_}-{pd.Timestamp(d):%Y%m%d}-{rk}", "engine": e_, "rank": rk, "symbol": s,
                             "signal_day": f"{pd.Timestamp(d):%Y-%m-%d}", "s_atr14": a["atr"][i] if i is not None
                             else np.nan, "etf": s.endswith("BEES"), "d1_net": net, "complete": bool(ok),
                             "year": pd.Timestamp(d).year})
    Tg = pd.DataFrame(rows)
    lane = np.full(len(Tg), "NO CUT-OFF", dtype=object)
    for y in sorted(Tg["year"].unique()):
        prior = Tg[(Tg["year"] < y) & Tg["complete"]]["s_atr14"].dropna()
        if len(prior) >= 100:
            cut = float(np.quantile(prior, 2 / 3))
            m = (Tg["year"] == y).to_numpy()
            a_ = Tg["s_atr14"].to_numpy(float)
            lane[m] = np.where(np.isfinite(a_[m]), np.where(a_[m] > cut, "JUMPY", "CALM"), "NO ATR")
    Tg["lane"] = lane
    noatr = rng.random(len(Tg)) < 0.02                      # a pick without a recorded ATR: the tree's NO ATR lane
    Tg.loc[noatr & (Tg["lane"] != "NO CUT-OFF").to_numpy(), "lane"] = "NO ATR"
    if bad_net:
        k = rng.choice(len(Tg), int(bad_net * len(Tg)), replace=False)
        Tg.loc[Tg.index[k], "d1_net"] += 0.5
    for c_, v_ in (("cutoff", np.nan), ("gap_pct", 0.0), ("opened_up", True), ("dip_2pct", False),
                   ("runner", False), ("first_setup", ""), ("setup_net", np.nan), ("bunch", ""), ("action", ""),
                   ("how", ""), ("in_book_start1", False)):
        Tg[c_] = v_
    Tg = Tg.drop(columns="year")
    sbase = root.parent / (root.name + "_setuplab")
    tr = SL.new_run_dir(sbase / "TREE", "TREE")
    Tg.to_parquet(tr / "tree_tags.parquet", index=False)
    (tr / "TREE_RUN.json").write_text(json.dumps({"version": "setuplab v1.1"}), encoding="utf-8")
    SL.write_hashes(tr, ["tree_tags.parquet", "TREE_RUN.json"])
    return {"root": root, "sbase": sbase, "tree": Tg, "ev": ev, "cal": cal, "syms": syms}


def run(w, out, extra=()):
    rc, log = quiet(WY.main, ["run", "--root", str(w["root"]), "--setups", str(w["sbase"]), "--out", str(out),
                              "--stage-e-any"] + list(extra))
    runs = sorted((Path(out) / "runs").glob("WHY_*")) if (Path(out) / "runs").exists() else []
    return rc, log, (runs[-1] if runs else None)


def t7_planted():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_planted_"))
    try:
        w = make_world(tmp / "cache", "planted", seed=11)
        rc, log, rd = run(w, tmp / "out")
        meta = json.loads((rd / "run.json").read_text()) if rd else {}
        V = meta.get("verdicts", {}).get("ALL", {})
        info = meta.get("info", {})
        check("t7 PLANTED world runs end to end; the gate passes (net here = the tree's D1 net on every complete pick); "
              "suspensions counted", rc == 0 and info.get("gate", {}).get("passed") and
              info["gate"]["share"] == 1.0 and info["bars"]["no_bar_that_day_rows"] > 0, log[-1500:])
        want = {"1": "TRUE", "5": "TRUE", "6": "TRUE", "7": "TRUE", "8": "TRUE", "9": "TRUE"}
        bad = {k: (V.get(k), v) for k, v in want.items() if V.get(k) != v}
        check("t7b PLANTED: picks after a hard fall TRUE; rebound TRUE; fast TRUE; fades TRUE; volume burst TRUE; the "
              "20-day-low warning TRUE", not bad, (bad, V))
        check("t7c PLANTED: the rule the engines use (R1, biggest fall in ATRs) MATCHES THE MODEL",
              meta.get("rules", {}).get("R1") == "MATCHES THE MODEL", meta.get("rules"))
        names = ["REPORT.md", "claims.csv", "profile.csv", "path.csv", "rules.csv", "examples.csv", "picks.parquet",
                 "run.json", "DECLARATION.json", "outputs.sha256"]
        hashes = {ln.split("  ")[1]: ln.split("  ")[0] for ln in (rd / "outputs.sha256").read_text().splitlines()}
        hok = all(WY.sha256(rd / k) == v for k, v in hashes.items()) and len(hashes) == 9
        Ex = pd.read_csv(rd / "examples.csv")
        rep = (rd / "REPORT.md").read_text(encoding="utf-8")
        check("t7d outputs: every file, hashes match, 12 examples (3 per engine x lane), the report opens with the "
              "verdicts and names claim 10 NOT TESTED", all((rd / k).is_file() for k in names) and hok and
              len(Ex) == 12 and sorted(Ex.groupby("group").size().tolist()) == [3, 3, 3, 3] and
              rep.index("## Verdicts") < rep.index("## 1.") and "NOT TESTED" in rep, (hok, len(Ex)))
        # every pick of the tree is there, measured from its own bars (two by hand)
        Q = pd.read_parquet(rd / "picks.parquet")
        Tg = w["tree"]
        q = Q[(Q.engine == "D") & (Q["rank"] == 1)].iloc[[100, 500]]
        ok = True
        for _, r in q.iterrows():
            df = pd.read_parquet(w["root"] / f"{r.symbol}_daily.parquet")
            dd = df["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).dt.normalize()
            i = int(np.flatnonzero(dd == pd.Timestamp(r.day))[0])
            c = df["close"].to_numpy()
            ok &= abs(r.ret5 - (c[i] / c[i - 5] - 1)) < 1e-6 and abs(r.r5 - (c[i + 5] / df["open"].iat[i + 1] - 1) *
                                                                     100) < 1e-9
        check("t7e every tree pick is in picks.parquet with its stock-day's numbers (two by hand)",
              len(Q) == len(Tg) and ok, (len(Q), len(Tg)))
        # the cells' populations by hand: periods split at 2024-01-01, lanes CALM / JUMPY (+ NO ATR), ranks 1-3
        Cl = pd.read_csv(rd / "claims.csv")
        Cl["claim"] = Cl["claim"].astype(str)
        okc = True
        for (lane, lanes) in (("ALL", None), ("CALM", ["CALM"]), ("JUMPY", ["JUMPY", "NO ATR"])):
            for e in ("D", "ENS"):
                for per, lo, hi in (("2020-23", "1900-01-01", "2023-12-31"), ("2024-26", "2024-01-01", "2100-01-01")):
                    m = (Q.engine == e) & ~Q.etf & (Q["rank"] <= 3) & (Q.day >= lo) & (Q.day <= hi) & \
                        Q.p_ret5.notna()
                    if lanes:
                        m &= Q.lane.isin(lanes)
                    row = Cl[(Cl.claim == "1") & (Cl.lane == lane) & (Cl.ranks == "1-3") & (Cl.engine == e) &
                             (Cl.period == per)]
                    okc &= len(row) == 1 and int(row.n.iloc[0]) == int(m.sum()) and \
                        abs(row.stat.iloc[0] - 100 * (Q.loc[m, "p_ret5"] <= 0.2).mean()) < 1e-6
        # the 12 examples are the declared draw
        need = list(WY.MEASURES) + [f"r{k}" for k in range(1, 11)] + ["dn8", "vb"]
        okx = (~Q.etf) & (Q["rank"] <= 3) & Q[need].notna().all(axis=1)
        rng = np.random.default_rng(7)
        want = []
        for e in ("D", "ENS"):
            for lanes in (["CALM"], ["JUMPY", "NO ATR"]):
                G = Q[okx & (Q.engine == e) & Q.lane.isin(lanes)].sort_values("trade_id")
                want += G["trade_id"].iloc[np.sort(rng.choice(len(G), 3, replace=False))].tolist()
        check("t7g each cell's picks by hand (periods split at 2024-01-01, calm / jumpy lanes, ranks 1-3, ETFs out) "
              "and the 12 examples = the declared random draw (seed 7)", okc and Ex["trade_id"].tolist() == want,
              (okc, Ex["trade_id"].tolist()[:4], want[:4]))
        # rerun guard
        rc2, log2, _ = run(w, tmp / "out")
        rc3, log3, rd3 = run(w, tmp / "out", ["--rerun-reason", "test"])
        led = [json.loads(x) for x in (tmp / "out" / WY.LEDGER).read_text().splitlines()]
        check("t7f a second run is refused without --rerun-reason; with one it runs and the ledger records both",
              rc2 == 2 and "rerun-reason" in log2 and rc3 == 0 and len(led) == 2 and led[1]["rerun_reason"] == "test",
              (rc2, rc3, len(led)))
        return w
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t8_fallen_random():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_absent_"))
    try:
        w = make_world(tmp / "cache", "fallen", seed=12)
        rc, log, rd = run(w, tmp / "out")
        meta = json.loads((rd / "run.json").read_text()) if rd else {}
        V = meta.get("verdicts", {}).get("ALL", {})
        bad = {k: V.get(k) for k in ("5", "6", "7", "8", "9") if V.get(k) == "TRUE"}
        check("t8 FALLEN world (picks by fall, nothing after): picks after a hard fall TRUE, but none of the after-the-"
              "pick claims is TRUE; R1 does not 'match' (no edge)", rc == 0 and V.get("1") == "TRUE" and not bad and
              meta.get("rules", {}).get("R1") != "MATCHES THE MODEL", (V, meta.get("rules"), log[-800:]))
        w2 = make_world(tmp / "cache2", "random", seed=13)
        rc, log, rd = run(w2, tmp / "out2")
        meta = json.loads((rd / "run.json").read_text()) if rd else {}
        V = meta.get("verdicts", {}).get("ALL", {})
        bad = {k: V.get(k) for k in V if V.get(k) in ("TRUE", "PARTLY", "MODEL ADDS")}
        check("t8b RANDOM world: no claim TRUE or PARTLY, the model adds nothing", rc == 0 and not bad and
              V.get("1") == "FALSE" and V.get("2") == "FALSE", (V, log[-800:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t9_gate_and_guards():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_gate_"))
    try:
        w = make_world(tmp / "cache", "random", seed=14, n_stocks=40, bad_net=0.02)
        rc, log, rd = run(w, tmp / "out")
        check("t9 the gate: a tree whose D1 net is off on 2% of picks STOPS the run (exit 3) before any claim; no run "
              "folder, no ledger line", rc == 3 and "STOPPED" in log and rd is None and
              not (tmp / "out" / WY.LEDGER).exists(), (rc, log[-600:]))
        rc, log = quiet(WY.main, ["run", "--root", str(w["root"]), "--setups", str(w["sbase"]),
                                  "--out", str(w["root"] / "x"), "--stage-e-any"])
        rc2, log2 = quiet(WY.main, ["run", "--setups", str(w["sbase"]), "--out", str(tmp / "o2")])
        rc3, log3 = quiet(WY.main, ["run", "--root", str(w["root"]), "--setups", str(tmp / "nothing"),
                                    "--out", str(tmp / "o3")])
        check("t9b refused: an output folder inside the cache, no --root (no default cache path), no setuplab output",
              rc == 2 and "never writes there" in log and rc2 == 2 and "--root" in log2 and rc3 == 2, (log, log2, log3))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    print(f"{WY.VERSION} self-test (pandas {pd.__version__}, numpy {np.__version__})", flush=True)
    for t in (t1_declaration, t2_measures, t3_controls, t3b_day_frame, t4_rules, t5_claim_logic, t6_claim3_logic, t7_planted,
              t8_fallen_random, t9_gate_and_guards):
        try:
            t()
        except Exception as e:                                  # noqa: BLE001
            import traceback
            check(f"{t.__name__} raised {type(e).__name__}: {e}", False, traceback.format_exc()[-1500:])
    bad = [n for n, ok in RESULTS if not ok]
    print(f"\n{len(RESULTS)} checks, {len(bad)} failed")
    if bad:
        print("FAILED: " + "; ".join(bad))
        return 1
    print(f"VERIFIED ({WY.VERSION})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
