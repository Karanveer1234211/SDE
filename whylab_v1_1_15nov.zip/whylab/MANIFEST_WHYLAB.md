# MANIFEST - whylab v1.1 (15 Nov 2026)

This research tool lives in its own folder beside tradelab and setuplab. Nothing in `bigmove_deploy`, tradelab or setuplab changes. Production, including stage D's code and its frozen run, is only read.

| file | what | sha256 (first 16) |
|---|---|---|
| `whylab\whylab.py` | the tool: `check`, `run` (claims), `model` (part K) | 3764c39fea5a1a52 |
| `whylab\WHY_DECLARATION.json` | the claims' rules, fixed 14 Nov 2026 20:45 IST; unchanged since v1.0 | e3967dd85a42d063 |
| `whylab\WHY_K_DECLARATION.json` | part K's rules, fixed 15 Nov 2026 00:20 IST before any K run, with 2 amendments | 158621297b501323 |
| `whylab\tests\test_whylab.py` | self-test, 26 checks | f76bf1dde5480a30 |
| `whylab\env_whylab.bat` | session setup (CRLF; labels unique); only its comments changed since v1.0 | 6ab03b19aae9fd97 |
| `whylab\README_WHYLAB.md` | what it does, how to run it | 10322321ff2fa2b0 |
| `whylab\MANIFEST_WHYLAB.md` | this file | - |

**What it uses unchanged:**
- setuplab v1.1: Boot, atr_simple, TREE.json and its ETF rule, run folders, hashes.
- tradelab: tl_setups v1.7, tl_data, tl_common.
- Part K, imported read only:
  - production's `stage_d_gate.py`, checked against FROZEN_ENGINES.json: its CFG, make_label, eligible_mask and horizon_of;
  - `stage_b_screen.py`: ELIG_COL, _read_col and _naive.

**What it writes:** only `C:\QuantData\whylab\runs\WHY_*`, `C:\QuantData\whylab\model\K_*` and `whylab_ledger.jsonl`.

**Verified 15 Nov 2026:** `VERIFIED (whylab v1.1)`, 26 checks, 0 failed.
- Library sets: pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2 (yours), and pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1.
- About 70 s each.
- Also checked from a clean folder.

**Planted bugs, 38 of 38 caught:**
- **Claims part (v1.0, 26):** listed in v1.0's manifest. That code is unchanged.
- **Part K (12):**
  - the fit-sample seed order;
  - the raw target instead of make_label;
  - rows sorted by symbol first;
  - varying inputs shuffled across all rows;
  - day-constant inputs not shuffled;
  - ETFs kept in the top 3;
  - the verdict read on the interval's low end;
  - a 90% gate;
  - preds.parquet's sha not checked;
  - two repeats instead of three;
  - money not net of costs;
  - groups ranked the wrong way.

**Fixed while building (synthetic data only, before any K run):**
- A test hand-check drew its random numbers in a different order from the declared scheme. The test was fixed, not the tool.
- The "money not net of costs" bug slipped past the first suite, because costs cancel in a before-and-after difference. The suite now checks the top 3's own net by hand.

**Part K's evidence base:**
- D's frozen files that Karan sent on 14 Nov:
  - `stage_d_gate.py`: sha256 5d339ca0eedd…, equal to FROZEN_ENGINES.json;
  - `stage_d.json`: fdc4d33f49c1…, equal;
  - the preds schema (5,849,876 rows, 4 targets);
  - FROZEN_ENGINES.json.
- Read from the frozen D run: D's 205 inputs and the 5 `label_oc_5` folds, tested 2020-01-16 .. 2026-09-15.
