# whylab v1.1 — are the 14 Nov claims about the model's picks true, and what does D itself rely on?

**Question (Karan, 14 Nov 2026).** 20:14: "Let's try to understand in detail what the model REALLY relies on? And what drives the momentum after the stock is picked by the model?" 20:22, after Claude's answer: "No no no. No assumptions. Lets test on pc and come to a concerete sure shot valuable reliable conclusion."

**What it does.** Every claim Claude made at 20:14 is checked on every pick of the frozen engines, against every other stock of the same day. Every measure, threshold and rule is fixed in **`WHY_DECLARATION.json`** (14 Nov 2026, before any run on real data). `whylab.py` refuses any other version of that file.

**The picks.** Every pick in setuplab's newest TREE run: D and ENS, ranks 1–10, 2020-01-16 to 2026-09-15, ETFs out. Verdicts use ranks 1–3, the traded book. Ranks 1–10 are shown beside them without a verdict. Calm and jumpy picks use the tree's own lanes.

**"Every other stock that day".** Every symbol in `panel_oc` on the signal day (the engines' candidate list), ETFs out.

**The outcome.** Buy at the D1 open, sell at the D5 close, 0.35 points of costs. This is the tree's own D1 net, and the run checks that it gives the same number on at least 99% of picks before judging anything. The pick's **own move** is its return from the D1 open minus the average stock's return over the same days.

**How a claim becomes TRUE.** Each claim is judged in four cells: D and ENS, each in 2020–23 and in 2024–26. Every cell has a 95% interval (blocks of 10 signal days, 2,000 resamples). TRUE needs the claim in all four.

| # | Claim | What is measured |
|---|---|---|
| 1 | Picks come after a hard fall | Share of picks in the day's bottom 20% by 5-day return (chance is 20%). The same for RSI 7, 20-day position, 20- and 60-day return. |
| 2 | Picks are the most volatile stocks | Share in the day's top 20% by ATR % |
| 3 | A simple rule could do the model's job | R1 = the 3 stocks with the biggest 5-day fall in ATRs, R2 = the 3 with the lowest RSI 7, vs the engine's ranks 1–3, same days, paired |
| 4 | The gain is the model's choice, not only the type of stock | Each pick vs its 10 look-alikes: unpicked stocks of the same day nearest in 5-day return and ATR % |
| 5 | It is a rebound: a bigger fall, a bigger gain | Own move to D5 of the most-fallen third of picks minus the least-fallen third. The same for all stocks is shown beside it. |
| 6 | It is fast | Own move from the D1 open to the D2 close, and from the D2 close to the D5 close |
| 7 | It fades after D5 | Own move from the D5 close to the D10 close (and to the D6 open) |
| 8 | It comes with a volume burst | D1–D3 volume vs the stock's own 20-day average, and vs the look-alikes' |
| 9 | Closing near the 20-day low warns of a further fall first | Share touching −8% under the D1 open by D5: the third closest to the 20-day low minus the farthest |
| 10 | News or results drive the move | **Not tested.** The pipeline has no announcement data, and nothing stands in for it. |

The report also shows what the picks look like on the signal day (15 measures, as percentiles of the day), the average path D1–D10, and **12 example picks drawn at random** (seed 7) rather than chosen.

## Part K (v1.1, `model`) — what D itself relies on

The rules are fixed in **`WHY_K_DECLARATION.json`** (15 Nov 2026 00:20 IST, before any K run). It keeps the 14 Nov `model_part` and records two amendments made after reading D's frozen files, and before any K code ran on them:
- **Corrected input groups.** The 14 Nov name patterns misfiled 19 of D's 205 inputs: "dow" matched drawdown and downside, the day dummies and `Comb_` flags fell into "market", and a few volume names matched nothing.
- **D only.** ENS's C half would need its own folds and feature store.

What `model` does:
1. **Checks the frozen files.** Production's `stage_d_gate.py`, the D run's `stage_d.json` and `preds.parquet` must all have the sha256s that `panel_oc\frozen\FROZEN_ENGINES.json` records.
2. **Rebuilds D's 5 folds** for `label_oc_5` with stage D's own recipe: `stage_d_gate.CFG` and `make_label`, `stage_b_screen._read_col`, the same rows, the same 400,000-row samples and the same seeds.
3. **Gate.** The rebuilt scores must reproduce the frozen `preds.parquet`: the same top 3 on at least 99% of days and a median daily rank correlation of at least 0.999. If not, nothing else runs and the report says why.
4. **Knock-outs.** D's 205 inputs fall into 10 groups. For one group at a time, on every test day:
   - inputs that differ between stocks are shuffled across that day's stocks;
   - inputs that are the same for every stock that day are shuffled across days.

   This is repeated 3 times. The same fitted models re-pick the top 3 (ETFs out).
5. **Verdict.** D **RELIES ON** a group when scrambling it costs money: the 95% interval of the change in top-3 net per trade (D1 open to D5 close, after 0.35 points of costs) is below 0. Groups are ranked by the money lost. Raw price levels get their own line.

## Install and run

Unzip into `C:\Users\karanvsi\PyCharmMiscProject`. v1.1 replaces the files in the `whylab` folder; nothing else changes.

```
cd /d C:\Users\karanvsi\PyCharmMiscProject
tar -xf "%USERPROFILE%\Downloads\whylab_v1_1_15nov.zip"
call whylab\env_whylab.bat
python tests\test_whylab.py
python whylab.py check
python whylab.py model --root %CACHE_DAILY_ROOT%
```

The test must end `VERIFIED (whylab v1.1)`.

`model` prints what it loaded, one line per fold fitted, the gate, one line per fold of knock-outs, then a `RESULT:` line and `DONE`. Expect about 20-30 minutes and about 3 GB of memory. That is an estimate, not measured on your PC. Your D run's 5 `label_oc_5` fits took 257 s in all (stage_d.json). One D-sized re-scoring timed here, scaled to your PC, puts the 150 re-scorings at about 18 minutes. The input table is 1,890,199 rows × 205 inputs, about 1.55 GB, and the first line `model` prints shows its size.

`run`, the claims, already ran as WHY_20261114_001 under the same declaration, so a second `run` is refused. Either command runs again only with `--rerun-reason "<a verified bug>"`, which goes into the ledger.

**Part K outputs** (`C:\QuantData\whylab\model\K_<date>_<nnn>\`):
- `KREPORT.md`: the gate, the groups ranked by money lost, the raw-price-level line, and every input with its group.
- `families.csv`, `inputs.csv`, `gate.csv`, `folds.csv`.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- A ledger line.

If the gate fails, it prints `STOPPED:` and the report says why.

**Outputs** (`C:\QuantData\whylab\runs\WHY_<date>_<nnn>\`):
- `REPORT.md`: the verdicts first, then each claim cell by cell, the rules, the signal-day profile, the path, the examples and the data checks.
- `claims.csv`: every cell of every claim, for all, calm, jumpy and ranks 1–10.
- `profile.csv`, `path.csv`, `rules.csv`, `examples.csv`.
- `picks.parquet`: every pick with every measure and outcome.
- `run.json`, `DECLARATION.json`, `outputs.sha256`.
- One line per run in `C:\QuantData\whylab\whylab_ledger.jsonl`.

**Reads only:** setuplab's newest TREE run (hash-checked), `panel_oc` (timestamp and symbol only), every universe stock's daily bars through tradelab's loader (production's stage E), setuplab's `TREE.json` ETF names, and NSE's ETF list when present. **Writes only** under `WHYLAB_OUT`.

**If the run stops** with `STOPPED:` (the gate), nothing is written. Send the screen: it means the bars here and the tree's prices disagree on more than 1% of picks.

## Tests (`tests\test_whylab.py`, 26 checks)

- **By hand:**
  - every measure and outcome against an independent loop, including a suspended session;
  - the day frame (percentiles, ETFs out, the market's mean, the excess);
  - the look-alike controls;
  - the rules' daily top 3 (ties by symbol, a missing outcome left out);
  - every claim's rule on made-up pick tables where the claim is planted, absent, reversed, or explained by the type.
- **Whole runs on synthetic caches** in the real layouts (daily bars, NIFTY50, panel_oc, a setuplab TREE run, tradelab's production stand-ins):
  - **PLANTED**: one-day crashes, a D1–D2 rebound on 3× volume, flat to D5, a fade over D6–D10; half close at their low and dip 10% on D1. Claims 1, 5–9 come out TRUE, and R1 (the engines' own rule) matches the model.
  - **FALLEN**: the same picks with nothing after. Claim 1 is TRUE and no after-the-pick claim is.
  - **RANDOM**: nothing is TRUE.
- **Each cell's picks by hand:** the period split, lanes, ranks and ETFs, and the 12 examples equal the declared draw.
- **The gate:** a tree whose D1 net is off on 2% of picks stops the run, and nothing is written.
- **Guards:** outputs and their hashes, the ledger, the rerun guard, and refusals (output inside the cache, no `--root`, no setuplab output).
- **Part K, on a synthetic panel_oc with stand-in production modules:**
  - stage D's fold loop written out independently makes the "frozen" `preds.parquet`, and the rebuild must reproduce it exactly;
  - an outcome that follows one input makes D **RELY ON** that input's group, the largest loss;
  - one knock-out is recomputed by hand: picks replaced, money and the top 3's own net, day by day;
  - the input groups come out right (including the amended cases), and the scramble keeps each day's values;
  - frozen scores that don't reproduce on 5% of days stop part K;
  - it refuses before anything runs on a changed `stage_d_gate.py`, a changed config, or a changed `preds.parquet`.
- **Planted bugs:** 38 of them, each caught (see MANIFEST).
