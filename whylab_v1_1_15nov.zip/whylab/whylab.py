"""
whylab.py - whylab v1.1: are Claude's 14 Nov claims about the model's picks true (run), and what does D itself rely
on (model, part K)? Each claim is checked on every pick of the frozen engines (D and ENS, ranks 1-3 judged, ranks 1-10
shown), against every other stock of the same day, in 2020-23 and in 2024-26 separately. WHY_DECLARATION.json and
WHY_K_DECLARATION.json (both pinned below) fix every measure and every rule before any run; whylab refuses any other.

    python whylab.py check                                       the declarations are the pinned ones; the libraries
    python whylab.py run --root %CACHE_DAILY_ROOT% [--setups %SETUPLAB_OUT%] [--out <folder>] [--stage-e-any]
                         [--rerun-reason "<a verified bug>"]
                                                                 -> WHYLAB_OUT\\runs\\WHY_<date>_<nnn>
    python whylab.py model --root %CACHE_DAILY_ROOT% [--out <folder>] [--rerun-reason "<a verified bug>"]
                                                                 -> WHYLAB_OUT\\model\\K_<date>_<nnn>

PART K (model): D's 5 walk-forward folds rebuilt with production's own stage D code (stage_d_gate.CFG, make_label;
stage_b_screen._read_col; imported read only and checked against FROZEN_ENGINES.json), which must reproduce the
frozen preds.parquet before anything else; then each group of D's 205 inputs is scrambled in turn on the test days
and the same fitted models re-pick the top 3. D relies on a group when scrambling it costs money (95% interval below
0). Writes K_<date>_<nnn>\\ KREPORT.md, families.csv, inputs.csv, gate.csv, folds.csv, run.json, DECLARATION.json,
outputs.sha256 and a ledger line.

THE CLAIMS (Claude, 14 Nov 20:14): 1 picks come after a hard fall; 2 picks are the most volatile stocks; 3 a simple
rule could do the model's job; 4 the gain is the model's choice, not only the type of stock; 5 the move is a rebound
(a bigger fall, a bigger gain); 6 it is fast; 7 it fades after D5; 8 it comes with a volume burst; 9 closing near the
20-day low warns of a further fall first; 10 news drives it (NOT TESTED: no announcement data).

READS (read only): setuplab's newest TREE run (every pick, its lane, ETF flag and D1 net; hash-checked through
tradelab's tl_setups), CACHE_DAILY_ROOT\\panel_oc\\panel.parquet (timestamp and symbol only: who could be picked each
day), every universe stock's daily bars through tradelab's tl_data (production's stage E loader), setuplab's TREE.json
(ETF names) and NSE's ETF list when present. WRITES only under --out / WHYLAB_OUT: WHY_<date>_<nnn>\\ REPORT.md,
claims.csv, profile.csv, path.csv, rules.csv, examples.csv, picks.parquet, run.json, DECLARATION.json,
outputs.sha256; one line per run in whylab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import tl_common as TC
import tl_data as TD
import tl_setups as SU

VERSION = "whylab v1.1"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "WHY_DECLARATION.json"
DECL_SHA = "e3967dd85a42d063a71e20a260ee9659c6f12c36eb58b20172c4029e48d37442"
LEDGER = "whylab_ledger.jsonl"
SL_VERSION = "setuplab v1.1"
SL_NEEDS = ("Boot", "atr_simple", "load_tree", "tree_etf", "etf_list", "new_run_dir", "write_hashes")

COST = 0.35
P2_START = np.datetime64("2024-01-01", "D")
ENGINES = ("D", "ENS")
PERIODS = ("P1", "P2")
CELLS = tuple((e, p) for e in ENGINES for p in PERIODS)
PNAME = {"P1": "2020-23", "P2": "2024-26", "ALL": "2020-26"}
LANES = {"ALL": None, "CALM": ("CALM",), "JUMPY": ("JUMPY", "NO ATR")}
MEASURES = ("ret1", "ret5", "ret20", "ret60", "rsi7", "pos20", "lo52", "hi52", "atrp", "vol20", "vratio", "value20",
            "price", "sde3", "sde10")
MNAME = {"ret1": "signal-day return", "ret5": "5-day return", "ret20": "20-day return", "ret60": "60-day return",
         "rsi7": "RSI 7", "pos20": "position in the 20-day range", "lo52": "above the 52-week low",
         "hi52": "below the 52-week high", "atrp": "ATR % (14-day)", "vol20": "20-day volatility",
         "vratio": "signal-day volume vs 20-day average", "value20": "rupees traded a day (20-day median)",
         "price": "share price", "sde3": "SDE 3", "sde10": "SDE 10"}
PCT_MEASURES = ("ret1", "ret5", "ret20", "ret60", "lo52", "hi52", "atrp", "vol20")     # shown as % in the report
KMAX = 10
GATE_TOL = 1e-4
GATE_SHARE = 0.99
NN = 10
RSI_SKIP = 50
B, BLOCK, SEED = 2000, 10, 7
CLAIMS = {1: "Picks come after a hard fall", 2: "Picks are the most volatile stocks",
          3: "A simple rule could do the model's job",
          4: "The gain is the model's choice, not only the type of stock (fallen and volatile)",
          5: "The move is a rebound: a bigger fall before, a bigger gain after", 6: "The move is fast (by the D2 close)",
          7: "The move fades after D5", 8: "The move comes with a volume burst",
          9: "Closing near the 20-day low warns of a further fall first", 10: "News or results drive the move"}
RULES = {"R1": ("ret5 / atrp", "biggest 5-day fall in ATRs"), "R2": ("rsi7", "lowest RSI 7")}


class WHError(Exception):
    """A precondition failed: nothing is written (exit 2)."""


class GateFailed(Exception):
    """The reconciliation gate failed: the run stops before any claim is judged (exit 3)."""


def say(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def sha256(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_decl(path: Path = DECL_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != DECL_SHA:
        raise WHError(f"{Path(path).name} has sha256 {sha[:16]}, not the pinned {DECL_SHA[:16]} - the declaration is "
                      f"fixed before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def libs():
    """setuplab (its Boot, ATR, tree file and ETF rule are used unchanged, so its version is checked)."""
    try:
        import setuplab as SL
    except ImportError as e:
        raise WHError(f"cannot import setuplab ({e}) - start with env_whylab.bat (it puts setuplab on PYTHONPATH)")
    miss = [n for n in SL_NEEDS if not hasattr(SL, n)]
    if miss or getattr(SL, "VERSION", "") != SL_VERSION:
        raise WHError(f"setuplab is {getattr(SL, 'VERSION', '?')} (missing {miss}); whylab uses {SL_VERSION}'s code")
    if not hasattr(SU, "sde_series") or not hasattr(SU, "load_tree"):
        raise WHError("tradelab's tl_setups lacks sde_series / load_tree - whylab needs tradelab with tl_setups v1.7")
    return SL


def out_base(arg: Optional[str], root: Optional[Path]) -> Path:
    v = arg or os.environ.get("WHYLAB_OUT")
    if not v:
        raise WHError("no output folder: pass --out or start with env_whylab.bat (sets WHYLAB_OUT)")
    b = Path(v).resolve()
    guards = ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                          ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise WHError(f"output folder {b} is inside {g}; whylab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


# ---------------------------------------------------------------------------------------------------- the inputs
def read_picks(base: Path) -> Tuple[pd.DataFrame, dict]:
    """Every pick of setuplab's newest tree run (hash-checked), engines D and ENS, ranks 1-10."""
    T, info = SU.load_tree(base, need=True)
    need = {"trade_id", "engine", "rank", "symbol", "signal_day", "lane", "etf", "d1_net", "complete"}
    miss = sorted(need - set(T.columns))
    if miss:
        raise WHError(f"the tree run {info['run']} lacks {miss} - it needs setuplab v1.1's tree command")
    P = T[list(need) + [c for c in ("s_atr14",) if c in T.columns]].copy()
    P["engine"] = P["engine"].astype(str)
    P["rank"] = pd.to_numeric(P["rank"], errors="coerce")
    P = P[P["engine"].isin(ENGINES) & P["rank"].between(1, 10)].copy()
    P["rank"] = P["rank"].astype(int)
    P["symbol"] = P["symbol"].astype(str).str.strip().str.upper()
    P["day"] = TC.to_day(P["signal_day"])
    P["etf"] = P["etf"].astype("boolean").fillna(False).astype(bool)
    P["complete"] = P["complete"].astype("boolean").fillna(False).astype(bool)
    P["d1_net"] = pd.to_numeric(P["d1_net"], errors="coerce").astype(float)
    P["lane"] = P["lane"].fillna("").astype(str)
    if P.duplicated(["engine", "day", "rank"]).any():
        raise WHError(f"the tree run {info['run']} holds two picks for the same engine, day and rank - refusing")
    P = P.sort_values(["day", "engine", "rank"]).reset_index(drop=True)
    return P, info


def read_universe(root: Path, days: np.ndarray, log=say) -> Tuple[pd.DataFrame, dict]:
    """(day, symbol) of every panel_oc row on the picks' signal days: who the engines could pick."""
    import pyarrow.parquet as pq
    pf = TD.PanelFeatures(root, "panel_oc")
    tbl = pq.read_table(pf.path, columns=[pf.tcol, "symbol"])
    d = TC.to_day(tbl.column(pf.tcol).to_pandas())
    s = tbl.column("symbol").to_pandas().astype(str).str.strip().str.upper().to_numpy()
    keep = np.isin(d, days)
    U = pd.DataFrame({"day": d[keep], "symbol": s[keep]}).drop_duplicates(["day", "symbol"])
    U = U.sort_values(["symbol", "day"]).reset_index(drop=True)
    log(f" universe: {len(U):,} stock-days on {U['day'].nunique():,} signal days, {U['symbol'].nunique():,} symbols "
        f"({pf.path})")
    return U, {"panel": str(pf.path), "panel_rows_read": int(len(d)), "stock_days": int(len(U)),
               "symbols": int(U["symbol"].nunique())}


# ---------------------------------------------------------------------------------------------------- one stock
def _roll(x: np.ndarray, w: int, how: str) -> np.ndarray:
    r = pd.Series(x).rolling(w, min_periods=w)
    return np.array(getattr(r, how)().to_numpy(float), dtype=float, copy=True)


def stock_arrays(SL, ds, cal: np.ndarray) -> Dict[str, np.ndarray]:
    """Every measure (known at bar t's close) and every outcome (from bar t+1's open), aligned with the stock's
    bars. Outcomes in %; blank when bar t+1 is not the calendar's next session or a bar is missing."""
    o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
    v = np.asarray(ds.v, float) if ds.v is not None else np.full(len(c), np.nan)
    n = len(c)
    F: Dict[str, np.ndarray] = {}
    with np.errstate(divide="ignore", invalid="ignore"):
        for k in (1, 5, 20, 60):
            x = np.full(n, np.nan)
            if n > k:
                x[k:] = c[k:] / c[:-k] - 1
            F[f"ret{k}"] = x
        d = np.full(n, np.nan)
        d[1:] = np.diff(c)
        g = np.where(d > 0, d, 0.0)
        ls = np.where(d < 0, -d, 0.0)
        rsi = np.full(n, np.nan)
        if n > 1:
            ag = np.array(pd.Series(g[1:]).ewm(alpha=1 / 7, adjust=False).mean().to_numpy(float), copy=True)
            al = np.array(pd.Series(ls[1:]).ewm(alpha=1 / 7, adjust=False).mean().to_numpy(float), copy=True)
            rs = np.where(al > 0, 100 - 100 / (1 + ag / np.where(al > 0, al, 1.0)), np.where(ag > 0, 100.0, 50.0))
            rsi[1:] = rs
            rsi[~np.isfinite(d)] = np.nan
        rsi[:RSI_SKIP] = np.nan
        F["rsi7"] = rsi
        lo20, hi20 = _roll(l, 20, "min"), _roll(h, 20, "max")
        F["pos20"] = np.where(hi20 - lo20 > 0, (c - lo20) / (hi20 - lo20), np.nan)
        F["lo52"] = c / _roll(l, 252, "min") - 1
        F["hi52"] = c / _roll(h, 252, "max") - 1
        F["atrp"] = np.asarray(SL.atr_simple(h, l, c), float)
        r1 = np.full(n, np.nan)
        r1[1:] = c[1:] / c[:-1] - 1
        F["vol20"] = np.array(pd.Series(r1).rolling(20, min_periods=20).std(ddof=1).to_numpy(float), copy=True)
        vavg = np.full(n, np.nan)
        if n > 1:
            vavg[1:] = _roll(v, 20, "mean")[:-1]                  # t-20 .. t-1
        F["vratio"] = v / vavg
        F["value20"] = _roll(c * v, 20, "median")
        F["price"] = c.copy()
        F["sde3"] = np.asarray(SU.sde_series(c, 3), float)
        F["sde10"] = np.asarray(SU.sde_series(c, 10), float)
        for k_ in list(F):
            F[k_] = np.where(np.isfinite(F[k_]), F[k_], np.nan)
        # outcomes
        dates = np.asarray(ds.dates).astype("datetime64[D]")
        j = np.searchsorted(cal, dates, side="right")
        nxt = np.where(j < len(cal), cal[np.minimum(j, len(cal) - 1)], np.datetime64("NaT"))
        ok1 = np.zeros(n, bool)
        if n > 1:
            ok1[:-1] = dates[1:] == nxt[:-1]
        o1 = np.full(n, np.nan)
        o1[:-1] = o[1:]
        o1[~ok1 | ~(o1 > 0)] = np.nan

        def ahead(a, k):
            out = np.full(n, np.nan)
            if n > k:
                out[:-k] = a[k:]
            return out
        for k in range(1, KMAX + 1):
            F[f"r{k}"] = (ahead(c, k) / o1 - 1) * 100
        F["open6"] = (ahead(o, 6) / o1 - 1) * 100
        lmin = np.full(n, np.nan)
        if n > 5:
            lmin[:-5] = _roll(l, 5, "min")[5:]                     # lows of t+1 .. t+5
        F["dn8"] = np.where(np.isfinite(lmin) & np.isfinite(o1), (lmin / o1 - 1 <= -0.08).astype(float), np.nan)
        lv = [np.log(ahead(v, k) / vavg) for k in (1, 2, 3)]
        F["vb"] = np.where(ok1, np.mean(np.vstack(lv), axis=0), np.nan)
        for k_ in [f"r{k}" for k in range(1, KMAX + 1)] + ["open6", "vb"]:
            F[k_] = np.where(np.isfinite(F[k_]), F[k_], np.nan)
    return F


OUT_COLS = tuple([f"r{k}" for k in range(1, KMAX + 1)] + ["open6", "dn8", "vb"])


def assemble(SL, market, U: pd.DataFrame, log=say, chunk: int = 100) -> Tuple[pd.DataFrame, dict]:
    """The universe table: every (day, symbol) with its measures and outcomes from the stock's own bars."""
    n = len(U)
    cols = {k: np.full(n, np.nan, dtype=np.float32 if k in MEASURES else np.float64) for k in MEASURES + OUT_COLS}
    groups = U.groupby("symbol", sort=True).indices
    syms = list(groups)
    cal = np.asarray(market.cal).astype("datetime64[D]")
    days = U["day"].to_numpy().astype("datetime64[D]")
    no_bars, no_day, t0 = 0, 0, time.time()
    for c0 in range(0, len(syms), chunk):
        part = syms[c0:c0 + chunk]
        market.load(part)
        for sym in part:
            rows = groups[sym]
            ds = market.daily.get(sym)
            if ds is None or not len(ds.dates):
                no_bars += len(rows)
                continue
            dd = np.asarray(ds.dates).astype("datetime64[D]")
            pos = np.searchsorted(dd, days[rows])
            hit = (pos < len(dd)) & (dd[np.minimum(pos, len(dd) - 1)] == days[rows])
            no_day += int((~hit).sum())
            if hit.any():
                F = stock_arrays(SL, ds, cal)
                r, p_ = rows[hit], pos[hit]
                for k in cols:
                    cols[k][r] = F[k][p_]
            market.daily.pop(sym, None)
        log(f"   bars: {min(c0 + chunk, len(syms)):,} of {len(syms):,} symbols ({time.time() - t0:.0f}s)")
    T = U.copy()
    for k, a in cols.items():
        T[k] = a
    return T, {"no_bars_rows": int(no_bars), "no_bar_that_day_rows": int(no_day), "missing_symbols":
               sorted(set(market.missing))[:50], "missing_symbol_count": int(len(set(market.missing)))}


XK = tuple([f"r{k}" for k in range(1, KMAX + 1)] + ["open6"])


def day_frame(SL, T: pd.DataFrame, picks: pd.DataFrame, root: Path) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    """ETF flags, within-day percentiles, the pick flags; Ud = the universe's mean outcome u_k per signal day."""
    try:
        _, tdoc = SL.load_tree()
        listed = SL.etf_list(root)
    except ValueError as e:
        raise WHError(f"setuplab's ETF rule is not usable: {e}")
    T = T.sort_values(["day", "symbol"]).reset_index(drop=True)
    T["etf"] = SL.tree_etf(T["symbol"].to_numpy(), tdoc, listed)
    uni = ~T["etf"].to_numpy()
    g = T.loc[uni, ["day"] + list(MEASURES)].groupby("day")
    for m in MEASURES:
        pc = np.full(len(T), np.nan)
        pc[uni] = g[m].rank(pct=True).to_numpy(dtype=float)
        T[f"p_{m}"] = pc
    Ud = T.loc[uni, ["day"] + list(XK)].groupby("day")[list(XK)].mean()
    Ud.columns = [f"u_{k}" for k in XK]
    Ud = Ud.reset_index()
    T["x_r5"] = T["r5"].to_numpy(float) - T["day"].map(Ud.set_index("day")["u_r5"]).to_numpy(float)
    T["net5"] = T["r5"] - COST
    pk = set(zip(picks["day"].to_numpy().astype("datetime64[D]").tolist(), picks["symbol"].tolist()))
    T["picked"] = [(d, s) in pk for d, s in zip(T["day"].to_numpy().astype("datetime64[D]").tolist(), T["symbol"])]
    info = {"etf_rows": int((~uni).sum()), "nse_etf_list": listed is not None,
            "median_universe_per_day": float(T.loc[uni, "day"].value_counts().median()) if uni.any() else 0.0}
    return T, Ud, info


def controls(T: pd.DataFrame, log=say) -> pd.DataFrame:
    """For every picked stock-day: its NN nearest unpicked universe stocks of the same day in (ret5, atrp) percentile
    with an outcome - their mean r5, mean vb, how many and how far."""
    out = []
    uni = ~T["etf"].to_numpy()
    T2 = T.loc[uni, ["day", "symbol", "picked", "p_ret5", "p_atrp", "r5", "vb"]]
    for d, G in T2.groupby("day", sort=True):
        pm = G["picked"].to_numpy()
        if not pm.any():
            continue
        a = G[["p_ret5", "p_atrp"]].to_numpy(float)
        cand = (~pm) & np.isfinite(a).all(1) & np.isfinite(G["r5"].to_numpy(float))
        ci = np.flatnonzero(cand)
        r5 = G["r5"].to_numpy(float)[ci]
        vb = G["vb"].to_numpy(float)[ci]
        for q in np.flatnonzero(pm):
            rec = {"day": d, "symbol": G["symbol"].iat[q], "c_n": 0, "c_r5": np.nan, "c_vb": np.nan, "c_dist": np.nan}
            if np.isfinite(a[q]).all() and len(ci) >= NN:
                dist = np.sqrt(((a[ci] - a[q]) ** 2).sum(1))
                o = np.argsort(dist, kind="stable")[:NN]          # rows sorted by symbol: ties go to the symbol order
                rec.update(c_n=NN, c_r5=float(r5[o].mean()), c_dist=float(dist[o].mean()),
                           c_vb=float(np.nanmean(vb[o])) if np.isfinite(vb[o]).any() else np.nan)
            out.append(rec)
    C = pd.DataFrame(out, columns=["day", "symbol", "c_n", "c_r5", "c_vb", "c_dist"])
    log(f" controls: {int((C['c_n'] == NN).sum()):,} of {len(C):,} picked stock-days matched with {NN} stocks each")
    return C


def pick_table(P: pd.DataFrame, T: pd.DataFrame, Ud: pd.DataFrame, C: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """Every pick with its stock-day's measures, percentiles, outcomes, the day's u_k, its excess x_k, controls."""
    keep = ["day", "symbol"] + list(MEASURES) + [f"p_{m}" for m in MEASURES] + list(OUT_COLS) + ["net5"]
    Q = P.merge(T[keep], on=["day", "symbol"], how="left", indicator=True)
    info = {"picks": int(len(Q)), "not_in_panel": int((Q["_merge"] == "left_only").sum()),
            "not_in_panel_examples": Q.loc[Q["_merge"] == "left_only", ["engine", "day", "symbol"]].head(10)
            .astype(str).values.tolist()}
    Q = Q.drop(columns="_merge").merge(C, on=["day", "symbol"], how="left").merge(Ud, on="day", how="left")
    for k in XK:
        Q[f"x_{k}"] = Q[k].to_numpy(float) - Q[f"u_{k}"].to_numpy(float)
    Q["period"] = np.where(Q["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    return Q.reset_index(drop=True), info


def gate(Q: pd.DataFrame) -> dict:
    """net5 here vs the tree's d1_net on the complete non-ETF picks."""
    m = Q["complete"].to_numpy() & ~Q["etf"].to_numpy() & np.isfinite(Q["d1_net"].to_numpy(float))
    a, b = Q["net5"].to_numpy(float)[m], Q["d1_net"].to_numpy(float)[m]
    eq = np.isfinite(a) & (np.abs(a - b) <= GATE_TOL)
    share = float(eq.mean()) if m.any() else 0.0
    bad = Q.loc[m].loc[~eq, ["trade_id", "symbol", "day", "net5", "d1_net"]].head(10)
    return {"picks": int(m.sum()), "equal": int(eq.sum()), "share": share, "no_outcome_here": int((~np.isfinite(a)).sum()),
            "passed": bool(m.any() and share >= GATE_SHARE), "examples": bad.astype(str).values.tolist()}


# ---------------------------------------------------------------------------------------------------- statistics
class Stat:
    """Means and differences of means over rows with their 95% intervals: setuplab's Boot (circular blocks of 10
    signal days, 2,000 resamples, seed 7), the same draws for every number."""

    def __init__(self, SL, days: np.ndarray):
        self.boot = SL.Boot(np.unique(np.asarray(days).astype("datetime64[D]")), B=B, block=BLOCK, seed=SEED)
        self.nd = len(self.boot.days)

    def di(self, days) -> np.ndarray:
        return self.boot.index(np.asarray(days).astype("datetime64[D]"))

    def _res(self, di, vals, masks):
        cols = []
        for m in masks:
            cols += [np.bincount(di[m], weights=vals[m], minlength=self.nd),
                     np.bincount(di[m], minlength=self.nd).astype(float)]
        R = self.boot.M @ np.column_stack(cols)
        with np.errstate(invalid="ignore", divide="ignore"):
            return R[:, 0::2] / np.where(R[:, 1::2] > 0, R[:, 1::2], np.nan)

    def mean(self, di, vals, mask) -> dict:
        vals = np.asarray(vals, float)
        m = np.asarray(mask, bool) & np.isfinite(vals) & (di >= 0)
        out = {"n": int(m.sum()), "days": int(len(np.unique(di[m]))), "stat": np.nan, "lo": np.nan, "hi": np.nan}
        if m.sum() < 2:
            return out
        out["stat"] = float(vals[m].mean())
        R = self._res(di, vals, [m])[:, 0]
        if np.isfinite(R).sum() > 100:
            out["lo"], out["hi"] = float(np.nanpercentile(R, 2.5)), float(np.nanpercentile(R, 97.5))
        return out

    def diff(self, di, va, ma, vb, mb) -> dict:
        va, vb = np.asarray(va, float), np.asarray(vb, float)
        ma = np.asarray(ma, bool) & np.isfinite(va) & (di >= 0)
        mb = np.asarray(mb, bool) & np.isfinite(vb) & (di >= 0)
        out = {"n": int(ma.sum() + mb.sum()), "n_a": int(ma.sum()), "n_b": int(mb.sum()), "stat": np.nan,
               "lo": np.nan, "hi": np.nan, "a": np.nan, "b": np.nan}
        if ma.sum() < 2 or mb.sum() < 2:
            return out
        out["a"], out["b"] = float(va[ma].mean()), float(vb[mb].mean())
        out["stat"] = out["a"] - out["b"]
        v = np.where(ma, va, vb)
        R = self._res(di, np.nan_to_num(v), [ma, mb])
        d = R[:, 0] - R[:, 1]
        if np.isfinite(d).sum() > 100:
            out["lo"], out["hi"] = float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5))
        return out


def above(r: dict, x: float = 0.0) -> bool:
    return bool(np.isfinite(r.get("lo", np.nan)) and r["lo"] > x)


def below(r: dict, x: float = 0.0) -> bool:
    return bool(np.isfinite(r.get("hi", np.nan)) and r["hi"] < x)


def known(r: dict) -> bool:
    return bool(np.isfinite(r.get("lo", np.nan)) and np.isfinite(r.get("hi", np.nan)))


# ---------------------------------------------------------------------------------------------------- the claims
def mask_of(Q: pd.DataFrame, e: str, period: str, lane: str = "ALL", ranks: int = 3) -> np.ndarray:
    m = (Q["engine"].to_numpy() == e) & ~Q["etf"].to_numpy() & (Q["rank"].to_numpy() <= ranks)
    if LANES.get(lane):
        m &= np.isin(Q["lane"].to_numpy(), LANES[lane])
    if period in PERIODS:
        m &= Q["period"].to_numpy() == period
    return m


def thirds(vals: np.ndarray, m: np.ndarray, other: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Low / high thirds of vals inside m (cut at m's own 1/3 and 2/3 quantiles), where other is also finite."""
    ok = m & np.isfinite(vals) & np.isfinite(other)
    if ok.sum() < 6:
        z = np.zeros(len(vals), bool)
        return z, z
    q1, q2 = np.quantile(vals[ok], [1 / 3, 2 / 3])
    return ok & (vals <= q1), ok & (vals > q2)


def claim_cells(S: Stat, Q: pd.DataFrame, lane: str = "ALL", ranks: int = 3) -> Dict[int, dict]:
    """Claims 1, 2, 4-9 in the four cells (and the whole period, reported) for one lane and rank band."""
    di = S.di(Q["day"])
    g = lambda c: Q[c].to_numpy(float)                                           # noqa: E731
    pr5, patr = g("p_ret5"), g("p_atrp")
    r5, x2, x5, x10, xo6 = g("r5"), g("x_r2"), g("x_r5"), g("x_r10"), g("x_open6")
    u5, cr5, vb, cvb = g("u_r5"), g("c_r5"), g("vb"), g("c_vb")
    dn8 = g("dn8") * 100
    out: Dict[int, dict] = {k: {} for k in (1, 2, 4, 5, 6, 7, 8, 9)}
    for e in ENGINES:
        for p in PERIODS + ("ALL",):
            m = mask_of(Q, e, p, lane, ranks)
            key = (e, p)
            # 1 hard fall
            sh = {nm: S.mean(di, np.where(np.isfinite(g(f"p_{nm}")), (g(f"p_{nm}") <= 0.2) * 100.0, np.nan), m)
                  for nm in ("ret5", "rsi7", "pos20", "ret20", "ret60")}
            r = dict(sh["ret5"])
            r["cell"] = "MOST" if above(r, 50) else ("MORE THAN CHANCE" if above(r, 20) else "NO")
            r["beside"] = {nm: sh[nm] for nm in ("rsi7", "pos20", "ret20", "ret60")}
            out[1][key] = r
            # 2 volatile
            r = S.mean(di, np.where(np.isfinite(patr), (patr > 0.8) * 100.0, np.nan), m)
            r["cell"] = "MOST" if above(r, 50) else ("MORE THAN CHANCE" if above(r, 20) else "NO")
            out[2][key] = r
            # 4 model vs type
            r = S.mean(di, r5 - cr5, m)
            t = S.mean(di, cr5 - u5, m & np.isfinite(r5 - cr5))
            r["type"] = t
            r["pick_excess"] = S.mean(di, r5 - u5, m & np.isfinite(r5 - cr5))
            r["cell"] = ("MODEL ADDS" if above(r) else "MODEL WORSE" if below(r) else
                         "TYPE EXPLAINS" if (known(r) and above(t)) else "NEITHER")
            out[4][key] = r
            # 5 rebound
            lo_, hi_ = thirds(pr5, m, x5)
            r = S.diff(di, x5, lo_, x5, hi_)
            r["cell"] = "REBOUND" if above(r) else ("MOMENTUM" if below(r) else "NONE")
            out[5][key] = r
            # 6 fast
            a = S.mean(di, x2, m & np.isfinite(x5))
            b = S.mean(di, x5 - x2, m)
            r = {"n": a["n"], "x2": a, "x2_5": b, "stat": a["stat"], "lo": a["lo"], "hi": a["hi"]}
            r["cell"] = "BUILDS TO D5" if above(b) else ("FAST" if above(a) and known(b) else "NONE")
            out[6][key] = r
            # 7 fade
            r = S.mean(di, x10 - x5, m)
            r["open6"] = S.mean(di, xo6 - x5, m)
            r["cell"] = "FADES" if below(r) else ("KEEPS GOING" if above(r) else "FLAT")
            out[7][key] = r
            # 8 volume
            a = S.mean(di, vb, m)
            b = S.mean(di, vb - cvb, m)
            r = {"n": a["n"], "vb": a, "vs_similar": b, "stat": b["stat"], "lo": b["lo"], "hi": b["hi"]}
            r["cell"] = "BURST" if (above(a) and above(b)) else ("HIGH BUT NOT SPECIAL" if above(a) else "NONE")
            out[8][key] = r
            # 9 faller warning
            res = {}
            for nm in ("pos20", "rsi7", "sde3"):
                lo_, hi_ = thirds(g(nm), m, dn8)
                res[nm] = S.diff(di, dn8, lo_, dn8, hi_)
            r = dict(res["pos20"])
            r["beside"] = {"rsi7": res["rsi7"], "sde3": res["sde3"]}
            r["cell"] = "HOLDS" if above(r) else ("REVERSED" if below(r) else "NONE")
            out[9][key] = r
    return out


def verdict(cid: int, cells: Dict[tuple, dict]) -> str:
    c = [cells[k]["cell"] for k in CELLS if k in cells]
    if len(c) < 4:
        return "TOO FEW PICKS"
    alls = lambda x: all(v == x for v in c)                                   # noqa: E731
    if cid in (1, 2):
        return "TRUE" if alls("MOST") else ("PARTLY" if all(v in ("MOST", "MORE THAN CHANCE") for v in c) else "FALSE")
    if cid == 4:
        return c[0] if alls(c[0]) else "MIXED"
    if cid == 5:
        return "TRUE" if alls("REBOUND") else ("MOMENTUM" if alls("MOMENTUM") else "NOT RELIABLE")
    if cid == 6:
        return "TRUE" if alls("FAST") else ("BUILDS TO D5" if alls("BUILDS TO D5") else "MIXED")
    if cid == 7:
        return "TRUE" if alls("FADES") else ("KEEPS GOING" if alls("KEEPS GOING") else "NOT RELIABLE")
    if cid == 8:
        return "TRUE" if alls("BURST") else "NOT SHOWN"
    if cid == 9:
        return "TRUE" if alls("HOLDS") else "NOT RELIABLE"
    raise ValueError(cid)


def rules_daily(T: pd.DataFrame, Q: pd.DataFrame) -> pd.DataFrame:
    """Per signal day: each engine's ranks 1-3 mean net5, each rule's 3, everything; overlap; liquidity."""
    uni = T.loc[~T["etf"].to_numpy(), ["day", "symbol", "ret5", "atrp", "rsi7", "net5", "value20"]].copy()
    uni["R1"] = uni["ret5"].astype(float) / uni["atrp"].astype(float)
    uni["R2"] = uni["rsi7"].astype(float)
    rows = []
    mod = Q[~Q["etf"].to_numpy() & (Q["rank"].to_numpy() <= 3)]
    mod_by = {k: G for k, G in mod.groupby(["day", "engine"])}
    for d, G in uni.groupby("day", sort=True):
        rec = {"day": d, "all": float(np.nanmean(G["net5"])) if np.isfinite(G["net5"]).any() else np.nan,
               "n_universe": int(len(G))}
        sym = G["symbol"].to_numpy()
        for rk in RULES:
            sc = G[rk].to_numpy(float)
            ok = np.flatnonzero(np.isfinite(sc))
            o = ok[np.lexsort((sym[ok], sc[ok]))]
            top3, top10 = o[:3], set(sym[o[:10]])
            nv = G["net5"].to_numpy(float)[top3]
            rec[rk] = float(np.nanmean(nv)) if np.isfinite(nv).any() else np.nan
            rec[f"{rk}_value20"] = float(np.nanmedian(G["value20"].to_numpy(float)[top3])) if len(top3) else np.nan
            for e in ENGINES:
                M = mod_by.get((d, e))
                rec[f"{e}_in_{rk}_top10"] = float(np.mean([s in top10 for s in M["symbol"]])) if M is not None and \
                    len(M) else np.nan
        for e in ENGINES:
            M = mod_by.get((d, e))
            nv = M["net5"].to_numpy(float) if M is not None else np.array([])
            rec[e] = float(np.nanmean(nv)) if np.isfinite(nv).any() else np.nan
            rec[f"{e}_value20"] = float(np.nanmedian(M["value20"].to_numpy(float))) if M is not None and len(M) \
                else np.nan
        rows.append(rec)
    R = pd.DataFrame(rows)
    R["period"] = np.where(R["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    return R


def claim3(S: Stat, R: pd.DataFrame) -> Dict[str, dict]:
    di = S.di(R["day"])
    out: Dict[str, dict] = {}
    for rk in RULES:
        cells = {}
        for e in ENGINES:
            for p in PERIODS + ("ALL",):
                m = np.ones(len(R), bool) if p == "ALL" else (R["period"].to_numpy() == p)
                mv, rv, av = R[e].to_numpy(float), R[rk].to_numpy(float), R["all"].to_numpy(float)
                both = m & np.isfinite(mv) & np.isfinite(rv)
                d_mr = S.mean(di, mv - rv, both)
                d_re = S.mean(di, rv - av, m & np.isfinite(rv) & np.isfinite(av))
                r = {"model": S.mean(di, mv, both), "rule": S.mean(di, rv, both), "everything": S.mean(di, av, both),
                     "model_minus_rule": d_mr, "rule_minus_everything": d_re,
                     "overlap": float(np.nanmean(R.loc[m, f"{e}_in_{rk}_top10"])) if m.any() else np.nan,
                     "model_value20": float(np.nanmedian(R.loc[m, f"{e}_value20"])) if m.any() else np.nan,
                     "rule_value20": float(np.nanmedian(R.loc[m, f"{rk}_value20"])) if m.any() else np.nan}
                r.update({k: d_mr[k] for k in ("n", "stat", "lo", "hi")})
                r["cell"] = ("MODEL BETTER" if above(d_mr) else "RULE BETTER" if below(d_mr) else
                             "AS GOOD" if (known(d_mr) and above(d_re)) else "RULE HAS NO EDGE")
                cells[(e, p)] = r
        c = [cells[k]["cell"] for k in CELLS]
        v = ("MATCHES THE MODEL" if all(x in ("AS GOOD", "RULE BETTER") for x in c) else
             "MODEL BETTER" if all(x == "MODEL BETTER" for x in c) else "MIXED")
        out[rk] = {"cells": cells, "verdict": v}
    return out


def universe_rebound(S: Stat, T: pd.DataFrame) -> Dict[str, dict]:
    """Claim 5's difference for every universe stock: per day, the mean x5 of the day's lowest third by ret5 minus
    the highest third, averaged over days."""
    U = T.loc[~T["etf"].to_numpy() & np.isfinite(T["x_r5"].to_numpy(float)) & np.isfinite(T["p_ret5"].to_numpy(float)),
              ["day", "p_ret5", "x_r5"]]
    p = U["p_ret5"].to_numpy(float)
    D = pd.DataFrame({"day": U["day"].to_numpy(), "lo": np.where(p <= 1 / 3, U["x_r5"], np.nan),
                      "hi": np.where(p > 2 / 3, U["x_r5"], np.nan)}).groupby("day").mean()
    D["d"] = D["lo"] - D["hi"]
    D = D.reset_index()
    di = S.di(D["day"])
    per = np.where(D["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    return {p_: S.mean(di, D["d"].to_numpy(float), (per == p_) if p_ != "ALL" else np.ones(len(D), bool))
            for p_ in PERIODS + ("ALL",)}


def profile(S: Stat, Q: pd.DataFrame, T: pd.DataFrame) -> pd.DataFrame:
    di = S.di(Q["day"])
    uni = T.loc[~T["etf"].to_numpy(), ["day"] + list(MEASURES)]
    rows = []
    for e in ENGINES:
        for lane in LANES:
            for p in ("ALL",) + PERIODS:
                m = mask_of(Q, e, p, lane, 3)
                days = np.unique(Q.loc[m, "day"].to_numpy())
                um = uni["day"].isin(days).to_numpy()
                for nm in MEASURES:
                    pc = Q[f"p_{nm}"].to_numpy(float)
                    r = S.mean(di, pc, m)
                    lo20 = S.mean(di, np.where(np.isfinite(pc), (pc <= 0.2) * 100.0, np.nan), m)
                    hi20 = S.mean(di, np.where(np.isfinite(pc), (pc > 0.8) * 100.0, np.nan), m)
                    rows.append({"engine": e, "lane": lane, "period": p, "measure": nm, "n": r["n"],
                                 "mean_pct": r["stat"], "lo": r["lo"], "hi": r["hi"], "bottom20_pct": lo20["stat"],
                                 "bottom20_lo": lo20["lo"], "bottom20_hi": lo20["hi"], "top20_pct": hi20["stat"],
                                 "top20_lo": hi20["lo"], "top20_hi": hi20["hi"],
                                 "picks_median": float(np.nanmedian(Q.loc[m, nm])) if m.any() else np.nan,
                                 "universe_median": float(np.nanmedian(uni.loc[um, nm])) if um.any() else np.nan})
    return pd.DataFrame(rows)


def path_table(S: Stat, Q: pd.DataFrame) -> pd.DataFrame:
    di = S.di(Q["day"])
    rows = []
    for e in ENGINES:
        for lane in LANES:
            for p in ("ALL",) + PERIODS:
                m = mask_of(Q, e, p, lane, 3)
                for k in [f"r{k}" for k in range(1, KMAX + 1)] + ["open6"]:
                    x = S.mean(di, Q[f"x_{k}"].to_numpy(float), m)
                    rows.append({"engine": e, "lane": lane, "period": p, "point": k, "n": x["n"],
                                 "excess": x["stat"], "lo": x["lo"], "hi": x["hi"],
                                 "pick_raw": float(np.nanmean(Q.loc[m, k])) if m.any() else np.nan,
                                 "market": float(np.nanmean(Q.loc[m, f"u_{k}"])) if m.any() else np.nan})
    return pd.DataFrame(rows)


def examples(Q: pd.DataFrame) -> pd.DataFrame:
    need = list(MEASURES) + [f"r{k}" for k in range(1, KMAX + 1)] + ["dn8", "vb"]
    ok = (~Q["etf"].to_numpy()) & (Q["rank"].to_numpy() <= 3) & Q[need].notna().all(axis=1).to_numpy()
    rng = np.random.default_rng(SEED)
    parts = []
    for e in ENGINES:
        for lane in ("CALM", "JUMPY"):
            G = Q[ok & (Q["engine"].to_numpy() == e) & np.isin(Q["lane"].to_numpy(), LANES[lane])]
            G = G.sort_values("trade_id")
            if len(G):
                parts.append(G.iloc[np.sort(rng.choice(len(G), min(3, len(G)), replace=False))].assign(group=f"{e} {lane}"))
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


# ---------------------------------------------------------------------------------------------------- the report
def _f(x, nd=2, sign=True) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


def _ci(r: dict, nd=2, sign=True) -> str:
    if not known(r):
        return "[-]"
    return f"[{_f(r['lo'], nd, sign)}, {_f(r['hi'], nd, sign)}]"


def _s(r: dict, nd=2, sign=True, unit="") -> str:
    return f"{_f(r.get('stat', np.nan), nd, sign)}{unit} {_ci(r, nd, sign)}"


SHORT = {1: "share of picks in the day's bottom 20% by 5-day return (chance 20%)",
         2: "share of picks in the day's top 20% by ATR % (chance 20%)",
         4: "pick's D1-open-to-D5-close return minus its 10 look-alike unpicked stocks' (points)",
         5: "own move D1 open to D5 close, most-fallen third of picks minus least-fallen third (points)",
         6: "own move D1 open to D2 close / D2 close to D5 close (points)",
         7: "own move D5 close to D10 close (points)",
         8: "D1-D3 volume vs its own 20-day average (log) / vs look-alike stocks (log)",
         9: "share hitting -8% under the D1 open by D5: third closest to the 20-day low minus the farthest (points)"}


def cell_text(cid: int, r: dict) -> str:
    if cid in (1, 2):
        return f"{_f(r['stat'], 1, False)}% {_ci(r, 1, False)}"
    if cid == 6:
        return f"{_s(r['x2'])} / {_s(r['x2_5'])}"
    if cid == 8:
        return f"{_s(r['vb'], 3)} / {_s(r['vs_similar'], 3)}"
    return _s(r)


def md_cells(cid: int, cells: Dict[tuple, dict]) -> List[str]:
    L = ["| engine | 2020-23 | 2024-26 | 2020-26 (shown, not judged) |", "|---|---|---|---|"]
    for e in ENGINES:
        row = [f"| {e} "]
        for p in PERIODS + ("ALL",):
            r = cells.get((e, p))
            row.append(f"| {cell_text(cid, r)}{' **' + r['cell'] + '**' if p != 'ALL' else ''} " if r else "| - ")
        L.append("".join(row) + "|")
    return L


def claim3_md(L3: dict) -> List[str]:
    L = ["## 3. " + CLAIMS[3], "",
         "Per signal day: the mean net (buy the D1 open, sell the D5 close, 0.35 points) of the engine's ranks 1-3 "
         "vs each rule's 3 stocks from the same universe, paired by day (points per trade).", ""]
    for rk in RULES:
        L += [f"**{rk} - {RULES[rk][1]}: {L3[rk]['verdict']}**", "",
              "| engine | period | model | rule | everything | model - rule | rule - everything | model picks in "
              "rule's top 10 | rupees/day traded (model / rule) | cell |", "|---|---|---|---|---|---|---|---|---|---|"]
        for e in ENGINES:
            for p in PERIODS + ("ALL",):
                r = L3[rk]["cells"][(e, p)]
                L.append(f"| {e} | {PNAME[p]} | {_f(r['model']['stat'])} | {_f(r['rule']['stat'])} | "
                         f"{_f(r['everything']['stat'])} | {_s(r['model_minus_rule'])} | "
                         f"{_s(r['rule_minus_everything'])} | {_f(100 * r['overlap'], 1, False)}% | "
                         f"{_money(r['model_value20'])} / {_money(r['rule_value20'])} | "
                         f"{r['cell'] if p != 'ALL' else '-'} |")
        L.append("")
    return L


def report(res: dict, decl: dict, sha: str, info: dict, secs: float) -> str:
    V, L3 = res["verdicts"], res["claim3"]
    L = [f"# whylab - are the 14 Nov claims about the model's picks true? ({info['run']})", "",
         f"{VERSION} | declaration {sha[:16]} (fixed {decl['declared_at']}) | tree run {info['tree']['run']} | "
         f"{info['picks_judged']:,} ranks 1-3 picks of D and ENS, ETFs out | {secs:.0f} s", "",
         "Each claim is judged in four cells - D and ENS, each in 2020-23 and in 2024-26 - with 95% intervals "
         "(blocks of 10 signal days). **TRUE needs all four.** The pick's own move = its return from the D1 open minus "
         "the average stock's return over the same days.", "",
         "## Verdicts", "", "| # | claim | verdict | calm picks | jumpy picks |", "|---|---|---|---|---|"]
    for cid in range(1, 11):
        if cid == 3:
            v = "; ".join(f"{rk} ({RULES[rk][1]}): **{L3[rk]['verdict']}**" for rk in RULES)
            L.append(f"| 3 | {CLAIMS[3]} | {v} | - | - |")
        elif cid == 10:
            L.append(f"| 10 | {CLAIMS[10]} | **NOT TESTED** - no announcement data in the pipeline | - | - |")
        else:
            L.append(f"| {cid} | {CLAIMS[cid]} | **{V['ALL'][cid]}** | {V['CALM'][cid]} | {V['JUMPY'][cid]} |")
    L += ["", "Calm and jumpy use the tree's lanes (from 2021; their 2020-23 cell is 2021-23).", ""]
    for cid in (1, 2, 3, 4, 5, 6, 7, 8, 9):
        if cid == 3:
            L += claim3_md(L3)
            continue
        L += [f"## {cid}. {CLAIMS[cid]} - **{V['ALL'][cid]}**", "", f"Measured: {SHORT[cid]}.", ""]
        L += md_cells(cid, res["cells"]["ALL"][cid])
        L.append("")
        if cid == 1:
            L.append("Beside it (bottom-20% shares, D / ENS, 2020-26): " + "; ".join(
                f"{MNAME[nm]} {_f(res['cells']['ALL'][1][('D', 'ALL')]['beside'][nm]['stat'], 1, False)}% / "
                f"{_f(res['cells']['ALL'][1][('ENS', 'ALL')]['beside'][nm]['stat'], 1, False)}%"
                for nm in ("rsi7", "pos20", "ret20", "ret60")) + ".")
        if cid == 4:
            for e in ENGINES:
                r = res["cells"]["ALL"][4][(e, "ALL")]
                L.append(f"- {e} 2020-26: the pick's own move {_s(r['pick_excess'])} = the look-alikes' own move "
                         f"{_s(r['type'])} + the model's choice {_s(r)} (points).")
        if cid == 5:
            u = res["universe_rebound"]
            L.append(f"Every stock, not only picks (the same thirds within each day): 2020-23 {_s(u['P1'])}, 2024-26 "
                     f"{_s(u['P2'])} points.")
        if cid == 7:
            L.append("D5 close to the D6 open (own move): " + "; ".join(
                f"{e} {_s(res['cells']['ALL'][7][(e, 'ALL')]['open6'])}" for e in ENGINES) + ".")
        if cid == 9:
            L.append("Beside it, the same with RSI 7 / SDE 3 in place of the 20-day position (2020-26): " + "; ".join(
                f"{e} {_s(res['cells']['ALL'][9][(e, 'ALL')]['beside']['rsi7'])} / "
                f"{_s(res['cells']['ALL'][9][(e, 'ALL')]['beside']['sde3'])}" for e in ENGINES) + ".")
        for lane in ("CALM", "JUMPY"):
            c = res["cells"][lane][cid]
            L.append(f"- {lane.lower()} picks: " + "; ".join(
                f"{e} {PNAME[p]} {cell_text(cid, c[(e, p)])} {c[(e, p)]['cell']}" for e, p in CELLS) +
                f" -> {V[lane][cid]}")
        L.append("")
    L += ["## What the picks look like on the signal day (ranks 1-3, 2020-26)", "",
          "Average percentile among the day's stocks (0.50 = typical; low = the bottom of the day), with the picks' "
          "and the universe's medians.", "",
          "| measure | D percentile | ENS percentile | D median | ENS median | universe median |", "|---|---|---|---|---|---|"]
    Pf = res["profile"]
    for nm in MEASURES:
        a = Pf[(Pf.engine == "D") & (Pf.lane == "ALL") & (Pf.period == "ALL") & (Pf.measure == nm)].iloc[0]
        b = Pf[(Pf.engine == "ENS") & (Pf.lane == "ALL") & (Pf.period == "ALL") & (Pf.measure == nm)].iloc[0]
        L.append(f"| {MNAME[nm]} | {a.mean_pct:.2f} [{a.lo:.2f}, {a.hi:.2f}] | {b.mean_pct:.2f} [{b.lo:.2f}, "
                 f"{b.hi:.2f}] | {_val(nm, a.picks_median)} | {_val(nm, b.picks_median)} | "
                 f"{_val(nm, a.universe_median)} |")
    L += ["", "Calm and jumpy picks separately: profile.csv.", "",
          "## The path after the pick (own move, ranks 1-3, 2020-26)", "",
          "| engine | " + " | ".join(f"D{k} close" for k in range(1, KMAX + 1)) + " | D6 open |",
          "|---|" + "---|" * (KMAX + 1)]
    Pt = res["path"]
    for e in ENGINES:
        X = Pt[(Pt.engine == e) & (Pt.lane == "ALL") & (Pt.period == "ALL")].set_index("point")
        L.append(f"| {e} | " + " | ".join(_f(X.loc[f'r{k}', 'excess']) for k in range(1, KMAX + 1)) +
                 f" | {_f(X.loc['open6', 'excess'])} |")
    L += ["", "Points from the D1 open, after taking out the average stock's move; intervals and calm / jumpy in "
          "path.csv.", "", "## 12 examples, drawn at random (seed 7), not chosen", "",
          "| group | stock | signal day | rank | 5-day return | RSI 7 | 20-day position | ATR % | D1 | D2 | D3 | D5 "
          "| D10 | hit -8% | D1-D3 volume |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in res["examples"].iterrows():
        L.append(f"| {r.group} | {r.symbol} | {pd.Timestamp(r.day).date()} | {int(r['rank'])} | {100 * r.ret5:+.1f}% "
                 f"(pct {r.p_ret5:.2f}) | {r.rsi7:.0f} | {r.pos20:.2f} | {100 * r.atrp:.1f}% | {r.r1:+.1f}% | "
                 f"{r.r2:+.1f}% | {r.r3:+.1f}% | {r.r5:+.1f}% | {r.r10:+.1f}% | {'yes' if r.dn8 > 0.5 else 'no'} "
                 f"| {np.exp(r.vb):.1f}x |")
    L += ["", "Returns D1..D10 are from the D1 open (raw, not own move).", "", "## Data checks", ""]
    g_ = info["gate"]
    L += [f"- Gate: net here = the tree's D1 net on {g_['equal']:,} of {g_['picks']:,} complete picks "
          f"({100 * g_['share']:.2f}%, needs 99%) - **{'PASSED' if g_['passed'] else 'FAILED'}**; no outcome here: "
          f"{g_['no_outcome_here']}.",
          f"- Universe: {info['universe']['stock_days']:,} stock-days, {info['universe']['symbols']:,} symbols "
          f"(median {info['days']['median_universe_per_day']:.0f} stocks a day after {info['days']['etf_rows']:,} "
          f"ETF rows); NSE's ETF list {'used' if info['days']['nse_etf_list'] else 'not found (name rule only)'}.",
          f"- Bars: {info['bars']['no_bars_rows']:,} stock-days without bars, {info['bars']['no_bar_that_day_rows']:,} "
          f"without a bar on the day; {info['bars']['missing_symbol_count']} symbols missing from the cache.",
          f"- Picks: {info['picks']['picks']:,} (ranks 1-10, both engines); not in the panel that day: "
          f"{info['picks']['not_in_panel']}.",
          f"- Look-alike controls: {info['controls_matched']:,} of {info['controls_total']:,} picked stock-days "
          f"matched (10 stocks each), mean distance {info['controls_dist']:.3f} in percentile units.",
          "", "## Not tested", "", "- Claim 10 (news, results): the pipeline has no company-announcement data. Nothing "
          "here stands in for it.", "- What D itself leans on (part K): needs D's own training code; see the "
          "declaration's model_part.", ""]
    return "\n".join(L) + "\n"


def _money(x) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    return f"Rs {x / 1e7:.2f} cr"


def _val(nm: str, x) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    if nm in PCT_MEASURES:
        return f"{100 * x:+.1f}%" if nm not in ("atrp", "vol20") else f"{100 * x:.1f}%"
    if nm == "value20":
        return _money(x)
    if nm == "price":
        return f"Rs {x:,.0f}"
    return f"{x:.2f}"


# ---------------------------------------------------------------------------------------------------- the run
def flat_rows(res: dict) -> pd.DataFrame:
    rows = []
    for lane, C in res["cells"].items():
        for cid, cells in C.items():
            for (e, p), r in cells.items():
                rows.append({"claim": cid, "lane": lane, "ranks": "1-3", "engine": e, "period": PNAME[p],
                             "n": r.get("n"), "stat": r.get("stat"), "lo": r.get("lo"), "hi": r.get("hi"),
                             "cell": r.get("cell") if p != "ALL" else "", "verdict": res["verdicts"][lane][cid]})
    for cid, cells in res["cells_r10"].items():
        for (e, p), r in cells.items():
            rows.append({"claim": cid, "lane": "ALL", "ranks": "1-10", "engine": e, "period": PNAME[p],
                         "n": r.get("n"), "stat": r.get("stat"), "lo": r.get("lo"), "hi": r.get("hi"),
                         "cell": r.get("cell") if p != "ALL" else "", "verdict": "(shown, not judged)"})
    for rk, v in res["claim3"].items():
        for (e, p), r in v["cells"].items():
            rows.append({"claim": f"3 {rk}", "lane": "ALL", "ranks": "1-3", "engine": e, "period": PNAME[p],
                         "n": r.get("n"), "stat": r.get("stat"), "lo": r.get("lo"), "hi": r.get("hi"),
                         "cell": r.get("cell") if p != "ALL" else "", "verdict": v["verdict"]})
    return pd.DataFrame(rows)


def rules_rows(res: dict) -> pd.DataFrame:
    rows = []
    for rk, v in res["claim3"].items():
        for (e, p), r in v["cells"].items():
            rows.append({"rule": rk, "engine": e, "period": PNAME[p], "days": r["n"], "model": r["model"]["stat"],
                         "rule_net": r["rule"]["stat"], "everything": r["everything"]["stat"],
                         "model_minus_rule": r["model_minus_rule"]["stat"], "mr_lo": r["model_minus_rule"]["lo"],
                         "mr_hi": r["model_minus_rule"]["hi"], "rule_minus_everything":
                         r["rule_minus_everything"]["stat"], "re_lo": r["rule_minus_everything"]["lo"],
                         "re_hi": r["rule_minus_everything"]["hi"], "overlap_top10": r["overlap"],
                         "model_value20": r["model_value20"], "rule_value20": r["rule_value20"], "cell": r["cell"],
                         "verdict": v["verdict"]})
    return pd.DataFrame(rows)


def ledger_runs(bout: Path, sha: str) -> List[dict]:
    p = bout / LEDGER
    if not p.is_file():
        return []
    out = []
    for ln in p.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(ln)
        except json.JSONDecodeError:
            continue
        if r.get("declaration_sha256") == sha and r.get("event") == "run":
            out.append(r)
    return out


def new_run_dir(SL, base: Path) -> Path:
    return SL.new_run_dir(base / "runs", "WHY")


def analyse(SL, P: pd.DataFrame, T: pd.DataFrame, root: Path, log=say) -> Tuple[dict, dict, pd.DataFrame]:
    """Everything after the bars: the day frame, controls, the gate, the claims."""
    T, Ud, dinfo = day_frame(SL, T, P, root)
    C = controls(T, log)
    Q, pinfo = pick_table(P, T, Ud, C)
    g_ = gate(Q)
    info = {"days": dinfo, "picks": pinfo, "gate": g_, "controls_total": int(len(C)),
            "controls_matched": int((C["c_n"] == NN).sum()),
            "controls_dist": float(np.nanmean(C["c_dist"])) if len(C) else np.nan}
    log(f" gate: {g_['equal']:,} of {g_['picks']:,} picks give the tree's D1 net ({100 * g_['share']:.2f}%)")
    if not g_["passed"]:
        raise GateFailed(f"only {100 * g_['share']:.2f}% of {g_['picks']:,} picks give the tree's D1 net (needs 99%) "
                         f"- bars or dates misaligned; e.g. {g_['examples'][:3]}")
    S = Stat(SL, P["day"].to_numpy())
    cells = {lane: claim_cells(S, Q, lane, 3) for lane in LANES}
    res = {"cells": cells, "cells_r10": claim_cells(S, Q, "ALL", 10)}
    res["verdicts"] = {lane: {cid: verdict(cid, c) for cid, c in cells[lane].items()} for lane in LANES}
    R = rules_daily(T, Q)
    res["claim3"] = claim3(S, R)
    res["universe_rebound"] = universe_rebound(S, T)
    res["profile"] = profile(S, Q, T)
    res["path"] = path_table(S, Q)
    res["examples"] = examples(Q)
    res["rules_daily"] = R
    info["picks_judged"] = int((~Q["etf"] & (Q["rank"] <= 3)).sum())
    return res, info, Q


def execute(SL, decl: dict, sha: str, root: Path, base: Path, bout: Path, stage_e_any: bool = False,
            rerun_reason: Optional[str] = None, log=say) -> Path:
    t0 = time.time()
    prev = ledger_runs(bout, sha)
    if prev and not rerun_reason:
        raise WHError(f"this declaration already ran ({prev[-1].get('run')}); a second run needs --rerun-reason "
                      f"\"<a verified bug>\" (recorded in the ledger)")
    P, tinfo = read_picks(base)
    log(f"{VERSION}: tree run {tinfo['run']} - {len(P):,} picks of D and ENS, ranks 1-10, "
        f"{pd.Timestamp(P['day'].min()).date()} .. {pd.Timestamp(P['day'].max()).date()}")
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    days = np.unique(P["day"].to_numpy().astype("datetime64[D]"))
    U, uinfo = read_universe(root, days, log)
    missing_pick_days = sorted(set(days.tolist()) - set(np.unique(U["day"].to_numpy().astype("datetime64[D]")).tolist()))
    T, binfo = assemble(SL, market, U, log)
    res, info, Q = analyse(SL, P, T, root, log)
    run = new_run_dir(SL, bout)
    info.update({"run": run.name, "tree": tinfo, "universe": uinfo, "bars": binfo,
                 "pick_days_without_panel_rows": [str(d) for d in missing_pick_days[:20]],
                 "production": prod.describe()})
    secs = time.time() - t0
    (run / "REPORT.md").write_text(report(res, decl, sha, info, secs), encoding="utf-8")
    flat_rows(res).to_csv(run / "claims.csv", index=False, float_format="%.10g")
    res["profile"].to_csv(run / "profile.csv", index=False, float_format="%.10g")
    res["path"].to_csv(run / "path.csv", index=False, float_format="%.10g")
    rules_rows(res).to_csv(run / "rules.csv", index=False, float_format="%.10g")
    res["examples"].to_csv(run / "examples.csv", index=False, float_format="%.10g")
    Q.to_parquet(run / "picks.parquet", index=False)
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    meta = {"version": VERSION, "declaration_sha256": sha, "root": str(root), "seconds": round(secs, 1),
            "verdicts": {lane: {str(k): v for k, v in vs.items()} for lane, vs in res["verdicts"].items()},
            "rules": {rk: v["verdict"] for rk, v in res["claim3"].items()},
            "info": json.loads(json.dumps(info, default=str)), "rerun_reason": rerun_reason,
            "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__}
    (run / "run.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    SL.write_hashes(run, ["REPORT.md", "claims.csv", "profile.csv", "path.csv", "rules.csv", "examples.csv",
                          "picks.parquet", "run.json", "DECLARATION.json"])
    rec = {"event": "run", "run": run.name, "at": dt.datetime.now().isoformat(timespec="seconds"),
           "declaration_sha256": sha, "version": VERSION, "tree_run": tinfo["run"],
           "verdicts": meta["verdicts"]["ALL"], "rules": meta["rules"], "rerun_reason": rerun_reason}
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    log(f"RESULT: " + "; ".join(f"{k} {v}" for k, v in meta["verdicts"]["ALL"].items()) + "; rules " +
        ", ".join(f"{k} {v}" for k, v in meta["rules"].items()))
    log(f"DONE -> {run}")
    return run


# ==================================================================================== PART K (v1.1)
# What D itself relies on: D's 5 walk-forward folds rebuilt with stage D's own recipe (production imported read
# only), proven equal to the frozen scores, then one group of inputs at a time scrambled on the test days.
K_FILE = HERE / "WHY_K_DECLARATION.json"
K_SHA = "158621297b5013235efcdc4cd99f518ae203c9555b6c00da283566f357cdd342"
K_TARGET = "label_oc_5"
K_REPEATS = (7, 8, 9)
K_GATE_TOP3 = 0.99
K_GATE_RHO = 0.999
K_DAYCONST = 0.99
K_CHUNK = 200_000
SD_NEEDS = ("CFG", "make_label", "eligible_mask", "horizon_of")
SB_NEEDS = ("ELIG_COL", "_read_col", "_naive")


def load_k(path: Path = K_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != K_SHA:
        raise WHError(f"{Path(path).name} has sha256 {sha[:16]}, not the pinned {K_SHA[:16]} - the declaration is "
                      f"fixed before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def k_modules():
    """Production's stage D code, imported read only (env_whylab.bat puts bigmove_deploy\\open_close first)."""
    try:
        import stage_d_gate as SD
        import stage_b_screen as SB
    except ImportError as e:
        raise WHError(f"cannot import production's stage D code ({e}) - start with env_whylab.bat (it puts "
                      f"bigmove_deploy\\open_close on PYTHONPATH)")
    miss = [f"stage_d_gate.{n}" for n in SD_NEEDS if not hasattr(SD, n)] + \
        [f"stage_b_screen.{n}" for n in SB_NEEDS if not hasattr(SB, n)]
    if miss:
        raise WHError(f"production's stage D code lacks {miss} - not the frozen version?")
    return SD, SB


def k_families(feats: List[str], decl: dict) -> List[Tuple[str, List[int]]]:
    """Each input to the first family whose pattern matches its lower-case name (declaration order)."""
    import re
    pats = [(n, re.compile(p)) for n, p in decl["families"]]
    out = {n: [] for n, _ in pats}
    for j, f in enumerate(feats):
        for n, pat in pats:
            if pat.search(f.lower()):
                out[n].append(j)
                break
    return [(n, out[n]) for n, _ in pats if out[n]]


def k_inputs(root: Path, SD) -> dict:
    """The frozen D run, every file checked against FROZEN_ENGINES.json."""
    pp = root / "panel_oc" / "panel.parquet"
    fz = root / "panel_oc" / "frozen" / "FROZEN_ENGINES.json"
    for p in (pp, fz):
        if not p.is_file():
            raise WHError(f"{p} not found")
    man = json.loads(fz.read_text(encoding="utf-8"))
    run = man["engines"]["D"]["run"]
    if man.get("target") != K_TARGET:
        raise WHError(f"FROZEN_ENGINES.json's target is {man.get('target')}, not {K_TARGET}")
    rd = root / "panel_oc" / "stage_d" / run
    files = man.get("files", {})
    want = {"stage_d_gate.py": (Path(SD.__file__), files.get("code/stage_d_gate.py")),
            "stage_d.json": (rd / "stage_d.json", files.get(f"runs/D/{run}/stage_d.json")),
            "preds.parquet": (rd / "preds.parquet", files.get(f"runs/D/{run}/preds.parquet"))}
    for nm, (p, h) in want.items():
        if not Path(p).is_file():
            raise WHError(f"{p} not found")
        if not h:
            raise WHError(f"FROZEN_ENGINES.json records no sha256 for {nm}")
        got = TC.sha256_file(p)
        if got != h:
            raise WHError(f"{p} has sha256 {got[:16]}, not the frozen {h[:16]} (FROZEN_ENGINES.json) - refusing")
    sd = json.loads((rd / "stage_d.json").read_text(encoding="utf-8"))
    if json.loads(json.dumps(sd.get("config"))) != json.loads(json.dumps(SD.CFG)):
        raise WHError("stage_d.json's config differs from stage_d_gate.CFG - not the frozen recipe")
    folds = [f for f in sd.get("folds", []) if f.get("target") == K_TARGET]
    if not sd.get("features") or len(folds) != int(SD.CFG["n_splits"]):
        raise WHError(f"stage_d.json lists {len(sd.get('features') or [])} features and {len(folds)} {K_TARGET} folds")
    return {"pp": pp, "run": run, "rd": rd, "feats": list(sd["features"]), "folds": folds, "frozen": man,
            "stage_d_gate": str(Path(SD.__file__).resolve())}


def k_load(SD, SB, pp: Path, feats: List[str], log=say):
    """Eligible rows sorted by (session, symbol), the target and the feature matrix - as run_gate builds them."""
    base = pd.read_parquet(pp, columns=["timestamp", "symbol", SB.ELIG_COL])
    ts = np.asarray(SB._naive(base["timestamp"])).astype("datetime64[ns]")
    sym = base["symbol"].astype(str).to_numpy()
    buy = pd.to_numeric(base[SB.ELIG_COL], errors="coerce").to_numpy(dtype=float)
    del base
    el = SD.eligible_mask(buy)
    order = np.lexsort((sym, ts))
    sel = order[el[order]]
    ts_s, sym_s = ts[sel], sym[sel]
    sessions = np.unique(ts_s)
    day = np.searchsorted(sessions, ts_s)
    y = np.asarray(SB._read_col(pp, K_TARGET), dtype=float)[sel]
    X = np.empty((len(sel), len(feats)), dtype=np.float32)
    t0 = time.time()
    for j, f in enumerate(feats):
        X[:, j] = SB._read_col(pp, f)[sel]
        if j and j % 50 == 0:
            log(f"   features: {j} of {len(feats)} ({time.time() - t0:.0f}s)")
    log(f" K: {len(sel):,} eligible rows of {len(ts):,}, {len(feats)} features ({X.nbytes / 1e9:.2f} GB)")
    return ts_s, sym_s, sessions, day, y, X


def k_fit(SD, X, y, day, sessions, folds, log=say):
    """stage_d_gate.run_gate's fold loop for the target, unchanged: the fitted models and every test score."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    cfg = SD.CFG
    h = SD.horizon_of(K_TARGET)
    sidx = {np.datetime64(s, "ns"): i for i, s in enumerate(sessions)}
    score = np.full(len(day), np.nan)
    fits = []
    for f in folds:
        fo = int(f["fold"])
        tr_end = sidx[np.datetime64(pd.Timestamp(f["train_end"]), "ns")]
        te0 = sidx[np.datetime64(pd.Timestamp(f["test_start"]), "ns")]
        te1 = sidx[np.datetime64(pd.Timestamp(f["test_end"]), "ns")]
        tr = np.flatnonzero((day <= tr_end) & np.isfinite(y))
        gap = te0 - int(day[tr].max())
        if gap <= h:
            raise WHError(f"fold {fo}: the last training row is {gap} sessions before the test window")
        lab, lo, hi = SD.make_label(y[tr], day[tr], cfg["winsor_pct"])
        rng = np.random.default_rng([cfg["seed"], fo, h])
        keep = (np.arange(len(tr)) if len(tr) <= cfg["fit_cap"]
                else np.sort(rng.choice(len(tr), cfg["fit_cap"], replace=False)))
        fit_i, fit_lab = tr[keep], lab[keep]
        t1 = time.time()
        model = HistGradientBoostingRegressor(random_state=cfg["seed"], **cfg["hgb"])
        model.fit(X[fit_i], fit_lab)
        te = np.flatnonzero((day >= te0) & (day <= te1))
        for a in range(0, len(te), K_CHUNK):
            b = te[a:a + K_CHUNK]
            score[b] = model.predict(X[b])
        fits.append({"fold": fo, "model": model, "te": te, "train_rows": int(len(tr)), "fit_rows": int(len(fit_i)),
                     "test_rows": int(len(te)), "recorded": {k: f.get(k) for k in ("train_rows", "fit_rows",
                                                                                    "test_rows")}})
        log(f" K: fold {fo} trained on {len(fit_i):,} of {len(tr):,} rows to {f['train_end']}, scored {len(te):,} "
            f"rows {f['test_start']}..{f['test_end']} ({time.time() - t1:.0f}s)")
    return fits, score


def day_ranks(day: np.ndarray, sym: np.ndarray, val: np.ndarray) -> np.ndarray:
    """Position of each row within its day: score descending, ties by symbol (stage D's daily_top_n order)."""
    o = np.lexsort((sym, -val, day))
    d = day[o]
    first = np.r_[True, d[1:] != d[:-1]]
    gstart = np.flatnonzero(first)
    pos = np.empty(len(o), dtype=np.int64)
    pos[o] = np.arange(len(o)) - np.repeat(gstart, np.diff(np.r_[gstart, len(o)]))
    return pos


def k_gate(rd: Path, ts_s, sym_s, day, score) -> dict:
    """The rebuilt scores against preds.parquet: same top 3 (stage D's ranking) and the daily rank correlation."""
    P = pd.read_parquet(rd / "preds.parquet", columns=["timestamp", "symbol", "target", "score"])
    P = P[P["target"].astype(str) == K_TARGET]
    P = pd.DataFrame({"timestamp": pd.to_datetime(P["timestamp"]).to_numpy(dtype="datetime64[ns]"),
                      "symbol": P["symbol"].astype(str).to_numpy(), "frozen": P["score"].to_numpy(float)})
    m = np.isfinite(score)
    A = pd.DataFrame({"timestamp": ts_s[m], "symbol": sym_s[m], "day": day[m], "mine": score[m]})
    J = A.merge(P, on=["timestamp", "symbol"], how="outer", indicator=True)
    both = J[J["_merge"] == "both"].copy()
    out = {"rows_rebuilt": int(m.sum()), "rows_frozen": int(len(P)), "rows_matched": int(len(both)),
           "only_rebuilt": int((J["_merge"] == "left_only").sum()), "only_frozen": int((J["_merge"] == "right_only").sum())}
    if both.empty:
        out.update({"days": 0, "same_top3_share": 0.0, "median_rho": float("nan"), "max_abs_diff": float("nan"),
                    "passed": False})
        return out
    d = both["day"].to_numpy()
    sy = both["symbol"].to_numpy()
    mine, frz = both["mine"].to_numpy(float), both["frozen"].to_numpy(float)
    t1 = day_ranks(d, sy, mine) < 3
    t2 = day_ranks(d, sy, frz) < 3
    days = np.unique(d)
    di = np.searchsorted(days, d)
    agree = np.bincount(di[t1 & t2], minlength=len(days))
    same = agree == np.minimum(3, np.bincount(di, minlength=len(days)))
    r1 = both.groupby("day")["mine"].rank().to_numpy(float)
    r2 = both.groupby("day")["frozen"].rank().to_numpy(float)
    n = np.bincount(di, minlength=len(days)).astype(float)
    s1, s2 = np.bincount(di, r1, len(days)), np.bincount(di, r2, len(days))
    s11, s22, s12 = (np.bincount(di, r1 * r1, len(days)), np.bincount(di, r2 * r2, len(days)),
                     np.bincount(di, r1 * r2, len(days)))
    with np.errstate(invalid="ignore", divide="ignore"):
        cov = s12 / n - (s1 / n) * (s2 / n)
        rho = cov / np.sqrt((s11 / n - (s1 / n) ** 2) * (s22 / n - (s2 / n) ** 2))
    out.update({"days": int(len(days)), "same_top3_share": float(same.mean()),
                "median_rho": float(np.nanmedian(rho)), "max_abs_diff": float(np.max(np.abs(mine - frz)))})
    out["passed"] = bool(out["same_top3_share"] >= K_GATE_TOP3 and out["median_rho"] >= K_GATE_RHO)
    return out


def k_dayconst(X: np.ndarray, fits: list, day: np.ndarray) -> np.ndarray:
    """Per column: one value for every eligible stock (or all blank) on at least 99% of test days."""
    const = np.zeros(X.shape[1])
    ndays = 0
    for f in fits:
        te = f["te"]
        G = pd.DataFrame(X[te]).groupby(day[te])
        mn, mx, cnt, size = G.min(), G.max(), G.count(), G.size().to_numpy()[:, None]
        c = ((mn.to_numpy() == mx.to_numpy()) & (cnt.to_numpy() == size)) | (cnt.to_numpy() == 0)
        const += c.sum(axis=0)
        ndays += len(size)
    return const / max(ndays, 1) >= K_DAYCONST


def k_scramble(Xt: np.ndarray, dt: np.ndarray, cols: List[int], dc: np.ndarray, rng) -> np.ndarray:
    """Xt with the family's columns scrambled: stock-varying ones across the day's stocks (one permutation per
    day, the same for all of them), day-constant ones across the window's days (each day gets another's values)."""
    Xp = Xt.copy()
    vc = [c for c in cols if not dc[c]]
    cc = [c for c in cols if dc[c]]
    if vc:
        order = np.lexsort((rng.random(len(dt)), dt))
        Xp[:, vc] = Xt[np.ix_(order, vc)]
    if cc:
        first = np.r_[0, np.flatnonzero(np.diff(dt)) + 1]
        perm = rng.permutation(len(first))
        dpos = np.searchsorted(first, np.arange(len(dt)), side="right") - 1
        Xp[:, cc] = Xt[np.ix_(first[perm][dpos], cc)]
    return Xp


def k_top3(dt, st, val, etf):
    """True for the rows in each day's top 3 by score (ETFs out), ties by symbol."""
    v = np.where(etf, -np.inf, val)
    return (day_ranks(dt, st, v) < 3) & ~etf


def k_knockout(fits, X, day, sym, y, etf, fams, dc, log=say):
    """Per family: per test day, the share of the original top 3 replaced and the top-3 mean net after minus before
    (each the mean over the repeats). Returns (days, base net per day, {family: (changed, diff)})."""
    net = (y - COST / 100) * 100
    days_all, base_all = [], []
    res = {nm: [[], []] for nm, _ in fams}
    t0 = time.time()
    for f in fits:
        te = f["te"]
        Xt, dt, st, yt, et = X[te], day[te], sym[te], net[te], etf[te]
        s0 = np.concatenate([f["model"].predict(Xt[a:a + K_CHUNK]) for a in range(0, len(te), K_CHUNK)])
        c0 = k_top3(dt, st, s0, et)
        dd = np.unique(dt)
        di = np.searchsorted(dd, dt)
        nd = len(dd)

        def day_net(ch):
            ok = ch & np.isfinite(yt)
            s_, c_ = np.bincount(di[ok], yt[ok], nd), np.bincount(di[ok], minlength=nd)
            with np.errstate(invalid="ignore", divide="ignore"):
                return np.where(c_ > 0, s_ / np.maximum(c_, 1), np.nan)
        b0 = day_net(c0)
        n0 = np.bincount(di[c0], minlength=nd)
        days_all.append(dd)
        base_all.append(b0)
        for k, (nm, cols) in enumerate(fams):
            chg, dif = np.zeros(nd), np.zeros(nd)
            for r in K_REPEATS:
                rng = np.random.default_rng([r, int(f["fold"]), k])
                Xp = k_scramble(Xt, dt, cols, dc, rng)
                s1 = np.concatenate([f["model"].predict(Xp[a:a + K_CHUNK]) for a in range(0, len(te), K_CHUNK)])
                del Xp
                c1 = k_top3(dt, st, s1, et)
                kept = np.bincount(di[c0 & c1], minlength=nd)
                with np.errstate(invalid="ignore", divide="ignore"):
                    chg += np.where(n0 > 0, 1 - kept / np.maximum(n0, 1), np.nan)
                dif += day_net(c1) - b0
            res[nm][0].append(chg / len(K_REPEATS))
            res[nm][1].append(dif / len(K_REPEATS))
        log(f" K: fold {f['fold']} knock-outs done ({time.time() - t0:.0f}s)")
    days = np.concatenate(days_all)
    return days, np.concatenate(base_all), {nm: (np.concatenate(v[0]), np.concatenate(v[1])) for nm, v in res.items()}


def k_execute(SL, root: Path, bout: Path, rerun_reason: Optional[str] = None, log=say) -> Path:
    t0 = time.time()
    kd, ksha = load_k()
    prev = [r for r in (json.loads(x) for x in ((bout / LEDGER).read_text(encoding="utf-8").splitlines()
                                                 if (bout / LEDGER).is_file() else []))
            if r.get("event") == "model" and r.get("declaration_sha256") == ksha]
    if prev and not rerun_reason:
        raise WHError(f"part K already ran ({prev[-1].get('run')}); a second run needs --rerun-reason "
                      f"\"<a verified bug>\" (recorded in the ledger)")
    SD, SB = k_modules()
    inp = k_inputs(root, SD)
    log(f"{VERSION} part K: D run {inp['run']}, {len(inp['feats'])} inputs, {len(inp['folds'])} folds of {K_TARGET}; "
        f"stage_d_gate {inp['stage_d_gate']}")
    fams = k_families(inp["feats"], kd)
    ts_s, sym_s, sessions, day, y, X = k_load(SD, SB, inp["pp"], inp["feats"], log)
    fits, score = k_fit(SD, X, y, day, sessions, inp["folds"], log)
    g = k_gate(inp["rd"], ts_s, sym_s, day, score)
    log(f" K gate: same top 3 on {100 * g['same_top3_share']:.2f}% of {g['days']:,} days, median rank correlation "
        f"{g['median_rho']:.6f} -> {'PASSED' if g['passed'] else 'FAILED'}")
    run = SL.new_run_dir(bout / "model", "K")
    folds_tab = pd.DataFrame([{"fold": f["fold"], "train_rows": f["train_rows"], "fit_rows": f["fit_rows"],
                               "test_rows": f["test_rows"], **{f"recorded_{k}": v for k, v in f["recorded"].items()}}
                              for f in fits])
    inputs_tab = pd.DataFrame([{"input": inp["feats"][j], "family": nm} for nm, cols in fams for j in cols])
    fam_rows, base, days = [], None, None
    if g["passed"]:
        try:
            _, tdoc = SL.load_tree()
            listed = SL.etf_list(root)
        except ValueError as e:
            raise WHError(f"setuplab's ETF rule is not usable: {e}")
        etf = SL.tree_etf(sym_s, tdoc, listed)
        dc = k_dayconst(X, fits, day)
        inputs_tab["day_constant"] = [bool(dc[inp["feats"].index(x)]) for x in inputs_tab["input"]]
        days_i, base_net, R = k_knockout(fits, X, day, sym_s, y, etf, fams, dc, log)
        days = sessions[days_i].astype("datetime64[D]")
        S = Stat(SL, days)
        di = S.di(days)
        per = np.where(days < P2_START, "P1", "P2")
        base = {p: S.mean(di, base_net, (per == p) if p != "ALL" else np.ones(len(days), bool))
                for p in ("ALL",) + PERIODS}
        for nm, cols in fams:
            chg, dif = R[nm]
            row = {"family": nm, "inputs": len(cols), "day_constant": int(sum(bool(dc[c]) for c in cols)),
                   "picks_changed_pct": 100 * float(np.nanmean(chg))}
            for p in ("ALL",) + PERIODS:
                m = (per == p) if p != "ALL" else np.ones(len(days), bool)
                r = S.mean(di, dif, m)
                row.update({f"lost_{p}": r["stat"], f"lo_{p}": r["lo"], f"hi_{p}": r["hi"]})
            row["verdict"] = "RELIES ON" if np.isfinite(row["hi_ALL"]) and row["hi_ALL"] < 0 else "NO CLEAR RELIANCE"
            fam_rows.append(row)
    F = pd.DataFrame(fam_rows)
    if len(F):
        F = F.sort_values("lost_ALL").reset_index(drop=True)
    secs = time.time() - t0
    info = {"run": run.name, "d_run": inp["run"], "gate": g, "stage_d_gate": inp["stage_d_gate"], "seconds": secs,
            "rows": int(len(day)), "inputs": len(inp["feats"])}
    (run / "KREPORT.md").write_text(k_report(F, g, folds_tab, inputs_tab, base, kd, ksha, info), encoding="utf-8")
    F.to_csv(run / "families.csv", index=False, float_format="%.10g")
    inputs_tab.to_csv(run / "inputs.csv", index=False)
    pd.DataFrame([g]).to_csv(run / "gate.csv", index=False, float_format="%.10g")
    folds_tab.to_csv(run / "folds.csv", index=False)
    (run / "DECLARATION.json").write_bytes(K_FILE.read_bytes())
    meta = {"version": VERSION, "declaration_sha256": ksha, "root": str(root), "info": info,
            "verdicts": {r["family"]: r["verdict"] for r in fam_rows}, "rerun_reason": rerun_reason,
            "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__}
    try:
        import sklearn
        meta["sklearn"] = sklearn.__version__
    except ImportError:
        pass
    (run / "run.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    SL.write_hashes(run, ["KREPORT.md", "families.csv", "inputs.csv", "gate.csv", "folds.csv", "DECLARATION.json",
                          "run.json"])
    rec = {"event": "model", "run": run.name, "at": dt.datetime.now().isoformat(timespec="seconds"),
           "declaration_sha256": ksha, "version": VERSION, "gate_passed": g["passed"], "verdicts": meta["verdicts"],
           "rerun_reason": rerun_reason}
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    if not g["passed"]:
        log(f"STOPPED: the rebuild does not reproduce the frozen scores - no knock-out ran ({run})")
        raise GateFailed(f"part K gate failed: same top 3 on {100 * g['same_top3_share']:.2f}% of days, median rank "
                         f"correlation {g['median_rho']:.6f} (needs 99% and 0.999); report in {run}")
    log("RESULT: " + "; ".join(f"{r['family']} {r['verdict']} ({_f(r['lost_ALL'])})" for r in F.to_dict("records")))
    log(f"DONE -> {run}")
    return run


def k_report(F, g, folds_tab, inputs_tab, base, kd, ksha, info) -> str:
    L = [f"# whylab part K - what D itself relies on ({info['run']})", "",
         f"{VERSION} | K declaration {ksha[:16]} (fixed {kd['declared_at']}) | D run {info['d_run']} | "
         f"{info['rows']:,} eligible rows, {info['inputs']} inputs | {info['seconds']:.0f} s", "",
         "D's 5 walk-forward folds were rebuilt with stage D's own code and settings (production imported read only). "
         "Then one group of inputs at a time was scrambled on the test days - shuffled across the day's stocks, or "
         "across days for inputs that are the same for every stock - and the same fitted models re-picked the top 3 "
         "(ETFs out). **D relies on a group when scrambling it costs money**: the 95% interval of the change in the "
         "top-3 net per trade is below 0 (D1 open to D5 close, 0.35 points of costs).", "",
         "## The rebuild must equal the frozen D first", "",
         f"- Same top 3 as the frozen scores on **{100 * g['same_top3_share']:.2f}%** of {g['days']:,} days (needs 99%); "
         f"median daily rank correlation **{g['median_rho']:.6f}** (needs 0.999); largest score difference "
         f"{g['max_abs_diff']:.3g}. Rows: rebuilt {g['rows_rebuilt']:,}, frozen {g['rows_frozen']:,}, matched "
         f"{g['rows_matched']:,}. -> **{'PASSED' if g['passed'] else 'FAILED'}**", ""]
    L += ["| fold | train rows | fit rows | test rows | recorded train / fit / test |", "|---|---|---|---|---|"]
    for _, r in folds_tab.iterrows():
        L.append(f"| {r['fold']} | {r['train_rows']:,} | {r['fit_rows']:,} | {r['test_rows']:,} | "
                 f"{r.get('recorded_train_rows')} / {r.get('recorded_fit_rows')} / {r.get('recorded_test_rows')} |")
    if not g["passed"]:
        L += ["", "**No knock-out ran: the rebuild is not the frozen D, so nothing measured on it could be called "
              "D's.** Send this report and gate.csv.", ""]
        return "\n".join(L) + "\n"
    L += ["", "## What D relies on (ranked by the money lost when the group is scrambled)", "",
          f"The rebuilt top 3 (ETFs out) made {_s(base['ALL'])} points a trade over 2020-26 "
          f"(2020-23 {_s(base['P1'])}, 2024-26 {_s(base['P2'])}).", "",
          "| group | inputs | picks replaced | money lost per trade, 2020-26 | 2020-23 | 2024-26 | verdict |",
          "|---|---|---|---|---|---|---|"]
    for _, r in F.iterrows():
        L.append(f"| {r['family']} | {r['inputs']}{' (' + str(r['day_constant']) + ' same for every stock)' if r['day_constant'] else ''} "
                 f"| {r['picks_changed_pct']:.1f}% | {_f(r['lost_ALL'])} [{_f(r['lo_ALL'])}, {_f(r['hi_ALL'])}] | "
                 f"{_f(r['lost_P1'])} [{_f(r['lo_P1'])}, {_f(r['hi_P1'])}] | {_f(r['lost_P2'])} [{_f(r['lo_P2'])}, "
                 f"{_f(r['hi_P2'])}] | **{r['verdict']}** |")
    raw = F[F["family"] == "raw price levels"]
    if len(raw):
        r = raw.iloc[0]
        L += ["", f"**Raw price levels** (the question open since 1 Nov): {r['inputs']} inputs - "
              + ", ".join(inputs_tab.loc[inputs_tab.family == "raw price levels", "input"]) +
              f". Scrambling them replaced {r['picks_changed_pct']:.1f}% of the picks and changed the net by "
              f"{_f(r['lost_ALL'])} [{_f(r['lo_ALL'])}, {_f(r['hi_ALL'])}] points a trade -> **{r['verdict']}**."]
    L += ["", "Picks replaced = the share of the original top-3 picks no longer in the top 3 (mean over days and the 3 "
          "repeats). A group can move many picks and cost nothing (the replacements are as good) - only the money "
          "decides.", "", "## Every input and its group", ""]
    for nm in inputs_tab["family"].unique():
        xs = inputs_tab[inputs_tab.family == nm]
        L.append(f"- **{nm}** ({len(xs)}): " + ", ".join(
            x + ("*" if dcx else "") for x, dcx in zip(xs["input"], xs.get("day_constant", [False] * len(xs)))))
    L += ["", "* = the same for every stock on the day: scrambled across days.", ""]
    return "\n".join(L) + "\n"


def cmd_model(a) -> int:
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    bout = out_base(a.out, root)
    k_execute(SL, root, bout, a.rerun_reason)
    return 0


def cmd_check(a) -> int:
    decl, sha = load_decl()
    kd, ksha = load_k()
    SL = libs()
    print(f"{VERSION}: declaration {sha[:16]} OK ({decl['declared_at']}); part K declaration {ksha[:16]} OK; "
          f"{SL.VERSION}; "
          f"{getattr(TC, 'VERSION', 'tradelab ?')} / {getattr(SU, 'SETUPS_VERSION', 'tl_setups ?')}; "
          f"pandas {pd.__version__}; numpy {np.__version__}")
    return 0


def cmd_run(a) -> int:
    decl, sha = load_decl()
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    base = Path(a.setups or os.environ.get("SETUPLAB_OUT") or "")
    if not str(base) or not base.is_dir():
        raise WHError("pass --setups <setuplab output folder> or start with env_whylab.bat (sets SETUPLAB_OUT)")
    bout = out_base(a.out, root)
    execute(SL, decl, sha, root, base, bout, a.stage_e_any, a.rerun_reason)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="whylab", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check")
    k = sub.add_parser("model")
    k.add_argument("--root")
    k.add_argument("--out")
    k.add_argument("--rerun-reason")
    r = sub.add_parser("run")
    r.add_argument("--root")
    r.add_argument("--setups")
    r.add_argument("--out")
    r.add_argument("--stage-e-any", action="store_true")
    r.add_argument("--rerun-reason")
    a = ap.parse_args(argv)
    try:
        return {"check": cmd_check, "run": cmd_run, "model": cmd_model}[a.cmd](a)
    except (WHError, TC.TLError) as e:
        print(f"REFUSED: {e}", flush=True)
        return 2
    except GateFailed as e:
        print(f"STOPPED: {e}", flush=True)
        return 3


if __name__ == "__main__":
    sys.exit(main())
