# MANIFEST - whylab v1.2 (15 Nov 2026)

This research tool lives in its own folder beside tradelab and setuplab. Nothing in `bigmove_deploy`, tradelab or setuplab changes. Production is only read: stage D's code and frozen run, `D.pkl` and the live panel.

| file | what | sha256 (first 16) |
|---|---|---|
| `whylab\whylab.py` | the tool: `check`, `run` (claims), `model` (part K), `explain` and `today` (part P) | 107a2107975f22b5 |
| `whylab\WHY_DECLARATION.json` | the claims' rules, fixed 14 Nov 2026 20:45 IST; unchanged | e3967dd85a42d063 |
| `whylab\WHY_K_DECLARATION.json` | part K's rules, fixed 15 Nov 2026 00:20 IST; unchanged | 158621297b501323 |
| `whylab\WHY_P_DECLARATION.json` | part P's rules, fixed 15 Nov 2026 01:00 IST, before any P run and before part K's result was seen | 99db37895043cc79 |
| `whylab\tests\test_whylab.py` | self-test, 41 checks | ad28209355b3a1a9 |
| `whylab\env_whylab.bat` | session setup (CRLF; labels unique); only its comments changed | e7abcef958e9c7a7 |
| `whylab\README_WHYLAB.md` | what it does, how to run it | 43352427739f4590 |
| `whylab\MANIFEST_WHYLAB.md` | this file | - |

**New library:** shap 0.54.1, needed by part P only.
- Its requirements are numpy>=2, scipy, scikit-learn, pandas, tqdm, packaging, slicer 0.0.8 and cloudpickle, with no upper pins.
- A ready-built Windows version exists (cp312-abi3-win_amd64).
- A dry run on your versions (numpy 2.4.1, pandas 2.3.3, scikit-learn 1.5.2, Python 3.13) changes none of them.

**What it uses unchanged:**
- setuplab v1.1: Boot, TREE.json and its ETF rule, run folders, hashes.
- tradelab: tl_setups v1.7, tl_data, tl_common.
- Imported read only from production:
  - `stage_d_gate.py`, checked against FROZEN_ENGINES.json: CFG, make_label, eligible_mask, horizon_of;
  - `stage_b_screen.py`: ELIG_COL, _read_col, _naive;
  - `paper_pipeline.paths` (today only, to find the live panel).
- `today` checks D.pkl's sha256 and library versions against PRODUCTION.json, as production_models.load_verified does.

**What it writes:** only `C:\QuantData\whylab\runs\WHY_*`, `model\K_*`, `explain\P_*`, `today\` (including `today\checks\`) and `whylab_ledger.jsonl`.

**Verified 15 Nov 2026:** `VERIFIED (whylab v1.2)`, 41 checks, 0 failed.
- On pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2 (your versions): 104 s.
- On pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1: 124 s.
- Both with shap 0.54.1, and from a clean folder.

**Planted bugs, 58 of 58 caught:**
- **Claims part (v1.0, 26):** listed in v1.0's manifest; that code is unchanged.
- **Part K (v1.1, 12):** listed in v1.1's manifest; that code is unchanged.
- **Part P (20):**
  - comparison and explanation:
    - the comparison keeps the day's picks;
    - it keeps ETFs;
    - path-dependent shap instead of interventional;
    - explanations not checked;
    - a pick re-explained one session early;
    - the status read on the day's top group instead of the original reason;
  - the vote:
    - 2 of 3 versions enough;
    - check versions drawn without replacement;
    - V1 and V2 sharing one draw;
  - the tests:
    - T2's hold chosen on 2024-26;
    - T2's edge not per day;
    - T3 from the close instead of the next open;
    - T3 taking the last gone close;
    - T4's hurdle without costs;
    - T4's interval treating overlapping groups as apart;
    - 50 picks enough;
    - the outcome gate at 90%;
  - `today`:
    - check versions not verified;
    - D.pkl not reproduced first;
    - ETFs picked.

**Fixed while building (synthetic data only, before any P run):**
- **T4's interval.** setuplab-style differences assume two separate groups of picks. T4 compares the held picks with all picks, which include them. The first version's interval did not even contain its own estimate. Part P now resamples the two means separately on the same days. The test recomputes the interval by hand from the resampling matrix; the original version fails it.
- **The by-hand tolerance.** shap's interventional values match the Shapley definition to about 1e-8 of their size, not 1e-12. On D's scale (scores about 0.01) that is about 1e-10, far below anything reported.

**Run times** are estimates for your PC, not measured: `explain` about 20-25 minutes, scaled from part K's measured 1,624 s and the explanation speed timed here; `today` 4-5 minutes the first time, then under a minute.
