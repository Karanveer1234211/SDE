"""
tests/test_whylab.py - whylab v1.0 self-test.

    cd /d C:\\Users\\karanvsi\\PyCharmMiscProject\\whylab
    python tests\\test_whylab.py

By hand: every measure and outcome against an independent loop (with a suspended session); the look-alike controls;
the rules' daily top 3 (ties by symbol), their overlap and means; every claim's cell and verdict on made-up pick tables
where the claim is planted, absent or reversed. Then whole runs on synthetic caches in the real file layouts (daily
bars, NIFTY50, panel_oc, a setuplab TREE run; tradelab's production stand-ins):
  PLANTED - stocks crash over 5 days, rebound on D1-D2 with 3x volume, sit still to D5, give back on D6-D10; half
            close the crash at their low and dip 10% on D1; the engines pick the biggest falls in ATRs
  FALLEN  - the same picks by fall, but no rebound, no volume, no dip: the after-the-pick claims must not hold
  RANDOM  - random picks, nothing planted: the signal-day claims must not hold either
and the gate (a tree whose D1 net is off on 2% of picks stops the run, nothing written), outputs and their hashes,
the ledger and the rerun guard, and the refusals. Ends 'VERIFIED (whylab v1.0)' when every check passes; exit 1
otherwise.
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
for _v in ("CACHE_DAILY_ROOT", "BIGMOVE_DIR", "WHYLAB_OUT", "SETUPLAB_OUT"):
    os.environ.pop(_v, None)
import tl_data as TD  # noqa: E402
sys.path.insert(0, str(Path(TD.__file__).resolve().parent / "tests"))
import tl_world as W  # noqa: E402
import whylab as WY  # noqa: E402

SL = WY.libs()
RESULTS = []
IST = "Asia/Kolkata"


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(("  ok   " if ok else "  FAIL ") + name + ("" if ok else f"\n         {str(detail)[:900]}"), flush=True)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = fn(*a, **k)
    return rc, buf.getvalue()


def close(a, b, tol=1e-9):
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * (1 + np.abs(b)))))


# ---------------------------------------------------------------------------------------------------- by hand
def hand_measures(o, h, l, c, v, dates, cal):
    """An independent loop for every measure and outcome (the declaration's words, written out)."""
    n = len(c)
    M = {k: np.full(n, np.nan) for k in WY.MEASURES + WY.OUT_COLS}
    ag = al = None
    rsi = np.full(n, np.nan)
    for t in range(1, n):
        d = c[t] - c[t - 1]
        g_, l_ = max(d, 0.0), max(-d, 0.0)
        ag = g_ if ag is None else ag + (g_ - ag) / 7
        al = l_ if al is None else al + (l_ - al) / 7
        rsi[t] = 100 - 100 / (1 + ag / al) if al > 0 else (100.0 if ag > 0 else 50.0)
    calpos = {d: i for i, d in enumerate(cal)}
    for t in range(n):
        for k in (1, 5, 20, 60):
            if t >= k:
                M[f"ret{k}"][t] = c[t] / c[t - k] - 1
        if t >= WY.RSI_SKIP:
            M["rsi7"][t] = rsi[t]
        if t >= 19:
            lo, hi = min(l[t - 19:t + 1]), max(h[t - 19:t + 1])
            M["pos20"][t] = (c[t] - lo) / (hi - lo) if hi > lo else np.nan
            M["value20"][t] = float(np.median(c[t - 19:t + 1] * v[t - 19:t + 1]))
        if t >= 251:
            M["lo52"][t] = c[t] / min(l[t - 251:t + 1]) - 1
            M["hi52"][t] = c[t] / max(h[t - 251:t + 1]) - 1
        if t >= 14:
            tr = [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(t - 13, t + 1)]
            M["atrp"][t] = np.mean(tr) / c[t]
        if t >= 20:
            M["vol20"][t] = float(np.std([c[i] / c[i - 1] - 1 for i in range(t - 19, t + 1)], ddof=1))
            M["vratio"][t] = v[t] / np.mean(v[t - 20:t])
        M["price"][t] = c[t]
        for nn in (3, 10):
            if t >= nn:
                den = sum(abs(c[i] - c[i - 1]) for i in range(t - nn + 1, t + 1))
                M[f"sde{nn}"][t] = max(-1.0, min(1.0, (c[t] - c[t - nn]) / den)) if den > 1e-12 else np.nan
        # outcomes
        ci = calpos.get(dates[t])
        if t + 1 < n and ci is not None and ci + 1 < len(cal) and dates[t + 1] == cal[ci + 1]:
            o1 = o[t + 1]
            for k in range(1, 11):
                if t + k < n:
                    M[f"r{k}"][t] = (c[t + k] / o1 - 1) * 100
            if t + 6 < n:
                M["open6"][t] = (o[t + 6] / o1 - 1) * 100
            if t + 5 < n:
                M["dn8"][t] = float(min(l[t + 1:t + 6]) / o1 - 1 <= -0.08)
            if t >= 20 and t + 3 < n:
                va = np.mean(v[t - 20:t])
                M["vb"][t] = np.mean([np.log(v[t + k] / va) for k in (1, 2, 3)])
    return M


class DS:
    def __init__(self, dates, o, h, l, c, v):
        self.dates, self.o, self.h, self.l, self.c, self.v = dates, o, h, l, c, v


def t1_declaration():
    d, sha = WY.load_decl()
    kd, ksha = WY.load_k()
    rc, out = quiet(WY.main, ["check"])
    tmp = Path(tempfile.mkdtemp(prefix="whylab_decl_"))
    try:
        bad = tmp / "WHY_DECLARATION.json"
        bad.write_bytes(WY.DECL_FILE.read_bytes().replace(b"35", b"36", 1))
        try:
            WY.load_decl(bad)
            refused = False
        except WY.WHError:
            refused = True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    check("t1 the declarations are the pinned ones (claims 1-10, the gate; part K's rebuild, gate, groups and "
          "amendments); a changed copy is refused; 'check' runs", sha == WY.DECL_SHA and len(d["claims"]) == 10 and
          refused and rc == 0 and "OK" in out and "gate" in d and ksha == WY.K_SHA and len(kd["amendments"]) == 2
          and len(kd["families"]) == 10, (sha[:16], rc, out))


def t2_measures():
    rng = np.random.default_rng(3)
    cal = np.arange(np.datetime64("2021-01-01"), np.datetime64("2022-06-30")).astype("datetime64[D]")
    cal = cal[np.isin((cal.astype("datetime64[D]").view("int64") - 4) % 7, [0, 1, 2, 3, 4])]   # Mon-Fri
    n = len(cal)
    keep = np.ones(n, bool)
    keep[300] = False                                   # suspended one session: bar 299's D1 is not the next session
    dates = cal[keep]
    m = len(dates)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, m)))
    o = np.r_[100, c[:-1]] * np.exp(rng.normal(0, 0.005, m))
    h = np.fmax(o, c) * np.exp(np.abs(rng.normal(0, 0.01, m)))
    l = np.fmin(o, c) * np.exp(-np.abs(rng.normal(0, 0.01, m)))
    l[200] = o[200] * 0.85                              # a deep low inside D1..D5 of bars 195..199
    v = rng.lognormal(10, 0.5, m)
    F = WY.stock_arrays(SL, DS(dates, o, h, l, c, v), cal)
    H = hand_measures(o, h, l, c, v, list(dates), list(cal))
    bad = [k for k in WY.MEASURES + WY.OUT_COLS if not close(F[k], H[k], 1e-9)]
    sus = int(np.searchsorted(dates, cal[299]))
    check("t2 every measure and outcome = an independent loop (RSI 7, 20-day position, 52-week distances, simple ATR, "
          "volatility, volume ratio, rupees traded, SDE, D1..D10, D6 open, the -8% dip, D1-D3 volume); a session "
          "after a suspension has no outcome", not bad and np.isnan(F["r5"][sus]) and np.isfinite(F["r5"][sus - 1])
          and F["dn8"][196] == 1.0 and np.isnan(F["rsi7"][WY.RSI_SKIP - 1]) and np.isfinite(F["rsi7"][WY.RSI_SKIP]),
          {k: (np.nanmax(np.abs(F[k] - H[k])) if np.isfinite(F[k] - H[k]).any() else "all nan") for k in bad})


def t3_controls():
    d = np.datetime64("2023-05-02")
    syms = [f"A{i:02d}" for i in range(30)]
    rng = np.random.default_rng(4)
    T = pd.DataFrame({"day": pd.to_datetime([d] * 30), "symbol": syms, "etf": False,
                      "p_ret5": rng.uniform(0, 1, 30), "p_atrp": rng.uniform(0, 1, 30), "r5": rng.normal(0, 3, 30),
                      "vb": rng.normal(0, 1, 30), "picked": False})
    T.loc[[3, 7], "picked"] = True
    T.loc[11, "r5"] = np.nan                             # no outcome: never a control
    T.loc[12, ["p_ret5", "p_atrp"]] = [T.loc[3, "p_ret5"], T.loc[3, "p_atrp"]]   # a twin of pick 3 (distance 0)
    T.loc[13, ["p_ret5", "p_atrp"]] = [T.loc[3, "p_ret5"], T.loc[3, "p_atrp"]]   # and another: ties by symbol
    C = WY.controls(T, log=lambda *a: None).set_index("symbol")
    ok = True
    for q in (3, 7):
        cand = T[(~T.picked) & T.r5.notna()]
        dist = np.sqrt((cand.p_ret5 - T.p_ret5[q]) ** 2 + (cand.p_atrp - T.p_atrp[q]) ** 2)
        nn = cand.assign(dd=dist).sort_values(["dd", "symbol"]).head(10)
        r = C.loc[syms[q]]
        ok &= abs(r.c_r5 - nn.r5.mean()) < 1e-12 and abs(r.c_vb - nn.vb.mean()) < 1e-12 and r.c_n == 10 and \
            abs(r.c_dist - nn.dd.mean()) < 1e-12
    check("t3 look-alike controls = the 10 nearest unpicked stocks of the day in (5-day return, ATR %) percentile, "
          "with an outcome, ties by symbol (by hand)", ok and len(C) == 2, C)


def t3b_day_frame():
    d1, d2 = pd.Timestamp("2023-01-02"), pd.Timestamp("2024-02-05")
    rng = np.random.default_rng(9)
    rows = []
    for d in (d1, d2):
        for i in range(8):
            r = {"day": d, "symbol": ("NIFTYBEES" if i == 7 else f"C{i}")}
            for m in WY.MEASURES:
                r[m] = float(rng.normal())
            for k in WY.OUT_COLS:
                r[k] = float(rng.normal())
            rows.append(r)
    T = pd.DataFrame(rows)
    T.loc[2, "ret5"] = np.nan
    P = pd.DataFrame({"day": [d1], "symbol": ["C3"]})
    T2, Ud, info = WY.day_frame(SL, T, P, Path(tempfile.gettempdir()) / "no_such_cache")
    ok = info["etf_rows"] == 2 and T2["picked"].sum() == 1
    for d in (d1, d2):
        G = T2[(T2.day == d) & ~T2.etf]
        for m in ("ret5", "atrp"):
            v = G[m].to_numpy(float)
            fin = np.isfinite(v)
            want = pd.Series(v[fin]).rank(pct=True).to_numpy()
            ok &= np.allclose(G[f"p_{m}"].to_numpy(float)[fin], want, atol=1e-6) and \
                bool(np.isnan(G[f"p_{m}"].to_numpy(float)[~fin]).all())
        u5 = G["r5"].mean()
        ok &= abs(Ud.set_index("day").loc[d, "u_r5"] - u5) < 1e-12 and \
            np.allclose(G["x_r5"], G["r5"] - u5, atol=1e-12) and bool(T2[(T2.day == d) & T2.etf][f"p_ret5"].isna().all())
    check("t3b the day frame by hand: percentiles among the day's stocks (ETFs out, a blank value stays blank), the "
          "day's mean outcome over the universe, the excess, the pick flags", ok, info)


def t4_rules():
    d1, d2 = pd.Timestamp("2023-01-02"), pd.Timestamp("2024-03-04")
    rows = []
    for d, off in ((d1, 0.0), (d2, 1.0)):
        for i in range(12):
            rows.append({"day": d, "symbol": f"B{i:02d}", "etf": i == 0, "ret5": -0.01 * (12 - i), "atrp": 0.02,
                         "rsi7": 50 - i if i != 5 else 10.0, "net5": float(i) + off, "value20": 1e7 * (i + 1)})
    T = pd.DataFrame(rows)
    T.loc[(T.day == d1) & (T.symbol == "B02"), "ret5"] = -0.11            # ties B01 at -0.11: symbol order wins
    T.loc[(T.day == d2) & (T.symbol == "B03"), "net5"] = np.nan          # chosen by R1 but no outcome: left out
    Q = pd.DataFrame({"day": [d1, d1, d1, d2], "engine": ["D", "D", "ENS", "D"], "rank": [1, 2, 1, 1],
                      "symbol": ["B05", "B09", "B01", "B11"], "etf": False, "net5": [5.0, 9.0, 1.0, 12.0],
                      "value20": [6e7, 1e8, 2e7, 1.2e8]})
    R = WY.rules_daily(T, Q).set_index("day")
    r1 = R.loc[d1]
    ok = (abs(r1["R1"] - np.mean([1.0, 2.0, 3.0])) < 1e-12 and abs(r1["R2"] - np.mean([5.0, 11.0, 10.0])) < 1e-12 and
          abs(r1["D"] - 7.0) < 1e-12 and abs(r1["ENS"] - 1.0) < 1e-12 and abs(r1["all"] - np.mean(range(1, 12))) < 1e-12
          and abs(r1["D_in_R2_top10"] - 1.0) < 1e-12 and abs(r1["ENS_in_R1_top10"] - 1.0) < 1e-12 and
          abs(R.loc[d2, "R1"] - np.mean([2.0, 3.0])) < 1e-12 and np.isnan(R.loc[d2, "ENS"]))
    check("t4 the rules' top 3 a day by hand (R1 lowest 5-day fall in ATRs, R2 lowest RSI 7; ETFs out, ties by symbol, "
          "a chosen stock without an outcome left out), the model's ranks 1-3, everything, the top-10 overlap", ok, R.T)


def make_Q(kind, seed=5, n1=700, n2=300):
    """A made-up pick table: 3 picks a day per engine; each claim planted ('planted'), absent, reversed ('reverse')
    or with the type explaining the gain ('type')."""
    rng = np.random.default_rng(seed)
    days = pd.bdate_range("2020-01-01", periods=n1).append(pd.bdate_range("2024-01-01", periods=n2))
    rows = []
    for e in WY.ENGINES:
        for t, d in enumerate(days):
            for rk in (1, 2, 3):
                rows.append((e, rk, d))
    Q = pd.DataFrame(rows, columns=["engine", "rank", "day"])
    n = len(Q)
    Q["etf"] = False
    Q["lane"] = np.where(rng.random(n) < 0.5, "CALM", "JUMPY")
    Q["period"] = np.where(Q["day"] < pd.Timestamp("2024-01-01"), "P1", "P2")
    u = rng.uniform(0, 1, n)
    if kind in ("planted", "type", "reverse"):
        Q["p_ret5"] = 0.15 * u
        Q["p_atrp"] = 0.85 + 0.15 * rng.uniform(0, 1, n)
    else:
        Q["p_ret5"] = u
        Q["p_atrp"] = rng.uniform(0, 1, n)
    for nm in ("rsi7", "pos20", "ret20", "ret60"):
        Q[f"p_{nm}"] = rng.uniform(0, 1, n)
    eps = lambda s=1.0: rng.normal(0, s, n)                                    # noqa: E731
    Q["pos20"] = rng.uniform(0, 1, n)
    Q["rsi7"] = rng.uniform(10, 60, n)
    Q["sde3"] = rng.uniform(-1, 1, n)
    Q["u_r5"] = eps(0.5)
    if kind == "planted":
        Q["x_r2"] = 2 + eps()
        Q["x_r5"] = Q["x_r2"] - 20 * Q["p_ret5"] + 1.5 + eps(0.3)
        Q["x_r10"] = Q["x_r5"] - 1 + eps()
        Q["vb"], Q["c_vb"] = 1 + eps(0.5), 0.2 + eps(0.5)
        Q["dn8"] = (rng.random(n) < np.where(Q["pos20"] < 1 / 3, 0.6, 0.1)).astype(float)
    elif kind == "reverse":
        Q["x_r2"] = eps()
        Q["x_r5"] = Q["x_r2"] + 2 + 20 * Q["p_ret5"] + eps(0.3)
        Q["x_r10"] = Q["x_r5"] + 1 + eps()
        Q["vb"], Q["c_vb"] = -0.5 + eps(0.5), eps(0.5)
        Q["dn8"] = (rng.random(n) < np.where(Q["pos20"] < 1 / 3, 0.1, 0.6)).astype(float)
    else:
        Q["x_r2"] = eps()
        Q["x_r5"] = Q["x_r2"] + eps() + (1.5 if kind == "type" else 0.0)
        Q["x_r10"] = Q["x_r5"] + eps()
        Q["vb"], Q["c_vb"] = eps(0.5), eps(0.5)
        Q["dn8"] = (rng.random(n) < 0.2).astype(float)
    Q["x_open6"] = Q["x_r5"] + eps(0.5)
    Q["r5"] = Q["x_r5"] + Q["u_r5"]
    if kind == "planted":
        Q["c_r5"] = Q["r5"] - 1.5 + eps()
    elif kind == "reverse":
        Q["c_r5"] = Q["r5"] + 1.5 + eps()
    elif kind == "type":
        Q["c_r5"] = Q["r5"].copy()                    # the look-alikes do exactly as well
    else:
        Q["c_r5"] = Q["u_r5"] + eps(2.0)
    return Q


def t5_claim_logic():
    S = WY.Stat(SL, make_Q("absent")["day"].to_numpy())
    got = {}
    for kind in ("planted", "absent", "reverse", "type"):
        C = WY.claim_cells(S, make_Q(kind), "ALL", 3)
        got[kind] = {cid: WY.verdict(cid, c) for cid, c in C.items()}
    want = {"planted": {1: "TRUE", 2: "TRUE", 4: "MODEL ADDS", 5: "TRUE", 6: "TRUE", 7: "TRUE", 8: "TRUE", 9: "TRUE"},
            "absent": {1: "FALSE", 2: "FALSE", 5: "NOT RELIABLE", 6: "MIXED", 7: "NOT RELIABLE", 8: "NOT SHOWN",
                       9: "NOT RELIABLE"},
            "reverse": {4: "MODEL WORSE", 5: "MOMENTUM", 6: "BUILDS TO D5", 7: "KEEPS GOING", 8: "NOT SHOWN",
                        9: "NOT RELIABLE"},
            "type": {4: "TYPE EXPLAINS"}}
    bad = {k: {c: (got[k][c], v) for c, v in w.items() if got[k][c] != v} for k, w in want.items()}
    bad = {k: v for k, v in bad.items() if v}
    check("t5 every claim's rule on made-up pick tables: planted -> TRUE (and the model adds), absent -> not shown, "
          "reversed -> MOMENTUM / BUILDS TO D5 / KEEPS GOING / MODEL WORSE, look-alikes as good -> TYPE EXPLAINS",
          not bad and got["absent"][4] not in ("MODEL ADDS", "MODEL WORSE"), bad or got)
    # a MOST / MORE THAN CHANCE / NO ladder for claim 1 by hand
    Q = make_Q("absent")
    Q["p_ret5"] = np.where(np.random.default_rng(1).random(len(Q)) < 0.35, 0.1, 0.6)
    c = WY.claim_cells(S, Q, "ALL", 3)[1]
    m = WY.mask_of(Q, "D", "P1")
    share = 100 * np.mean(Q.loc[m, "p_ret5"] <= 0.2)
    check("t5b claim 1 by hand: 35% of picks in the bottom 20% -> MORE THAN CHANCE in each cell -> PARTLY; the share "
          "is the plain share", WY.verdict(1, c) == "PARTLY" and abs(c[("D", "P1")]["stat"] - share) < 1e-9 and
          c[("D", "P1")]["lo"] < share < c[("D", "P1")]["hi"], c[("D", "P1")])


def t6_claim3_logic():
    rng = np.random.default_rng(8)
    days = pd.bdate_range("2020-01-01", periods=700).append(pd.bdate_range("2024-01-01", periods=300))
    base = rng.normal(0, 2, len(days))
    R = pd.DataFrame({"day": days, "period": np.where(days < pd.Timestamp("2024-01-01"), "P1", "P2"), "all": base})
    for k in ("D", "ENS", "R1", "R2"):
        for c in ("_value20",):
            R[k + c] = 1e7
    for e in WY.ENGINES:
        for rk in WY.RULES:
            R[f"{e}_in_{rk}_top10"] = 0.5
    R["D"] = base + 1.0 + rng.normal(0, 1, len(days))
    R["ENS"] = base + 1.0 + rng.normal(0, 1, len(days))
    R["R1"] = base + 1.0 + rng.normal(0, 1, len(days))            # as good as the model
    R["R2"] = base + rng.normal(0, 1, len(days))                  # no edge: the model is better
    S = WY.Stat(SL, days.to_numpy())
    a = WY.claim3(S, R)
    R2 = R.copy()
    R2["R1"] = base + rng.normal(0, 1, len(days))
    R2["D"] = R2["ENS"] = base + rng.normal(0, 1, len(days))      # nothing has an edge
    b = WY.claim3(S, R2)
    check("t6 claim 3's rule: a rule as good as the model with an edge -> MATCHES THE MODEL; a rule without one -> "
          "MODEL BETTER; no edge anywhere -> MIXED (RULE HAS NO EDGE)", a["R1"]["verdict"] == "MATCHES THE MODEL" and
          a["R2"]["verdict"] == "MODEL BETTER" and b["R1"]["verdict"] == "MIXED" and
          all(v["cell"] == "RULE HAS NO EDGE" for k, v in b["R1"]["cells"].items() if k[1] != "ALL"),
          (a["R1"]["verdict"], a["R2"]["verdict"], b["R1"]["verdict"]))


# ---------------------------------------------------------------------------------------------------- worlds
def hand_atr(h, l, c):
    tr = np.full(len(c), np.nan)
    tr[1:] = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    return pd.Series(tr).rolling(14, min_periods=14).mean().to_numpy() / c


def make_world(root: Path, kind: str, seed: int, n_stocks: int = 90, bad_net: float = 0.0) -> dict:
    """Daily bars + NIFTY50 + panel_oc + a setuplab TREE run. kind: planted / fallen / random (module docstring)."""
    rng = np.random.default_rng(seed)
    cal = pd.bdate_range("2019-01-01", "2025-06-30")
    cal = cal[~((cal.month == 1) & (cal.day == 26))]
    n = len(cal)
    W.write_mods(root)
    W.use_mods(root)
    S = n_stocks
    sig = rng.uniform(0.012, 0.04, S)
    lr = rng.normal(0, 1, (S, n)) * sig[:, None]
    vm = rng.lognormal(0, 0.3, (S, n))
    ev = np.zeros((S, n), bool)
    atlow = np.zeros((S, n), bool)
    if kind == "planted":                     # one-day crashes, so the freshest falls lead each day's ranking
        add = np.zeros((S, n))
        for s in range(S):
            t = 30
            while t < n - 12:
                if rng.random() < 0.12:
                    dep = rng.uniform(1.0, 1.5)
                    add[s, t] += -10.0 * dep * sig[s]
                    add[s, t + 1:t + 3] += 6.5 * dep * sig[s]
                    add[s, t + 6:t + 11] += -0.6 * dep * sig[s]
                    vm[s, t + 1:t + 4] *= 3.0
                    ev[s, t] = True
                    atlow[s, t] = rng.random() < 0.5
                    t += 11
                else:
                    t += 1
        lr += add                              # each event nets to zero: -10 + 2 x 6.5 - 5 x 0.6 (no drift added)
    C = 100 * np.exp(np.cumsum(lr, axis=1))
    O = np.concatenate([np.full((S, 1), 100.0), C[:, :-1]], axis=1) * np.exp(rng.normal(0, 0.2, (S, n)) * sig[:, None])
    Hh = np.fmax(O, C) * np.exp(np.abs(rng.normal(0, 0.5, (S, n))) * sig[:, None])
    Ll = np.fmin(O, C) * np.exp(-np.abs(rng.normal(0, 0.5, (S, n))) * sig[:, None])
    for s, t in zip(*np.nonzero(ev)):
        if atlow[s, t]:                        # closes at its low, then dips 10% under the D1 open
            O[s, t] = max(O[s, t], C[s, t] * 1.01)
            Hh[s, t] = max(Hh[s, t], O[s, t])
            Ll[s, t] = C[s, t]
            Ll[s, t + 1] = min(Ll[s, t + 1], O[s, t + 1] * 0.90)
        else:                                  # closes well off its low
            Ll[s, t] = min(Ll[s, t], C[s, t] * np.exp(-1.5 * sig[s]))
    V = rng.lognormal(12, 0.6, S)[:, None] * vm
    syms = [f"S{i:03d}" for i in range(S)]
    daily = {}
    gone = {"S005": 400, "S017": 900}                     # suspended sessions (no bar)
    for i, s in enumerate(syms):
        df = pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": O[i], "high": Hh[i], "low": Ll[i], "close": C[i],
                           "volume": V[i]})
        if s in gone:
            df = df.drop(index=gone[s]).reset_index(drop=True)
        daily[s] = df
        df.to_parquet(root / f"{s}_daily.parquet", index=False)
    for e_, sg in (("NIFTYBEES", 0.006), ("GOLDBEES", 0.005)):
        c = 100 * np.exp(np.cumsum(rng.normal(0, sg, n)))
        o = np.r_[100, c[:-1]]
        daily[e_] = pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": o, "high": np.fmax(o, c) * 1.002,
                                  "low": np.fmin(o, c) * 0.998, "close": c, "volume": 1e6})
        daily[e_].to_parquet(root / f"{e_}_daily.parquet", index=False)
    c = 18000 * np.exp(np.cumsum(rng.normal(0, 0.009, n)))
    pd.DataFrame({"timestamp": cal.tz_localize(IST), "open": c, "high": c * 1.004, "low": c * 0.996, "close": c,
                  "volume": 1e6}).to_parquet(root / "NIFTY50_daily.parquet", index=False)
    allsyms = syms + ["NIFTYBEES", "GOLDBEES"]
    (root / "panel_oc").mkdir(exist_ok=True)
    pd.DataFrame({"timestamp": np.tile(cal.tz_localize(IST), len(allsyms)), "symbol": np.repeat(allsyms, n),
                  "D_rsi14": 50.0}).to_parquet(root / "panel_oc" / "panel.parquet", index=False)
    # the engines' picks (independent hand formulas: 5-day return over the simple ATR)
    calD = cal.values.astype("datetime64[D]")
    pos = {s: {d: i for i, d in enumerate(daily[s]["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).values
                                         .astype("datetime64[D]"))} for s in allsyms}
    arr = {s: {k: daily[s][k].to_numpy(float) for k in ("open", "high", "low", "close")} for s in allsyms}
    for s in allsyms:
        a = arr[s]
        a["atr"] = hand_atr(a["high"], a["low"], a["close"])
        r5 = np.full(len(a["close"]), np.nan)
        r5[5:] = a["close"][5:] / a["close"][:-5] - 1
        a["sc"] = r5 / a["atr"]
    t_first = int(np.searchsorted(cal, pd.Timestamp("2020-01-16")))
    sidx = {s: i for i, s in enumerate(syms)}
    rows = []
    for t in range(t_first, n - 11):
        d = calD[t]
        cands = []
        for s in syms:
            i = pos[s].get(d)
            if i is not None and np.isfinite(arr[s]["sc"][i]):
                cands.append((s, i, arr[s]["sc"][i]))
        if kind == "random":
            noise_d, noise_e = rng.normal(0, 1, len(cands)), rng.normal(0, 1, len(cands))
            sd = noise_d
            se = noise_e
        else:                                  # the biggest 5-day falls in ATRs (R1) with a little noise
            sc = np.array([x[2] for x in cands])
            sd = -sc + 0.05 * rng.normal(0, 1, len(cands))
            se = -sc + 0.2 * rng.normal(0, 1, len(cands))
        for e_, sv in (("D", sd), ("ENS", se)):
            order = np.argsort(-sv, kind="stable")[:10]
            lst = [cands[j][0] for j in order]
            if e_ == "D" and rng.random() < 0.03:
                lst = lst[:2] + ["NIFTYBEES"] + lst[2:9]
            for rk, s in enumerate(lst, 1):
                i = pos[s].get(d)
                a = arr[s]
                ok = (i is not None and i + 5 < len(a["close"]) and
                      calD[t + 1] == daily[s]["timestamp"].iloc[i + 1].tz_convert(IST).tz_localize(None).to_datetime64()
                      .astype("datetime64[D]"))
                net = (a["close"][i + 5] / a["open"][i + 1] - 1) * 100 - 0.35 if ok else np.nan
                rows.append({"trade_id": f"{e_}-{pd.Timestamp(d):%Y%m%d}-{rk}", "engine": e_, "rank": rk, "symbol": s,
                             "signal_day": f"{pd.Timestamp(d):%Y-%m-%d}", "s_atr14": a["atr"][i] if i is not None
                             else np.nan, "etf": s.endswith("BEES"), "d1_net": net, "complete": bool(ok),
                             "year": pd.Timestamp(d).year})
    Tg = pd.DataFrame(rows)
    lane = np.full(len(Tg), "NO CUT-OFF", dtype=object)
    for y in sorted(Tg["year"].unique()):
        prior = Tg[(Tg["year"] < y) & Tg["complete"]]["s_atr14"].dropna()
        if len(prior) >= 100:
            cut = float(np.quantile(prior, 2 / 3))
            m = (Tg["year"] == y).to_numpy()
            a_ = Tg["s_atr14"].to_numpy(float)
            lane[m] = np.where(np.isfinite(a_[m]), np.where(a_[m] > cut, "JUMPY", "CALM"), "NO ATR")
    Tg["lane"] = lane
    noatr = rng.random(len(Tg)) < 0.02                      # a pick without a recorded ATR: the tree's NO ATR lane
    Tg.loc[noatr & (Tg["lane"] != "NO CUT-OFF").to_numpy(), "lane"] = "NO ATR"
    if bad_net:
        k = rng.choice(len(Tg), int(bad_net * len(Tg)), replace=False)
        Tg.loc[Tg.index[k], "d1_net"] += 0.5
    for c_, v_ in (("cutoff", np.nan), ("gap_pct", 0.0), ("opened_up", True), ("dip_2pct", False),
                   ("runner", False), ("first_setup", ""), ("setup_net", np.nan), ("bunch", ""), ("action", ""),
                   ("how", ""), ("in_book_start1", False)):
        Tg[c_] = v_
    Tg = Tg.drop(columns="year")
    sbase = root.parent / (root.name + "_setuplab")
    tr = SL.new_run_dir(sbase / "TREE", "TREE")
    Tg.to_parquet(tr / "tree_tags.parquet", index=False)
    (tr / "TREE_RUN.json").write_text(json.dumps({"version": "setuplab v1.1"}), encoding="utf-8")
    SL.write_hashes(tr, ["tree_tags.parquet", "TREE_RUN.json"])
    return {"root": root, "sbase": sbase, "tree": Tg, "ev": ev, "cal": cal, "syms": syms}


def run(w, out, extra=()):
    rc, log = quiet(WY.main, ["run", "--root", str(w["root"]), "--setups", str(w["sbase"]), "--out", str(out),
                              "--stage-e-any"] + list(extra))
    runs = sorted((Path(out) / "runs").glob("WHY_*")) if (Path(out) / "runs").exists() else []
    return rc, log, (runs[-1] if runs else None)


def t7_planted():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_planted_"))
    try:
        w = make_world(tmp / "cache", "planted", seed=11)
        rc, log, rd = run(w, tmp / "out")
        meta = json.loads((rd / "run.json").read_text()) if rd else {}
        V = meta.get("verdicts", {}).get("ALL", {})
        info = meta.get("info", {})
        check("t7 PLANTED world runs end to end; the gate passes (net here = the tree's D1 net on every complete pick); "
              "suspensions counted", rc == 0 and info.get("gate", {}).get("passed") and
              info["gate"]["share"] == 1.0 and info["bars"]["no_bar_that_day_rows"] > 0, log[-1500:])
        want = {"1": "TRUE", "5": "TRUE", "6": "TRUE", "7": "TRUE", "8": "TRUE", "9": "TRUE"}
        bad = {k: (V.get(k), v) for k, v in want.items() if V.get(k) != v}
        check("t7b PLANTED: picks after a hard fall TRUE; rebound TRUE; fast TRUE; fades TRUE; volume burst TRUE; the "
              "20-day-low warning TRUE", not bad, (bad, V))
        check("t7c PLANTED: the rule the engines use (R1, biggest fall in ATRs) MATCHES THE MODEL",
              meta.get("rules", {}).get("R1") == "MATCHES THE MODEL", meta.get("rules"))
        names = ["REPORT.md", "claims.csv", "profile.csv", "path.csv", "rules.csv", "examples.csv", "picks.parquet",
                 "run.json", "DECLARATION.json", "outputs.sha256"]
        hashes = {ln.split("  ")[1]: ln.split("  ")[0] for ln in (rd / "outputs.sha256").read_text().splitlines()}
        hok = all(WY.sha256(rd / k) == v for k, v in hashes.items()) and len(hashes) == 9
        Ex = pd.read_csv(rd / "examples.csv")
        rep = (rd / "REPORT.md").read_text(encoding="utf-8")
        check("t7d outputs: every file, hashes match, 12 examples (3 per engine x lane), the report opens with the "
              "verdicts and names claim 10 NOT TESTED", all((rd / k).is_file() for k in names) and hok and
              len(Ex) == 12 and sorted(Ex.groupby("group").size().tolist()) == [3, 3, 3, 3] and
              rep.index("## Verdicts") < rep.index("## 1.") and "NOT TESTED" in rep, (hok, len(Ex)))
        # every pick of the tree is there, measured from its own bars (two by hand)
        Q = pd.read_parquet(rd / "picks.parquet")
        Tg = w["tree"]
        q = Q[(Q.engine == "D") & (Q["rank"] == 1)].iloc[[100, 500]]
        ok = True
        for _, r in q.iterrows():
            df = pd.read_parquet(w["root"] / f"{r.symbol}_daily.parquet")
            dd = df["timestamp"].dt.tz_convert(IST).dt.tz_localize(None).dt.normalize()
            i = int(np.flatnonzero(dd == pd.Timestamp(r.day))[0])
            c = df["close"].to_numpy()
            ok &= abs(r.ret5 - (c[i] / c[i - 5] - 1)) < 1e-6 and abs(r.r5 - (c[i + 5] / df["open"].iat[i + 1] - 1) *
                                                                     100) < 1e-9
        check("t7e every tree pick is in picks.parquet with its stock-day's numbers (two by hand)",
              len(Q) == len(Tg) and ok, (len(Q), len(Tg)))
        # the cells' populations by hand: periods split at 2024-01-01, lanes CALM / JUMPY (+ NO ATR), ranks 1-3
        Cl = pd.read_csv(rd / "claims.csv")
        Cl["claim"] = Cl["claim"].astype(str)
        okc = True
        for (lane, lanes) in (("ALL", None), ("CALM", ["CALM"]), ("JUMPY", ["JUMPY", "NO ATR"])):
            for e in ("D", "ENS"):
                for per, lo, hi in (("2020-23", "1900-01-01", "2023-12-31"), ("2024-26", "2024-01-01", "2100-01-01")):
                    m = (Q.engine == e) & ~Q.etf & (Q["rank"] <= 3) & (Q.day >= lo) & (Q.day <= hi) & \
                        Q.p_ret5.notna()
                    if lanes:
                        m &= Q.lane.isin(lanes)
                    row = Cl[(Cl.claim == "1") & (Cl.lane == lane) & (Cl.ranks == "1-3") & (Cl.engine == e) &
                             (Cl.period == per)]
                    okc &= len(row) == 1 and int(row.n.iloc[0]) == int(m.sum()) and \
                        abs(row.stat.iloc[0] - 100 * (Q.loc[m, "p_ret5"] <= 0.2).mean()) < 1e-6
        # the 12 examples are the declared draw
        need = list(WY.MEASURES) + [f"r{k}" for k in range(1, 11)] + ["dn8", "vb"]
        okx = (~Q.etf) & (Q["rank"] <= 3) & Q[need].notna().all(axis=1)
        rng = np.random.default_rng(7)
        want = []
        for e in ("D", "ENS"):
            for lanes in (["CALM"], ["JUMPY", "NO ATR"]):
                G = Q[okx & (Q.engine == e) & Q.lane.isin(lanes)].sort_values("trade_id")
                want += G["trade_id"].iloc[np.sort(rng.choice(len(G), 3, replace=False))].tolist()
        check("t7g each cell's picks by hand (periods split at 2024-01-01, calm / jumpy lanes, ranks 1-3, ETFs out) "
              "and the 12 examples = the declared random draw (seed 7)", okc and Ex["trade_id"].tolist() == want,
              (okc, Ex["trade_id"].tolist()[:4], want[:4]))
        # rerun guard
        rc2, log2, _ = run(w, tmp / "out")
        rc3, log3, rd3 = run(w, tmp / "out", ["--rerun-reason", "test"])
        led = [json.loads(x) for x in (tmp / "out" / WY.LEDGER).read_text().splitlines()]
        check("t7f a second run is refused without --rerun-reason; with one it runs and the ledger records both",
              rc2 == 2 and "rerun-reason" in log2 and rc3 == 0 and len(led) == 2 and led[1]["rerun_reason"] == "test",
              (rc2, rc3, len(led)))
        return w
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t8_fallen_random():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_absent_"))
    try:
        w = make_world(tmp / "cache", "fallen", seed=12)
        rc, log, rd = run(w, tmp / "out")
        meta = json.loads((rd / "run.json").read_text()) if rd else {}
        V = meta.get("verdicts", {}).get("ALL", {})
        bad = {k: V.get(k) for k in ("5", "6", "7", "8", "9") if V.get(k) == "TRUE"}
        check("t8 FALLEN world (picks by fall, nothing after): picks after a hard fall TRUE, but none of the after-the-"
              "pick claims is TRUE; R1 does not 'match' (no edge)", rc == 0 and V.get("1") == "TRUE" and not bad and
              meta.get("rules", {}).get("R1") != "MATCHES THE MODEL", (V, meta.get("rules"), log[-800:]))
        w2 = make_world(tmp / "cache2", "random", seed=13)
        rc, log, rd = run(w2, tmp / "out2")
        meta = json.loads((rd / "run.json").read_text()) if rd else {}
        V = meta.get("verdicts", {}).get("ALL", {})
        bad = {k: V.get(k) for k in V if V.get(k) in ("TRUE", "PARTLY", "MODEL ADDS")}
        check("t8b RANDOM world: no claim TRUE or PARTLY, the model adds nothing", rc == 0 and not bad and
              V.get("1") == "FALSE" and V.get("2") == "FALSE", (V, log[-800:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t9_gate_and_guards():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_gate_"))
    try:
        w = make_world(tmp / "cache", "random", seed=14, n_stocks=40, bad_net=0.02)
        rc, log, rd = run(w, tmp / "out")
        check("t9 the gate: a tree whose D1 net is off on 2% of picks STOPS the run (exit 3) before any claim; no run "
              "folder, no ledger line", rc == 3 and "STOPPED" in log and rd is None and
              not (tmp / "out" / WY.LEDGER).exists(), (rc, log[-600:]))
        rc, log = quiet(WY.main, ["run", "--root", str(w["root"]), "--setups", str(w["sbase"]),
                                  "--out", str(w["root"] / "x"), "--stage-e-any"])
        rc2, log2 = quiet(WY.main, ["run", "--setups", str(w["sbase"]), "--out", str(tmp / "o2")])
        rc3, log3 = quiet(WY.main, ["run", "--root", str(w["root"]), "--setups", str(tmp / "nothing"),
                                    "--out", str(tmp / "o3")])
        check("t9b refused: an output folder inside the cache, no --root (no default cache path), no setuplab output",
              rc == 2 and "never writes there" in log and rc2 == 2 and "--root" in log2 and rc3 == 2, (log, log2, log3))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------------------------------------------- part K
SB_STANDIN = """
\"\"\"TEST STAND-IN for stage_b_screen (ELIG_COL, _read_col, _naive) - NOT the production file.\"\"\"
import numpy as np
import pandas as pd
ELIG_COL = "label_buyable_o1"
FAMILY_ID = "oc_test"


def _naive(s):
    t = pd.to_datetime(pd.Series(s))
    if getattr(t.dt, "tz", None) is not None:
        t = t.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return t


def _read_col(pp, col):
    return pd.read_parquet(pp, columns=[col])[col].to_numpy(dtype=float)
"""

SD_STANDIN = """
\"\"\"TEST STAND-IN for stage_d_gate (CFG, make_label, eligible_mask, horizon_of) - NOT the production file.\"\"\"
import re
import numpy as np
CODE_VERSION = "stage_d_gate TEST STAND-IN"
CFG = {"model": "HistGradientBoostingRegressor",
       "hgb": {"loss": "squared_error", "max_iter": 40, "learning_rate": 0.1, "max_leaf_nodes": 15,
               "min_samples_leaf": 40, "l2_regularization": 1.0, "early_stopping": False},
       "label": "demeaned_by_day_winsorized", "winsor_pct": [1, 99], "fit_cap": 9000, "n_splits": 3,
       "min_train_frac": 0.35, "embargo": 5, "top_n_primary": 3, "top_n_all": [1, 3, 5, 10], "cost_bps": 35.0,
       "interval_level": 0.9875, "boot_B": 10000, "boot_block": 10, "recency_start": "2024-01-01", "seed": 7}


def horizon_of(target):
    return int(re.fullmatch(r"label_oc_(\\d+)", target).group(1))


def eligible_mask(buyable):
    return buyable == 1


def make_label(y, day, pct=(1, 99)):
    y = np.asarray(y, dtype=float)
    u, inv = np.unique(day, return_inverse=True)
    s = np.bincount(inv, y, minlength=len(u))
    c = np.bincount(inv, minlength=len(u))
    dm = y - (s / c)[inv]
    lo, hi = np.percentile(dm, pct)
    return np.clip(dm, lo, hi), float(lo), float(hi)
"""

K_FEATS = ["D_rsi7", "D_atr_pct", "D_breakout_high_20", "MKT_D_rsi14", "DOW_1", "Comb_ATRhigh__EMA20neg",
           "D_amihud_20", "D_drawdown_252", "D_adx14", "D_inside_day", "X_universe_size", "NIFTYBANK_ret_1d"]


def use_prod(d: Path):
    for m in ("stage_d_gate", "stage_b_screen"):
        sys.modules.pop(m, None)
    if str(d) in sys.path:
        sys.path.remove(str(d))
    sys.path.insert(0, str(d))


def oracle_preds(pp: Path, feats, folds, SD, SB):
    """stage_d_gate.run_gate's fold loop for label_oc_5, written out independently: the frozen preds."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    base = pd.read_parquet(pp, columns=["timestamp", "symbol", "label_buyable_o1"])
    ts = SB._naive(base["timestamp"]).to_numpy(dtype="datetime64[ns]")
    sym = base["symbol"].astype(str).to_numpy()
    el = base["label_buyable_o1"].to_numpy(float) == 1
    order = np.lexsort((sym, ts))
    sel = order[el[order]]
    ts_s, sym_s = ts[sel], sym[sel]
    sessions = np.unique(ts_s)
    day = np.searchsorted(sessions, ts_s)
    y = pd.read_parquet(pp, columns=["label_oc_5"])["label_oc_5"].to_numpy(float)[sel]
    X = np.column_stack([pd.read_parquet(pp, columns=[f])[f].to_numpy(float)[sel] for f in feats]).astype(np.float32)
    score = np.full(len(sel), np.nan)
    pos = {np.datetime64(s_, "ns"): i for i, s_ in enumerate(sessions)}
    for f in folds:
        tr_end = pos[np.datetime64(pd.Timestamp(f["train_end"]), "ns")]
        te0, te1 = (pos[np.datetime64(pd.Timestamp(f[k]), "ns")] for k in ("test_start", "test_end"))
        tr = np.flatnonzero((day <= tr_end) & np.isfinite(y))
        lab, _, _ = SD.make_label(y[tr], day[tr], (1, 99))
        rng = np.random.default_rng([7, int(f["fold"]), 5])
        keep = np.sort(rng.choice(len(tr), SD.CFG["fit_cap"], replace=False)) if len(tr) > SD.CFG["fit_cap"] \
            else np.arange(len(tr))
        m = HistGradientBoostingRegressor(random_state=7, **SD.CFG["hgb"]).fit(X[tr[keep]], lab[keep])
        te = np.flatnonzero((day >= te0) & (day <= te1))
        score[te] = m.predict(X[te])
    ok = np.isfinite(score)
    return pd.DataFrame({"timestamp": sessions[day[ok]], "symbol": sym_s[ok], "target": "label_oc_5",
                         "score": score[ok].astype("float32"), "outcome": y[ok].astype("float32")})


def make_k_world(tmp: Path, planted: bool = True, seed: int = 31, n_stocks: int = 50):
    rng = np.random.default_rng(seed)
    root = tmp / "cache"
    prod = tmp / "_prod"
    prod.mkdir(parents=True, exist_ok=True)
    (prod / "stage_b_screen.py").write_text(SB_STANDIN, encoding="utf-8")
    (prod / "stage_d_gate.py").write_text(SD_STANDIN, encoding="utf-8")
    use_prod(prod)
    import stage_b_screen as SB_
    import stage_d_gate as SD_
    cal = pd.bdate_range("2021-01-04", periods=600)
    n = len(cal)
    syms = [f"K{i:02d}" for i in range(n_stocks)] + ["NIFTYBEES"]
    S = len(syms)
    rows = {"timestamp": np.repeat(cal.tz_localize(IST).to_numpy(), S), "symbol": np.tile(syms, n)}
    N = n * S
    sig = rng.normal(size=N)
    rows["D_rsi7"] = sig
    for f in ("D_atr_pct", "D_breakout_high_20", "D_amihud_20", "D_drawdown_252", "D_adx14", "D_inside_day"):
        rows[f] = rng.normal(size=N)
    rows["Comb_ATRhigh__EMA20neg"] = (rng.random(N) < 0.3).astype(float)
    per_day = lambda v: np.repeat(v, S)                                          # noqa: E731
    rows["MKT_D_rsi14"] = per_day(rng.normal(size=n))
    rows["DOW_1"] = per_day((cal.dayofweek == 1).astype(float))
    rows["X_universe_size"] = per_day(rng.integers(40, 51, n).astype(float))
    rows["NIFTYBANK_ret_1d"] = per_day(rng.normal(0, 0.01, n))
    y = (0.006 * sig if planted else 0.0) + rng.normal(0, 0.02, N)
    y[np.repeat(np.arange(n) >= n - 5, S)] = np.nan
    rows["label_oc_5"] = y
    rows["label_buyable_o1"] = (rng.random(N) > 0.03).astype(float)
    P = pd.DataFrame(rows)
    (root / "panel_oc").mkdir(parents=True, exist_ok=True)
    pp = root / "panel_oc" / "panel.parquet"
    P.to_parquet(pp, index=False)
    sess = pd.DatetimeIndex(cal)
    folds = []
    for fo, (tr_end, t0_, t1_) in enumerate(((200, 207, 333), (326, 334, 466), (459, 467, 590)), 1):
        folds.append({"target": "label_oc_5", "fold": fo, "train_end": str(sess[tr_end].date()),
                      "test_start": str(sess[t0_].date()), "test_end": str(sess[t1_].date())})
    rd = root / "panel_oc" / "stage_d" / "STAGED_TEST_001"
    rd.mkdir(parents=True, exist_ok=True)
    (rd / "stage_d.json").write_text(json.dumps({"features": K_FEATS, "folds": folds, "config": SD_.CFG}),
                                     encoding="utf-8")
    pr = oracle_preds(pp, K_FEATS, folds, SD_, SB_)
    other = pr.assign(target="label_oc_1", score=rng.normal(size=len(pr)).astype("float32"))
    pd.concat([pr, other], ignore_index=True).to_parquet(rd / "preds.parquet", index=False)
    write_frozen(root, prod)
    return {"root": root, "prod": prod, "rd": rd, "pp": pp, "folds": folds, "preds": pr}


def write_frozen(root: Path, prod: Path):
    rd = root / "panel_oc" / "stage_d" / "STAGED_TEST_001"
    (root / "panel_oc" / "frozen").mkdir(parents=True, exist_ok=True)
    (root / "panel_oc" / "frozen" / "FROZEN_ENGINES.json").write_text(json.dumps({
        "target": "label_oc_5", "engines": {"D": {"run": "STAGED_TEST_001"}},
        "files": {"code/stage_d_gate.py": WY.sha256(prod / "stage_d_gate.py"),
                  "runs/D/STAGED_TEST_001/stage_d.json": WY.sha256(rd / "stage_d.json"),
                  "runs/D/STAGED_TEST_001/preds.parquet": WY.sha256(rd / "preds.parquet")}}), encoding="utf-8")


def run_k(w, out, extra=()):
    use_prod(w["prod"])
    rc, log = quiet(WY.main, ["model", "--root", str(w["root"]), "--out", str(out)] + list(extra))
    runs = sorted((Path(out) / "model").glob("K_*")) if (Path(out) / "model").exists() else []
    return rc, log, (runs[-1] if runs else None)


def tk1_families_and_scramble():
    kd, ksha = WY.load_k()
    names = ["D_drawdown_252", "X_z_D_downside_dev_60", "D_monthly_trend", "DOW_3", "D_dow", "Comb_ATRlow__EMA20pos",
             "D_vol_surge_20", "W_vol_vs_4w", "W_close_pos", "X_universe_size", "NIFTYBANK_ret_1d", "MKT_D_rsi14",
             "D_breakout_low_50", "D_macd_hist", "D_obv", "D_obv_slope", "D_rsi7", "D_WQ_29", "D_atr_pct",
             "D_inside_day"]
    want = ["position in range (52-week, 20-day, bands)", "volatility and jumpiness", "trend", "calendar", "calendar",
            "combined flags", "volume and liquidity", "volume and liquidity", "position in range (52-week, 20-day, bands)",
            "market and outside series", "market and outside series", "market and outside series", "raw price levels",
            "raw price levels", "raw price levels", "volume and liquidity", "returns, reversal and oscillators",
            "returns, reversal and oscillators", "volatility and jumpiness", "other"]
    got = {}
    for nm, cols in WY.k_families(names, kd):
        for c in cols:
            got[names[c]] = nm
    bad = [(x, got.get(x), w_) for x, w_ in zip(names, want) if got.get(x) != w_]
    # the scramble: varying columns keep each day's values (shuffled together), day-constant ones take another day's
    rng = np.random.default_rng(4)
    dt_ = np.repeat(np.arange(6), 5)
    Xt = np.column_stack([rng.normal(size=30), rng.normal(size=30), np.repeat(rng.normal(size=6), 5)]).astype(np.float32)
    dc = WY.k_dayconst(Xt, [{"te": np.arange(30)}], dt_)
    Xp = WY.k_scramble(Xt, dt_, [0, 1, 2], dc, np.random.default_rng(9))
    same_days = all(sorted(Xp[dt_ == d, 0]) == sorted(Xt[dt_ == d, 0]) for d in range(6))
    together = all(any((Xp[i, 0] == Xt[j, 0]) and (Xp[i, 1] == Xt[j, 1]) for j in np.flatnonzero(dt_ == dt_[i]))
                   for i in range(30))
    const = all(len(set(Xp[dt_ == d, 2])) == 1 for d in range(6)) and sorted(set(Xp[:, 2])) == sorted(set(Xt[:, 2]))
    moved = (Xp[:, 0] != Xt[:, 0]).any() and (Xp[:, 2] != Xt[:, 2]).any()
    check("tk1 part K's groups by hand (the amended patterns: drawdown / downside / monthly trend / day dummies / "
          "Comb_ flags / volume surge / weekly close position / the market's series); the scramble keeps a day's "
          "stock-varying values (shuffled together) and gives day-constant columns another day's value",
          not bad and list(dc) == [False, False, True] and same_days and together and const and moved and
          WY.K_REPEATS == (7, 8, 9) and WY.K_TARGET == "label_oc_5",
          (bad, list(dc), same_days, together, const))


def tk2_planted():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_k_"))
    try:
        w = make_k_world(tmp, planted=True)
        rc, log, rd = run_k(w, tmp / "out")
        F = pd.read_csv(rd / "families.csv") if rd and (rd / "families.csv").is_file() and \
            (rd / "families.csv").stat().st_size > 2 else pd.DataFrame()
        g = pd.read_csv(rd / "gate.csv").iloc[0] if rd else None
        check("tk2 part K rebuilds stage D's folds from its own recipe and reproduces the frozen scores exactly (same "
              "top 3 on every day, rank correlation 1); the other target's rows are ignored",
              rc == 0 and g is not None and g["passed"] and g["same_top3_share"] == 1.0 and g["max_abs_diff"] < 1e-6
              and g["only_rebuilt"] == 0 and g["only_frozen"] == 0, (rc, log[-1500:]))
        top = F.iloc[0] if len(F) else None
        others = F[F["family"] != "returns, reversal and oscillators"] if len(F) else F
        check("tk2b PLANTED (the outcome follows D_rsi7 only): D RELIES ON 'returns, reversal and oscillators', it "
              "costs the most money and moves the most picks; the raw price levels get their own line",
              top is not None and top["family"] == "returns, reversal and oscillators" and top["verdict"] == "RELIES ON"
              and top["picks_changed_pct"] > 2 * others["picks_changed_pct"].max() and
              all(v == ("RELIES ON" if h_ < 0 else "NO CLEAR RELIANCE") for v, h_ in zip(F["verdict"], F["hi_ALL"])) and
              list(F["lost_ALL"]) == sorted(F["lost_ALL"]) and
              "Raw price levels" in (rd / "KREPORT.md").read_text(encoding="utf-8"), F.to_string())
        # one knock-out by hand: the declared scheme recomputed outside whylab on whylab's own fitted models
        use_prod(w["prod"])
        import stage_b_screen as SB_
        import stage_d_gate as SD_
        kd, _ = WY.load_k()
        inp = WY.k_inputs(w["root"], SD_)
        ts_s, sym_s, sessions, day, y, X = WY.k_load(SD_, SB_, inp["pp"], inp["feats"], log=lambda *a: None)
        fits, score = WY.k_fit(SD_, X, y, day, sessions, inp["folds"], log=lambda *a: None)
        fams = WY.k_families(inp["feats"], kd)
        etf = np.array([s_.endswith("BEES") for s_ in sym_s])
        dc = WY.k_dayconst(X, fits, day)
        days, base, R = WY.k_knockout(fits, X, day, sym_s, y, etf, fams, dc, log=lambda *a: None)
        k = [nm for nm, _ in fams].index("market and outside series")
        cols = fams[k][1]
        f = fits[0]
        te = f["te"]
        Xt, dt_, st_ = X[te], day[te], sym_s[te]
        net = (y[te] - 0.0035) * 100
        nd = len(np.unique(dt_))

        def top3(sc):
            out = np.zeros(len(sc), bool)
            for d in np.unique(dt_):
                ii = np.flatnonzero((dt_ == d) & ~etf[te])
                o = sorted(ii, key=lambda i: (-sc[i], st_[i]))[:3]
                out[o] = True
            return out
        c0 = top3(f["model"].predict(Xt))
        hand_base = np.array([np.nanmean(net[c0 & (dt_ == d)]) for d in np.unique(dt_)])
        chg, dif = np.zeros(nd), np.zeros(nd)
        for r in WY.K_REPEATS:
            g_ = np.random.default_rng([r, int(f["fold"]), k])
            Xp = Xt.copy()
            vc = [c for c in cols if not dc[c]]
            cc = [c for c in cols if dc[c]]
            if vc:                                       # stock-varying columns first (none in this group)
                order = np.lexsort((g_.random(len(dt_)), dt_))
                Xp[:, vc] = Xt[np.ix_(order, vc)]
            first = np.r_[0, np.flatnonzero(np.diff(dt_)) + 1]
            perm = g_.permutation(len(first))
            src = np.empty(len(dt_), int)
            for q, d0 in enumerate(first):
                d1 = first[q + 1] if q + 1 < len(first) else len(dt_)
                src[d0:d1] = first[perm[q]]
            Xp[:, cc] = Xt[np.ix_(src, cc)]
            c1 = top3(f["model"].predict(Xp))
            for q, d in enumerate(np.unique(dt_)):
                m0, m1 = c0 & (dt_ == d), c1 & (dt_ == d)
                chg[q] += 1 - (m0 & m1).sum() / m0.sum()
                dif[q] += np.nanmean(net[m1]) - np.nanmean(net[m0])
        hand_chg, hand_dif = chg / 3, dif / 3
        wc, wd = R["market and outside series"]
        check("tk2c one knock-out by hand (the market group on fold 1: day-constant columns given another day's "
              "values, 3 repeats, ETFs out, ties by symbol): the same picks replaced and the same money, day by day; "
              "the top 3's own net (after 0.35 points of costs)",
              len(cc) == 3 and not vc and np.allclose(wc[:nd], hand_chg, atol=1e-12) and
              np.allclose(wd[:nd], hand_dif, atol=1e-9) and np.allclose(base[:nd], hand_base, atol=1e-9),
              (np.abs(wd[:nd] - hand_dif).max(), np.abs(base[:nd] - hand_base).max()))
        names = ["KREPORT.md", "families.csv", "inputs.csv", "gate.csv", "folds.csv", "DECLARATION.json", "run.json",
                 "outputs.sha256"]
        rc2, log2, _ = run_k(w, tmp / "out")
        led = [json.loads(x) for x in (tmp / "out" / WY.LEDGER).read_text().splitlines()]
        check("tk2d outputs and hashes; a second part K run is refused without --rerun-reason; the ledger line",
              all((rd / x).is_file() for x in names) and rc2 == 2 and "rerun-reason" in log2 and len(led) == 1 and
              led[0]["event"] == "model" and led[0]["gate_passed"], (rc2, log2[-300:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def tk3_gate_and_refusals():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_k2_"))
    try:
        w = make_k_world(tmp, planted=True, seed=32, n_stocks=30)
        P = pd.read_parquet(w["rd"] / "preds.parquet")
        m = (P["target"] == "label_oc_5").to_numpy()
        days = np.unique(P.loc[m, "timestamp"])
        bad = set(days[::20])                                     # 5% of the days scrambled
        mm = m & P["timestamp"].isin(bad).to_numpy()
        P.loc[mm, "score"] = np.random.default_rng(1).permutation(P.loc[mm, "score"].to_numpy())
        P.to_parquet(w["rd"] / "preds.parquet", index=False)
        write_frozen(w["root"], w["prod"])
        rc, log, rd = run_k(w, tmp / "out")
        rep_ = (rd / "KREPORT.md").read_text(encoding="utf-8") if rd else ""
        check("tk3 the gate: frozen scores that the rebuild does not reproduce on 5% of days STOP part K (exit 3); the "
              "report says the rebuild is not the frozen D and no knock-out ran",
              rc == 3 and "STOPPED" in log and "FAILED" in rep_ and "No knock-out ran" in rep_ and
              not (rd / "families.csv").read_text().strip(), (rc, log[-600:]))
        # refusals: a stage_d_gate.py changed after the freeze, a config that is not the frozen one
        (w["prod"] / "stage_d_gate.py").write_text(SD_STANDIN + "\n# changed\n", encoding="utf-8")
        rc1, log1, _ = run_k(w, tmp / "out_b")
        (w["prod"] / "stage_d_gate.py").write_text(SD_STANDIN, encoding="utf-8")
        sdj = json.loads((w["rd"] / "stage_d.json").read_text())
        sdj["config"]["fit_cap"] = 1234
        (w["rd"] / "stage_d.json").write_text(json.dumps(sdj), encoding="utf-8")
        write_frozen(w["root"], w["prod"])
        rc2, log2, _ = run_k(w, tmp / "out_c")
        sdj["config"]["fit_cap"] = 9000
        (w["rd"] / "stage_d.json").write_text(json.dumps(sdj), encoding="utf-8")
        write_frozen(w["root"], w["prod"])
        P2 = pd.read_parquet(w["rd"] / "preds.parquet")
        P2.loc[P2.index[:5], "score"] += 1.0
        P2.to_parquet(w["rd"] / "preds.parquet", index=False)                  # changed after the freeze
        rc3, log3, _ = run_k(w, tmp / "out_d")
        check("tk3b refused before anything runs: production's stage_d_gate.py not the frozen file; a stage_d.json "
              "whose config is not stage_d_gate's; a preds.parquet changed after the freeze",
              rc1 == 2 and "not the frozen" in log1 and rc2 == 2 and "config differs" in log2 and rc3 == 2 and
              "preds.parquet" in log3 and not (tmp / "out_b" / "model").exists() and
              not (tmp / "out_d" / "model").exists(), (log1[-300:], log2[-300:], log3[-300:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------------------------------------------- part P
PP_STANDIN = """
\"\"\"TEST STAND-IN for paper_pipeline (paths) - NOT the production file.\"\"\"
from pathlib import Path


def paths(root):
    return {"live": Path(root) / "panel_live" / "panel.parquet", "paper": Path(root) / "paper"}
"""
RET_G, VOL_G = "returns, reversal and oscillators", "volatility and jumpiness"


def use_prod_p(d: Path):
    sys.modules.pop("paper_pipeline", None)
    use_prod(d)


def brute_shap(f, x, bg):
    """Interventional Shapley values by the definition: v(S) = mean over the background rows of f with S taken
    from x, every subset weighted |S|! (M-|S|-1)! / M!."""
    from itertools import combinations
    from math import factorial
    M = len(x)
    phi = np.zeros(M)

    def v(S):
        Z = bg.copy()
        if S:
            Z[:, list(S)] = x[list(S)]
        return float(f(Z).mean())
    for j in range(M):
        others = [k for k in range(M) if k != j]
        for r in range(M):
            for S in combinations(others, r):
                w = factorial(len(S)) * factorial(M - len(S) - 1) / factorial(M)
                phi[j] += w * (v(S + (j,)) - v(S))
    return phi


def tp1_shap_by_hand():
    from sklearn.ensemble import HistGradientBoostingRegressor
    shap = WY.p_shap()
    rng = np.random.default_rng(11)
    Xa = rng.normal(size=(3000, 5))
    Xa[rng.random(Xa.shape) < 0.05] = np.nan
    ya = np.nan_to_num(Xa[:, 0]) * (np.nan_to_num(Xa[:, 1]) > 0) + 0.5 * np.nan_to_num(Xa[:, 2]) + \
        0.3 * np.nan_to_num(Xa[:, 4]) + rng.normal(0, 0.2, 3000)
    m = HistGradientBoostingRegressor(max_iter=25, max_leaf_nodes=8, random_state=0).fit(Xa, ya)
    bg = rng.normal(size=(12, 5))
    bg[3, 1] = np.nan
    bg[:, 4] = 0.7                                     # the same for every stock of the day
    xs = rng.normal(size=(3, 5))
    xs[:, 4] = 0.7
    xs[1, 2] = np.nan
    E = WY.PExplainer(shap, m)
    phi = E(xs, bg)
    hand = np.vstack([brute_shap(m.predict, xs[i], bg) for i in range(3)])
    fresh = shap.TreeExplainer(m, data=bg, feature_perturbation="interventional").shap_values(xs,
                                                                                              check_additivity=False)
    G = WY.p_groups([("a", [0, 1]), ("b", [2]), ("c", [3, 4])], 5)
    adds = np.allclose(phi.sum(1), m.predict(xs) - m.predict(bg).mean(), atol=1e-7)
    E2 = WY.PExplainer(shap, m)
    E2.ens.values = E2.ens.values * 1.001                # the parsed trees no longer the model's
    try:
        E2(xs, bg)
        caught = False
    except WY.PAddError:
        caught = True
    check("tp1 each push = the Shapley value by its definition (every subset of inputs, the other inputs from each of "
          "the day's comparison stocks; gaps in the data included) to within 1e-7 (shap's own rounding is ~1e-8 of the "
          "values); the pushes add up to the score minus the comparison's mean; an input the same for every stock pushes "
          "exactly 0; the parsed trees reused = a fresh explainer; group pushes are sums; an explanation that does not "
          "add up stops the run",
          np.allclose(phi, hand, atol=1e-7) and np.allclose(phi, fresh, atol=1e-12) and adds and
          np.all(phi[:, 4] == 0) and np.allclose(phi @ G, np.column_stack([phi[:, :2].sum(1), phi[:, 2],
                                                                           phi[:, 3:].sum(1)])) and caught,
          (np.abs(phi - hand).max(), np.abs(phi - fresh).max(), adds, phi[:, 4], caught))


def tp2_draw_and_versions():
    cand = np.arange(10, 300)
    d0 = WY.p_draw(0, 20240105, cand)
    want = np.sort(cand[np.random.default_rng([0, 20240105]).choice(290, 100, replace=False)])
    small = WY.p_draw(1, 20240105, np.arange(50))
    ok_draw = (np.array_equal(d0, want) and len(d0) == 100 and not np.array_equal(d0, WY.p_draw(1, 20240105, cand))
               and np.array_equal(small, np.arange(50)) and np.array_equal(d0, WY.p_draw(0, 20240105, cand)))
    tmp = Path(tempfile.mkdtemp(prefix="whylab_pv_"))
    try:
        from sklearn.ensemble import HistGradientBoostingRegressor
        w = make_k_world(tmp, planted=True, seed=33, n_stocks=30)
        use_prod(w["prod"])
        import stage_b_screen as SB_
        import stage_d_gate as SD_
        inp = WY.k_inputs(w["root"], SD_)
        ts_s, sym_s, sessions, day, y, X = WY.k_load(SD_, SB_, inp["pp"], inp["feats"], log=lambda *a: None)
        fits, score = WY.k_fit(SD_, X, y, day, sessions, inp["folds"], log=lambda *a: None)
        f, te = inp["folds"][1], fits[1]["te"]
        same = np.array_equal(WY.p_refit(SD_, X, y, day, sessions, f, None).predict(X[te]),
                              fits[1]["model"].predict(X[te]))
        v1 = WY.p_refit(SD_, X, y, day, sessions, f, 1)
        sidx = {np.datetime64(s, "ns"): i for i, s in enumerate(sessions)}
        tr = np.flatnonzero((day <= sidx[np.datetime64(pd.Timestamp(f["train_end"]), "ns")]) & np.isfinite(y))
        lab, _, _ = SD_.make_label(y[tr], day[tr], (1, 99))
        keep = np.sort(np.random.default_rng([7, int(f["fold"]), 5, 1]).choice(len(tr), min(9000, len(tr)),
                                                                                replace=True))
        hand = HistGradientBoostingRegressor(random_state=7, **SD_.CFG["hgb"]).fit(X[tr[keep]], lab[keep])
        boot = (np.array_equal(v1.predict(X[te]), hand.predict(X[te])) and len(np.unique(keep)) < len(keep) and
                not np.array_equal(v1.predict(X[te]), fits[1]["model"].predict(X[te])))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    check("tp2 the comparison draw (100 of the day's candidates without replacement, numpy rng [version, YYYYMMDD], "
          "sorted; all of them when not more; another version draws others); the check versions use part K's training "
          "rows (the official draw rebuilt there = the fold's model exactly) and a bootstrap draw WITH replacement "
          "(rng [7, fold, 5, b]) = the same fit by hand",
          ok_draw and same and boot, (ok_draw, same, boot))


def make_q(seed=5):
    """A made-up pick table: fast (all at D1, its reason gone at D1), slow (builds, accelerates after D5, reason still
    there at D5), MIXED (reason gone at D3 after an unknown D1), and a category too small in 2024-26."""
    rng = np.random.default_rng(seed)
    days = pd.bdate_range("2020-01-01", "2025-12-31")
    rows = []
    for d in days:
        p_t = 0.067 if d.year < 2024 else 0.134
        for cat in ("fast", "slow", "flip", WY.MIXED) + (("tiny",) if rng.random() < p_t else ()):
            r = {"day": np.datetime64(d.date()), "category": cat}
            e = rng.normal(0, 0.05, 16)
            if cat == "fast":
                xr = [4.0] * 10
                xo = [5.0, 4.5, 4.2, 4.1, 4.0]
                st = [WY.GONE, WY.GONE, WY.THERE, WY.GONE, WY.GONE]
            elif cat == "slow":
                xr = [0.5 * k for k in range(1, 6)] + [2.5 + 1.0 * (k - 5) for k in range(6, 11)]
                xo = [0.4, 0.9, 1.4, 1.9, 2.6]
                st = [WY.THERE] * 5
            elif cat == "flip":                       # all at D1 in 2020-23, builds to D10 in 2024-26
                xr = [3.0] * 10 if d.year < 2024 else [0.5 * k for k in range(1, 11)]
                xo = [3.0] * 5 if d.year < 2024 else [0.4, 0.9, 1.4, 1.9, 2.4]
                st = [WY.THERE] * 4 + [WY.GONE]
            elif cat == WY.MIXED:
                xr = [0.4 * k for k in range(1, 11)]
                xo = [0.3, 0.7, 3.0, 1.5, 2.1]
                st = [WY.UNKNOWN, WY.THERE, WY.GONE, WY.GONE, WY.GONE]
            else:
                xr = [1.0] * 10
                xo = [1.0] * 5
                st = [WY.THERE] * 5
            for k in range(1, 11):
                r[f"x_r{k}"] = xr[k - 1] + e[k - 1]
            for k in range(2, 7):
                r[f"x_o{k}"] = xo[k - 2] + e[8 + k]
            for c in range(1, 6):
                r[f"st_{c}"] = st[c - 1]
            rows.append(r)
    Q = pd.DataFrame(rows)
    Q["period"] = np.where(Q["day"].to_numpy().astype("datetime64[D]") < WY.P2_START, "P1", "P2")
    return Q


def tp3_tests_by_hand():
    Q = make_q()
    S = WY.Stat(SL, Q["day"].to_numpy())
    R = WY.p_tests(S, Q, ["fast", "slow", "flip", "tiny"])
    C = R["categories"].set_index("category")
    P1, P2 = (Q["period"] == "P1").to_numpy(), (Q["period"] == "P2").to_numpy()
    ok = []
    for c in ("fast", "slow", "flip", WY.MIXED):
        A = (Q["category"] == c).to_numpy()
        e = np.column_stack([(Q[f"x_r{k}"].to_numpy() - 0.35) / k for k in range(1, 11)])
        ks = int(np.argmax(e[A & P1].mean(0))) + 1
        d2 = float((e[A & P2, ks - 1] - e[A & P2, 4]).mean())
        t1 = float(Q.loc[A & P1, "x_r5"].mean() - Q.loc[~A & P1, "x_r5"].mean())
        ok.append(C.loc[c, "k_star"] == ks and np.isclose(C.loc[c, "t2_P2"], d2) and np.isclose(C.loc[c, "t1_P1"], t1))
    first = np.where(Q["category"] == "fast", 1, np.where(Q["category"] == WY.MIXED, 3, 0))
    v3 = np.where(first == 1, Q["x_r5"] - Q["x_o2"], np.where(first == 3, Q["x_r5"] - Q["x_o4"], np.nan))
    t3_1 = float(np.nanmean(v3[P1]))
    there5 = (Q["category"].isin(["slow", "tiny"])).to_numpy()
    t4_2 = float((Q.loc[there5 & P2, "x_r10"] - Q.loc[there5 & P2, "x_r5"]).mean() - (Q.loc[P2, "x_r5"] - 0.35).mean())
    # the intervals by hand from setuplab's resampling matrix: T4's two groups overlap (the held picks are also in
    # "all picks"), each resampled day adds its rows to both means
    di, Mx = S.di(Q["day"].to_numpy()), S.boot.M
    nd = Mx.shape[1]

    def boot_mean(v, m):
        return (Mx @ np.bincount(di[m], v[m], nd)) / (Mx @ np.bincount(di[m], minlength=nd))
    a4 = (Q["x_r10"] - Q["x_r5"]).to_numpy()
    h4 = (Q["x_r5"] - 0.35).to_numpy()
    lo4, hi4 = np.percentile(boot_mean(a4, there5 & P2) - boot_mean(h4, P2), [2.5, 97.5])
    fastm = (Q["category"] == "fast").to_numpy()
    x5 = Q["x_r5"].to_numpy()
    lo1, hi1 = np.percentile(boot_mean(x5, fastm & P1) - boot_mean(x5, ~fastm & P1), [2.5, 97.5])
    ints = (np.isclose(R["T4"]["lo_P2"], lo4) and np.isclose(R["T4"]["hi_P2"], hi4) and lo4 < t4_2 < hi4 and
            np.isclose(C.loc["fast", "t1_lo_P1"], lo1) and np.isclose(C.loc["fast", "t1_hi_P1"], hi1))
    check("tp3 T1-T4 by hand on a made-up pick table: the best hold chosen on 2020-23 (edge a day after costs) and "
          "judged on 2024-26; each category against all the other picks; the first close where the reason is gone "
          "(an unknown close skipped) and the own move from the NEXT open to the D5 close; the reason-still-there "
          "picks' D5-D10 move against a new pick's (own move to D5 - 0.35); the intervals from the resampling matrix by "
          "hand (T4's groups overlap); verdicts; too few picks",
          all(ok) and ints and np.array_equal(R["first_gone"], first) and np.isclose(R["T3"]["stat_P1"], t3_1) and
          np.isclose(R["T4"]["stat_P2"], t4_2) and C.loc["fast", "T2"] == "OWN HOLD D1" and
          C.loc["slow", "T2"] == "OWN HOLD D10" and C.loc["flip", "k_star"] == 1 and C.loc["flip", "T2"] == "KEEP D5"
          and C.loc["tiny", "picks_P1"] > 50 and C.loc["tiny", "picks_P2"] > 50 and
          C.loc["fast", "T1"] == "DIFFERS: BETTER" and
          C.loc[WY.MIXED, "T1"] == "DIFFERS: WORSE" and C.loc["tiny", "T1"] == "TOO FEW" and
          C.loc["tiny", "T2"] == "TOO FEW" and R["T3"]["verdict"] == "EXIT EARLY" and
          R["T4"]["verdict"] == "HOLD LONGER", (ok, ints, (R["T4"]["lo_P2"], lo4, R["T4"]["hi_P2"], hi4, t4_2),
                                                C[["k_star", "T1", "T2"]].to_string(), R["T3"]["verdict"],
                                                R["T4"]["verdict"]))


def tp4_outcomes_by_hand():
    rng = np.random.default_rng(8)
    cal = np.arange(np.datetime64("2022-01-03"), np.datetime64("2022-12-30")).astype("datetime64[D]")
    cal = cal[np.isin((cal.view("int64") - 4) % 7, [0, 1, 2, 3, 4])]
    keep = np.ones(len(cal), bool)
    keep[100] = False
    dates = cal[keep]
    m = len(dates)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, m)))
    o = np.r_[100, c[:-1]] * np.exp(rng.normal(0, 0.005, m))
    h, l, v = np.fmax(o, c) * 1.01, np.fmin(o, c) * 0.99, rng.lognormal(10, 0.5, m)
    ds = DS(dates, o, h, l, c, v)
    F = WY.p_arrays(ds, cal)
    A = WY.stock_arrays(SL, ds, cal)
    hand = {k: np.full(m, np.nan) for k in ("o2", "o3", "o4", "o5")}
    for t in range(m - 1):
        j = int(np.searchsorted(cal, dates[t], side="right"))
        if j < len(cal) and dates[t + 1] == cal[j]:
            for k in (2, 3, 4, 5):
                if t + k < m:
                    hand[f"o{k}"][t] = (o[t + k] / o[t + 1] - 1) * 100
    sus = int(np.searchsorted(dates, cal[99]))
    check("tp4 part P's outcomes: D1..D10 closes and the D6 open = the claims part's own, the D2..D5 opens by hand; no "
          "outcome after a suspension",
          all(close(F[f"r{k}"], A[f"r{k}"], 1e-12) for k in range(1, 11)) and close(F["o6"], A["open6"], 1e-12) and
          all(close(F[k], hand[k], 1e-12) for k in hand) and np.isnan(F["o3"][sus]) and np.isfinite(F["o3"][sus - 1]),
          {k: np.nanmax(np.abs(F[k] - hand[k])) for k in hand})


def make_p_world(tmp: Path, kind: str = "planted", seed: int = 41, n_stocks: int = 72) -> dict:
    """Bars, panel_oc, the frozen D run (stand-in stage D, an independent fold loop), a setuplab TREE run.
    planted: A = RSI 7 jumps one day (gone the next), the stock jumps 9% on D1 then gives back 0.75% a day to D5;
    B = ATR % high for 11 days while the stock climbs 1.2% a day for 10 days. null: nothing planted."""
    rng = np.random.default_rng(seed)
    root = tmp / "cache"
    root.mkdir(parents=True, exist_ok=True)
    prod = tmp / "_prod"
    prod.mkdir(parents=True, exist_ok=True)
    (prod / "stage_b_screen.py").write_text(SB_STANDIN, encoding="utf-8")
    (prod / "stage_d_gate.py").write_text(SD_STANDIN, encoding="utf-8")
    (prod / "paper_pipeline.py").write_text(PP_STANDIN, encoding="utf-8")
    use_prod_p(prod)
    W.write_mods(root)
    W.use_mods(root)
    import stage_b_screen as SB_
    import stage_d_gate as SD_
    cal = pd.bdate_range("2021-06-01", "2025-06-30")
    cal = cal[~((cal.month == 1) & (cal.day == 26))]
    n, S = len(cal), n_stocks
    syms = [f"P{i:02d}" for i in range(S)]
    sig = rng.uniform(0.01, 0.02, S)
    lr = rng.normal(0, 1, (S, n)) * sig[:, None]
    rsi, atr = rng.normal(0, 1, (S, n)), rng.normal(0, 1, (S, n))
    evA, evB = np.zeros((S, n), bool), np.full((S, n), -1)
    if kind == "planted":
        for s in range(S):
            t = 20
            while t < n - 16:
                if rng.random() < 0.045:
                    if rng.random() < 0.62:
                        evA[s, t] = True
                        rsi[s, t] = 3.5 + 0.3 * rng.normal()
                        rsi[s, t + 1:t + 6] = -1.5 + 0.2 * rng.normal(size=5)
                        lr[s, t + 1] += np.log(1.09)
                        lr[s, t + 2:t + 6] += np.log(1 - 0.0075)
                        t += 7
                    else:
                        atr[s, t:t + 11] = 3.5 + 0.3 * rng.normal(size=11)
                        evB[s, t:t + 11] = np.arange(11)
                        lr[s, t + 1:t + 11] += np.log(1.012)
                        t += 14
                else:
                    t += 1
    C = 100 * np.exp(np.cumsum(lr, axis=1))
    O = np.concatenate([np.full((S, 1), 100.0), C[:, :-1]], axis=1) * np.exp(rng.normal(0, 0.1, (S, n)) * sig[:, None])
    Hh = np.fmax(O, C) * np.exp(np.abs(rng.normal(0, 0.5, (S, n))) * sig[:, None])
    Ll = np.fmin(O, C) * np.exp(-np.abs(rng.normal(0, 0.5, (S, n))) * sig[:, None])
    V = rng.lognormal(12, 0.5, (S, n))
    tsI = cal.tz_localize(IST)
    for i, s in enumerate(syms):
        pd.DataFrame({"timestamp": tsI, "open": O[i], "high": Hh[i], "low": Ll[i], "close": C[i],
                      "volume": V[i]}).to_parquet(root / f"{s}_daily.parquet", index=False)
    e = 100 * np.exp(np.cumsum(rng.normal(0, 0.006, n)))
    eo = np.r_[100.0, e[:-1]]
    pd.DataFrame({"timestamp": tsI, "open": eo, "high": np.fmax(eo, e) * 1.002, "low": np.fmin(eo, e) * 0.998,
                  "close": e, "volume": 1e6}).to_parquet(root / "NIFTYBEES_daily.parquet", index=False)
    c = 18000 * np.exp(np.cumsum(rng.normal(0, 0.009, n)))
    pd.DataFrame({"timestamp": tsI, "open": c, "high": c * 1.004, "low": c * 0.996, "close": c,
                  "volume": 1e6}).to_parquet(root / "NIFTY50_daily.parquet", index=False)
    allsyms = syms + ["NIFTYBEES"]
    SA = len(allsyms)
    Ca, Oa = np.vstack([C, e[None, :]]), np.vstack([O, eo[None, :]])
    lab = np.full((SA, n), np.nan)
    lab[:, :-5] = Ca[:, 5:] / Oa[:, 1:-4] - 1
    N = n * SA

    def col(M):
        return np.asarray(M).T.reshape(-1)
    rows = {"timestamp": np.repeat(tsI.to_numpy(), SA), "symbol": np.tile(allsyms, n),
            "D_rsi7": col(np.vstack([rsi, rng.normal(0, 1, (1, n))])),
            "D_atr_pct": col(np.vstack([atr, rng.normal(0, 1, (1, n))]))}
    for f in ("D_breakout_high_20", "D_amihud_20", "D_drawdown_252", "D_adx14", "D_inside_day"):
        rows[f] = rng.normal(size=N)
    rows["Comb_ATRhigh__EMA20neg"] = (rng.random(N) < 0.3).astype(float)
    rows["MKT_D_rsi14"] = np.repeat(rng.normal(size=n), SA)
    rows["DOW_1"] = np.repeat((cal.dayofweek == 1).astype(float), SA)
    rows["X_universe_size"] = np.repeat(np.full(n, float(SA)), SA)
    rows["NIFTYBANK_ret_1d"] = np.repeat(rng.normal(0, 0.01, n), SA)
    rows["label_oc_5"] = col(lab)
    rows["label_buyable_o1"] = (rng.random(N) > 0.01).astype(float)
    (root / "panel_oc").mkdir(parents=True, exist_ok=True)
    pp = root / "panel_oc" / "panel.parquet"
    pd.DataFrame(rows).to_parquet(pp, index=False)
    sess = pd.DatetimeIndex(cal)
    folds = []
    for fo, (a, b) in enumerate((("2022-01-03", "2022-12-30"), ("2023-01-02", "2023-12-29"),
                                 ("2024-01-02", "2025-06-13")), 1):
        t0_, t1_ = int(sess.searchsorted(pd.Timestamp(a))), int(sess.searchsorted(pd.Timestamp(b)))
        folds.append({"target": "label_oc_5", "fold": fo, "train_end": str(sess[t0_ - 7].date()),
                      "test_start": str(sess[t0_].date()), "test_end": str(sess[t1_].date())})
    rd = root / "panel_oc" / "stage_d" / "STAGED_TEST_001"
    rd.mkdir(parents=True, exist_ok=True)
    (rd / "stage_d.json").write_text(json.dumps({"features": K_FEATS, "folds": folds, "config": SD_.CFG}),
                                     encoding="utf-8")
    pr = oracle_preds(pp, K_FEATS, folds, SD_, SB_)
    pr.to_parquet(rd / "preds.parquet", index=False)
    write_frozen(root, prod)
    # setuplab's TREE run: engine D, ranks 1-10 by the frozen score, the D1 net from the bars by hand
    tday = {np.datetime64(d, "D"): i for i, d in enumerate(cal.values.astype("datetime64[D]"))}
    pos = {s: i for i, s in enumerate(allsyms)}
    trs = []
    for d, g in pr.groupby("timestamp", sort=True):
        g = g.sort_values(["score", "symbol"], ascending=[False, True]).head(10)
        t = tday[np.datetime64(pd.Timestamp(d).date(), "D")]
        for rk, s in enumerate(g["symbol"], 1):
            i = pos[s]
            ok = t + 5 < n
            trs.append({"trade_id": f"D-{pd.Timestamp(d):%Y%m%d}-{rk}", "engine": "D", "rank": rk, "symbol": s,
                        "signal_day": f"{pd.Timestamp(d):%Y-%m-%d}", "s_atr14": np.nan, "etf": s.endswith("BEES"),
                        "d1_net": (Ca[i, t + 5] / Oa[i, t + 1] - 1) * 100 - 0.35 if ok else np.nan,
                        "complete": bool(ok), "lane": "NO CUT-OFF"})
    Tg = pd.DataFrame(trs)
    for c_, v_ in (("cutoff", np.nan), ("gap_pct", 0.0), ("opened_up", True), ("dip_2pct", False),
                   ("runner", False), ("first_setup", ""), ("setup_net", np.nan), ("bunch", ""), ("action", ""),
                   ("how", ""), ("in_book_start1", False)):
        Tg[c_] = v_
    sbase = tmp / "setuplab_out"
    write_tree(sbase, Tg)
    return {"root": root, "prod": prod, "pp": pp, "rd": rd, "sbase": sbase, "folds": folds, "preds": pr,
            "evA": evA, "evB": evB, "syms": syms, "cal": cal, "tree": Tg}


def write_tree(sbase: Path, Tg: pd.DataFrame) -> Path:
    tr = SL.new_run_dir(sbase / "TREE", "TREE")
    Tg.to_parquet(tr / "tree_tags.parquet", index=False)
    (tr / "TREE_RUN.json").write_text(json.dumps({"version": "setuplab v1.1"}), encoding="utf-8")
    SL.write_hashes(tr, ["tree_tags.parquet", "TREE_RUN.json"])
    return tr


def run_p(w, out, extra=()):
    use_prod_p(w["prod"])
    W.use_mods(w["root"])
    rc, log = quiet(WY.main, ["explain", "--root", str(w["root"]), "--setups", str(w["sbase"]), "--out", str(out),
                              "--stage-e-any"] + list(extra))
    runs = sorted((Path(out) / "explain").glob("P_*")) if (Path(out) / "explain").exists() else []
    return rc, log, (runs[-1] if runs else None)


def kind_of_picks(w, Pk):
    """A / B (and the B phase) of each pick from the world's own records."""
    cday = {d: i for i, d in enumerate(w["cal"].values.astype("datetime64[D]"))}
    si = {s: i for i, s in enumerate(w["syms"])}
    t = np.array([cday[np.datetime64(pd.Timestamp(d).date(), "D")] for d in Pk["day"]])
    s = np.array([si.get(x, -1) for x in Pk["symbol"]])
    ok = s >= 0
    A = np.zeros(len(Pk), bool)
    ph = np.full(len(Pk), -1)
    A[ok] = w["evA"][s[ok], t[ok]]
    ph[ok] = w["evB"][s[ok], t[ok]]
    return A, ph


def tp5_planted():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_p_"))
    try:
        w = make_p_world(tmp, "planted")
        rc, log, rd = run_p(w, tmp / "out")
        ok = rc == 0 and rd is not None and (rd / "picks.csv").is_file()
        check("tp5 PLANTED world: part P runs - part K's gate, every explanation adds up, the bars give the tree's D1 "
              "net", ok and "PASSED" in (rd / "PREPORT.md").read_text(encoding="utf-8"), (rc, log[-2500:]))
        if not ok:
            return
        Pk = pd.read_csv(rd / "picks.csv", parse_dates=["day"])
        C = pd.read_csv(rd / "categories.csv").set_index("category")
        T = pd.read_csv(rd / "tests.csv").set_index("test")
        A, ph = kind_of_picks(w, Pk)
        B = ph >= 0
        pr = w["preds"].copy()
        pr = pr[~pr["symbol"].str.endswith("BEES")].sort_values(["timestamp", "score", "symbol"],
                                                                 ascending=[True, False, True])
        top = pr.groupby("timestamp").head(3)
        want = set(zip(pd.to_datetime(top["timestamp"]).dt.date, top["symbol"]))
        got = set(zip(Pk["day"].dt.date, Pk["symbol"]))
        a_ok = float(((Pk["category"] == RET_G) & Pk["confident"])[A].mean())
        b_ok = float(((Pk["category"] == VOL_G) & Pk["confident"])[B].mean())
        vote = ((Pk["confident"] == ((Pk["reason"] == Pk["v1_top"]) & (Pk["reason"] == Pk["v2_top"]))).all() and
                (Pk["category"] == np.where(Pk["confident"], Pk["reason"], WY.MIXED)).all())
        check("tp5b the picks are part K's (the frozen top 3, ETFs out); CONFIDENT = all three versions name the same "
              "group, the category is that group, else MIXED; the planted reasons come out CONFIDENT: RSI-7 jumps -> "
              "'returns, reversal and oscillators', ATR % -> 'volatility and jumpiness'",
              len(got ^ want) <= 0.01 * len(want) and A.sum() > 300 and B.sum() > 300 and a_ok >= 0.9 and b_ok >= 0.9
              and vote, (len(got ^ want), int(A.sum()), int(B.sum()), a_ok, b_ok, vote))
        a_gone = float((Pk.loc[A, "st_1"] == WY.GONE).mean())
        b_there = float((Pk.loc[B & (ph <= 5), [f"st_{c}" for c in range(1, 6)]] == WY.THERE).all(axis=1).mean())
        check("tp5c transitions: the RSI-7 picks' reason is GONE at the D1 close; the ATR-% picks' reason is STILL THERE "
              "through D5 while ATR % stays high; T3 (reason gone -> sell at the next open) = EXIT EARLY; the "
              "returns category's best hold = D1 (OWN HOLD D1)",
              a_gone >= 0.95 and b_there >= 0.9 and T.loc["T3 reason gone", "verdict"] == "EXIT EARLY" and
              C.loc[RET_G, "T2"] == "OWN HOLD D1" and int(T.loc["T3 reason gone", "gone_at_D1"]) >= A.sum() * 0.9,
              (a_gone, b_there, T.loc["T3 reason gone", "verdict"], C["T2"].to_dict()))
        # one pick by hand: its fold's model rebuilt, the declared draw, shap by the definition's library call
        use_prod_p(w["prod"])
        import stage_b_screen as SB_
        import stage_d_gate as SD_
        kd, _ = WY.load_k()
        inp = WY.k_inputs(w["root"], SD_)
        ts_s, sym_s, sessions, day, y, X = WY.k_load(SD_, SB_, inp["pp"], inp["feats"], log=lambda *a: None)
        fits, score = WY.k_fit(SD_, X, y, day, sessions, inp["folds"], log=lambda *a: None)
        fams = WY.k_families(inp["feats"], kd)
        q = int(np.flatnonzero(A)[len(np.flatnonzero(A)) // 2])
        d = np.datetime64(Pk["day"].iloc[q].date(), "D")
        di = int(np.searchsorted(sessions.astype("datetime64[D]"), d))
        rows = np.flatnonzero(day == di)
        etf = np.array([s.endswith("BEES") for s in sym_s])
        fo = [k for k, f in enumerate(fits) if di in set(day[f["te"]])][0]
        pk = rows[np.argsort(-np.where(etf[rows], -np.inf, score[rows]), kind="stable")[:3]]
        cand = np.array([r for r in rows if not etf[r] and r not in set(pk)])
        bg = cand if len(cand) <= 100 else np.sort(cand[np.random.default_rng([0, int(str(d).replace("-", ""))])
                                                        .choice(len(cand), 100, replace=False)])
        r0 = rows[sym_s[rows] == Pk["symbol"].iloc[q]][0]
        shap = WY.p_shap()
        phi = shap.TreeExplainer(fits[fo]["model"], data=X[bg].astype(float), feature_perturbation="interventional") \
            .shap_values(X[[r0]].astype(float), check_additivity=False)[0]
        hand = {nm: phi[cols].sum() * 100 for nm, cols in fams}
        got_p = {nm: Pk[f"push_{nm}"].iloc[q] for nm, _ in fams}
        check("tp5d one pick by hand: its fold's model, the declared comparison draw, shap -> the same pushes per group "
              "as picks.csv",
              all(abs(hand[k] - got_p[k]) < 1e-9 for k in hand), {k: (hand[k], got_p[k]) for k in hand})
        names = ["PREPORT.md", "picks.csv", "reasons.csv", "categories.csv", "transitions.csv", "tests.csv", "gate.csv",
                 "DECLARATION.json", "run.json", "outputs.sha256"]
        rc2, log2, _ = run_p(w, tmp / "out")
        led = [json.loads(x) for x in (tmp / "out" / WY.LEDGER).read_text().splitlines()]
        rep_ = (rd / "PREPORT.md").read_text(encoding="utf-8")
        check("tp5e outputs and hashes; the report's sections; a second part P run is refused without --rerun-reason; "
              "the ledger line",
              all((rd / x).is_file() for x in names) and rc2 == 2 and "rerun-reason" in log2 and len(led) == 1 and
              led[0]["event"] == "explain" and "Transitions" in rep_ and "T3" in rep_ and "How sure" in rep_,
              (rc2, log2[-300:], [x for x in names if not (rd / x).is_file()]))
        conf_planted = float(json.loads((rd / "run.json").read_text())["confident_pct"])
        w["conf"] = conf_planted
        return w
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def tp6_null_and_gates(conf_planted):
    tmp = Path(tempfile.mkdtemp(prefix="whylab_pn_"))
    try:
        w = make_p_world(tmp, "null", seed=43)
        rc, log, rd = run_p(w, tmp / "out")
        ok = rc == 0 and rd is not None and (rd / "run.json").is_file()
        conf = float(json.loads((rd / "run.json").read_text())["confident_pct"]) if ok else np.nan
        T = pd.read_csv(rd / "tests.csv").set_index("test") if ok else None
        Pn = pd.read_csv(rd / "picks.csv") if ok else None
        vote = ok and bool((Pn["confident"] == ((Pn["reason"] == Pn["v1_top"]) & (Pn["reason"] == Pn["v2_top"]))).all())
        check("tp6 NULL world (nothing planted): the three versions seldom agree - under 30% CONFIDENT, far fewer than "
              "the planted world; T3 is not EXIT EARLY",
              ok and vote and conf_planted is not None and conf < 30 and conf < conf_planted - 20 and
              T.loc["T3 reason gone", "verdict"] != "EXIT EARLY", (rc, conf, conf_planted, log[-800:]))
        # the outcome gate: a tree whose D1 net is off on 2% of D's rows stops the run, no test judged
        Tg = w["tree"].copy()
        k = np.random.default_rng(1).choice(len(Tg), int(0.02 * len(Tg)), replace=False)
        Tg.loc[Tg.index[k], "d1_net"] += 0.5
        write_tree(w["sbase"], Tg)
        rc2, log2, rd2 = run_p(w, tmp / "out2")
        rep2 = (rd2 / "PREPORT.md").read_text(encoding="utf-8") if rd2 else ""
        old = WY.P_SHAP
        WY.P_SHAP = "9.9.9"
        try:
            rc3, log3, _ = run_p(w, tmp / "out3")
        finally:
            WY.P_SHAP = old
        bad = tmp / "WHY_P_DECLARATION.json"
        bad.write_bytes(WY.P_FILE.read_bytes().replace(b"100", b"101", 1))
        try:
            WY.load_p(bad)
            refused = False
        except WY.WHError:
            refused = True
        check("tp6b the outcome gate: a tree whose D1 net is off on 2% of the picks STOPS part P (exit 3), the report "
              "says so and no test is judged; a shap other than 0.54.1 is refused; a changed declaration is refused",
              rc2 == 3 and "STOPPED" in log2 and "STOPPED" in rep2 and not (rd2 / "picks.csv").exists() and
              rc3 == 2 and "shap" in log3 and refused, (rc2, log2[-600:], rc3, log3[-300:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def make_production(w):
    """production_models' recipe written out independently: D.pkl and PRODUCTION.json; the live panel (the last 40
    sessions, naive timestamps)."""
    import pickle
    import sklearn
    from sklearn.ensemble import HistGradientBoostingRegressor
    use_prod_p(w["prod"])
    import stage_b_screen as SB_
    import stage_d_gate as SD_
    pp, root = w["pp"], w["root"]
    b = pd.read_parquet(pp, columns=["timestamp", "symbol", "label_buyable_o1", "label_oc_5"])
    ts = SB_._naive(b["timestamp"]).to_numpy(dtype="datetime64[ns]")
    yy = b["label_oc_5"].to_numpy(float)
    rows = np.flatnonzero((b["label_buyable_o1"].to_numpy(float) == 1) & np.isfinite(yy))
    day = np.searchsorted(np.unique(ts), ts)
    X = np.column_stack([pd.read_parquet(pp, columns=[f])[f].to_numpy(float)[rows] for f in K_FEATS]).astype(np.float32)
    lab, _, _ = SD_.make_label(yy[rows], day[rows], (1, 99))
    keep = np.sort(np.random.default_rng([7, 99, 5]).choice(len(rows), SD_.CFG["fit_cap"], replace=False))
    m = HistGradientBoostingRegressor(random_state=7, **SD_.CFG["hgb"]).fit(X[keep], lab[keep])
    d = root / "panel_oc" / "frozen" / "production"
    d.mkdir(parents=True, exist_ok=True)
    with open(d / "D.pkl", "wb") as f:
        pickle.dump(m, f)
    meta = {"seed": [7, 99, 5], "libraries": {"python": sys.version.split()[0], "numpy": np.__version__,
                                              "pandas": pd.__version__, "sklearn": sklearn.__version__},
            "models": {"D": {"file": "D.pkl", "sha256": WY.sha256(d / "D.pkl"), "features": K_FEATS,
                             "train_rows": int(len(rows)), "fit_rows": int(len(keep)),
                             "train_end": str(pd.Timestamp(ts[rows].max()).date())}}}
    (d / "PRODUCTION.json").write_text(json.dumps(meta), encoding="utf-8")
    P = pd.read_parquet(pp, columns=["timestamp", "symbol"] + K_FEATS)
    P["timestamp"] = SB_._naive(P["timestamp"]).to_numpy(dtype="datetime64[ns]")
    last = np.sort(P["timestamp"].unique())[-40:]
    P.loc[(P["symbol"] == "NIFTYBEES") & P["timestamp"].isin(last[-6:]), "D_rsi7"] = 4.0   # D would rank the ETF first
    (root / "panel_live").mkdir(exist_ok=True)
    P[P["timestamp"].isin(last)].to_parquet(root / "panel_live" / "panel.parquet", index=False)
    return m


def tt1_today():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_t_"))
    try:
        w = make_p_world(tmp, "planted", seed=45, n_stocks=60)
        m = make_production(w)
        out = tmp / "out"

        def run_t():
            use_prod_p(w["prod"])
            return quiet(WY.main, ["today", "--root", str(w["root"]), "--out", str(out)])
        rc, log = run_t()
        files = sorted((out / "today").glob("TODAY_*.csv"))
        ok = rc == 0 and len(files) == 1
        check("tt1 today runs: builds the two check versions once, only after reproducing D.pkl from production's "
              "recipe", ok and "building the two check versions" in log and "D.pkl reproduced" in log, (rc, log[-2000:]))
        if not ok:
            return
        R = pd.read_csv(files[0])
        L = pd.read_parquet(w["root"] / "panel_live" / "panel.parquet")
        L = L.sort_values(["timestamp", "symbol"]).reset_index(drop=True)
        sess = np.sort(L["timestamp"].unique())
        last = L[L["timestamp"] == sess[-1]].copy()
        last["s"] = m.predict(last[K_FEATS].to_numpy(np.float32))
        last = last[~last["symbol"].str.endswith("BEES")].sort_values(["s", "symbol"], ascending=[False, True])
        new = R[R["kind"] == "new"]
        # one held pick by hand: its reason on its own session, then at the newest close
        shap = WY.p_shap()
        kd, _ = WY.load_k()
        fams = WY.k_families(K_FEATS, kd)
        h = R[R["kind"] == "held"].iloc[0]
        d = np.datetime64(h["session"], "D")
        Ld = L[L["timestamp"].to_numpy().astype("datetime64[D]") == d].copy()
        Ld["s"] = m.predict(Ld[K_FEATS].to_numpy(np.float32))
        nb = ~Ld["symbol"].str.endswith("BEES")
        pk = set(Ld[nb].sort_values(["s", "symbol"], ascending=[False, True])["symbol"].head(3))
        bg_d = Ld[nb & ~Ld["symbol"].isin(pk)].sort_values("symbol")
        T0 = L[L["timestamp"] == sess[-1]].copy()
        T0["s"] = m.predict(T0[K_FEATS].to_numpy(np.float32))
        nb0 = ~T0["symbol"].str.endswith("BEES")
        pk0 = set(T0[nb0].sort_values(["s", "symbol"], ascending=[False, True])["symbol"].head(3))
        bg_0 = T0[nb0 & ~T0["symbol"].isin(pk0)].sort_values("symbol")
        assert len(bg_d) <= 100 and len(bg_0) <= 100

        def gp(rowsdf, bgdf):
            phi = shap.TreeExplainer(m, data=bgdf[K_FEATS].to_numpy(float), feature_perturbation="interventional") \
                .shap_values(rowsdf[K_FEATS].to_numpy(float), check_additivity=False)[0]
            return {nm: phi[cols].sum() for nm, cols in fams}
        p_then = gp(Ld[Ld["symbol"] == h["symbol"]], bg_d)
        reason = max(p_then, key=lambda k: p_then[k])
        p_now = gp(T0[T0["symbol"] == h["symbol"]], bg_0)
        status = "STILL THERE" if p_now[reason] > 0 else "GONE"
        L0 = L[L["timestamp"] == sess[-1]].copy()
        L0["s"] = m.predict(L0[K_FEATS].to_numpy(np.float32))
        etf_first = L0.sort_values("s", ascending=False)["symbol"].iloc[0] == "NIFTYBEES"
        check("tt1b today's picks = D.pkl's top 3 on the newest live session (ETFs out: the ETF D ranks first is left "
              "out; naive timestamps read); each "
              "has a category; a held pick's reason (its own session) and its status at the newest close = shap by hand",
              etf_first and list(new["symbol"]) == list(last["symbol"].head(3)) and new["category"].notna().all() and
              h["reason"] == reason and h["status_now"] == status and abs(h["reason_push_now"] - 100 * p_now[reason])
              < 1e-9, (list(new["symbol"]), list(last["symbol"].head(3)), h.to_dict(), reason, status))
        cdir = next((out / "today" / "checks").iterdir())
        mt = {p.name: p.stat().st_mtime_ns for p in cdir.iterdir()}
        rc2, log2 = run_t()
        same = {p.name: p.stat().st_mtime_ns for p in cdir.iterdir()} == mt
        prodd = w["root"] / "panel_oc" / "frozen" / "production"
        raw = (prodd / "D.pkl").read_bytes()
        (prodd / "D.pkl").write_bytes(raw + b"\0")
        rc3, log3 = run_t()
        (prodd / "D.pkl").write_bytes(raw)
        mraw = (prodd / "PRODUCTION.json").read_text(encoding="utf-8")
        mj = json.loads(mraw)
        mj["libraries"]["sklearn"] = "0.0.1"
        (prodd / "PRODUCTION.json").write_text(json.dumps(mj), encoding="utf-8")
        rc4, log4 = run_t()
        (prodd / "PRODUCTION.json").write_text(mraw, encoding="utf-8")
        v1 = cdir / "V1.pkl"
        vraw = v1.read_bytes()
        v1.write_bytes(vraw + b"\0")
        rc5, log5 = run_t()
        v1.write_bytes(vraw)
        mj = json.loads(mraw)
        mj["seed"] = [7, 99, 6]                                    # not the seed D.pkl was drawn with
        (prodd / "PRODUCTION.json").write_text(json.dumps(mj), encoding="utf-8")
        use_prod_p(w["prod"])
        rc6, log6 = quiet(WY.main, ["today", "--root", str(w["root"]), "--out", str(tmp / "out_seed")])
        (prodd / "PRODUCTION.json").write_text(mraw, encoding="utf-8")
        check("tt1c a second run reuses the check versions (files untouched); refused: a D.pkl changed after the "
              "freeze, a scikit-learn other than the one D.pkl was trained under, a changed check version, check versions "
              "whose recipe does not reproduce D.pkl (nothing saved)",
              rc2 == 0 and "building" not in log2 and same and rc3 == 2 and "changed since it was frozen" in log3 and
              rc4 == 2 and "version-bound" in log4 and rc5 == 2 and "V1.pkl" in log5 and rc6 == 2 and
              "does not reproduce D.pkl" in log6 and not list((tmp / "out_seed").rglob("*.pkl")),
              (rc2, rc3, rc4, rc5, rc6, log3[-200:], log4[-200:], log5[-200:], log6[-300:]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def tt2_live_reader():
    tmp = Path(tempfile.mkdtemp(prefix="whylab_lv_"))
    try:
        use_prod_p(Path(tempfile.mkdtemp(prefix="whylab_lvp_")))
        p_ = Path(sys.path[0])
        (p_ / "stage_b_screen.py").write_text(SB_STANDIN, encoding="utf-8")
        (p_ / "stage_d_gate.py").write_text(SD_STANDIN, encoding="utf-8")
        import stage_b_screen as SB_
        cal = pd.bdate_range("2025-03-03", periods=9)
        res = []
        for tz in (True, False):
            ts = cal.tz_localize(IST) if tz else cal
            Fd = pd.DataFrame({"timestamp": np.repeat(ts, 3), "symbol": np.tile(["B", "A", "C"], 9),
                               "f1": np.arange(27.0), "f2": 1.0})
            Fd = Fd.sample(frac=1.0, random_state=3)
            fp = tmp / f"live_{tz}.parquet"
            Fd.to_parquet(fp, index=False)
            R = WY.p_read_live(SB_, fp, ["f1", "f2"], n=4)
            res.append(list(pd.to_datetime(R["ts"]).dt.date.unique()) == list(cal[-4:].date) and
                       list(R["symbol"][:3]) == ["A", "B", "C"] and len(R) == 12)
        dup = pd.concat([Fd, Fd.head(1)])
        dup.to_parquet(tmp / "dup.parquet", index=False)
        try:
            WY.p_read_live(SB_, tmp / "dup.parquet", ["f1"], n=4)
            dref = False
        except WY.WHError:
            dref = True
        check("tt2 the live reader: the last 4 sessions, IST-aware or naive timestamps, sorted by session and symbol; a "
              "stock twice on one session is refused", all(res) and dref, (res, dref))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    print(f"{WY.VERSION} self-test (pandas {pd.__version__}, numpy {np.__version__})", flush=True)
    state = {}

    def tp5():
        state["w"] = tp5_planted()

    def tp6():
        tp6_null_and_gates((state.get("w") or {}).get("conf"))
    tp5.__name__, tp6.__name__ = "tp5_planted", "tp6_null_and_gates"
    for t in (t1_declaration, t2_measures, t3_controls, t3b_day_frame, t4_rules, t5_claim_logic, t6_claim3_logic, t7_planted,
              t8_fallen_random, t9_gate_and_guards, tk1_families_and_scramble, tk2_planted, tk3_gate_and_refusals,
              tp1_shap_by_hand, tp2_draw_and_versions, tp3_tests_by_hand, tp4_outcomes_by_hand, tp5, tp6,
              tt1_today, tt2_live_reader):
        try:
            t()
        except Exception as e:                                  # noqa: BLE001
            import traceback
            check(f"{t.__name__} raised {type(e).__name__}: {e}", False, traceback.format_exc()[-1500:])
    bad = [n for n, ok in RESULTS if not ok]
    print(f"\n{len(RESULTS)} checks, {len(bad)} failed")
    if bad:
        print("FAILED: " + "; ".join(bad))
        return 1
    print(f"VERIFIED ({WY.VERSION})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
