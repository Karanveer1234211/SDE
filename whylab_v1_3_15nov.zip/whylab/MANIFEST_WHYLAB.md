# MANIFEST - whylab v1.3 (15 Nov 2026)

This research tool lives in its own folder beside tradelab and setuplab. Nothing in `bigmove_deploy`, tradelab or setuplab changes. Production is only read: stage D's code and frozen run, `D.pkl`, the live panel and the daily cache.

| file | what | sha256 (first 16) |
|---|---|---|
| `whylab\whylab.py` | the tool: `check`, `run` (claims), `model` (part K), `explain` and `today` (part P), `triggers` (part T) | f225147f317b26fc |
| `whylab\WHY_DECLARATION.json` | the claims' rules, fixed 14 Nov 2026 20:45 IST; unchanged | e3967dd85a42d063 |
| `whylab\WHY_K_DECLARATION.json` | part K's rules, fixed 15 Nov 2026 00:20 IST; unchanged | 158621297b501323 |
| `whylab\WHY_P_DECLARATION.json` | part P's rules, fixed 15 Nov 2026 01:00 IST; unchanged | 99db37895043cc79 |
| `whylab\WHY_T_DECLARATION.json` | part T's rules, fixed 15 Nov 2026 11:27 IST, amended 11:31 (the 1-ATR fall check), both before any T run | 7a23786a1a801af0 |
| `whylab\tests\test_whylab.py` | self-test, 51 checks | 422d8b8a2607c0e1 |
| `whylab\env_whylab.bat` | session setup (CRLF; labels unique); only its comments changed | bebdf1ae59dbf687 |
| `whylab\README_WHYLAB.md` | what it does, how to run it | dc496e3dcc90e657 |
| `whylab\MANIFEST_WHYLAB.md` | this file | - |

**Libraries:** part T needs nothing new. Part P needs shap 0.54.1 (already installed on your PC).

**What it uses unchanged:**
- setuplab v1.1: Boot, atr_simple, TREE.json and its ETF rule, run folders, hashes.
- tradelab: tl_setups v1.7, tl_data (production's stage E loader), tl_common.
- Imported read only from production, by parts K and P:
  - `stage_d_gate.py` and `stage_b_screen.py`;
  - `paper_pipeline.paths` (today).
- Part T reads part P's run (`picks.csv`, `reasons.csv`) only after checking its `outputs.sha256` and its declaration.

**What it writes:** only `C:\QuantData\whylab\runs\WHY_*`, `model\K_*`, `explain\P_*`, `today\`, `triggers\T_*` and `whylab_ledger.jsonl`.

**Verified 15 Nov 2026:** `VERIFIED (whylab v1.3)`, 51 checks, 0 failed.
- On pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2 (your versions) and on pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1.
- Run time here: 126 s on your versions, 164 s on the newer ones.
- Also checked from a clean folder.

**Planted bugs, 78 of 78 caught:**
- **Claims (26), part K (12), part P (22):** listed in the earlier manifests; that code is unchanged.
- **Part T (18):**
  - translation:
    - candle checked after volatility;
    - market series not left out;
  - indicators:
    - RSI smoothed like an EMA;
    - Bollinger with the sample SD;
    - range expansion measured against today's ATR;
    - the 52-week high including today, which the first suite missed (see below);
  - the move: measured from the signal-day close;
  - the verdict:
    - without the distance bins;
    - 5 closes ahead;
    - counting the move's own close;
    - one period enough;
  - the shown measure:
    - equal weights for the days;
    - counting the move close;
  - kinds and indicators:
    - every pick measured on every trigger;
    - MIXED picks pooled;
    - pushes at or below 0 counted as own;
  - the gate at 90%, and part P's hashes not checked.

**Found while building (synthetic data only, before any T run):**
- **The plain comparison flags false triggers.** On random walks, the agreed comparison of "fired before the move: moved against not moved" shows "close above yesterday's high" about 36–40 points ahead, with no trigger at all, because the move itself has begun. Comparing at the same distance from the target removes that: nothing passes on random walks. That is why the verdict is the same-distance test.
- **Range expansion moves both ways.** On random walks, "true range above 1.5× ATR" raised the chance of a 1-ATR rise in 2020-23, and also of a 1-ATR fall. The fall check (FALLS TOO) was added to the declaration at 11:31, before any T run.
- **The 52-week edge.** A planted bug making the 52-week high include today slipped past the first suite. tt3 now checks a high exactly 252 closes back, and it is caught.

**Run time** for `triggers` on your PC is an estimate: a few minutes, mostly reading the bars.
