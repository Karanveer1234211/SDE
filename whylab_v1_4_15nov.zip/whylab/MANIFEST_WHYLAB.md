# MANIFEST - whylab v1.4 (15 Nov 2026)

This research tool lives in its own folder beside tradelab and setuplab. Nothing in `bigmove_deploy`, tradelab or setuplab changes. Production is only read: stage D's code and frozen run, `D.pkl`, the live panel and the daily cache.

| file | what | sha256 (first 16) |
|---|---|---|
| `whylab\whylab.py` | the tool: `check`, `run` (claims), `model` (part K), `explain` and `today` (part P), `triggers` (part T) | 3e7753ef45dfcd6f |
| `whylab\WHY_DECLARATION.json` | the claims' rules, fixed 14 Nov 2026 20:45 IST; unchanged | e3967dd85a42d063 |
| `whylab\WHY_K_DECLARATION.json` | part K's rules, fixed 15 Nov 2026 00:20 IST; unchanged | 158621297b501323 |
| `whylab\WHY_P_DECLARATION.json` | part P's rules, fixed 15 Nov 2026 01:00 IST; unchanged | 99db37895043cc79 |
| `whylab\WHY_T_DECLARATION.json` | part T's rules, fixed 15 Nov 2026 12:17 IST before any T run; replaces v1.3's (7a23786a1a801af0), which was never run | f6825bc20d149b6d |
| `whylab\tests\test_whylab.py` | self-test, 53 checks | 8e1ac93c31f6c659 |
| `whylab\env_whylab.bat` | session setup (CRLF; labels unique); only its comment changed | 600fa99cb700bb7c |
| `whylab\README_WHYLAB.md` | what it does, how to run it | 2b1a5b89cba5e36f |
| `whylab\MANIFEST_WHYLAB.md` | this file | - |

**Libraries:** part T needs nothing new. Part P needs shap 0.54.1 (already installed on your PC).

**What it uses unchanged:**
- setuplab v1.1: Boot, atr_simple, bh_q (Benjamini–Hochberg, used by part T from v1.4), TREE.json and its ETF rule, run folders, hashes.
- tradelab: tl_setups v1.7, tl_data (production's stage E loader), tl_common.
- Imported read only from production, by parts K and P:
  - `stage_d_gate.py` and `stage_b_screen.py`;
  - `paper_pipeline.paths` (today).
- Part T reads part P's run (`picks.csv`, `reasons.csv`) only after checking its `outputs.sha256` and its declaration.

**What it writes:** only `C:\QuantData\whylab\runs\WHY_*`, `model\K_*`, `explain\P_*`, `today\`, `triggers\T_*` and `whylab_ledger.jsonl`.

**Verified 15 Nov 2026:** `VERIFIED (whylab v1.4)`, 53 checks, 0 failed.
- 147 s on pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2 (your versions).
- 174 s on pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1.
- Also checked from a clean folder.

## What changed in part T (v1.3 -> v1.4)

Karan forwarded a review at 12:00. Each point was checked against the code and part P's real run P_20261115_002. v1.3's part T was never run; its declaration is replaced and pinned out.

**Faults the review found, fixed:**
1. **"13-week momentum" was triggered by a 5-day breakout.** It now has its own events, on the 4- and 13-week returns behind D's inputs W_ret_4w and W_ret_13w:
   - the 4-week return crosses above 0 (ROC 20);
   - the 13-week return crosses above 0 (ROC 65);
   - a new 13-week closing high.
2. **The verdict pooled the closes D1–D7.** It now compares at the same close after the pick, as well as the same distance from the target.
3. **No many-tests check.** v1.3 would have run up to 429 kind × trigger rows; v1.4 will run up to 496. Now Benjamini–Hochberg runs over every judged test, at a 5% false discovery rate, on the weaker period's p (setuplab's rule plus clashlab's weaker-period rule). Rows that pass both periods but not this check are marked MAY BE CHANCE.
4. **Only D1 was checked against the market calendar.** D1–D10 must now be the market's next 10 sessions; otherwise the pick is left out and counted.

**Faults found while checking the review, fixed:**

5. **A translation bug.** The day-of-week pattern `^(d_)?dow` also matched `D_downside_dev_60`. That input is in the top 5 of 805 picks and was dropped as "left out" instead of being followed as volatility. The pattern now needs `dow` followed by `_`, a digit or the end. The test now checks all 135 real input names, where v1.3's test used made-up ones.
6. **The 52-week range had no low-side event,** though D uses it from both ends: 59% of D_drawdown_252's pushes come from at or below the day's median. Added: a new 52-week closing low.
7. **A crossing was compared with closes where it could not have crossed.** The verdict now compares only with closes where the trigger could have fired; for a crossing, the line was below at the close before.

**Kept on purpose:**
- **The readable indicators remain a translation of D's inputs, not the inputs themselves** (the review's main point). It is now measured and reported per kind. On P_20261115_002, D's push over the top 5 inputs splits into:
  - 62.2% the stock's own daily inputs;
  - 24.7% cross-sectional or weekly inputs, followed through the stock's own daily indicator;
  - 13.1% left out, of which 10.0% is WorldQuant.
- **No entry comparison.** At 10:56 Karan said to do only what is asked. The report and the declaration now state that a TRIGGER is a historical link worth testing as an entry, not a tested entry.

**Found while building (synthetic data only):**
- **v1.3's planted calm event was a 2% drop,** which also moved the stock 2+ ATRs from the target. At the same close and distance, band widening added nothing in that world. That is the right answer to v1.4's question, so v1.4 no longer calls band widening a TRIGGER there. The test world now plants a wide-range day with the close unchanged, and its own trigger (true range above 1.5× ATR) is found through the many-tests check.
- **The confounds, measured on made-up picks:**
  - **Early firing:** a trigger that fires early but says nothing passes the old pooled comparison and not the same-close one.
  - **Firing state:** a crossing that fires only out of a state that itself speeds the move shows about +11 to +13 points when compared with every close, and nothing when compared with closes where it could have fired.
- **Two planted bugs slipped through the first v1.4 suite:**
  - counting unmatched firings toward the 100;
  - "within 5% of the 52-week high" firing where the 52-week high starts.
  - tt5 now has a cell with only firings, and tt3 has a series that is always at its high. Both bugs are now caught.

## Planted bugs, 99 of 99 caught

- **Claims (26), part K (12), part P (22):** listed in the earlier manifests. That code is unchanged.
- **Part T (39):**
  - **17 carried over from v1.3's 18, run on the v1.4 code** (the 18th, "verdict without the distance bins", is listed under v1.4):
    - translation: candle checked after volatility; market series not left out;
    - indicators: RSI smoothed like an EMA; Bollinger with the sample SD; range expansion against today's ATR; the 52-week high including today;
    - the move measured from the signal-day close;
    - the verdict: 5 closes ahead; counting the move's own close; one period enough;
    - the shown measure: equal weights for the days; counting the move close;
    - kinds and indicators: every pick on every trigger; MIXED picks pooled; pushes at or below 0 counted as own;
    - the gate at 90%; part P's hashes not checked.
  - **v1.4's 22:**
    - translation: the old day-of-week pattern; cross-sectional inputs counted as own daily;
    - indicators: ROC 65 from 64 bars back; ROC 20 from 21; the 13-week high including today; the 52-week low against the high; a crossing allowed anywhere; "within 5% of the 52-week high" firing where it could not;
    - the verdict:
      - ignoring where the trigger could fire;
      - pooling the closes;
      - no distance bins;
      - unmatched firings counted;
      - a one-sided p;
    - the many-tests check: none at all; the stronger period's p; opposite periods keeping their p; a 10% rate; MAY BE CHANCE dropped; FALLS TOO from one period;
    - the calendar: only D1 checked;
    - the ledger: a run under the replaced declaration not counted;
    - coverage: counting pushes at or below 0.

**Run time** for `triggers` on your PC is an estimate: a few minutes, mostly reading the bars. The same-close comparison has about 7 times as many cells as v1.3's, which adds some time to the bootstrap.
