"""
whylab.py - whylab v1.4: are Claude's 14 Nov claims about the model's picks true (run), what does D itself rely on
(model, part K), why was each pick picked (explain, part P; today), and what triggered each pick's move in its own
indicators (triggers, part T)? Each claim is checked on every pick of the
frozen engines (D and ENS, ranks 1-3 judged, ranks 1-10 shown), against every other stock of the same day, in 2020-23
and in 2024-26 separately. WHY_DECLARATION.json, WHY_K_DECLARATION.json, WHY_P_DECLARATION.json and
WHY_T_DECLARATION.json (all pinned below) fix every measure and every rule before any run; whylab refuses any other.

    python whylab.py check                                       the declarations are the pinned ones; the libraries
    python whylab.py run --root %CACHE_DAILY_ROOT% [--setups %SETUPLAB_OUT%] [--out <folder>] [--stage-e-any]
                         [--rerun-reason "<a verified bug>"]
                                                                 -> WHYLAB_OUT\\runs\\WHY_<date>_<nnn>
    python whylab.py model --root %CACHE_DAILY_ROOT% [--out <folder>] [--rerun-reason "<a verified bug>"]
                                                                 -> WHYLAB_OUT\\model\\K_<date>_<nnn>
    python whylab.py explain --root %CACHE_DAILY_ROOT% [--setups %SETUPLAB_OUT%] [--out <folder>]
                             [--rerun-reason "<a verified bug>"]  -> WHYLAB_OUT\\explain\\P_<date>_<nnn>
    python whylab.py triggers --root %CACHE_DAILY_ROOT% [--p-run <part P run>] [--out <folder>]
                              [--rerun-reason "<a verified bug>"]   -> WHYLAB_OUT\\triggers\\T_<date>_<nnn>
    python whylab.py today --root %CACHE_DAILY_ROOT% [--out <folder>] [--live <live panel.parquet>]
                                                                 -> WHYLAB_OUT\\today\\TODAY_<session>.md

PART K (model): D's 5 walk-forward folds rebuilt with production's own stage D code (stage_d_gate.CFG, make_label;
stage_b_screen._read_col; imported read only and checked against FROZEN_ENGINES.json), which must reproduce the
frozen preds.parquet before anything else; then each group of D's 205 inputs is scrambled in turn on the test days
and the same fitted models re-pick the top 3. D relies on a group when scrambling it costs money (95% interval below
0). Writes K_<date>_<nnn>\\ KREPORT.md, families.csv, inputs.csv, gate.csv, folds.csv, run.json, DECLARATION.json,
outputs.sha256 and a ledger line.

PART P (explain): part K's rebuild and gate, then every pick's score split into its inputs' pushes (shap 0.54.1,
interventional, against 100 other stocks of the same day) and summed by part K's groups; the biggest group is the
pick's reason, CONFIDENT when two bootstrap versions of the same fold agree, else MIXED; the reason re-checked at the
D1-D5 closes; then T1-T4 (WHY_P_DECLARATION.json). today: the same for the production D.pkl's picks on the newest
session of the live panel, and whether the held picks' reasons are still there. Research only.

PART T (triggers): part P's picks and their top inputs, each input translated to the readable indicator behind it
(EMA-20 slope, RSI-14, Bollinger, 52-week and 20-day range, 4/13-week momentum, volume, ATR, ADX/DI, MACD, candle);
that indicator's triggers followed on the stock's own daily bars from the signal day to D10 (the market's next 10
sessions); the move = the first close at or above the D1 open + 1 ATR. Kinds are never pooled; a trigger is measured
only on the picks of a kind whose own indicators include it. Shown: fired before the move, movers against non-movers on
the same days. Judged: the move within 3 closes after the trigger against closes where it could have fired but did
not, at the same close after the pick and the same distance from the target, in both periods, then Benjamini-Hochberg
over every test of the run (WHY_T_DECLARATION.json). A TRIGGER is a historical link to test as an entry, not a tested
entry.

THE CLAIMS (Claude, 14 Nov 20:14): 1 picks come after a hard fall; 2 picks are the most volatile stocks; 3 a simple
rule could do the model's job; 4 the gain is the model's choice, not only the type of stock; 5 the move is a rebound
(a bigger fall, a bigger gain); 6 it is fast; 7 it fades after D5; 8 it comes with a volume burst; 9 closing near the
20-day low warns of a further fall first; 10 news drives it (NOT TESTED: no announcement data).

READS (read only): setuplab's newest TREE run (every pick, its lane, ETF flag and D1 net; hash-checked through
tradelab's tl_setups), CACHE_DAILY_ROOT\\panel_oc\\panel.parquet (timestamp and symbol only: who could be picked each
day), every universe stock's daily bars through tradelab's tl_data (production's stage E loader), setuplab's TREE.json
(ETF names) and NSE's ETF list when present. WRITES only under --out / WHYLAB_OUT: WHY_<date>_<nnn>\\ REPORT.md,
claims.csv, profile.csv, path.csv, rules.csv, examples.csv, picks.parquet, run.json, DECLARATION.json,
outputs.sha256; one line per run in whylab_ledger.jsonl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import tl_common as TC
import tl_data as TD
import tl_setups as SU

VERSION = "whylab v1.4"
HERE = Path(__file__).resolve().parent
DECL_FILE = HERE / "WHY_DECLARATION.json"
DECL_SHA = "e3967dd85a42d063a71e20a260ee9659c6f12c36eb58b20172c4029e48d37442"
LEDGER = "whylab_ledger.jsonl"
SL_VERSION = "setuplab v1.1"
SL_NEEDS = ("Boot", "atr_simple", "load_tree", "tree_etf", "etf_list", "new_run_dir", "write_hashes", "bh_q")

COST = 0.35
P2_START = np.datetime64("2024-01-01", "D")
ENGINES = ("D", "ENS")
PERIODS = ("P1", "P2")
CELLS = tuple((e, p) for e in ENGINES for p in PERIODS)
PNAME = {"P1": "2020-23", "P2": "2024-26", "ALL": "2020-26"}
LANES = {"ALL": None, "CALM": ("CALM",), "JUMPY": ("JUMPY", "NO ATR")}
MEASURES = ("ret1", "ret5", "ret20", "ret60", "rsi7", "pos20", "lo52", "hi52", "atrp", "vol20", "vratio", "value20",
            "price", "sde3", "sde10")
MNAME = {"ret1": "signal-day return", "ret5": "5-day return", "ret20": "20-day return", "ret60": "60-day return",
         "rsi7": "RSI 7", "pos20": "position in the 20-day range", "lo52": "above the 52-week low",
         "hi52": "below the 52-week high", "atrp": "ATR % (14-day)", "vol20": "20-day volatility",
         "vratio": "signal-day volume vs 20-day average", "value20": "rupees traded a day (20-day median)",
         "price": "share price", "sde3": "SDE 3", "sde10": "SDE 10"}
PCT_MEASURES = ("ret1", "ret5", "ret20", "ret60", "lo52", "hi52", "atrp", "vol20")     # shown as % in the report
KMAX = 10
GATE_TOL = 1e-4
GATE_SHARE = 0.99
NN = 10
RSI_SKIP = 50
B, BLOCK, SEED = 2000, 10, 7
CLAIMS = {1: "Picks come after a hard fall", 2: "Picks are the most volatile stocks",
          3: "A simple rule could do the model's job",
          4: "The gain is the model's choice, not only the type of stock (fallen and volatile)",
          5: "The move is a rebound: a bigger fall before, a bigger gain after", 6: "The move is fast (by the D2 close)",
          7: "The move fades after D5", 8: "The move comes with a volume burst",
          9: "Closing near the 20-day low warns of a further fall first", 10: "News or results drive the move"}
RULES = {"R1": ("ret5 / atrp", "biggest 5-day fall in ATRs"), "R2": ("rsi7", "lowest RSI 7")}


class WHError(Exception):
    """A precondition failed: nothing is written (exit 2)."""


class GateFailed(Exception):
    """The reconciliation gate failed: the run stops before any claim is judged (exit 3)."""


def say(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def sha256(p) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load_decl(path: Path = DECL_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != DECL_SHA:
        raise WHError(f"{Path(path).name} has sha256 {sha[:16]}, not the pinned {DECL_SHA[:16]} - the declaration is "
                      f"fixed before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def libs():
    """setuplab (its Boot, ATR, tree file and ETF rule are used unchanged, so its version is checked)."""
    try:
        import setuplab as SL
    except ImportError as e:
        raise WHError(f"cannot import setuplab ({e}) - start with env_whylab.bat (it puts setuplab on PYTHONPATH)")
    miss = [n for n in SL_NEEDS if not hasattr(SL, n)]
    if miss or getattr(SL, "VERSION", "") != SL_VERSION:
        raise WHError(f"setuplab is {getattr(SL, 'VERSION', '?')} (missing {miss}); whylab uses {SL_VERSION}'s code")
    if not hasattr(SU, "sde_series") or not hasattr(SU, "load_tree"):
        raise WHError("tradelab's tl_setups lacks sde_series / load_tree - whylab needs tradelab with tl_setups v1.7")
    return SL


def out_base(arg: Optional[str], root: Optional[Path]) -> Path:
    v = arg or os.environ.get("WHYLAB_OUT")
    if not v:
        raise WHError("no output folder: pass --out or start with env_whylab.bat (sets WHYLAB_OUT)")
    b = Path(v).resolve()
    guards = ([Path(root).resolve()] if root else []) + [Path(os.environ[e]).resolve() for e in
                                                          ("CACHE_DAILY_ROOT", "BIGMOVE_DIR") if os.environ.get(e)]
    for g in guards:
        if b == g or g in b.parents:
            raise WHError(f"output folder {b} is inside {g}; whylab never writes there")
    b.mkdir(parents=True, exist_ok=True)
    return b


# ---------------------------------------------------------------------------------------------------- the inputs
def read_picks(base: Path) -> Tuple[pd.DataFrame, dict]:
    """Every pick of setuplab's newest tree run (hash-checked), engines D and ENS, ranks 1-10."""
    T, info = SU.load_tree(base, need=True)
    need = {"trade_id", "engine", "rank", "symbol", "signal_day", "lane", "etf", "d1_net", "complete"}
    miss = sorted(need - set(T.columns))
    if miss:
        raise WHError(f"the tree run {info['run']} lacks {miss} - it needs setuplab v1.1's tree command")
    P = T[list(need) + [c for c in ("s_atr14",) if c in T.columns]].copy()
    P["engine"] = P["engine"].astype(str)
    P["rank"] = pd.to_numeric(P["rank"], errors="coerce")
    P = P[P["engine"].isin(ENGINES) & P["rank"].between(1, 10)].copy()
    P["rank"] = P["rank"].astype(int)
    P["symbol"] = P["symbol"].astype(str).str.strip().str.upper()
    P["day"] = TC.to_day(P["signal_day"])
    P["etf"] = P["etf"].astype("boolean").fillna(False).astype(bool)
    P["complete"] = P["complete"].astype("boolean").fillna(False).astype(bool)
    P["d1_net"] = pd.to_numeric(P["d1_net"], errors="coerce").astype(float)
    P["lane"] = P["lane"].fillna("").astype(str)
    if P.duplicated(["engine", "day", "rank"]).any():
        raise WHError(f"the tree run {info['run']} holds two picks for the same engine, day and rank - refusing")
    P = P.sort_values(["day", "engine", "rank"]).reset_index(drop=True)
    return P, info


def read_universe(root: Path, days: np.ndarray, log=say) -> Tuple[pd.DataFrame, dict]:
    """(day, symbol) of every panel_oc row on the picks' signal days: who the engines could pick."""
    import pyarrow.parquet as pq
    pf = TD.PanelFeatures(root, "panel_oc")
    tbl = pq.read_table(pf.path, columns=[pf.tcol, "symbol"])
    d = TC.to_day(tbl.column(pf.tcol).to_pandas())
    s = tbl.column("symbol").to_pandas().astype(str).str.strip().str.upper().to_numpy()
    keep = np.isin(d, days)
    U = pd.DataFrame({"day": d[keep], "symbol": s[keep]}).drop_duplicates(["day", "symbol"])
    U = U.sort_values(["symbol", "day"]).reset_index(drop=True)
    log(f" universe: {len(U):,} stock-days on {U['day'].nunique():,} signal days, {U['symbol'].nunique():,} symbols "
        f"({pf.path})")
    return U, {"panel": str(pf.path), "panel_rows_read": int(len(d)), "stock_days": int(len(U)),
               "symbols": int(U["symbol"].nunique())}


# ---------------------------------------------------------------------------------------------------- one stock
def _roll(x: np.ndarray, w: int, how: str) -> np.ndarray:
    r = pd.Series(x).rolling(w, min_periods=w)
    return np.array(getattr(r, how)().to_numpy(float), dtype=float, copy=True)


def stock_arrays(SL, ds, cal: np.ndarray) -> Dict[str, np.ndarray]:
    """Every measure (known at bar t's close) and every outcome (from bar t+1's open), aligned with the stock's
    bars. Outcomes in %; blank when bar t+1 is not the calendar's next session or a bar is missing."""
    o, h, l, c = (np.asarray(x, float) for x in (ds.o, ds.h, ds.l, ds.c))
    v = np.asarray(ds.v, float) if ds.v is not None else np.full(len(c), np.nan)
    n = len(c)
    F: Dict[str, np.ndarray] = {}
    with np.errstate(divide="ignore", invalid="ignore"):
        for k in (1, 5, 20, 60):
            x = np.full(n, np.nan)
            if n > k:
                x[k:] = c[k:] / c[:-k] - 1
            F[f"ret{k}"] = x
        d = np.full(n, np.nan)
        d[1:] = np.diff(c)
        g = np.where(d > 0, d, 0.0)
        ls = np.where(d < 0, -d, 0.0)
        rsi = np.full(n, np.nan)
        if n > 1:
            ag = np.array(pd.Series(g[1:]).ewm(alpha=1 / 7, adjust=False).mean().to_numpy(float), copy=True)
            al = np.array(pd.Series(ls[1:]).ewm(alpha=1 / 7, adjust=False).mean().to_numpy(float), copy=True)
            rs = np.where(al > 0, 100 - 100 / (1 + ag / np.where(al > 0, al, 1.0)), np.where(ag > 0, 100.0, 50.0))
            rsi[1:] = rs
            rsi[~np.isfinite(d)] = np.nan
        rsi[:RSI_SKIP] = np.nan
        F["rsi7"] = rsi
        lo20, hi20 = _roll(l, 20, "min"), _roll(h, 20, "max")
        F["pos20"] = np.where(hi20 - lo20 > 0, (c - lo20) / (hi20 - lo20), np.nan)
        F["lo52"] = c / _roll(l, 252, "min") - 1
        F["hi52"] = c / _roll(h, 252, "max") - 1
        F["atrp"] = np.asarray(SL.atr_simple(h, l, c), float)
        r1 = np.full(n, np.nan)
        r1[1:] = c[1:] / c[:-1] - 1
        F["vol20"] = np.array(pd.Series(r1).rolling(20, min_periods=20).std(ddof=1).to_numpy(float), copy=True)
        vavg = np.full(n, np.nan)
        if n > 1:
            vavg[1:] = _roll(v, 20, "mean")[:-1]                  # t-20 .. t-1
        F["vratio"] = v / vavg
        F["value20"] = _roll(c * v, 20, "median")
        F["price"] = c.copy()
        F["sde3"] = np.asarray(SU.sde_series(c, 3), float)
        F["sde10"] = np.asarray(SU.sde_series(c, 10), float)
        for k_ in list(F):
            F[k_] = np.where(np.isfinite(F[k_]), F[k_], np.nan)
        # outcomes
        dates = np.asarray(ds.dates).astype("datetime64[D]")
        j = np.searchsorted(cal, dates, side="right")
        nxt = np.where(j < len(cal), cal[np.minimum(j, len(cal) - 1)], np.datetime64("NaT"))
        ok1 = np.zeros(n, bool)
        if n > 1:
            ok1[:-1] = dates[1:] == nxt[:-1]
        o1 = np.full(n, np.nan)
        o1[:-1] = o[1:]
        o1[~ok1 | ~(o1 > 0)] = np.nan

        def ahead(a, k):
            out = np.full(n, np.nan)
            if n > k:
                out[:-k] = a[k:]
            return out
        for k in range(1, KMAX + 1):
            F[f"r{k}"] = (ahead(c, k) / o1 - 1) * 100
        F["open6"] = (ahead(o, 6) / o1 - 1) * 100
        lmin = np.full(n, np.nan)
        if n > 5:
            lmin[:-5] = _roll(l, 5, "min")[5:]                     # lows of t+1 .. t+5
        F["dn8"] = np.where(np.isfinite(lmin) & np.isfinite(o1), (lmin / o1 - 1 <= -0.08).astype(float), np.nan)
        lv = [np.log(ahead(v, k) / vavg) for k in (1, 2, 3)]
        F["vb"] = np.where(ok1, np.mean(np.vstack(lv), axis=0), np.nan)
        for k_ in [f"r{k}" for k in range(1, KMAX + 1)] + ["open6", "vb"]:
            F[k_] = np.where(np.isfinite(F[k_]), F[k_], np.nan)
    return F


OUT_COLS = tuple([f"r{k}" for k in range(1, KMAX + 1)] + ["open6", "dn8", "vb"])


def assemble(SL, market, U: pd.DataFrame, log=say, chunk: int = 100) -> Tuple[pd.DataFrame, dict]:
    """The universe table: every (day, symbol) with its measures and outcomes from the stock's own bars."""
    n = len(U)
    cols = {k: np.full(n, np.nan, dtype=np.float32 if k in MEASURES else np.float64) for k in MEASURES + OUT_COLS}
    groups = U.groupby("symbol", sort=True).indices
    syms = list(groups)
    cal = np.asarray(market.cal).astype("datetime64[D]")
    days = U["day"].to_numpy().astype("datetime64[D]")
    no_bars, no_day, t0 = 0, 0, time.time()
    for c0 in range(0, len(syms), chunk):
        part = syms[c0:c0 + chunk]
        market.load(part)
        for sym in part:
            rows = groups[sym]
            ds = market.daily.get(sym)
            if ds is None or not len(ds.dates):
                no_bars += len(rows)
                continue
            dd = np.asarray(ds.dates).astype("datetime64[D]")
            pos = np.searchsorted(dd, days[rows])
            hit = (pos < len(dd)) & (dd[np.minimum(pos, len(dd) - 1)] == days[rows])
            no_day += int((~hit).sum())
            if hit.any():
                F = stock_arrays(SL, ds, cal)
                r, p_ = rows[hit], pos[hit]
                for k in cols:
                    cols[k][r] = F[k][p_]
            market.daily.pop(sym, None)
        log(f"   bars: {min(c0 + chunk, len(syms)):,} of {len(syms):,} symbols ({time.time() - t0:.0f}s)")
    T = U.copy()
    for k, a in cols.items():
        T[k] = a
    return T, {"no_bars_rows": int(no_bars), "no_bar_that_day_rows": int(no_day), "missing_symbols":
               sorted(set(market.missing))[:50], "missing_symbol_count": int(len(set(market.missing)))}


XK = tuple([f"r{k}" for k in range(1, KMAX + 1)] + ["open6"])


def day_frame(SL, T: pd.DataFrame, picks: pd.DataFrame, root: Path) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    """ETF flags, within-day percentiles, the pick flags; Ud = the universe's mean outcome u_k per signal day."""
    try:
        _, tdoc = SL.load_tree()
        listed = SL.etf_list(root)
    except ValueError as e:
        raise WHError(f"setuplab's ETF rule is not usable: {e}")
    T = T.sort_values(["day", "symbol"]).reset_index(drop=True)
    T["etf"] = SL.tree_etf(T["symbol"].to_numpy(), tdoc, listed)
    uni = ~T["etf"].to_numpy()
    g = T.loc[uni, ["day"] + list(MEASURES)].groupby("day")
    for m in MEASURES:
        pc = np.full(len(T), np.nan)
        pc[uni] = g[m].rank(pct=True).to_numpy(dtype=float)
        T[f"p_{m}"] = pc
    Ud = T.loc[uni, ["day"] + list(XK)].groupby("day")[list(XK)].mean()
    Ud.columns = [f"u_{k}" for k in XK]
    Ud = Ud.reset_index()
    T["x_r5"] = T["r5"].to_numpy(float) - T["day"].map(Ud.set_index("day")["u_r5"]).to_numpy(float)
    T["net5"] = T["r5"] - COST
    pk = set(zip(picks["day"].to_numpy().astype("datetime64[D]").tolist(), picks["symbol"].tolist()))
    T["picked"] = [(d, s) in pk for d, s in zip(T["day"].to_numpy().astype("datetime64[D]").tolist(), T["symbol"])]
    info = {"etf_rows": int((~uni).sum()), "nse_etf_list": listed is not None,
            "median_universe_per_day": float(T.loc[uni, "day"].value_counts().median()) if uni.any() else 0.0}
    return T, Ud, info


def controls(T: pd.DataFrame, log=say) -> pd.DataFrame:
    """For every picked stock-day: its NN nearest unpicked universe stocks of the same day in (ret5, atrp) percentile
    with an outcome - their mean r5, mean vb, how many and how far."""
    out = []
    uni = ~T["etf"].to_numpy()
    T2 = T.loc[uni, ["day", "symbol", "picked", "p_ret5", "p_atrp", "r5", "vb"]]
    for d, G in T2.groupby("day", sort=True):
        pm = G["picked"].to_numpy()
        if not pm.any():
            continue
        a = G[["p_ret5", "p_atrp"]].to_numpy(float)
        cand = (~pm) & np.isfinite(a).all(1) & np.isfinite(G["r5"].to_numpy(float))
        ci = np.flatnonzero(cand)
        r5 = G["r5"].to_numpy(float)[ci]
        vb = G["vb"].to_numpy(float)[ci]
        for q in np.flatnonzero(pm):
            rec = {"day": d, "symbol": G["symbol"].iat[q], "c_n": 0, "c_r5": np.nan, "c_vb": np.nan, "c_dist": np.nan}
            if np.isfinite(a[q]).all() and len(ci) >= NN:
                dist = np.sqrt(((a[ci] - a[q]) ** 2).sum(1))
                o = np.argsort(dist, kind="stable")[:NN]          # rows sorted by symbol: ties go to the symbol order
                rec.update(c_n=NN, c_r5=float(r5[o].mean()), c_dist=float(dist[o].mean()),
                           c_vb=float(np.nanmean(vb[o])) if np.isfinite(vb[o]).any() else np.nan)
            out.append(rec)
    C = pd.DataFrame(out, columns=["day", "symbol", "c_n", "c_r5", "c_vb", "c_dist"])
    log(f" controls: {int((C['c_n'] == NN).sum()):,} of {len(C):,} picked stock-days matched with {NN} stocks each")
    return C


def pick_table(P: pd.DataFrame, T: pd.DataFrame, Ud: pd.DataFrame, C: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """Every pick with its stock-day's measures, percentiles, outcomes, the day's u_k, its excess x_k, controls."""
    keep = ["day", "symbol"] + list(MEASURES) + [f"p_{m}" for m in MEASURES] + list(OUT_COLS) + ["net5"]
    Q = P.merge(T[keep], on=["day", "symbol"], how="left", indicator=True)
    info = {"picks": int(len(Q)), "not_in_panel": int((Q["_merge"] == "left_only").sum()),
            "not_in_panel_examples": Q.loc[Q["_merge"] == "left_only", ["engine", "day", "symbol"]].head(10)
            .astype(str).values.tolist()}
    Q = Q.drop(columns="_merge").merge(C, on=["day", "symbol"], how="left").merge(Ud, on="day", how="left")
    for k in XK:
        Q[f"x_{k}"] = Q[k].to_numpy(float) - Q[f"u_{k}"].to_numpy(float)
    Q["period"] = np.where(Q["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    return Q.reset_index(drop=True), info


def gate(Q: pd.DataFrame) -> dict:
    """net5 here vs the tree's d1_net on the complete non-ETF picks."""
    m = Q["complete"].to_numpy() & ~Q["etf"].to_numpy() & np.isfinite(Q["d1_net"].to_numpy(float))
    a, b = Q["net5"].to_numpy(float)[m], Q["d1_net"].to_numpy(float)[m]
    eq = np.isfinite(a) & (np.abs(a - b) <= GATE_TOL)
    share = float(eq.mean()) if m.any() else 0.0
    bad = Q.loc[m].loc[~eq, ["trade_id", "symbol", "day", "net5", "d1_net"]].head(10)
    return {"picks": int(m.sum()), "equal": int(eq.sum()), "share": share, "no_outcome_here": int((~np.isfinite(a)).sum()),
            "passed": bool(m.any() and share >= GATE_SHARE), "examples": bad.astype(str).values.tolist()}


# ---------------------------------------------------------------------------------------------------- statistics
class Stat:
    """Means and differences of means over rows with their 95% intervals: setuplab's Boot (circular blocks of 10
    signal days, 2,000 resamples, seed 7), the same draws for every number."""

    def __init__(self, SL, days: np.ndarray):
        self.boot = SL.Boot(np.unique(np.asarray(days).astype("datetime64[D]")), B=B, block=BLOCK, seed=SEED)
        self.nd = len(self.boot.days)

    def di(self, days) -> np.ndarray:
        return self.boot.index(np.asarray(days).astype("datetime64[D]"))

    def _res(self, di, vals, masks):
        cols = []
        for m in masks:
            cols += [np.bincount(di[m], weights=vals[m], minlength=self.nd),
                     np.bincount(di[m], minlength=self.nd).astype(float)]
        R = self.boot.M @ np.column_stack(cols)
        with np.errstate(invalid="ignore", divide="ignore"):
            return R[:, 0::2] / np.where(R[:, 1::2] > 0, R[:, 1::2], np.nan)

    def mean(self, di, vals, mask) -> dict:
        vals = np.asarray(vals, float)
        m = np.asarray(mask, bool) & np.isfinite(vals) & (di >= 0)
        out = {"n": int(m.sum()), "days": int(len(np.unique(di[m]))), "stat": np.nan, "lo": np.nan, "hi": np.nan}
        if m.sum() < 2:
            return out
        out["stat"] = float(vals[m].mean())
        R = self._res(di, vals, [m])[:, 0]
        if np.isfinite(R).sum() > 100:
            out["lo"], out["hi"] = float(np.nanpercentile(R, 2.5)), float(np.nanpercentile(R, 97.5))
        return out

    def diff(self, di, va, ma, vb, mb) -> dict:
        va, vb = np.asarray(va, float), np.asarray(vb, float)
        ma = np.asarray(ma, bool) & np.isfinite(va) & (di >= 0)
        mb = np.asarray(mb, bool) & np.isfinite(vb) & (di >= 0)
        out = {"n": int(ma.sum() + mb.sum()), "n_a": int(ma.sum()), "n_b": int(mb.sum()), "stat": np.nan,
               "lo": np.nan, "hi": np.nan, "a": np.nan, "b": np.nan}
        if ma.sum() < 2 or mb.sum() < 2:
            return out
        out["a"], out["b"] = float(va[ma].mean()), float(vb[mb].mean())
        out["stat"] = out["a"] - out["b"]
        v = np.where(ma, va, vb)
        R = self._res(di, np.nan_to_num(v), [ma, mb])
        d = R[:, 0] - R[:, 1]
        if np.isfinite(d).sum() > 100:
            out["lo"], out["hi"] = float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5))
        return out


def above(r: dict, x: float = 0.0) -> bool:
    return bool(np.isfinite(r.get("lo", np.nan)) and r["lo"] > x)


def below(r: dict, x: float = 0.0) -> bool:
    return bool(np.isfinite(r.get("hi", np.nan)) and r["hi"] < x)


def known(r: dict) -> bool:
    return bool(np.isfinite(r.get("lo", np.nan)) and np.isfinite(r.get("hi", np.nan)))


# ---------------------------------------------------------------------------------------------------- the claims
def mask_of(Q: pd.DataFrame, e: str, period: str, lane: str = "ALL", ranks: int = 3) -> np.ndarray:
    m = (Q["engine"].to_numpy() == e) & ~Q["etf"].to_numpy() & (Q["rank"].to_numpy() <= ranks)
    if LANES.get(lane):
        m &= np.isin(Q["lane"].to_numpy(), LANES[lane])
    if period in PERIODS:
        m &= Q["period"].to_numpy() == period
    return m


def thirds(vals: np.ndarray, m: np.ndarray, other: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Low / high thirds of vals inside m (cut at m's own 1/3 and 2/3 quantiles), where other is also finite."""
    ok = m & np.isfinite(vals) & np.isfinite(other)
    if ok.sum() < 6:
        z = np.zeros(len(vals), bool)
        return z, z
    q1, q2 = np.quantile(vals[ok], [1 / 3, 2 / 3])
    return ok & (vals <= q1), ok & (vals > q2)


def claim_cells(S: Stat, Q: pd.DataFrame, lane: str = "ALL", ranks: int = 3) -> Dict[int, dict]:
    """Claims 1, 2, 4-9 in the four cells (and the whole period, reported) for one lane and rank band."""
    di = S.di(Q["day"])
    g = lambda c: Q[c].to_numpy(float)                                           # noqa: E731
    pr5, patr = g("p_ret5"), g("p_atrp")
    r5, x2, x5, x10, xo6 = g("r5"), g("x_r2"), g("x_r5"), g("x_r10"), g("x_open6")
    u5, cr5, vb, cvb = g("u_r5"), g("c_r5"), g("vb"), g("c_vb")
    dn8 = g("dn8") * 100
    out: Dict[int, dict] = {k: {} for k in (1, 2, 4, 5, 6, 7, 8, 9)}
    for e in ENGINES:
        for p in PERIODS + ("ALL",):
            m = mask_of(Q, e, p, lane, ranks)
            key = (e, p)
            # 1 hard fall
            sh = {nm: S.mean(di, np.where(np.isfinite(g(f"p_{nm}")), (g(f"p_{nm}") <= 0.2) * 100.0, np.nan), m)
                  for nm in ("ret5", "rsi7", "pos20", "ret20", "ret60")}
            r = dict(sh["ret5"])
            r["cell"] = "MOST" if above(r, 50) else ("MORE THAN CHANCE" if above(r, 20) else "NO")
            r["beside"] = {nm: sh[nm] for nm in ("rsi7", "pos20", "ret20", "ret60")}
            out[1][key] = r
            # 2 volatile
            r = S.mean(di, np.where(np.isfinite(patr), (patr > 0.8) * 100.0, np.nan), m)
            r["cell"] = "MOST" if above(r, 50) else ("MORE THAN CHANCE" if above(r, 20) else "NO")
            out[2][key] = r
            # 4 model vs type
            r = S.mean(di, r5 - cr5, m)
            t = S.mean(di, cr5 - u5, m & np.isfinite(r5 - cr5))
            r["type"] = t
            r["pick_excess"] = S.mean(di, r5 - u5, m & np.isfinite(r5 - cr5))
            r["cell"] = ("MODEL ADDS" if above(r) else "MODEL WORSE" if below(r) else
                         "TYPE EXPLAINS" if (known(r) and above(t)) else "NEITHER")
            out[4][key] = r
            # 5 rebound
            lo_, hi_ = thirds(pr5, m, x5)
            r = S.diff(di, x5, lo_, x5, hi_)
            r["cell"] = "REBOUND" if above(r) else ("MOMENTUM" if below(r) else "NONE")
            out[5][key] = r
            # 6 fast
            a = S.mean(di, x2, m & np.isfinite(x5))
            b = S.mean(di, x5 - x2, m)
            r = {"n": a["n"], "x2": a, "x2_5": b, "stat": a["stat"], "lo": a["lo"], "hi": a["hi"]}
            r["cell"] = "BUILDS TO D5" if above(b) else ("FAST" if above(a) and known(b) else "NONE")
            out[6][key] = r
            # 7 fade
            r = S.mean(di, x10 - x5, m)
            r["open6"] = S.mean(di, xo6 - x5, m)
            r["cell"] = "FADES" if below(r) else ("KEEPS GOING" if above(r) else "FLAT")
            out[7][key] = r
            # 8 volume
            a = S.mean(di, vb, m)
            b = S.mean(di, vb - cvb, m)
            r = {"n": a["n"], "vb": a, "vs_similar": b, "stat": b["stat"], "lo": b["lo"], "hi": b["hi"]}
            r["cell"] = "BURST" if (above(a) and above(b)) else ("HIGH BUT NOT SPECIAL" if above(a) else "NONE")
            out[8][key] = r
            # 9 faller warning
            res = {}
            for nm in ("pos20", "rsi7", "sde3"):
                lo_, hi_ = thirds(g(nm), m, dn8)
                res[nm] = S.diff(di, dn8, lo_, dn8, hi_)
            r = dict(res["pos20"])
            r["beside"] = {"rsi7": res["rsi7"], "sde3": res["sde3"]}
            r["cell"] = "HOLDS" if above(r) else ("REVERSED" if below(r) else "NONE")
            out[9][key] = r
    return out


def verdict(cid: int, cells: Dict[tuple, dict]) -> str:
    c = [cells[k]["cell"] for k in CELLS if k in cells]
    if len(c) < 4:
        return "TOO FEW PICKS"
    alls = lambda x: all(v == x for v in c)                                   # noqa: E731
    if cid in (1, 2):
        return "TRUE" if alls("MOST") else ("PARTLY" if all(v in ("MOST", "MORE THAN CHANCE") for v in c) else "FALSE")
    if cid == 4:
        return c[0] if alls(c[0]) else "MIXED"
    if cid == 5:
        return "TRUE" if alls("REBOUND") else ("MOMENTUM" if alls("MOMENTUM") else "NOT RELIABLE")
    if cid == 6:
        return "TRUE" if alls("FAST") else ("BUILDS TO D5" if alls("BUILDS TO D5") else "MIXED")
    if cid == 7:
        return "TRUE" if alls("FADES") else ("KEEPS GOING" if alls("KEEPS GOING") else "NOT RELIABLE")
    if cid == 8:
        return "TRUE" if alls("BURST") else "NOT SHOWN"
    if cid == 9:
        return "TRUE" if alls("HOLDS") else "NOT RELIABLE"
    raise ValueError(cid)


def rules_daily(T: pd.DataFrame, Q: pd.DataFrame) -> pd.DataFrame:
    """Per signal day: each engine's ranks 1-3 mean net5, each rule's 3, everything; overlap; liquidity."""
    uni = T.loc[~T["etf"].to_numpy(), ["day", "symbol", "ret5", "atrp", "rsi7", "net5", "value20"]].copy()
    uni["R1"] = uni["ret5"].astype(float) / uni["atrp"].astype(float)
    uni["R2"] = uni["rsi7"].astype(float)
    rows = []
    mod = Q[~Q["etf"].to_numpy() & (Q["rank"].to_numpy() <= 3)]
    mod_by = {k: G for k, G in mod.groupby(["day", "engine"])}
    for d, G in uni.groupby("day", sort=True):
        rec = {"day": d, "all": float(np.nanmean(G["net5"])) if np.isfinite(G["net5"]).any() else np.nan,
               "n_universe": int(len(G))}
        sym = G["symbol"].to_numpy()
        for rk in RULES:
            sc = G[rk].to_numpy(float)
            ok = np.flatnonzero(np.isfinite(sc))
            o = ok[np.lexsort((sym[ok], sc[ok]))]
            top3, top10 = o[:3], set(sym[o[:10]])
            nv = G["net5"].to_numpy(float)[top3]
            rec[rk] = float(np.nanmean(nv)) if np.isfinite(nv).any() else np.nan
            rec[f"{rk}_value20"] = float(np.nanmedian(G["value20"].to_numpy(float)[top3])) if len(top3) else np.nan
            for e in ENGINES:
                M = mod_by.get((d, e))
                rec[f"{e}_in_{rk}_top10"] = float(np.mean([s in top10 for s in M["symbol"]])) if M is not None and \
                    len(M) else np.nan
        for e in ENGINES:
            M = mod_by.get((d, e))
            nv = M["net5"].to_numpy(float) if M is not None else np.array([])
            rec[e] = float(np.nanmean(nv)) if np.isfinite(nv).any() else np.nan
            rec[f"{e}_value20"] = float(np.nanmedian(M["value20"].to_numpy(float))) if M is not None and len(M) \
                else np.nan
        rows.append(rec)
    R = pd.DataFrame(rows)
    R["period"] = np.where(R["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    return R


def claim3(S: Stat, R: pd.DataFrame) -> Dict[str, dict]:
    di = S.di(R["day"])
    out: Dict[str, dict] = {}
    for rk in RULES:
        cells = {}
        for e in ENGINES:
            for p in PERIODS + ("ALL",):
                m = np.ones(len(R), bool) if p == "ALL" else (R["period"].to_numpy() == p)
                mv, rv, av = R[e].to_numpy(float), R[rk].to_numpy(float), R["all"].to_numpy(float)
                both = m & np.isfinite(mv) & np.isfinite(rv)
                d_mr = S.mean(di, mv - rv, both)
                d_re = S.mean(di, rv - av, m & np.isfinite(rv) & np.isfinite(av))
                r = {"model": S.mean(di, mv, both), "rule": S.mean(di, rv, both), "everything": S.mean(di, av, both),
                     "model_minus_rule": d_mr, "rule_minus_everything": d_re,
                     "overlap": float(np.nanmean(R.loc[m, f"{e}_in_{rk}_top10"])) if m.any() else np.nan,
                     "model_value20": float(np.nanmedian(R.loc[m, f"{e}_value20"])) if m.any() else np.nan,
                     "rule_value20": float(np.nanmedian(R.loc[m, f"{rk}_value20"])) if m.any() else np.nan}
                r.update({k: d_mr[k] for k in ("n", "stat", "lo", "hi")})
                r["cell"] = ("MODEL BETTER" if above(d_mr) else "RULE BETTER" if below(d_mr) else
                             "AS GOOD" if (known(d_mr) and above(d_re)) else "RULE HAS NO EDGE")
                cells[(e, p)] = r
        c = [cells[k]["cell"] for k in CELLS]
        v = ("MATCHES THE MODEL" if all(x in ("AS GOOD", "RULE BETTER") for x in c) else
             "MODEL BETTER" if all(x == "MODEL BETTER" for x in c) else "MIXED")
        out[rk] = {"cells": cells, "verdict": v}
    return out


def universe_rebound(S: Stat, T: pd.DataFrame) -> Dict[str, dict]:
    """Claim 5's difference for every universe stock: per day, the mean x5 of the day's lowest third by ret5 minus
    the highest third, averaged over days."""
    U = T.loc[~T["etf"].to_numpy() & np.isfinite(T["x_r5"].to_numpy(float)) & np.isfinite(T["p_ret5"].to_numpy(float)),
              ["day", "p_ret5", "x_r5"]]
    p = U["p_ret5"].to_numpy(float)
    D = pd.DataFrame({"day": U["day"].to_numpy(), "lo": np.where(p <= 1 / 3, U["x_r5"], np.nan),
                      "hi": np.where(p > 2 / 3, U["x_r5"], np.nan)}).groupby("day").mean()
    D["d"] = D["lo"] - D["hi"]
    D = D.reset_index()
    di = S.di(D["day"])
    per = np.where(D["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    return {p_: S.mean(di, D["d"].to_numpy(float), (per == p_) if p_ != "ALL" else np.ones(len(D), bool))
            for p_ in PERIODS + ("ALL",)}


def profile(S: Stat, Q: pd.DataFrame, T: pd.DataFrame) -> pd.DataFrame:
    di = S.di(Q["day"])
    uni = T.loc[~T["etf"].to_numpy(), ["day"] + list(MEASURES)]
    rows = []
    for e in ENGINES:
        for lane in LANES:
            for p in ("ALL",) + PERIODS:
                m = mask_of(Q, e, p, lane, 3)
                days = np.unique(Q.loc[m, "day"].to_numpy())
                um = uni["day"].isin(days).to_numpy()
                for nm in MEASURES:
                    pc = Q[f"p_{nm}"].to_numpy(float)
                    r = S.mean(di, pc, m)
                    lo20 = S.mean(di, np.where(np.isfinite(pc), (pc <= 0.2) * 100.0, np.nan), m)
                    hi20 = S.mean(di, np.where(np.isfinite(pc), (pc > 0.8) * 100.0, np.nan), m)
                    rows.append({"engine": e, "lane": lane, "period": p, "measure": nm, "n": r["n"],
                                 "mean_pct": r["stat"], "lo": r["lo"], "hi": r["hi"], "bottom20_pct": lo20["stat"],
                                 "bottom20_lo": lo20["lo"], "bottom20_hi": lo20["hi"], "top20_pct": hi20["stat"],
                                 "top20_lo": hi20["lo"], "top20_hi": hi20["hi"],
                                 "picks_median": float(np.nanmedian(Q.loc[m, nm])) if m.any() else np.nan,
                                 "universe_median": float(np.nanmedian(uni.loc[um, nm])) if um.any() else np.nan})
    return pd.DataFrame(rows)


def path_table(S: Stat, Q: pd.DataFrame) -> pd.DataFrame:
    di = S.di(Q["day"])
    rows = []
    for e in ENGINES:
        for lane in LANES:
            for p in ("ALL",) + PERIODS:
                m = mask_of(Q, e, p, lane, 3)
                for k in [f"r{k}" for k in range(1, KMAX + 1)] + ["open6"]:
                    x = S.mean(di, Q[f"x_{k}"].to_numpy(float), m)
                    rows.append({"engine": e, "lane": lane, "period": p, "point": k, "n": x["n"],
                                 "excess": x["stat"], "lo": x["lo"], "hi": x["hi"],
                                 "pick_raw": float(np.nanmean(Q.loc[m, k])) if m.any() else np.nan,
                                 "market": float(np.nanmean(Q.loc[m, f"u_{k}"])) if m.any() else np.nan})
    return pd.DataFrame(rows)


def examples(Q: pd.DataFrame) -> pd.DataFrame:
    need = list(MEASURES) + [f"r{k}" for k in range(1, KMAX + 1)] + ["dn8", "vb"]
    ok = (~Q["etf"].to_numpy()) & (Q["rank"].to_numpy() <= 3) & Q[need].notna().all(axis=1).to_numpy()
    rng = np.random.default_rng(SEED)
    parts = []
    for e in ENGINES:
        for lane in ("CALM", "JUMPY"):
            G = Q[ok & (Q["engine"].to_numpy() == e) & np.isin(Q["lane"].to_numpy(), LANES[lane])]
            G = G.sort_values("trade_id")
            if len(G):
                parts.append(G.iloc[np.sort(rng.choice(len(G), min(3, len(G)), replace=False))].assign(group=f"{e} {lane}"))
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()


# ---------------------------------------------------------------------------------------------------- the report
def _f(x, nd=2, sign=True) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


def _ci(r: dict, nd=2, sign=True) -> str:
    if not known(r):
        return "[-]"
    return f"[{_f(r['lo'], nd, sign)}, {_f(r['hi'], nd, sign)}]"


def _s(r: dict, nd=2, sign=True, unit="") -> str:
    return f"{_f(r.get('stat', np.nan), nd, sign)}{unit} {_ci(r, nd, sign)}"


SHORT = {1: "share of picks in the day's bottom 20% by 5-day return (chance 20%)",
         2: "share of picks in the day's top 20% by ATR % (chance 20%)",
         4: "pick's D1-open-to-D5-close return minus its 10 look-alike unpicked stocks' (points)",
         5: "own move D1 open to D5 close, most-fallen third of picks minus least-fallen third (points)",
         6: "own move D1 open to D2 close / D2 close to D5 close (points)",
         7: "own move D5 close to D10 close (points)",
         8: "D1-D3 volume vs its own 20-day average (log) / vs look-alike stocks (log)",
         9: "share hitting -8% under the D1 open by D5: third closest to the 20-day low minus the farthest (points)"}


def cell_text(cid: int, r: dict) -> str:
    if cid in (1, 2):
        return f"{_f(r['stat'], 1, False)}% {_ci(r, 1, False)}"
    if cid == 6:
        return f"{_s(r['x2'])} / {_s(r['x2_5'])}"
    if cid == 8:
        return f"{_s(r['vb'], 3)} / {_s(r['vs_similar'], 3)}"
    return _s(r)


def md_cells(cid: int, cells: Dict[tuple, dict]) -> List[str]:
    L = ["| engine | 2020-23 | 2024-26 | 2020-26 (shown, not judged) |", "|---|---|---|---|"]
    for e in ENGINES:
        row = [f"| {e} "]
        for p in PERIODS + ("ALL",):
            r = cells.get((e, p))
            row.append(f"| {cell_text(cid, r)}{' **' + r['cell'] + '**' if p != 'ALL' else ''} " if r else "| - ")
        L.append("".join(row) + "|")
    return L


def claim3_md(L3: dict) -> List[str]:
    L = ["## 3. " + CLAIMS[3], "",
         "Per signal day: the mean net (buy the D1 open, sell the D5 close, 0.35 points) of the engine's ranks 1-3 "
         "vs each rule's 3 stocks from the same universe, paired by day (points per trade).", ""]
    for rk in RULES:
        L += [f"**{rk} - {RULES[rk][1]}: {L3[rk]['verdict']}**", "",
              "| engine | period | model | rule | everything | model - rule | rule - everything | model picks in "
              "rule's top 10 | rupees/day traded (model / rule) | cell |", "|---|---|---|---|---|---|---|---|---|---|"]
        for e in ENGINES:
            for p in PERIODS + ("ALL",):
                r = L3[rk]["cells"][(e, p)]
                L.append(f"| {e} | {PNAME[p]} | {_f(r['model']['stat'])} | {_f(r['rule']['stat'])} | "
                         f"{_f(r['everything']['stat'])} | {_s(r['model_minus_rule'])} | "
                         f"{_s(r['rule_minus_everything'])} | {_f(100 * r['overlap'], 1, False)}% | "
                         f"{_money(r['model_value20'])} / {_money(r['rule_value20'])} | "
                         f"{r['cell'] if p != 'ALL' else '-'} |")
        L.append("")
    return L


def report(res: dict, decl: dict, sha: str, info: dict, secs: float) -> str:
    V, L3 = res["verdicts"], res["claim3"]
    L = [f"# whylab - are the 14 Nov claims about the model's picks true? ({info['run']})", "",
         f"{VERSION} | declaration {sha[:16]} (fixed {decl['declared_at']}) | tree run {info['tree']['run']} | "
         f"{info['picks_judged']:,} ranks 1-3 picks of D and ENS, ETFs out | {secs:.0f} s", "",
         "Each claim is judged in four cells - D and ENS, each in 2020-23 and in 2024-26 - with 95% intervals "
         "(blocks of 10 signal days). **TRUE needs all four.** The pick's own move = its return from the D1 open minus "
         "the average stock's return over the same days.", "",
         "## Verdicts", "", "| # | claim | verdict | calm picks | jumpy picks |", "|---|---|---|---|---|"]
    for cid in range(1, 11):
        if cid == 3:
            v = "; ".join(f"{rk} ({RULES[rk][1]}): **{L3[rk]['verdict']}**" for rk in RULES)
            L.append(f"| 3 | {CLAIMS[3]} | {v} | - | - |")
        elif cid == 10:
            L.append(f"| 10 | {CLAIMS[10]} | **NOT TESTED** - no announcement data in the pipeline | - | - |")
        else:
            L.append(f"| {cid} | {CLAIMS[cid]} | **{V['ALL'][cid]}** | {V['CALM'][cid]} | {V['JUMPY'][cid]} |")
    L += ["", "Calm and jumpy use the tree's lanes (from 2021; their 2020-23 cell is 2021-23).", ""]
    for cid in (1, 2, 3, 4, 5, 6, 7, 8, 9):
        if cid == 3:
            L += claim3_md(L3)
            continue
        L += [f"## {cid}. {CLAIMS[cid]} - **{V['ALL'][cid]}**", "", f"Measured: {SHORT[cid]}.", ""]
        L += md_cells(cid, res["cells"]["ALL"][cid])
        L.append("")
        if cid == 1:
            L.append("Beside it (bottom-20% shares, D / ENS, 2020-26): " + "; ".join(
                f"{MNAME[nm]} {_f(res['cells']['ALL'][1][('D', 'ALL')]['beside'][nm]['stat'], 1, False)}% / "
                f"{_f(res['cells']['ALL'][1][('ENS', 'ALL')]['beside'][nm]['stat'], 1, False)}%"
                for nm in ("rsi7", "pos20", "ret20", "ret60")) + ".")
        if cid == 4:
            for e in ENGINES:
                r = res["cells"]["ALL"][4][(e, "ALL")]
                L.append(f"- {e} 2020-26: the pick's own move {_s(r['pick_excess'])} = the look-alikes' own move "
                         f"{_s(r['type'])} + the model's choice {_s(r)} (points).")
        if cid == 5:
            u = res["universe_rebound"]
            L.append(f"Every stock, not only picks (the same thirds within each day): 2020-23 {_s(u['P1'])}, 2024-26 "
                     f"{_s(u['P2'])} points.")
        if cid == 7:
            L.append("D5 close to the D6 open (own move): " + "; ".join(
                f"{e} {_s(res['cells']['ALL'][7][(e, 'ALL')]['open6'])}" for e in ENGINES) + ".")
        if cid == 9:
            L.append("Beside it, the same with RSI 7 / SDE 3 in place of the 20-day position (2020-26): " + "; ".join(
                f"{e} {_s(res['cells']['ALL'][9][(e, 'ALL')]['beside']['rsi7'])} / "
                f"{_s(res['cells']['ALL'][9][(e, 'ALL')]['beside']['sde3'])}" for e in ENGINES) + ".")
        for lane in ("CALM", "JUMPY"):
            c = res["cells"][lane][cid]
            L.append(f"- {lane.lower()} picks: " + "; ".join(
                f"{e} {PNAME[p]} {cell_text(cid, c[(e, p)])} {c[(e, p)]['cell']}" for e, p in CELLS) +
                f" -> {V[lane][cid]}")
        L.append("")
    L += ["## What the picks look like on the signal day (ranks 1-3, 2020-26)", "",
          "Average percentile among the day's stocks (0.50 = typical; low = the bottom of the day), with the picks' "
          "and the universe's medians.", "",
          "| measure | D percentile | ENS percentile | D median | ENS median | universe median |", "|---|---|---|---|---|---|"]
    Pf = res["profile"]
    for nm in MEASURES:
        a = Pf[(Pf.engine == "D") & (Pf.lane == "ALL") & (Pf.period == "ALL") & (Pf.measure == nm)].iloc[0]
        b = Pf[(Pf.engine == "ENS") & (Pf.lane == "ALL") & (Pf.period == "ALL") & (Pf.measure == nm)].iloc[0]
        L.append(f"| {MNAME[nm]} | {a.mean_pct:.2f} [{a.lo:.2f}, {a.hi:.2f}] | {b.mean_pct:.2f} [{b.lo:.2f}, "
                 f"{b.hi:.2f}] | {_val(nm, a.picks_median)} | {_val(nm, b.picks_median)} | "
                 f"{_val(nm, a.universe_median)} |")
    L += ["", "Calm and jumpy picks separately: profile.csv.", "",
          "## The path after the pick (own move, ranks 1-3, 2020-26)", "",
          "| engine | " + " | ".join(f"D{k} close" for k in range(1, KMAX + 1)) + " | D6 open |",
          "|---|" + "---|" * (KMAX + 1)]
    Pt = res["path"]
    for e in ENGINES:
        X = Pt[(Pt.engine == e) & (Pt.lane == "ALL") & (Pt.period == "ALL")].set_index("point")
        L.append(f"| {e} | " + " | ".join(_f(X.loc[f'r{k}', 'excess']) for k in range(1, KMAX + 1)) +
                 f" | {_f(X.loc['open6', 'excess'])} |")
    L += ["", "Points from the D1 open, after taking out the average stock's move; intervals and calm / jumpy in "
          "path.csv.", "", "## 12 examples, drawn at random (seed 7), not chosen", "",
          "| group | stock | signal day | rank | 5-day return | RSI 7 | 20-day position | ATR % | D1 | D2 | D3 | D5 "
          "| D10 | hit -8% | D1-D3 volume |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in res["examples"].iterrows():
        L.append(f"| {r.group} | {r.symbol} | {pd.Timestamp(r.day).date()} | {int(r['rank'])} | {100 * r.ret5:+.1f}% "
                 f"(pct {r.p_ret5:.2f}) | {r.rsi7:.0f} | {r.pos20:.2f} | {100 * r.atrp:.1f}% | {r.r1:+.1f}% | "
                 f"{r.r2:+.1f}% | {r.r3:+.1f}% | {r.r5:+.1f}% | {r.r10:+.1f}% | {'yes' if r.dn8 > 0.5 else 'no'} "
                 f"| {np.exp(r.vb):.1f}x |")
    L += ["", "Returns D1..D10 are from the D1 open (raw, not own move).", "", "## Data checks", ""]
    g_ = info["gate"]
    L += [f"- Gate: net here = the tree's D1 net on {g_['equal']:,} of {g_['picks']:,} complete picks "
          f"({100 * g_['share']:.2f}%, needs 99%) - **{'PASSED' if g_['passed'] else 'FAILED'}**; no outcome here: "
          f"{g_['no_outcome_here']}.",
          f"- Universe: {info['universe']['stock_days']:,} stock-days, {info['universe']['symbols']:,} symbols "
          f"(median {info['days']['median_universe_per_day']:.0f} stocks a day after {info['days']['etf_rows']:,} "
          f"ETF rows); NSE's ETF list {'used' if info['days']['nse_etf_list'] else 'not found (name rule only)'}.",
          f"- Bars: {info['bars']['no_bars_rows']:,} stock-days without bars, {info['bars']['no_bar_that_day_rows']:,} "
          f"without a bar on the day; {info['bars']['missing_symbol_count']} symbols missing from the cache.",
          f"- Picks: {info['picks']['picks']:,} (ranks 1-10, both engines); not in the panel that day: "
          f"{info['picks']['not_in_panel']}.",
          f"- Look-alike controls: {info['controls_matched']:,} of {info['controls_total']:,} picked stock-days "
          f"matched (10 stocks each), mean distance {info['controls_dist']:.3f} in percentile units.",
          "", "## Not tested", "", "- Claim 10 (news, results): the pipeline has no company-announcement data. Nothing "
          "here stands in for it.", "- What D itself leans on (part K): needs D's own training code; see the "
          "declaration's model_part.", ""]
    return "\n".join(L) + "\n"


def _money(x) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    return f"Rs {x / 1e7:.2f} cr"


def _val(nm: str, x) -> str:
    if x is None or not np.isfinite(x):
        return "-"
    if nm in PCT_MEASURES:
        return f"{100 * x:+.1f}%" if nm not in ("atrp", "vol20") else f"{100 * x:.1f}%"
    if nm == "value20":
        return _money(x)
    if nm == "price":
        return f"Rs {x:,.0f}"
    return f"{x:.2f}"


# ---------------------------------------------------------------------------------------------------- the run
def flat_rows(res: dict) -> pd.DataFrame:
    rows = []
    for lane, C in res["cells"].items():
        for cid, cells in C.items():
            for (e, p), r in cells.items():
                rows.append({"claim": cid, "lane": lane, "ranks": "1-3", "engine": e, "period": PNAME[p],
                             "n": r.get("n"), "stat": r.get("stat"), "lo": r.get("lo"), "hi": r.get("hi"),
                             "cell": r.get("cell") if p != "ALL" else "", "verdict": res["verdicts"][lane][cid]})
    for cid, cells in res["cells_r10"].items():
        for (e, p), r in cells.items():
            rows.append({"claim": cid, "lane": "ALL", "ranks": "1-10", "engine": e, "period": PNAME[p],
                         "n": r.get("n"), "stat": r.get("stat"), "lo": r.get("lo"), "hi": r.get("hi"),
                         "cell": r.get("cell") if p != "ALL" else "", "verdict": "(shown, not judged)"})
    for rk, v in res["claim3"].items():
        for (e, p), r in v["cells"].items():
            rows.append({"claim": f"3 {rk}", "lane": "ALL", "ranks": "1-3", "engine": e, "period": PNAME[p],
                         "n": r.get("n"), "stat": r.get("stat"), "lo": r.get("lo"), "hi": r.get("hi"),
                         "cell": r.get("cell") if p != "ALL" else "", "verdict": v["verdict"]})
    return pd.DataFrame(rows)


def rules_rows(res: dict) -> pd.DataFrame:
    rows = []
    for rk, v in res["claim3"].items():
        for (e, p), r in v["cells"].items():
            rows.append({"rule": rk, "engine": e, "period": PNAME[p], "days": r["n"], "model": r["model"]["stat"],
                         "rule_net": r["rule"]["stat"], "everything": r["everything"]["stat"],
                         "model_minus_rule": r["model_minus_rule"]["stat"], "mr_lo": r["model_minus_rule"]["lo"],
                         "mr_hi": r["model_minus_rule"]["hi"], "rule_minus_everything":
                         r["rule_minus_everything"]["stat"], "re_lo": r["rule_minus_everything"]["lo"],
                         "re_hi": r["rule_minus_everything"]["hi"], "overlap_top10": r["overlap"],
                         "model_value20": r["model_value20"], "rule_value20": r["rule_value20"], "cell": r["cell"],
                         "verdict": v["verdict"]})
    return pd.DataFrame(rows)


def ledger_runs(bout: Path, sha: str) -> List[dict]:
    p = bout / LEDGER
    if not p.is_file():
        return []
    out = []
    for ln in p.read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(ln)
        except json.JSONDecodeError:
            continue
        if r.get("declaration_sha256") == sha and r.get("event") == "run":
            out.append(r)
    return out


def new_run_dir(SL, base: Path) -> Path:
    return SL.new_run_dir(base / "runs", "WHY")


def analyse(SL, P: pd.DataFrame, T: pd.DataFrame, root: Path, log=say) -> Tuple[dict, dict, pd.DataFrame]:
    """Everything after the bars: the day frame, controls, the gate, the claims."""
    T, Ud, dinfo = day_frame(SL, T, P, root)
    C = controls(T, log)
    Q, pinfo = pick_table(P, T, Ud, C)
    g_ = gate(Q)
    info = {"days": dinfo, "picks": pinfo, "gate": g_, "controls_total": int(len(C)),
            "controls_matched": int((C["c_n"] == NN).sum()),
            "controls_dist": float(np.nanmean(C["c_dist"])) if len(C) else np.nan}
    log(f" gate: {g_['equal']:,} of {g_['picks']:,} picks give the tree's D1 net ({100 * g_['share']:.2f}%)")
    if not g_["passed"]:
        raise GateFailed(f"only {100 * g_['share']:.2f}% of {g_['picks']:,} picks give the tree's D1 net (needs 99%) "
                         f"- bars or dates misaligned; e.g. {g_['examples'][:3]}")
    S = Stat(SL, P["day"].to_numpy())
    cells = {lane: claim_cells(S, Q, lane, 3) for lane in LANES}
    res = {"cells": cells, "cells_r10": claim_cells(S, Q, "ALL", 10)}
    res["verdicts"] = {lane: {cid: verdict(cid, c) for cid, c in cells[lane].items()} for lane in LANES}
    R = rules_daily(T, Q)
    res["claim3"] = claim3(S, R)
    res["universe_rebound"] = universe_rebound(S, T)
    res["profile"] = profile(S, Q, T)
    res["path"] = path_table(S, Q)
    res["examples"] = examples(Q)
    res["rules_daily"] = R
    info["picks_judged"] = int((~Q["etf"] & (Q["rank"] <= 3)).sum())
    return res, info, Q


def execute(SL, decl: dict, sha: str, root: Path, base: Path, bout: Path, stage_e_any: bool = False,
            rerun_reason: Optional[str] = None, log=say) -> Path:
    t0 = time.time()
    prev = ledger_runs(bout, sha)
    if prev and not rerun_reason:
        raise WHError(f"this declaration already ran ({prev[-1].get('run')}); a second run needs --rerun-reason "
                      f"\"<a verified bug>\" (recorded in the ledger)")
    P, tinfo = read_picks(base)
    log(f"{VERSION}: tree run {tinfo['run']} - {len(P):,} picks of D and ENS, ranks 1-10, "
        f"{pd.Timestamp(P['day'].min()).date()} .. {pd.Timestamp(P['day'].max()).date()}")
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    days = np.unique(P["day"].to_numpy().astype("datetime64[D]"))
    U, uinfo = read_universe(root, days, log)
    missing_pick_days = sorted(set(days.tolist()) - set(np.unique(U["day"].to_numpy().astype("datetime64[D]")).tolist()))
    T, binfo = assemble(SL, market, U, log)
    res, info, Q = analyse(SL, P, T, root, log)
    run = new_run_dir(SL, bout)
    info.update({"run": run.name, "tree": tinfo, "universe": uinfo, "bars": binfo,
                 "pick_days_without_panel_rows": [str(d) for d in missing_pick_days[:20]],
                 "production": prod.describe()})
    secs = time.time() - t0
    (run / "REPORT.md").write_text(report(res, decl, sha, info, secs), encoding="utf-8")
    flat_rows(res).to_csv(run / "claims.csv", index=False, float_format="%.10g")
    res["profile"].to_csv(run / "profile.csv", index=False, float_format="%.10g")
    res["path"].to_csv(run / "path.csv", index=False, float_format="%.10g")
    rules_rows(res).to_csv(run / "rules.csv", index=False, float_format="%.10g")
    res["examples"].to_csv(run / "examples.csv", index=False, float_format="%.10g")
    Q.to_parquet(run / "picks.parquet", index=False)
    (run / "DECLARATION.json").write_bytes(DECL_FILE.read_bytes())
    meta = {"version": VERSION, "declaration_sha256": sha, "root": str(root), "seconds": round(secs, 1),
            "verdicts": {lane: {str(k): v for k, v in vs.items()} for lane, vs in res["verdicts"].items()},
            "rules": {rk: v["verdict"] for rk, v in res["claim3"].items()},
            "info": json.loads(json.dumps(info, default=str)), "rerun_reason": rerun_reason,
            "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__}
    (run / "run.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    SL.write_hashes(run, ["REPORT.md", "claims.csv", "profile.csv", "path.csv", "rules.csv", "examples.csv",
                          "picks.parquet", "run.json", "DECLARATION.json"])
    rec = {"event": "run", "run": run.name, "at": dt.datetime.now().isoformat(timespec="seconds"),
           "declaration_sha256": sha, "version": VERSION, "tree_run": tinfo["run"],
           "verdicts": meta["verdicts"]["ALL"], "rules": meta["rules"], "rerun_reason": rerun_reason}
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    log(f"RESULT: " + "; ".join(f"{k} {v}" for k, v in meta["verdicts"]["ALL"].items()) + "; rules " +
        ", ".join(f"{k} {v}" for k, v in meta["rules"].items()))
    log(f"DONE -> {run}")
    return run


# ==================================================================================== PART K (v1.1)
# What D itself relies on: D's 5 walk-forward folds rebuilt with stage D's own recipe (production imported read
# only), proven equal to the frozen scores, then one group of inputs at a time scrambled on the test days.
K_FILE = HERE / "WHY_K_DECLARATION.json"
K_SHA = "158621297b5013235efcdc4cd99f518ae203c9555b6c00da283566f357cdd342"
K_TARGET = "label_oc_5"
K_REPEATS = (7, 8, 9)
K_GATE_TOP3 = 0.99
K_GATE_RHO = 0.999
K_DAYCONST = 0.99
K_CHUNK = 200_000
SD_NEEDS = ("CFG", "make_label", "eligible_mask", "horizon_of")
SB_NEEDS = ("ELIG_COL", "_read_col", "_naive")


def load_k(path: Path = K_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != K_SHA:
        raise WHError(f"{Path(path).name} has sha256 {sha[:16]}, not the pinned {K_SHA[:16]} - the declaration is "
                      f"fixed before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def k_modules():
    """Production's stage D code, imported read only (env_whylab.bat puts bigmove_deploy\\open_close first)."""
    try:
        import stage_d_gate as SD
        import stage_b_screen as SB
    except ImportError as e:
        raise WHError(f"cannot import production's stage D code ({e}) - start with env_whylab.bat (it puts "
                      f"bigmove_deploy\\open_close on PYTHONPATH)")
    miss = [f"stage_d_gate.{n}" for n in SD_NEEDS if not hasattr(SD, n)] + \
        [f"stage_b_screen.{n}" for n in SB_NEEDS if not hasattr(SB, n)]
    if miss:
        raise WHError(f"production's stage D code lacks {miss} - not the frozen version?")
    return SD, SB


def k_families(feats: List[str], decl: dict) -> List[Tuple[str, List[int]]]:
    """Each input to the first family whose pattern matches its lower-case name (declaration order)."""
    import re
    pats = [(n, re.compile(p)) for n, p in decl["families"]]
    out = {n: [] for n, _ in pats}
    for j, f in enumerate(feats):
        for n, pat in pats:
            if pat.search(f.lower()):
                out[n].append(j)
                break
    return [(n, out[n]) for n, _ in pats if out[n]]


def k_inputs(root: Path, SD) -> dict:
    """The frozen D run, every file checked against FROZEN_ENGINES.json."""
    pp = root / "panel_oc" / "panel.parquet"
    fz = root / "panel_oc" / "frozen" / "FROZEN_ENGINES.json"
    for p in (pp, fz):
        if not p.is_file():
            raise WHError(f"{p} not found")
    man = json.loads(fz.read_text(encoding="utf-8"))
    run = man["engines"]["D"]["run"]
    if man.get("target") != K_TARGET:
        raise WHError(f"FROZEN_ENGINES.json's target is {man.get('target')}, not {K_TARGET}")
    rd = root / "panel_oc" / "stage_d" / run
    files = man.get("files", {})
    want = {"stage_d_gate.py": (Path(SD.__file__), files.get("code/stage_d_gate.py")),
            "stage_d.json": (rd / "stage_d.json", files.get(f"runs/D/{run}/stage_d.json")),
            "preds.parquet": (rd / "preds.parquet", files.get(f"runs/D/{run}/preds.parquet"))}
    for nm, (p, h) in want.items():
        if not Path(p).is_file():
            raise WHError(f"{p} not found")
        if not h:
            raise WHError(f"FROZEN_ENGINES.json records no sha256 for {nm}")
        got = TC.sha256_file(p)
        if got != h:
            raise WHError(f"{p} has sha256 {got[:16]}, not the frozen {h[:16]} (FROZEN_ENGINES.json) - refusing")
    sd = json.loads((rd / "stage_d.json").read_text(encoding="utf-8"))
    if json.loads(json.dumps(sd.get("config"))) != json.loads(json.dumps(SD.CFG)):
        raise WHError("stage_d.json's config differs from stage_d_gate.CFG - not the frozen recipe")
    folds = [f for f in sd.get("folds", []) if f.get("target") == K_TARGET]
    if not sd.get("features") or len(folds) != int(SD.CFG["n_splits"]):
        raise WHError(f"stage_d.json lists {len(sd.get('features') or [])} features and {len(folds)} {K_TARGET} folds")
    return {"pp": pp, "run": run, "rd": rd, "feats": list(sd["features"]), "folds": folds, "frozen": man,
            "stage_d_gate": str(Path(SD.__file__).resolve())}


def k_load(SD, SB, pp: Path, feats: List[str], log=say):
    """Eligible rows sorted by (session, symbol), the target and the feature matrix - as run_gate builds them."""
    base = pd.read_parquet(pp, columns=["timestamp", "symbol", SB.ELIG_COL])
    ts = np.asarray(SB._naive(base["timestamp"])).astype("datetime64[ns]")
    sym = base["symbol"].astype(str).to_numpy()
    buy = pd.to_numeric(base[SB.ELIG_COL], errors="coerce").to_numpy(dtype=float)
    del base
    el = SD.eligible_mask(buy)
    order = np.lexsort((sym, ts))
    sel = order[el[order]]
    ts_s, sym_s = ts[sel], sym[sel]
    sessions = np.unique(ts_s)
    day = np.searchsorted(sessions, ts_s)
    y = np.asarray(SB._read_col(pp, K_TARGET), dtype=float)[sel]
    X = np.empty((len(sel), len(feats)), dtype=np.float32)
    t0 = time.time()
    for j, f in enumerate(feats):
        X[:, j] = SB._read_col(pp, f)[sel]
        if j and j % 50 == 0:
            log(f"   features: {j} of {len(feats)} ({time.time() - t0:.0f}s)")
    log(f" K: {len(sel):,} eligible rows of {len(ts):,}, {len(feats)} features ({X.nbytes / 1e9:.2f} GB)")
    return ts_s, sym_s, sessions, day, y, X


def k_fit(SD, X, y, day, sessions, folds, log=say):
    """stage_d_gate.run_gate's fold loop for the target, unchanged: the fitted models and every test score."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    cfg = SD.CFG
    h = SD.horizon_of(K_TARGET)
    sidx = {np.datetime64(s, "ns"): i for i, s in enumerate(sessions)}
    score = np.full(len(day), np.nan)
    fits = []
    for f in folds:
        fo = int(f["fold"])
        tr_end = sidx[np.datetime64(pd.Timestamp(f["train_end"]), "ns")]
        te0 = sidx[np.datetime64(pd.Timestamp(f["test_start"]), "ns")]
        te1 = sidx[np.datetime64(pd.Timestamp(f["test_end"]), "ns")]
        tr = np.flatnonzero((day <= tr_end) & np.isfinite(y))
        gap = te0 - int(day[tr].max())
        if gap <= h:
            raise WHError(f"fold {fo}: the last training row is {gap} sessions before the test window")
        lab, lo, hi = SD.make_label(y[tr], day[tr], cfg["winsor_pct"])
        rng = np.random.default_rng([cfg["seed"], fo, h])
        keep = (np.arange(len(tr)) if len(tr) <= cfg["fit_cap"]
                else np.sort(rng.choice(len(tr), cfg["fit_cap"], replace=False)))
        fit_i, fit_lab = tr[keep], lab[keep]
        t1 = time.time()
        model = HistGradientBoostingRegressor(random_state=cfg["seed"], **cfg["hgb"])
        model.fit(X[fit_i], fit_lab)
        te = np.flatnonzero((day >= te0) & (day <= te1))
        for a in range(0, len(te), K_CHUNK):
            b = te[a:a + K_CHUNK]
            score[b] = model.predict(X[b])
        fits.append({"fold": fo, "model": model, "te": te, "train_rows": int(len(tr)), "fit_rows": int(len(fit_i)),
                     "test_rows": int(len(te)), "recorded": {k: f.get(k) for k in ("train_rows", "fit_rows",
                                                                                    "test_rows")}})
        log(f" K: fold {fo} trained on {len(fit_i):,} of {len(tr):,} rows to {f['train_end']}, scored {len(te):,} "
            f"rows {f['test_start']}..{f['test_end']} ({time.time() - t1:.0f}s)")
    return fits, score


def day_ranks(day: np.ndarray, sym: np.ndarray, val: np.ndarray) -> np.ndarray:
    """Position of each row within its day: score descending, ties by symbol (stage D's daily_top_n order)."""
    o = np.lexsort((sym, -val, day))
    d = day[o]
    first = np.r_[True, d[1:] != d[:-1]]
    gstart = np.flatnonzero(first)
    pos = np.empty(len(o), dtype=np.int64)
    pos[o] = np.arange(len(o)) - np.repeat(gstart, np.diff(np.r_[gstart, len(o)]))
    return pos


def k_gate(rd: Path, ts_s, sym_s, day, score) -> dict:
    """The rebuilt scores against preds.parquet: same top 3 (stage D's ranking) and the daily rank correlation."""
    P = pd.read_parquet(rd / "preds.parquet", columns=["timestamp", "symbol", "target", "score"])
    P = P[P["target"].astype(str) == K_TARGET]
    P = pd.DataFrame({"timestamp": pd.to_datetime(P["timestamp"]).to_numpy(dtype="datetime64[ns]"),
                      "symbol": P["symbol"].astype(str).to_numpy(), "frozen": P["score"].to_numpy(float)})
    m = np.isfinite(score)
    A = pd.DataFrame({"timestamp": ts_s[m], "symbol": sym_s[m], "day": day[m], "mine": score[m]})
    J = A.merge(P, on=["timestamp", "symbol"], how="outer", indicator=True)
    both = J[J["_merge"] == "both"].copy()
    out = {"rows_rebuilt": int(m.sum()), "rows_frozen": int(len(P)), "rows_matched": int(len(both)),
           "only_rebuilt": int((J["_merge"] == "left_only").sum()), "only_frozen": int((J["_merge"] == "right_only").sum())}
    if both.empty:
        out.update({"days": 0, "same_top3_share": 0.0, "median_rho": float("nan"), "max_abs_diff": float("nan"),
                    "passed": False})
        return out
    d = both["day"].to_numpy()
    sy = both["symbol"].to_numpy()
    mine, frz = both["mine"].to_numpy(float), both["frozen"].to_numpy(float)
    t1 = day_ranks(d, sy, mine) < 3
    t2 = day_ranks(d, sy, frz) < 3
    days = np.unique(d)
    di = np.searchsorted(days, d)
    agree = np.bincount(di[t1 & t2], minlength=len(days))
    same = agree == np.minimum(3, np.bincount(di, minlength=len(days)))
    r1 = both.groupby("day")["mine"].rank().to_numpy(float)
    r2 = both.groupby("day")["frozen"].rank().to_numpy(float)
    n = np.bincount(di, minlength=len(days)).astype(float)
    s1, s2 = np.bincount(di, r1, len(days)), np.bincount(di, r2, len(days))
    s11, s22, s12 = (np.bincount(di, r1 * r1, len(days)), np.bincount(di, r2 * r2, len(days)),
                     np.bincount(di, r1 * r2, len(days)))
    with np.errstate(invalid="ignore", divide="ignore"):
        cov = s12 / n - (s1 / n) * (s2 / n)
        rho = cov / np.sqrt((s11 / n - (s1 / n) ** 2) * (s22 / n - (s2 / n) ** 2))
    out.update({"days": int(len(days)), "same_top3_share": float(same.mean()),
                "median_rho": float(np.nanmedian(rho)), "max_abs_diff": float(np.max(np.abs(mine - frz)))})
    out["passed"] = bool(out["same_top3_share"] >= K_GATE_TOP3 and out["median_rho"] >= K_GATE_RHO)
    return out


def k_dayconst(X: np.ndarray, fits: list, day: np.ndarray) -> np.ndarray:
    """Per column: one value for every eligible stock (or all blank) on at least 99% of test days."""
    const = np.zeros(X.shape[1])
    ndays = 0
    for f in fits:
        te = f["te"]
        G = pd.DataFrame(X[te]).groupby(day[te])
        mn, mx, cnt, size = G.min(), G.max(), G.count(), G.size().to_numpy()[:, None]
        c = ((mn.to_numpy() == mx.to_numpy()) & (cnt.to_numpy() == size)) | (cnt.to_numpy() == 0)
        const += c.sum(axis=0)
        ndays += len(size)
    return const / max(ndays, 1) >= K_DAYCONST


def k_scramble(Xt: np.ndarray, dt: np.ndarray, cols: List[int], dc: np.ndarray, rng) -> np.ndarray:
    """Xt with the family's columns scrambled: stock-varying ones across the day's stocks (one permutation per
    day, the same for all of them), day-constant ones across the window's days (each day gets another's values)."""
    Xp = Xt.copy()
    vc = [c for c in cols if not dc[c]]
    cc = [c for c in cols if dc[c]]
    if vc:
        order = np.lexsort((rng.random(len(dt)), dt))
        Xp[:, vc] = Xt[np.ix_(order, vc)]
    if cc:
        first = np.r_[0, np.flatnonzero(np.diff(dt)) + 1]
        perm = rng.permutation(len(first))
        dpos = np.searchsorted(first, np.arange(len(dt)), side="right") - 1
        Xp[:, cc] = Xt[np.ix_(first[perm][dpos], cc)]
    return Xp


def k_top3(dt, st, val, etf):
    """True for the rows in each day's top 3 by score (ETFs out), ties by symbol."""
    v = np.where(etf, -np.inf, val)
    return (day_ranks(dt, st, v) < 3) & ~etf


def k_knockout(fits, X, day, sym, y, etf, fams, dc, log=say):
    """Per family: per test day, the share of the original top 3 replaced and the top-3 mean net after minus before
    (each the mean over the repeats). Returns (days, base net per day, {family: (changed, diff)})."""
    net = (y - COST / 100) * 100
    days_all, base_all = [], []
    res = {nm: [[], []] for nm, _ in fams}
    t0 = time.time()
    for f in fits:
        te = f["te"]
        Xt, dt, st, yt, et = X[te], day[te], sym[te], net[te], etf[te]
        s0 = np.concatenate([f["model"].predict(Xt[a:a + K_CHUNK]) for a in range(0, len(te), K_CHUNK)])
        c0 = k_top3(dt, st, s0, et)
        dd = np.unique(dt)
        di = np.searchsorted(dd, dt)
        nd = len(dd)

        def day_net(ch):
            ok = ch & np.isfinite(yt)
            s_, c_ = np.bincount(di[ok], yt[ok], nd), np.bincount(di[ok], minlength=nd)
            with np.errstate(invalid="ignore", divide="ignore"):
                return np.where(c_ > 0, s_ / np.maximum(c_, 1), np.nan)
        b0 = day_net(c0)
        n0 = np.bincount(di[c0], minlength=nd)
        days_all.append(dd)
        base_all.append(b0)
        for k, (nm, cols) in enumerate(fams):
            chg, dif = np.zeros(nd), np.zeros(nd)
            for r in K_REPEATS:
                rng = np.random.default_rng([r, int(f["fold"]), k])
                Xp = k_scramble(Xt, dt, cols, dc, rng)
                s1 = np.concatenate([f["model"].predict(Xp[a:a + K_CHUNK]) for a in range(0, len(te), K_CHUNK)])
                del Xp
                c1 = k_top3(dt, st, s1, et)
                kept = np.bincount(di[c0 & c1], minlength=nd)
                with np.errstate(invalid="ignore", divide="ignore"):
                    chg += np.where(n0 > 0, 1 - kept / np.maximum(n0, 1), np.nan)
                dif += day_net(c1) - b0
            res[nm][0].append(chg / len(K_REPEATS))
            res[nm][1].append(dif / len(K_REPEATS))
        log(f" K: fold {f['fold']} knock-outs done ({time.time() - t0:.0f}s)")
    days = np.concatenate(days_all)
    return days, np.concatenate(base_all), {nm: (np.concatenate(v[0]), np.concatenate(v[1])) for nm, v in res.items()}


def k_execute(SL, root: Path, bout: Path, rerun_reason: Optional[str] = None, log=say) -> Path:
    t0 = time.time()
    kd, ksha = load_k()
    prev = [r for r in (json.loads(x) for x in ((bout / LEDGER).read_text(encoding="utf-8").splitlines()
                                                 if (bout / LEDGER).is_file() else []))
            if r.get("event") == "model" and r.get("declaration_sha256") == ksha]
    if prev and not rerun_reason:
        raise WHError(f"part K already ran ({prev[-1].get('run')}); a second run needs --rerun-reason "
                      f"\"<a verified bug>\" (recorded in the ledger)")
    SD, SB = k_modules()
    inp = k_inputs(root, SD)
    log(f"{VERSION} part K: D run {inp['run']}, {len(inp['feats'])} inputs, {len(inp['folds'])} folds of {K_TARGET}; "
        f"stage_d_gate {inp['stage_d_gate']}")
    fams = k_families(inp["feats"], kd)
    ts_s, sym_s, sessions, day, y, X = k_load(SD, SB, inp["pp"], inp["feats"], log)
    fits, score = k_fit(SD, X, y, day, sessions, inp["folds"], log)
    g = k_gate(inp["rd"], ts_s, sym_s, day, score)
    log(f" K gate: same top 3 on {100 * g['same_top3_share']:.2f}% of {g['days']:,} days, median rank correlation "
        f"{g['median_rho']:.6f} -> {'PASSED' if g['passed'] else 'FAILED'}")
    run = SL.new_run_dir(bout / "model", "K")
    folds_tab = pd.DataFrame([{"fold": f["fold"], "train_rows": f["train_rows"], "fit_rows": f["fit_rows"],
                               "test_rows": f["test_rows"], **{f"recorded_{k}": v for k, v in f["recorded"].items()}}
                              for f in fits])
    inputs_tab = pd.DataFrame([{"input": inp["feats"][j], "family": nm} for nm, cols in fams for j in cols])
    fam_rows, base, days = [], None, None
    if g["passed"]:
        try:
            _, tdoc = SL.load_tree()
            listed = SL.etf_list(root)
        except ValueError as e:
            raise WHError(f"setuplab's ETF rule is not usable: {e}")
        etf = SL.tree_etf(sym_s, tdoc, listed)
        dc = k_dayconst(X, fits, day)
        inputs_tab["day_constant"] = [bool(dc[inp["feats"].index(x)]) for x in inputs_tab["input"]]
        days_i, base_net, R = k_knockout(fits, X, day, sym_s, y, etf, fams, dc, log)
        days = sessions[days_i].astype("datetime64[D]")
        S = Stat(SL, days)
        di = S.di(days)
        per = np.where(days < P2_START, "P1", "P2")
        base = {p: S.mean(di, base_net, (per == p) if p != "ALL" else np.ones(len(days), bool))
                for p in ("ALL",) + PERIODS}
        for nm, cols in fams:
            chg, dif = R[nm]
            row = {"family": nm, "inputs": len(cols), "day_constant": int(sum(bool(dc[c]) for c in cols)),
                   "picks_changed_pct": 100 * float(np.nanmean(chg))}
            for p in ("ALL",) + PERIODS:
                m = (per == p) if p != "ALL" else np.ones(len(days), bool)
                r = S.mean(di, dif, m)
                row.update({f"lost_{p}": r["stat"], f"lo_{p}": r["lo"], f"hi_{p}": r["hi"]})
            row["verdict"] = "RELIES ON" if np.isfinite(row["hi_ALL"]) and row["hi_ALL"] < 0 else "NO CLEAR RELIANCE"
            fam_rows.append(row)
    F = pd.DataFrame(fam_rows)
    if len(F):
        F = F.sort_values("lost_ALL").reset_index(drop=True)
    secs = time.time() - t0
    info = {"run": run.name, "d_run": inp["run"], "gate": g, "stage_d_gate": inp["stage_d_gate"], "seconds": secs,
            "rows": int(len(day)), "inputs": len(inp["feats"])}
    (run / "KREPORT.md").write_text(k_report(F, g, folds_tab, inputs_tab, base, kd, ksha, info), encoding="utf-8")
    F.to_csv(run / "families.csv", index=False, float_format="%.10g")
    inputs_tab.to_csv(run / "inputs.csv", index=False)
    pd.DataFrame([g]).to_csv(run / "gate.csv", index=False, float_format="%.10g")
    folds_tab.to_csv(run / "folds.csv", index=False)
    (run / "DECLARATION.json").write_bytes(K_FILE.read_bytes())
    meta = {"version": VERSION, "declaration_sha256": ksha, "root": str(root), "info": info,
            "verdicts": {r["family"]: r["verdict"] for r in fam_rows}, "rerun_reason": rerun_reason,
            "python": sys.version.split()[0], "pandas": pd.__version__, "numpy": np.__version__}
    try:
        import sklearn
        meta["sklearn"] = sklearn.__version__
    except ImportError:
        pass
    (run / "run.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    SL.write_hashes(run, ["KREPORT.md", "families.csv", "inputs.csv", "gate.csv", "folds.csv", "DECLARATION.json",
                          "run.json"])
    rec = {"event": "model", "run": run.name, "at": dt.datetime.now().isoformat(timespec="seconds"),
           "declaration_sha256": ksha, "version": VERSION, "gate_passed": g["passed"], "verdicts": meta["verdicts"],
           "rerun_reason": rerun_reason}
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    if not g["passed"]:
        log(f"STOPPED: the rebuild does not reproduce the frozen scores - no knock-out ran ({run})")
        raise GateFailed(f"part K gate failed: same top 3 on {100 * g['same_top3_share']:.2f}% of days, median rank "
                         f"correlation {g['median_rho']:.6f} (needs 99% and 0.999); report in {run}")
    log("RESULT: " + "; ".join(f"{r['family']} {r['verdict']} ({_f(r['lost_ALL'])})" for r in F.to_dict("records")))
    log(f"DONE -> {run}")
    return run


def k_report(F, g, folds_tab, inputs_tab, base, kd, ksha, info) -> str:
    L = [f"# whylab part K - what D itself relies on ({info['run']})", "",
         f"{VERSION} | K declaration {ksha[:16]} (fixed {kd['declared_at']}) | D run {info['d_run']} | "
         f"{info['rows']:,} eligible rows, {info['inputs']} inputs | {info['seconds']:.0f} s", "",
         "D's 5 walk-forward folds were rebuilt with stage D's own code and settings (production imported read only). "
         "Then one group of inputs at a time was scrambled on the test days - shuffled across the day's stocks, or "
         "across days for inputs that are the same for every stock - and the same fitted models re-picked the top 3 "
         "(ETFs out). **D relies on a group when scrambling it costs money**: the 95% interval of the change in the "
         "top-3 net per trade is below 0 (D1 open to D5 close, 0.35 points of costs).", "",
         "## The rebuild must equal the frozen D first", "",
         f"- Same top 3 as the frozen scores on **{100 * g['same_top3_share']:.2f}%** of {g['days']:,} days (needs 99%); "
         f"median daily rank correlation **{g['median_rho']:.6f}** (needs 0.999); largest score difference "
         f"{g['max_abs_diff']:.3g}. Rows: rebuilt {g['rows_rebuilt']:,}, frozen {g['rows_frozen']:,}, matched "
         f"{g['rows_matched']:,}. -> **{'PASSED' if g['passed'] else 'FAILED'}**", ""]
    L += ["| fold | train rows | fit rows | test rows | recorded train / fit / test |", "|---|---|---|---|---|"]
    for _, r in folds_tab.iterrows():
        L.append(f"| {r['fold']} | {r['train_rows']:,} | {r['fit_rows']:,} | {r['test_rows']:,} | "
                 f"{r.get('recorded_train_rows')} / {r.get('recorded_fit_rows')} / {r.get('recorded_test_rows')} |")
    if not g["passed"]:
        L += ["", "**No knock-out ran: the rebuild is not the frozen D, so nothing measured on it could be called "
              "D's.** Send this report and gate.csv.", ""]
        return "\n".join(L) + "\n"
    L += ["", "## What D relies on (ranked by the money lost when the group is scrambled)", "",
          f"The rebuilt top 3 (ETFs out) made {_s(base['ALL'])} points a trade over 2020-26 "
          f"(2020-23 {_s(base['P1'])}, 2024-26 {_s(base['P2'])}).", "",
          "| group | inputs | picks replaced | money lost per trade, 2020-26 | 2020-23 | 2024-26 | verdict |",
          "|---|---|---|---|---|---|---|"]
    for _, r in F.iterrows():
        L.append(f"| {r['family']} | {r['inputs']}{' (' + str(r['day_constant']) + ' same for every stock)' if r['day_constant'] else ''} "
                 f"| {r['picks_changed_pct']:.1f}% | {_f(r['lost_ALL'])} [{_f(r['lo_ALL'])}, {_f(r['hi_ALL'])}] | "
                 f"{_f(r['lost_P1'])} [{_f(r['lo_P1'])}, {_f(r['hi_P1'])}] | {_f(r['lost_P2'])} [{_f(r['lo_P2'])}, "
                 f"{_f(r['hi_P2'])}] | **{r['verdict']}** |")
    raw = F[F["family"] == "raw price levels"]
    if len(raw):
        r = raw.iloc[0]
        L += ["", f"**Raw price levels** (the question open since 1 Nov): {r['inputs']} inputs - "
              + ", ".join(inputs_tab.loc[inputs_tab.family == "raw price levels", "input"]) +
              f". Scrambling them replaced {r['picks_changed_pct']:.1f}% of the picks and changed the net by "
              f"{_f(r['lost_ALL'])} [{_f(r['lo_ALL'])}, {_f(r['hi_ALL'])}] points a trade -> **{r['verdict']}**."]
    L += ["", "Picks replaced = the share of the original top-3 picks no longer in the top 3 (mean over days and the 3 "
          "repeats). A group can move many picks and cost nothing (the replacements are as good) - only the money "
          "decides.", "", "## Every input and its group", ""]
    for nm in inputs_tab["family"].unique():
        xs = inputs_tab[inputs_tab.family == nm]
        L.append(f"- **{nm}** ({len(xs)}): " + ", ".join(
            x + ("*" if dcx else "") for x, dcx in zip(xs["input"], xs.get("day_constant", [False] * len(xs)))))
    L += ["", "* = the same for every stock on the day: scrambled across days.", ""]
    return "\n".join(L) + "\n"


# ==================================================================================== PART P (v1.2)
# Why each pick was picked: each pick's score split into its inputs' pushes (shap, against a draw of the same day's
# stocks) and summed by part K's groups; confidence from two bootstrap versions of the same fold; the reason followed
# through the D1..D5 closes; then whether a kind of pick, or the reason fading, calls for its own plan. And today's.
P_FILE = HERE / "WHY_P_DECLARATION.json"
P_SHA = "99db37895043cc79528c4d27ebc891d212a4da1e00c3b847640074a4309fec79"
P_SHAP = "0.54.1"
P_NBG = 100
P_BOOTS = (1, 2)
P_CLOSES = (1, 2, 3, 4, 5)
P_MIN = 100
P_ADD_TOL = 1e-7
P_TREE_MATCH = 0.95
P_REPRO_TOL = 1e-9
P_TOP_INPUTS = 5
P_LIVE_SESSIONS = 6
MIXED = "MIXED"
THERE, GONE, UNKNOWN = 1, 0, -1
STATUS = {THERE: "STILL THERE", GONE: "GONE", UNKNOWN: "UNKNOWN"}
P_OUT = tuple([f"r{k}" for k in range(1, KMAX + 1)] + [f"o{k}" for k in range(2, 7)])


class PAddError(Exception):
    """An explanation did not add up to the stock's score minus the comparison's mean score (exit 3)."""


def load_p(path: Path = P_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != P_SHA:
        raise WHError(f"{Path(path).name} has sha256 {sha[:16]}, not the pinned {P_SHA[:16]} - the declaration is "
                      f"fixed before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def p_shap():
    try:
        import shap
    except ImportError as e:
        raise WHError(f"cannot import shap ({e}) - install it once: pip install shap=={P_SHAP}")
    if getattr(shap, "__version__", "") != P_SHAP:
        raise WHError(f"shap is {getattr(shap, '__version__', '?')}; part P is declared on shap {P_SHAP} - "
                      f"pip install shap=={P_SHAP}")
    return shap


def p_ymd(t) -> int:
    return int(pd.Timestamp(t).strftime("%Y%m%d"))


def p_draw(v: int, ymd: int, cand: np.ndarray) -> np.ndarray:
    """Version v's comparison stocks on a session: P_NBG of the candidate rows (given in symbol order), without
    replacement, numpy default_rng([v, YYYYMMDD]); all of them when there are not more."""
    cand = np.asarray(cand)
    if len(cand) <= P_NBG:
        return cand.copy()
    rng = np.random.default_rng([v, ymd])
    return np.sort(cand[rng.choice(len(cand), P_NBG, replace=False)])


def p_groups(fams, n_inputs: int) -> np.ndarray:
    """0/1 matrix inputs x groups (part K's groups, their order)."""
    G = np.zeros((n_inputs, len(fams)))
    for k, (_, cols) in enumerate(fams):
        G[cols, k] = 1.0
    return G


def p_split_points(t: np.ndarray) -> np.ndarray:
    """shap 0.54.1's interventional code (tree_shap.h, tree_shap_indep) holds each split point as a 32-bit float and
    sends a stock right when its value > that float. A split point between two 32-bit values that rounds UP sends a
    stock sitting exactly on the rounded value the other way from scikit-learn (value <= the 64-bit split point goes
    left): found on Karan's PC, 15 Nov 2026 (P_20261115_001 stopped, gap 3.66e-06). Each split point is rounded DOWN
    to a 32-bit float instead: for every 32-bit value x, x > t32 exactly when x > t, so every stock takes D's branch."""
    t = np.asarray(t, dtype=np.float64)
    fin = np.isfinite(t)
    with np.errstate(over="ignore", invalid="ignore"):
        t32 = np.where(fin, t, 0.0).astype(np.float32)
        up = fin & (t32.astype(np.float64) > t)
        t32[up] = np.nextafter(t32[up], np.float32(-np.inf))
    return np.where(fin, t32.astype(np.float64), t)


class PExplainer:
    """One fitted model explained against a different comparison set on each session: shap's interventional
    TreeSHAP on trees parsed once, split points rounded down to 32 bits (p_split_points). D's inputs are 32-bit
    floats. Every call is checked against scikit-learn's own predictions."""

    def __init__(self, shap, model):
        self.shap, self.model = shap, model
        self.ens = shap.TreeExplainer(model).model
        self.ens.thresholds = p_split_points(self.ens.thresholds)
        self.calls, self.rows, self.max_gap = 0, 0, 0.0

    def __call__(self, rows: np.ndarray, bg: np.ndarray) -> np.ndarray:
        rows = np.asarray(rows, dtype=np.float64)
        bg = np.asarray(bg, dtype=np.float64)
        if len(bg) > P_NBG or len(bg) < 1:
            raise WHError(f"a comparison set of {len(bg)} stocks (needs 1..{P_NBG})")
        for a in (rows, bg):
            if not np.array_equal(a.astype(np.float32).astype(np.float64), a, equal_nan=True):
                raise WHError("an explanation needs 32-bit inputs (D's own); these are not")
        E = self.shap.TreeExplainer(self.ens, data=bg, feature_perturbation="interventional")
        phi = np.asarray(E.shap_values(rows, check_additivity=False), dtype=float).reshape(len(rows), -1)
        s = self.model.predict(rows)
        gap = np.abs(phi.sum(1) - (s - self.model.predict(bg).mean()))
        self.calls += 1
        self.rows += len(rows)
        if len(gap):
            self.max_gap = max(self.max_gap, float(gap.max()))
            if (gap > P_ADD_TOL + 1e-6 * np.abs(s)).any():
                raise PAddError(f"an explanation does not add up to the score difference (gap {float(gap.max()):.3g})")
        return phi


def p_refit(SD, X, y, day, sessions, f: dict, b: Optional[int]):
    """k_fit's training rows for the fold, then V1/V2: min(fit_cap, rows) rows drawn WITH replacement, numpy
    default_rng([seed, fold, 5, b]). b None = the official draw (without replacement, [seed, fold, 5]): the tests use
    it to prove these are k_fit's rows."""
    from sklearn.ensemble import HistGradientBoostingRegressor
    cfg = SD.CFG
    h = SD.horizon_of(K_TARGET)
    sidx = {np.datetime64(s, "ns"): i for i, s in enumerate(sessions)}
    tr_end = sidx[np.datetime64(pd.Timestamp(f["train_end"]), "ns")]
    tr = np.flatnonzero((day <= tr_end) & np.isfinite(y))
    lab, _, _ = SD.make_label(y[tr], day[tr], cfg["winsor_pct"])
    if b is None:
        rng = np.random.default_rng([cfg["seed"], int(f["fold"]), h])
        keep = (np.arange(len(tr)) if len(tr) <= cfg["fit_cap"]
                else np.sort(rng.choice(len(tr), cfg["fit_cap"], replace=False)))
    else:
        rng = np.random.default_rng([cfg["seed"], int(f["fold"]), h, int(b)])
        keep = np.sort(rng.choice(len(tr), min(cfg["fit_cap"], len(tr)), replace=True))
    model = HistGradientBoostingRegressor(random_state=cfg["seed"], **cfg["hgb"])
    model.fit(X[tr[keep]], lab[keep])
    return model


def p_bounds(day: np.ndarray, n_sessions: int) -> Tuple[np.ndarray, np.ndarray]:
    """Rows are sorted by (session, symbol): each session's first row and one past its last."""
    s = np.arange(n_sessions)
    return np.searchsorted(day, s, side="left"), np.searchsorted(day, s, side="right")


def p_picks(fits, day, sym, score, etf):
    """Part K's picks: every test day's top 3 by the rebuilt score, ETFs out, ties by symbol. (rows, fold, rank)."""
    rows, fold, rank = [], [], []
    for fi, f in enumerate(fits):
        te = f["te"]
        r = day_ranks(day[te], sym[te], np.where(etf[te], -np.inf, score[te]))
        c = (r < 3) & ~etf[te]
        rows.append(te[c])
        fold.append(np.full(int(c.sum()), fi))
        rank.append(r[c] + 1)
    rows, fold, rank = np.concatenate(rows), np.concatenate(fold), np.concatenate(rank)
    o = np.lexsort((rank, day[rows]))
    return rows[o], fold[o], rank[o]


def p_percentile(col: np.ndarray, x: float) -> float:
    """x's place among the session's values: share below plus half the share equal (blanks left out)."""
    v = col[np.isfinite(col)]
    if not len(v) or not np.isfinite(x):
        return np.nan
    return float(((v < x).sum() + 0.5 * (v == x).sum()) / len(v))


def p_explain(shap, models, X, day, sym, sessions, etf, picks, G, log=say) -> dict:
    """Each pick explained on its signal day by V0, V1 and V2 (each against its own comparison draw), and by V0 at the
    D1..D5 closes. models[fold] = (V0, V1, V2)."""
    rows, fold, _ = picks
    n, nS, nG = len(rows), len(sessions), G.shape[1]
    starts, ends = p_bounds(day, nS)
    ymd = np.array([p_ymd(s) for s in sessions])
    d0 = day[rows]
    by_sess = {int(d): rows[d0 == d] for d in np.unique(d0)}
    cache: Dict[tuple, np.ndarray] = {}

    def draw(v, d):
        if (v, d) not in cache:
            r = np.arange(starts[d], ends[d])
            r = r[~etf[r]]
            if d in by_sess:
                r = r[~np.isin(r, by_sess[d])]
            cache[(v, d)] = p_draw(v, int(ymd[d]), r)
        return cache[(v, d)]
    work: Dict[tuple, list] = {}
    for i in range(n):
        fi, d = int(fold[i]), int(d0[i])
        for v in range(3):
            work.setdefault((fi, v, d), []).append((i, 0, rows[i]))
        for c in P_CLOSES:
            dd = d + c
            if dd >= nS:
                continue
            seg = sym[starts[dd]:ends[dd]]
            j = int(np.searchsorted(seg, sym[rows[i]]))
            if j < len(seg) and seg[j] == sym[rows[i]]:
                work.setdefault((fi, 0, dd), []).append((i, c, starts[dd] + j))
    E = {(fi, v): PExplainer(shap, models[fi][v]) for fi in range(len(models)) for v in range(3)}
    top = np.full((3, n), -1)
    push0 = np.full((n, nG), np.nan)
    phi0 = np.full((n, X.shape[1]), np.nan)
    pushc = np.full((n, len(P_CLOSES), nG), np.nan)
    keys = sorted(work)
    t0, step = time.time(), max(1, len(keys) // 10)
    for q, key in enumerate(keys):
        fi, v, d = key
        items = work[key]
        rr = np.array([it[2] for it in items])
        try:
            phi = E[(fi, v)](X[rr], X[draw(v, d)])
        except PAddError as e:
            raise PAddError(f"{e} - fold {fi + 1}, version V{v}, session {pd.Timestamp(sessions[d]).date()}, stocks "
                            f"{', '.join(map(str, sym[rr][:20]))}")
        pg = phi @ G
        for k_, (i, c, _) in enumerate(items):
            if c == 0:
                top[v, i] = int(np.argmax(pg[k_]))
                if v == 0:
                    push0[i], phi0[i] = pg[k_], phi[k_]
            else:
                pushc[i, c - 1] = pg[k_]
        if (q + 1) % step == 0:
            log(f"   explained: {q + 1:,} of {len(keys):,} (model, version, session) sets ({time.time() - t0:.0f}s)")
    orig = top[0]
    st = np.full((n, len(P_CLOSES)), UNKNOWN, dtype=int)
    topc = np.full((n, len(P_CLOSES)), -1)
    for c in range(len(P_CLOSES)):
        has = np.isfinite(pushc[:, c]).all(1)
        val = pushc[np.arange(n), c, np.maximum(orig, 0)]
        st[:, c] = np.where(has, np.where(val > 0, THERE, GONE), UNKNOWN)
        topc[:, c] = np.where(has, np.argmax(np.nan_to_num(pushc[:, c], nan=-np.inf), axis=1), -1)
    second = np.argsort(-push0, axis=1, kind="stable")[:, 1] if nG > 1 else np.zeros(n, int)
    return {"top": top, "push0": push0, "phi0": phi0, "pushc": pushc, "status": st, "topc": topc, "second": second,
            "calls": int(sum(e.calls for e in E.values())), "rows": int(sum(e.rows for e in E.values())),
            "max_gap": float(max(e.max_gap for e in E.values())), "draws": cache}


# ---------------------------------------------------------------------------------------------------- P outcomes
def p_arrays(ds, cal: np.ndarray) -> Dict[str, np.ndarray]:
    """r1..r10 (Dk close / D1 open - 1) and o2..o6 (Dk open / D1 open - 1) in points, aligned with the bars: the
    claims part's rule (blank when bar t+1 is not the calendar's next session or a bar is missing)."""
    o, c = np.asarray(ds.o, float), np.asarray(ds.c, float)
    n = len(c)
    dates = np.asarray(ds.dates).astype("datetime64[D]")
    j = np.searchsorted(cal, dates, side="right")
    nxt = np.where(j < len(cal), cal[np.minimum(j, len(cal) - 1)], np.datetime64("NaT"))
    ok1 = np.zeros(n, bool)
    if n > 1:
        ok1[:-1] = dates[1:] == nxt[:-1]
    o1 = np.full(n, np.nan)
    o1[:-1] = o[1:]
    o1[~ok1 | ~(o1 > 0)] = np.nan

    def ahead(a, k):
        out = np.full(n, np.nan)
        if n > k:
            out[:-k] = a[k:]
        return out
    F: Dict[str, np.ndarray] = {}
    with np.errstate(divide="ignore", invalid="ignore"):
        for k in range(1, KMAX + 1):
            F[f"r{k}"] = (ahead(c, k) / o1 - 1) * 100
        for k in range(2, 7):
            F[f"o{k}"] = (ahead(o, k) / o1 - 1) * 100
    return {k: np.where(np.isfinite(v), v, np.nan) for k, v in F.items()}


def p_assemble(market, U: pd.DataFrame, log=say, chunk: int = 100) -> Tuple[pd.DataFrame, dict]:
    """Every (day, symbol) of the universe with r1..r10 and o2..o6 from the stock's own bars."""
    n = len(U)
    cols = {k: np.full(n, np.nan) for k in P_OUT}
    groups = U.groupby("symbol", sort=True).indices
    syms = list(groups)
    cal = np.asarray(market.cal).astype("datetime64[D]")
    days = U["day"].to_numpy().astype("datetime64[D]")
    no_bars, t0 = 0, time.time()
    for c0 in range(0, len(syms), chunk):
        part = syms[c0:c0 + chunk]
        market.load(part)
        for s in part:
            rr = groups[s]
            ds = market.daily.get(s)
            if ds is None or not len(ds.dates):
                no_bars += len(rr)
                continue
            dd = np.asarray(ds.dates).astype("datetime64[D]")
            pos = np.searchsorted(dd, days[rr])
            hit = (pos < len(dd)) & (dd[np.minimum(pos, len(dd) - 1)] == days[rr])
            if hit.any():
                F = p_arrays(ds, cal)
                for k in cols:
                    cols[k][rr[hit]] = F[k][pos[hit]]
            market.daily.pop(s, None)
        log(f"   bars: {min(c0 + chunk, len(syms)):,} of {len(syms):,} symbols ({time.time() - t0:.0f}s)")
    T = U.copy()
    for k, a in cols.items():
        T[k] = a
    return T, {"no_bars_rows": int(no_bars), "missing_symbol_count": int(len(set(market.missing)))}


def p_tree_gate(Pk: pd.DataFrame, TP: pd.DataFrame) -> dict:
    """r5 - 0.35 here against the tree's d1_net, on the picks the tree also holds (engine D, complete, not ETF)."""
    Td = TP[TP["engine"] == "D"][["day", "symbol", "d1_net", "complete", "etf"]].drop_duplicates(["day", "symbol"])
    M = Pk[["day", "symbol", "r5"]].merge(Td, on=["day", "symbol"], how="left", indicator=True)
    inn = (M["_merge"] == "both").to_numpy()
    m = (inn & M["complete"].astype("boolean").fillna(False).to_numpy(bool) &
         ~M["etf"].astype("boolean").fillna(False).to_numpy(bool) & np.isfinite(M["d1_net"].to_numpy(float)))
    a, b = M["r5"].to_numpy(float)[m] - COST, M["d1_net"].to_numpy(float)[m]
    eq = np.isfinite(a) & (np.abs(a - b) <= GATE_TOL)
    out = {"picks": int(len(M)), "in_tree": int(inn.sum()), "in_tree_share": float(inn.mean()) if len(M) else 0.0,
           "compared": int(m.sum()), "equal": int(eq.sum()), "share": float(eq.mean()) if m.any() else 0.0,
           "examples": M.loc[m].loc[~eq, ["day", "symbol", "r5", "d1_net"]].head(10).astype(str).values.tolist()}
    out["passed"] = bool(out["in_tree_share"] >= P_TREE_MATCH and m.any() and out["share"] >= GATE_SHARE)
    return out


# ---------------------------------------------------------------------------------------------------- P tests
def p_diff(S: Stat, di, va, ma, vb, mb) -> dict:
    """mean(va over ma) - mean(vb over mb) with its 95% interval, the two means resampled on the same days. The groups
    may overlap (each row counts in both), unlike Stat.diff, which takes one value per row."""
    va, vb = np.asarray(va, float), np.asarray(vb, float)
    ma = np.asarray(ma, bool) & np.isfinite(va) & (di >= 0)
    mb = np.asarray(mb, bool) & np.isfinite(vb) & (di >= 0)
    out = {"n_a": int(ma.sum()), "n_b": int(mb.sum()), "a": np.nan, "b": np.nan, "stat": np.nan, "lo": np.nan,
           "hi": np.nan}
    if ma.sum() < 2 or mb.sum() < 2:
        return out
    out["a"], out["b"] = float(va[ma].mean()), float(vb[mb].mean())
    out["stat"] = out["a"] - out["b"]
    d = S._res(di, np.nan_to_num(va), [ma])[:, 0] - S._res(di, np.nan_to_num(vb), [mb])[:, 0]
    if np.isfinite(d).sum() > 100:
        out["lo"], out["hi"] = float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5))
    return out


def p_tests(S: Stat, Q: pd.DataFrame, groups: List[str]) -> dict:
    """T1-T4 on the pick table Q (day, period, category, x_r1..x_r10, x_o2..x_o6, st_1..st_5)."""
    di = S.di(Q["day"].to_numpy())
    per = Q["period"].to_numpy()
    cat = Q["category"].to_numpy()
    x = {k: Q[f"x_r{k}"].to_numpy(float) for k in range(1, KMAX + 1)}
    xo = {k: Q[f"x_o{k}"].to_numpy(float) for k in range(2, 7)}
    Ek = np.column_stack([(x[k] - COST) / k for k in range(1, KMAX + 1)])
    P1, P2 = per == "P1", per == "P2"
    cats = [g for g in groups if (cat == g).any()] + ([MIXED] if (cat == MIXED).any() else [])
    rows = []
    for c in cats:
        A = cat == c
        n1, n2 = int((A & P1 & np.isfinite(x[5])).sum()), int((A & P2 & np.isfinite(x[5])).sum())
        ok = n1 >= P_MIN and n2 >= P_MIN
        r = {"category": c, "picks": int(A.sum()), "picks_P1": n1, "picks_P2": n2, "judged": ok}
        for k in range(1, KMAX + 1):
            r[f"own_D{k}"] = float(np.nanmean(x[k][A])) if np.isfinite(x[k][A]).any() else np.nan
        for p, M_ in (("P1", P1), ("P2", P2)):
            m5 = S.mean(di, x[5], A & M_)
            d1 = S.diff(di, x[5], A & M_, x[5], ~A & M_)
            r.update({f"own5_{p}": m5["stat"], f"own5_lo_{p}": m5["lo"], f"own5_hi_{p}": m5["hi"],
                      f"t1_{p}": d1["stat"], f"t1_lo_{p}": d1["lo"], f"t1_hi_{p}": d1["hi"]})
        dd = {p: {"lo": r[f"t1_lo_{p}"], "hi": r[f"t1_hi_{p}"]} for p in PERIODS}
        r["T1"] = ("TOO FEW" if not ok else "DIFFERS: BETTER" if above(dd["P1"]) and above(dd["P2"]) else
                   "DIFFERS: WORSE" if below(dd["P1"]) and below(dd["P2"]) else "NO CLEAR DIFFERENCE")
        means = [float(np.nanmean(Ek[A & P1, k])) if np.isfinite(Ek[A & P1, k]).any() else -np.inf
                 for k in range(KMAX)]
        ks = int(np.argmax(means)) + 1
        r.update({f"edge_P1_D{k}": means[k - 1] for k in range(1, KMAX + 1)})
        d2 = S.mean(di, Ek[:, ks - 1] - Ek[:, 4], A & P2)
        r.update({"k_star": ks, "t2_P2": d2["stat"], "t2_lo": d2["lo"], "t2_hi": d2["hi"]})
        r["T2"] = ("TOO FEW" if not ok else "KEEP D5" if ks == 5 else f"OWN HOLD D{ks}" if above(d2) else "KEEP D5")
        rows.append(r)
    st = Q[[f"st_{c}" for c in P_CLOSES]].to_numpy(int)
    first = np.zeros(len(Q), int)
    for c in (4, 3, 2, 1):                                     # the earliest GONE among the D1..D4 closes wins
        first = np.where(st[:, c - 1] == GONE, c, first)
    v3 = np.full(len(Q), np.nan)
    for c in (1, 2, 3, 4):
        m = first == c
        v3[m] = x[5][m] - xo[c + 1][m]
    t3 = {"by_close": {c: int((first == c).sum()) for c in (1, 2, 3, 4)}}
    for p, M_ in (("P1", P1), ("P2", P2)):
        r_ = S.mean(di, v3, (first > 0) & M_)
        t3.update({f"n_{p}": r_["n"], f"stat_{p}": r_["stat"], f"lo_{p}": r_["lo"], f"hi_{p}": r_["hi"]})
    ok3 = t3["n_P1"] >= P_MIN and t3["n_P2"] >= P_MIN
    b3 = {p: {"lo": t3[f"lo_{p}"], "hi": t3[f"hi_{p}"]} for p in PERIODS}
    t3["verdict"] = ("TOO FEW" if not ok3 else "EXIT EARLY" if below(b3["P1"]) and below(b3["P2"]) else
                     "KEEP TO D5" if above(b3["P1"]) and above(b3["P2"]) else "NOT RELIABLE")
    there5 = st[:, len(P_CLOSES) - 1] == THERE
    a4, h4 = x[10] - x[5], x[5] - COST
    t4 = {}
    for p, M_ in (("P1", P1), ("P2", P2)):
        r_ = p_diff(S, di, a4, there5 & M_, h4, M_)
        t4.update({f"n_{p}": r_["n_a"], f"held_{p}": r_["a"], f"new_{p}": r_["b"], f"stat_{p}": r_["stat"],
                   f"lo_{p}": r_["lo"], f"hi_{p}": r_["hi"]})
    ok4 = t4["n_P1"] >= P_MIN and t4["n_P2"] >= P_MIN
    t4["verdict"] = ("TOO FEW" if not ok4 else "HOLD LONGER" if above({"lo": t4["lo_P1"]}) and
                     above({"lo": t4["lo_P2"]}) else "SELL AT D5")
    return {"categories": pd.DataFrame(rows), "T3": t3, "T4": t4, "first_gone": first, "v3": v3}


def p_transitions(Q: pd.DataFrame, groups: List[str]) -> pd.DataFrame:
    """Per category (and all picks): the share whose reason is still there / gone / unknown at each close, and whose
    top group at the close is still the original one."""
    out = []
    cats = ["ALL"] + [g for g in groups if (Q["category"] == g).any()] + \
        ([MIXED] if (Q["category"] == MIXED).any() else [])
    for c in cats:
        m = np.ones(len(Q), bool) if c == "ALL" else (Q["category"] == c).to_numpy()
        for k in P_CLOSES:
            s = Q.loc[m, f"st_{k}"].to_numpy(int)
            same = (Q.loc[m, f"top_{k}"].to_numpy() == Q.loc[m, "reason"].to_numpy()) & (s != UNKNOWN)
            known_ = (s != UNKNOWN).sum()
            out.append({"category": c, "close": f"D{k}", "picks": int(m.sum()),
                        "still_there_pct": 100 * float((s == THERE).sum() / max(known_, 1)),
                        "gone_pct": 100 * float((s == GONE).sum() / max(known_, 1)),
                        "unknown_pct": 100 * float((s == UNKNOWN).mean()) if len(s) else np.nan,
                        "same_top_group_pct": 100 * float(same.sum() / max(known_, 1))})
    return pd.DataFrame(out)


# ---------------------------------------------------------------------------------------------------- P run
def p_execute(SL, root: Path, base: Path, bout: Path, stage_e_any: bool = False, rerun_reason: Optional[str] = None,
              log=say) -> Path:
    t0 = time.time()
    pd_, psha = load_p()
    kd, ksha = load_k()
    shap = p_shap()
    prev = [r for r in (json.loads(x) for x in ((bout / LEDGER).read_text(encoding="utf-8").splitlines()
                                                 if (bout / LEDGER).is_file() else []))
            if r.get("event") == "explain" and r.get("declaration_sha256") == psha]
    if prev and not rerun_reason:
        raise WHError(f"part P already ran ({prev[-1].get('run')}); a second run needs --rerun-reason "
                      f"\"<a verified bug>\" (recorded in the ledger)")
    SD, SB = k_modules()
    inp = k_inputs(root, SD)
    TP, tinfo = read_picks(base)
    log(f"{VERSION} part P: D run {inp['run']}, {len(inp['feats'])} inputs, {len(inp['folds'])} folds of {K_TARGET}; "
        f"shap {shap.__version__}; tree run {tinfo['run']}")
    fams = k_families(inp["feats"], kd)
    groups = [nm for nm, _ in fams]
    G = p_groups(fams, len(inp["feats"]))
    ts_s, sym_s, sessions, day, y, X = k_load(SD, SB, inp["pp"], inp["feats"], log)
    fits, score = k_fit(SD, X, y, day, sessions, inp["folds"], log)
    g = k_gate(inp["rd"], ts_s, sym_s, day, score)
    log(f" K gate: same top 3 on {100 * g['same_top3_share']:.2f}% of {g['days']:,} days, median rank correlation "
        f"{g['median_rho']:.6f} -> {'PASSED' if g['passed'] else 'FAILED'}")
    run = SL.new_run_dir(bout / "explain", "P")
    info = {"run": run.name, "d_run": inp["run"], "k_gate": g, "tree": tinfo, "inputs": len(inp["feats"]),
            "rows": int(len(day)), "shap": shap.__version__}

    def stop(msg: str, gates: dict):
        info["seconds"] = time.time() - t0
        (run / "PREPORT.md").write_text(p_report_stopped(msg, gates, info, pd_, psha), encoding="utf-8")
        pd.DataFrame([{**{k: v for k, v in gates.items() if not isinstance(v, (list, dict))}}]).to_csv(
            run / "gate.csv", index=False, float_format="%.10g")
        (run / "DECLARATION.json").write_bytes(P_FILE.read_bytes())
        (run / "run.json").write_text(json.dumps({"version": VERSION, "declaration_sha256": psha, "stopped": msg,
                                                  "info": json.loads(json.dumps(info, default=str)),
                                                  "rerun_reason": rerun_reason}, indent=1), encoding="utf-8")
        SL.write_hashes(run, ["PREPORT.md", "gate.csv", "DECLARATION.json", "run.json"])
        with open(bout / LEDGER, "a", encoding="utf-8") as f:
            f.write(json.dumps({"event": "explain", "run": run.name, "at": dt.datetime.now().isoformat(
                timespec="seconds"), "declaration_sha256": psha, "version": VERSION, "stopped": msg,
                "rerun_reason": rerun_reason}) + "\n")
        log(f"STOPPED: {msg} ({run})")
        raise GateFailed(f"part P stopped: {msg}; report in {run}")
    if not g["passed"]:
        stop("the rebuild does not reproduce the frozen scores (part K's gate)", {"k_gate_passed": False, **g})
    try:
        _, tdoc = SL.load_tree()
        listed = SL.etf_list(root)
    except ValueError as e:
        raise WHError(f"setuplab's ETF rule is not usable: {e}")
    etf = SL.tree_etf(sym_s, tdoc, listed)
    picks = p_picks(fits, day, sym_s, score, etf)
    rows, fold, rank = picks
    log(f" P: {len(rows):,} picks on {len(np.unique(day[rows])):,} days; fitting the check versions V1, V2")
    models = []
    for fi, f in enumerate(fits):
        t1 = time.time()
        vs = [p_refit(SD, X, y, day, sessions, inp["folds"][fi], b) for b in P_BOOTS]
        models.append((f["model"], vs[0], vs[1]))
        log(f" P: fold {f['fold']} check versions fitted ({time.time() - t1:.0f}s)")
    try:
        R = p_explain(shap, models, X, day, sym_s, sessions, etf, picks, G, log)
    except PAddError as e:
        stop(str(e), {"k_gate_passed": True, "explanations_add_up": False})
    log(f" P: {R['calls']:,} explanations of {R['rows']:,} rows; largest gap from the score difference "
        f"{R['max_gap']:.2e}")
    top, n = R["top"], len(rows)
    conf = (top[0] == top[1]) & (top[0] == top[2])
    gname = np.array(groups, dtype=object)
    sd = sessions[day[rows]].astype("datetime64[D]")
    Pk = pd.DataFrame({"day": sd, "symbol": sym_s[rows], "fold": [fits[i]["fold"] for i in fold], "rank": rank,
                       "score": score[rows], "reason": gname[top[0]], "v1_top": gname[top[1]],
                       "v2_top": gname[top[2]], "confident": conf,
                       "category": np.where(conf, gname[top[0]], MIXED), "second": gname[R["second"]]})
    Pk["period"] = np.where(sd < P2_START, "P1", "P2")
    for k, nm in enumerate(groups):
        Pk[f"push_{nm}"] = R["push0"][:, k] * 100
    for c in P_CLOSES:
        Pk[f"st_{c}"] = R["status"][:, c - 1]
        Pk[f"top_{c}"] = np.where(R["topc"][:, c - 1] >= 0, gname[np.maximum(R["topc"][:, c - 1], 0)], "")
        Pk[f"push_reason_D{c}"] = R["pushc"][np.arange(n), c - 1, np.maximum(top[0], 0)] * 100
    # the inputs behind each pick (V0, signal day)
    starts, ends = p_bounds(day, len(sessions))
    rs = []
    for i in range(n):
        phi = R["phi0"][i]
        d = int(day[rows[i]])
        blk = np.arange(starts[d], ends[d])
        blk = blk[~etf[blk]]
        for q, j in enumerate(np.argsort(-phi, kind="stable")[:P_TOP_INPUTS]):
            rs.append({"day": sd[i], "symbol": sym_s[rows[i]], "place": q + 1, "input": inp["feats"][j],
                       "group": groups[int(np.argmax(G[j]))], "push": phi[j] * 100,
                       "value": float(X[rows[i], j]), "day_percentile": p_percentile(X[blk, j], float(X[rows[i], j]))})
    RS = pd.DataFrame(rs)
    # outcomes from the bars
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    U, uinfo = read_universe(root, np.unique(sd), log)
    T, binfo = p_assemble(market, U, log)
    T["etf"] = SL.tree_etf(T["symbol"].to_numpy(), tdoc, listed)
    Ud = T.loc[~T["etf"].to_numpy(), ["day"] + list(P_OUT)].groupby("day")[list(P_OUT)].mean()
    Ud.columns = [f"u_{k}" for k in P_OUT]
    Pk = Pk.merge(T[["day", "symbol"] + list(P_OUT)], on=["day", "symbol"], how="left").merge(
        Ud.reset_index(), on="day", how="left")
    for k in P_OUT:
        Pk[f"x_{k}"] = Pk[k].to_numpy(float) - Pk[f"u_{k}"].to_numpy(float)
    tg = p_tree_gate(Pk, TP)
    log(f" outcome gate: the tree holds {tg['in_tree']:,} of {tg['picks']:,} picks; {tg['equal']:,} of {tg['compared']:,} "
        f"give its D1 net ({100 * tg['share']:.2f}%)")
    if not tg["passed"]:
        stop(f"the bars do not give the tree's D1 net (the tree holds {100 * tg['in_tree_share']:.2f}% of the picks, "
             f"{100 * tg['share']:.2f}% equal; needs 95% and 99%)", {"k_gate_passed": True, **tg})
    S = Stat(SL, Pk["day"].to_numpy())
    res = p_tests(S, Pk, groups)
    Pk["first_gone_close"] = res["first_gone"]
    TR = p_transitions(Pk, groups)
    di = S.di(Pk["day"].to_numpy())
    conf_tab = {p: S.mean(di, Pk["confident"].to_numpy(float) * 100,
                          (Pk["period"] == p).to_numpy() if p != "ALL" else np.ones(n, bool))
                for p in ("ALL",) + PERIODS}
    agree = {"V0=V1": float((top[0] == top[1]).mean()), "V0=V2": float((top[0] == top[2]).mean()),
             "V1=V2": float((top[1] == top[2]).mean()), "all three": float(conf.mean())}
    secs = time.time() - t0
    info.update({"seconds": secs, "picks": int(n), "explanations": R["calls"], "explained_rows": R["rows"],
                 "max_gap": R["max_gap"], "outcome_gate": tg, "universe": uinfo, "bars": binfo, "agree": agree})
    C = res["categories"]
    (run / "PREPORT.md").write_text(p_report(Pk, C, res, TR, RS, conf_tab, agree, fams, inp["feats"], info, pd_, psha),
                                    encoding="utf-8")
    keep_cols = ([c for c in Pk.columns if not c.startswith("u_")])
    Pk[keep_cols].to_csv(run / "picks.csv", index=False, float_format="%.10g")
    RS.to_csv(run / "reasons.csv", index=False, float_format="%.10g")
    C.to_csv(run / "categories.csv", index=False, float_format="%.10g")
    TR.to_csv(run / "transitions.csv", index=False, float_format="%.10g")
    tests = [{"test": "T3 reason gone", **{k: v for k, v in res["T3"].items() if k != "by_close"},
              **{f"gone_at_D{c}": v for c, v in res["T3"]["by_close"].items()}},
             {"test": "T4 reason still there", **res["T4"]}]
    pd.DataFrame(tests).to_csv(run / "tests.csv", index=False, float_format="%.10g")
    pd.DataFrame([{"k_gate_passed": True, "same_top3_share": g["same_top3_share"], "median_rho": g["median_rho"],
                   "explanations_add_up": True, "max_gap": R["max_gap"],
                   **{f"outcome_{k}": v for k, v in tg.items() if not isinstance(v, (list, dict))}}]).to_csv(
        run / "gate.csv", index=False, float_format="%.10g")
    (run / "DECLARATION.json").write_bytes(P_FILE.read_bytes())
    verdicts = {"T1": dict(zip(C["category"], C["T1"])), "T2": dict(zip(C["category"], C["T2"])),
                "T3": res["T3"]["verdict"], "T4": res["T4"]["verdict"]}
    meta = {"version": VERSION, "declaration_sha256": psha, "root": str(root), "verdicts": verdicts,
            "confident_pct": conf_tab["ALL"]["stat"], "info": json.loads(json.dumps(info, default=str)),
            "rerun_reason": rerun_reason, "python": sys.version.split()[0], "pandas": pd.__version__,
            "numpy": np.__version__}
    try:
        import sklearn
        meta["sklearn"] = sklearn.__version__
    except ImportError:
        pass
    (run / "run.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    SL.write_hashes(run, ["PREPORT.md", "picks.csv", "reasons.csv", "categories.csv", "transitions.csv", "tests.csv",
                          "gate.csv", "DECLARATION.json", "run.json"])
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"event": "explain", "run": run.name, "at": dt.datetime.now().isoformat(timespec="seconds"),
                            "declaration_sha256": psha, "version": VERSION, "verdicts": verdicts,
                            "rerun_reason": rerun_reason}) + "\n")
    log("RESULT: confident " + _f(conf_tab["ALL"]["stat"], 1, False) + "%; " +
        "; ".join(f"{r['category']} {r['picks']} picks: T1 {r['T1']}, T2 {r['T2']}" for r in C.to_dict("records")) +
        f"; T3 {res['T3']['verdict']}; T4 {res['T4']['verdict']}")
    log(f"DONE -> {run}")
    return run


# ---------------------------------------------------------------------------------------------------- P report
def _pp(x, nd=2) -> str:
    return _f(x, nd)


def p_report_stopped(msg: str, gates: dict, info: dict, pd_: dict, psha: str) -> str:
    L = [f"# whylab part P - why each pick was picked ({info['run']})", "",
         f"{VERSION} | P declaration {psha[:16]} (fixed {pd_['declared_at']}) | D run {info['d_run']}", "",
         f"**STOPPED: {msg}.** No test was judged; nothing measured here can be called D's.", "",
         "Checks:", ""]
    for k, v in gates.items():
        if not isinstance(v, (list, dict)):
            L.append(f"- {k}: {v}")
    L += ["", "Send this report and gate.csv."]
    return "\n".join(L) + "\n"


def p_report(Pk, C, res, TR, RS, conf_tab, agree, fams, feats, info, pd_, psha) -> str:
    g, tg = info["k_gate"], info["outcome_gate"]
    t3, t4 = res["T3"], res["T4"]
    L = [f"# whylab part P - why each pick was picked ({info['run']})", "",
         f"{VERSION} | P declaration {psha[:16]} (fixed {pd_['declared_at']}) | D run {info['d_run']} | "
         f"{info['picks']:,} picks (top 3 a day, ETFs out) | shap {info['shap']} | {info['seconds']:.0f} s", "",
         "Each pick's score was split into how much each of D's inputs pushed it above **the average of 100 other "
         "stocks of the same day** (shap). The pushes were added up by part K's 10 input groups; the group that "
         "pushed most is the pick's **reason**. Two more versions of D, trained on resampled history, explained the "
         "same pick against their own draws of the day's stocks: a pick is **CONFIDENT** when all three name the same "
         "reason, otherwise **MIXED**. Then each pick's reason was checked again at the D1-D5 closes (still there, or "
         "gone). Own move = the pick's return from the D1 open minus the average stock's. Points; 95% intervals.", "",
         "## Checks", "",
         f"- The rebuild is the frozen D: same top 3 on {100 * g['same_top3_share']:.2f}% of {g['days']:,} days, median "
         f"rank correlation {g['median_rho']:.6f} -> PASSED.",
         f"- Every explanation adds up to the score difference: {info['explanations']:,} explanations, largest gap "
         f"{info['max_gap']:.2e} (allowed 1e-7 + 1e-6 x score).",
         f"- Outcomes: the tree holds {tg['in_tree']:,} of {tg['picks']:,} picks ({100 * tg['in_tree_share']:.2f}%); "
         f"{tg['equal']:,} of {tg['compared']:,} give its D1 net ({100 * tg['share']:.2f}%) -> PASSED.", "",
         "## How sure is the reason?", "",
         f"- CONFIDENT: {_s(conf_tab['ALL'], 1, False, '%')} of picks (2020-23 {_s(conf_tab['P1'], 1, False, '%')}, "
         f"2024-26 {_s(conf_tab['P2'], 1, False, '%')}).",
         "- Versions agreeing: " + ", ".join(f"{k} {100 * v:.1f}%" for k, v in agree.items()) + "."]
    mx = Pk[~Pk["confident"]]
    if len(mx):
        pairs = (mx["reason"] + " / " + mx["second"]).value_counts().head(5)
        L.append("- MIXED picks' top two groups (V0), most common: " +
                 "; ".join(f"{k} ({v})" for k, v in pairs.items()) + ".")
    L += ["", "## The kinds of pick", "",
          "| category | picks 2020-23 / 2024-26 (share of the period's picks) | own move to D5, 2020-23 | 2024-26 | "
          "T1 vs the other picks "
          "2020-23 / 2024-26 | T1 | T2 best hold (chosen on 2020-23) | T2 2024-26: its edge a day minus D5's | T2 |",
          "|---|---|---|---|---|---|---|---|---|"]
    per_n = {p: max(int((Pk["period"] == p).sum()), 1) for p in PERIODS}
    Co = C.assign(_m=(C["category"] == MIXED)).sort_values(["_m", "picks"], ascending=[True, False], kind="stable")
    for r in Co.to_dict("records"):
        j_ = bool(r["judged"])
        sh = {p: 100 * int(((Pk["category"] == r["category"]) & (Pk["period"] == p)).sum()) / per_n[p] for p in PERIODS}
        t1 = (f"{_pp(r['t1_P1'])} [{_pp(r['t1_lo_P1'])}, {_pp(r['t1_hi_P1'])}] / {_pp(r['t1_P2'])} "
              f"[{_pp(r['t1_lo_P2'])}, {_pp(r['t1_hi_P2'])}]") if j_ else "-"
        t2 = (f"{_pp(r['t2_P2'], 3)} [{_pp(r['t2_lo'], 3)}, {_pp(r['t2_hi'], 3)}]" if j_ and r["k_star"] != 5 else "-")
        L.append(f"| {r['category']} | {r['picks_P1']:,} ({sh['P1']:.0f}%) / {r['picks_P2']:,} ({sh['P2']:.0f}%) | "
                 f"{_pp(r['own5_P1'])} [{_pp(r['own5_lo_P1'])}, "
                 f"{_pp(r['own5_hi_P1'])}] | {_pp(r['own5_P2'])} [{_pp(r['own5_lo_P2'])}, {_pp(r['own5_hi_P2'])}] | "
                 f"{t1} | **{r['T1']}** | {'D' + str(r['k_star']) if j_ else '-'} | {t2} | **{r['T2']}** |")
    L += ["", "Edge a day = (own move to the exit - 0.35) / days held. A category is judged with at least "
          f"{P_MIN} picks in each period.", "", "Own move by close, all picks of the category, D1 .. D10:", ""]
    for r in Co.to_dict("records"):
        L.append(f"- {r['category']}: " + ", ".join(_pp(r[f'own_D{k}']) for k in range(1, KMAX + 1)))
    L += ["", "## Transitions: is the reason still there?", "",
          "The pick is explained again at each close by its own fold's model. STILL THERE = the reason's group still "
          "pushes it above the day's average stock.", "",
          "| category | picks | still there at D1 / D2 / D3 / D4 / D5 close | top group unchanged at D5 | "
          "unknown at D5 |", "|---|---|---|---|---|"]
    for c in TR["category"].unique():
        t = TR[TR["category"] == c].set_index("close")
        L.append(f"| {c} | {int(t['picks'].iloc[0]):,} | " +
                 " / ".join(f"{t.loc[f'D{k}', 'still_there_pct']:.0f}%" for k in P_CLOSES) +
                 f" | {t.loc['D5', 'same_top_group_pct']:.0f}% | {t.loc['D5', 'unknown_pct']:.0f}% |")
    L += ["", f"**T3 - when the reason is gone, sell early? -> {t3['verdict']}**", "",
          "Picks whose reason is gone at a D1-D4 close (the first such close: " +
          ", ".join(f"D{c} {v:,}" for c, v in t3["by_close"].items()) +
          "): own move from the next open to the D5 close - what selling at that open would have given up (below 0: "
          "selling there would have saved it). "
          f"2020-23 {_pp(t3['stat_P1'])} [{_pp(t3['lo_P1'])}, {_pp(t3['hi_P1'])}] ({t3['n_P1']:,} picks); "
          f"2024-26 {_pp(t3['stat_P2'])} [{_pp(t3['lo_P2'])}, {_pp(t3['hi_P2'])}] ({t3['n_P2']:,} picks). "
          "EXIT EARLY needs both intervals below 0.", "",
          f"**T4 - when the reason is still there at D5, hold longer? -> {t4['verdict']}**", "",
          "Picks whose reason is still there at the D5 close: own move D5 close to D10 close, minus what the freed "
          "money makes in a new pick (own move to D5 - 0.35). "
          f"2020-23 {_pp(t4['held_P1'])} - {_pp(t4['new_P1'])} = {_pp(t4['stat_P1'])} [{_pp(t4['lo_P1'])}, "
          f"{_pp(t4['hi_P1'])}] ({t4['n_P1']:,} picks); 2024-26 {_pp(t4['held_P2'])} - {_pp(t4['new_P2'])} = "
          f"{_pp(t4['stat_P2'])} [{_pp(t4['lo_P2'])}, {_pp(t4['hi_P2'])}] ({t4['n_P2']:,} picks). HOLD LONGER needs "
          "both intervals above 0.", "",
          "## The latest picks and their reasons", "",
          "| signal day | stock | category | reason's push | the inputs pushing it up most (value; percentile that day; "
          "push) |",
          "|---|---|---|---|---|"]
    last = Pk.sort_values(["day", "rank"]).tail(15)
    for r in last.to_dict("records"):
        xs = RS[(RS["day"] == r["day"]) & (RS["symbol"] == r["symbol"]) & (RS["push"] > 0)].head(3)
        tops = "; ".join(f"{q['input']} = {q['value']:.4g} ({100 * q['day_percentile']:.0f}th) {_pp(q['push'], 3)}"
                         for q in xs.to_dict("records"))
        cat = r["category"] if r["confident"] else f"MIXED ({r['reason']} / {r['second']})"
        L.append(f"| {pd.Timestamp(r['day']).date()} | {r['symbol']} | {cat} | "
                 f"{_pp(r['push_' + r['reason']], 3)} | {tops} |")
    L += ["", "## The groups", ""]
    for nm, cols in fams:
        L.append(f"- **{nm}** ({len(cols)}): " + ", ".join(feats[j] for j in cols))
    L += ["", "Pushes are in points of D's 5-day score above the comparison stocks' average. Inputs that are the same "
          "for every stock on a day push 0. Nothing here changes the paper test's plan; a category that passes is a "
          "candidate, judged next by the forward paper test.", ""]
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------------------------------- today
def p_prod(root: Path):
    """PRODUCTION.json and D.pkl, checked as production_models.load_verified checks them."""
    d = root / "panel_oc" / "frozen" / "production"
    mp = d / "PRODUCTION.json"
    if not mp.is_file():
        raise WHError(f"{mp} not found - production_models.py train has not run")
    meta = json.loads(mp.read_text(encoding="utf-8"))
    import sklearn
    now = {"sklearn": sklearn.__version__, "numpy": np.__version__}
    for lib in ("sklearn", "numpy"):
        then = meta.get("libraries", {}).get(lib)
        if then and then != now[lib]:
            raise WHError(f"{lib} is {now[lib]} but D.pkl was trained under {then} - refusing (pickles are "
                          f"version-bound; never upgrade it during the paper test)")
    m = meta.get("models", {}).get("D")
    if not m:
        raise WHError("PRODUCTION.json lists no D model")
    fp = d / m["file"]
    if not fp.is_file() or sha256(fp) != m["sha256"]:
        raise WHError(f"production model D ({fp}) is missing or changed since it was frozen")
    import pickle
    with open(fp, "rb") as f:
        model = pickle.load(f)
    return meta, model, m["sha256"]


def p_checks(SD, SB, root: Path, meta: dict, V0, dsha: str, bout: Path, log=say):
    """The two check versions of the production model: built once (production's recipe, bootstrap draws), only after
    the same code reproduces D.pkl; then reused, every file checked."""
    import pickle
    cdir = bout / "today" / "checks" / dsha[:16]
    cj = cdir / "CHECKS.json"
    if cj.is_file():
        ci = json.loads(cj.read_text(encoding="utf-8"))
        out = []
        for b in P_BOOTS:
            fp = cdir / f"V{b}.pkl"
            if not fp.is_file() or sha256(fp) != ci.get("files", {}).get(fp.name):
                raise WHError(f"check version {fp.name} is missing or changed - delete {cdir} to build it again")
            with open(fp, "rb") as f:
                out.append(pickle.load(f))
        return out, ci, False
    from sklearn.ensemble import HistGradientBoostingRegressor
    log(" today: building the two check versions once (production's recipe on resampled history)")
    pp = root / "panel_oc" / "panel.parquet"
    man = json.loads((root / "panel_oc" / "frozen" / "FROZEN_ENGINES.json").read_text(encoding="utf-8"))
    target = man.get("target")
    if target != K_TARGET:
        raise WHError(f"FROZEN_ENGINES.json's target is {target}, not {K_TARGET}")
    md = meta["models"]["D"]
    feats = list(md["features"])
    b_ = pd.read_parquet(pp, columns=["timestamp", "symbol", SB.ELIG_COL, target])
    ts = np.asarray(SB._naive(b_["timestamp"])).astype("datetime64[ns]")
    buy = pd.to_numeric(b_[SB.ELIG_COL], errors="coerce").to_numpy(float)
    yy = pd.to_numeric(b_[target], errors="coerce").to_numpy(float)
    del b_
    rows = np.flatnonzero(SD.eligible_mask(buy) & np.isfinite(yy))
    day = np.searchsorted(np.unique(ts), ts)
    if len(rows) != int(md.get("train_rows", -1)):
        raise WHError(f"the research panel has {len(rows):,} resolved eligible rows but D.pkl was trained on "
                      f"{md.get('train_rows')} - the check versions cannot be built on D's rows")
    X = np.empty((len(rows), len(feats)), dtype=np.float32)
    for j, f in enumerate(feats):
        X[:, j] = SB._read_col(pp, f)[rows]
    cfg = SD.CFG
    seed = [int(s) for s in meta.get("seed", [])]
    lab, _, _ = SD.make_label(yy[rows], day[rows], cfg["winsor_pct"])

    def fit(keep):
        return HistGradientBoostingRegressor(random_state=cfg["seed"], **cfg["hgb"]).fit(X[keep], lab[keep])
    rng = np.random.default_rng(seed)
    keep = (np.arange(len(rows)) if len(rows) <= cfg["fit_cap"]
            else np.sort(rng.choice(len(rows), cfg["fit_cap"], replace=False)))
    m0 = fit(keep)
    probe = np.sort(np.random.default_rng(0).choice(len(rows), min(2000, len(rows)), replace=False))
    diff = float(np.max(np.abs(m0.predict(X[probe]) - V0.predict(X[probe]))))
    if not diff <= P_REPRO_TOL:
        raise WHError(f"production's recipe rebuilt here does not reproduce D.pkl (largest difference {diff:.3g}) - "
                      f"check versions built this way would not be D's; refusing")
    cdir.mkdir(parents=True, exist_ok=True)
    out, files = [], {}
    for b in P_BOOTS:
        r2 = np.random.default_rng(seed + [b])
        m = fit(np.sort(r2.choice(len(rows), min(cfg["fit_cap"], len(rows)), replace=True)))
        fp = cdir / f"V{b}.pkl"
        with open(fp, "wb") as f:
            pickle.dump(m, f, protocol=pickle.HIGHEST_PROTOCOL)
        files[fp.name] = sha256(fp)
        out.append(m)
    import sklearn
    ci = {"version": VERSION, "built_at": dt.datetime.now().isoformat(timespec="seconds"), "d_sha256": dsha,
          "seed": seed, "boots": list(P_BOOTS), "train_rows": int(len(rows)), "reproduced_max_diff": diff,
          "libraries": {"sklearn": sklearn.__version__, "numpy": np.__version__}, "files": files}
    cj.write_text(json.dumps(ci, indent=1), encoding="utf-8")
    log(f" today: D.pkl reproduced (largest difference {diff:.2g}); check versions saved in {cdir}")
    return out, ci, True


def p_live_path(root: Path, live: Optional[str]) -> Path:
    if live:
        p = Path(live)
    else:
        try:
            import paper_pipeline as PP
            p = Path(PP.paths(root)["live"])
        except Exception as e:                                              # noqa: BLE001
            raise WHError(f"cannot find the live panel through production's paper_pipeline.paths ({e}) - pass "
                          f"--live <the live panel.parquet>")
    if not p.is_file():
        raise WHError(f"the live panel {p} not found")
    return p


def p_read_live(SB, live: Path, feats: List[str], n: int = P_LIVE_SESSIONS) -> pd.DataFrame:
    """The last n sessions of the live panel: timestamp, symbol and D's inputs, sorted by (session, symbol)."""
    import pyarrow.compute as pc
    import pyarrow.dataset as pds
    import pyarrow.parquet as pq
    names = set(pq.read_schema(live).names)
    miss = [c for c in ["timestamp", "symbol"] + feats if c not in names]
    if miss:
        raise WHError(f"the live panel {live} lacks {len(miss)} of D's columns, e.g. {miss[:5]}")
    t = pq.read_table(live, columns=["timestamp"]).column("timestamp").combine_chunks()
    u = pc.unique(t)
    if not len(u):
        raise WHError(f"the live panel {live} is empty")
    u = u.take(pc.sort_indices(u))
    thr = u[max(0, len(u) - n)]
    tbl = pds.dataset(str(live), format="parquet").to_table(columns=["timestamp", "symbol"] + feats,
                                                             filter=pc.field("timestamp") >= thr)
    F = tbl.to_pandas()
    F["ts"] = np.asarray(SB._naive(F["timestamp"])).astype("datetime64[ns]")
    F["symbol"] = F["symbol"].astype(str)
    if F.duplicated(["ts", "symbol"]).any():
        raise WHError(f"the live panel {live} holds a stock twice on one session - refusing")
    return F.sort_values(["ts", "symbol"], kind="stable").reset_index(drop=True)


def today_execute(SL, root: Path, bout: Path, live: Optional[str] = None, log=say) -> Path:
    t0 = time.time()
    pd_, psha = load_p()
    kd, ksha = load_k()
    shap = p_shap()
    SD, SB = k_modules()
    meta, V0, dsha = p_prod(root)
    feats = list(meta["models"]["D"]["features"])
    fams = k_families(feats, kd)
    groups = [nm for nm, _ in fams]
    G = p_groups(fams, len(feats))
    (V1, V2), ci, built = p_checks(SD, SB, root, meta, V0, dsha, bout, log)
    lp = p_live_path(root, live)
    F = p_read_live(SB, lp, feats)
    X = F[feats].to_numpy(np.float32)
    sym, ts = F["symbol"].to_numpy(), F["ts"].to_numpy()
    sess = np.unique(ts)
    day = np.searchsorted(sess, ts)
    try:
        _, tdoc = SL.load_tree()
        listed = SL.etf_list(root)
    except ValueError as e:
        raise WHError(f"setuplab's ETF rule is not usable: {e}")
    etf = SL.tree_etf(sym, tdoc, listed)
    score = V0.predict(X)
    rk = day_ranks(day, sym, np.where(etf, -np.inf, score))
    pick = (rk < 3) & ~etf
    nS = len(sess)
    T0 = nS - 1
    starts, ends = p_bounds(day, nS)
    E = [PExplainer(shap, m) for m in (V0, V1, V2)]

    def draw(v, d):
        r = np.arange(starts[d], ends[d])
        r = r[~etf[r] & ~pick[r]]
        return p_draw(v, p_ymd(sess[d]), r)
    gname = np.array(groups, dtype=object)
    new = np.flatnonzero(pick & (day == T0))
    new = new[np.argsort(rk[new], kind="stable")]
    pg = [E[v](X[new], X[draw(v, T0)]) @ G for v in range(3)]
    phi0 = E[0](X[new], X[draw(0, T0)])
    blk = np.arange(starts[T0], ends[T0])
    blk = blk[~etf[blk]]
    rows_out, L = [], []
    sdate = pd.Timestamp(sess[T0]).date()
    L += [f"# whylab today - D's picks on the {sdate} close", "",
          f"{VERSION} | D.pkl {dsha[:16]} | check versions {'built now' if built else 'built ' + ci['built_at']} | "
          f"live panel {lp} | {time.time() - t0:.0f} s", "",
          "**Research only: the paper test's plan is unchanged.** Pushes = points of D's 5-day score above the average "
          "of 100 other stocks of the same session.", "", "## Today's picks (buy at the next open in D's plan)", ""]
    for q, i in enumerate(new):
        tops = [int(np.argmax(pg[v][q])) for v in range(3)]
        conf = tops[0] == tops[1] == tops[2]
        order = np.argsort(-pg[0][q], kind="stable")
        cat = gname[tops[0]] if conf else MIXED
        ins = [j for j in np.argsort(-phi0[q], kind="stable")[:P_TOP_INPUTS] if phi0[q][j] > 0]
        L.append(f"**{int(rk[i]) + 1}. {sym[i]}** (score {score[i] * 100:+.3f}): " +
                 (f"**{cat}** - CONFIDENT (all three versions agree)" if conf else
                  f"**MIXED** - versions say {', '.join(gname[t] for t in tops)}"))
        L.append("- pushes: " + ", ".join(f"{gname[k]} {pg[0][q][k] * 100:+.3f}" for k in order[:4]))
        L.append("- the inputs pushing it up most: " + "; ".join(
            f"{feats[j]} = {X[i, j]:.4g} ({100 * p_percentile(X[blk, j], float(X[i, j])):.0f}th percentile today) "
            f"{phi0[q][j] * 100:+.3f}" for j in ins))
        rows_out.append({"kind": "new", "session": str(sdate), "symbol": sym[i], "rank": int(rk[i]) + 1,
                         "score": score[i], "reason": gname[tops[0]], "v1_top": gname[tops[1]],
                         "v2_top": gname[tops[2]], "confident": conf, "category": cat,
                         **{f"push_{g_}": pg[0][q][k] * 100 for k, g_ in enumerate(groups)}})
    L += ["", "## Picks still held: is the reason still there at this close?", ""]
    for d in range(max(0, T0 - 5), T0):
        pr = np.flatnonzero(pick & (day == d))
        if not len(pr):
            continue
        pr = pr[np.argsort(rk[pr], kind="stable")]
        p0 = E[0](X[pr], X[draw(0, d)]) @ G
        rows_now = []
        for i in pr:
            j = np.searchsorted(sym[starts[T0]:ends[T0]], sym[i])
            rows_now.append(starts[T0] + j if j < ends[T0] - starts[T0] and sym[starts[T0] + j] == sym[i] else -1)
        rows_now = np.array(rows_now)
        okr = rows_now >= 0
        pn = np.full((len(pr), len(groups)), np.nan)
        if okr.any():
            pn[okr] = E[0](X[rows_now[okr]], X[draw(0, T0)]) @ G
        k_day = T0 - d
        for q, i in enumerate(pr):
            g0 = int(np.argmax(p0[q]))
            if okr[q]:
                v_ = pn[q, g0]
                stt = THERE if v_ > 0 else GONE
                now = gname[int(np.argmax(pn[q]))]
            else:
                v_, stt, now = np.nan, UNKNOWN, ""
            L.append(f"- {sym[i]} (picked on the {pd.Timestamp(sess[d]).date()} close, D{k_day} today"
                     f"{' - sold at this close in D' + chr(39) + 's plan' if k_day == 5 else ''}): reason "
                     f"{gname[g0]} ({p0[q][g0] * 100:+.3f} then) - **{STATUS[stt]}**" +
                     (f" ({v_ * 100:+.3f} now); today's top group {now}" if okr[q] else " (no row this session)"))
            rows_out.append({"kind": "held", "session": str(pd.Timestamp(sess[d]).date()), "symbol": sym[i],
                             "rank": int(rk[i]) + 1, "score": score[i], "reason": gname[g0], "day_now": k_day,
                             "status_now": STATUS[stt], "reason_push_now": v_ * 100 if np.isfinite(v_) else np.nan,
                             "top_group_now": now})
    L += ["", "STILL THERE = the reason's group still pushes the stock above the session's average stock; GONE = it no "
          "longer does. Whether that should change the exit is part P's T3/T4 (run `explain`).", ""]
    od = bout / "today"
    od.mkdir(parents=True, exist_ok=True)
    name = f"TODAY_{pd.Timestamp(sess[T0]):%Y%m%d}"
    (od / f"{name}.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    pd.DataFrame(rows_out).to_csv(od / f"{name}.csv", index=False, float_format="%.10g")
    print("\n".join(L), flush=True)
    log(f"DONE -> {od / (name + '.md')}")
    return od / f"{name}.md"


# ==================================================================================== PART T (v1.4)
# What triggered each pick's move, in the pick's own indicators. Part P's picks and top inputs; each input translated
# to the readable indicator behind it; that indicator's triggers followed from the signal day to D10 (the market's next
# 10 sessions) on the stock's own daily bars; the move = the first close 1 ATR above the D1 open. Per kind, never
# pooled: how often each trigger came before the move (shown), and whether the move came sooner after it than after
# closes where it could have fired but did not, at the same close after the pick and the same distance from the target,
# in both periods and after the many-tests check (judged).
T_FILE = HERE / "WHY_T_DECLARATION.json"
T_SHA = "f6825bc20d149b6dd018eab3f63d580db3d60355d06efaf15dadef271f51b033"
T_OLD_SHA = "7a23786a1a801af09a4979fa7a93d930be613aa86ac985b15d9b785e43e702ec"   # 15 Nov 11:27 (v1.3), replaced, never run
T_DAYS = 10
T_HORIZON = 3
T_LAST = 7
T_BINS = np.array([0.25, 0.5, 0.75, 1.0, 1.5, 2.0])
T_MIN = 100
T_R5_TOL = 1e-6
T_GATE = 0.99
T_FDR = 0.05
LEFT_OUT = "left out"
T_TRANSLATE = (
    (LEFT_OUT, r"^mkt_|^x_universe|_ret_1d$|^(d_)?dow(_|\d|$)|^comb_|wq_|days_since|_run$|_code$"),
    ("RSI-14", r"rsi"),
    ("MACD", r"macd"),
    ("ADX / DI", r"adx|pdi|mdi"),
    ("EMA-20 slope", r"ema20_angle|close_roll_slope|slope_stability|ema_stack|_trend$"),
    ("Bollinger bands", r"bb_"),
    ("52-week range", r"52w|drawdown_252"),
    ("20-day range", r"donch|dist_from_20|breakout_"),
    ("4/13-week momentum", r"w_ret_|ret_13w|ret_4w"),
    ("volume", r"vol_surge|dvol|vol_z|vol_vs|cmf|obv|turnover|dollar_vol|amihud"),
    ("candle", r"intraday_ret|gap_pct|body_ratio|wick|inside_day|nr_|_nr$|oli|overnight"),
    ("ATR / volatility", r"atr|realvol|range_pct|range_to|vol_yz|downside_dev|roll_std|relvol|upside_vol|n_5pct|"
                         r"compress|skew|kurt|rstd|cpr_width"),
)
T_TRIGGERS = {
    "EMA-20 slope": (("ema_slope_up", "EMA-20 slope rises"), ("ema_cross", "close crosses above EMA-20")),
    "RSI-14": (("rsi_30", "RSI-14 crosses above 30"), ("rsi_50", "RSI-14 crosses above 50")),
    "MACD": (("macd_cross", "MACD crosses above its signal"),),
    "ADX / DI": (("di_cross", "+DI crosses above -DI"),),
    "Bollinger bands": (("bb_mid", "close crosses above the middle band"), ("bb_widen", "band width widens 10%+")),
    "52-week range": (("hi52_new", "new 52-week closing high"), ("hi52_near", "close comes within 5% of the 52-week high"),
                      ("lo52_new", "new 52-week closing low")),
    "20-day range": (("hi20_break", "close above the previous 20-day high"),),
    "4/13-week momentum": (("roc20_up", "4-week return crosses above 0 (ROC 20)"),
                           ("roc65_up", "13-week return crosses above 0 (ROC 65)"),
                           ("hi65_new", "new 13-week closing high")),
    "volume": (("vol_15", "volume above 1.5x its 20-day average"), ("obv_hi20", "OBV above its previous 20-day high")),
    "ATR / volatility": (("tr_15", "true range above 1.5x ATR"), ("atr5_20", "5-day ATR crosses above the 20-day")),
    "candle": (("bull_close", "bullish close (top quarter of the range)"), ("gap_up", "gap up above the previous high")),
}
T_YARD = (("y_prev_high", "close above the previous day's high"), ("y_vol15", "volume above 1.5x its 20-day average"))
T_KEYS = [k for trs in T_TRIGGERS.values() for k, _ in trs] + [k for k, _ in T_YARD]
T_LABEL = {**{k: lab for trs in T_TRIGGERS.values() for k, lab in trs}, **dict(T_YARD)}
T_IND_OF = {**{k: ind for ind, trs in T_TRIGGERS.items() for k, _ in trs}, **{k: "yardstick" for k, _ in T_YARD}}
T_CROSS = ("ema_cross", "rsi_30", "rsi_50", "macd_cross", "di_cross", "bb_mid", "hi52_near", "roc20_up", "roc65_up",
           "atr5_20")
T_VALUES = ("EMA-20 slope %/day", "RSI-14", "BB width %", "52w position %", "from 52w high %", "20-day position %",
            "4-week return %", "13-week return %", "volume / 20d avg", "ATR %", "+DI - -DI", "MACD hist %",
            "close location %", "gap %")
T_SOURCES = ("own daily", "cross-sectional or weekly", "left out")


def load_t(path: Path = T_FILE) -> Tuple[dict, str]:
    sha = sha256(path)
    if sha != T_SHA:
        raise WHError(f"{Path(path).name} has sha256 {sha[:16]}, not the pinned {T_SHA[:16]} - the declaration is "
                      f"fixed before any run; restore the shipped file")
    return json.loads(Path(path).read_text(encoding="utf-8")), sha


def t_translate(name: str) -> str:
    """The readable indicator behind one of D's inputs (first matching pattern), or LEFT_OUT."""
    s = str(name).lower()
    for ind, pat in T_TRANSLATE:
        if re.search(pat, s):
            return ind
    return LEFT_OUT


def t_source(name: str) -> str:
    """How an input is followed: the stock's own daily input through its indicator family; a cross-sectional (X_) or
    weekly (W_) input through the stock's own daily indicator; or not at all."""
    if t_translate(name) == LEFT_OUT:
        return "left out"
    return "cross-sectional or weekly" if re.match(r"^(x_|w_)", str(name).lower()) else "own daily"


def _pine_avg(x: np.ndarray, n: int, alpha: float) -> np.ndarray:
    """TradingView's recursive averages (ta.ema: alpha 2/(n+1); ta.rma: 1/n): blank until n values in a row exist;
    there the simple average of those n; then a = alpha * x + (1 - alpha) * a[-1]."""
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    fin = np.isfinite(x)
    run = np.convolve(fin.astype(float), np.ones(n), "full")[:len(x)] if len(x) else np.array([])
    st = np.flatnonzero(run >= n)
    if not len(st):
        return out
    s = int(st[0])
    seg = x[s:].copy()
    seg[0] = x[s - n + 1:s + 1].mean()
    out[s:] = pd.Series(seg).ewm(alpha=alpha, adjust=False, ignore_na=True).mean().to_numpy()
    out[s:][~np.isfinite(seg)] = np.nan
    return out


def _prev_roll(x: np.ndarray, n: int, how: str) -> np.ndarray:
    """max / min / mean of the previous n values (today left out)."""
    s = pd.Series(np.asarray(x, float)).shift(1).rolling(n, min_periods=n)
    return {"max": s.max, "min": s.min, "mean": s.mean}[how]().to_numpy()


def t_series(o, h, l, c, v):
    """From one stock's daily bars: every trigger (True at a close where it fires); where it could have fired (a
    crossing: both lines exist and the line was at or below at the previous close; any other trigger: its inputs
    exist); every readable value; the ATR. A trigger fires only where it could have."""
    o, h, l, c, v = (np.asarray(a, float) for a in (o, h, l, c, v))
    n = len(c)
    fin = np.isfinite
    prev = lambda a: np.r_[np.nan, a[:-1]] if n else a                                       # noqa: E731
    lag = lambda a, k: np.r_[np.full(min(k, n), np.nan), a[:max(n - k, 0)]]                 # noqa: E731
    pc, ph, pl = prev(c), prev(h), prev(l)
    tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
    tr[0:1] = np.nan
    atr = pd.Series(tr).rolling(14, min_periods=14).mean().to_numpy()
    ema = _pine_avg(c, 20, 2 / 21)
    d_ema = ema - prev(ema)
    ch = c - pc
    up, dn = _pine_avg(np.where(np.isfinite(ch), np.maximum(ch, 0), np.nan), 14, 1 / 14), \
        _pine_avg(np.where(np.isfinite(ch), np.maximum(-ch, 0), np.nan), 14, 1 / 14)
    with np.errstate(invalid="ignore", divide="ignore"):
        rsi = np.where(dn == 0, 100.0, np.where(up == 0, 0.0, 100 - 100 / (1 + up / dn)))
    rsi[~(np.isfinite(up) & np.isfinite(dn))] = np.nan
    macd = _pine_avg(c, 12, 2 / 13) - _pine_avg(c, 26, 2 / 27)
    sig = _pine_avg(macd, 9, 2 / 10)
    upm, dnm = h - ph, pl - l
    pdm = np.where(np.isfinite(upm), np.where((upm > dnm) & (upm > 0), upm, 0.0), np.nan)
    mdm = np.where(np.isfinite(dnm), np.where((dnm > upm) & (dnm > 0), dnm, 0.0), np.nan)
    rtr = _pine_avg(tr, 14, 1 / 14)
    with np.errstate(invalid="ignore", divide="ignore"):
        pdi, mdi = 100 * _pine_avg(pdm, 14, 1 / 14) / rtr, 100 * _pine_avg(mdm, 14, 1 / 14) / rtr
        roc20, roc65 = c / lag(c, 20) - 1, c / lag(c, 65) - 1
    cs = pd.Series(c)
    basis = cs.rolling(20, min_periods=20).mean().to_numpy()
    sd = cs.rolling(20, min_periods=20).std(ddof=0).to_numpy()
    with np.errstate(invalid="ignore", divide="ignore"):
        width = 4 * sd / basis
    hi52 = cs.rolling(252, min_periods=252).max().to_numpy()
    lo52 = cs.rolling(252, min_periods=252).min().to_numpy()
    prev252, prev252lo, prev65 = _prev_roll(c, 252, "max"), _prev_roll(c, 252, "min"), _prev_roll(c, 65, "max")
    hi20p = _prev_roll(h, 20, "max")
    v20p = _prev_roll(v, 20, "mean")
    obv = np.cumsum(np.nan_to_num(np.sign(ch)) * np.nan_to_num(v))
    obv20p = _prev_roll(obv, 20, "max")
    trs = pd.Series(tr)
    a5, a20 = trs.rolling(5, min_periods=5).mean().to_numpy(), trs.rolling(20, min_periods=20).mean().to_numpy()
    rng = h - l
    zero = np.zeros(n)
    with np.errstate(invalid="ignore", divide="ignore"):
        def could(a, b):            # a crossing: both lines exist, and the line was at or below at the previous close
            return fin(a) & fin(b) & (prev(a) <= prev(b))
        crosses = {"ema_cross": (c, ema), "rsi_30": (rsi, zero + 30), "rsi_50": (rsi, zero + 50),
                   "macd_cross": (macd, sig), "di_cross": (pdi, mdi), "bb_mid": (c, basis), "roc20_up": (roc20, zero),
                   "roc65_up": (roc65, zero), "atr5_20": (a5, a20)}
        can = {k: could(a, b) for k, (a, b) in crosses.items()}
        ev = {k: can[k] & (a > b) for k, (a, b) in crosses.items()}
        can["hi52_near"] = fin(c) & fin(hi52) & fin(pc) & fin(prev(hi52)) & ~(pc >= 0.95 * prev(hi52))
        ev["hi52_near"] = can["hi52_near"] & (c >= 0.95 * hi52)
        other = {"ema_slope_up": (fin(d_ema) & fin(prev(d_ema)), d_ema > prev(d_ema)),
                 "bb_widen": (fin(width) & fin(prev(width)), width >= 1.1 * prev(width)),
                 "hi52_new": (fin(c) & fin(prev252), c > prev252),
                 "lo52_new": (fin(c) & fin(prev252lo), c < prev252lo),
                 "hi20_break": (fin(c) & fin(hi20p), c > hi20p),
                 "hi65_new": (fin(c) & fin(prev65), c > prev65),
                 "vol_15": (fin(v) & fin(v20p), v > 1.5 * v20p),
                 "obv_hi20": (fin(obv20p), obv > obv20p),
                 "tr_15": (fin(tr) & fin(prev(atr)), tr > 1.5 * prev(atr)),
                 "bull_close": (fin(o) & fin(h) & fin(l) & fin(c), (c > o) & (rng > 0) & (c - l >= 0.75 * rng)),
                 "gap_up": (fin(o) & fin(ph), o > ph),
                 "y_prev_high": (fin(c) & fin(ph), c > ph),
                 "y_vol15": (fin(v) & fin(v20p), v > 1.5 * v20p)}
        for k, (cn, cond) in other.items():
            can[k], ev[k] = cn, cn & cond
        h20 = pd.Series(h).rolling(20, min_periods=20).max().to_numpy()
        l20 = pd.Series(l).rolling(20, min_periods=20).min().to_numpy()
        val = {"EMA-20 slope %/day": (ema / prev(ema) - 1) * 100, "RSI-14": rsi, "BB width %": width * 100,
               "52w position %": (c - lo52) / (hi52 - lo52) * 100, "from 52w high %": (c / hi52 - 1) * 100,
               "20-day position %": (c - l20) / (h20 - l20) * 100, "4-week return %": roc20 * 100,
               "13-week return %": roc65 * 100, "volume / 20d avg": v / v20p, "ATR %": atr / c * 100,
               "+DI - -DI": pdi - mdi, "MACD hist %": (macd - sig) / c * 100, "close location %": (c - l) / rng * 100,
               "gap %": (o / pc - 1) * 100}
    ev = {k: np.asarray(ev[k], bool) for k in T_KEYS}
    can = {k: np.asarray(can[k], bool) for k in T_KEYS}
    val = {k: np.where(np.isfinite(a), a, np.nan) for k, a in val.items()}
    return ev, can, val, atr


def t_find_p_run(bout: Path, p_run: Optional[str]) -> Path:
    """The part P run to build on: --p-run, else the newest complete P run under WHYLAB_OUT\\explain."""
    if p_run:
        d = Path(p_run)
        if not d.is_dir():
            d = bout / "explain" / p_run
        cands = [d]
    else:
        cands = sorted((bout / "explain").glob("P_*"), reverse=True) if (bout / "explain").is_dir() else []
    for d in cands:
        rj = d / "run.json"
        if not (d / "picks.csv").is_file() or not rj.is_file():
            continue
        meta = json.loads(rj.read_text(encoding="utf-8"))
        if meta.get("declaration_sha256") != P_SHA or meta.get("stopped"):
            continue
        hf = d / "outputs.sha256"
        if not hf.is_file():
            raise WHError(f"{d} has no outputs.sha256")
        want = dict(reversed(ln.split("  ", 1)) for ln in hf.read_text(encoding="utf-8").splitlines() if "  " in ln)
        for nm in ("picks.csv", "reasons.csv", "run.json"):
            if nm not in want or sha256(d / nm) != want[nm]:
                raise WHError(f"{d / nm} does not match its recorded sha256 - part P's outputs changed after the run")
        return d
    raise WHError("no finished part P run found (run `explain` first, or pass --p-run <its folder>)")


def t_collect(market, P: pd.DataFrame, log=say, chunk: int = 100) -> dict:
    """Each pick's bars D0..D10 with every trigger, where it could have fired, every readable value at each close, and
    its ATR. D1..D10 must be the market calendar's next 10 sessions after the signal day; otherwise the pick is left
    out ('calendar'), as it is without the bars ('no bars') or the signal-day ATR ('no ATR')."""
    n, K = len(P), T_DAYS + 1
    EV = np.zeros((n, K, len(T_KEYS)), bool)
    CAN = np.zeros((n, K, len(T_KEYS)), bool)
    why = np.full(n, "no bars", dtype=object)
    VAL = np.full((n, K, len(T_VALUES)), np.nan)
    OHLC = np.full((n, K, 4), np.nan)
    DATES = np.full((n, K), np.datetime64("NaT"), dtype="datetime64[D]")
    ATR = np.full(n, np.nan)
    ok = np.zeros(n, bool)
    cal = np.asarray(market.cal).astype("datetime64[D]")
    days = P["day"].to_numpy().astype("datetime64[D]")
    groups = P.groupby("symbol", sort=True).indices
    syms = list(groups)
    t0 = time.time()
    for c0 in range(0, len(syms), chunk):
        part = syms[c0:c0 + chunk]
        market.load(part)
        for s in part:
            ds = market.daily.get(s)
            if ds is None or not len(ds.dates):
                continue
            dd = np.asarray(ds.dates).astype("datetime64[D]")
            ev, can, val, atr = t_series(ds.o, ds.h, ds.l, ds.c, ds.v)
            for i in groups[s]:
                t = int(np.searchsorted(dd, days[i]))
                if t >= len(dd) or dd[t] != days[i] or t + T_DAYS >= len(dd):
                    continue
                j = int(np.searchsorted(cal, dd[t], side="right"))
                if j + T_DAYS > len(cal) or not np.array_equal(dd[t + 1:t + K], cal[j:j + T_DAYS]):
                    why[i] = "calendar"
                    continue
                if not np.isfinite(atr[t]):
                    why[i] = "no ATR"
                    continue
                sl = slice(t, t + K)
                EV[i] = np.column_stack([ev[k][sl] for k in T_KEYS])
                CAN[i] = np.column_stack([can[k][sl] for k in T_KEYS])
                VAL[i] = np.column_stack([val[k][sl] for k in T_VALUES])
                OHLC[i] = np.column_stack([np.asarray(a, float)[sl] for a in (ds.o, ds.h, ds.l, ds.c)])
                DATES[i] = dd[sl]
                ATR[i] = atr[t]
                ok[i] = True
                why[i] = ""
            market.daily.pop(s, None)
        log(f"   bars: {min(c0 + chunk, len(syms)):,} of {len(syms):,} symbols ({time.time() - t0:.0f}s)")
    return {"EV": EV, "CAN": CAN, "VAL": VAL, "OHLC": OHLC, "DATES": DATES, "ATR": ATR, "ok": ok, "why": why}


def t_moves(OHLC: np.ndarray, ATR: np.ndarray, ok: np.ndarray):
    """target = D1 open + 1 ATR; M = the first close D1..D10 at or above it (0 = not moved)."""
    o1 = OHLC[:, 1, 0]
    target = o1 + ATR
    hit = OHLC[:, 1:, 3] >= target[:, None]
    M = np.where(hit.any(1), hit.argmax(1) + 1, 0)
    M[~ok] = -1
    with np.errstate(invalid="ignore", divide="ignore"):
        gap = (target[:, None] - OHLC[:, :, 3]) / ATR[:, None]
    return target, M, gap


def t_falls(OHLC: np.ndarray, ATR: np.ndarray, ok: np.ndarray):
    """The mirror of the move, shown only: the first close D1..D10 at or below the D1 open - 1 ATR (0 = none), and each
    close's distance above that level in ATRs."""
    low = OHLC[:, 1, 0] - ATR
    hit = OHLC[:, 1:, 3] <= low[:, None]
    Md = np.where(hit.any(1), hit.argmax(1) + 1, 0)
    Md[~ok] = -1
    with np.errstate(invalid="ignore", divide="ignore"):
        gd = (OHLC[:, :, 3] - low[:, None]) / ATR[:, None]
    return Md, gd


def _boot_tot(S: Stat, di: np.ndarray, cols: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
    """Per-day sums of each column, then the full-sample totals and the resampled totals (B x columns)."""
    X = np.column_stack([np.bincount(di, weights=c_, minlength=S.nd) for c_ in cols])
    return X.sum(0), S.boot.M @ X


def t_measure_a(S: Stat, di, mask, M, F) -> dict:
    """Movers (D2..D10): fired at a close from D1 to the close before the move; non-movers: fired from D1 to the same
    day, weighted like the movers' move days. F = trigger at closes 0..10 (picks x 11)."""
    out = {"movers": 0, "non_movers": 0, "rate_moved": np.nan, "rate_not": np.nan, "stat": np.nan, "lo": np.nan,
           "hi": np.nan, "first_close": np.nan, "lead": np.nan}
    mv = mask & (M >= 2) & (di >= 0)
    nm = mask & (M == 0) & (di >= 0)
    out["movers"], out["non_movers"] = int(mv.sum()), int(nm.sum())
    if mv.sum() < 2 or nm.sum() < 2:
        return out
    cum = np.cumsum(F[:, 1:], axis=1) > 0                                   # fired at some close D1..Dk (k = 1..10)
    fired = np.zeros(len(M), bool)
    fired[mv] = cum[mv, M[mv] - 2]
    Ls = list(range(2, T_DAYS + 1))
    cols = [np.where(mv, fired, 0.0), mv.astype(float)]
    cols += [np.where(mv & (M == L), 1.0, 0.0) for L in Ls]
    cols += [np.where(nm, cum[:, L - 2], 0.0) for L in Ls] + [nm.astype(float)]
    tot, R = _boot_tot(S, np.where(di >= 0, di, 0), cols)

    def rates(t):
        with np.errstate(invalid="ignore", divide="ignore"):
            a = t[..., 0] / t[..., 1]
            w = np.stack([t[..., 2 + q] for q in range(len(Ls))], -1) / t[..., 1][..., None]
            g = np.stack([t[..., 2 + len(Ls) + q] for q in range(len(Ls))], -1) / t[..., -1][..., None]
            b = (w * g).sum(-1)
        return a, b
    a, b = rates(tot)
    ra, rb = rates(R)
    d = ra - rb
    out.update({"rate_moved": float(a), "rate_not": float(b), "stat": float(a - b)})
    if np.isfinite(d).sum() > 100:
        out["lo"], out["hi"] = float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5))
    fk = np.where(F[:, 1:], np.arange(1, T_DAYS + 1)[None, :], 99).min(1)
    sel = mv & fired
    if sel.any():
        out["first_close"] = float(np.median(fk[sel]))
        out["lead"] = float(np.median(M[sel] - fk[sel]))
    return out


def t_measure_b(S: Stat, di, mask, M, F, gap, C) -> dict:
    """At closes D1..D7 not yet moved where the trigger could fire (C): the move within the next 3 closes after closes
    where it fired minus closes where it did not, compared inside cells of the same close after the pick and the same
    distance from the target, averaged over the cells that hold both, weighted by the trigger's firings there. fired =
    those matched firings. The resampled SD gives a two-sided p (normal approximation)."""
    out = {"fired": 0, "fired_all": 0, "rate_fired": np.nan, "rate_not": np.nan, "stat": np.nan, "lo": np.nan,
           "hi": np.nan, "sd": np.nan, "p": np.nan}
    nb = len(T_BINS) + 1
    rows_i, rows_k = [], []
    for k in range(1, T_LAST + 1):
        r = np.flatnonzero(mask & (di >= 0) & ((M == 0) | (M > k)))
        rows_i.append(r)
        rows_k.append(np.full(len(r), k))
    ri, rk = np.concatenate(rows_i), np.concatenate(rows_k)
    if not len(ri):
        return out
    g = gap[ri, rk]
    keep = np.isfinite(g) & C[ri, rk]
    ri, rk, g = ri[keep], rk[keep], g[keep]
    e = F[ri, rk]
    y = ((M[ri] > rk) & (M[ri] <= rk + T_HORIZON)).astype(float)
    cell = (rk - 1) * nb + np.digitize(g, T_BINS)
    dd = di[ri]
    out["fired_all"] = int(e.sum())
    ce = np.bincount(cell[e], minlength=T_LAST * nb)
    cn = np.bincount(cell[~e], minlength=T_LAST * nb)
    both = np.flatnonzero((ce > 0) & (cn > 0))
    out["fired"] = int(ce[both].sum())
    if out["fired"] < 2:
        return out
    out["rate_fired"], out["rate_not"] = float(y[e].mean()), float(y[~e].mean())
    cols = []
    for q in both:
        mq = cell == q
        cols += [(mq & e).astype(float), np.where(mq & e, y, 0.0), (mq & ~e).astype(float), np.where(mq & ~e, y, 0.0)]
    tot, R = _boot_tot(S, dd, cols)

    def stat(t):
        t = np.asarray(t, float)
        nE, yE, nN, yN = (t[..., q::4] for q in range(4))
        with np.errstate(invalid="ignore", divide="ignore"):
            dif = yE / nE - yN / nN
            w = np.where((nE > 0) & (nN > 0), nE, 0.0)
            return np.nansum(np.where(w > 0, dif, 0.0) * w, -1) / np.where(w.sum(-1) > 0, w.sum(-1), np.nan)
    out["stat"] = float(stat(tot))
    d = stat(R)
    if np.isfinite(d).sum() > 100:
        out["lo"], out["hi"] = float(np.nanpercentile(d, 2.5)), float(np.nanpercentile(d, 97.5))
        out["sd"] = float(np.nanstd(d))
        if out["sd"] > 0:
            out["p"] = float(math.erfc(abs(out["stat"]) / out["sd"] / math.sqrt(2)))
    return out


def t_family(SL, T: pd.DataFrame) -> pd.DataFrame:
    """The verdicts, with the many-tests check over every judged test of the run (not TOO FEW): a test's p = the larger
    of its two periods' two-sided p when both periods point the same way, else 1; Benjamini-Hochberg q over them all.
    TRIGGER (LESS LIKELY) = both 95% intervals above (below) 0 and q at most 5%; both intervals on one side but q above
    5% = MAY BE CHANCE. FALLS TOO = a TRIGGER whose 1-ATR-fall intervals are also above 0 in both periods."""
    T = T.copy()
    if not len(T):
        for c_ in ("p_both", "q", "verdict", "falls_too"):
            T[c_] = []
        return T
    g = lambda c_: T[c_].to_numpy(float)                                                        # noqa: E731
    few = (g("B_P1_fired") < T_MIN) | (g("B_P2_fired") < T_MIN)
    same = np.sign(g("B_P1_stat")) * np.sign(g("B_P2_stat")) > 0
    p = np.where(same, np.maximum(g("B_P1_p"), g("B_P2_p")), 1.0)
    p = np.where(np.isfinite(g("B_P1_p")) & np.isfinite(g("B_P2_p")), p, np.nan)
    p[few] = np.nan
    q = SL.bh_q(p)
    with np.errstate(invalid="ignore"):
        up = (g("B_P1_lo") > 0) & (g("B_P2_lo") > 0)
        dn = (g("B_P1_hi") < 0) & (g("B_P2_hi") < 0)
        sure = q <= T_FDR
        fall = (g("F_P1_lo") > 0) & (g("F_P2_lo") > 0)
    T["p_both"], T["q"] = p, q
    T["verdict"] = np.select([few, up & sure, dn & sure, up | dn],
                             ["TOO FEW", "TRIGGER", "LESS LIKELY", "MAY BE CHANCE"], "NO CLEAR TRIGGER")
    T["falls_too"] = (T["verdict"] == "TRIGGER").to_numpy() & fall
    return T


def t_kinds(P: pd.DataFrame) -> np.ndarray:
    conf = P["confident"].astype(str).str.lower().isin(["true", "1"])
    pair = ["MIXED: " + " + ".join(sorted([str(a), str(b)])) for a, b in zip(P["reason"], P["second"])]
    return np.where(conf, P["category"].astype(str), pair).astype(object)


def t_analyse(S: Stat, P: pd.DataFrame, EL: np.ndarray, EV: np.ndarray, CAN: np.ndarray, M: np.ndarray,
              gap: np.ndarray, Md: np.ndarray, gd: np.ndarray) -> pd.DataFrame:
    """Every kind x every trigger measured on that kind's picks that carry it: A shown (2020-26 and each period), B
    judged in each period, the 1-ATR fall after it (F) shown in each period. Verdicts come from t_family."""
    di = S.di(P["day"].to_numpy())
    kinds = P["kind"].to_numpy()
    per = P["period"].to_numpy()
    rows = []
    order = P["kind"].value_counts().index.tolist()
    for kd in order:
        K_ = kinds == kd
        for j, key in enumerate(T_KEYS):
            base = K_ & EL[:, j] & (M >= 0)
            if not base.any():
                continue
            r = {"kind": kd, "trigger": T_LABEL[key], "key": key, "indicator": T_IND_OF[key],
                 "type": "yardstick" if key.startswith("y_") else "own", "picks": int(base.sum())}
            for p, pm in (("ALL", np.ones(len(P), bool)), ("P1", per == "P1"), ("P2", per == "P2")):
                a = t_measure_a(S, di, base & pm, M, EV[:, :, j])
                r.update({f"A_{p}_{k}": v for k, v in a.items()})
                if p == "ALL":
                    continue
                b = t_measure_b(S, di, base & pm, M, EV[:, :, j], gap, CAN[:, :, j])
                dn = t_measure_b(S, di, base & pm & (Md >= 0), Md, EV[:, :, j], gd, CAN[:, :, j])
                r.update({f"B_{p}_{k}": v for k, v in b.items()})
                r.update({f"F_{p}_{k}": v for k, v in dn.items()})
            rows.append(r)
    return pd.DataFrame(rows)


def t_execute(SL, root: Path, bout: Path, p_run: Optional[str] = None, stage_e_any: bool = False,
              rerun_reason: Optional[str] = None, log=say) -> Path:
    t0 = time.time()
    td, tsha = load_t()
    prev = [r for r in (json.loads(x) for x in ((bout / LEDGER).read_text(encoding="utf-8").splitlines()
                                                 if (bout / LEDGER).is_file() else []))
            if r.get("event") == "triggers" and r.get("declaration_sha256") in (tsha, T_OLD_SHA)]
    if prev and not rerun_reason:
        old = " under the replaced v1.3 declaration" if prev[-1].get("declaration_sha256") == T_OLD_SHA else ""
        raise WHError(f"part T already ran ({prev[-1].get('run')}{old}); a second run needs --rerun-reason "
                      f"\"<a verified bug>\" (recorded in the ledger)")
    pdir = t_find_p_run(bout, p_run)
    P = pd.read_csv(pdir / "picks.csv", parse_dates=["day"])
    RS = pd.read_csv(pdir / "reasons.csv", parse_dates=["day"])
    log(f"{VERSION} part T: part P run {pdir.name}, {len(P):,} picks")
    P["day"] = P["day"].to_numpy().astype("datetime64[D]")
    RS["day"] = RS["day"].to_numpy().astype("datetime64[D]")
    P["kind"] = t_kinds(P)
    P["period"] = np.where(P["day"].to_numpy().astype("datetime64[D]") < P2_START, "P1", "P2")
    # each pick's own indicators: its top inputs with a push above 0, translated
    RS["indicator"] = [t_translate(x) for x in RS["input"]]
    RS["source"] = [t_source(x) for x in RS["input"]]
    pos = RS[RS["push"] > 0].sort_values(["day", "symbol", "place"])
    own = pos[pos["indicator"] != LEFT_OUT].groupby(["day", "symbol"])["indicator"].agg(lambda s: list(dict.fromkeys(s)))
    left = pos[pos["indicator"] == LEFT_OUT].groupby(["day", "symbol"])["input"].agg(list)
    keyp = list(zip(P["day"], P["symbol"]))
    P["own_indicators"] = ["; ".join(own.get(k, [])) for k in keyp]
    P["left_out_inputs"] = ["; ".join(left.get(k, [])) for k in keyp]
    EL = np.zeros((len(P), len(T_KEYS)), bool)
    for i, k in enumerate(keyp):
        inds = set(own.get(k, []))
        for j, key in enumerate(T_KEYS):
            EL[i, j] = key.startswith("y_") or T_IND_OF[key] in inds
    prod = TD.Production(stage_e_any=stage_e_any)
    market = TD.Market(root, prod)
    B = t_collect(market, P, log)
    P["left_out_reason"] = B["why"]
    target, M, gap = t_moves(B["OHLC"], B["ATR"], B["ok"])
    Md, gd = t_falls(B["OHLC"], B["ATR"], B["ok"])
    r5 = (B["OHLC"][:, 5, 3] / B["OHLC"][:, 1, 0] - 1) * 100
    pr5 = pd.to_numeric(P["r5"], errors="coerce").to_numpy(float)
    cmp_ = np.isfinite(pr5)
    eq = cmp_ & np.isfinite(r5) & (np.abs(r5 - pr5) <= T_R5_TOL)
    g = {"picks": int(len(P)), "with_bars": int(B["ok"].sum()), "compared": int(cmp_.sum()), "equal": int(eq.sum()),
         "share": float(eq.sum() / max(cmp_.sum(), 1)), "left_out_no_bars": int((B["why"] == "no bars").sum()),
         "left_out_calendar": int((B["why"] == "calendar").sum()), "left_out_no_atr": int((B["why"] == "no ATR").sum())}
    g["passed"] = bool(cmp_.any() and g["share"] >= T_GATE)
    run = SL.new_run_dir(bout / "triggers", "T")
    log(f" gate: these bars give part P's D1-D5 move on {g['equal']:,} of {g['compared']:,} picks "
        f"({100 * g['share']:.2f}%) -> {'PASSED' if g['passed'] else 'FAILED'}; left out: {g['left_out_calendar']:,} "
        f"calendar (D1-D10 not the market's next 10 sessions), {g['left_out_no_bars']:,} no bars, "
        f"{g['left_out_no_atr']:,} no ATR")
    if not g["passed"]:
        (run / "TREPORT.md").write_text(
            f"# whylab part T ({run.name})\n\n**STOPPED: these bars do not give part P's D1-D5 move "
            f"({100 * g['share']:.2f}% equal, needs 99%).** Nothing was measured. Picks left out: "
            f"{g['left_out_calendar']:,} because D1-D10 are not the market's next 10 sessions, "
            f"{g['left_out_no_bars']:,} without the bars, {g['left_out_no_atr']:,} without the signal-day ATR.\n",
            encoding="utf-8")
        pd.DataFrame([g]).to_csv(run / "gate.csv", index=False)
        (run / "DECLARATION.json").write_bytes(T_FILE.read_bytes())
        (run / "run.json").write_text(json.dumps({"version": VERSION, "declaration_sha256": tsha, "stopped": True,
                                                  "gate": g, "p_run": pdir.name}, indent=1), encoding="utf-8")
        SL.write_hashes(run, ["TREPORT.md", "gate.csv", "DECLARATION.json", "run.json"])
        with open(bout / LEDGER, "a", encoding="utf-8") as f:
            f.write(json.dumps({"event": "triggers", "run": run.name, "at": dt.datetime.now().isoformat(
                timespec="seconds"), "declaration_sha256": tsha, "version": VERSION, "stopped": True,
                "rerun_reason": rerun_reason}) + "\n")
        log(f"STOPPED: the bars do not give part P's move ({run})")
        raise GateFailed(f"part T stopped at the gate; report in {run}")
    S = Stat(SL, P["day"].to_numpy())
    T = t_family(SL, t_analyse(S, P, EL, B["EV"], B["CAN"], M, gap, Md, gd))
    secs = time.time() - t0
    # per pick
    used = M >= 0
    gain = (B["OHLC"][:, :, 3] - B["OHLC"][:, 1:2, 0]) / B["ATR"][:, None]
    PK = P[["day", "symbol", "rank", "kind", "category", "confident", "reason", "second", "own_indicators",
            "left_out_inputs", "left_out_reason"]].copy()
    PK["used"] = used
    PK["atr_rs"], PK["d1_open"], PK["target"] = B["ATR"], B["OHLC"][:, 1, 0], target
    PK["moved"] = np.where(used, np.where(M > 0, "MOVED", "NOT MOVED"), "")
    PK["move_day"] = np.where(M > 0, M, np.nan)
    PK["best_close_atr"] = pd.DataFrame(np.where(used[:, None], gain[:, 1:], np.nan)).max(axis=1).to_numpy()
    paths = []
    for i in np.flatnonzero(used):
        for k in range(T_DAYS + 1):
            r = {"day": P["day"].iloc[i], "symbol": P["symbol"].iloc[i], "close": f"D{k}", "date": B["DATES"][i, k],
                 "open": B["OHLC"][i, k, 0], "high": B["OHLC"][i, k, 1], "low": B["OHLC"][i, k, 2],
                 "close_price": B["OHLC"][i, k, 3], "from_d1_open_atr": gain[i, k],
                 "moved_here": bool(M[i] == k and k > 0)}
            r.update({nm: B["VAL"][i, k, q] for q, nm in enumerate(T_VALUES)})
            paths.append(r)
    PA = pd.DataFrame(paths)
    fr = []
    for i in np.flatnonzero(used):
        for j, key in enumerate(T_KEYS):
            if not EL[i, j]:
                continue
            f = B["EV"][i, :, j]
            after = np.flatnonzero(f[1:]) + 1
            first = int(after[0]) if len(after) else None
            fr.append({"day": P["day"].iloc[i], "symbol": P["symbol"].iloc[i], "kind": P["kind"].iloc[i],
                       "trigger": T_LABEL[key], "indicator": T_IND_OF[key],
                       "type": "yardstick" if key.startswith("y_") else "own", "fired_on_signal_day": bool(f[0]),
                       "first_close_after": f"D{first}" if first else "",
                       "before_move": (bool(first is not None and first < M[i]) if M[i] > 0 else None),
                       "closes_before_move": (int(M[i] - first) if (first and M[i] > first) else None)})
    FR = pd.DataFrame(fr)
    tr_tab = (RS.groupby(["input", "indicator", "source"]).agg(in_top5=("push", "size"), push=("push", "sum"))
              .reset_index().sort_values("in_top5", ascending=False))
    CV = t_coverage(P, RS)
    judged = T[T["verdict"] != "TOO FEW"] if len(T) else T
    info = {"run": run.name, "p_run": pdir.name, "gate": g, "seconds": secs, "picks_used": int(used.sum()),
            "moved": int((M > 0).sum()), "moved_d1": int((M == 1).sum()), "not_moved": int((M == 0).sum()),
            "tests": int(len(T)), "judged": int(len(judged)), "fdr": T_FDR,
            "both_periods": int((judged["verdict"].isin(["TRIGGER", "LESS LIKELY", "MAY BE CHANCE"])).sum())
            if len(judged) else 0}
    (run / "TREPORT.md").write_text(t_report(P, M, T, FR, CV, info, td, tsha), encoding="utf-8")
    PK.to_csv(run / "picks.csv", index=False, float_format="%.10g")
    PA.to_csv(run / "paths.csv", index=False, float_format="%.10g")
    FR.to_csv(run / "firings.csv", index=False)
    T.to_csv(run / "triggers.csv", index=False, float_format="%.10g")
    tr_tab.to_csv(run / "translation.csv", index=False, float_format="%.10g")
    CV.to_csv(run / "coverage.csv", index=False, float_format="%.10g")
    pd.DataFrame([g]).to_csv(run / "gate.csv", index=False)
    (run / "DECLARATION.json").write_bytes(T_FILE.read_bytes())
    verdicts = {f"{r['kind']} | {r['trigger']}": r["verdict"] for r in T.to_dict("records")
                if r["verdict"] in ("TRIGGER", "LESS LIKELY")} if len(T) else {}
    meta = {"version": VERSION, "declaration_sha256": tsha, "root": str(root), "info": info, "verdicts": verdicts,
            "rerun_reason": rerun_reason, "python": sys.version.split()[0], "pandas": pd.__version__,
            "numpy": np.__version__}
    (run / "run.json").write_text(json.dumps(meta, indent=1, default=str), encoding="utf-8")
    SL.write_hashes(run, ["TREPORT.md", "picks.csv", "paths.csv", "firings.csv", "triggers.csv", "translation.csv",
                          "coverage.csv", "gate.csv", "DECLARATION.json", "run.json"])
    with open(bout / LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps({"event": "triggers", "run": run.name, "at": dt.datetime.now().isoformat(timespec="seconds"),
                            "declaration_sha256": tsha, "version": VERSION, "tests_judged": info["judged"],
                            "triggers_found": int(sum(v == "TRIGGER" for v in verdicts.values())),
                            "less_likely": int(sum(v == "LESS LIKELY" for v in verdicts.values())),
                            "rerun_reason": rerun_reason}) + "\n")
    log(f"RESULT: {int(used.sum()):,} picks; moved {int((M > 0).sum()):,} (on D1 {int((M == 1).sum()):,}), not moved "
        f"{int((M == 0).sum()):,}; {info['judged']:,} tests judged; " +
        (("; ".join(f"{k}: {v}" for k, v in verdicts.items())) or "no TRIGGER"))
    log(f"DONE -> {run}")
    return run


def _pc(x, nd=0) -> str:
    return "-" if x is None or not np.isfinite(x) else f"{100 * x:.{nd}f}%"


def t_coverage(P: pd.DataFrame, RS: pd.DataFrame) -> pd.DataFrame:
    """Per kind, and over all picks: the share of D's push toward the picks (their top inputs with a push above 0)
    followed through the stock's own daily input's indicator family, through the stock's own daily indicator for a
    cross-sectional (X_) or weekly (W_) input, or not at all (WorldQuant formulas shown apart)."""
    pos = RS[RS["push"] > 0].merge(P[["day", "symbol", "kind"]], on=["day", "symbol"], how="inner")
    pos = pos.assign(wq=pos["input"].astype(str).str.lower().str.contains("wq_"))
    rows = []
    for kd, grp in [("ALL picks", pos)] + [(k, pos[pos["kind"] == k]) for k in P["kind"].value_counts().index]:
        tot = float(grp["push"].sum())
        r = {"kind": kd, "picks": int(len(grp[["day", "symbol"]].drop_duplicates())), "inputs": int(len(grp))}
        for s_ in T_SOURCES:
            r[s_] = float(grp.loc[grp["source"] == s_, "push"].sum() / tot) if tot > 0 else np.nan
        r["of which WorldQuant"] = float(grp.loc[grp["wq"], "push"].sum() / tot) if tot > 0 else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


def _q(x) -> str:
    return "-" if x is None or not np.isfinite(x) else ("<0.1%" if x < 0.0005 else f"{100 * x:.1f}%")


def _cov_line(r) -> str:
    return (f"{_pc(r['own daily'])} the stock's own daily inputs (followed through their indicator family), "
            f"{_pc(r['cross-sectional or weekly'])} cross-sectional or weekly inputs (followed through the stock's own "
            f"daily indicator), {_pc(r['left out'])} left out (WorldQuant {_pc(r['of which WorldQuant'])})")


def t_report(P, M, T, FR, CV, info, td, tsha) -> str:
    g = info["gate"]
    used = M >= 0
    cov = {r["kind"]: r for r in CV.to_dict("records")}
    nv = T["verdict"].value_counts() if len(T) else pd.Series(dtype=int)
    found = T[T["verdict"] == "TRIGGER"] if len(T) else T
    own_lab = set(zip(found.loc[found["type"] == "own", "kind"], found.loc[found["type"] == "own", "trigger"]))
    found = found[(found["type"] == "own").to_numpy() |
                  np.array([(k, t) not in own_lab for k, t in zip(found["kind"], found["trigger"])], bool)]
    L = [f"# whylab part T - what triggered each pick's move ({info['run']})", "",
         f"{VERSION} | T declaration {tsha[:16]} (fixed {td['declared_at']}) | part P run {info['p_run']} | "
         f"{info['picks_used']:,} picks | {info['seconds']:.0f} s", "",
         "For every pick, the inputs D used for it (part P) were turned into the readable indicators behind them, and "
         "those indicators' triggers were followed on the stock's daily bars from the signal day to D10 (the market's "
         "next 10 sessions). **The move** = the first close at or above the D1 open + 1 ATR. Each kind of pick is "
         "measured on its own: a trigger is measured only on the picks of that kind whose own indicators include it.",
         "",
         "- **Fired before the move** (shown): of the picks that moved on D2-D10, how many had the trigger fire between "
         "D1 and the close before the move; of the picks that never moved, how many had it fire over the same days. "
         "Part of this is the move itself starting.",
         "- **Verdict**: at closes D1-D7 before the move, did the move come within 3 closes more often after the "
         "trigger fired than after closes where it could have fired but did not (a crossing: the line was below), "
         "**at the same close after the pick and the same distance from the target**? TRIGGER = yes in 2020-23 and in "
         "2024-26 (95% intervals above 0) AND it survives the many-tests check (Benjamini-Hochberg over every judged "
         "test of this run, false discovery rate 5%, on the weaker period). MAY BE CHANCE = both periods, but not "
         "after that check. FALLS TOO = it also made a 1-ATR fall more likely in both periods: a sign of a bigger move "
         "either way, not of a rise.",
         "- **A TRIGGER is a historical link worth testing as an entry, not a tested entry.** Nothing here measures "
         "next-open fills, costs, exits, MFE/MAE or missed winners.", "",
         "## Checks", "",
         f"- These bars give part P's D1-D5 move on {g['equal']:,} of {g['compared']:,} picks "
         f"({100 * g['share']:.2f}%) -> PASSED. Picks left out: {g['left_out_calendar']:,} because D1-D10 are not "
         f"the market's next 10 sessions, {g['left_out_no_bars']:,} without the bars, {g['left_out_no_atr']:,} "
         f"without the signal-day ATR.",
         f"- Picks measured: {info['picks_used']:,}. Moved {info['moved']:,} "
         f"({100 * info['moved'] / max(info['picks_used'], 1):.1f}%; on D1 {info['moved_d1']:,}), not moved "
         f"{info['not_moved']:,}.",
         f"- Tests: {info['tests']:,} kind x trigger rows; {info['judged']:,} judged (100+ matched firings in each "
         f"period); {info['both_periods']:,} on one side of 0 in both periods; after the many-tests check: TRIGGER "
         f"{len(found):,} (a yardstick that repeats a kind's own trigger counted once), LESS LIKELY "
         f"{int(nv.get('LESS LIKELY', 0)):,}, MAY BE CHANCE {int(nv.get('MAY BE CHANCE', 0)):,}.",
         "- D's top-5 push over all picks: " + (_cov_line(cov["ALL picks"]) if "ALL picks" in cov else "-") + ".", ""]
    order = {"TRIGGER": 0, "LESS LIKELY": 1, "MAY BE CHANCE": 2, "NO CLEAR TRIGGER": 3, "TOO FEW": 4}
    for kd in P["kind"].value_counts().index:
        m = (P["kind"] == kd).to_numpy() & used
        if not m.any():
            continue
        mv = M[m]
        inds = pd.Series([x for s in P.loc[m, "own_indicators"] for x in str(s).split("; ") if x and x != "nan"])
        top = inds.value_counts().head(6)
        L += [f"## {kd} ({int(m.sum()):,} picks)", "",
              f"- Moved within 10 days: {100 * (mv > 0).mean():.0f}% (on D1 {100 * (mv == 1).mean():.0f}%); median move "
              f"day D{int(np.median(mv[mv > 0])) if (mv > 0).any() else 0}.",
              "- Its own indicators (share of its picks): " +
              ", ".join(f"{k} {100 * v / m.sum():.0f}%" for k, v in top.items()) + ".",
              "- D's top-5 push for these picks: " + (_cov_line(cov[kd]) if kd in cov else "-") + ".", "",
              "| trigger | indicator | picks | fired before the move: moved / not moved | first fires / closes before "
              "the move | move within 3 closes after it vs could have but did not, same close and distance: 2020-23 / "
              "2024-26 | the same for a 1-ATR fall | many-tests q | verdict |",
              "|---|---|---|---|---|---|---|---|---|"]
        Tk = T[T["kind"] == kd].copy()
        Tk["_o"] = Tk["verdict"].map(order)
        Tk["_s"] = np.fmin(Tk["B_P1_stat"].to_numpy(float), Tk["B_P2_stat"].to_numpy(float))
        for r in Tk.sort_values(["type", "_o", "_s"], ascending=[True, True, False]).to_dict("records"):
            a = (f"{_pc(r['A_ALL_rate_moved'])} / {_pc(r['A_ALL_rate_not'])}" if np.isfinite(r["A_ALL_stat"]) else "-")
            fc = (f"D{r['A_ALL_first_close']:.0f} / {r['A_ALL_lead']:.0f}" if np.isfinite(r["A_ALL_first_close"])
                  else "-")
            b = " / ".join(f"{_f(100 * r[f'B_{p}_stat'], 1)} [{_f(100 * r[f'B_{p}_lo'], 1)}, {_f(100 * r[f'B_{p}_hi'], 1)}]"
                           f" ({r[f'B_{p}_fired']:,})" for p in PERIODS)
            fl = " / ".join(_f(100 * r[f"F_{p}_stat"], 1) for p in PERIODS)
            nm = r["trigger"] + (" *(yardstick)*" if r["type"] == "yardstick" else "")
            vd = r["verdict"] + (" - FALLS TOO" if r.get("falls_too") else "")
            L.append(f"| {nm} | {r['indicator']} | {r['picks']:,} | {a} | {fc} | {b} | {fl} | {_q(r['q'])} "
                     f"| **{vd}** |")
        L += ["", "Verdict numbers: points of chance (the move within 3 closes after the trigger fired, minus after "
              "closes where it could have fired but did not, at the same close after the pick and the same distance "
              "from the target); in brackets the 95% interval, then the matched firings. A trigger needs 100 matched "
              "firings in each period.", ""]
    L[L.index("## Checks"):L.index("## Checks")] = (
        ["## Triggers found (2020-23 / 2024-26, points of chance at the same close and distance; many-tests q)", ""] +
        ([f"- **{r['kind']}**: {r['trigger']} ({r['indicator']}): {_f(100 * r['B_P1_stat'], 1)} / "
          f"{_f(100 * r['B_P2_stat'], 1)}; q {_q(r['q'])}{' - FALLS TOO' if r.get('falls_too') else ''}"
          for r in found.to_dict("records")] or ["- None passed both periods and the many-tests check."]) + [""])
    L += ["## The latest picks", ""]
    lastp = P.assign(_M=M)[used].sort_values(["day", "rank"]).tail(12)
    for r in lastp.to_dict("records"):
        fx = FR[(FR["day"] == r["day"]) & (FR["symbol"] == r["symbol"]) & (FR["type"] == "own") &
                (FR["first_close_after"] != "")] if len(FR) else FR
        fires = "; ".join(f"{q['trigger']} {q['first_close_after']}" for q in fx.to_dict("records")[:5]) or "none"
        mv = f"moved on D{int(r['_M'])}" if r["_M"] > 0 else "did not move by D10"
        L.append(f"- {pd.Timestamp(r['day']).date()} **{r['symbol']}** ({r['kind']}): own indicators "
                 f"{r['own_indicators'] or '-'}; {mv}; its own triggers after the pick: {fires}.")
    L += ["", "Per pick: picks.csv (the move; why a pick was left out), paths.csv (its indicators at every close "
          "D0-D10), firings.csv (each of its triggers, when it first fired, before the move or not); translation.csv "
          "(every input, its readable indicator and how it is followed); coverage.csv (the push shares above). "
          "Research only: nothing changes in the paper test.", ""]
    return "\n".join(L) + "\n"


def cmd_model(a) -> int:
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    bout = out_base(a.out, root)
    k_execute(SL, root, bout, a.rerun_reason)
    return 0


def cmd_check(a) -> int:
    decl, sha = load_decl()
    kd, ksha = load_k()
    pd_, psha = load_p()
    td_, tsha = load_t()
    SL = libs()
    try:
        import shap
        sv = f"shap {shap.__version__}" + ("" if shap.__version__ == P_SHAP else f" (part P needs {P_SHAP})")
    except ImportError:
        sv = f"shap NOT INSTALLED (part P needs it: pip install shap=={P_SHAP})"
    print(f"{VERSION}: declaration {sha[:16]} OK ({decl['declared_at']}); part K declaration {ksha[:16]} OK; "
          f"part P declaration {psha[:16]} OK; part T declaration {tsha[:16]} OK; {sv}; {SL.VERSION}; "
          f"{getattr(TC, 'VERSION', 'tradelab ?')} / {getattr(SU, 'SETUPS_VERSION', 'tl_setups ?')}; "
          f"pandas {pd.__version__}; numpy {np.__version__}")
    return 0


def cmd_explain(a) -> int:
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    base = Path(a.setups or os.environ.get("SETUPLAB_OUT") or "")
    if not str(base) or not base.is_dir():
        raise WHError("pass --setups <setuplab output folder> or start with env_whylab.bat (sets SETUPLAB_OUT)")
    bout = out_base(a.out, root)
    p_execute(SL, root, base, bout, a.stage_e_any, a.rerun_reason)
    return 0


def cmd_triggers(a) -> int:
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    bout = out_base(a.out, root)
    t_execute(SL, root, bout, a.p_run, a.stage_e_any, a.rerun_reason)
    return 0


def cmd_today(a) -> int:
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    bout = out_base(a.out, root)
    today_execute(SL, root, bout, a.live)
    return 0


def cmd_run(a) -> int:
    decl, sha = load_decl()
    SL = libs()
    if not a.root:
        raise WHError("pass --root %CACHE_DAILY_ROOT% (there is no default cache path)")
    root = Path(a.root)
    if not root.is_dir():
        raise WHError(f"--root {root} is not a folder")
    base = Path(a.setups or os.environ.get("SETUPLAB_OUT") or "")
    if not str(base) or not base.is_dir():
        raise WHError("pass --setups <setuplab output folder> or start with env_whylab.bat (sets SETUPLAB_OUT)")
    bout = out_base(a.out, root)
    execute(SL, decl, sha, root, base, bout, a.stage_e_any, a.rerun_reason)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="whylab", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check")
    k = sub.add_parser("model")
    k.add_argument("--root")
    k.add_argument("--out")
    k.add_argument("--rerun-reason")
    x = sub.add_parser("explain")
    x.add_argument("--root")
    x.add_argument("--setups")
    x.add_argument("--out")
    x.add_argument("--stage-e-any", action="store_true")
    x.add_argument("--rerun-reason")
    g = sub.add_parser("triggers")
    g.add_argument("--root")
    g.add_argument("--out")
    g.add_argument("--p-run")
    g.add_argument("--stage-e-any", action="store_true")
    g.add_argument("--rerun-reason")
    t = sub.add_parser("today")
    t.add_argument("--root")
    t.add_argument("--out")
    t.add_argument("--live")
    r = sub.add_parser("run")
    r.add_argument("--root")
    r.add_argument("--setups")
    r.add_argument("--out")
    r.add_argument("--stage-e-any", action="store_true")
    r.add_argument("--rerun-reason")
    a = ap.parse_args(argv)
    try:
        return {"check": cmd_check, "run": cmd_run, "model": cmd_model, "explain": cmd_explain,
                "today": cmd_today, "triggers": cmd_triggers}[a.cmd](a)
    except (WHError, TC.TLError) as e:
        print(f"REFUSED: {e}", flush=True)
        return 2
    except (GateFailed, PAddError) as e:
        print(f"STOPPED: {e}", flush=True)
        return 3


if __name__ == "__main__":
    sys.exit(main())
