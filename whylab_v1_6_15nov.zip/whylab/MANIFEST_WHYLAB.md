# MANIFEST - whylab v1.6 (15 Nov 2026)

This research tool lives in its own folder beside tradelab and setuplab. Nothing in `bigmove_deploy`, tradelab or setuplab changes. Production is only read: stage D's code and frozen run, `D.pkl`, the live panel and the daily cache. Parts C and M also read setuplab's TREE run, research watchlist and TAGS run; part M also reads the panel the TAGS run tagged with (all read only).

| file | what | sha256 (first 16) |
|---|---|---|
| `whylab\whylab.py` | the tool: `check`, `run` (claims), `model` (part K), `explain` and `today` (part P), `triggers` (part T), `choices` (part C), `modify` (part M) | 80072dc1f1300259 |
| `whylab\WHY_DECLARATION.json` | the claims' rules, fixed 14 Nov 2026 20:45 IST; unchanged | e3967dd85a42d063 |
| `whylab\WHY_K_DECLARATION.json` | part K's rules, fixed 15 Nov 2026 00:20 IST; unchanged | 158621297b501323 |
| `whylab\WHY_P_DECLARATION.json` | part P's rules, fixed 15 Nov 2026 01:00 IST; unchanged | 99db37895043cc79 |
| `whylab\WHY_T_DECLARATION.json` | part T's rules, fixed 15 Nov 2026 12:17 IST; unchanged | f6825bc20d149b6d |
| `whylab\WHY_C_DECLARATION.json` | part C's rules, fixed 15 Nov 2026 14:06 IST; unchanged | bf55408b6dc602a9 |
| `whylab\WHY_M_DECLARATION.json` | part M's rules, fixed 15 Nov 2026 15:12 IST before any M run | d9b2845a4170e48b |
| `whylab\tests\test_whylab.py` | self-test, 71 checks | cacffe955a0cb165 |
| `whylab\env_whylab.bat` | session setup (CRLF; labels unique); only its comment changed | 2cee4488f86b4cc2 |
| `whylab\README_WHYLAB.md` | what it does, how to run it | 1b983989dae563b8 |
| `whylab\MANIFEST_WHYLAB.md` | this file | - |

**Libraries:** nothing new. Part P needs shap 0.54.1 (already installed on your PC).

**What it uses unchanged:**
- **setuplab v1.1:**
  - Boot, atr_simple, bh_q;
  - the whole entry-tree code, which parts C and M use as is: load, load_tree, load_frozen, tree_complete, tree_cutoff, tree_history_picks, tree_run_books, tree_first_setup, tree_plan, tree_sim and tree_stats;
  - part M also uses the setups' own code as is: frozen_conds, frozen_features, the Book (its panel reader and join), trigger and exits_arr. Its size book is tree_sim with one change, checked bit for bit against tree_sim at 1/3;
  - TREE.json and its ETF rule, run folders and hashes.
- **tradelab:** tl_setups v1.7 (finds and hash-checks the TREE run), tl_data (production's stage E loader) and tl_common.
- **Imported read only from production by parts K and P:** `stage_d_gate.py`, `stage_b_screen.py` and `paper_pipeline.paths` (today).
- **Read only after checking:** part T and part C read part P's run (`outputs.sha256`, its declaration); parts C and M read the TREE run (hashes, reconciled, TREE.json's and FROZEN_SETUPS.json's sha256) and its TAGS run (hashes); part M re-tags on the TAGS run's panel and must reproduce that run exactly.

**What it writes:** only `C:\QuantData\whylab\runs\WHY_*`, `model\K_*`, `explain\P_*`, `today\`, `triggers\T_*`, `choices\C_*`, `modify\M_*` and `whylab_ledger.jsonl`.

**Verified 15 Nov 2026:** `VERIFIED (whylab v1.6)`, 71 checks, 0 failed.
- 191 s on pandas 2.3.3 / numpy 2.4.1 / scikit-learn 1.5.2 (your versions), from a clean folder: this zip unpacked beside setuplab v1.1 and tradelab.
- Also on pandas 3.0.5 / numpy 2.5.3 / scikit-learn 1.9.1.

## Part M (v1.6): what it adds

- **`modify`** changes one rule for one kind of D's picks (trend, position, returns, MIXED returns + trend), then applies the tree's rules again to all the window's D picks, so displaced trades count. 68 changes in seven families: setup eligibility (28), dip depth (12), weekly persistence (4), exit at D10 (4), size 1/2 or 1/6 (8), skip (4), lane (8). Each is judged against the frozen tree in setuplab's own book, with the many-tests check within each family (WHY_M_DECLARATION.json).
- **The gate:** part C's, plus four exact checks:
  - the TAGS run's fills give the tree's first setups;
  - re-tagged on the TAGS run's panel, the seven setups give every D pick that run's fills and nets;
  - whylab's own read of the 13-week return equals the re-tag's;
  - the size book at 1/3 is tree_sim bit for bit.
- **Found while building (synthetic data only):**
  - In the first planted world, the jumpy stocks' features always met C3, which needs no dip. The lasting bad-week reading then made C3 buy those picks at the D1 open, before their planted dip, and "trend, bad week lasts" came out WORSE. That is the right answer for that world. The world now keeps C3 off those stocks, and the planted gain is found.
  - Taking a setup away often changes nothing: the next setup fills the same day at the same price. Such a change is reported as CHANGES NOTHING and left out of the many-tests check, as declared.
  - Before the planted-bug run, four tests were tightened so each part of the gate is shown to catch a real difference:
    - a status-only and a net-only TAGS change;
    - a 1e-6 change in the weekly read;
    - a null panel that carries its own change column, with N1 filling;
    - a non-trend toy pick whose first setup is S1.
  - All 29 part M planted bugs were then caught on the first run.

## Part C (v1.5): what it adds

- **`choices`** routes one kind of D's picks at a time to buy at the open, to the frozen setups only, or to its confirmation rule. Every other pick keeps the frozen tree's decision. It judges each of the 24 variants against the frozen tree in setuplab's own book (WHY_C_DECLARATION.json).
- **The gate:** the TREE run is reconciled, and the rebuild gives that run's own D tree and baseline numbers within 1e-6. Kinds and matching bars must exist on 99% of the window's D picks.
- **Found while building (synthetic data only):**
  - In the first planted world, the tree's own book collapsed: random picks plus heavy losses at the trend picks' open buys. So "trend, open" came out below 0 in both periods but not significant in 2024-26. Softening the plant (a −0.5% D5 instead of −2.3%) fixed it.
  - Two planted bugs slipped through the first part C suite:
    - one start day used instead of five: the toy book's five starts were identical;
    - the current week's 13-week return instead of the last completed week's: the test series grew at a constant rate.
  - tc2b now starts after a trade, and tc1 uses a wavy climb. Both bugs are caught.

## Planted bugs, 149 of 149 caught

- **Claims (26), part K (12), part P (22):** listed in the earlier manifests. That code is unchanged.
- **Part T (39):** listed below (v1.4). That code is unchanged.
- **Part M (29):**
  - the conditions:
    - the dip scale ignored;
    - "no dip" keeping the dip;
    - persistence swapping every '<' condition;
    - persistence not used;
    - persistence filling a missing change;
    - persistence leaking across symbols;
    - a zero change counted as a reading;
  - the gate:
    - the weekly read ignoring the panel's own change column;
    - the weekly gate comparing the re-tag with itself;
    - re-tag nets compared loosely;
    - the re-tag ignoring the status;
    - N1 read at the D5 exit;
    - the re-tag on ENS;
  - the changes:
    - the lane flip reversed;
    - the lane family judged on the kind;
    - the lane family judged on the target lane;
    - the exit at D9;
    - the D10 net from the D1 open;
    - a missing D10 close not kept;
    - D10 for every kind;
    - the size for every trade;
    - slots ignoring the size;
    - the size not applied;
    - the size computed in another order (not tree_sim at 1/3);
    - skip keeping the kind;
    - setups changed for every pick;
  - the verdicts:
    - the many-tests check over all families;
    - CHANGES NOTHING counted in it;
    - "picks changed" ignoring the size.
- **Part C (21):**
  - the gate:
    - the rebuild compared loosely;
    - reconciled not checked;
    - the coverage gate at 90%;
    - bars that differ from the watchlist still used;
  - routing:
    - the kind's tree trades kept;
    - the open entry a day late;
    - the confirmation entry a day early;
    - the confirmation trade priced at the wrong open;
    - every frozen setup sold at D5;
    - kinds read from the top reason;
    - a MIXED pick given no rule;
  - the comparison:
    - x 365 instead of 252;
    - no many-tests check;
    - the worst-fall guard reversed;
    - the stronger period's p;
    - 10 picks a period enough;
    - one start day instead of five;
  - the rules:
    - trend on a rising EMA;
    - position from the top half;
    - volatility at half an ATR;
    - returns on the current week.

## What changed in part T (v1.3 -> v1.4)

Karan forwarded a review at 12:00. Each point was checked against the code and part P's real run P_20261115_002. v1.3's part T was never run; its declaration is replaced and pinned out.

**Faults the review found, fixed:**
1. **"13-week momentum" was triggered by a 5-day breakout.** It now has its own events, on the 4- and 13-week returns behind D's inputs W_ret_4w and W_ret_13w:
   - the 4-week return crosses above 0 (ROC 20);
   - the 13-week return crosses above 0 (ROC 65);
   - a new 13-week closing high.
2. **The verdict pooled the closes D1–D7.** It now compares at the same close after the pick, as well as the same distance from the target.
3. **No many-tests check.** v1.3 would have run up to 429 kind × trigger rows; v1.4 will run up to 496. Now Benjamini–Hochberg runs over every judged test, at a 5% false discovery rate, on the weaker period's p (setuplab's rule plus clashlab's weaker-period rule). Rows that pass both periods but not this check are marked MAY BE CHANCE.
4. **Only D1 was checked against the market calendar.** D1–D10 must now be the market's next 10 sessions; otherwise the pick is left out and counted.

**Faults found while checking the review, fixed:**

5. **A translation bug.** The day-of-week pattern `^(d_)?dow` also matched `D_downside_dev_60`. That input is in the top 5 of 805 picks and was dropped as "left out" instead of being followed as volatility. The pattern now needs `dow` followed by `_`, a digit or the end. The test now checks all 135 real input names, where v1.3's test used made-up ones.
6. **The 52-week range had no low-side event,** though D uses it from both ends: 59% of D_drawdown_252's pushes come from at or below the day's median. Added: a new 52-week closing low.
7. **A crossing was compared with closes where it could not have crossed.** The verdict now compares only with closes where the trigger could have fired; for a crossing, the line was below at the close before.

**Kept on purpose:**
- **The readable indicators remain a translation of D's inputs, not the inputs themselves** (the review's main point). It is now measured and reported per kind. On P_20261115_002, D's push over the top 5 inputs splits into:
  - 62.2% the stock's own daily inputs;
  - 24.7% cross-sectional or weekly inputs, followed through the stock's own daily indicator;
  - 13.1% left out, of which 10.0% is WorldQuant.
- **No entry comparison.** At 10:56 Karan said to do only what is asked. The report and the declaration now state that a TRIGGER is a historical link worth testing as an entry, not a tested entry.

**Found while building (synthetic data only):**
- **v1.3's planted calm event was a 2% drop,** which also moved the stock 2+ ATRs from the target. At the same close and distance, band widening added nothing in that world. That is the right answer to v1.4's question, so v1.4 no longer calls band widening a TRIGGER there. The test world now plants a wide-range day with the close unchanged, and its own trigger (true range above 1.5× ATR) is found through the many-tests check.
- **The confounds, measured on made-up picks:**
  - **Early firing:** a trigger that fires early but says nothing passes the old pooled comparison and not the same-close one.
  - **Firing state:** a crossing that fires only out of a state that itself speeds the move shows about +11 to +13 points when compared with every close, and nothing when compared with closes where it could have fired.
- **Two planted bugs slipped through the first v1.4 suite:**
  - counting unmatched firings toward the 100;
  - "within 5% of the 52-week high" firing where the 52-week high starts.
  - tt5 now has a cell with only firings, and tt3 has a series that is always at its high. Both bugs are now caught.

## Part T's planted bugs (v1.4), 39 of 39 caught

- **Claims (26), part K (12), part P (22):** listed in the earlier manifests. That code is unchanged.
- **Part T (39):**
  - **17 carried over from v1.3's 18, run on the v1.4 code** (the 18th, "verdict without the distance bins", is listed under v1.4):
    - translation: candle checked after volatility; market series not left out;
    - indicators: RSI smoothed like an EMA; Bollinger with the sample SD; range expansion against today's ATR; the 52-week high including today;
    - the move measured from the signal-day close;
    - the verdict: 5 closes ahead; counting the move's own close; one period enough;
    - the shown measure: equal weights for the days; counting the move close;
    - kinds and indicators: every pick on every trigger; MIXED picks pooled; pushes at or below 0 counted as own;
    - the gate at 90%; part P's hashes not checked.
  - **v1.4's 22:**
    - translation: the old day-of-week pattern; cross-sectional inputs counted as own daily;
    - indicators: ROC 65 from 64 bars back; ROC 20 from 21; the 13-week high including today; the 52-week low against the high; a crossing allowed anywhere; "within 5% of the 52-week high" firing where it could not;
    - the verdict:
      - ignoring where the trigger could fire;
      - pooling the closes;
      - no distance bins;
      - unmatched firings counted;
      - a one-sided p;
    - the many-tests check: none at all; the stronger period's p; opposite periods keeping their p; a 10% rate; MAY BE CHANCE dropped; FALLS TOO from one period;
    - the calendar: only D1 checked;
    - the ledger: a run under the replaced declaration not counted;
    - coverage: counting pushes at or below 0.

**Run time** for `triggers` on your PC is an estimate: a few minutes, mostly reading the bars. The same-close comparison has about 7 times as many cells as v1.3's, which adds some time to the bootstrap.

**Run time** for `choices` on your PC is an estimate: a few minutes (reading the bars for the window's D picks, then 26 books x 5 start days in setuplab's own book code). It took 30 s (C_20261115_001).

**Run time** for `modify` on your PC is an estimate: a few minutes. Most of it is reading the panel (9 feature columns, then the 13-week return). The 71 books (68 changes, the tree, the baseline and the size check) x 5 start days take about three times part C's 26.
